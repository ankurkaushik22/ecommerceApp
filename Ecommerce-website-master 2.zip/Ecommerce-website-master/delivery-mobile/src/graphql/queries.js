import { gql } from '@apollo/client';

export const GET_TAX_SETTINGS = gql`
  query GetTaxSettings($activeOnly: Boolean) {
    getTaxSettings(activeOnly: $activeOnly) {
      _id
      name
      rate
      cgst
      sgst
      igst
      hsnCode
      isDefault
      isActive
      description
    }
  }
`;

export const GET_DELIVERY_AGENT_ORDERS = gql`
  query GetDeliveryAgentOrders($status: String) {
    getDeliveryAgentOrders(status: $status) {
      _id
      orderNumber
      status
      paymentMethod
      paymentStatus
      subtotal
      shippingCost
      discount
      tax
      total
      estimatedDelivery
      deliveredAt
      createdAt
      notes
      vendorNotes
      deliveryInstructions
      customer {
        _id
        name
        email
        phone
        avatar
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      items {
        product {
          _id
        }
        name
        price
        quantity
        image
        variantLabel
        total
        addons {
          name
          price
          icon
        }
        instructions
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const GET_ORDER_BY_ID = gql`
  query GetOrder($id: ID!) {
    getOrder(id: $id) {
      _id
      orderNumber
      status
      paymentMethod
      paymentStatus
      subtotal
      shippingCost
      tax
      total
      estimatedDelivery
      deliveredAt
      createdAt
      notes
      vendorNotes
      deliveryInstructions
      customer {
        _id
        name
        email
        phone
        avatar
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      items {
        product {
          _id
        }
        name
        price
        quantity
        image
        variantLabel
        total
        addons {
          name
          price
          icon
        }
        instructions
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      destinationLocation {
        latitude
        longitude
        address
      }
      deliveryLocationUpdates {
        latitude
        longitude
        heading
        timestamp
        status
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const GET_STORE_SETTINGS = gql`
  query GetStoreSettings {
    getStoreSettings {
      _id
      storeName
      disabledVerticals
      latestDeliveryVersion
      deliveryApkUrl
      forceAppUpdate
    }
  }
`;

export const GET_ME = gql`
  query GetMe {
    me {
      _id
      name
      email
      phone
      avatar
      role
      isVerified
      isOnline
      deliveryPayoutType
      deliveryPerOrderRate
      deliveryMonthlySalary
      deliveryDailyIncentive
      deliveryMinOrdersForIncentive
      vehicleType
      vehicleRegistrationNumber
      submittedCash
      vehicles {
        _id
        vehicleType
        registrationNumber
        isPrimary
      }
    }
  }
`;

export const GET_NOTIFICATIONS = gql`
  query GetNotifications {
    getNotifications {
      _id
      title
      message
      type
      isRead
      createdAt
      targetId
      link
    }
  }
`;

export const GET_DASHBOARD_STATS = gql`
  query GetDashboardStats($vertical: String) {
    getDashboardStats(vertical: $vertical) {
      totalRevenue
      todayRevenue
      totalOrders
      todayOrders
      totalProducts
      totalUsers
      totalVendors
      pendingOrders
      pendingVendorCount
      pendingProductCount
      recentOrders {
        _id
        orderNumber
        total
        subtotal
        tax
        shippingCost
        discount
        status
        paymentMethod
        paymentStatus
        createdAt
        customer {
          _id
          name
          email
          phone
          avatar
        }
        shippingAddress {
          fullName
          phone
          addressLine1
          city
          state
          postalCode
        }
        items {
          name
          quantity
          price
          image
        }
      }
    }
  }
`;

export const GET_ALL_PRODUCTS = gql`
  query GetAllProducts($filter: ProductFilterInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, pagination: $pagination) {
      products {
        _id
        name
        slug
        price
        comparePrice
        stock
        sku
        vertical
        isActive
        approvalStatus
        images
        salesCount
        createdAt
        vendor {
          _id
          name
          email
        }
        category {
          _id
          name
        }
        rating {
          average
          count
        }
      }
      total
      page
      pages
    }
  }
`;

export const GET_ALL_ORDERS = gql`
  query GetAllOrders($status: String, $search: String, $pagination: PaginationInput) {
    getOrders(status: $status, search: $search, pagination: $pagination) {
      orders {
        _id
        orderNumber
        status
        paymentMethod
        paymentStatus
        subtotal
        shippingCost
        discount
        tax
        total
        createdAt
        customer {
          _id
          name
          email
          phone
        }
        shippingAddress {
          fullName
          phone
          addressLine1
          city
          state
          postalCode
        }
        items {
          name
          price
          quantity
          image
          variantLabel
          total
        }
        deliveryAgent {
          _id
          name
          phone
        }
        deliveryBoy {
          _id
          name
          phone
        }
      }
      total
      page
      pages
    }
  }
`;

export const GET_DELIVERY_AGENTS = gql`
  query GetDeliveryAgents {
    getDeliveryAgents {
      _id
      name
      phone
      email
      avatar
      isOnline
    }
  }
`;

export const GET_VENDOR_PAYOUT_SUMMARY = gql`
  query GetVendorPayoutSummary($vendorId: ID) {
    getVendorPayoutSummary(vendorId: $vendorId) {
      totalSales
      totalCommission
      totalEarnings
      eligibleBalance
      pendingPayout
      totalPaidOut
      returnPendingBalance
      bankDetails {
        accountHolderName
        accountNumber
        bankName
        ifscCode
        upiId
      }
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories($vertical: String) {
    getCategories(vertical: $vertical) {
      _id
      name
      slug
      vertical
    }
  }
`;






