import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_ORDER_BY_ID } from '../../graphql/queries';
import { UPDATE_DELIVERY_STATUS, UPDATE_DELIVERY_LOCATION } from '../../graphql/mutations';
import { useDutyStore } from '../../store/dutyStore';
import Header from '../../components/common/Header';
import StatusBadge from '../../components/common/StatusBadge';
import DeliveryMapView from '../../components/map/DeliveryMapView';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const FAILURE_REASONS = [
  'Customer Unavailable / Phone Unreachable',
  'Customer Refused Delivery',
  'Incorrect / Incomplete Address',
  'Package Damaged / Premises Locked',
  'Other Reason',
];

export default function DeliveryDetailScreen({ route, navigation }) {
  const { orderId } = route.params || {};
  const { currentLocation, setCurrentLocation } = useDutyStore();
  const [isSimulating, setIsSimulating] = useState(false);

  const [showFailModal, setShowFailModal] = useState(false);
  const [selectedFailReason, setSelectedFailReason] = useState(FAILURE_REASONS[0]);
  const [customFailNotes, setCustomFailNotes] = useState('');

  const { data, loading, refetch } = useQuery(GET_ORDER_BY_ID, {
    variables: { id: orderId },
    skip: !orderId,
    pollInterval: 5000,
  });

  const [updateStatus, { loading: updatingStatus }] = useMutation(UPDATE_DELIVERY_STATUS, {
    onCompleted: () => {
      refetch();
    },
    onError: (err) => {
      Alert.alert('Update Failed', err.message);
    },
  });

  const [updateLocation] = useMutation(UPDATE_DELIVERY_LOCATION);

  const order = data?.getOrder;

  if (loading || !order) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading delivery task details...</Text>
      </View>
    );
  }

  const address = order.shippingAddress;
  const addressString = address
    ? `${address.addressLine1 || ''}, ${address.addressLine2 ? address.addressLine2 + ', ' : ''}${address.city || ''}, ${address.state || ''} - ${address.postalCode || ''}`
    : 'Customer Address';

  const customerLat = order.destinationLocation?.latitude || 28.995;
  const customerLng = order.destinationLocation?.longitude || 77.718;

  const agentLat = order.liveLocation?.latitude || currentLocation.latitude;
  const agentLng = order.liveLocation?.longitude || currentLocation.longitude;

  // 1-Step Simulated movement towards customer
  const handleSimulateMove = () => {
    const nextLat = agentLat + (customerLat - agentLat) * 0.25;
    const nextLng = agentLng + (customerLng - agentLng) * 0.25;

    const newLoc = {
      latitude: parseFloat(nextLat.toFixed(5)),
      longitude: parseFloat(nextLng.toFixed(5)),
      heading: 45,
      speed: 28,
    };
    setCurrentLocation(newLoc);

    updateLocation({
      variables: {
        orderId: order._id,
        latitude: newLoc.latitude,
        longitude: newLoc.longitude,
        heading: newLoc.heading,
        speed: newLoc.speed,
      },
    });

    Alert.alert(
      'Live GPS Updated',
      `Broadcasted new coordinates: ${newLoc.latitude}, ${newLoc.longitude} to customer app.`
    );
  };

  const handleStatusChange = (nextStatus, message) => {
    Alert.alert(
      'Confirm Status Update',
      `Are you sure you want to mark this package as "${nextStatus.replace(/_/g, ' ').toUpperCase()}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            updateStatus({
              variables: {
                orderId: order._id,
                status: nextStatus,
                notes: message,
                latitude: agentLat,
                longitude: agentLng,
              },
            });
          },
        },
      ]
    );
  };

  const handleConfirmFailure = () => {
    const finalReason = selectedFailReason === 'Other Reason'
      ? (customFailNotes.trim() || 'Delivery failed')
      : `${selectedFailReason}${customFailNotes.trim() ? ` (${customFailNotes.trim()})` : ''}`;

    updateStatus({
      variables: {
        orderId: order._id,
        status: 'cancelled',
        notes: `Delivery Failed: ${finalReason}`,
        latitude: agentLat,
        longitude: agentLng,
      },
    });

    setShowFailModal(false);
  };

  return (
    <View style={styles.container}>
      <Header
        title={`Task #${order.orderNumber || order._id.slice(-6)}`}
        subtitle={order.status.replace(/_/g, ' ').toUpperCase()}
        showBack={true}
        rightComponent={
          <TouchableOpacity
            style={styles.navHeaderBtn}
            onPress={() => navigation.navigate('LiveTrackingNav', { orderId: order._id })}
          >
            <Ionicons name="map" size={18} color={COLORS.primary} />
            <Text style={styles.navHeaderBtnText}>Live Nav</Text>
          </TouchableOpacity>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Interactive Map View */}
        <DeliveryMapView
          agentLocation={{ latitude: agentLat, longitude: agentLng }}
          customerLocation={{ latitude: customerLat, longitude: customerLng }}
          customerAddress={addressString}
          customerName={address?.fullName || order.customer?.name || 'Customer'}
          customerPhone={address?.phone || order.customer?.phone}
          orderNumber={order.orderNumber}
          orderStatus={order.status}
          onSimulateMove={handleSimulateMove}
          isLiveBroadcasting={order.status === 'out_for_delivery'}
        />

        {/* Action Stepper Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Delivery Progress & Actions</Text>
          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>Current Status:</Text>
            <StatusBadge status={order.status} />
          </View>

          {/* Stepper Buttons based on status */}
          {['placed', 'accepted', 'processing', 'ready_for_pickup', 'confirmed', 'preparing'].includes(order.status) && (
            <TouchableOpacity
              style={styles.actionBtnPrimary}
              onPress={() =>
                handleStatusChange(
                  'picked_up',
                  'Delivery agent accepted the task and picked up package.'
                )
              }
              disabled={updatingStatus}
            >
              <Ionicons name="cube-outline" size={20} color={COLORS.white} />
              <Text style={styles.actionBtnText}>Accept & Pick Up Package</Text>
            </TouchableOpacity>
          )}

          {['picked_up', 'dispatched'].includes(order.status) && (
            <View style={{ gap: 10 }}>
              <TouchableOpacity
                style={[styles.actionBtnPrimary, { backgroundColor: COLORS.secondary }]}
                onPress={() =>
                  handleStatusChange(
                    'out_for_delivery',
                    'Delivery agent is heading towards customer address with the package.'
                  )
                }
                disabled={updatingStatus}
              >
                <Ionicons name="bicycle" size={20} color={COLORS.white} />
                <Text style={styles.actionBtnText}>Start Journey: Out for Delivery</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionBtnSuccess}
                onPress={() =>
                  handleStatusChange(
                    'delivered',
                    'Package successfully handed over to customer. Payment reconciled.'
                  )
                }
                disabled={updatingStatus}
              >
                <Ionicons name="checkmark-circle" size={20} color={COLORS.white} />
                <Text style={styles.actionBtnText}>Mark as Successfully Delivered 🎉</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionBtnDanger}
                onPress={() => setShowFailModal(true)}
                disabled={updatingStatus}
              >
                <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                <Text style={styles.actionBtnDangerText}>Mark Delivery Failed ❌</Text>
              </TouchableOpacity>
            </View>
          )}

          {order.status === 'out_for_delivery' && (
            <View style={styles.outForDeliveryActions}>
              <TouchableOpacity
                style={styles.actionBtnSuccess}
                onPress={() =>
                  handleStatusChange(
                    'delivered',
                    'Package successfully handed over to customer. Payment reconciled.'
                  )
                }
                disabled={updatingStatus}
              >
                <Ionicons name="checkmark-circle" size={20} color={COLORS.white} />
                <Text style={styles.actionBtnText}>Mark as Successfully Delivered 🎉</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.actionBtnDanger}
                onPress={() => setShowFailModal(true)}
                disabled={updatingStatus}
              >
                <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                <Text style={styles.actionBtnDangerText}>Mark Delivery Failed ❌</Text>
              </TouchableOpacity>
            </View>
          )}

          {order.status === 'delivered' && (
            <View style={styles.deliveredBanner}>
              <Ionicons name="checkmark-done-circle" size={24} color={COLORS.success} />
              <Text style={styles.deliveredBannerText}>This order is completed and delivered.</Text>
            </View>
          )}

          {order.status === 'cancelled' && (
            <View style={[styles.deliveredBanner, { backgroundColor: '#FEE2E2', borderColor: '#FCA5A5', borderWidth: 1 }]}>
              <Ionicons name="alert-circle" size={24} color="#DC2626" />
              <View style={{ flex: 1 }}>
                <Text style={{ color: '#DC2626', fontSize: 13, fontWeight: '800' }}>Delivery Failed / Cancelled</Text>
                {Boolean(order.cancelReason) && (
                  <Text style={{ color: '#991B1B', fontSize: 12, marginTop: 2 }}>
                    Reason: {order.cancelReason}
                  </Text>
                )}
              </View>
            </View>
          )}
        </View>

        {/* Customer & Address Details */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Customer Information</Text>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name</Text>
            <Text style={styles.infoValue}>
              {address?.fullName || order.customer?.name || 'Customer'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Phone</Text>
            <Text style={styles.infoValue}>
              {address?.phone || order.customer?.phone || 'Not provided'}
            </Text>
          </View>

          <View style={[styles.infoRow, { flexDirection: 'column', alignItems: 'flex-start' }]}>
            <Text style={styles.infoLabel}>Delivery Address</Text>
            <Text style={[styles.infoValue, { marginTop: 4 }]}>
              {addressString}
            </Text>
          </View>

          {Boolean(order.vendorNotes) && (
            <View style={{ marginTop: 12, backgroundColor: '#EFF6FF', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#BFDBFE' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <Ionicons name="storefront" size={16} color="#1D4ED8" />
                <Text style={{ fontSize: 11, fontWeight: '700', color: '#1D4ED8', textTransform: 'uppercase' }}>
                  Merchant / Vendor Note
                </Text>
              </View>
              <Text style={{ fontSize: 13, color: '#1E3A8A', fontWeight: '600', lineHeight: 18 }}>
                {order.vendorNotes}
              </Text>
            </View>
          )}

          {Boolean(order.notes || order.deliveryInstructions) && (
            <View style={{ marginTop: 12, backgroundColor: '#FEF3C7', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#FDE68A' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                <Ionicons name="alert-circle" size={16} color="#B45309" />
                <Text style={{ fontSize: 11, fontWeight: '700', color: '#B45309', textTransform: 'uppercase' }}>
                  Delivery Instructions
                </Text>
              </View>
              <Text style={{ fontSize: 13, color: '#92400E', fontWeight: '600', lineHeight: 18 }}>
                {order.notes || order.deliveryInstructions}
              </Text>
            </View>
          )}
        </View>

        {/* Package Items Breakdown */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Package Contents ({order.items?.length || 0} items)</Text>
          {order.items?.map((item, idx) => (
            <View key={item._id || idx} style={styles.itemRow}>
              {item.image ? (
                <Image source={{ uri: item.image }} style={styles.itemImage} />
              ) : (
                <View style={styles.itemPlaceholder}>
                  <Ionicons name="cube-outline" size={20} color={COLORS.textMuted} />
                </View>
              )}
              <View style={styles.itemInfo}>
                <Text style={styles.itemName} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.itemQty}>Qty: {item.quantity || 1}</Text>
              </View>
              <Text style={styles.itemPrice}>₹{((item.price || 0) * (item.quantity || 1)).toFixed(0)}</Text>
            </View>
          ))}

          {/* Payment Summary */}
          <View style={styles.paymentSummary}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Payment Mode</Text>
              <Text style={styles.summaryValue}>
                {order.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : 'Prepaid Online'}
              </Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Total Payable Amount</Text>
              <Text style={styles.totalValue}>₹{order.total?.toFixed(0)}</Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Mark Delivery Failed Modal */}
      <Modal
        visible={showFailModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowFailModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View style={styles.modalHeaderTitleGroup}>
                <Ionicons name="alert-circle-outline" size={24} color="#EF4444" />
                <Text style={styles.modalTitle}>Mark Delivery Failed</Text>
              </View>
              <TouchableOpacity onPress={() => setShowFailModal(false)}>
                <Ionicons name="close" size={22} color="#6B7280" />
              </TouchableOpacity>
            </View>

            <Text style={styles.modalSub}>Select a reason for delivery failure:</Text>

            <ScrollView style={{ maxHeight: 220, marginVertical: 10 }}>
              {FAILURE_REASONS.map((reason) => {
                const isSelected = selectedFailReason === reason;
                return (
                  <TouchableOpacity
                    key={reason}
                    style={[styles.reasonChip, isSelected && styles.reasonChipActive]}
                    onPress={() => setSelectedFailReason(reason)}
                    activeOpacity={0.8}
                  >
                    <Ionicons
                      name={isSelected ? 'radio-button-on' : 'radio-button-off'}
                      size={18}
                      color={isSelected ? '#EF4444' : '#9CA3AF'}
                    />
                    <Text style={[styles.reasonText, isSelected && styles.reasonTextActive]}>
                      {reason}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>

            <Text style={styles.inputLabel}>Additional Notes / Reason Details</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="e.g. Tried calling customer 3 times, no answer..."
              placeholderTextColor="#9CA3AF"
              multiline
              value={customFailNotes}
              onChangeText={setCustomFailNotes}
            />

            <View style={styles.modalActionRow}>
              <TouchableOpacity style={styles.modalCancelBtn} onPress={() => setShowFailModal(false)}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalConfirmBtn}
                onPress={handleConfirmFailure}
                disabled={updatingStatus}
              >
                {updatingStatus ? (
                  <ActivityIndicator color="#FFFFFF" size="small" />
                ) : (
                  <Text style={styles.modalConfirmText}>Submit Failure</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.background,
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  navHeaderBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    gap: 4,
  },
  navHeaderBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statusLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  actionBtnPrimary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  actionBtnSuccess: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.success,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  actionBtnDanger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FEF2F2',
    borderWidth: 1.5,
    borderColor: '#FCA5A5',
    paddingVertical: 12,
    borderRadius: SIZES.radius,
    gap: 8,
    marginTop: 4,
  },
  actionBtnDangerText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '800',
  },
  actionBtnText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '700',
  },
  outForDeliveryActions: {
    gap: 10,
  },
  deliveredBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.successLight,
    padding: 12,
    borderRadius: 8,
    gap: 8,
  },
  deliveredBannerText: {
    color: COLORS.success,
    fontSize: 13,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  infoLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 13,
    color: COLORS.text,
    fontWeight: '700',
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  itemImage: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    marginRight: 10,
  },
  itemPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  itemQty: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  itemPrice: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  paymentSummary: {
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  summaryLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  summaryValue: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '900',
    color: COLORS.primary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.55)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalCard: {
    width: '100%',
    backgroundColor: COLORS.surface,
    borderRadius: 20,
    padding: 20,
    ...SHADOWS.medium,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  modalHeaderTitleGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#111827',
  },
  modalSub: {
    fontSize: 13,
    color: '#6B7280',
    marginBottom: 8,
  },
  reasonChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    marginBottom: 8,
    gap: 10,
    backgroundColor: '#F9FAFB',
  },
  reasonChipActive: {
    borderColor: '#EF4444',
    backgroundColor: '#FEF2F2',
  },
  reasonText: {
    fontSize: 13,
    color: '#374151',
    fontWeight: '600',
  },
  reasonTextActive: {
    color: '#DC2626',
    fontWeight: '800',
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: '#374151',
    marginTop: 4,
    marginBottom: 6,
  },
  modalInput: {
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    padding: 12,
    fontSize: 13,
    color: '#111827',
    height: 70,
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  modalActionRow: {
    flexDirection: 'row',
    gap: 10,
  },
  modalCancelBtn: {
    flex: 1,
    height: 44,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#D1D5DB',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCancelText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#4B5563',
  },
  modalConfirmBtn: {
    flex: 1,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#EF4444',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalConfirmText: {
    fontSize: 14,
    fontWeight: '800',
    color: '#FFFFFF',
  },
});
