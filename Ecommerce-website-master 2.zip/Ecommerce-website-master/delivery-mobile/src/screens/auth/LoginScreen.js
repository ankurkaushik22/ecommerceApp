import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Modal,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useMutation } from '@apollo/client';
import {
  LOGIN_MUTATION,
  FORGOT_PASSWORD_MUTATION,
  VERIFY_RESET_OTP_MUTATION,
  RESET_PASSWORD_MUTATION,
  REGISTER_MUTATION,
} from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function LoginScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [mobileNumber, setMobileNumber] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Forgot Password Modal State
  const [forgotModalVisible, setForgotModalVisible] = useState(false);
  const [forgotStep, setForgotStep] = useState(1);
  const [forgotMobile, setForgotMobile] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Vendor Registration Modal State
  const [vendorModalVisible, setVendorModalVisible] = useState(false);
  const [vendorName, setVendorName] = useState('');
  const [vendorEmail, setVendorEmail] = useState('');
  const [vendorPhone, setVendorPhone] = useState('');
  const [vendorPassword, setVendorPassword] = useState('');
  const [showVendorPassword, setShowVendorPassword] = useState(false);
  const [vendorVertical, setVendorVertical] = useState('shopping');

  const setAuth = useAuthStore((s) => s.setAuth);

  const [registerVendorMutation, { loading: registerLoading }] = useMutation(REGISTER_MUTATION, {
    onCompleted: (data) => {
      const { user, token } = data.register;
      Alert.alert(
        'Business Registered!',
        `Welcome ${user.name || 'Vendor'}! Your vendor account has been created successfully.`,
        [
          {
            text: 'Open Vendor Console',
            onPress: () => {
              setVendorModalVisible(false);
              resetVendorForm();
              setAuth(user, token);
            },
          },
        ]
      );
    },
    onError: (err) => {
      Alert.alert('Registration Failed', err.message || 'Could not create vendor account');
    },
  });

  const resetVendorForm = () => {
    setVendorName('');
    setVendorEmail('');
    setVendorPhone('');
    setVendorPassword('');
    setShowVendorPassword(false);
    setVendorVertical('shopping');
  };

  const handleVendorRegisterSubmit = () => {
    if (!vendorName.trim()) {
      Alert.alert('Required Field', 'Please enter your company/store name.');
      return;
    }
    if (!vendorEmail.trim()) {
      Alert.alert('Required Field', 'Please enter your business email.');
      return;
    }
    if (!vendorPassword || vendorPassword.length < 6) {
      Alert.alert('Invalid Password', 'Password must be at least 6 characters long.');
      return;
    }

    registerVendorMutation({
      variables: {
        input: {
          name: vendorName.trim(),
          email: vendorEmail.trim(),
          phone: vendorPhone.trim() || undefined,
          password: vendorPassword,
          role: 'vendor',
          vendorVertical: vendorVertical,
          vendorCategory: 'General Seller',
          acceptedTerms: true,
        },
      },
    });
  };

  const [loginMutation, { loading }] = useMutation(LOGIN_MUTATION, {
    onCompleted: (data) => {
      const { user, token } = data.login;
      setAuth(user, token);
    },
    onError: (err) => {
      Alert.alert('Login Failed', err.message || 'Invalid delivery partner credentials');
    },
  });

  const [forgotPasswordMutation, { loading: forgotLoading }] = useMutation(
    FORGOT_PASSWORD_MUTATION,
    {
      onCompleted: (data) => {
        Alert.alert('OTP Sent', data.forgotPassword?.message || 'Verification OTP sent');
        setForgotStep(2);
      },
      onError: (err) => {
        Alert.alert('Error', err.message || 'Failed to request password reset');
      },
    }
  );

  const [verifyOtpMutation, { loading: verifyLoading }] = useMutation(
    VERIFY_RESET_OTP_MUTATION,
    {
      onCompleted: (data) => {
        if (data.verifyResetOTP?.resetToken) {
          setResetToken(data.verifyResetOTP.resetToken);
          setForgotStep(3);
        } else {
          Alert.alert('Success', data.verifyResetOTP?.message || 'OTP verified');
          setForgotStep(3);
        }
      },
      onError: (err) => {
        Alert.alert('Verification Failed', err.message || 'Invalid or expired OTP');
      },
    }
  );

  const [resetPasswordMutation, { loading: resetLoading }] = useMutation(
    RESET_PASSWORD_MUTATION,
    {
      onCompleted: (data) => {
        const { user, token } = data.resetPassword;
        Alert.alert('Password Updated', 'Your password has been successfully reset!');
        setForgotModalVisible(false);
        resetForgotState();
        setAuth(user, token);
      },
      onError: (err) => {
        Alert.alert('Reset Failed', err.message || 'Failed to reset password');
      },
    }
  );

  const resetForgotState = () => {
    setForgotStep(1);
    setForgotMobile('');
    setOtpCode('');
    setResetToken('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleLogin = () => {
    if (!mobileNumber.trim() || !password.trim()) {
      Alert.alert('Required', 'Please enter your mobile number and password');
      return;
    }
    loginMutation({
      variables: {
        input: { email: mobileNumber.trim(), password: password.trim() },
      },
    });
  };

  const handleRequestOtp = () => {
    if (!forgotMobile.trim()) {
      Alert.alert('Required', 'Please enter your registered mobile number or email');
      return;
    }
    forgotPasswordMutation({
      variables: { email: forgotMobile.trim() },
    });
  };

  const handleVerifyOtp = () => {
    if (!otpCode.trim()) {
      Alert.alert('Required', 'Please enter the verification OTP code');
      return;
    }
    verifyOtpMutation({
      variables: { email: forgotMobile.trim(), otp: otpCode.trim() },
    });
  };

  const handleResetPasswordSubmit = () => {
    if (!newPassword || newPassword.length < 6) {
      Alert.alert('Invalid Password', 'New password must be at least 6 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert('Mismatch', 'Passwords do not match');
      return;
    }
    resetPasswordMutation({
      variables: { token: resetToken, newPassword },
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: Math.max(insets.top, 24) },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Brand Banner */}
        <View style={styles.header}>
          <Image
            source={require('../../../assets/logo.png')}
            style={styles.logoImage}
            resizeMode="contain"
          />
          <Text style={styles.title}>Suaaka Partner Console</Text>
          <Text style={styles.subtitle}>Vendor, Delivery & Admin Multi-Role Portal</Text>
        </View>

        {/* Login Form Card */}
        <View style={styles.formCard}>
          {/* Email / Mobile Input */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Email / Mobile Number</Text>
            <View style={styles.inputBox}>
              <Ionicons name="person-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Enter email or mobile number"
                placeholderTextColor="#94A3B8"
                keyboardType="default"
                autoCapitalize="none"
                value={mobileNumber}
                onChangeText={setMobileNumber}
              />
            </View>
          </View>

          {/* Password Input */}
          <View style={styles.inputGroup}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={styles.label}>Password</Text>
              <TouchableOpacity
                onPress={() => {
                  setForgotMobile(mobileNumber);
                  setForgotModalVisible(true);
                }}
              >
                <Text style={styles.forgotBtnText}>Forgot Password?</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.inputBox}>
              <Ionicons name="lock-closed-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="••••••••"
                placeholderTextColor="#94A3B8"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color="#94A3B8"
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* Access Delivery Console Submit Button */}
          <TouchableOpacity
            style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color={COLORS.white} />
            ) : (
              <>
                <Ionicons name="log-in-outline" size={20} color={COLORS.white} />
                <Text style={styles.loginBtnText}>Access Delivery Console</Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* Register a Business Option Card */}
        <View style={styles.vendorCard}>
          <View style={styles.vendorHeaderRow}>
            <View style={styles.vendorBadge}>
              <Ionicons name="storefront-outline" size={22} color="#047857" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.vendorCardTitle}>Own a store or restaurant?</Text>
              <Text style={styles.vendorCardSub}>
                Register a business with us & sell to thousands of customers.
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.vendorRegisterBtn}
            activeOpacity={0.85}
            onPress={() => setVendorModalVisible(true)}
          >
            <Ionicons name="cart-outline" size={20} color={COLORS.white} />
            <Text style={styles.vendorRegisterBtnText}>Register a business with us</Text>
          </TouchableOpacity>
        </View>

        {/* Footer Note */}
        <View style={styles.footerNote}>
          <Ionicons name="shield-checkmark-outline" size={16} color="#047857" />
          <Text style={styles.footerNoteText}>
            GPS Location tracking is active only during duty hours.
          </Text>
        </View>
      </ScrollView>

      {/* FORGOT PASSWORD MODAL */}
      <Modal visible={forgotModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Ionicons name="key-outline" size={22} color="#047857" />
                <Text style={styles.modalTitle}>Forgot Password</Text>
              </View>
              <TouchableOpacity
                onPress={() => {
                  setForgotModalVisible(false);
                  resetForgotState();
                }}
              >
                <Ionicons name="close" size={24} color={COLORS.textSecondary} />
              </TouchableOpacity>
            </View>

            {forgotStep === 1 && (
              <View style={{ marginTop: 12 }}>
                <Text style={styles.stepTitle}>Step 1: Enter Mobile Number</Text>
                <Text style={styles.stepDesc}>
                  Enter your registered mobile number or email to receive a password reset OTP.
                </Text>
                <View style={[styles.inputBox, { marginTop: 14 }]}>
                  <Ionicons name="call-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Enter mobile number"
                    placeholderTextColor="#94A3B8"
                    keyboardType="phone-pad"
                    value={forgotMobile}
                    onChangeText={setForgotMobile}
                  />
                </View>
                <TouchableOpacity
                  style={[styles.modalSubmitBtn, forgotLoading && styles.loginBtnDisabled]}
                  onPress={handleRequestOtp}
                  disabled={forgotLoading}
                >
                  {forgotLoading ? (
                    <ActivityIndicator color={COLORS.white} />
                  ) : (
                    <Text style={styles.modalSubmitBtnText}>Send Verification OTP</Text>
                  )}
                </TouchableOpacity>
              </View>
            )}

            {forgotStep === 2 && (
              <View style={{ marginTop: 12 }}>
                <Text style={styles.stepTitle}>Step 2: Enter Verification OTP</Text>
                <Text style={styles.stepDesc}>
                  Enter the 6-digit OTP code sent for {forgotMobile}.
                </Text>
                <View style={[styles.inputBox, { marginTop: 14 }]}>
                  <Ionicons name="shield-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={[styles.input, { letterSpacing: 4, fontWeight: '700' }]}
                    placeholder="123456"
                    placeholderTextColor="#94A3B8"
                    keyboardType="number-pad"
                    maxLength={6}
                    value={otpCode}
                    onChangeText={setOtpCode}
                  />
                </View>
                <TouchableOpacity
                  style={[styles.modalSubmitBtn, verifyLoading && styles.loginBtnDisabled]}
                  onPress={handleVerifyOtp}
                  disabled={verifyLoading}
                >
                  {verifyLoading ? (
                    <ActivityIndicator color={COLORS.white} />
                  ) : (
                    <Text style={styles.modalSubmitBtnText}>Verify OTP</Text>
                  )}
                </TouchableOpacity>
              </View>
            )}

            {forgotStep === 3 && (
              <View style={{ marginTop: 12 }}>
                <Text style={styles.stepTitle}>Step 3: Create New Password</Text>
                <Text style={styles.stepDesc}>Set a new strong password for your account.</Text>

                <View style={[styles.inputBox, { marginTop: 14 }]}>
                  <Ionicons name="lock-closed-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="New Password (min 6 chars)"
                    placeholderTextColor="#94A3B8"
                    secureTextEntry={!showNewPassword}
                    value={newPassword}
                    onChangeText={setNewPassword}
                  />
                  <TouchableOpacity onPress={() => setShowNewPassword(!showNewPassword)} style={styles.eyeBtn}>
                    <Ionicons
                      name={showNewPassword ? 'eye-off-outline' : 'eye-outline'}
                      size={20}
                      color="#94A3B8"
                    />
                  </TouchableOpacity>
                </View>

                <View style={[styles.inputBox, { marginTop: 10 }]}>
                  <Ionicons name="lock-closed-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Confirm New Password"
                    placeholderTextColor="#94A3B8"
                    secureTextEntry={!showNewPassword}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                  />
                </View>

                <TouchableOpacity
                  style={[styles.modalSubmitBtn, resetLoading && styles.loginBtnDisabled]}
                  onPress={handleResetPasswordSubmit}
                  disabled={resetLoading}
                >
                  {resetLoading ? (
                    <ActivityIndicator color={COLORS.white} />
                  ) : (
                    <Text style={styles.modalSubmitBtnText}>Reset & Log In</Text>
                  )}
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </Modal>

      {/* VENDOR REGISTRATION MODAL */}
      <Modal visible={vendorModalVisible} animationType="slide" transparent>
        <KeyboardAvoidingView
          style={styles.modalOverlay}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View style={[styles.modalContent, { maxHeight: '90%' }]}>
            <View style={styles.modalHeader}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <View style={styles.vendorModalIconBadge}>
                  <Ionicons name="storefront-outline" size={20} color="#047857" />
                </View>
                <View>
                  <Text style={styles.modalTitle}>Register Your Business</Text>
                  <Text style={{ fontSize: 11, color: COLORS.textMuted }}>Create a seller account on Suaaka</Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => {
                  setVendorModalVisible(false);
                  resetVendorForm();
                }}
              >
                <Ionicons name="close" size={24} color={COLORS.textSecondary} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} style={{ marginTop: 12 }}>
              {/* Business Name */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Business / Store Name *</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="business-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Acme Supermarket / Food Hub"
                    placeholderTextColor="#94A3B8"
                    value={vendorName}
                    onChangeText={setVendorName}
                  />
                </View>
              </View>

              {/* Business Email */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Business Email *</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="mail-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. store@example.com"
                    placeholderTextColor="#94A3B8"
                    keyboardType="email-address"
                    autoCapitalize="none"
                    value={vendorEmail}
                    onChangeText={setVendorEmail}
                  />
                </View>
              </View>

              {/* Phone Number */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Phone Number (Optional)</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="call-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Enter phone number"
                    placeholderTextColor="#94A3B8"
                    keyboardType="phone-pad"
                    value={vendorPhone}
                    onChangeText={setVendorPhone}
                  />
                </View>
              </View>

              {/* Password */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Password *</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="lock-closed-outline" size={20} color="#94A3B8" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Minimum 6 characters"
                    placeholderTextColor="#94A3B8"
                    secureTextEntry={!showVendorPassword}
                    value={vendorPassword}
                    onChangeText={setVendorPassword}
                  />
                  <TouchableOpacity onPress={() => setShowVendorPassword(!showVendorPassword)} style={styles.eyeBtn}>
                    <Ionicons
                      name={showVendorPassword ? 'eye-off-outline' : 'eye-outline'}
                      size={20}
                      color="#94A3B8"
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Business Vertical */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Business Vertical</Text>
                <View style={{ gap: 8, marginTop: 4 }}>
                  {[
                    {
                      id: 'shopping',
                      title: 'Shopping (E-Commerce Store)',
                      desc: 'Apparel, electronics & retail products',
                      icon: 'bag-handle',
                    },
                    {
                      id: 'grocery',
                      title: 'Grocery & Essentials',
                      desc: 'Fresh produce, daily essentials & household items',
                      icon: 'basket',
                    },
                    {
                      id: 'food',
                      title: 'Food & Restaurants',
                      desc: 'Cooked meals, beverages & restaurant items',
                      icon: 'fast-food',
                    },
                  ].map((v) => {
                    const isSelected = vendorVertical === v.id;
                    return (
                      <TouchableOpacity
                        key={v.id}
                        onPress={() => setVendorVertical(v.id)}
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          backgroundColor: isSelected ? '#ECFDF5' : '#F8FAFC',
                          borderWidth: isSelected ? 1.5 : 1,
                          borderColor: isSelected ? '#10B981' : '#E2E8F0',
                          borderRadius: SIZES.radius,
                          padding: 12,
                          gap: 10,
                        }}
                      >
                        <Ionicons
                          name={v.icon}
                          size={22}
                          color={isSelected ? '#047857' : '#64748B'}
                        />
                        <View style={{ flex: 1 }}>
                          <Text
                            style={{
                              fontSize: 14,
                              fontWeight: '700',
                              color: isSelected ? '#065F46' : '#1E293B',
                            }}
                          >
                            {v.title}
                          </Text>
                          <Text
                            style={{
                              fontSize: 11,
                              color: isSelected ? '#047857' : '#64748B',
                              marginTop: 2,
                            }}
                          >
                            {v.desc}
                          </Text>
                        </View>
                        <Ionicons
                          name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                          size={22}
                          color={isSelected ? '#047857' : '#CBD5E1'}
                        />
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>

              {/* Submit Registration Button */}
              <TouchableOpacity
                style={[styles.modalSubmitBtn, { backgroundColor: '#047857', marginBottom: 12 }, registerLoading && styles.loginBtnDisabled]}
                onPress={handleVendorRegisterSubmit}
                disabled={registerLoading}
              >
                {registerLoading ? (
                  <ActivityIndicator color={COLORS.white} />
                ) : (
                  <Text style={styles.modalSubmitBtnText}>Create Vendor Account</Text>
                )}
              </TouchableOpacity>
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scroll: {
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginTop: 16,
    marginBottom: 24,
  },
  logoImage: {
    width: 160,
    height: 70,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#0F172A',
    letterSpacing: -0.5,
    marginTop: 16,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    color: '#64748B',
    marginTop: 4,
    fontWeight: '600',
    textAlign: 'center',
  },
  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    ...SHADOWS.medium,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 13,
    fontWeight: '700',
    color: '#334155',
    marginBottom: 8,
  },
  forgotBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#047857',
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    fontSize: 14,
    color: '#0F172A',
  },
  eyeBtn: {
    padding: 6,
  },
  loginBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#047857',
    borderRadius: 14,
    height: 52,
    marginTop: 12,
    gap: 8,
    ...SHADOWS.medium,
  },
  loginBtnDisabled: {
    opacity: 0.6,
  },
  loginBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  vendorCard: {
    backgroundColor: '#ECFDF5',
    borderWidth: 1.5,
    borderColor: '#A7F3D0',
    borderRadius: 20,
    padding: 18,
    marginTop: 20,
    ...SHADOWS.light,
  },
  vendorHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  vendorBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  vendorCardTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
  },
  vendorCardSub: {
    fontSize: 12,
    color: '#475569',
    marginTop: 3,
    fontWeight: '500',
    lineHeight: 17,
  },
  vendorRegisterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#047857',
    borderRadius: 12,
    height: 48,
    gap: 8,
  },
  vendorRegisterBtnText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 28,
    marginBottom: 10,
    gap: 6,
  },
  footerNoteText: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '500',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 20,
    ...SHADOWS.medium,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  stepTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  stepDesc: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  modalSubmitBtn: {
    backgroundColor: '#047857',
    borderRadius: SIZES.radius,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
  },
  modalSubmitBtnText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '800',
  },
  vendorModalIconBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
