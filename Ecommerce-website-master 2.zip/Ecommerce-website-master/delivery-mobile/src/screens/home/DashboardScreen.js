import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  RefreshControl,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_DELIVERY_AGENT_ORDERS } from '../../graphql/queries';
import { UPDATE_AGENT_DUTY_STATUS } from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import { useDutyStore } from '../../store/dutyStore';
import Header from '../../components/common/Header';
import DeliveryCard from '../../components/common/DeliveryCard';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DashboardScreen({ navigation }) {
  const user = useAuthStore((s) => s.user);
  const { isOnDuty, setIsOnDuty, currentLocation } = useDutyStore();
  const [selectedFilter, setSelectedFilter] = useState('all');

  const { data, loading, refetch } = useQuery(GET_DELIVERY_AGENT_ORDERS, {
    pollInterval: 10000, // Poll every 10 seconds for live new assignments
  });

  const [updateDutyStatus] = useMutation(UPDATE_AGENT_DUTY_STATUS);

  const handleToggleDuty = (val) => {
    setIsOnDuty(val);
    updateDutyStatus({
      variables: {
        isOnline: val,
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
      },
    });
  };

  const orders = data?.getDeliveryAgentOrders || [];

  // Filter orders strictly belonging to this driver
  const myOrders = orders.filter((o) =>
    o.deliveryAgent?._id === user?._id ||
    o.deliveryBoy?._id === user?._id ||
    o.deliveryAgent === user?._id ||
    o.deliveryBoy === user?._id ||
    (!o.deliveryAgent && !o.deliveryBoy)
  );

  // Active assigned orders strictly for Tasks tab (excluding delivered/completed which are in History tab)
  const activeTasks = myOrders.filter((o) =>
    ['placed', 'accepted', 'processing', 'ready_for_pickup', 'picked_up', 'confirmed', 'preparing', 'dispatched', 'out_for_delivery'].includes(o.status)
  );

  const filteredOrders = activeTasks.filter((o) => {
    if (selectedFilter === 'active') {
      return ['placed', 'accepted', 'processing', 'ready_for_pickup', 'confirmed', 'preparing'].includes(o.status);
    }
    if (selectedFilter === 'out_for_delivery') {
      return ['out_for_delivery', 'picked_up', 'dispatched'].includes(o.status);
    }
    return true;
  });

  return (
    <View style={styles.container}>
      <Header
        title="Delivery Console"
        subtitle={`Partner ID: #${user?._id?.slice(-6) || '84920'}`}
        rightComponent={
          <View style={styles.dutyToggleWrap}>
            <Text style={[styles.dutyText, { color: isOnDuty ? COLORS.success : COLORS.textMuted }]}>
              {isOnDuty ? 'ON DUTY' : 'OFFLINE'}
            </Text>
            <Switch
              value={isOnDuty}
              onValueChange={handleToggleDuty}
              trackColor={{ false: '#CBD5E1', true: '#A7F3D0' }}
              thumbColor={isOnDuty ? COLORS.primary : '#F1F5F9'}
            />
          </View>
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} colors={[COLORS.primary]} />}
      >
        {/* Section Header */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>My Deliveries</Text>
          <Text style={styles.sectionCount}>{filteredOrders.length} Tasks</Text>
        </View>

        {/* Filter Pills */}
        <View style={styles.pillRow}>
          {[
            { label: 'All Tasks', value: 'all' },
            { label: 'Assigned Now', value: 'active' },
            { label: 'Out for Delivery', value: 'out_for_delivery' },
          ].map((pill) => (
            <TouchableOpacity
              key={pill.value}
              style={[styles.pill, selectedFilter === pill.value && styles.pillActive]}
              onPress={() => setSelectedFilter(pill.value)}
            >
              <Text
                style={[
                  styles.pillText,
                  selectedFilter === pill.value && styles.pillTextActive,
                ]}
              >
                {pill.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="bicycle-outline" size={54} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Deliveries in this list</Text>
            <Text style={styles.emptySub}>
              {isOnDuty
                ? 'Stay nearby the hub. New orders will appear here automatically.'
                : 'Turn ON your duty switch to get assigned new orders.'}
            </Text>
          </View>
        ) : (
          filteredOrders.map((order) => (
            <DeliveryCard
              key={order._id}
              order={order}
              onPress={() => navigation.navigate('DeliveryDetail', { orderId: order._id })}
              onTrackPress={() => navigation.navigate('LiveTrackingNav', { orderId: order._id })}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  dutyToggleWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  dutyText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  sectionCount: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.primary,
  },
  pillRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  pill: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  pillActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  pillText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  pillTextActive: {
    color: COLORS.white,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginTop: 10,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 12,
  },
  emptySub: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 18,
  },
});
