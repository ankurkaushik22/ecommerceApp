import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_ALL_ORDERS } from '../../graphql/queries';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

function formatDate(createdAt) {
  if (!createdAt) return 'N/A';
  const raw = typeof createdAt === 'string' && !isNaN(createdAt) ? Number(createdAt) : createdAt;
  const d = new Date(raw);
  if (isNaN(d.getTime())) return 'N/A';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

export default function AdminOrdersScreen() {
  const insets = useSafeAreaInsets();
  const [activeStatus, setActiveStatus] = useState('all');

  const { data, loading, refetch } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: activeStatus === 'all' ? null : activeStatus,
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawOrders = data?.getOrders;
  const orders = Array.isArray(rawOrders?.orders) ? rawOrders.orders : Array.isArray(rawOrders) ? rawOrders : [];

  return (
    <View style={[styles.container, { paddingTop: Math.max(insets.top, 16) }]}>
      <View style={styles.header}>
        <Text style={styles.title}>All Store Orders</Text>
        <TouchableOpacity style={styles.refreshBtn} onPress={() => refetch()}>
          <Ionicons name="refresh" size={20} color={COLORS.primary} />
        </TouchableOpacity>
      </View>

      {/* Filter Tabs */}
      <View style={styles.tabsWrapper}>
        <FlatList
          horizontal
          data={['all', 'pending', 'processing', 'out_for_delivery', 'delivered', 'cancelled']}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          renderItem={({ item }) => {
            const isSelected = activeStatus === item;
            return (
              <TouchableOpacity
                style={[styles.tab, isSelected && styles.activeTab]}
                onPress={() => setActiveStatus(item)}
              >
                <Text style={[styles.tabText, isSelected && styles.activeTabText]}>
                  {item.replace(/_/g, ' ').toUpperCase()}
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      {loading ? (
        <View style={styles.loaderBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : orders.length === 0 ? (
        <View style={styles.emptyBox}>
          <Ionicons name="bag-remove-outline" size={48} color={COLORS.textMuted} />
          <Text style={styles.emptyText}>No orders found in this status</Text>
        </View>
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <View style={styles.orderCard}>
              <View style={styles.cardHeader}>
                <View>
                  <Text style={styles.orderNum}>#{item.orderNumber}</Text>
                  <Text style={styles.dateText}>
                    {formatDate(item.createdAt)}
                  </Text>
                </View>
                <View
                  style={[
                    styles.badge,
                    {
                      backgroundColor:
                        item.status === 'delivered'
                          ? '#D1FAE5'
                          : item.status === 'cancelled'
                          ? '#FEE2E2'
                          : '#FEF3C7',
                    },
                  ]}
                >
                  <Text style={styles.badgeText}>{item.status.toUpperCase()}</Text>
                </View>
              </View>

              <View style={styles.divider} />

              <Text style={styles.customerText}>
                Customer: {item.customer?.name || item.shippingAddress?.fullName || 'Customer'}
              </Text>
              <Text style={styles.addressText}>
                📍 {item.shippingAddress?.addressLine1}, {item.shippingAddress?.city}
              </Text>

              <View style={styles.cardFooter}>
                <Text style={styles.totalAmount}>Total: ₹{(item.total || 0).toLocaleString('en-IN')}</Text>
                <Text style={styles.paymentMethod}>
                  {item.paymentMethod?.toUpperCase()} • {item.paymentStatus?.toUpperCase()}
                </Text>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.text,
  },
  refreshBtn: {
    padding: 6,
  },
  tabsWrapper: {
    marginBottom: 12,
  },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  activeTab: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  tabText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  orderCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  orderNum: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
  },
  dateText: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#92400E',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 10,
  },
  customerText: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.text,
  },
  addressText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
    marginBottom: 8,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  totalAmount: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.primary,
  },
  paymentMethod: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textMuted,
  },
  loaderBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  emptyText: {
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 8,
  },
});
