import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_DASHBOARD_STATS } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function AdminHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((s) => s.user);

  const { data, loading, refetch } = useQuery(GET_DASHBOARD_STATS, {
    fetchPolicy: 'cache-and-network',
  });

  const stats = data?.getDashboardStats || {};

  return (
    <View style={[styles.container, { paddingTop: Math.max(insets.top, 16) }]}>
      {/* Top Header */}
      <View style={styles.header}>
        <View>
          <View style={styles.roleBadge}>
            <Ionicons name="shield-checkmark" size={12} color="#4F46E5" />
            <Text style={styles.roleBadgeText}>
              {user?.role === 'superadmin' ? 'SUPER ADMIN CONSOLE' : 'ADMIN CONSOLE'}
            </Text>
          </View>
          <Text style={styles.welcomeText}>Store Overview,</Text>
          <Text style={styles.userNameText}>{user?.name || 'Administrator'}</Text>
        </View>

        <TouchableOpacity
          style={styles.notifBtn}
          onPress={() => navigation.navigate('ProfileTab')}
        >
          <Ionicons name="person-circle-outline" size={32} color={COLORS.text} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} />}
      >
        {/* Store Performance Metrics */}
        <Text style={styles.sectionTitle}>Store Performance</Text>
        <View style={styles.metricsGrid}>
          <View style={[styles.metricCard, { backgroundColor: '#EEF2FF' }]}>
            <View style={[styles.iconCircle, { backgroundColor: '#4F46E5' }]}>
              <Ionicons name="stats-chart-outline" size={20} color="#FFFFFF" />
            </View>
            <Text style={styles.metricLabel}>Total Revenue</Text>
            <Text style={styles.metricValue}>₹{(stats.totalRevenue || 0).toLocaleString('en-IN')}</Text>
          </View>

          <View style={[styles.metricCard, { backgroundColor: '#ECFDF5' }]}>
            <View style={[styles.iconCircle, { backgroundColor: '#10B981' }]}>
              <Ionicons name="cash-outline" size={20} color="#FFFFFF" />
            </View>
            <Text style={styles.metricLabel}>Today's Revenue</Text>
            <Text style={styles.metricValue}>₹{(stats.todayRevenue || 0).toLocaleString('en-IN')}</Text>
          </View>

          <View style={[styles.metricCard, { backgroundColor: '#FEF3C7' }]}>
            <View style={[styles.iconCircle, { backgroundColor: '#F59E0B' }]}>
              <Ionicons name="cart-outline" size={20} color="#FFFFFF" />
            </View>
            <Text style={styles.metricLabel}>Total Orders</Text>
            <Text style={styles.metricValue}>{stats.totalOrders || 0}</Text>
          </View>

          <View style={[styles.metricCard, { backgroundColor: '#F3E8FF' }]}>
            <View style={[styles.iconCircle, { backgroundColor: '#8B5CF6' }]}>
              <Ionicons name="people-outline" size={20} color="#FFFFFF" />
            </View>
            <Text style={styles.metricLabel}>Active Vendors</Text>
            <Text style={styles.metricValue}>{stats.totalVendors || 0}</Text>
          </View>
        </View>

        {/* System Management Actions */}
        <Text style={styles.sectionTitle}>Management Console</Text>
        <View style={styles.actionsRow}>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('AdminOrders')}
          >
            <View style={[styles.actionIconBox, { backgroundColor: '#4F46E5' }]}>
              <Ionicons name="receipt-outline" size={22} color="#FFFFFF" />
            </View>
            <Text style={styles.actionText}>All Store Orders</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('VendorProducts')}
          >
            <View style={[styles.actionIconBox, { backgroundColor: '#10B981' }]}>
              <Ionicons name="cube-outline" size={22} color="#FFFFFF" />
            </View>
            <Text style={styles.actionText}>Products & Stock</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('ProfileTab')}
          >
            <View style={[styles.actionIconBox, { backgroundColor: '#6B7280' }]}>
              <Ionicons name="options-outline" size={22} color="#FFFFFF" />
            </View>
            <Text style={styles.actionText}>System Settings</Text>
          </TouchableOpacity>
        </View>

        {/* Store Recent Orders */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Live Store Orders</Text>
          <TouchableOpacity onPress={() => navigation.navigate('AdminOrders')}>
            <Text style={styles.viewAllText}>View All ›</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator color={COLORS.primary} style={{ marginTop: 20 }} />
        ) : (stats.recentOrders || []).length === 0 ? (
          <View style={styles.emptyCard}>
            <Ionicons name="bag-check-outline" size={36} color={COLORS.textMuted} />
            <Text style={styles.emptyText}>No recent orders</Text>
          </View>
        ) : (
          (stats.recentOrders || []).slice(0, 5).map((order) => (
            <TouchableOpacity
              key={order._id}
              style={styles.orderCard}
              onPress={() => navigation.navigate('AdminOrders')}
            >
              <View style={styles.orderCardHeader}>
                <Text style={styles.orderNumber}>#{order.orderNumber}</Text>
                <View style={styles.statusBadge}>
                  <Text style={styles.statusBadgeText}>{order.status.toUpperCase()}</Text>
                </View>
              </View>
              <Text style={styles.customerName}>
                {order.customer?.name || order.shippingAddress?.fullName || 'Customer'} • ₹{(order.total || 0).toLocaleString('en-IN')}
              </Text>
            </TouchableOpacity>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EEF2FF',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    gap: 4,
    marginBottom: 4,
  },
  roleBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#3730A3',
  },
  welcomeText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  userNameText: {
    fontSize: 20,
    fontWeight: '800',
    color: COLORS.text,
  },
  notifBtn: {
    padding: 4,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 16,
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 16,
    marginBottom: 12,
  },
  viewAllText: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.primary,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  metricCard: {
    width: '48%',
    borderRadius: 16,
    padding: 14,
    ...SHADOWS.light,
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  metricLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.text,
    marginTop: 2,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  actionCard: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  actionIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.text,
  },
  orderCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  orderCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  orderNumber: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.text,
  },
  statusBadge: {
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#92400E',
  },
  customerName: {
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  emptyCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 14,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 8,
  },
});
