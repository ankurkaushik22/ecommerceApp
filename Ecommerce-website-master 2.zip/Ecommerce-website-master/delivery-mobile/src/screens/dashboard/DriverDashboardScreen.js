import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_DELIVERY_AGENT_ORDERS, GET_ME } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DriverDashboardScreen({ navigation }) {
  const user = useAuthStore((s) => s.user);

  const { data: meData } = useQuery(GET_ME, {
    pollInterval: 10000,
  });

  const me = meData?.me || user;
  const isMonthly = me?.deliveryPayoutType === 'monthly';
  const perOrderRate = me?.deliveryPerOrderRate ?? 65;
  const monthlySalary = me?.deliveryMonthlySalary ?? 18000;
  const dailyIncentive = me?.deliveryDailyIncentive ?? 150;

  const { data, loading, refetch } = useQuery(GET_DELIVERY_AGENT_ORDERS, {
    pollInterval: 10000,
  });

  const orders = data?.getDeliveryAgentOrders || [];

  // Filter orders strictly belonging to this driver
  const myOrders = orders.filter((o) =>
    o.deliveryAgent?._id === user?._id ||
    o.deliveryBoy?._id === user?._id ||
    o.deliveryAgent === user?._id ||
    o.deliveryBoy === user?._id ||
    (!o.deliveryAgent && !o.deliveryBoy)
  );

  // Active assigned orders
  const activeOrders = myOrders.filter((o) =>
    ['placed', 'accepted', 'processing', 'ready_for_pickup', 'picked_up', 'confirmed', 'preparing', 'dispatched', 'out_for_delivery'].includes(o.status)
  );

  // Delivered orders
  const deliveredOrders = myOrders.filter((o) => ['delivered', 'completed'].includes(o.status));

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const deliveredToday = deliveredOrders.filter((o) => {
    const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
    if (!dStr) return false;
    const d = new Date(dStr);
    return d.getDate() === now.getDate() && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).length;

  const deliveredThisMonth = deliveredOrders.filter((o) => {
    const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
    if (!dStr) return false;
    const d = new Date(dStr);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).length;

  const totalDeliveredOverall = deliveredOrders.length;

  const submittedCash = me?.submittedCash || 0;

  const codCollected = deliveredOrders
    .filter((o) => (o.paymentMethod || '').toLowerCase() === 'cod')
    .reduce((sum, o) => sum + (o.total || 0), 0);

  const amountToSubmit = Math.max(0, codCollected - submittedCash);

  const totalEarningsToday = isMonthly
    ? (monthlySalary / 30) + (deliveredToday > 0 ? dailyIncentive : 0)
    : (deliveredToday > 0 ? (deliveredToday * perOrderRate + dailyIncentive) : 0);

  return (
    <View style={styles.container}>
      <Header
        title="Dashboard"
        subtitle={`Partner ID: #${user?._id?.slice(-6) || '84920'}`}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} colors={[COLORS.primary]} />}
      >
        {/* Section Header */}
        <View style={styles.welcomeCard}>
          <View style={styles.welcomeTextGroup}>
            <Text style={styles.welcomeTitle}>Welcome back, {user?.name?.split(' ')[0] || 'Partner'}! 👋</Text>
            <Text style={styles.welcomeSub}>
              {isMonthly
                ? `Fixed Monthly Payout Plan (₹${monthlySalary.toLocaleString('en-IN')}/month)`
                : `Per Order Trip Plan (₹${perOrderRate}/trip)`}
            </Text>
          </View>
        </View>

        {/* The Metric Cards Grid */}
        <View style={styles.metricsGrid}>
          <TouchableOpacity
            style={styles.metricCard}
            activeOpacity={0.75}
            onPress={() => navigation.navigate('TasksTab')}
          >
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.primaryLight }]}>
              <Ionicons name="bicycle-outline" size={22} color={COLORS.primary} />
            </View>
            <Text style={styles.metricValue}>{activeOrders.length}</Text>
            <Text style={styles.metricLabel}>Assigned Now</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.metricCard}
            activeOpacity={0.75}
            onPress={() => navigation.navigate('HistoryTab')}
          >
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.successLight }]}>
              <Ionicons name="today-outline" size={22} color={COLORS.success} />
            </View>
            <Text style={styles.metricValue}>{deliveredToday}</Text>
            <Text style={styles.metricLabel}>Delivered Today</Text>
          </TouchableOpacity>

          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.secondaryLight }]}>
              <Ionicons name="cash-outline" size={22} color={COLORS.secondary} />
            </View>
            <Text style={styles.metricValue}>₹{codCollected.toFixed(0)}</Text>
            <Text style={styles.metricLabel}>COD Collected</Text>
          </View>

          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: '#FEF3C7' }]}>
              <Ionicons name="arrow-up-circle-outline" size={22} color="#D97706" />
            </View>
            <Text style={[styles.metricValue, { color: amountToSubmit > 0 ? '#D97706' : COLORS.text }]}>
              ₹{amountToSubmit.toFixed(0)}
            </Text>
            <Text style={styles.metricLabel}>Amount to Submit</Text>
          </View>
        </View>

        {/* Detailed Breakdown Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Earnings & Cash Reconciliations</Text>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="cash-outline" size={18} color={COLORS.secondary} />
              <Text style={styles.breakdownLabel}>Total COD Collected</Text>
            </View>
            <Text style={[styles.breakdownValue, { fontWeight: '800' }]}>₹{codCollected.toLocaleString('en-IN')}</Text>
          </View>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="checkmark-done-circle-outline" size={18} color="#2563EB" />
              <Text style={styles.breakdownLabel}>Cash Deposited / Submitted</Text>
            </View>
            <Text style={[styles.breakdownValue, { color: '#2563EB', fontWeight: '800' }]}>₹{submittedCash.toLocaleString('en-IN')}</Text>
          </View>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="arrow-up-circle-outline" size={18} color="#D97706" />
              <Text style={styles.breakdownLabel}>Amount to Submit (Pending)</Text>
            </View>
            <Text style={[styles.breakdownValue, { color: amountToSubmit > 0 ? '#D97706' : '#10B981', fontWeight: '800' }]}>
              ₹{amountToSubmit.toLocaleString('en-IN')}
            </Text>
          </View>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="wallet-outline" size={18} color={COLORS.secondary} />
              <Text style={styles.breakdownLabel}>Assigned Payout Model</Text>
            </View>
            <Text style={[styles.breakdownValue, { color: isMonthly ? '#9333EA' : COLORS.primary, fontWeight: '800' }]}>
              {isMonthly ? 'Fixed Monthly' : 'Trip-Based (Per Order)'}
            </Text>
          </View>

          {isMonthly ? (
            <View style={styles.breakdownRow}>
              <View style={styles.breakdownLeft}>
                <Ionicons name="calendar" size={18} color={COLORS.primary} />
                <Text style={styles.breakdownLabel}>Base Monthly Salary</Text>
              </View>
              <Text style={styles.breakdownValue}>₹{monthlySalary.toLocaleString('en-IN')}/month</Text>
            </View>
          ) : (
            <View style={styles.breakdownRow}>
              <View style={styles.breakdownLeft}>
                <Ionicons name="bicycle" size={18} color={COLORS.success} />
                <Text style={styles.breakdownLabel}>Trip Rate (₹{perOrderRate}/trip)</Text>
              </View>
              <Text style={styles.breakdownValue}>₹{deliveredToday * perOrderRate}</Text>
            </View>
          )}

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="gift-outline" size={18} color={COLORS.accent} />
              <Text style={styles.breakdownLabel}>Daily Shift Incentive</Text>
            </View>
            <Text style={styles.breakdownValue}>
              {deliveredToday > 0 ? `₹${dailyIncentive} (Active)` : `₹${dailyIncentive} (Pending Duty)`}
            </Text>
          </View>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons
                name={
                  meData?.me?.vehicleType === '4_wheeler'
                    ? 'car-outline'
                    : meData?.me?.vehicleType === 'bicycle'
                    ? 'bicycle-outline'
                    : 'bicycle-outline'
                }
                size={18}
                color={COLORS.primary}
              />
              <Text style={styles.breakdownLabel}>Assigned Vehicles</Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              {(meData?.me?.vehicles && meData.me.vehicles.length > 0
                ? meData.me.vehicles
                : [
                    {
                      vehicleType: meData?.me?.vehicleType || '2_wheeler',
                      registrationNumber: meData?.me?.vehicleRegistrationNumber || '',
                      isPrimary: true,
                    },
                  ]
              ).map((v, i) => {
                const label =
                  v.vehicleType === '4_wheeler'
                    ? '4-Wheeler'
                    : v.vehicleType === 'bicycle'
                    ? 'Bicycle'
                    : v.vehicleType === 'other'
                    ? 'Other'
                    : '2-Wheeler';
                return (
                  <Text key={i} style={[styles.breakdownValue, { fontWeight: '800', textAlign: 'right' }]}>
                    {label} {v.registrationNumber ? `(${v.registrationNumber})` : ''}
                    {v.isPrimary ? ' ⭐' : ''}
                  </Text>
                );
              })}
            </View>
          </View>

          <View style={styles.breakdownRow}>
            <View style={styles.breakdownLeft}>
              <Ionicons name="checkmark-circle-outline" size={18} color="#9333EA" />
              <Text style={styles.breakdownLabel}>Monthly Completion Rate</Text>
            </View>
            <Text style={[styles.breakdownValue, { color: '#9333EA', fontWeight: '800' }]}>100%</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  welcomeCard: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  welcomeTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  welcomeSub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  metricCard: {
    width: '48%',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  metricIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: '900',
    color: COLORS.text,
  },
  metricLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 4,
    fontWeight: '700',
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 14,
  },
  breakdownRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    gap: 8,
  },
  breakdownLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    flexShrink: 1,
  },
  breakdownLabel: {
    fontSize: 12.5,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  breakdownValue: {
    fontSize: 12.5,
    fontWeight: '700',
    color: COLORS.text,
    textAlign: 'right',
  },
});
