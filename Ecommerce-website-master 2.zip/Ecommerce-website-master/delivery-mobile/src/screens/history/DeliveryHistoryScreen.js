import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_DELIVERY_AGENT_ORDERS } from '../../graphql/queries';
import Header from '../../components/common/Header';
import DeliveryCard from '../../components/common/DeliveryCard';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DeliveryHistoryScreen({ navigation }) {
  const [activeTab, setActiveTab] = useState('today');

  const { data, loading, refetch } = useQuery(GET_DELIVERY_AGENT_ORDERS, {
    variables: { status: 'delivered' },
  });

  const orders = data?.getDeliveryAgentOrders || [];

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  const deliveredToday = orders.filter((o) => {
    const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
    if (!dStr) return false;
    const d = new Date(dStr);
    return d.getDate() === now.getDate() && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).length;

  const deliveredThisMonth = orders.filter((o) => {
    const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
    if (!dStr) return false;
    const d = new Date(dStr);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  }).length;

  const totalDeliveredOverall = orders.length;

  const filteredOrders = orders.filter((o) => {
    if (activeTab === 'today') {
      const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
      if (!dStr) return false;
      const d = new Date(dStr);
      return d.getDate() === now.getDate() && d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    }
    if (activeTab === 'month') {
      const dStr = o.deliveredAt || o.updatedAt || o.createdAt;
      if (!dStr) return false;
      const d = new Date(dStr);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    }
    return true; // 'overall'
  });

  return (
    <View style={styles.container}>
      <Header title="Delivery History" subtitle="Completed & reconciled deliveries" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} colors={[COLORS.primary]} />}
      >
        {/* Clickable Performance Header Summary */}
        <View style={styles.summaryCard}>
          <TouchableOpacity
            style={[styles.summaryItem, activeTab === 'today' && styles.activeTabToday]}
            onPress={() => setActiveTab('today')}
            activeOpacity={0.8}
          >
            <Text style={[styles.summaryValue, { color: '#10B981' }]}>{deliveredToday}</Text>
            <Text style={[styles.summaryLabel, activeTab === 'today' && styles.activeTabLabelToday]}>
              Today {activeTab === 'today' ? '✓' : ''}
            </Text>
          </TouchableOpacity>

          <View style={styles.summaryDivider} />

          <TouchableOpacity
            style={[styles.summaryItem, activeTab === 'month' && styles.activeTabMonth]}
            onPress={() => setActiveTab('month')}
            activeOpacity={0.8}
          >
            <Text style={[styles.summaryValue, { color: '#9333EA' }]}>{deliveredThisMonth}</Text>
            <Text style={[styles.summaryLabel, activeTab === 'month' && styles.activeTabLabelMonth]}>
              This Month {activeTab === 'month' ? '✓' : ''}
            </Text>
          </TouchableOpacity>

          <View style={styles.summaryDivider} />

          <TouchableOpacity
            style={[styles.summaryItem, activeTab === 'overall' && styles.activeTabOverall]}
            onPress={() => setActiveTab('overall')}
            activeOpacity={0.8}
          >
            <Text style={[styles.summaryValue, { color: '#D97706' }]}>{totalDeliveredOverall}</Text>
            <Text style={[styles.summaryLabel, activeTab === 'overall' && styles.activeTabLabelOverall]}>
              Overall Total {activeTab === 'overall' ? '✓' : ''}
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>
          {activeTab === 'today'
            ? "Today's Completed Orders"
            : activeTab === 'month'
            ? "This Month's Completed Orders"
            : 'All Completed Orders'}
        </Text>

        {filteredOrders.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="checkmark-done-circle-outline" size={54} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Deliveries Found</Text>
            <Text style={styles.emptySub}>
              {activeTab === 'today'
                ? "No completed orders recorded today."
                : activeTab === 'month'
                ? "No completed orders recorded this month."
                : "Once you complete delivery tasks, your full trip history will appear here."}
            </Text>
          </View>
        ) : (
          filteredOrders.map((order) => (
            <DeliveryCard
              key={order._id}
              order={order}
              onPress={() => navigation.navigate('DeliveryDetail', { orderId: order._id })}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  summaryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 6,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 6,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  summaryDivider: {
    width: 1,
    height: 28,
    backgroundColor: COLORS.borderLight,
  },
  activeTabToday: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  activeTabMonth: {
    backgroundColor: '#F3E8FF',
    borderColor: '#9333EA',
  },
  activeTabOverall: {
    backgroundColor: '#FEF3C7',
    borderColor: '#D97706',
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '900',
    color: COLORS.primary,
  },
  summaryLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 4,
    fontWeight: '600',
  },
  activeTabLabelToday: {
    color: '#047857',
    fontWeight: '900',
  },
  activeTabLabelMonth: {
    color: '#7E22CE',
    fontWeight: '900',
  },
  activeTabLabelOverall: {
    color: '#B45309',
    fontWeight: '900',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginTop: 10,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 12,
  },
  emptySub: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 18,
  },
});
