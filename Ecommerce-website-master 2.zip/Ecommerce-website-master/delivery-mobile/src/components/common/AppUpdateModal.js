import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_STORE_SETTINGS } from '../../graphql/queries';
import appConfig from '../../../app.json';

function isVersionHigher(latest, current) {
  if (!latest || !current) return false;
  const lParts = latest.split('.').map((n) => parseInt(n, 10) || 0);
  const cParts = current.split('.').map((n) => parseInt(n, 10) || 0);
  const maxLen = Math.max(lParts.length, cParts.length);
  for (let i = 0; i < maxLen; i++) {
    const l = lParts[i] || 0;
    const c = cParts[i] || 0;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}

export default function AppUpdateModal() {
  const [dismissed, setDismissed] = useState(false);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
    pollInterval: 30000,
  });

  const storeSettings = settingsData?.getStoreSettings;
  const currentVersion = appConfig?.expo?.version || '1.0.0';
  const latestVersion = storeSettings?.latestDeliveryVersion;
  const apkDownloadUrl = storeSettings?.deliveryApkUrl;
  const isForceUpdate = Boolean(storeSettings?.forceAppUpdate);

  const hasNewUpdate =
    Boolean(latestVersion) &&
    Boolean(apkDownloadUrl) &&
    isVersionHigher(latestVersion, currentVersion);

  if (!hasNewUpdate || dismissed) {
    return null;
  }

  const handleUpdateNow = () => {
    if (!apkDownloadUrl) return;
    Linking.openURL(apkDownloadUrl).catch((err) =>
      console.error('Error opening update URL:', err)
    );
  };

  return (
    <Modal
      visible={true}
      transparent={true}
      animationType="fade"
      onRequestClose={() => {
        if (!isForceUpdate) setDismissed(true);
      }}
    >
      <View style={styles.overlay}>
        <View style={styles.card}>
          <View style={styles.iconContainer}>
            <Ionicons name="bicycle-outline" size={40} color="#059669" />
          </View>

          <Text style={styles.title}>Delivery App Update Available!</Text>
          <Text style={styles.subtitle}>
            A new version <Text style={styles.boldVersion}>v{latestVersion}</Text> of Suaaka Delivery is available. Update now for new delivery features and stability fixes.
          </Text>

          <TouchableOpacity
            style={styles.updateBtn}
            onPress={handleUpdateNow}
            activeOpacity={0.8}
          >
            <Text style={styles.updateBtnText}>Download Update</Text>
            <Ionicons name="cloud-download-outline" size={20} color="#FFFFFF" />
          </TouchableOpacity>

          {!isForceUpdate && (
            <TouchableOpacity
              style={styles.laterBtn}
              onPress={() => setDismissed(true)}
            >
              <Text style={styles.laterBtnText}>Remind Me Later</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
  },
  iconContainer: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '800',
    color: '#0F172A',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  boldVersion: {
    fontWeight: '700',
    color: '#059669',
  },
  updateBtn: {
    width: '100%',
    height: 48,
    backgroundColor: '#059669',
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  updateBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  progressContainer: {
    width: '100%',
    alignItems: 'center',
    gap: 8,
  },
  progressBarTrack: {
    width: '100%',
    height: 10,
    borderRadius: 5,
    backgroundColor: '#E2E8F0',
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#059669',
    borderRadius: 5,
  },
  progressText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748B',
  },
  errorText: {
    fontSize: 11,
    color: '#EF4444',
    textAlign: 'center',
    marginTop: 8,
  },
  laterBtn: {
    marginTop: 12,
    paddingVertical: 6,
  },
  laterBtnText: {
    fontSize: 12,
    color: '#94A3B8',
    fontWeight: '600',
  },
});
