const dns = require('dns');
dns.setServers(['8.8.8.8', '1.1.1.1']);
const mongoose = require('mongoose');
require('dotenv').config();

async function run() {
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('Connected to MongoDB');

  const defaultsBySlug = {
    'complete-home-deep-cleaning-and-sanitization-service': {
      serviceDuration: '4 hours',
      warranty: '100% Quality & Re-clean Guarantee',
      includedFeatures: [
        'Full kitchen degreasing & countertop wipe',
        'Bathroom tiles descaling & sanitization',
        'Floor scrubbing with single-disc machine',
        'Balcony, window grills & glass wiping',
      ],
    },
    'ac-master-jet-servicing-and-cooling-tune-up': {
      serviceDuration: '45 mins',
      warranty: '30 Days Cooling Guarantee',
      includedFeatures: [
        'High-pressure power jet indoor coil wash',
        'Outdoor condenser unit dust & debris wash',
        'Gas leak & operating temperature check',
        'Drain pipe flushing & blower cleaning',
      ],
    },
    'expert-electrician-home-visit-and-inspection-1-hour': {
      serviceDuration: '60 mins',
      warranty: '30 Days Post-Service Warranty',
      includedFeatures: [
        'Doorstep electrical circuit fault diagnosis',
        'Inspection and repair of up to 2 switchboards',
        'Earthing, MCB & voltage load check',
        'Assistance in procurement of ISI genuine parts',
      ],
    },
    'plumbing-repair-and-pipe-leakage-fix-service': {
      serviceDuration: '45 mins',
      warranty: '30 Days Leak-Free Guarantee',
      includedFeatures: [
        'Tap, mixer & angle valve repair or replacement',
        'Under-sink drainage & trap pipe leak fix',
        'Water pressure & blockage inspection',
        'Installation of branded fittings',
      ],
    },
    'ios-app-development': {
      serviceDuration: '2-4 weeks',
      warranty: '30 Days Post-Launch Support',
      includedFeatures: [
        'Native Swift / SwiftUI iOS application design',
        'App Store guidelines & submission review',
        'Secure API integration & local caching',
        'Comprehensive QA testing across iOS devices',
      ],
    },
  };

  const services = await mongoose.connection.db.collection('products').find({ vertical: 'services' }).toArray();
  for (const s of services) {
    const update = {
      $set: {
        stock: 999,
        specifications: [],
      },
    };

    if (!s.serviceDuration || !s.includedFeatures || !s.warranty) {
      const match = defaultsBySlug[s.slug];
      if (match) {
        if (!s.serviceDuration) update.$set.serviceDuration = match.serviceDuration;
        if (!s.warranty) update.$set.warranty = match.warranty;
        if (!s.includedFeatures || s.includedFeatures.length === 0) update.$set.includedFeatures = match.includedFeatures;
      } else {
        if (!s.serviceDuration) update.$set.serviceDuration = '45 mins';
        if (!s.warranty) update.$set.warranty = '30 Days Verified Service Warranty';
        if (!s.includedFeatures || s.includedFeatures.length === 0) {
          update.$set.includedFeatures = [
            'Certified & background-verified technician visit',
            'Full doorstep inspection & diagnostic check',
            'Genuine brand parts procurement support',
            'Post-service quality testing & demonstration',
          ];
        }
      }
    }

    await mongoose.connection.db.collection('products').updateOne({ _id: s._id }, update);
    console.log(`Updated: ${s.name} (${s.slug})`);
  }

  console.log('All 10 services successfully synced in MongoDB!');
  process.exit(0);
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
