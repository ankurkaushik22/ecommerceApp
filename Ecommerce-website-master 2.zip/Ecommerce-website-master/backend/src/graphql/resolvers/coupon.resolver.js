import { GraphQLError } from 'graphql';
import Coupon from '../../models/Coupon.js';
import { requireAdmin } from '../../middleware/auth.middleware.js';

const couponResolvers = {
  Query: {
    getAllCoupons: async (_, __, { user }) => {
      requireAdmin(user);
      return Coupon.find().sort({ createdAt: -1 });
    },
  },

  Mutation: {
    createCoupon: async (_, { input }, { user }) => {
      requireAdmin(user);
      const couponData = { ...input, code: input.code.toUpperCase() };
      if (couponData.maxDiscountAmount === undefined && couponData.maxDiscount !== undefined) {
        couponData.maxDiscountAmount = couponData.maxDiscount;
      }
      if (couponData.startsAt === undefined && couponData.validFrom !== undefined) {
        couponData.startsAt = couponData.validFrom;
      }
      if (couponData.expiresAt === undefined && couponData.validUntil !== undefined) {
        couponData.expiresAt = couponData.validUntil;
      }
      return Coupon.create(couponData);
    },

    updateCoupon: async (_, { id, input }, { user }) => {
      requireAdmin(user);
      const couponData = { ...input, code: input.code.toUpperCase() };
      if (couponData.maxDiscountAmount === undefined && couponData.maxDiscount !== undefined) {
        couponData.maxDiscountAmount = couponData.maxDiscount;
      }
      if (couponData.startsAt === undefined && couponData.validFrom !== undefined) {
        couponData.startsAt = couponData.validFrom;
      }
      if (couponData.expiresAt === undefined && couponData.validUntil !== undefined) {
        couponData.expiresAt = couponData.validUntil;
      }
      return Coupon.findByIdAndUpdate(id, couponData, { new: true });
    },

    deleteCoupon: async (_, { id }, { user }) => {
      requireAdmin(user);
      await Coupon.findByIdAndDelete(id);
      return true;
    },

    validateCoupon: async (_, { code, orderAmount }, { user }) => {
      const coupon = await Coupon.findOne({ code: code.toUpperCase() });
      if (!coupon) {
        return { valid: false, message: 'Coupon not found', discount: 0 };
      }

      const validation = coupon.isValid(orderAmount);
      if (!validation.valid) {
        return { valid: false, message: validation.message, discount: 0 };
      }

      const discount = coupon.calculateDiscount(orderAmount);
      return { valid: true, discount, coupon, message: `${coupon.value}${coupon.type === 'percentage' ? '%' : '₹'} off applied!` };
    },
  },
};

export default couponResolvers;
