import { StoreSetting } from '../../models/StoreSetting.js';
import { requireAdmin, requireSuperAdmin } from '../../middleware/auth.middleware.js';

const storeSettingResolvers = {
  Query: {
    getStoreSettings: async () => {
      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = await StoreSetting.create({
          storeName: 'My Store',
          logoUrl: '',
          faviconUrl: '',
          appIconUrl: '',
          paymentMode: 'both',
        });
      }
      return settings;
    },
  },
  Mutation: {
    updateStoreSettings: async (
      _,
      {
        storeName,
        logoUrl,
        faviconUrl,
        appIconUrl,
        disabledVerticals,
        serviceBookingMode,
        serviceContactPhone,
        paymentMode,
        latestCustomerVersion,
        customerApkUrl,
        latestDeliveryVersion,
        deliveryApkUrl,
        forceAppUpdate,
        websiteDisplayMode,
        customerPlayStoreUrl,
        customerIosUrl,
      },
      context
    ) => {
      requireAdmin(context.user);

      if (
        latestCustomerVersion !== undefined ||
        customerApkUrl !== undefined ||
        latestDeliveryVersion !== undefined ||
        deliveryApkUrl !== undefined ||
        forceAppUpdate !== undefined ||
        websiteDisplayMode !== undefined ||
        customerPlayStoreUrl !== undefined ||
        customerIosUrl !== undefined
      ) {
        requireSuperAdmin(context.user);
      }

      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = new StoreSetting();
      }

      if (storeName !== undefined) settings.storeName = storeName;
      if (logoUrl !== undefined) settings.logoUrl = logoUrl;
      if (faviconUrl !== undefined) settings.faviconUrl = faviconUrl;
      if (appIconUrl !== undefined) settings.appIconUrl = appIconUrl;
      if (disabledVerticals !== undefined) settings.disabledVerticals = disabledVerticals;
      if (serviceBookingMode !== undefined) settings.serviceBookingMode = serviceBookingMode;
      if (serviceContactPhone !== undefined) settings.serviceContactPhone = serviceContactPhone;
      if (paymentMode !== undefined) settings.paymentMode = paymentMode;
      if (latestCustomerVersion !== undefined) settings.latestCustomerVersion = latestCustomerVersion;
      if (customerApkUrl !== undefined) settings.customerApkUrl = customerApkUrl;
      if (latestDeliveryVersion !== undefined) settings.latestDeliveryVersion = latestDeliveryVersion;
      if (deliveryApkUrl !== undefined) settings.deliveryApkUrl = deliveryApkUrl;
      if (forceAppUpdate !== undefined) settings.forceAppUpdate = forceAppUpdate;
      if (websiteDisplayMode !== undefined) settings.websiteDisplayMode = websiteDisplayMode;
      if (customerPlayStoreUrl !== undefined) settings.customerPlayStoreUrl = customerPlayStoreUrl;
      if (customerIosUrl !== undefined) settings.customerIosUrl = customerIosUrl;

      await settings.save();
      return settings;
    },
  },
};

export default storeSettingResolvers;
