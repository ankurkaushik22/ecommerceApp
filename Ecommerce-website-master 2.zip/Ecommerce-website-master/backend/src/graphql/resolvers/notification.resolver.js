import { GraphQLError } from 'graphql';
import { PubSub } from 'graphql-subscriptions';
import Notification from '../../models/Notification.js';
import User from '../../models/User.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

export const pubsub = new PubSub();
const NOTIFICATION_RECEIVED = 'NOTIFICATION_RECEIVED';

const notificationResolvers = {
  Query: {
    getNotifications: async (_, __, { user }) => {
      requireAuth(user);
      return Notification.find({ user: user._id }).sort({ createdAt: -1 }).limit(50);
    },

    getUnreadNotificationCount: async (_, __, { user }) => {
      if (!user) return 0;
      return Notification.countDocuments({ user: user._id, isRead: false });
    },
  },

  Mutation: {
    markNotificationRead: async (_, { id }, { user }) => {
      requireAuth(user);
      const notification = await Notification.findOneAndUpdate(
        { _id: id, user: user._id },
        { isRead: true },
        { new: true }
      );
      if (!notification) {
        throw new GraphQLError('Notification not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return notification;
    },

    markAllNotificationsRead: async (_, __, { user }) => {
      requireAuth(user);
      await Notification.updateMany({ user: user._id, isRead: false }, { isRead: true });
      return true;
    },

    updatePushToken: async (_, { token }, { user }) => {
      requireAuth(user);
      await User.findByIdAndUpdate(user._id, { pushToken: token });
      return true;
    },
  },

  Subscription: {
    notificationReceived: {
      subscribe: (_, { userId }) => {
        return pubsub.asyncIterator(`${NOTIFICATION_RECEIVED}_${userId}`);
      },
    },
  },
};

const formatReadableText = (text) => {
  if (!text || typeof text !== 'string') return text || '';
  let cleaned = text.replace(/_/g, ' ');
  return cleaned.replace(/\b[A-Z]{2,}\b/g, (match) =>
    match.charAt(0) + match.slice(1).toLowerCase()
  );
};

// Helper to publish notification (used by other resolvers)
export const publishNotification = async (userId, notificationData) => {
  const sanitizedTitle = formatReadableText(notificationData.title || 'New Notification');
  const sanitizedMessage = formatReadableText(notificationData.message || notificationData.content || '');

  const notification = await Notification.create({
    user: userId,
    ...notificationData,
    title: sanitizedTitle,
    message: sanitizedMessage,
  });

  pubsub.publish(`${NOTIFICATION_RECEIVED}_${userId}`, {
    notificationReceived: notification,
  });

  // Also send Push Notification if user has registered a push token
  try {
    const userDoc = await User.findById(userId).select('pushToken fcmToken');
    const token = userDoc?.pushToken || userDoc?.fcmToken;
    if (token) {
      await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Accept-encoding': 'gzip, deflate',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: token,
          sound: 'default',
          title: sanitizedTitle,
          body: sanitizedMessage,
          data: {
            type: notificationData.type,
            targetId: notificationData.targetId,
            link: notificationData.link,
          },
          priority: 'high',
          channelId: 'default',
          badge: 1,
          _displayInForeground: true,
        }),
      });
    }
  } catch (err) {
    console.error('Error sending push notification via Expo:', err);
  }

  return notification;
};

export default notificationResolvers;
