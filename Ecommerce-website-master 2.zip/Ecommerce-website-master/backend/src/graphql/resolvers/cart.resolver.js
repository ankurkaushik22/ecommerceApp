import { GraphQLError } from 'graphql';
import Cart from '../../models/Cart.js';
import Product from '../../models/Product.js';
import Coupon from '../../models/Coupon.js';
import { requireAuth } from '../../middleware/auth.middleware.js';
import { resolveVariantInfo } from './order.resolver.js';

const populateCart = (cart) =>
  cart.populate({
    path: 'items.product',
    populate: [{ path: 'category' }, { path: 'subcategory' }, { path: 'taxSetting' }],
  });

const formatCart = (cart) => {
  const getItemPrice = (item) => (typeof item.price === 'number' && item.price > 0) ? item.price : Number(item.product?.price || 0);
  const subtotal = cart.items.reduce((sum, item) => sum + getItemPrice(item) * (item.quantity || 1), 0);
  const discount = cart.couponDiscount || cart.discount || 0;
  const tax = Math.round(subtotal * 0.18);
  const shippingCost = subtotal > 500 || subtotal === 0 ? 0 : 49;
  const total = Math.max(0, subtotal - discount + tax + shippingCost);

  return {
    _id: cart._id,
    user: cart.user,
    items: cart.items.map((item) => {
      const price = getItemPrice(item);
      const { variantLabel, image, stock: varStock } = resolveVariantInfo(item.product, item.variantIndex);
      const availableStock = item.product?.vertical === 'services'
        ? 999
        : (item.variantIndex >= 0 ? (varStock ?? 0) : (item.product?.stock ?? 0));
      return {
        _id: item._id,
        product: item.product,
        variantIndex: item.variantIndex,
        variantLabel: variantLabel || null,
        image: image || item.product?.images?.[0] || '',
        quantity: item.quantity,
        price,
        total: price * (item.quantity || 1),
        availableStock,
        addons: item.addons || [],
        instructions: item.instructions || '',
      };
    }),
    subtotal,
    itemCount: cart.items.reduce((sum, item) => sum + (item.quantity || 1), 0),
    couponCode: cart.couponCode,
    couponDiscount: discount,
    discount,
    shippingCost,
    tax,
    total,
    updatedAt: cart.updatedAt,
  };
};

const cartResolvers = {
  Query: {
    getCart: async (_, __, { user }) => {
      requireAuth(user);
      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }
      await populateCart(cart);
      return formatCart(cart);
    },
  },

  Mutation: {
    addToCart: async (_, { input }, { user }) => {
      requireAuth(user);
      const { productId, variantIndex = -1, quantity: rawQuantity, addons = [], instructions = '', customPrice } = input;
      const quantity = Math.max(1, Math.min(50, Math.floor(Number(rawQuantity) || 1)));

      const product = await Product.findById(productId);
      if (!product || !product.isActive || product.approvalStatus === 'pending' || product.approvalStatus === 'rejected') {
        throw new GraphQLError('Product not found, inactive, or pending approval', { extensions: { code: 'NOT_FOUND' } });
      }

      const { price: variantPrice, stock: varStock } = resolveVariantInfo(product, variantIndex);

      const basePrice = (variantIndex >= 0 && variantPrice > 0) ? variantPrice : product.price;
      const addonSum = Array.isArray(addons) ? addons.reduce((sum, a) => sum + (Number(a.price) || 0), 0) : 0;
      const price = typeof customPrice === 'number' && customPrice > 0 ? customPrice : (basePrice + addonSum);

      // Check stock
      const availableStock = variantIndex >= 0 ? varStock : product.stock;

      if (availableStock < quantity) {
        throw new GraphQLError(`Only ${availableStock} items available in stock`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }

      const addonsKeyStr = (arr) => (arr || []).map((a) => a.name).sort().join('|');
      const targetAddonsKey = addonsKeyStr(addons);
      const targetInstructions = (instructions || '').trim();

      // Check if exact same customized item already in cart
      const existingItemIndex = cart.items.findIndex(
        (item) =>
          item.product.toString() === productId &&
          item.variantIndex === variantIndex &&
          addonsKeyStr(item.addons) === targetAddonsKey &&
          (item.instructions || '').trim() === targetInstructions
      );

      if (existingItemIndex > -1) {
        const newQty = Math.min(50, cart.items[existingItemIndex].quantity + quantity);
        if (newQty > availableStock) {
          throw new GraphQLError(`Cannot add more. Only ${availableStock} items available.`, {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        cart.items[existingItemIndex].quantity = newQty;
        cart.items[existingItemIndex].price = price;
      } else {
        cart.items.push({
          product: productId,
          variantIndex,
          quantity,
          price,
          addons: addons || [],
          instructions: targetInstructions,
        });
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    syncCart: async (_, { items = [] }, { user }) => {
      requireAuth(user);
      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }

      for (const item of items) {
        const { productId, variantIndex = -1, quantity: rawQuantity = 1 } = item;
        const quantity = Math.max(1, Math.min(50, Math.floor(Number(rawQuantity) || 1)));
        const product = await Product.findById(productId);
        if (!product || !product.isActive) continue;

        const { price: variantPrice, stock: varStock } = resolveVariantInfo(product, variantIndex);
        const price = (variantIndex >= 0 && variantPrice > 0) ? variantPrice : product.price;
        const availableStock = variantIndex >= 0 ? varStock : product.stock;
        const clampedQty = Math.max(1, Math.min(quantity, Math.max(1, availableStock)));

        const existingItemIndex = cart.items.findIndex(
          (ci) => ci.product.toString() === productId && ci.variantIndex === variantIndex
        );

        if (existingItemIndex > -1) {
          cart.items[existingItemIndex].quantity = Math.min(
            availableStock || 50,
            Math.max(cart.items[existingItemIndex].quantity, clampedQty)
          );
        } else {
          cart.items.push({ product: productId, variantIndex, quantity: clampedQty, price });
        }
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    updateCartItem: async (_, { itemId, quantity: rawQuantity }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const item = cart.items.id(itemId);
      if (!item) throw new GraphQLError('Cart item not found', { extensions: { code: 'NOT_FOUND' } });

      const targetQty = Number(rawQuantity);
      if (isNaN(targetQty) || targetQty <= 0) {
        cart.items = cart.items.filter((i) => i._id.toString() !== itemId);
      } else {
        const quantity = Math.min(50, Math.floor(targetQty));
        // Check stock
        const product = await Product.findById(item.product);
        if (product) {
          const { stock: varStock, variantLabel } = resolveVariantInfo(product, item.variantIndex);
          const availableStock = item.variantIndex >= 0 ? varStock : product.stock;
          if (quantity > availableStock) {
            throw new GraphQLError(`Only ${availableStock} item${availableStock === 1 ? '' : 's'} available in stock${variantLabel ? ` (${variantLabel})` : ''}`, {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
        }
        item.quantity = quantity;
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeFromCart: async (_, { itemId }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      cart.items = cart.items.filter((item) => item._id.toString() !== itemId);
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    clearCart: async (_, __, { user }) => {
      requireAuth(user);
      await Cart.findOneAndUpdate({ user: user._id }, { items: [], couponCode: null, couponDiscount: 0 });
      return true;
    },

    applyCoupon: async (_, { code }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const coupon = await Coupon.findOne({ code: code.toUpperCase() });
      if (!coupon) {
        throw new GraphQLError('Invalid coupon code', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const subtotal = cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const validation = coupon.isValid(subtotal);

      if (!validation.valid) {
        throw new GraphQLError(validation.message, { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const discount = coupon.calculateDiscount(subtotal);
      cart.couponCode = coupon.code;
      cart.couponDiscount = discount;
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeCoupon: async (_, __, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOneAndUpdate(
        { user: user._id },
        { couponCode: null, couponDiscount: 0 },
        { new: true }
      );
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });
      await populateCart(cart);
      return formatCart(cart);
    },
  },
};

export default cartResolvers;
