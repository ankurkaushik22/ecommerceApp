import mongoose from 'mongoose';
import { GraphQLError } from 'graphql';
import Order from '../../models/Order.js';
import Product from '../../models/Product.js';
import User from '../../models/User.js';
import Category from '../../models/Category.js';
import TaxSetting from '../../models/TaxSetting.js';
import DeliveryOption from '../../models/DeliveryOption.js';
import RolePermission from '../../models/RolePermission.js';
import { requireAdmin, requireAuth, requireAdminOrVendor, requireSuperAdmin } from '../../middleware/auth.middleware.js';
import { subDays, format, startOfDay, endOfDay } from 'date-fns';

const getDayLabel = (daysAgo) => {
  const date = subDays(new Date(), daysAgo);
  return format(date, 'MMM d');
};

const adminResolvers = {
  Query: {
    getDashboardStats: async (_, { vertical }, { user }) => {
      requireAdminOrVendor(user);

      const now = new Date();
      const todayStart = startOfDay(now);
      const todayEnd = endOfDay(now);

      // If user is vendor, filter stats exclusively for their items and store
      const isVendor = user.role === 'vendor';
      const vendorObjId = isVendor ? new mongoose.Types.ObjectId(user._id.toString()) : null;
      const vendorFilter = isVendor
        ? { $or: [{ vendor: vendorObjId }, { 'items.vendor': vendorObjId }] }
        : {};
      const productVendorFilter = isVendor ? { vendor: vendorObjId } : {};

      const orderVerticalFilter = vertical && vertical !== 'all' ? { vertical } : {};

      let productVerticalFilter = {};
      if (vertical && vertical !== 'all') {
        const categoryIds = await Category.find({ vertical }).distinct('_id');
        productVerticalFilter = { category: { $in: categoryIds } };
      }

      const orderMatch = { ...vendorFilter, ...orderVerticalFilter };
      const productMatch = { ...productVendorFilter, ...productVerticalFilter };

      const [
        totalRevenueResult,
        todayRevenueResult,
        totalOrders,
        todayOrders,
        totalProducts,
        totalUsers,
        totalVendors,
        pendingOrders,
        pendingVendorCount,
        pendingProductCount,
        recentOrders,
        topProducts,
      ] = await Promise.all([
        Order.aggregate([
          { $match: { status: { $nin: ['cancelled', 'refunded'] }, ...orderMatch } },
          { $group: { _id: null, total: { $sum: '$total' } } },
        ]),
        Order.aggregate([
          {
            $match: {
              status: { $nin: ['cancelled', 'refunded'] },
              createdAt: { $gte: todayStart, $lte: todayEnd },
              ...orderMatch,
            },
          },
          { $group: { _id: null, total: { $sum: '$total' } } },
        ]),
        Order.countDocuments(orderMatch),
        Order.countDocuments({ createdAt: { $gte: todayStart }, ...orderMatch }),
        Product.countDocuments(productMatch),
        isVendor ? 0 : User.countDocuments({ role: 'customer' }),
        isVendor ? 1 : User.countDocuments({ role: 'vendor' }),
        Order.countDocuments({ status: { $in: ['placed', 'accepted', 'processing', 'pending', 'ready_for_pickup'] }, ...orderMatch }),
        isVendor ? 0 : User.countDocuments({ role: 'vendor', isActive: { $ne: false }, $or: [{ isVerified: false }, { isVerified: { $exists: false } }] }),
        Product.countDocuments({ approvalStatus: 'pending', ...productMatch }),
        Order.find(orderMatch)
          .sort({ createdAt: -1 })
          .limit(5)
          .populate('customer', 'name email avatar phone'),
        Product.find(productMatch).sort({ salesCount: -1 }).limit(5),
      ]);

      const totalRevenue = totalRevenueResult[0]?.total || 0;
      const todayRevenue = todayRevenueResult[0]?.total || 0;

      // 7-day revenue chart
      const revenueChart = await Promise.all(
        Array.from({ length: 7 }, async (_, i) => {
          const daysAgo = 6 - i;
          const dayStart = startOfDay(subDays(now, daysAgo));
          const dayEnd = endOfDay(subDays(now, daysAgo));
          const dayRevenue = await Order.aggregate([
            {
              $match: {
                status: { $nin: ['cancelled', 'refunded'] },
                createdAt: { $gte: dayStart, $lte: dayEnd },
                ...orderMatch,
              },
            },
            { $group: { _id: null, total: { $sum: '$total' } } },
          ]);
          return {
            label: getDayLabel(daysAgo),
            value: dayRevenue[0]?.total || 0,
          };
        })
      );

      // 7-day orders chart
      const ordersChart = await Promise.all(
        Array.from({ length: 7 }, async (_, i) => {
          const daysAgo = 6 - i;
          const dayStart = startOfDay(subDays(now, daysAgo));
          const dayEnd = endOfDay(subDays(now, daysAgo));
          const count = await Order.countDocuments({
            createdAt: { $gte: dayStart, $lte: dayEnd },
            ...orderMatch,
          });
          return {
            label: getDayLabel(daysAgo),
            value: count,
          };
        })
      );

      return {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        todayRevenue: Math.round(todayRevenue * 100) / 100,
        totalOrders,
        todayOrders,
        totalProducts,
        totalUsers,
        totalVendors,
        pendingOrders,
        pendingVendorCount,
        pendingProductCount,
        recentOrders,
        topProducts,
        revenueChart,
        ordersChart,
      };
    },

    getAllUsers: async (_, { role, pagination = {} }, { user }) => {
      requireAdmin(user);
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;

      const query = {};
      if (role && role !== 'all') {
        const targetRole = role.toLowerCase().trim();
        if (targetRole === 'customer') {
          query.$or = [{ role: 'customer' }, { role: { $exists: false } }, { role: null }, { role: '' }];
        } else {
          query.role = targetRole;
        }
      }

      // If logged in as admin (not superadmin), hide superadmin accounts
      if (user.role !== 'superadmin') {
        if (role === 'superadmin') {
          return []; // Admin cannot query superadmins
        }
        query.role = { ...(query.role ? (typeof query.role === 'string' ? { $eq: query.role } : query.role) : {}), $ne: 'superadmin' };
      }

      return User.find(query)
        .select('-password')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },

    getUserById: async (_, { id }, { user }) => {
      requireAdmin(user);
      const target = await User.findById(id);
      if (target?.role === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Access denied to super administrator profile', {
          extensions: { code: 'FORBIDDEN' },
        });
      }
      return target;
    },

    getVendors: async (_, { pagination = {} }, { user }) => {
      requireAdmin(user);
      const { page = 1, limit = 50 } = pagination;
      return User.find({ role: 'vendor' })
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit);
    },

    getDeliveryAgents: async (_, __, { user }) => {
      requireAdminOrVendor(user);
      return User.find({ role: 'delivery', isActive: true }).sort({ name: 1 });
    },

    getRoles: async (_, __, { user }) => {
      requireAdminOrVendor(user);

      // Clean up legacy analytics module from any existing role permission documents
      await RolePermission.updateMany(
        { modules: 'analytics' },
        { $pull: { modules: 'analytics' } }
      );

      let roles = await RolePermission.find().sort({ roleName: 1 });
      if (!roles || roles.length === 0) {
        // Auto-initialize standard system roles
        roles = await RolePermission.insertMany([
          {
            roleName: 'superadmin',
            displayName: 'Super Administrator',
            description: 'Full unrestricted root access to all system modules, server settings, and user management',
            modules: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'users', 'roles', 'coupons', 'delivery', 'taxes', 'invoices', 'reviews', 'banners', 'legal', 'support', 'returns', 'vendors', 'settings'],
            isSystem: true,
          },
          {
            roleName: 'admin',
            displayName: 'Administrator',
            description: 'Administrative access to manage store inventory, orders, customers, delivery, and taxes',
            modules: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'users', 'coupons', 'delivery', 'taxes', 'invoices', 'reviews', 'banners', 'legal', 'support', 'returns', 'vendors', 'settings'],
            isSystem: true,
          },
          {
            roleName: 'vendor',
            displayName: 'Vendor / Seller',
            description: 'Manage store products, orders, returns, and customer reviews',
            modules: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'returns', 'reviews', 'support'],
            isSystem: true,
          },
          {
            roleName: 'delivery',
            displayName: 'Delivery Agent',
            description: 'Manage assigned deliveries and update transit status',
            modules: ['dashboard', 'orders'],
            isSystem: true,
          },
          {
            roleName: 'manager',
            displayName: 'Store Operations Manager',
            description: 'Manage products, categories, orders, coupons, and customer reviews',
            modules: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'coupons', 'reviews', 'invoices'],
            isSystem: false,
          },
        ]);
      } else {
        // Ensure superadmin role entry exists in DB
        const hasSuperAdminRole = roles.some((r) => r.roleName === 'superadmin');
        if (!hasSuperAdminRole) {
          const superAdminRole = await RolePermission.create({
            roleName: 'superadmin',
            displayName: 'Super Administrator',
            description: 'Full unrestricted root access to all system modules, server settings, and user management',
            modules: ['dashboard', 'products', 'categories', 'orders', 'users', 'roles', 'coupons', 'delivery', 'taxes', 'invoices', 'reviews', 'analytics', 'settings'],
            isSystem: true,
          });
          roles.push(superAdminRole);
        }
      }

      // Admin users cannot see or manage the superadmin role
      if (user.role !== 'superadmin') {
        roles = roles.filter((r) => r.roleName !== 'superadmin');
      }

      return roles;
    },

    getDeliveryOptions: async (_, { activeOnly = false, vertical }) => {
      // 1. Smart Migration for existing documents in database
      const existingDocs = await DeliveryOption.find({});
      for (const doc of existingDocs) {
        const nameLower = (doc.name || '').toLowerCase();
        const descLower = (doc.description || '').toLowerCase();
        const text = `${nameLower} ${descLower}`;

        let correctVertical = doc.vertical;
        if (!correctVertical || correctVertical === 'shopping' || correctVertical === 'all') {
          if (text.includes('food') || text.includes('meal') || text.includes('kitchen') || text.includes('restaurant')) {
            correctVertical = 'food';
          } else if (text.includes('grocery') || text.includes('essentials') || text.includes('dark store') || text.includes('fresh')) {
            correctVertical = 'grocery';
          } else if (text.includes('service') || text.includes('appointment') || text.includes('doorstep') || text.includes('technician')) {
            correctVertical = 'services';
          } else {
            correctVertical = 'shopping';
          }
        }

        if (doc.vertical !== correctVertical) {
          await DeliveryOption.findByIdAndUpdate(doc._id, { vertical: correctVertical });
        }
      }

      // 2. Ensure each vertical has default options seeded if missing
      for (const vert of ['shopping', 'food', 'grocery', 'services']) {
        const vCount = await DeliveryOption.countDocuments({ vertical: vert });
        if (vCount === 0) {
          if (vert === 'shopping') {
            await DeliveryOption.create({
              name: 'Standard Shipping (Retail)',
              description: 'Standard courier delivery in 3-5 business days',
              estimatedDays: '3-5 Business Days',
              price: 49,
              minOrderForFree: 499,
              vertical: 'shopping',
              isDefault: true,
              isActive: true,
              sortOrder: 1,
            });
          } else if (vert === 'food') {
            await DeliveryOption.create({
              name: 'Instant Food Express (30 Mins)',
              description: 'Direct hot meal delivery from restaurant kitchen',
              estimatedDays: '30-45 Minutes',
              price: 35,
              minOrderForFree: 299,
              vertical: 'food',
              isDefault: true,
              isActive: true,
              sortOrder: 1,
            });
          } else if (vert === 'grocery') {
            await DeliveryOption.create({
              name: 'Quick Grocery Express (15-30 Mins)',
              description: 'Fresh vegetables, fruits & dark store essentials',
              estimatedDays: '15-30 Minutes',
              price: 25,
              minOrderForFree: 199,
              vertical: 'grocery',
              isDefault: true,
              isActive: true,
              sortOrder: 1,
            });
            await DeliveryOption.create({
              name: 'Standard Grocery Delivery (1-2 Hours)',
              description: 'Scheduled daily grocery delivery',
              estimatedDays: '1-2 Hours',
              price: 45,
              minOrderForFree: 499,
              vertical: 'grocery',
              isDefault: false,
              isActive: true,
              sortOrder: 2,
            });
          } else if (vert === 'services') {
            await DeliveryOption.create({
              name: 'Doorstep Service Visit Slot',
              description: 'Certified expert technician visits at appointment slot',
              estimatedDays: 'Scheduled Appointment Slot',
              price: 0,
              minOrderForFree: 0,
              vertical: 'services',
              isDefault: true,
              isActive: true,
              sortOrder: 1,
            });
          }
        }
      }

      // 3. Build query filter
      const query = {};
      if (activeOnly) query.isActive = true;
      if (vertical && vertical !== 'all') {
        query.vertical = vertical;
      }

      let results = await DeliveryOption.find(query).sort({ sortOrder: 1, createdAt: 1 });
      if ((!results || results.length === 0) && vertical && vertical !== 'all') {
        results = await DeliveryOption.find({ ...(activeOnly && { isActive: true }) }).sort({ sortOrder: 1, createdAt: 1 });
      }
      return results;
    },

    getTaxSettings: async (_, { activeOnly = false }) => {
      const query = activeOnly ? { isActive: true } : {};
      let taxes = await TaxSetting.find(query).sort({ rate: -1 });
      if ((!taxes || taxes.length === 0) && !activeOnly) {
        // Auto-seed GST tax brackets
        taxes = await TaxSetting.insertMany([
          {
            name: 'Standard GST (18%)',
            rate: 18,
            cgst: 9,
            sgst: 9,
            igst: 18,
            hsnCode: '9983',
            description: 'Standard Goods & Services Tax for electronic and general merchandise',
            isDefault: true,
            isActive: true,
          },
          {
            name: 'Reduced GST (12%)',
            rate: 12,
            cgst: 6,
            sgst: 6,
            igst: 12,
            hsnCode: '9984',
            description: 'Reduced rate for processed items and apparel',
            isDefault: false,
            isActive: true,
          },
          {
            name: 'Essential Goods GST (5%)',
            rate: 5,
            cgst: 2.5,
            sgst: 2.5,
            igst: 5,
            hsnCode: '9985',
            description: 'Essential items rate',
            isDefault: false,
            isActive: true,
          },
        ]);
      }
      return taxes;
    },

    getAnalytics: async (_, { period = '30d' }, { user }) => {
      requireAdminOrVendor(user);

      const days = period === '7d' ? 7 : period === '90d' ? 90 : 30;
      const startDate = subDays(new Date(), days);

      const isVendor = user.role === 'vendor';
      const vendorMatch = isVendor
        ? { $or: [{ vendor: user._id }, { 'items.vendor': user._id }] }
        : {};

      const [ordersByStatusResult, revenueByCategoryResult, monthlyRevenueResult] = await Promise.all([
        Order.aggregate([
          { $match: { ...vendorMatch } },
          { $group: { _id: '$status', count: { $sum: 1 } } },
        ]),
        Order.aggregate([
          { $match: { status: { $nin: ['cancelled', 'refunded'] }, ...vendorMatch } },
          { $unwind: '$items' },
          ...(isVendor ? [{ $match: { 'items.vendor': user._id } }] : []),
          {
            $lookup: {
              from: 'products',
              localField: 'items.product',
              foreignField: '_id',
              as: 'productData',
            },
          },
          { $unwind: { path: '$productData', preserveNullAndEmpty: true } },
          {
            $lookup: {
              from: 'categories',
              localField: 'productData.category',
              foreignField: '_id',
              as: 'categoryData',
            },
          },
          { $unwind: { path: '$categoryData', preserveNullAndEmpty: true } },
          {
            $group: {
              _id: { $ifNull: ['$categoryData.name', 'General Store'] },
              revenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } },
            },
          },
          { $sort: { revenue: -1 } },
          { $limit: 10 },
        ]),
        Order.aggregate([
          {
            $match: { status: { $nin: ['cancelled', 'refunded'] }, createdAt: { $gte: startDate }, ...vendorMatch },
          },
          {
            $group: {
              _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
              revenue: { $sum: '$total' },
              orders: { $sum: 1 },
            },
          },
          { $sort: { _id: 1 } },
        ]),
      ]);

      // Build continuous daily timeline for all days in selected period
      const numDays = period === '7d' ? 7 : period === '90d' ? 90 : 30;
      const dailyMap = {};
      (monthlyRevenueResult || []).forEach((m) => {
        if (m._id) dailyMap[m._id] = m;
      });

      const fullTimeline = Array.from({ length: numDays }, (_, i) => {
        const d = subDays(new Date(), numDays - 1 - i);
        const key = format(d, 'yyyy-MM-dd');
        const label = format(d, 'MMM d');
        return {
          _id: key,
          date: label,
          revenue: dailyMap[key]?.revenue ? Math.round(dailyMap[key].revenue * 100) / 100 : 0,
          orders: dailyMap[key]?.orders || 0,
        };
      });

      return {
        ordersByStatus: ordersByStatusResult.length > 0 ? ordersByStatusResult : [{ _id: 'placed', count: 1 }],
        revenueByCategory: revenueByCategoryResult.length > 0 ? revenueByCategoryResult : [{ _id: 'General Store', revenue: 0 }],
        monthlyRevenue: fullTimeline,
        period,
      };
    },
  },

  Mutation: {
    // User CRUD
    createUser: async (_, { input }, { user }) => {
      requireAdmin(user);
      const { name, email, password, role = 'vendor', phone, permissions } = input;
      const normalizedRole = (role || 'vendor').toLowerCase().trim();

      if (!phone || !phone.trim()) {
        throw new GraphQLError('Phone number is required', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Rule: Admin cannot create customer from user management
      if (normalizedRole === 'customer') {
        throw new GraphQLError('Customer accounts cannot be created from the staff management module. Customers register via the customer portal.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Rule: Admin cannot create superadmin role
      if (normalizedRole === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Only super administrators can create superadmin accounts.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const existing = await User.findOne({ email: email.toLowerCase().trim() });
      if (existing) {
        throw new GraphQLError('A user with this email already exists', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const verticals = input.vendorVerticals || (input.vendorVertical ? [input.vendorVertical] : []);
      const primaryVertical = verticals[0] || input.vendorVertical || 'shopping';

      let vehiclesData = [];
      if (Array.isArray(input.vehicles) && input.vehicles.length > 0) {
        vehiclesData = input.vehicles.slice(0, 3).map((v, index) => ({
          vehicleType: v.vehicleType || '2_wheeler',
          registrationNumber: v.registrationNumber || '',
          isPrimary: v.isPrimary !== undefined ? v.isPrimary : (index === 0)
        }));
      } else if (input.vehicleType || input.vehicleRegistrationNumber) {
        vehiclesData = [{
          vehicleType: input.vehicleType || '2_wheeler',
          registrationNumber: input.vehicleRegistrationNumber || '',
          isPrimary: true
        }];
      }

      if (vehiclesData.length > 0) {
        const hasPrimary = vehiclesData.some(v => v.isPrimary);
        if (!hasPrimary) {
          vehiclesData[0].isPrimary = true;
        }
      }

      const primaryVehicle = vehiclesData.find(v => v.isPrimary) || vehiclesData[0];
      const mainVehicleType = primaryVehicle ? primaryVehicle.vehicleType : (input.vehicleType || '2_wheeler');
      const mainVehicleRegistrationNumber = primaryVehicle ? primaryVehicle.registrationNumber : (input.vehicleRegistrationNumber || '');

      const sanitizedPhone = phone && phone.trim() ? phone.trim() : undefined;
      const sanitizedEmail = email && email.trim() ? email.toLowerCase().trim() : undefined;

      try {
        return await User.create({
          name,
          email: sanitizedEmail,
          password,
          role: normalizedRole,
          phone: sanitizedPhone,
          permissions: permissions || [],
          vendorCategory: input.vendorCategory,
          vendorVertical: primaryVertical,
          vendorVerticals: verticals,
          commissionRate: input.commissionRate !== undefined ? input.commissionRate : 10,
          deliveryPayoutType: input.deliveryPayoutType || 'per_order',
          deliveryPerOrderRate: input.deliveryPerOrderRate !== undefined ? input.deliveryPerOrderRate : 65,
          deliveryMonthlySalary: input.deliveryMonthlySalary !== undefined ? input.deliveryMonthlySalary : 18000,
          deliveryDailyIncentive: input.deliveryDailyIncentive !== undefined ? input.deliveryDailyIncentive : 150,
          vehicleType: mainVehicleType,
          vehicleRegistrationNumber: mainVehicleRegistrationNumber,
          vehicles: vehiclesData,
          isVerified: true,
          isActive: true,
        });
      } catch (err) {
        if (err.code === 11000 || err.message?.includes('E11000')) {
          if (err.message?.includes('phone') || JSON.stringify(err.keyValue || {}).includes('phone')) {
            throw new GraphQLError('A user with this phone number already exists.', {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
          if (err.message?.includes('email') || JSON.stringify(err.keyValue || {}).includes('email')) {
            throw new GraphQLError('A user with this email address already exists.', {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
          throw new GraphQLError('A user with this information already exists.', {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        throw err;
      }
    },

    updateUser: async (_, { id, input }, { user }) => {
      requireAdmin(user);
      const userToUpdate = await User.findById(id);
      if (!userToUpdate) {
        throw new GraphQLError('User not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      // Rule: Non-superadmin cannot modify a superadmin account
      if (userToUpdate.role === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Access denied: cannot modify super administrator accounts.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      if (input.role) {
        const normalizedRole = input.role.toLowerCase().trim();
        if (normalizedRole === 'customer') {
          throw new GraphQLError('Cannot assign customer role in staff management.', {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        if (normalizedRole === 'superadmin' && user.role !== 'superadmin') {
          throw new GraphQLError('Only super administrators can assign the superadmin role.', {
            extensions: { code: 'FORBIDDEN' },
          });
        }
        userToUpdate.role = normalizedRole;
      }

      if (input.name) userToUpdate.name = input.name;
      if (input.email) userToUpdate.email = input.email.toLowerCase().trim();
      if (input.phone !== undefined) {
        userToUpdate.phone = input.phone && input.phone.trim() ? input.phone.trim() : undefined;
      }
      if (input.isActive !== undefined) userToUpdate.isActive = input.isActive;
      if (input.isVerified !== undefined) userToUpdate.isVerified = input.isVerified;
      if (input.permissions) userToUpdate.permissions = input.permissions;
      if (input.vendorCategory !== undefined) userToUpdate.vendorCategory = input.vendorCategory;
      if (input.commissionRate !== undefined) userToUpdate.commissionRate = input.commissionRate;
      if (input.deliveryPayoutType !== undefined) userToUpdate.deliveryPayoutType = input.deliveryPayoutType;
      if (input.deliveryPerOrderRate !== undefined) userToUpdate.deliveryPerOrderRate = input.deliveryPerOrderRate;
      if (input.deliveryMonthlySalary !== undefined) userToUpdate.deliveryMonthlySalary = input.deliveryMonthlySalary;
      if (input.deliveryDailyIncentive !== undefined) userToUpdate.deliveryDailyIncentive = input.deliveryDailyIncentive;
      if (Array.isArray(input.vehicles)) {
        let vehiclesData = input.vehicles.slice(0, 3).map((v, index) => ({
          vehicleType: v.vehicleType || '2_wheeler',
          registrationNumber: v.registrationNumber || '',
          isPrimary: v.isPrimary !== undefined ? v.isPrimary : (index === 0)
        }));
        if (vehiclesData.length > 0) {
          const hasPrimary = vehiclesData.some(v => v.isPrimary);
          if (!hasPrimary) vehiclesData[0].isPrimary = true;
          const primaryVehicle = vehiclesData.find(v => v.isPrimary) || vehiclesData[0];
          userToUpdate.vehicleType = primaryVehicle.vehicleType;
          userToUpdate.vehicleRegistrationNumber = primaryVehicle.registrationNumber;
        }
        userToUpdate.vehicles = vehiclesData;
      } else {
        if (input.vehicleType !== undefined) userToUpdate.vehicleType = input.vehicleType;
        if (input.vehicleRegistrationNumber !== undefined) userToUpdate.vehicleRegistrationNumber = input.vehicleRegistrationNumber;
      }
      if (input.vendorVerticals !== undefined) {
        userToUpdate.vendorVerticals = input.vendorVerticals;
        if (input.vendorVerticals.length > 0) {
          userToUpdate.vendorVertical = input.vendorVerticals[0];
        }
      } else if (input.vendorVertical !== undefined) {
        userToUpdate.vendorVertical = input.vendorVertical;
        if (!userToUpdate.vendorVerticals || userToUpdate.vendorVerticals.length === 0) {
          userToUpdate.vendorVerticals = [input.vendorVertical];
        }
      }
      if (input.password && input.password.length >= 6) {
        userToUpdate.password = input.password;
      }

      return userToUpdate.save();
    },

    updateDeliveryPartnerPayoutConfig: async (
      _,
      { userId, payoutType, perOrderRate, monthlySalary, dailyIncentive, minOrdersForIncentive, vehicleType, vehicleRegistrationNumber, vehicles },
      { user }
    ) => {
      requireAdmin(user);
      const targetUser = await User.findById(userId);
      if (!targetUser) {
        throw new GraphQLError('Delivery partner user not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      if (payoutType) targetUser.deliveryPayoutType = payoutType;
      if (perOrderRate !== undefined && perOrderRate !== null) targetUser.deliveryPerOrderRate = perOrderRate;
      if (monthlySalary !== undefined && monthlySalary !== null) targetUser.deliveryMonthlySalary = monthlySalary;
      if (dailyIncentive !== undefined && dailyIncentive !== null) targetUser.deliveryDailyIncentive = dailyIncentive;
      if (minOrdersForIncentive !== undefined && minOrdersForIncentive !== null) targetUser.deliveryMinOrdersForIncentive = minOrdersForIncentive;
      
      if (Array.isArray(vehicles)) {
        let vehiclesData = vehicles.slice(0, 3).map((v, index) => ({
          vehicleType: v.vehicleType || '2_wheeler',
          registrationNumber: v.registrationNumber || '',
          isPrimary: v.isPrimary !== undefined ? v.isPrimary : (index === 0)
        }));
        if (vehiclesData.length > 0) {
          const hasPrimary = vehiclesData.some(v => v.isPrimary);
          if (!hasPrimary) vehiclesData[0].isPrimary = true;
          const primaryVehicle = vehiclesData.find(v => v.isPrimary) || vehiclesData[0];
          targetUser.vehicleType = primaryVehicle.vehicleType;
          targetUser.vehicleRegistrationNumber = primaryVehicle.registrationNumber;
        }
        targetUser.vehicles = vehiclesData;
      } else {
        if (vehicleType !== undefined && vehicleType !== null) targetUser.vehicleType = vehicleType;
        if (vehicleRegistrationNumber !== undefined && vehicleRegistrationNumber !== null) targetUser.vehicleRegistrationNumber = vehicleRegistrationNumber;
      }

      await targetUser.save();
      return targetUser;
    },

    recordDeliveryCashReceived: async (_, { userId, amount, notes }, { user }) => {
      requireAdmin(user);
      const targetUser = await User.findById(userId);
      if (!targetUser) {
        throw new GraphQLError('Delivery partner user not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      const numAmt = Number(amount);
      if (isNaN(numAmt) || numAmt <= 0) {
        throw new GraphQLError('Please enter a valid cash amount greater than ₹0', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      targetUser.submittedCash = (targetUser.submittedCash || 0) + numAmt;
      if (!Array.isArray(targetUser.cashSubmissions)) {
        targetUser.cashSubmissions = [];
      }
      targetUser.cashSubmissions.push({
        amount: numAmt,
        receivedBy: user.name || 'Admin',
        notes: notes ? notes.trim() : 'Cash handed over at hub',
        createdAt: new Date(),
      });

      await targetUser.save();
      return targetUser;
    },

    deleteUser: async (_, { id }, { user }) => {
      requireAdmin(user);
      if (user._id.toString() === id) {
        throw new GraphQLError('You cannot delete your own account', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const userToDelete = await User.findById(id);
      if (!userToDelete) {
        throw new GraphQLError('User not found', { extensions: { code: 'NOT_FOUND' } });
      }

      // Rule: Superadmin accounts cannot be deleted
      if (userToDelete.role === 'superadmin') {
        throw new GraphQLError('Super administrator accounts cannot be deleted.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      // Rule: Only superadmin can delete admin accounts
      if (userToDelete.role === 'admin' && user.role !== 'superadmin') {
        throw new GraphQLError('Only super administrators can delete administrator accounts.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      await User.findByIdAndDelete(id);
      return true;
    },

    updateUserStatus: async (_, { userId, isActive }, { user }) => {
      requireAdmin(user);
      const userToUpdate = await User.findById(userId);
      if (!userToUpdate) throw new GraphQLError('User not found', { extensions: { code: 'NOT_FOUND' } });
      if (userToUpdate.role === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Cannot modify super administrator status', { extensions: { code: 'FORBIDDEN' } });
      }
      return User.findByIdAndUpdate(userId, { isActive }, { new: true });
    },

    updateUserRole: async (_, { userId, role }, { user }) => {
      requireAdmin(user);
      const normalizedRole = role.toLowerCase().trim();
      if (normalizedRole === 'customer') {
        throw new GraphQLError('Cannot assign customer role in staff management', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      if (normalizedRole === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Only super administrators can assign superadmin role', { extensions: { code: 'FORBIDDEN' } });
      }
      return User.findByIdAndUpdate(userId, { role: normalizedRole }, { new: true });
    },

    // Role Permissions
    saveRolePermissions: async (_, { input }, { user }) => {
      requireAdmin(user);
      const { roleName, displayName, description, modules } = input;
      const normalizedRoleName = roleName.toLowerCase().trim();

      // Rule: Admin cannot create or edit superadmin role
      if (normalizedRoleName === 'superadmin' && user.role !== 'superadmin') {
        throw new GraphQLError('Only super administrators can modify superadmin permissions', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      return RolePermission.findOneAndUpdate(
        { roleName: normalizedRoleName },
        { displayName, description, modules },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    },

    deleteRole: async (_, { id }, { user }) => {
      requireAdmin(user);
      const role = await RolePermission.findById(id);
      if (!role) throw new GraphQLError('Role not found', { extensions: { code: 'NOT_FOUND' } });
      if (role.isSystem || role.roleName === 'superadmin' || role.roleName === 'admin') {
        throw new GraphQLError('System core roles cannot be deleted', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }
      await role.deleteOne();
      return true;
    },

    // Delivery Options
    createDeliveryOption: async (_, { input }, { user }) => {
      requireAdmin(user);
      if (input.isDefault) {
        await DeliveryOption.updateMany({}, { isDefault: false });
      }
      return DeliveryOption.create(input);
    },

    updateDeliveryOption: async (_, { id, input }, { user }) => {
      requireAdmin(user);
      if (input.isDefault) {
        await DeliveryOption.updateMany({ _id: { $ne: id } }, { isDefault: false });
      }
      return DeliveryOption.findByIdAndUpdate(id, input, { new: true });
    },

    deleteDeliveryOption: async (_, { id }, { user }) => {
      requireAdmin(user);
      await DeliveryOption.findByIdAndDelete(id);
      return true;
    },

    // Tax Settings
    createTaxSetting: async (_, { input }, { user }) => {
      requireAdmin(user);
      if (input.isDefault) {
        await TaxSetting.updateMany({}, { isDefault: false });
      }
      return TaxSetting.create(input);
    },

    updateTaxSetting: async (_, { id, input }, { user }) => {
      requireAdmin(user);
      if (input.isDefault) {
        await TaxSetting.updateMany({ _id: { $ne: id } }, { isDefault: false });
      }
      return TaxSetting.findByIdAndUpdate(id, input, { new: true });
    },

    deleteTaxSetting: async (_, { id }, { user }) => {
      requireAdmin(user);
      await TaxSetting.findByIdAndDelete(id);
      return true;
    },
  },
};

export default adminResolvers;
