import mongoose from 'mongoose';

const storeSettingSchema = new mongoose.Schema(
  {
    storeName: {
      type: String,
    },
    logoUrl: {
      type: String,
    },
    faviconUrl: {
      type: String,
    },
    appIconUrl: {
      type: String,
    },
    disabledVerticals: [
      {
        type: String,
      },
    ],
    serviceBookingMode: {
      type: String,
      enum: ['call_now', 'book_now'],
      default: 'call_now',
    },
    serviceContactPhone: {
      type: String,
      default: '+91 98765 43210',
    },
    paymentMode: {
      type: String,
      enum: ['both', 'cash', 'online'],
      default: 'both',
    },
    latestCustomerVersion: {
      type: String,
      default: '1.0.0',
    },
    customerApkUrl: {
      type: String,
      default: '',
    },
    latestDeliveryVersion: {
      type: String,
      default: '1.0.0',
    },
    deliveryApkUrl: {
      type: String,
      default: '',
    },
    forceAppUpdate: {
      type: Boolean,
      default: false,
    },
    websiteDisplayMode: {
      type: String,
      enum: ['full_website', 'landing_page'],
      default: 'full_website',
    },
    customerPlayStoreUrl: {
      type: String,
      default: '',
    },
    customerIosUrl: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: true,
  }
);

export const StoreSetting = mongoose.model('StoreSetting', storeSettingSchema);
