import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMutation } from '@apollo/client';
import { ADD_REVIEW } from '../../graphql/mutations';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function ReviewModal({
  visible,
  onClose,
  order,
  onReviewSubmitted,
}) {
  const [targetType, setTargetType] = useState('product'); // 'product' | 'delivery'
  const [selectedProductId, setSelectedProductId] = useState(
    order?.items?.[0]?.product?._id || ''
  );

  // Independent review states
  const [productRating, setProductRating] = useState(5);
  const [productTitle, setProductTitle] = useState('');
  const [productComment, setProductComment] = useState('');

  const [deliveryRating, setDeliveryRating] = useState(5);
  const [deliveryTitle, setDeliveryTitle] = useState('');
  const [deliveryComment, setDeliveryComment] = useState('');

  const [addReview] = useMutation(ADD_REVIEW);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    const hasProductComment = Boolean(productComment.trim());
    const hasDeliveryComment = Boolean(deliveryComment.trim());

    if (!hasProductComment && !hasDeliveryComment) {
      Alert.alert('Required', 'Please write feedback for Product or Delivery Agent.');
      return;
    }

    setSubmitting(true);
    let count = 0;
    const errors = [];

    if (hasProductComment) {
      try {
        const prodInput = {
          targetType: 'product',
          orderId: order?._id,
          productId: selectedProductId || order?.items?.[0]?.product?._id || order?.items?.[0]?.product,
          rating: productRating,
          title: productTitle.trim() || 'Product Feedback',
          comment: productComment.trim(),
        };
        await addReview({ variables: { input: prodInput } });
        count++;
        setProductTitle('');
        setProductComment('');
        setProductRating(5);
      } catch (err) {
        errors.push(`Product: ${err.message}`);
      }
    }

    if (hasDeliveryComment) {
      try {
        const delivInput = {
          targetType: 'delivery',
          orderId: order?._id,
          deliveryAgentId: order?.deliveryAgent?._id || order?.deliveryAgent || order?.deliveryBoy?._id || order?.deliveryBoy,
          rating: deliveryRating,
          title: deliveryTitle.trim() || 'Delivery Feedback',
          comment: deliveryComment.trim(),
        };
        await addReview({ variables: { input: delivInput } });
        count++;
        setDeliveryTitle('');
        setDeliveryComment('');
        setDeliveryRating(5);
      } catch (err) {
        errors.push(`Delivery: ${err.message}`);
      }
    }

    setSubmitting(false);

    if (count > 0) {
      Alert.alert(
        'Thank you!',
        count > 1
          ? 'Both product and delivery reviews have been submitted successfully.'
          : 'Your review has been submitted successfully.'
      );
      if (onReviewSubmitted) onReviewSubmitted();
      onClose();
    }

    if (errors.length > 0) {
      Alert.alert('Review Error', errors.join('\n'));
    }
  };

  const currentRating = targetType === 'product' ? productRating : deliveryRating;
  const currentTitle = targetType === 'product' ? productTitle : deliveryTitle;
  const currentComment = targetType === 'product' ? productComment : deliveryComment;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modalContent}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Rate & Review</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Ionicons name="close" size={22} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>

          {/* Target Tabs */}
          <View style={styles.tabBar}>
            {[
              { key: 'product', label: '🛍️ Product' },
              { key: 'delivery', label: '🚚 Delivery Agent' },
            ].map((tab) => (
              <TouchableOpacity
                key={tab.key}
                style={[
                  styles.tabItem,
                  targetType === tab.key && styles.tabItemActive,
                ]}
                onPress={() => setTargetType(tab.key)}
              >
                <Text
                  style={[
                    styles.tabText,
                    targetType === tab.key && styles.tabTextActive,
                  ]}
                >
                  {tab.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Product selector if multiple items */}
          {targetType === 'product' && order?.items?.length > 1 && (
            <View style={{ marginBottom: 10 }}>
              <Text style={styles.inputLabel}>Select Product to Review</Text>
              <View style={styles.chipRow}>
                {order.items.map((item, idx) => {
                  const pId = item.product?._id || item.product || item._id;
                  const isSelected = selectedProductId === pId || (!selectedProductId && idx === 0);
                  return (
                    <TouchableOpacity
                      key={pId || idx}
                      style={[styles.productChip, isSelected && styles.productChipActive]}
                      onPress={() => setSelectedProductId(pId)}
                    >
                      <Text style={[styles.productChipText, isSelected && styles.productChipTextActive]} numberOfLines={1}>
                        {item.name || item.title || `Item ${idx + 1}`}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          )}

          {/* Stars */}
          <View style={styles.starsRow}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity
                key={star}
                onPress={() => (targetType === 'product' ? setProductRating(star) : setDeliveryRating(star))}
                style={styles.starButton}
              >
                <Ionicons
                  name={star <= currentRating ? 'star' : 'star-outline'}
                  size={32}
                  color={star <= currentRating ? COLORS.star : COLORS.border}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Title Input */}
          <Text style={styles.inputLabel}>Review Title</Text>
          <TextInput
            style={styles.input}
            placeholder={targetType === 'product' ? 'e.g. Excellent quality' : 'e.g. Fast & polite delivery'}
            placeholderTextColor={COLORS.textMuted}
            value={currentTitle}
            onChangeText={(txt) => (targetType === 'product' ? setProductTitle(txt) : setDeliveryTitle(txt))}
          />

          {/* Comment Input */}
          <Text style={styles.inputLabel}>Detailed Feedback *</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder={targetType === 'product' ? 'Share details about your experience with this item...' : 'Share details about your experience with the delivery partner...'}
            placeholderTextColor={COLORS.textMuted}
            multiline
            numberOfLines={4}
            value={currentComment}
            onChangeText={(txt) => (targetType === 'product' ? setProductComment(txt) : setDeliveryComment(txt))}
          />

          {/* Submit Button */}
          <TouchableOpacity
            style={[styles.submitButton, submitting && styles.submitButtonDisabled]}
            onPress={handleSubmit}
            disabled={submitting}
          >
            {submitting ? (
              <ActivityIndicator color={COLORS.white} />
            ) : (
              <Text style={styles.submitButtonText}>Submit Review</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: SIZES.radiusLg,
    borderTopRightRadius: SIZES.radiusLg,
    padding: SIZES.padding * 1.2,
    ...SHADOWS.medium,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusSm,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: SIZES.radiusSm - 2,
  },
  tabItemActive: {
    backgroundColor: COLORS.white,
    ...SHADOWS.small,
  },
  tabText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginTop: 4,
  },
  productChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    maxWidth: '48%',
  },
  productChipActive: {
    backgroundColor: COLORS.primaryLight || '#EEF2FF',
    borderColor: COLORS.primary,
  },
  productChipText: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  productChipTextActive: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginVertical: 12,
  },
  starButton: {
    padding: 4,
  },
  inputLabel: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 10,
    marginBottom: 4,
  },
  input: {
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: SIZES.sm,
    color: COLORS.text,
  },
  textArea: {
    height: 90,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusSm,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
    ...SHADOWS.glow,
  },
  submitButtonDisabled: {
    opacity: 0.7,
  },
  submitButtonText: {
    color: COLORS.white,
    fontSize: SIZES.md,
    fontWeight: '700',
  },
});
