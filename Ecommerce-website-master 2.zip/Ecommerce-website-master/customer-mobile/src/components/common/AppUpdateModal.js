import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_STORE_SETTINGS } from '../../graphql/queries';
import appConfig from '../../../app.json';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

function isVersionHigher(latest, current) {
  if (!latest || !current) return false;
  const lParts = latest.split('.').map((n) => parseInt(n, 10) || 0);
  const cParts = current.split('.').map((n) => parseInt(n, 10) || 0);
  const maxLen = Math.max(lParts.length, cParts.length);
  for (let i = 0; i < maxLen; i++) {
    const l = lParts[i] || 0;
    const c = cParts[i] || 0;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}

export default function AppUpdateModal() {
  const [dismissed, setDismissed] = useState(false);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
    pollInterval: 30000,
  });

  const storeSettings = settingsData?.getStoreSettings;
  const currentVersion = appConfig?.expo?.version || '1.0.0';
  const latestVersion = storeSettings?.latestCustomerVersion;
  const apkDownloadUrl = storeSettings?.customerApkUrl;
  const isForceUpdate = Boolean(storeSettings?.forceAppUpdate);

  const hasNewUpdate =
    Boolean(latestVersion) &&
    Boolean(apkDownloadUrl) &&
    isVersionHigher(latestVersion, currentVersion);

  if (!hasNewUpdate || dismissed) {
    return null;
  }

  const handleUpdateNow = () => {
    if (!apkDownloadUrl) return;
    Linking.openURL(apkDownloadUrl).catch((err) =>
      console.error('Error opening update URL:', err)
    );
  };

  return (
    <Modal
      visible={true}
      transparent={true}
      animationType="fade"
      onRequestClose={() => {
        if (!isForceUpdate) setDismissed(true);
      }}
    >
      <View style={styles.overlay}>
        <View style={styles.card}>
          <View style={styles.iconContainer}>
            <Ionicons name="rocket-outline" size={40} color={COLORS.primary} />
          </View>

          <Text style={styles.title}>Update Available!</Text>
          <Text style={styles.subtitle}>
            A new version <Text style={styles.boldVersion}>v{latestVersion}</Text> of Suaaka is available. Update now for instant performance improvements and bug fixes.
          </Text>

          <TouchableOpacity
            style={styles.updateBtn}
            onPress={handleUpdateNow}
            activeOpacity={0.8}
          >
            <Text style={styles.updateBtnText}>Download Update</Text>
            <Ionicons name="cloud-download-outline" size={20} color={COLORS.white} />
          </TouchableOpacity>

          {!isForceUpdate && (
            <TouchableOpacity
              style={styles.laterBtn}
              onPress={() => setDismissed(true)}
            >
              <Text style={styles.laterBtnText}>Remind Me Later</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.75)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusLg,
    padding: 24,
    alignItems: 'center',
    ...SHADOWS.card,
  },
  iconContainer: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#FFEDD5',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    color: COLORS.text,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 20,
  },
  boldVersion: {
    fontWeight: '700',
    color: COLORS.primary,
  },
  updateBtn: {
    width: '100%',
    height: 48,
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusMd,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    ...SHADOWS.glow,
  },
  updateBtnText: {
    color: COLORS.white,
    fontSize: SIZES.md,
    fontWeight: '700',
  },
  progressContainer: {
    width: '100%',
    alignItems: 'center',
    gap: 8,
  },
  progressBarTrack: {
    width: '100%',
    height: 10,
    borderRadius: 5,
    backgroundColor: '#E2E8F0',
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 5,
  },
  progressText: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  errorText: {
    fontSize: 11,
    color: COLORS.danger || '#EF4444',
    textAlign: 'center',
    marginTop: 8,
  },
  laterBtn: {
    marginTop: 12,
    paddingVertical: 6,
  },
  laterBtnText: {
    fontSize: SIZES.xs,
    color: COLORS.textMuted,
    fontWeight: '600',
  },
});
