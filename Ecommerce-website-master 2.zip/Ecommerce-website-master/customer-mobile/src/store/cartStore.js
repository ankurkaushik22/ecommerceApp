import { create } from 'zustand';
import { Vibration } from 'react-native';

export const useCartStore = create((set, get) => ({
  cart: null,
  items: [],
  itemCount: 0,

  setCart: (cartData) => {
    const rawItems = cartData?.items || [];
    const count = rawItems.reduce((acc, item) => acc + (item?.quantity || 0), 0);
    set({ cart: cartData, items: rawItems, itemCount: count });
  },

  addItem: (product, qty = 1) => {
    const currentItems = get().items || [];
    const prodId = product._id || product.id || product.productId;
    const vertical = product.vertical || product.category?.vertical || 'shopping';

    const getAddonsKey = (p) => (p?.addons || []).map(a => a.name).sort().join('|');
    const pAddonsKey = getAddonsKey(product);
    const pInstructions = (product.instructions || '').trim();
    const pVariant = (product.variantLabel || product.selectedVariant?.label || '').trim();

    const existingIndex = currentItems.findIndex((i) => {
      const iProdId = i.product?._id || i.productId || i._id;
      const iAddonsKey = getAddonsKey(i.product || i);
      const iInstructions = (i.instructions || i.product?.instructions || '').trim();
      const iVariant = (i.variantLabel || i.selectedVariant?.label || i.product?.variantLabel || '').trim();
      return iProdId === prodId && iAddonsKey === pAddonsKey && iInstructions === pInstructions && iVariant === pVariant;
    });

    let updated;
    if (existingIndex > -1) {
      updated = currentItems.map((item, idx) =>
        idx === existingIndex
          ? {
              ...item,
              quantity: (item.quantity || 0) + qty,
              price: product.price || item.price,
              vertical: item.vertical || vertical,
              product: { ...product, vertical },
            }
          : item
      );
    } else {
      const formattedProd = { ...product, vertical };
      updated = [
        ...currentItems,
        {
          _id: `temp-${Date.now()}`,
          product: formattedProd,
          productId: prodId,
          quantity: qty,
          price: product.price || 0,
          addons: product.addons || [],
          instructions: pInstructions,
          variantLabel: pVariant,
          variantIndex: product.variantIndex ?? -1,
          vertical,
        },
      ];
    }

    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
    try {
      Vibration.vibrate(60);
    } catch {}
  },

  updateQuantity: (itemId, newQty) => {
    const currentItems = get().items || [];
    let updated;
    if (newQty <= 0) {
      updated = currentItems.filter(
        (i) => i._id !== itemId && i.product?._id !== itemId && i.productId !== itemId
      );
    } else {
      updated = currentItems.map((item) =>
        (item._id === itemId || item.product?._id === itemId || item.productId === itemId)
          ? { ...item, quantity: newQty }
          : item
      );
    }
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
  },

  removeItem: (itemId) => {
    const currentItems = get().items || [];
    const updated = currentItems.filter(
      (i) => i._id !== itemId && i.product?._id !== itemId && i.productId !== itemId
    );
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
  },

  clearCartState: () => {
    set({ cart: null, items: [], itemCount: 0 });
  },
}));
