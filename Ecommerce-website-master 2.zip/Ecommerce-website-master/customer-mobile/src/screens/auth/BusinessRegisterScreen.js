import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useMutation, useQuery } from '@apollo/client';
import { REGISTER_MUTATION } from '../../graphql/mutations';
import { GET_STORE_SETTINGS } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function BusinessRegisterScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [selectedVertical, setSelectedVertical] = useState('shopping');
  const [showCategoryModal, setShowCategoryModal] = useState(false);

  const setAuth = useAuthStore((s) => s.setAuth);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;
  const disabledVerticals = storeSettings?.disabledVerticals || [];

  const CATEGORY_OPTIONS = [
    { id: 'shopping', label: 'Shopping (Retail / Products)', icon: 'bag-handle-outline', emoji: '🛍️' },
    { id: 'food', label: 'Food Delivery (Restaurant / Food Items)', icon: 'fast-food-outline', emoji: '🍔' },
    { id: 'grocery', label: 'Grocery (Fresh Staples & Dairy)', icon: 'leaf-outline', emoji: '🥦' },
    { id: 'services', label: 'Services (Home Repairs, Cleaning & Beauty)', icon: 'construct-outline', emoji: '🛠️' },
  ].filter((c) => !disabledVerticals.includes(c.id));

  const currentCategory = CATEGORY_OPTIONS.find((c) => c.id === selectedVertical) || CATEGORY_OPTIONS[0];

  const [registerMutation, { loading }] = useMutation(REGISTER_MUTATION, {
    onCompleted: async (data) => {
      const { user, token } = data.register;
      await setAuth(user, token);
      Alert.alert(
        'Business Account Created!',
        `Welcome ${user.name || 'Vendor'}! Your store registration was successful.`,
        [
          {
            text: 'OK',
            onPress: () => navigation.navigate('MainTabs'),
          },
        ]
      );
    },
    onError: (err) => {
      Alert.alert('Registration Failed', err.message || 'Could not register business account');
    },
  });

  const handleCreateBusinessAccount = () => {
    if (!companyName.trim()) {
      Alert.alert('Required Field', 'Please enter your Company Name.');
      return;
    }
    if (!email.trim()) {
      Alert.alert('Required Field', 'Please enter your Business Email.');
      return;
    }
    if (!password.trim()) {
      Alert.alert('Required Field', 'Please enter a Password.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Weak Password', 'Password must be at least 6 characters.');
      return;
    }

    registerMutation({
      variables: {
        input: {
          name: companyName.trim(),
          email: email.trim(),
          password: password.trim(),
          role: 'vendor',
          vendorVertical: selectedVertical,
          vendorCategory: 'General Seller',
          acceptedTerms: true,
        },
      },
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: Math.max(insets.top, 24) },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={24} color={COLORS.text} />
          </TouchableOpacity>

          <View style={styles.logoRow}>
            <View style={styles.logoBadge}>
              <Ionicons name="storefront-outline" size={28} color={COLORS.primary} />
            </View>
          </View>

          <Text style={styles.title}>Create a free business account</Text>
          <Text style={styles.subtitle}>
            Join thousands of sellers on {storeSettings?.storeName || 'Suaaka'}
          </Text>
        </View>

        {/* Card Form */}
        <View style={styles.card}>
          {/* Company Name */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Company Name *</Text>
            <View style={styles.inputBox}>
              <Ionicons name="person-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Acme Corp"
                placeholderTextColor={COLORS.textMuted}
                value={companyName}
                onChangeText={setCompanyName}
              />
            </View>
          </View>

          {/* Business Category / Vertical */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Business Category / Vertical *</Text>
            <TouchableOpacity
              style={styles.pickerBox}
              onPress={() => setShowCategoryModal(true)}
              activeOpacity={0.8}
            >
              <View style={styles.pickerLeft}>
                <Ionicons name="briefcase-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
                <Text style={styles.pickerText} numberOfLines={1}>
                  {currentCategory ? `${currentCategory.emoji} ${currentCategory.label}` : 'Select Category'}
                </Text>
              </View>
              <Ionicons name="chevron-down" size={18} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>

          {/* Business Email */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Business Email *</Text>
            <View style={styles.inputBox}>
              <Ionicons name="mail-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="contact@acme.com"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="email-address"
                autoCapitalize="none"
                value={email}
                onChangeText={setEmail}
              />
            </View>
          </View>

          {/* Password */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Password *</Text>
            <View style={styles.inputBox}>
              <Ionicons name="lock-closed-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="At least 6 characters"
                placeholderTextColor={COLORS.textMuted}
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
                <Ionicons
                  name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                  size={20}
                  color={COLORS.textSecondary}
                />
              </TouchableOpacity>
            </View>
          </View>

          {/* Terms & Conditions text */}
          <View style={styles.termsContainer}>
            <Text style={styles.termsText}>
              By continuing, you agree to {storeSettings?.storeName || 'Suaaka'}'s{' '}
              <Text
                style={styles.linkText}
                onPress={() => navigation.navigate('LegalPage', { slug: 'terms-and-conditions', title: 'Conditions of Use' })}
              >
                Conditions of Use
              </Text>
              {' '}and{' '}
              <Text
                style={styles.linkText}
                onPress={() => navigation.navigate('LegalPage', { slug: 'privacy-policy', title: 'Privacy Notice' })}
              >
                Privacy Notice
              </Text>.
            </Text>
          </View>

          {/* Create Business Account Button */}
          <TouchableOpacity
            style={[styles.submitBtn, loading && styles.disabledBtn]}
            onPress={handleCreateBusinessAccount}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color={COLORS.white} />
            ) : (
              <Text style={styles.submitBtnText}>Create Business Account</Text>
            )}
          </TouchableOpacity>

          {/* Divider & Footer */}
          <View style={styles.divider} />

          <View style={styles.footer}>
            <Text style={styles.footerText}>Already have an account? </Text>
            <TouchableOpacity onPress={() => navigation.navigate('Login')}>
              <Text style={styles.signInText}>Sign In</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Category Selection Modal */}
      <Modal
        visible={showCategoryModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowCategoryModal(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowCategoryModal(false)}
        >
          <View style={styles.modalContent} onStartShouldSetResponder={() => true}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Business Category</Text>
              <TouchableOpacity onPress={() => setShowCategoryModal(false)}>
                <Ionicons name="close" size={24} color={COLORS.text} />
              </TouchableOpacity>
            </View>

            {CATEGORY_OPTIONS.map((cat) => {
              const isSelected = cat.id === selectedVertical;
              return (
                <TouchableOpacity
                  key={cat.id}
                  style={[styles.modalOption, isSelected && styles.modalOptionSelected]}
                  onPress={() => {
                    setSelectedVertical(cat.id);
                    setShowCategoryModal(false);
                  }}
                >
                  <Text style={styles.modalOptionEmoji}>{cat.emoji}</Text>
                  <Text style={[styles.modalOptionText, isSelected && styles.modalOptionTextSelected]}>
                    {cat.label}
                  </Text>
                  {isSelected && <Ionicons name="checkmark-circle" size={20} color={COLORS.primary} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </TouchableOpacity>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scroll: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
    marginTop: 8,
  },
  backBtn: {
    alignSelf: 'flex-start',
    width: 40,
    height: 40,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  logoRow: {
    marginBottom: 12,
  },
  logoBadge: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#C7D2FE',
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 4,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusLg,
    padding: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.card,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 6,
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 12,
    height: 48,
  },
  pickerBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 12,
    height: 48,
  },
  pickerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 8,
  },
  pickerText: {
    fontSize: SIZES.sm,
    fontWeight: '600',
    color: COLORS.text,
    flex: 1,
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: SIZES.sm,
    color: COLORS.text,
  },
  eyeBtn: {
    padding: 6,
  },
  termsContainer: {
    marginBottom: 16,
  },
  termsText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    lineHeight: 18,
  },
  linkText: {
    color: '#2563EB',
    fontWeight: '600',
  },
  submitBtn: {
    backgroundColor: '#2563EB',
    borderRadius: SIZES.radiusMd,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.glow,
  },
  disabledBtn: {
    opacity: 0.7,
  },
  submitBtnText: {
    color: COLORS.white,
    fontSize: SIZES.md,
    fontWeight: '700',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
  },
  signInText: {
    fontSize: SIZES.sm,
    fontWeight: '700',
    color: '#2563EB',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    paddingBottom: 36,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    fontSize: SIZES.md,
    fontWeight: '700',
    color: COLORS.text,
  },
  modalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 12,
    borderRadius: SIZES.radiusMd,
    marginBottom: 8,
    backgroundColor: COLORS.background,
  },
  modalOptionSelected: {
    backgroundColor: '#EFF6FF',
    borderWidth: 1,
    borderColor: '#93C5FD',
  },
  modalOptionEmoji: {
    fontSize: 20,
    marginRight: 10,
  },
  modalOptionText: {
    flex: 1,
    fontSize: SIZES.sm,
    fontWeight: '600',
    color: COLORS.text,
  },
  modalOptionTextSelected: {
    color: '#1E40AF',
    fontWeight: '700',
  },
});
