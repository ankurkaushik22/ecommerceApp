import React, { useState, useRef, useMemo } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_ME, GET_NOTIFICATIONS, GET_STORE_SETTINGS, GET_BANNERS, GET_CATEGORIES } from '../../graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical } from '../../utils/cartHelpers';

const { width } = Dimensions.get('window');
const CARD_WIDTH = Math.floor((width - 32 - 16) / 3);



const ALL_GROCERY_FALLBACKS = [
  {
    _id: 'g-fizzy-1',
    name: 'Diet Coke Diets & Lights',
    slug: 'diet-coke-diets-lights',
    unitMeasure: '330 ml',
    optionsCount: 2,
    price: 50,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.8, count: 210 },
  },
  {
    _id: 'g-fizzy-2',
    name: 'Thums Up Soft Drink',
    slug: 'thums-up-soft-drink-750ml',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 39,
    comparePrice: 40,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.9, count: 340 },
  },
  {
    _id: 'g-fizzy-3',
    name: 'Thums Up Soft Drink',
    slug: 'thums-up-soft-drink-1ltr',
    unitMeasure: '1 ltr',
    optionsCount: null,
    price: 50,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.8, count: 180 },
  },
  {
    _id: 'g-fizzy-4',
    name: 'Sprite Lemon-Lime Soft Drink',
    slug: 'sprite-lemon-lime-soft-drink',
    unitMeasure: '750 ml',
    optionsCount: null,
    price: 36,
    comparePrice: 40,
    discountTag: '10% OFF on MRP',
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.7, count: 195 },
  },
  {
    _id: 'g-fizzy-5',
    name: "Limca Lemon 'N' Lime",
    slug: 'limca-lemon-n-lime',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 40,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: null,
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.6, count: 140 },
  },
  {
    _id: 'g-fizzy-6',
    name: 'Coca-Cola Soft Drink',
    slug: 'coca-cola-soft-drink',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 38,
    comparePrice: 40,
    discountTag: '5% OFF on MRP',
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.9, count: 510 },
  },
  {
    _id: 'g-pop-1',
    name: 'Organic Robusta Bananas',
    slug: 'organic-robusta-bananas',
    unitMeasure: '500g Pack',
    optionsCount: null,
    price: 39,
    comparePrice: 59,
    discountTag: '33% OFF on MRP',
    isVeg: true,
    tagBadge: 'Organic',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.8, count: 85 },
  },
  {
    _id: 'g-pop-2',
    name: 'Farm Fresh Pure Whole Cow Milk',
    slug: 'farm-fresh-pure-whole-cow-milk',
    unitMeasure: '1 Litre Pouch',
    optionsCount: null,
    price: 65,
    comparePrice: 75,
    discountTag: '13% OFF on MRP',
    isVeg: true,
    tagBadge: 'Fresh',
    deliveryMins: '10 mins',
    images: ['https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400'],
    category: { slug: 'dairy', name: 'Dairy, Bread & Eggs' },
    rating: { average: 4.9, count: 320 },
  },
  {
    _id: 'g-pop-3',
    name: 'Artisan Sourdough Country Loaf',
    slug: 'artisan-sourdough-country-loaf',
    unitMeasure: '400g Loaf',
    optionsCount: null,
    price: 99,
    comparePrice: 130,
    discountTag: '23% OFF on MRP',
    isVeg: true,
    tagBadge: 'Freshly Baked',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=400'],
    category: { slug: 'bakery', name: 'Bakery & Biscuits' },
    rating: { average: 4.7, count: 64 },
  },
  {
    _id: 'g-pop-4',
    name: 'Ready-to-eat Hass Avocados',
    slug: 'ready-to-eat-hass-avocados',
    unitMeasure: '2 pcs pack',
    optionsCount: null,
    price: 199,
    comparePrice: 249,
    discountTag: '20% OFF on MRP',
    isVeg: true,
    tagBadge: 'Imported',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=400'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.9, count: 128 },
  },
  {
    _id: 'g-pop-5',
    name: 'Hydroponic Fresh Baby Spinach',
    slug: 'hydroponic-fresh-baby-spinach-palak',
    unitMeasure: '250g Pack',
    optionsCount: null,
    price: 39,
    comparePrice: 55,
    discountTag: '29% OFF on MRP',
    isVeg: true,
    tagBadge: 'Fresh',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.7, count: 140 },
  },
  {
    _id: 'g-pop-6',
    name: 'Tender Fresh Chicken Breast (Boneless)',
    slug: 'tender-fresh-chicken-breast-boneless',
    unitMeasure: '500g Pack',
    optionsCount: null,
    price: 189,
    comparePrice: 220,
    discountTag: '14% OFF on MRP',
    isVeg: false,
    tagBadge: 'Antibiotic Free',
    deliveryMins: '20 mins',
    images: ['https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400'],
    category: { slug: 'meat', name: 'Chicken, Meat & Fish' },
    rating: { average: 4.9, count: 190 },
  },
];

export default function GroceryHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const scrollViewRef = useRef(null);
  const statusBarHeight = StatusBar.currentHeight || 0;
  const topPadding = Platform.OS === 'web' ? 16 : Math.max(insets.top, statusBarHeight, 24) + 6;

  const { user, isAuthenticated } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopTab, setSelectedTopTab] = useState('all');

  const items = useCartStore((s) => s.items || []);
  const setCart = useCartStore((s) => s.setCart);
  const addItem = useCartStore((s) => s.addItem);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const { toggleWishlist, isInWishlist } = useWishlistStore();

  const groceryCartItems = filterItemsByVertical(items || [], 'grocery');
  const totalGroceryItems = groceryCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = groceryCartItems.reduce(
    (sum, i) => sum + (i?.price || i?.product?.price || 0) * (i?.quantity || 0),
    0
  );

  const { data: meData } = useQuery(GET_ME, { skip: !isAuthenticated });

  const { data: productsData } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vertical: 'grocery' },
      pagination: { page: 1, limit: 50 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: bannerData } = useQuery(GET_BANNERS, {
    variables: { platform: 'mobile', vertical: 'grocery' },
    fetchPolicy: 'cache-and-network',
  });

  const groceryBanners = useMemo(() => {
    const fetched = bannerData?.getBanners || [];
    const active = fetched.filter(
      (b) => b.isActive !== false && (b.vertical === 'grocery' || b.vertical === 'all' || !b.vertical)
    );
    if (active.length > 0) return active;
    return [
      {
        _id: 'g-hero-fb-1',
        title: 'Diwali Offer',
        subtitle: 'Brighten your home with great deals on fresh groceries',
        tag: 'FESTIVE SALE',
        image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800',
        bgHex: '#059669',
      },
    ];
  }, [bannerData]);

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(50);
    },
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      setCart(res.updateCartItem);
    },
  });

  const serverProducts = productsData?.getProducts?.products || [];

  // Combine server products + fallbacks ensuring all items are displayed
  const allProducts = useMemo(() => {
    if (!serverProducts || serverProducts.length === 0) {
      return ALL_GROCERY_FALLBACKS;
    }
    const combined = [...serverProducts];
    ALL_GROCERY_FALLBACKS.forEach((fb) => {
      if (!combined.some((p) => (p.name || '').toLowerCase() === fb.name.toLowerCase())) {
        combined.push(fb);
      }
    });
    return combined;
  }, [serverProducts]);

  // Filter products based on search or selected tab
  const filteredProducts = useMemo(() => {
    return allProducts.filter((item) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const mName = (item.name || '').toLowerCase().includes(q);
        const mCat = (item.category?.name || '').toLowerCase().includes(q);
        const mUnit = (item.unitMeasure || '').toLowerCase().includes(q);
        if (!mName && !mCat && !mUnit) return false;
      }

      if (selectedTopTab !== 'all') {
        const cName = (item.category?.name || '').toLowerCase();
        const cSlug = (item.category?.slug || item.category?._id || '').toLowerCase();
        const target = selectedTopTab.toLowerCase();
        const matches = cName.includes(target) || cSlug.includes(target) || (item.name || '').toLowerCase().includes(target);
        if (!matches) return false;
      }
      return true;
    });
  }, [allProducts, searchQuery, selectedTopTab]);

  const currentUser = meData?.me || user;
  const currentAddress = currentUser?.addresses?.find((a) => a.isDefault) || currentUser?.addresses?.[0] || {
    addressLine1: '123 Maple St',
  };

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('grocery')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🥦</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Grocery Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting grocery orders. Please check back later!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const { data: catData } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'grocery' },
    fetchPolicy: 'cache-and-network',
  });

  const dbCategories = catData?.getCategories || [];

  const topTabs = useMemo(() => {
    const defaultAll = { id: 'all', name: 'All', icon: 'apps-outline' };
    if (!dbCategories || dbCategories.length === 0) return [defaultAll];
    return [
      defaultAll,
      ...dbCategories.map((cat) => ({
        id: cat.slug || cat._id,
        name: cat.name,
        icon: cat.icon || 'basket-outline',
        slug: cat.slug || cat._id,
      })),
    ];
  }, [dbCategories]);

  const categorySections = useMemo(() => {
    if (!dbCategories || dbCategories.length === 0) return [];

    const hasParentChild = dbCategories.some((c) => c.children && c.children.length > 0);

    if (hasParentChild) {
      return dbCategories.map((parent) => ({
        id: parent._id,
        title: parent.name,
        items: (parent.children && parent.children.length > 0) ? parent.children : [parent],
      }));
    }

    return [
      {
        id: 'grocery-categories',
        title: 'Explore Categories',
        items: dbCategories,
      },
    ];
  }, [dbCategories]);

  const renderCategoryTile = (cat) => (
    <TouchableOpacity
      key={cat._id || cat.id}
      style={styles.gridCategoryCard}
      activeOpacity={0.8}
      onPress={() =>
        navigation.navigate('GroceryCategory', {
          title: cat.name,
          categorySlug: cat.slug || cat.categorySlug || cat._id,
        })
      }
    >
      <View style={styles.gridCategoryBg}>
        <Image
          source={{ uri: cat.image || cat.icon || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=300' }}
          style={styles.gridCategoryImg}
          resizeMode="cover"
        />
      </View>
      <Text style={styles.gridCategoryLabel} numberOfLines={2}>
        {cat.name}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Top Header without 'SUAAKA FRESH' text */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <TouchableOpacity
          style={styles.addressRow}
          onPress={() => {
            if (!isAuthenticated) navigation.navigate('Login', { redirect: 'Addresses' });
            else navigation.navigate('Addresses');
          }}
          activeOpacity={0.8}
        >
          <Ionicons name="location-sharp" size={18} color="#059669" />
          <View style={styles.addressTextWrap}>
            <Text style={styles.deliverToLabel}>Deliver to:</Text>
            <Text style={styles.addressText} numberOfLines={1}>
              {currentAddress.label || 'Home'} - {currentAddress.addressLine1 || 'Sector 45'}, {currentAddress.city || 'Gurugram'}
            </Text>
          </View>
        </TouchableOpacity>
      </View>

      <ScrollView ref={scrollViewRef} showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Search Bar with Mic Icon */}
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={20} color="#64748B" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search for atta, dal, coke and more..."
            placeholderTextColor="#94A3B8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            onSubmitEditing={() =>
              navigation.navigate('GroceryCategory', {
                title: searchQuery || 'Search Groceries',
                search: searchQuery,
              })
            }
          />
          <TouchableOpacity activeOpacity={0.7} onPress={() => {}}>
            <Ionicons name="mic-outline" size={20} color="#64748B" />
          </TouchableOpacity>
        </View>

        {/* Dynamic Banner Carousel (Same style as Shopping in customer mobile app) */}
        {groceryBanners.length > 0 && (
          <View style={styles.carouselSection}>
            <ScrollView
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onScroll={(e) => {
                const slide = Math.round(e.nativeEvent.contentOffset.x / (width - 32));
                if (slide !== activeBannerIdx) setActiveBannerIdx(slide);
              }}
              scrollEventThrottle={16}
            >
              {groceryBanners.map((banner, bIdx) => (
                <TouchableOpacity
                  key={banner._id || banner.id || bIdx}
                  style={styles.bannerCard}
                  activeOpacity={0.92}
                  onPress={() => navigation.navigate('GroceryCategory', { isDeals: true })}
                >
                  {banner.image ? (
                    <Image
                      source={{ uri: banner.image }}
                      style={styles.bannerFullImg}
                      resizeMode="cover"
                    />
                  ) : (
                    <View style={[styles.bannerFallback, { backgroundColor: banner.bgHex || '#059669' }]}>
                      {banner.tag ? (
                        <View style={styles.bannerTag}>
                          <Text style={styles.bannerTagText}>{banner.tag}</Text>
                        </View>
                      ) : null}
                      <Text style={styles.bannerTitle}>{banner.title}</Text>
                      <Text style={styles.bannerSub}>{banner.subtitle}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Carousel Dots */}
            {groceryBanners.length > 1 && (
              <View style={styles.dotsRow}>
                {groceryBanners.map((_, i) => (
                  <View
                    key={i}
                    style={[styles.dot, activeBannerIdx === i && styles.dotActive]}
                  />
                ))}
              </View>
            )}
          </View>
        )}

        {/* Top Horizontal Category Tabs */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.topTabsScroll}
        >
          {topTabs.map((tab) => {
            const isSelected = selectedTopTab === tab.id;
            return (
              <TouchableOpacity
                key={tab.id}
                style={styles.topTabBtn}
                activeOpacity={0.8}
                onPress={() => setSelectedTopTab(tab.id)}
              >
                <View style={styles.topTabIconWrap}>
                  <Ionicons name={tab.icon || 'basket-outline'} size={20} color={isSelected ? '#0F172A' : '#64748B'} />
                  {tab.badge && (
                    <View style={styles.tabBadge}>
                      <Text style={styles.tabBadgeText}>{tab.badge}</Text>
                    </View>
                  )}
                </View>
                <Text style={[styles.topTabText, isSelected && styles.topTabTextActive]}>{tab.name}</Text>
                {isSelected && <View style={styles.activeTabLine} />}
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Dynamic Category Sections from Admin DB */}
        {categorySections.map((sec) => (
          <View key={sec.id} style={styles.sectionContainer}>
            <Text style={styles.sectionTitle}>{sec.title}</Text>
            <View style={styles.fourColGrid}>
              {sec.items.map(renderCategoryTile)}
            </View>
          </View>
        ))}

        {/* Products Grid: Showing All Grocery Products */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>
              {selectedTopTab === 'all'
                ? 'All Grocery Products'
                : `${topTabs.find((t) => t.id === selectedTopTab)?.name || 'Grocery'} Products`}
            </Text>
            <Text style={styles.itemCountBadge}>{filteredProducts.length} items</Text>
          </View>

          <View style={styles.threeColGrid}>
            {filteredProducts.map((item) => {
              const isFav = isInWishlist(item._id);
              const cartItem = items.find(
                (i) => (i.product?._id || i.productId || i._id) === item._id
              );
              const qty = cartItem ? cartItem.quantity : 0;
              const hasOptions = item.optionsCount || (item.variants && item.variants.length > 0);

              return (
                <TouchableOpacity
                  key={item._id}
                  style={styles.zomatoCard}
                  activeOpacity={0.92}
                  onPress={() =>
                    navigation.navigate('GroceryProductDetail', {
                      slug: item.slug || item._id,
                      product: item,
                    })
                  }
                >
                  {/* Heart Button */}
                  <TouchableOpacity
                    style={styles.cardHeartBtn}
                    onPress={() => toggleWishlist(item)}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Ionicons
                      name={isFav ? 'heart' : 'heart-outline'}
                      size={16}
                      color={isFav ? '#EF4444' : '#94A3B8'}
                    />
                  </TouchableOpacity>

                  {/* Product Image Wrapper */}
                  <View style={styles.cardImgWrap}>
                    <Image
                      source={{ uri: item.images?.[0] || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300' }}
                      style={styles.cardImg}
                      resizeMode="contain"
                    />
                    {/* Veg Indicator Badge */}
                    <View style={styles.vegSquare}>
                      <View style={[styles.vegDot, { backgroundColor: item.isVeg === false ? '#DC2626' : '#16A34A' }]} />
                    </View>

                    {/* Pagination Dots Indicator */}
                    <View style={styles.cardDotsRow}>
                      <View style={[styles.cardDot, styles.cardDotActive]} />
                      <View style={styles.cardDot} />
                      <View style={styles.cardDot} />
                    </View>
                  </View>

                  {/* Unit Measure */}
                  <Text style={styles.cardUnitText}>{item.unitMeasure || '1 unit'}</Text>

                  {/* ADD Button / Stepper */}
                  {qty === 0 ? (
                    <TouchableOpacity
                      style={styles.zomatoAddBtn}
                      activeOpacity={0.8}
                      onPress={() => {
                        addItem({ ...item, vertical: 'grocery' });
                        if (isAuthenticated) {
                          addToCart({
                            variables: {
                              input: { productId: item._id, quantity: 1 },
                            },
                          });
                        }
                      }}
                    >
                      <Text style={styles.zomatoAddBtnText}>ADD</Text>
                      {hasOptions && (
                        <Text style={styles.zomatoOptionsText}>
                          {item.optionsCount || item.variants?.length || 2} options
                        </Text>
                      )}
                    </TouchableOpacity>
                  ) : (
                    <View style={styles.zomatoStepperRow}>
                      <TouchableOpacity
                        style={styles.zomatoStepBtn}
                        onPress={() => {
                          updateQuantity(item._id, qty - 1);
                          if (isAuthenticated && cartItem?._id && !cartItem._id.startsWith('temp-')) {
                            updateCartItem({
                              variables: { itemId: cartItem._id, quantity: qty - 1 },
                            });
                          }
                        }}
                      >
                        <Ionicons name="remove" size={14} color="#FFF" />
                      </TouchableOpacity>
                      <Text style={styles.zomatoQtyText}>{qty}</Text>
                      <TouchableOpacity
                        style={styles.zomatoStepBtn}
                        onPress={() => {
                          updateQuantity(item._id, qty + 1);
                          if (isAuthenticated) {
                            addToCart({
                              variables: {
                                input: { productId: item._id, quantity: 1 },
                              },
                            });
                          }
                        }}
                      >
                        <Ionicons name="add" size={14} color="#FFF" />
                      </TouchableOpacity>
                    </View>
                  )}

                  {/* Price & Discount */}
                  <View style={styles.priceRow}>
                    <Text style={styles.cardPrice}>₹{Number(item.price).toLocaleString('en-IN')}</Text>
                    {item.comparePrice ? (
                      <Text style={styles.cardComparePrice}>₹{item.comparePrice}</Text>
                    ) : null}
                  </View>

                  {item.discountTag ? (
                    <Text style={styles.cardDiscountBadge}>{item.discountTag}</Text>
                  ) : null}

                  {/* Product Title */}
                  <Text style={styles.cardTitle} numberOfLines={2}>
                    {item.name}
                  </Text>

                  {/* Chilled / Tag Badge */}
                  {item.tagBadge ? (
                    <View style={styles.chilledPill}>
                      <Ionicons name="pricetag-outline" size={10} color="#2563EB" />
                      <Text style={styles.chilledPillText}>{item.tagBadge}</Text>
                    </View>
                  ) : null}

                  {/* Delivery Speed Badge */}
                  <View style={styles.deliveryRow}>
                    <Ionicons name="time-outline" size={11} color="#64748B" />
                    <Text style={styles.deliveryText}>{item.deliveryMins || '14 mins'}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>

      {/* Floating Bottom Cart Bar */}
      {totalGroceryItems > 0 && (
        <View style={[styles.floatingCart, { bottom: insets.bottom + 12 }]}>
          <View>
            <Text style={styles.floatingCartCount}>
              {totalGroceryItems} {totalGroceryItems === 1 ? 'ITEM' : 'ITEMS'} ADDED
            </Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'grocery' })}
            style={styles.viewCartButton}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  addressTextWrap: {
    flexShrink: 1,
  },
  deliverToLabel: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '600',
  },
  addressText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F172A',
  },
  scroll: {
    paddingBottom: 80,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#0F172A',
    fontWeight: '500',
  },
  topTabsScroll: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 8,
    gap: 20,
  },
  topTabBtn: {
    alignItems: 'center',
    position: 'relative',
    paddingBottom: 6,
  },
  topTabIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
    position: 'relative',
  },
  tabBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 1,
  },
  tabBadgeText: {
    color: '#FFF',
    fontSize: 8,
    fontWeight: 'bold',
  },
  topTabText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
  },
  topTabTextActive: {
    color: '#0F172A',
    fontWeight: '900',
  },
  activeTabLine: {
    position: 'absolute',
    bottom: 0,
    width: 24,
    height: 3,
    backgroundColor: '#0F172A',
    borderRadius: 2,
  },
  backToTopContainer: {
    alignItems: 'center',
    marginVertical: 10,
  },
  backToTopPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 6,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  backToTopText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#0F172A',
  },
  sectionContainer: {
    marginTop: 18,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '900',
    color: '#0F172A',
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  itemCountBadge: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  fourColGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    justifyContent: 'flex-start',
  },
  gridCategoryCard: {
    width: (width - 32 - 24) / 4,
    alignItems: 'center',
    marginBottom: 12,
  },
  gridCategoryBg: {
    width: '100%',
    aspectRatio: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    ...SHADOWS.small,
  },
  gridCategoryImg: {
    width: '100%',
    height: '100%',
    borderRadius: 15,
  },
  gridCategoryLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: '#0F172A',
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 14,
  },
  threeColGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  zomatoCard: {
    width: CARD_WIDTH,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 6,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    marginBottom: 12,
    position: 'relative',
    ...SHADOWS.small,
  },
  cardHeartBtn: {
    position: 'absolute',
    top: 6,
    right: 6,
    zIndex: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardImgWrap: {
    width: '100%',
    height: 90,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    position: 'relative',
    marginBottom: 4,
  },
  cardImg: {
    width: '80%',
    height: '80%',
  },
  vegSquare: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 12,
    height: 12,
    borderWidth: 1,
    borderColor: '#16A34A',
    borderRadius: 3,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
  vegDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#16A34A',
  },
  cardDotsRow: {
    position: 'absolute',
    bottom: 4,
    left: 6,
    flexDirection: 'row',
    gap: 2,
  },
  cardDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#CBD5E1',
  },
  cardDotActive: {
    backgroundColor: '#64748B',
  },
  cardUnitText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#64748B',
    marginBottom: 4,
  },
  zomatoAddBtn: {
    borderWidth: 1,
    borderColor: '#16A34A',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingVertical: 5,
    alignItems: 'center',
    marginBottom: 6,
  },
  zomatoAddBtnText: {
    color: '#16A34A',
    fontSize: 12,
    fontWeight: '900',
  },
  zomatoOptionsText: {
    fontSize: 8,
    fontWeight: '600',
    color: '#64748B',
    marginTop: 1,
  },
  zomatoStepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#16A34A',
    borderRadius: 8,
    paddingHorizontal: 6,
    paddingVertical: 4,
    marginBottom: 6,
  },
  zomatoStepBtn: {
    width: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zomatoQtyText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '900',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    marginTop: 2,
  },
  cardPrice: {
    fontSize: 13,
    fontWeight: '900',
    color: '#0F172A',
  },
  cardComparePrice: {
    fontSize: 10,
    color: '#94A3B8',
    textDecorationLine: 'line-through',
  },
  cardDiscountBadge: {
    fontSize: 9,
    fontWeight: '800',
    color: '#2563EB',
    marginTop: 1,
  },
  cardTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: '#1E293B',
    marginTop: 3,
    lineHeight: 14,
    height: 28,
  },
  chilledPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 6,
    alignSelf: 'flex-start',
    marginTop: 4,
  },
  chilledPillText: {
    fontSize: 9,
    fontWeight: '800',
    color: '#2563EB',
  },
  deliveryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginTop: 4,
  },
  deliveryText: {
    fontSize: 9,
    fontWeight: '600',
    color: '#64748B',
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#059669',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#D1FAE5',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  carouselSection: {
    paddingHorizontal: 16,
    marginTop: 14,
  },
  bannerCard: {
    width: width - 32,
    height: (width - 32) * 0.38,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: '#F1F5F9',
    position: 'relative',
    ...SHADOWS.medium,
  },
  bannerFullImg: {
    width: '100%',
    height: '100%',
  },
  bannerFallback: {
    width: '100%',
    height: '100%',
    padding: 16,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  bannerTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  bannerTagText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '800',
  },
  bannerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#FFF',
  },
  bannerSub: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
  },
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    marginTop: 10,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#CBD5E1',
  },
  dotActive: {
    width: 18,
    backgroundColor: '#059669',
  },
});
