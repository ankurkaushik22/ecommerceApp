import { gql } from '@apollo/client';

export const LOGIN = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        role
        avatar
        vendorCategory
        vendorVertical
        vendorVerticals
      }
    }
  }
`;

export const LOGOUT = gql`
  mutation Logout {
    logout
  }
`;

export const CREATE_PRODUCT = gql`
  mutation CreateProduct($input: ProductInput!) {
    createProduct(input: $input) {
      _id name slug price comparePrice stock sku vertical isActive approvalStatus commissionType commissionValue serviceDuration warranty includedFeatures specifications { key value } highlights
      variants { name options { label price stock sku thumbnail thumbnails } }
      category { _id name slug vertical parent { _id name slug vertical } }
      subcategory { _id name slug vertical }
      taxSetting { _id name rate }
    }
  }
`;

export const UPDATE_PRODUCT = gql`
  mutation UpdateProduct($id: ID!, $input: ProductInput!) {
    updateProduct(id: $id, input: $input) {
      _id name slug price comparePrice stock sku vertical isActive approvalStatus commissionType commissionValue serviceDuration warranty includedFeatures specifications { key value } highlights
      variants { name options { label price stock sku thumbnail thumbnails } }
      category { _id name slug vertical parent { _id name slug vertical } }
      subcategory { _id name slug vertical }
      taxSetting { _id name rate }
    }
  }
`;

export const DELETE_PRODUCT = gql`
  mutation DeleteProduct($id: ID!) {
    deleteProduct(id: $id)
  }
`;

export const TOGGLE_PRODUCT_STATUS = gql`
  mutation ToggleProductStatus($id: ID!) {
    toggleProductStatus(id: $id) { _id isActive }
  }
`;

export const UPDATE_PRODUCT_APPROVAL = gql`
  mutation UpdateProductApproval($id: ID!, $status: String!, $reason: String, $commissionType: String, $commissionValue: Float) {
    updateProductApproval(id: $id, status: $status, reason: $reason, commissionType: $commissionType, commissionValue: $commissionValue) {
      _id approvalStatus isActive commissionType commissionValue
    }
  }
`;

export const CREATE_CATEGORY = gql`
  mutation CreateCategory($input: CategoryInput!) {
    createCategory(input: $input) {
      _id name slug icon image isActive
      parent { _id name }
    }
  }
`;

export const UPDATE_CATEGORY = gql`
  mutation UpdateCategory($id: ID!, $input: CategoryInput!) {
    updateCategory(id: $id, input: $input) {
      _id name slug icon image isActive
      parent { _id name }
    }
  }
`;

export const DELETE_CATEGORY = gql`
  mutation DeleteCategory($id: ID!) {
    deleteCategory(id: $id)
  }
`;

export const UPDATE_ORDER_STATUS = gql`
  mutation UpdateOrderStatus($orderId: ID!, $status: String!, $message: String, $location: String, $deliverySlot: String) {
    updateOrderStatus(orderId: $orderId, status: $status, message: $message, location: $location, deliverySlot: $deliverySlot) {
      _id status vendorNotes deliverySlot trackingUpdates { status message timestamp location }
    }
  }
`;

export const UPDATE_ORDER_DELIVERY_SLOT = gql`
  mutation UpdateOrderDeliverySlot($orderId: ID!, $deliverySlot: String!) {
    updateOrderDeliverySlot(orderId: $orderId, deliverySlot: $deliverySlot) {
      _id deliverySlot trackingUpdates { status message timestamp location }
    }
  }
`;

export const ADD_ORDER_COMMENT = gql`
  mutation AddOrderComment($orderId: ID!, $message: String!) {
    addOrderComment(orderId: $orderId, message: $message) {
      _id status vendorNotes trackingUpdates { status message timestamp location }
    }
  }
`;

export const ASSIGN_DELIVERY_BOY = gql`
  mutation AssignDeliveryBoy($orderId: ID!, $deliveryBoyId: ID!) {
    assignDeliveryBoy(orderId: $orderId, deliveryBoyId: $deliveryBoyId) {
      _id
      deliveryBoy { _id name phone }
      deliveryAgent { _id name phone }
    }
  }
`;

export const UPDATE_USER_STATUS = gql`
  mutation UpdateUserStatus($userId: ID!, $isActive: Boolean!) {
    updateUserStatus(userId: $userId, isActive: $isActive) { _id isActive }
  }
`;

export const UPDATE_USER_ROLE = gql`
  mutation UpdateUserRole($userId: ID!, $role: String!) {
    updateUserRole(userId: $userId, role: $role) { _id role }
  }
`;

export const CREATE_COUPON = gql`
  mutation CreateCoupon($input: CouponInput!) {
    createCoupon(input: $input) {
      _id code type value description minOrderAmount maxDiscountAmount
      usageLimit usedCount isActive startsAt expiresAt createdAt
    }
  }
`;

export const UPDATE_COUPON = gql`
  mutation UpdateCoupon($id: ID!, $input: CouponInput!) {
    updateCoupon(id: $id, input: $input) {
      _id code type value description minOrderAmount maxDiscountAmount
      usageLimit usedCount isActive startsAt expiresAt createdAt
    }
  }
`;

export const DELETE_COUPON = gql`
  mutation DeleteCoupon($id: ID!) {
    deleteCoupon(id: $id)
  }
`;

export const UPDATE_PROFILE = gql`
  mutation UpdateProfile($name: String, $phone: String, $avatar: String) {
    updateProfile(name: $name, phone: $phone, avatar: $avatar) {
      _id name email phone avatar role
    }
  }
`;

export const CHANGE_PASSWORD = gql`
  mutation ChangePassword($currentPassword: String!, $newPassword: String!) {
    changePassword(currentPassword: $currentPassword, newPassword: $newPassword)
  }
`;

export const CREATE_USER = gql`
  mutation CreateUser($input: CreateUserInput!) {
    createUser(input: $input) {
      _id name email role phone isActive isVerified vendorCategory vendorVertical vendorVerticals commissionRate createdAt
    }
  }
`;

export const UPDATE_USER = gql`
  mutation UpdateUser($id: ID!, $input: UpdateUserInput!) {
    updateUser(id: $id, input: $input) {
      _id name email role phone isActive isVerified vendorCategory vendorVertical vendorVerticals commissionRate
    }
  }
`;

export const DELETE_USER = gql`
  mutation DeleteUser($id: ID!) {
    deleteUser(id: $id)
  }
`;

export const SAVE_ROLE_PERMISSIONS = gql`
  mutation SaveRolePermissions($input: RolePermissionInput!) {
    saveRolePermissions(input: $input) {
      _id roleName displayName description modules isSystem
    }
  }
`;

export const DELETE_ROLE = gql`
  mutation DeleteRole($id: ID!) {
    deleteRole(id: $id)
  }
`;

export const CREATE_DELIVERY_OPTION = gql`
  mutation CreateDeliveryOption($input: DeliveryOptionInput!) {
    createDeliveryOption(input: $input) {
      _id name description estimatedDays price minOrderForFree vertical isDefault isActive sortOrder
    }
  }
`;

export const UPDATE_DELIVERY_OPTION = gql`
  mutation UpdateDeliveryOption($id: ID!, $input: DeliveryOptionInput!) {
    updateDeliveryOption(id: $id, input: $input) {
      _id name description estimatedDays price minOrderForFree vertical isDefault isActive sortOrder
    }
  }
`;

export const DELETE_DELIVERY_OPTION = gql`
  mutation DeleteDeliveryOption($id: ID!) {
    deleteDeliveryOption(id: $id)
  }
`;

export const CREATE_TAX_SETTING = gql`
  mutation CreateTaxSetting($input: TaxSettingInput!) {
    createTaxSetting(input: $input) {
      _id name rate cgst sgst igst hsnCode isDefault isActive description
    }
  }
`;

export const UPDATE_TAX_SETTING = gql`
  mutation UpdateTaxSetting($id: ID!, $input: TaxSettingInput!) {
    updateTaxSetting(id: $id, input: $input) {
      _id name rate cgst sgst igst hsnCode isDefault isActive description
    }
  }
`;

export const DELETE_TAX_SETTING = gql`
  mutation DeleteTaxSetting($id: ID!) {
    deleteTaxSetting(id: $id)
  }
`;

export const REPLY_TO_REVIEW = gql`
  mutation ReplyToReview($reviewId: ID!, $comment: String!) {
    replyToReview(reviewId: $reviewId, comment: $comment) {
      _id targetType rating title comment
      reply { comment repliedAt repliedBy { _id name role avatar } }
    }
  }
`;

export const DELETE_REVIEW = gql`
  mutation DeleteReview($reviewId: ID!) {
    deleteReview(reviewId: $reviewId)
  }
`;

export const CREATE_BANNER = gql`
  mutation CreateBanner($input: BannerInput!) {
    createBanner(input: $input) {
      _id title subtitle image isActive platform vertical order
    }
  }
`;

export const UPDATE_BANNER = gql`
  mutation UpdateBanner($id: ID!, $input: BannerInput!) {
    updateBanner(id: $id, input: $input) {
      _id title subtitle image isActive platform vertical order
    }
  }
`;

export const DELETE_BANNER = gql`
  mutation DeleteBanner($id: ID!) {
    deleteBanner(id: $id)
  }
`;

export const UPDATE_RETURN_STATUS = gql`
  mutation UpdateReturnStatus($orderId: ID!, $status: String!) {
    updateReturnStatus(orderId: $orderId, status: $status) {
      _id returnStatus returnReason
    }
  }
`;

export const UPDATE_STORE_SETTINGS = gql`
  mutation UpdateStoreSettings($storeName: String, $logoUrl: String, $faviconUrl: String, $appIconUrl: String, $disabledVerticals: [String], $serviceBookingMode: String, $serviceContactPhone: String, $paymentMode: String, $latestCustomerVersion: String, $customerApkUrl: String, $latestDeliveryVersion: String, $deliveryApkUrl: String, $forceAppUpdate: Boolean, $websiteDisplayMode: String, $customerPlayStoreUrl: String, $customerIosUrl: String) {
    updateStoreSettings(storeName: $storeName, logoUrl: $logoUrl, faviconUrl: $faviconUrl, appIconUrl: $appIconUrl, disabledVerticals: $disabledVerticals, serviceBookingMode: $serviceBookingMode, serviceContactPhone: $serviceContactPhone, paymentMode: $paymentMode, latestCustomerVersion: $latestCustomerVersion, customerApkUrl: $customerApkUrl, latestDeliveryVersion: $latestDeliveryVersion, deliveryApkUrl: $deliveryApkUrl, forceAppUpdate: $forceAppUpdate, websiteDisplayMode: $websiteDisplayMode, customerPlayStoreUrl: $customerPlayStoreUrl, customerIosUrl: $customerIosUrl) {
      _id
      storeName
      logoUrl
      faviconUrl
      appIconUrl
      disabledVerticals
      serviceBookingMode
      serviceContactPhone
      paymentMode
      latestCustomerVersion
      customerApkUrl
      latestDeliveryVersion
      deliveryApkUrl
      forceAppUpdate
      websiteDisplayMode
      customerPlayStoreUrl
      customerIosUrl
    }
  }
`;

export const UPDATE_STORE_SETTINGS_BASIC = gql`
  mutation UpdateStoreSettingsBasic($storeName: String, $logoUrl: String, $faviconUrl: String, $appIconUrl: String, $disabledVerticals: [String], $serviceBookingMode: String, $serviceContactPhone: String, $paymentMode: String, $latestCustomerVersion: String, $customerApkUrl: String, $latestDeliveryVersion: String, $deliveryApkUrl: String, $forceAppUpdate: Boolean) {
    updateStoreSettings(storeName: $storeName, logoUrl: $logoUrl, faviconUrl: $faviconUrl, appIconUrl: $appIconUrl, disabledVerticals: $disabledVerticals, serviceBookingMode: $serviceBookingMode, serviceContactPhone: $serviceContactPhone, paymentMode: $paymentMode, latestCustomerVersion: $latestCustomerVersion, customerApkUrl: $customerApkUrl, latestDeliveryVersion: $latestDeliveryVersion, deliveryApkUrl: $deliveryApkUrl, forceAppUpdate: $forceAppUpdate) {
      _id
      storeName
      logoUrl
      faviconUrl
      appIconUrl
      disabledVerticals
      serviceBookingMode
      serviceContactPhone
      paymentMode
      latestCustomerVersion
      customerApkUrl
      latestDeliveryVersion
      deliveryApkUrl
      forceAppUpdate
    }
  }
`;

export const SEND_LOGIN_OTP = gql`
  mutation SendLoginOTP($email: String!) {
    sendLoginOTP(email: $email) {
      success
      message
    }
  }
`;

export const LOGIN_WITH_OTP = gql`
  mutation LoginWithOTP($email: String!, $otp: String!) {
    loginWithOTP(email: $email, otp: $otp) {
      token
      refreshToken
      user { _id name email role avatar vendorCategory vendorVertical vendorVerticals }
    }
  }
`;

export const UPDATE_VENDOR_BANK_DETAILS = gql`
  mutation UpdateVendorBankDetails($input: BankDetailsInput!, $vendorId: ID) {
    updateVendorBankDetails(input: $input, vendorId: $vendorId) {
      accountHolderName
      accountNumber
      bankName
      ifscCode
      upiId
    }
  }
`;

export const REQUEST_VENDOR_PAYOUT = gql`
  mutation RequestVendorPayout($amount: Float) {
    requestVendorPayout(amount: $amount) {
      _id
      amount
      status
      createdAt
    }
  }
`;

export const UPDATE_PAYOUT_REQUEST_STATUS = gql`
  mutation UpdatePayoutRequestStatus($id: ID!, $status: String!, $adminNotes: String) {
    updatePayoutRequestStatus(id: $id, status: $status, adminNotes: $adminNotes) {
      _id
      status
      adminNotes
      processedAt
    }
  }
`;

export const ADMIN_RELEASE_VENDOR_PAYOUT = gql`
  mutation AdminReleaseVendorPayout($vendorId: ID!, $amount: Float, $adminNotes: String) {
    adminReleaseVendorPayout(vendorId: $vendorId, amount: $amount, adminNotes: $adminNotes) {
      _id
      amount
      status
      adminNotes
      processedAt
    }
  }
`;

export const UPDATE_DELIVERY_PARTNER_PAYOUT_CONFIG = gql`
  mutation UpdateDeliveryPartnerPayoutConfig(
    $userId: ID!
    $payoutType: String
    $perOrderRate: Float
    $monthlySalary: Float
    $dailyIncentive: Float
    $minOrdersForIncentive: Int
    $vehicleType: String
    $vehicleRegistrationNumber: String
    $vehicles: [VehicleInput]
  ) {
    updateDeliveryPartnerPayoutConfig(
      userId: $userId
      payoutType: $payoutType
      perOrderRate: $perOrderRate
      monthlySalary: $monthlySalary
      dailyIncentive: $dailyIncentive
      minOrdersForIncentive: $minOrdersForIncentive
      vehicleType: $vehicleType
      vehicleRegistrationNumber: $vehicleRegistrationNumber
      vehicles: $vehicles
    ) {
      _id
      name
      deliveryPayoutType
      deliveryPerOrderRate
      deliveryMonthlySalary
      deliveryDailyIncentive
      deliveryMinOrdersForIncentive
      vehicleType
      vehicleRegistrationNumber
      vehicles {
        _id
        vehicleType
        registrationNumber
        isPrimary
      }
    }
  }
`;

export const RECORD_DELIVERY_CASH_RECEIVED = gql`
  mutation RecordDeliveryCashReceived($userId: ID!, $amount: Float!, $notes: String) {
    recordDeliveryCashReceived(userId: $userId, amount: $amount, notes: $notes) {
      _id
      name
      submittedCash
      cashSubmissions {
        _id
        amount
        receivedBy
        notes
        createdAt
      }
    }
  }
`;

