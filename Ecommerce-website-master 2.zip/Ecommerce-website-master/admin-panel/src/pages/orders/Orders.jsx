import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { MagnifyingGlassIcon, EyeIcon, XMarkIcon, ChevronDownIcon, TruckIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_ORDERS, GET_DELIVERY_BOYS } from '../../graphql/queries.js';
import { UPDATE_ORDER_STATUS, UPDATE_ORDER_DELIVERY_SLOT, ASSIGN_DELIVERY_BOY, ADD_ORDER_COMMENT } from '../../graphql/mutations.js';
import clsx from 'clsx';
import useVerticalStore from '../../store/verticalStore.js';
import useAuthStore from '../../store/authStore.js';

const STATUS_TABS = ['all', 'placed', 'accepted', 'processing', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed', 'cancelled', 'refunded'];
const STATUS_COLORS = {
  placed: 'badge-warning', accepted: 'badge-info', processing: 'badge-info',
  ready_for_pickup: 'badge-info', picked_up: 'badge-info', out_for_delivery: 'badge-info',
  delivered: 'badge-success', completed: 'badge-success', cancelled: 'badge-danger', refunded: 'badge-danger',
};
const NEXT_STATUSES = {
  placed: ['accepted', 'cancelled'],
  accepted: ['processing', 'cancelled'],
  processing: ['ready_for_pickup', 'cancelled'],
  ready_for_pickup: ['picked_up', 'cancelled'],
  picked_up: ['out_for_delivery', 'cancelled'],
  out_for_delivery: ['delivered'],
  delivered: ['completed', 'refunded'],
};

const isShoppingOrder = (order) => {
  const v = (order?.vertical || '').toLowerCase();
  return !['food', 'grocery', 'quick_commerce', 'supermarket', 'pharmacy'].includes(v);
};

export const getAvailableDeliverySlots = () => {
  const now = new Date();
  const currentHour = now.getHours();

  const slots = [];

  // Immediate slots (only during daytime / working hours 7 AM to 10 PM)
  if (currentHour >= 7 && currentHour < 22) {
    slots.push('Within 30-45 mins');
    slots.push('Within 45-60 mins');
  }

  // Today's slots - ONLY include if current hour is BEFORE the start of the time window
  const todayWindows = [
    { label: 'Today: 9AM - 11AM', startHour: 9 },
    { label: 'Today: 11AM - 1PM', startHour: 11 },
    { label: 'Today: 1PM - 3PM', startHour: 13 },
    { label: 'Today: 3PM - 5PM', startHour: 15 },
    { label: 'Today: 5PM - 7PM', startHour: 17 },
    { label: 'Today: 7PM - 9PM', startHour: 19 },
  ];

  todayWindows.forEach((w) => {
    if (currentHour < w.startHour) {
      slots.push(w.label);
    }
  });

  // Tomorrow's slots (always valid)
  slots.push('Tomorrow: 9AM - 11AM');
  slots.push('Tomorrow: 11AM - 1PM');
  slots.push('Tomorrow: 3PM - 5PM');
  slots.push('Tomorrow: 5PM - 7PM');

  return slots;
};

const getOrderDisplayTotal = (order) => {
  if (typeof order?.total === 'number' && order.total > 0) return order.total;
  const sub = Number(order?.subtotal || 0);
  const disc = Number(order?.discount || 0);
  const ship = Number(order?.shippingCost || 0);
  const tax = Number(order?.tax || 0);
  const calc = Math.max(0, sub - disc + ship + tax);
  return Math.round(calc * 100) / 100;
};

export default function Orders() {
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: statusFilter === 'all' ? undefined : statusFilter,
      search: search || undefined,
      vertical: activeVertical === 'all' ? undefined : activeVertical,
      pagination: { page, limit: 20 },
    },
    fetchPolicy: 'cache-and-network',
    pollInterval: 10000,
  });

  const { data: deliveryData, loading: loadingDelivery } = useQuery(GET_DELIVERY_BOYS, {
    fetchPolicy: 'cache-and-network',
    pollInterval: 10000,
  });
  const deliveryBoys = deliveryData?.getDeliveryAgents || deliveryData?.getAllUsers || [];

  const [updateStatus, { loading: updating }] = useMutation(UPDATE_ORDER_STATUS, {
    onCompleted: (res) => {
      toast.success('Order status updated!');
      refetch();
      if (res?.updateOrderStatus && selectedOrder) {
        setSelectedOrder((prev) =>
          prev
            ? {
                ...prev,
                status: res.updateOrderStatus.status,
                vendorNotes: res.updateOrderStatus.vendorNotes || prev.vendorNotes,
                deliverySlot: res.updateOrderStatus.deliverySlot || prev.deliverySlot,
                trackingUpdates: res.updateOrderStatus.trackingUpdates || prev.trackingUpdates,
              }
            : null
        );
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateDeliverySlot, { loading: updatingSlot }] = useMutation(UPDATE_ORDER_DELIVERY_SLOT, {
    onCompleted: (res) => {
      toast.success('Delivery slot updated!');
      refetch();
      if (res?.updateOrderDeliverySlot && selectedOrder) {
        setSelectedOrder((prev) =>
          prev
            ? {
                ...prev,
                deliverySlot: res.updateOrderDeliverySlot.deliverySlot,
                trackingUpdates: res.updateOrderDeliverySlot.trackingUpdates || prev.trackingUpdates,
              }
            : null
        );
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const [assignDelivery, { loading: assigningDelivery }] = useMutation(ASSIGN_DELIVERY_BOY, {
    onCompleted: (res) => {
      toast.success('Delivery partner assigned!');
      refetch();
      if (res?.assignDeliveryBoy && selectedOrder) {
        setSelectedOrder((prev) =>
          prev
            ? {
                ...prev,
                deliveryBoy: res.assignDeliveryBoy.deliveryBoy || prev.deliveryBoy,
                deliveryAgent: res.assignDeliveryBoy.deliveryAgent || prev.deliveryAgent,
              }
            : null
        );
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const [addComment, { loading: commenting }] = useMutation(ADD_ORDER_COMMENT, {
    onCompleted: (res) => {
      toast.success('Comment added to order!');
      refetch();
      if (res?.addOrderComment && selectedOrder) {
        setSelectedOrder((prev) =>
          prev
            ? {
                ...prev,
                vendorNotes: res.addOrderComment.vendorNotes || prev.vendorNotes,
                trackingUpdates: res.addOrderComment.trackingUpdates || prev.trackingUpdates,
              }
            : null
        );
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const orders = (data?.getAllOrders?.orders || []).filter(Boolean);
  const total = data?.getAllOrders?.total || 0;
  const pages = data?.getAllOrders?.pages || 1;

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Orders</h2>
          <p className="text-sm text-dark-500">{total} orders total</p>
        </div>
        <div className="relative w-full sm:w-64">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search orders..."
            className="input-field pl-9"
          />
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {STATUS_TABS.map((s) => (
          <button
            key={s}
            onClick={() => { setStatusFilter(s); setPage(1); }}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-200 flex-shrink-0',
              statusFilter === s
                ? 'bg-primary-600 text-white shadow-sm'
                : 'bg-white text-dark-500 border border-dark-200 hover:border-primary-300 hover:text-primary-600'
            )}
          >
            {s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
          </button>
        ))}
      </div>

      {/* Orders Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Order</th>
                <th className="px-4 py-3 text-left">Vertical</th>
                <th className="px-4 py-3 text-left">Customer</th>
                <th className="px-4 py-3 text-left">Items</th>
                <th className="px-4 py-3 text-right">Total</th>
                <th className="px-4 py-3 text-center">Payment</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-left">Date</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(8)].map((_, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-dark-100 rounded animate-pulse" /></td>
                      ))}
                    </tr>
                  ))
                : orders.map((order) => (
                    <motion.tr
                      key={order._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/50 transition-colors cursor-pointer"
                      onClick={() => setSelectedOrder(order)}
                    >
                      <td className="px-4 py-3">
                        <span className="text-sm font-semibold text-primary-600">#{order?.orderNumber || '—'}</span>
                        {Boolean((order.notes || order.deliveryInstructions || order.tableOrNotes)?.replace(/\[Slot:\s*[^\]]+\]/gi, '').trim()) && (
                          <div
                            className="mt-1 flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 border border-amber-200/70 px-1.5 py-0.5 rounded max-w-[180px] truncate"
                            title={(order.notes || order.deliveryInstructions || order.tableOrNotes)?.replace(/\[Slot:\s*[^\]]+\]/gi, '').trim()}
                          >
                            <span>📝</span>
                            <span className="truncate">{(order.notes || order.deliveryInstructions || order.tableOrNotes)?.replace(/\[Slot:\s*[^\]]+\]/gi, '').trim()}</span>
                          </div>
                        )}
                        {Boolean(order.deliverySlot || (order.notes || order.deliveryInstructions)?.match(/\[Slot:\s*([^\]]+)\]/i)?.[1]) && (
                          <div
                            className="mt-1 flex items-center gap-1 text-[11px] font-medium text-blue-700 bg-blue-50 border border-blue-200/70 px-1.5 py-0.5 rounded max-w-[180px] truncate"
                            title={`Delivery Slot: ${order.deliverySlot || (order.notes || order.deliveryInstructions)?.match(/\[Slot:\s*([^\]]+)\]/i)?.[1]}`}
                          >
                            <span>⏰</span>
                            <span className="truncate">{order.deliverySlot || (order.notes || order.deliveryInstructions)?.match(/\[Slot:\s*([^\]]+)\]/i)?.[1]}</span>
                          </div>
                        )}
                      </td>
<td className="px-4 py-3">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          order.vertical === 'food'
                            ? 'bg-orange-100 text-orange-800'
                            : order.vertical === 'grocery'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.vertical === 'services'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {order.vertical === 'food' ? '🍔 Food' : order.vertical === 'grocery' ? '🥦 Grocery' : order.vertical === 'services' ? '🛠️ Service' : '🛍️ Retail'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <img src={order.customer?.avatar} alt="" className="w-7 h-7 rounded-full" />
                          <div>
                            <p className="text-xs font-medium text-dark-800">{order.customer?.name}</p>
                            <p className="text-xs text-dark-400">{order.customer?.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-500">{order.items?.length} item(s)</td>
                      <td className="px-4 py-3 text-right text-sm font-semibold text-dark-900 font-mono">₹{getOrderDisplayTotal(order).toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={clsx(
                          'text-xs px-2 py-0.5 rounded-full font-medium',
                          order.paymentMethod === 'stripe' ? 'bg-purple-100 text-purple-700' : 'bg-amber-100 text-amber-700'
                        )}>
                          {order.paymentMethod === 'stripe' ? '💳 Card' : '💵 COD'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={STATUS_COLORS[order.status] || 'badge-gray'}>
                          {order.status?.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-400">
                        {order.createdAt ? format(new Date(order.createdAt), 'MMM d, yyyy') : '—'}
                      </td>
                      <td className="px-4 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                        >
                          <EyeIcon className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  ))
              }
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div className="px-4 py-3 border-t border-dark-100 flex items-center justify-between">
            <p className="text-xs text-dark-400">Page {page} of {pages}</p>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 text-sm btn-secondary disabled:opacity-40">← Prev</button>
              <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages} className="px-3 py-1 text-sm btn-secondary disabled:opacity-40">Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <OrderDetailModal
            order={selectedOrder}
            deliveryBoys={deliveryBoys}
            loadingDelivery={loadingDelivery}
            assigningDelivery={assigningDelivery}
            onClose={() => setSelectedOrder(null)}
            onUpdateStatus={({ status, message, location, deliverySlot }) =>
              updateStatus({ variables: { orderId: selectedOrder._id, status, message, location, deliverySlot } })
            }
            onUpdateDeliverySlot={(deliverySlot) =>
              updateDeliverySlot({ variables: { orderId: selectedOrder._id, deliverySlot } })
            }
            onAssignDelivery={(deliveryBoyId) =>
              assignDelivery({ variables: { orderId: selectedOrder._id, deliveryBoyId } })
            }
            onAddComment={(message) =>
              addComment({ variables: { orderId: selectedOrder._id, message } })
            }
            updating={updating}
            updatingSlot={updatingSlot}
            commenting={commenting}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function OrderDetailModal({
  order,
  deliveryBoys,
  loadingDelivery,
  assigningDelivery,
  onClose,
  onUpdateStatus,
  onUpdateDeliverySlot,
  onAssignDelivery,
  onAddComment,
  updating,
  updatingSlot,
  commenting,
}) {
  const user = useAuthStore((s) => s.user);
  const isSuperAdmin = user?.role === 'superadmin';
  const [newStatus, setNewStatus] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [orderComment, setOrderComment] = useState('');
  const [selectedDelivery, setSelectedDelivery] = useState(
    order.deliveryAgent?._id || order.deliveryBoy?._id || ''
  );

  useEffect(() => {
    setSelectedDelivery(order.deliveryAgent?._id || order.deliveryBoy?._id || '');
  }, [order?.deliveryAgent?._id, order?.deliveryBoy?._id]);

  const rawInstructions = order.deliveryInstructions || order.notes || order.tableOrNotes || '';
  const slotMatch = rawInstructions.match(/\[Slot:\s*([^\]]+)\]/i);
  const effectiveDeliverySlot = order.deliverySlot || (slotMatch ? slotMatch[1].trim() : null);
  const customerInstructions = rawInstructions
    .replace(/\[Slot:\s*[^\]]+\]/gi, '')
    .trim();

  const isShopping = isShoppingOrder(order);

  const [customSlotText, setCustomSlotText] = useState(effectiveDeliverySlot || '');
  const [shoppingDate, setShoppingDate] = useState(
    new Date().toISOString().split('T')[0]
  );

  const rawNext = NEXT_STATUSES[order.status] || [];
  const nextStatuses = rawNext.filter((s) => s !== 'completed' || isSuperAdmin);

  useEffect(() => {
    const raw = NEXT_STATUSES[order?.status] || [];
    const filtered = raw.filter((s) => s !== 'completed' || isSuperAdmin);
    setNewStatus(filtered[0] || '');
    setStatusMessage('');
  }, [order?.status, isSuperAdmin]);

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
      >
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-dark-100 flex items-center justify-between z-10">
          <div>
            <h2 className="text-lg font-semibold text-dark-900">Order #{order?.orderNumber || '—'}</h2>
            <p className="text-xs text-dark-400">{order.createdAt ? format(new Date(order.createdAt), 'MMMM d, yyyy · h:mm a') : ''}</p>
          </div>
          <button onClick={onClose}><XMarkIcon className="w-5 h-5 text-dark-400" /></button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status + Payment + Delivery Option + Delivery Slot */}
          <div className="flex flex-wrap gap-4">
            <div className="card px-4 py-3 flex-1 min-w-[140px]">
              <p className="text-xs text-dark-400 mb-1">Order Status</p>
              <span className={clsx('text-sm font-semibold capitalize', STATUS_COLORS[order.status]?.replace('badge-', 'text-'))}>
                {order.status?.replace(/_/g, ' ')}
              </span>
            </div>
            <div className="card px-4 py-3 flex-1 min-w-[140px]">
              <p className="text-xs text-dark-400 mb-1">Payment</p>
              <p className="text-sm font-semibold text-dark-800 capitalize">
                {order.paymentMethod} · <span className={order.paymentStatus === 'paid' ? 'text-green-600' : 'text-amber-600'}>{order.paymentStatus}</span>
              </p>
            </div>
            <div className="card px-4 py-3 flex-1 min-w-[160px]">
              <p className="text-xs text-dark-400 mb-1">Delivery Speed / Option</p>
              <p className="text-sm font-semibold text-dark-800">
                {order.deliveryOption?.name || 'Standard Delivery'}
                {order.deliveryOption?.estimatedDays ? ` (${order.deliveryOption.estimatedDays})` : ''}
              </p>
            </div>
            <div className="card px-4 py-3 flex-1 min-w-[160px] bg-blue-50/50 border border-blue-100">
              <p className="text-xs text-blue-700 font-medium mb-1 flex items-center gap-1">
                <span>{isShopping ? '📅' : '⏰'}</span> {isShopping ? 'Delivery Date' : 'Delivery Slot'}
              </p>
              <p className="text-sm font-bold text-blue-950">
                {order.deliverySlot || effectiveDeliverySlot || (
                  <span className="text-dark-400 font-normal italic text-xs">Not assigned</span>
                )}
              </p>
            </div>
          </div>

          {/* Delivery / Customer Instructions */}
          {Boolean(customerInstructions) && (
            <div className="card p-4 bg-amber-50/80 border border-amber-200 rounded-xl space-y-1.5 shadow-sm">
              <div className="flex items-center gap-2">
                <span className="text-base">
                  {order.vertical === 'food' ? '🍳' : order.vertical === 'services' ? '🛠️' : '🚚'}
                </span>
                <h3 className="text-xs font-bold text-amber-900 uppercase tracking-wider">
                  {order.vertical === 'food'
                    ? 'Cooking & Delivery Instructions'
                    : order.vertical === 'services'
                    ? 'Service Instructions & Notes'
                    : 'Delivery Instructions'}
                </h3>
              </div>
              <p className="text-sm font-semibold text-amber-950 whitespace-pre-wrap pl-6">
                {customerInstructions}
              </p>
            </div>
          )}

          {/* Customer & Vendor Details */}
          {(() => {
            const vName =
              order.vendor?.name ||
              order.items?.[0]?.product?.restaurantName ||
              order.items?.[0]?.vendor?.name ||
              order.items?.[0]?.product?.vendor?.name ||
              null;
            const rName = order.items?.[0]?.product?.restaurantName || '';
            const vEmail = order.vendor?.email || order.items?.[0]?.vendor?.email || order.items?.[0]?.product?.vendor?.email || '';
            const vPhone = order.vendor?.phone || order.items?.[0]?.vendor?.phone || order.items?.[0]?.product?.vendor?.phone || '';

            return (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Customer */}
                <div className="card p-3 bg-dark-50/50 border border-dark-100 rounded-xl">
                  <h3 className="text-xs font-bold text-dark-500 uppercase tracking-wider mb-2">Customer Details</h3>
                  <div className="flex items-center gap-3">
                    <img src={order.customer?.avatar} alt="" className="w-9 h-9 rounded-full object-cover" />
                    <div>
                      <p className="text-sm font-semibold text-dark-800">{order.customer?.name || 'Guest'}</p>
                      <p className="text-xs text-dark-500">{[order.customer?.email, order.customer?.phone].filter(Boolean).join(' · ')}</p>
                    </div>
                  </div>
                </div>

                {/* Vendor / Restaurant */}
                <div className="card p-3 bg-primary-50/40 border border-primary-100 rounded-xl">
                  <h3 className="text-xs font-bold text-primary-800 uppercase tracking-wider mb-2 flex items-center gap-1">
                    <span>🏪</span> {order.vertical === 'food' ? 'Restaurant / Vendor' : 'Vendor / Seller'}
                  </h3>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-primary-600 text-white flex items-center justify-center font-bold text-sm">
                      {(vName || rName || 'V')[0].toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-dark-900">
                        {vName || rName || 'N/A'}
                      </p>
                      <p className="text-xs text-dark-500">
                        {[
                          rName && rName !== vName ? `Restaurant: ${rName}` : null,
                          vEmail,
                          vPhone
                        ].filter(Boolean).join(' · ') || 'Vendor details active'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Items */}
          <div>
            <h3 className="text-sm font-semibold text-dark-700 mb-3">Items ({order.items?.length})</h3>
            <div className="space-y-2">
              {order.items?.map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-dark-50 rounded-lg">
                  <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-dark-800 truncate">{item.name}</p>
                    {item.variantLabel && <p className="text-xs text-dark-400">{item.variantLabel}</p>}
                    {item.addons && item.addons.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {item.addons.map((addon, aIdx) => (
                          <span key={aIdx} className="text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/80 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                            <span>{addon.icon || '➕'}</span>
                            <span>{addon.name} (+₹{addon.price})</span>
                          </span>
                        ))}
                      </div>
                    )}
                    {item.instructions && (
                      <p className="text-xs text-blue-700 italic font-medium mt-1 bg-blue-50/70 border border-blue-200/60 px-2 py-0.5 rounded-md inline-block">
                        💬 Note: {item.instructions}
                      </p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-dark-900 font-mono">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                    <p className="text-xs text-dark-400">x{item.quantity} @ ₹{Number(item.price).toLocaleString('en-IN')}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="card p-4 space-y-2">
            {[
              { label: 'Subtotal', value: order.subtotal },
              ...(order.discount > 0 ? [{ label: 'Discount', value: -order.discount, green: true }] : []),
              { label: 'Delivery / Shipping', value: order.shippingCost || 0 },
              { label: 'GST (18%)', value: order.tax || 0 },
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm text-dark-600 font-mono">
                <span>{row.label}</span>
                <span className={row.green ? 'text-green-600' : ''}>{row.green && '-'}₹{Math.abs(row.value)?.toLocaleString('en-IN')}</span>
              </div>
            ))}
            <div className="flex justify-between text-base font-bold text-dark-900 pt-2 border-t border-dark-100 font-mono">
              <span>Total</span>
              <span className="text-primary-600">₹{getOrderDisplayTotal(order).toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Shipping Address */}
          <div>
            <h3 className="text-sm font-semibold text-dark-700 mb-2">Shipping Address</h3>
            <div className="p-3 bg-dark-50 rounded-lg text-sm text-dark-600 space-y-0.5">
              <p className="font-medium text-dark-800">{order.shippingAddress?.fullName}</p>
              <p>{order.shippingAddress?.addressLine1}{order.shippingAddress?.addressLine2 ? `, ${order.shippingAddress.addressLine2}` : ''}</p>
              <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.postalCode}</p>
              <p>{order.shippingAddress?.country} · 📞 {order.shippingAddress?.phone}</p>
            </div>
          </div>

          {/* Tracking Timeline */}
          {order.trackingUpdates?.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-dark-700 mb-3">Tracking History</h3>
              <div className="space-y-3">
                {[...order.trackingUpdates].reverse().map((update, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full mt-0.5 flex-shrink-0 ${i === 0 ? 'bg-primary-500' : 'bg-dark-200'}`} />
                      {i < order.trackingUpdates.length - 1 && <div className="w-0.5 flex-1 bg-dark-100 mt-1" />}
                    </div>
                    <div className="pb-3">
                      <p className="text-sm font-medium text-dark-800 capitalize">{update.status?.replace(/_/g, ' ')}</p>
                      <p className="text-xs text-dark-500">{update.message}</p>
                      <p className="text-xs text-dark-400 mt-0.5">
                        {update.timestamp ? format(new Date(update.timestamp), 'MMM d, h:mm a') : ''}
                        {update.location && ` · 📍 ${update.location}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Send Comment / Note to Customer */}
          <div className="card p-4 space-y-3 bg-blue-50/50 border border-blue-200">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-dark-800 flex items-center gap-1.5">
                <span>💬</span>
                <span>Send Comment / Note to Customer</span>
              </h3>
              <span className="text-[11px] text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded font-medium">Visible on Customer Tracking</span>
            </div>
            {order.vendorNotes && (
              <div className="p-2.5 bg-white rounded-lg border border-blue-200 text-xs">
                <p className="text-[10px] font-bold text-blue-700 uppercase tracking-wider">Current Note to Customer:</p>
                <p className="text-dark-800 font-medium mt-0.5 whitespace-pre-wrap">{order.vendorNotes}</p>
              </div>
            )}
            <div className="flex gap-2">
              <input
                value={orderComment}
                onChange={(e) => setOrderComment(e.target.value)}
                className="input-field flex-1"
                placeholder="Write a comment or update for the customer..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && orderComment.trim() && !commenting) {
                    onAddComment(orderComment.trim());
                    setOrderComment('');
                  }
                }}
              />
              <button
                type="button"
                onClick={() => {
                  if (orderComment.trim()) {
                    onAddComment(orderComment.trim());
                    setOrderComment('');
                  }
                }}
                disabled={!orderComment.trim() || commenting}
                className="btn-primary whitespace-nowrap text-xs px-4 disabled:opacity-50"
              >
                {commenting ? 'Posting...' : 'Post Comment'}
              </button>
            </div>
          </div>

          {/* Update Status */}
          {nextStatuses.length > 0 && (
            <div className="card p-4 space-y-3.5 border border-primary-100 bg-gradient-to-b from-white to-primary-50/10">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-dark-800">Update Order Status</h3>
                {['food', 'grocery'].includes(order.vertical) && (
                  <span className="text-[11px] font-bold bg-primary-100 text-primary-800 px-2 py-0.5 rounded-full">
                    {order.vertical === 'food' ? '🍔 Food Order' : '🥦 Grocery Order'}
                  </span>
                )}
              </div>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                className="input-field"
              >
                <option value="">Select new status</option>
                {nextStatuses.map((s) => (
                  <option key={s} value={s}>{s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>
                ))}
              </select>

              {/* Delivery Slot / Date Selection */}
              {(isShopping
                ? (newStatus === 'out_for_delivery' || order.status === 'out_for_delivery')
                : (newStatus === 'accepted' || ['food', 'grocery', 'quick_commerce'].includes(order.vertical) || !order.deliverySlot)
              ) && (
                <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                      <span>{isShopping ? '📅' : '⏰'}</span>
                      <span>{isShopping ? 'Select Expected Delivery Date' : 'Assign Delivery Slot / Estimated Time'}</span>
                    </label>
                    <span className="text-[10px] text-blue-600 font-medium">
                      {isShopping ? 'Date calendar' : 'Custom delivery slot'}
                    </span>
                  </div>

                  {isShopping ? (
                    <div className="space-y-1.5">
                      <input
                        type="date"
                        min={new Date().toISOString().split('T')[0]}
                        value={shoppingDate}
                        onChange={(e) => setShoppingDate(e.target.value)}
                        className="input-field text-xs bg-white font-medium"
                      />
                      {shoppingDate && (
                        <p className="text-[11px] text-blue-800 font-semibold">
                          Selected Delivery Date: <span className="font-bold underline">{format(new Date(shoppingDate), 'dd MMM yyyy')}</span>
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <input
                        type="text"
                        value={customSlotText}
                        onChange={(e) => setCustomSlotText(e.target.value)}
                        placeholder="Enter delivery slot / estimated time (e.g. Tomorrow: 9AM - 11AM or Within 30 mins)..."
                        className="input-field text-xs bg-white font-medium"
                      />
                      {customSlotText && (
                        <p className="text-[11px] text-blue-800 font-semibold">
                          Slot to save: <span className="font-bold underline">{customSlotText}</span>
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}

              <input
                value={statusMessage}
                onChange={(e) => setStatusMessage(e.target.value)}
                className="input-field"
                placeholder="Add comment / message for customer (optional)"
              />
              <button
                onClick={() => {
                  if (newStatus) {
                    const finalSlot = isShopping
                      ? (shoppingDate ? format(new Date(shoppingDate), 'dd MMM yyyy') : (order.deliverySlot || effectiveDeliverySlot))
                      : (customSlotText.trim() || undefined);
                    onUpdateStatus({
                      status: newStatus,
                      message: statusMessage,
                      deliverySlot: finalSlot || undefined,
                    });
                  }
                }}
                disabled={!newStatus || updating}
                className="w-full btn-primary disabled:opacity-50"
              >
                {updating ? 'Updating...' : `Update Status${newStatus === 'accepted' ? ' & Accept Order' : ''}`}
              </button>
            </div>
          )}

          {/* Quick Delivery Slot / Date Management */}
          {(isShopping
            ? order.status === 'out_for_delivery'
            : ['accepted', 'processing', 'ready_for_pickup', 'out_for_delivery'].includes(order.status)
          ) && (
            <div className="card p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-dark-800 flex items-center gap-1.5">
                  <span>{isShopping ? '📅' : '⏰'}</span>
                  <span>{isShopping ? 'Delivery Date Management' : 'Delivery Slot Management'}</span>
                </span>
                <span className="text-xs font-semibold text-primary-700 bg-primary-50 px-2 py-0.5 rounded border border-primary-100">
                  Current: {order.deliverySlot || effectiveDeliverySlot || 'None'}
                </span>
              </div>
              {isShopping ? (
                <div className="flex gap-2 items-center">
                  <input
                    type="date"
                    min={new Date().toISOString().split('T')[0]}
                    value={shoppingDate}
                    onChange={(e) => setShoppingDate(e.target.value)}
                    className="input-field text-xs py-1.5 flex-1 bg-white font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (shoppingDate) {
                        const formatted = format(new Date(shoppingDate), 'dd MMM yyyy');
                        onUpdateDeliverySlot(formatted);
                      }
                    }}
                    disabled={!shoppingDate || updatingSlot}
                    className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-50 whitespace-nowrap"
                  >
                    {updatingSlot ? 'Saving...' : 'Update Date'}
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customSlotText}
                    onChange={(e) => setCustomSlotText(e.target.value)}
                    placeholder="Enter custom delivery slot..."
                    className="input-field text-xs py-1.5 flex-1 bg-white font-medium"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customSlotText.trim()) {
                        onUpdateDeliverySlot(customSlotText.trim());
                      }
                    }}
                    disabled={!customSlotText.trim() || updatingSlot}
                    className="btn-secondary text-xs px-3 py-1.5 disabled:opacity-50 whitespace-nowrap"
                  >
                    {updatingSlot ? 'Saving...' : 'Update Slot'}
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Assign Delivery Partner Card */}
          {!['delivered', 'completed', 'cancelled', 'refunded'].includes(order.status) && (
            <div className="card p-4 space-y-3 border border-indigo-100 bg-indigo-50/20 rounded-xl">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-dark-800 flex items-center gap-2">
                  <TruckIcon className="w-4 h-4 text-primary-600" />
                  <span>Assign Delivery Partner</span>
                </h3>
                {(order.deliveryAgent || order.deliveryBoy) ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-200 px-2.5 py-0.5 rounded-full">
                    Assigned: {(order.deliveryAgent || order.deliveryBoy)?.name}
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
                    Unassigned
                  </span>
                )}
              </div>

              {loadingDelivery ? (
                <p className="text-xs text-dark-400 py-1">Loading available delivery partners...</p>
              ) : deliveryBoys.length === 0 ? (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 space-y-1">
                  <p className="font-semibold">No active delivery partners found.</p>
                  <p className="text-[11px] text-amber-700">
                    To assign orders to delivery personnel, make sure delivery agents are registered with the <strong>Delivery</strong> role and are active.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {(order.deliveryAgent || order.deliveryBoy) && (
                    <div className="p-3 bg-white border border-gray-200 rounded-xl flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-dark-400 block tracking-wider">
                          Current Delivery Partner
                        </span>
                        <p className="font-bold text-dark-900 mt-0.5">
                          {(order.deliveryAgent || order.deliveryBoy)?.name}
                        </p>
                        <p className="text-dark-500 font-mono text-[11px]">
                          {(order.deliveryAgent || order.deliveryBoy)?.phone || 'No phone'}
                        </p>
                      </div>
                      {(() => {
                        const currentAgent = order.deliveryAgent || order.deliveryBoy;
                        const agentData = deliveryBoys.find(d => d._id === currentAgent?._id);
                        const online = agentData?.isOnline;
                        return (
                          <span className={`text-xs font-semibold px-2.5 py-1 rounded border ${online ? 'text-emerald-700 bg-emerald-50 border-emerald-100' : 'text-red-700 bg-red-50 border-red-100'}`}>
                            {online ? '🟢 Online' : '🔴 Offline'}
                          </span>
                        );
                      })()}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <select
                      value={selectedDelivery}
                      onChange={(e) => setSelectedDelivery(e.target.value)}
                      className="input-field text-xs flex-1 bg-white"
                    >
                      <option value="">Select delivery partner...</option>
                      {deliveryBoys.map((d) => (
                        <option key={d._id} value={d._id}>
                          {d.isOnline ? '🟢' : '🔴'} {d.name} ⭐ {d.deliveryRating?.average ? Number(d.deliveryRating.average).toFixed(1) : '4.8'} {d.phone ? `(${d.phone})` : ''} {d.isOnline ? '' : '- Offline'}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={() => {
                        if (!selectedDelivery) return;
                        const agent = deliveryBoys.find(d => d._id === selectedDelivery);
                        if (agent && !agent.isOnline) {
                          if (window.confirm(`⚠️ ${agent.name} is currently OFFLINE.\n\nThey may not see this assignment until they go online. Do you still want to assign?`)) {
                            onAssignDelivery(selectedDelivery);
                          }
                        } else {
                          onAssignDelivery(selectedDelivery);
                        }
                      }}
                      disabled={!selectedDelivery || assigningDelivery || selectedDelivery === (order.deliveryAgent?._id || order.deliveryBoy?._id)}
                      className="btn-primary text-xs px-4 whitespace-nowrap disabled:opacity-50"
                    >
                      {assigningDelivery
                        ? 'Assigning...'
                        : (order.deliveryAgent || order.deliveryBoy)
                        ? 'Reassign'
                        : 'Assign Partner'}
                    </button>
                  </div>

                  {selectedDelivery && (() => {
                    const agent = deliveryBoys.find(d => d._id === selectedDelivery);
                    if (agent && !agent.isOnline) {
                      return (
                        <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-800 flex items-start gap-2">
                          <span className="text-sm mt-0.5">⚠️</span>
                          <div>
                            <p className="font-bold">{agent.name} is currently offline</p>
                            <p className="text-[11px] text-red-600 mt-0.5">This partner won't receive the assignment until they open the Delivery App and go online.</p>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  })()}
                </div>
              )}
            </div>
          )}

          {/* If already delivered / completed, show delivery partner if assigned */}
          {['delivered', 'completed'].includes(order.status) && (order.deliveryAgent || order.deliveryBoy) && (
            <div className="card p-4 space-y-2 border border-gray-200 bg-gray-50/50 rounded-xl">
              <h3 className="text-xs font-bold text-dark-500 uppercase tracking-wider flex items-center gap-1.5">
                <TruckIcon className="w-3.5 h-3.5 text-emerald-600" />
                <span>Delivered By Partner</span>
              </h3>
              <div className="p-3 bg-white border border-gray-200 rounded-xl flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-dark-900">
                    {(order.deliveryAgent || order.deliveryBoy)?.name}
                  </p>
                  <p className="text-dark-500 font-mono text-[11px]">
                    {(order.deliveryAgent || order.deliveryBoy)?.phone || 'No phone'}
                  </p>
                </div>
                <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                  Delivered
                </span>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
