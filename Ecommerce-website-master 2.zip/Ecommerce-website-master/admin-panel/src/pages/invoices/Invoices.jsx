import { useState } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  DocumentTextIcon,
  PrinterIcon,
  MagnifyingGlassIcon,
  EyeIcon,
  XMarkIcon,
  ArrowDownTrayIcon,
} from '@heroicons/react/24/outline';
import { format } from 'date-fns';
import { GET_ALL_ORDERS } from '../../graphql/queries.js';

export default function Invoices() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: statusFilter === 'all' ? undefined : statusFilter,
      pagination: { limit: 100 },
    },
    fetchPolicy: 'network-only',
  });

  const orders = (data?.getAllOrders?.orders || []).filter(Boolean);

  const filteredOrders = orders.filter((o) => {
    const term = searchTerm.toLowerCase();
    return (
      o.orderNumber?.toLowerCase().includes(term) ||
      o.customer?.name?.toLowerCase().includes(term) ||
      o.customer?.email?.toLowerCase().includes(term)
    );
  });

  const isOrderRefunded = (order) => Boolean(
    order?.status === 'refunded' ||
    order?.paymentStatus === 'refunded' ||
    order?.returnStatus === 'approved' ||
    order?.returnStatus === 'refunded' ||
    (order?.status === 'cancelled' && (order?.paymentStatus === 'paid' || order?.paymentMethod !== 'cod')) ||
    order?.trackingUpdates?.some((u) => /refund/i.test(u?.message || u?.status || ''))
  );

  const isDispatchedOrBeyond = (order) => Boolean(
    ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(order?.status) ||
    order?.trackingUpdates?.some((u) => ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(u?.status))
  );

  const isCancelledBeforeDispatch = (order) => Boolean(order?.status === 'cancelled' && !isDispatchedOrBeyond(order));

  const isInvoiceValid = (order) => {
    if (!order) return false;
    if (isCancelledBeforeDispatch(order)) return false;
    const isCod = order.paymentMethod === 'cod';
    const isPaymentReceived = isCod
      ? (order.paymentStatus === 'paid' || ['delivered', 'completed'].includes(order.status))
      : (order.paymentStatus === 'paid' || order.paymentStatus === 'refunded');
    return Boolean(isPaymentReceived && isDispatchedOrBeyond(order));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">GST Invoice Management</h1>
          <p className="text-sm text-dark-500 mt-1">
            Generate, inspect, print, and export official GST compliant Invoices for customer orders
          </p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="card p-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-gray-100">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            placeholder="Search by order # or customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 text-xs"
          />
          <MagnifyingGlassIcon className="w-4 h-4 text-dark-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-dark-500">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="input-field py-1 text-xs"
          >
            <option value="all">All Invoices</option>
            <option value="delivered">Delivered</option>
            <option value="completed">Completed</option>
            <option value="paid">Paid</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-dark-50 text-dark-500 font-semibold border-b border-gray-200">
              <tr>
                <th className="py-3 px-4">Invoice / Ref #</th>
                <th className="py-3 px-4">Order Ref</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Billed To</th>
                <th className="py-3 px-4 text-right">Taxable</th>
                <th className="py-3 px-4 text-right">GST (18%)</th>
                <th className="py-3 px-4 text-right">Total</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading ? (
                <tr>
                  <td colSpan="9" className="text-center py-12 text-gray-400">
                    Loading invoices...
                  </td>
                </tr>
              ) : filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan="9" className="text-center py-12 text-gray-400">
                    No matching invoices found.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const subtotal = Number(order.subtotal || 0);
                  const discount = Number(order.discount || 0);
                  const taxable = Math.max(0, subtotal - discount);
                  const taxAmount = Number(order.tax || 0);
                  const refunded = isOrderRefunded(order);
                  const cancelledNoInvoice = isCancelledBeforeDispatch(order);
                  const invoiceReady = isInvoiceValid(order);

                  return (
                    <tr key={order._id} className="hover:bg-gray-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-primary-700">
                        {cancelledNoInvoice ? (
                          <span className="text-gray-400 font-normal">None (Cancelled)</span>
                        ) : invoiceReady ? (
                          `INV-${order.orderNumber || '—'}`
                        ) : (
                          <span className="text-blue-600 font-medium">Summary (#{order.orderNumber?.slice(-6)})</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-dark-800 font-medium">
                        #{order.orderNumber || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-gray-500">
                        {order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : '—'}
                      </td>
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-dark-900">{order.customer?.name || order.shippingAddress?.fullName || 'Customer'}</p>
                        <p className="text-[11px] text-gray-400">{order.customer?.email}</p>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono">
                        ₹{taxable.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-amber-700 font-semibold">
                        ₹{taxAmount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-dark-900">
                        ₹{order.total?.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            cancelledNoInvoice
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : refunded
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : invoiceReady
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {cancelledNoInvoice
                            ? 'Cancelled (No Invoice)'
                            : refunded
                            ? 'Refund Initiated'
                            : invoiceReady
                            ? 'Invoice Issued'
                            : 'Order Summary'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="px-3 py-1.5 rounded-xl bg-primary-50 hover:bg-primary-100 text-primary-700 font-bold text-xs flex items-center gap-1.5 ml-auto transition-colors"
                        >
                          <EyeIcon className="w-4 h-4" /> {invoiceReady ? 'View Invoice' : 'View Summary'}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Viewer Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-xl font-extrabold text-gray-900">
                    {isCancelledBeforeDispatch(selectedOrder)
                      ? 'ORDER CANCELLED (NO INVOICE)'
                      : isInvoiceValid(selectedOrder)
                      ? 'INVOICE'
                      : 'ORDER SUMMARY'}
                  </h3>
                  {isOrderRefunded(selectedOrder) && isInvoiceValid(selectedOrder) && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-300 shadow-2xs">
                      <span>↩️</span>
                      <span>Refund Initiated</span>
                    </span>
                  )}
                  {!isInvoiceValid(selectedOrder) && !isCancelledBeforeDispatch(selectedOrder) && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 border border-blue-300">
                      <span>Pre-Dispatch Summary</span>
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 font-mono">
                  {isInvoiceValid(selectedOrder)
                    ? `INV-${selectedOrder?.orderNumber || '—'}`
                    : `Order Ref: #${selectedOrder?.orderNumber || '—'}`}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <PrinterIcon className="w-4 h-4" /> Print / PDF
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Cancelled Before Dispatch Notice */}
            {isCancelledBeforeDispatch(selectedOrder) && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-2.5 text-xs text-rose-900">
                <span className="text-base">🚫</span>
                <div>
                  <p className="font-bold uppercase tracking-wide">Cancelled Before Dispatch / Supply</p>
                  <p className="text-rose-700 mt-0.5 font-medium">
                    This order was cancelled prior to goods dispatch/removal. Under GST law, no Tax Invoice was issued for this supply.
                  </p>
                </div>
              </div>
            )}

            {/* Pre-Dispatch Summary Notice */}
            {!isInvoiceValid(selectedOrder) && !isCancelledBeforeDispatch(selectedOrder) && (
              <div className="p-3.5 bg-blue-50/90 border border-blue-200 rounded-2xl flex items-start gap-2.5 text-xs text-blue-900">
                <span className="text-base">ℹ️</span>
                <div>
                  <p className="font-bold">
                    {selectedOrder.paymentMethod === 'cod' ? 'Cash on Delivery (Pending Delivery & Collection)' : 'Payment Received (Awaiting Dispatch)'}
                  </p>
                  <p className="text-blue-700 mt-0.5">
                    {selectedOrder.paymentMethod === 'cod'
                      ? 'Official GST Tax Invoice is generated once delivered and cash payment is received.'
                      : 'Payment is confirmed. Official GST Tax Invoice is generated once goods are dispatched for delivery.'}
                  </p>
                </div>
              </div>
            )}

            {/* Refund Initiated Banner */}
            {isOrderRefunded(selectedOrder) && (
              <div className="p-3.5 bg-rose-50/90 border border-rose-200 rounded-2xl flex items-center justify-between gap-3 text-xs">
                <div className="flex items-start gap-2.5">
                  <span className="text-lg">🔄</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-extrabold text-rose-900 uppercase tracking-wide">
                        Refund Initiated
                      </p>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-200/80 text-rose-800">
                        {selectedOrder.status === 'refunded' || selectedOrder.paymentStatus === 'refunded' || selectedOrder.returnStatus === 'refunded'
                          ? 'Refund Processed'
                          : 'In Progress'}
                      </span>
                    </div>
                    <p className="text-rose-700 text-xs mt-0.5 font-medium">
                      Full refund of <strong className="font-bold text-rose-950">₹{selectedOrder.total?.toLocaleString('en-IN')}</strong> has been initiated to the customer's original payment method ({selectedOrder.paymentMethod?.toUpperCase() || 'Source Account'}).
                    </p>
                  </div>
                </div>
                <div className="text-right whitespace-nowrap hidden sm:block">
                  <span className="text-[10px] font-semibold text-rose-500 block uppercase">Status</span>
                  <span className="text-xs font-bold text-rose-800">Refund Initiated</span>
                </div>
              </div>
            )}

            {/* Seller & Customer Details */}
            <div className="grid grid-cols-2 gap-4 text-xs text-gray-600 p-4 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-gray-900 text-sm">ShopZone E-Commerce Pvt Ltd</p>
                <p>Plot 42, Tech City, Meerut, UP - 250001</p>
                <p className="font-semibold text-gray-800 mt-1">GSTIN: 09AAACH7409R1ZZ</p>
                <p>PAN: AAACH7409R</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900 text-sm">Billed To: {selectedOrder.shippingAddress?.fullName || selectedOrder.customer?.name}</p>
                <p>{selectedOrder.shippingAddress?.addressLine1}</p>
                <p>{selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state} - {selectedOrder.shippingAddress?.postalCode}</p>
                <p>Phone: {selectedOrder.shippingAddress?.phone}</p>
                <p className="font-semibold text-gray-800 mt-1">
                  Date: {selectedOrder.createdAt ? format(new Date(selectedOrder.createdAt), 'dd MMM yyyy') : 'N/A'}
                </p>
              </div>
            </div>

            {/* Table */}
            <table className="w-full text-xs">
              <thead className="border-b border-gray-200 text-gray-500 font-semibold">
                <tr>
                  <th className="text-left py-2">Item Description</th>
                  <th className="text-center py-2">Qty</th>
                  <th className="text-right py-2">Price</th>
                  <th className="text-right py-2">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {selectedOrder.items?.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-2.5 font-medium">{item.name}</td>
                    <td className="py-2.5 text-center">{item.quantity}</td>
                    <td className="py-2.5 text-right font-mono">₹{Number(item.price).toLocaleString('en-IN')}</td>
                    <td className="py-2.5 text-right font-mono font-bold">₹{(item.price * item.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* GST Summary */}
            <div className="border-t border-gray-200 pt-3 space-y-1.5 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Taxable Subtotal</span>
                <span className="font-mono">₹{(selectedOrder.subtotal - (selectedOrder.discount || 0)).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>CGST (9%)</span>
                <span className="font-mono">₹{(selectedOrder.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>SGST (9%)</span>
                <span className="font-mono">₹{(selectedOrder.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Charges</span>
                <span className="font-mono">{selectedOrder.shippingCost === 0 ? 'FREE' : `₹${selectedOrder.shippingCost}`}</span>
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-extrabold text-gray-900">
                <span>Grand Total (INR)</span>
                <span className="font-mono text-primary-600">₹{selectedOrder.total?.toLocaleString('en-IN')}</span>
              </div>
              {isOrderRefunded(selectedOrder) && (
                <div className="pt-2 flex justify-between text-xs font-bold text-rose-700 border-t border-dashed border-rose-200 bg-rose-50/60 p-2 rounded-lg mt-1">
                  <span className="flex items-center gap-1.5">
                    <span>↩️</span>
                    <span>Refund Status</span>
                  </span>
                  <span className="font-extrabold text-rose-800 tracking-wide">
                    REFUND INITIATED (₹{selectedOrder.total?.toLocaleString('en-IN')})
                  </span>
                </div>
              )}
            </div>

            <p className="text-[10px] text-gray-400 text-center">
              {isInvoiceValid(selectedOrder)
                ? 'This is an authentic computer-generated GST invoice for official records.'
                : 'This is a computer-generated order summary.'}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
