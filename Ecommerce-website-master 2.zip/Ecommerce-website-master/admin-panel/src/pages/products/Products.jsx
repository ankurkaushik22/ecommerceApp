import { useState, useEffect, useRef, useMemo } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import {
  PlusIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  DocumentDuplicateIcon,
  MagnifyingGlassIcon,
  FunnelIcon,
  ArrowPathIcon,
  CheckIcon,
  XMarkIcon,
  DocumentArrowUpIcon,
  PhotoIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  ArrowsPointingOutIcon,
  SparklesIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_PRODUCTS, GET_ALL_CATEGORIES, GET_DASHBOARD_STATS, GET_STORE_SETTINGS, GET_TAX_SETTINGS } from '../../graphql/queries.js';
import { CREATE_PRODUCT, UPDATE_PRODUCT, DELETE_PRODUCT, TOGGLE_PRODUCT_STATUS, UPDATE_PRODUCT_APPROVAL } from '../../graphql/mutations.js';
import MultiImageUpload from '../../components/common/MultiImageUpload';
import ConfirmModal from '../../components/common/ConfirmModal';
import RichTextEditor from '../../components/common/RichTextEditor';
import useVerticalStore, { VERTICAL_OPTIONS, getCategoryVertical } from '../../store/verticalStore.js';
import useAuthStore from '../../store/authStore.js';
import { formatError } from '../../utils/formatError.js';

const PAGE_SIZE = 50;

export function resolveCategoryId(prod) {
  if (!prod) return '';
  const raw = prod.category?._id || prod.category || prod.categoryId;
  if (!raw) return '';
  if (typeof raw === 'object' && raw._id) return String(raw._id);
  if (typeof raw === 'object' && typeof raw.toString === 'function' && raw.toString() !== '[object Object]') {
    return String(raw);
  }
  return String(raw);
}

export default function Products() {
  const user = useAuthStore((s) => s.user);
  const isVendor = user?.role === 'vendor';
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [page, setPage] = useState(1);
  const [activeTab, setActiveTab] = useState('approved'); // 'approved' | 'pending'
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [isDuplicating, setIsDuplicating] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [rejectingProduct, setRejectingProduct] = useState(null);
  const [reviewingProduct, setReviewingProduct] = useState(null);
  const [editingStockId, setEditingStockId] = useState(null);
  const [inlineStockVal, setInlineStockVal] = useState('');

  const [updateProductMutation, { loading: updatingStock }] = useMutation(UPDATE_PRODUCT, {
    refetchQueries: [{ query: GET_DASHBOARD_STATS }],
    update: (cache) => {
      cache.evict({ fieldName: 'getProducts' });
      cache.gc();
    },
    onCompleted: async () => {
      toast.success('Stock updated successfully!');
      setEditingStockId(null);
      await Promise.all([
        refetch?.({ fetchPolicy: 'network-only' }),
        refetchPending?.({ fetchPolicy: 'network-only' }),
      ]);
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const handleQuickStockSave = (prod) => {
    const newStock = parseInt(inlineStockVal);
    if (isNaN(newStock) || newStock < 0) {
      toast.error('Please enter a valid stock quantity');
      return;
    }
    updateProductMutation({
      variables: {
        id: prod._id,
        input: {
          name: prod.name,
          description: prod.description,
          price: prod.price,
          categoryId: resolveCategoryId(prod),
          images: prod.images || [],
          stock: newStock,
          variants: prod.variants?.map((v) => ({
            name: v.name,
            options: (v.options || []).map((o) => ({
              label: o.label,
              price: o.price,
              stock: o.stock,
              sku: o.sku,
              thumbnail: o.thumbnail,
            })),
          })) || [],
        },
      },
    });
  };

  const { data, loading, refetch } = useQuery(GET_ALL_PRODUCTS, {
    variables: {
      filter: {
        ...(search && { search }),
        ...(categoryId && { categoryId }),
        ...(activeVertical !== 'all' && { vertical: activeVertical }),
        approvalStatus: activeTab,
        all: true,
      },
      pagination: { page: 1, limit: 300 },
      sort: { field: 'newest', order: 'desc' },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: catData } = useQuery(GET_ALL_CATEGORIES);

  const { data: pendingData, refetch: refetchPending } = useQuery(GET_ALL_PRODUCTS, {
    variables: {
      filter: {
        ...(activeVertical !== 'all' && { vertical: activeVertical }),
        approvalStatus: 'pending',
        all: true,
      },
      pagination: { page: 1, limit: 300 },
    },
    fetchPolicy: 'cache-and-network',
  });
  const pendingProductsCount = pendingData?.getProducts?.products?.length || 0;

  const [toggleStatus] = useMutation(TOGGLE_PRODUCT_STATUS, {
    refetchQueries: [{ query: GET_DASHBOARD_STATS }],
    update: (cache) => {
      cache.evict({ fieldName: 'getProducts' });
      cache.gc();
    },
    onCompleted: async () => {
      toast.success('Status updated');
      await Promise.all([
        refetch?.({ fetchPolicy: 'network-only' }),
        refetchPending?.({ fetchPolicy: 'network-only' }),
      ]);
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const [updateApproval, { loading: updatingApproval }] = useMutation(UPDATE_PRODUCT_APPROVAL, {
    refetchQueries: [{ query: GET_DASHBOARD_STATS }],
    update: (cache) => {
      cache.evict({ fieldName: 'getProducts' });
      cache.gc();
    },
    onCompleted: async () => {
      toast.success('Approval status updated');
      setRejectingProduct(null);
      setRejectReason('');
      setReviewingProduct(null);
      await Promise.all([
        refetch?.({ fetchPolicy: 'network-only' }),
        refetchPending?.({ fetchPolicy: 'network-only' }),
      ]);
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const [deleteProduct] = useMutation(DELETE_PRODUCT, {
    refetchQueries: [{ query: GET_DASHBOARD_STATS }],
    update: (cache) => {
      cache.evict({ fieldName: 'getProducts' });
      cache.gc();
    },
    onCompleted: async () => {
      toast.success('Product deleted');
      setDeleteConfirm(null);
      await Promise.all([
        refetch?.({ fetchPolicy: 'network-only' }),
        refetchPending?.({ fetchPolicy: 'network-only' }),
      ]);
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const rawProducts = data?.getProducts?.products || [];
  const allCategories = catData?.getAllCategories || [];

  // Filter products according to activeVertical tab
  const products = rawProducts.filter((p) => {
    if (activeVertical === 'all') return true;
    const v = p.vertical || p.category?.vertical || getCategoryVertical(p.category);
    return v === activeVertical;
  });
  const total = products.length;
  const pages = Math.ceil(total / PAGE_SIZE) || 1;

  // Filter categories displayed in the dropdown according to activeVertical if selected
  const categories = allCategories.filter((c) => {
    if (activeVertical === 'all') return true;
    return getCategoryVertical(c) === activeVertical;
  });



  const handleDuplicate = (prod) => {
    const duplicatedData = {
      ...prod,
      _id: undefined, // remove id to trigger create mode
      name: `${prod.name} (Copy)`,
      sku: prod.sku ? `${prod.sku}-COPY` : '',
    };
    setEditProduct(duplicatedData);
    setIsDuplicating(true);
    setShowModal(true);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Products</h2>
          <p className="text-sm text-dark-500">
            {total} {activeTab === 'approved' ? 'active' : 'pending request'} products {activeVertical !== 'all' && `(${activeVertical.toUpperCase()})`}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              setEditProduct(null);
              setIsDuplicating(false);
              setShowModal(true);
            }}
            className="flex items-center gap-2 btn-primary"
          >
            <PlusIcon className="w-4 h-4" /> Add Product
          </motion.button>
        </div>
      </div>

      {/* Tabs for Active Products vs New Product Requests */}
      <div className="flex border-b border-dark-200 gap-6">
        <button
          onClick={() => {
            setActiveTab('approved');
            setPage(1);
          }}
          className={`pb-3 text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'approved'
              ? 'border-primary-600 text-primary-600'
              : 'border-transparent text-dark-400 hover:text-dark-600'
          }`}
        >
          Active Products
        </button>
        <button
          onClick={() => {
            setActiveTab('pending');
            setPage(1);
          }}
          className={`pb-3 text-sm font-bold border-b-2 transition-colors flex items-center gap-2 cursor-pointer ${
            activeTab === 'pending'
              ? 'border-amber-500 text-amber-600'
              : 'border-transparent text-dark-400 hover:text-dark-600'
          }`}
        >
          <span>{isVendor ? 'Pending Requests' : 'New Product Requests'}</span>
          {pendingProductsCount > 0 && (
            <span className={`px-2 py-0.5 text-xs font-extrabold rounded-full transition-colors ${
              activeTab === 'pending'
                ? 'bg-amber-500 text-white shadow-2xs'
                : 'bg-amber-100 text-amber-800'
            }`}>
              {pendingProductsCount}
            </span>
          )}
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Search products..."
            className="input-field pl-9"
          />
        </div>
        <select
          value={categoryId}
          onChange={(e) => {
            setCategoryId(e.target.value);
            setPage(1);
          }}
          className="input-field sm:w-48"
        >
          <option value="">All Categories</option>
          {categories.map((c) => {
            const pName = c.parent?.name;
            const displayName = pName ? `${pName} → ${c.name}` : c.name;
            return (
              <option key={c._id} value={c._id}>
                {displayName} ({c.vertical || getCategoryVertical(c) || 'shopping'})
              </option>
            );
          })}
        </select>
        <button onClick={() => refetch()} className="flex items-center gap-2 btn-secondary whitespace-nowrap">
          <ArrowPathIcon className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Products Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Product</th>
                <th className="px-4 py-3 text-left">Vertical</th>
                <th className="px-4 py-3 text-left">Category</th>
                {activeTab === 'pending' && !isVendor && <th className="px-4 py-3 text-left">Vendor</th>}
                <th className="px-4 py-3 text-right">Price</th>
                <th className="px-4 py-3 text-right">Stock</th>
                {activeTab === 'pending' && !isVendor && <th className="px-4 py-3 text-center">Proposed Commission</th>}
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Featured</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(activeTab === 'pending' && !isVendor ? 10 : 8)].map((_, j) => (
                        <td key={j} className="px-4 py-3">
                          <div className="h-4 bg-dark-100 rounded animate-pulse" />
                        </td>
                      ))}
                    </tr>
                  ))
                : products.map((product) => (
                    <motion.tr
                      key={product._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/50 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              product.images?.[0] ||
                              'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'
                            }
                            alt={product.name}
                            className="w-10 h-10 object-cover rounded-lg border border-dark-100"
                          />
                          <div>
                            <p className="text-sm font-medium text-dark-800 line-clamp-1 max-w-[180px]">
                              {product.name}
                            </p>
                            <p className="text-xs text-dark-400">SKU: {product.sku || 'N/A'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {(() => {
                          const itemVertical = product.vertical || getCategoryVertical(product.category);
                          return (
                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase ${
                                itemVertical === 'food'
                                  ? 'bg-orange-100 text-orange-800'
                                  : itemVertical === 'grocery'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : itemVertical === 'services'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-purple-100 text-purple-800'
                              }`}
                            >
                              {itemVertical === 'food'
                                ? '🍔 Food'
                                : itemVertical === 'grocery'
                                ? '🥦 Grocery'
                                : itemVertical === 'services'
                                ? '🛠️ Service'
                                : '🛍️ Retail'}
                            </span>
                          );
                        })()}
                      </td>
                      <td className="px-4 py-3 text-sm text-dark-600">
                        {product.category?.name || 'Uncategorized'}
                      </td>
                      {activeTab === 'pending' && !isVendor && (
                        <td className="px-4 py-3 text-sm text-dark-800 font-medium">
                          {product.vendor?.name || 'Vendor'}
                        </td>
                      )}
                      <td className="px-4 py-3 text-right font-mono">
                        <span className="text-sm font-semibold text-dark-900">
                          ₹{Number(product.price).toLocaleString('en-IN')}
                        </span>
                        {product.comparePrice > product.price && (
                          <span className="block text-xs text-dark-400 line-through">
                            ₹{Number(product.comparePrice).toLocaleString('en-IN')}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {editingStockId === product._id ? (
                          <div className="inline-flex items-center gap-1.5 justify-end">
                            <input
                              type="number"
                              min="0"
                              value={inlineStockVal}
                              onChange={(e) => setInlineStockVal(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleQuickStockSave(product);
                                if (e.key === 'Escape') setEditingStockId(null);
                              }}
                              className="w-20 px-2 py-1 text-xs font-mono font-bold border border-blue-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                              autoFocus
                            />
                            <button
                              type="button"
                              onClick={() => handleQuickStockSave(product)}
                              disabled={updatingStock}
                              className="p-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs cursor-pointer"
                              title="Save Stock"
                            >
                              <CheckIcon className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingStockId(null)}
                              className="p-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-md text-xs cursor-pointer"
                              title="Cancel"
                            >
                              <XMarkIcon className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1.5 justify-end group">
                            <span
                              className={`text-sm font-medium ${
                                product.stock === 0
                                  ? 'text-red-500 font-bold'
                                  : product.stock < 10
                                  ? 'text-amber-500'
                                  : 'text-green-600'
                              }`}
                            >
                              {product.vertical === 'services' ? '∞ Service' : product.stock}
                            </span>
                            {product.vertical !== 'services' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingStockId(product._id);
                                  setInlineStockVal(product.stock ?? 0);
                                }}
                                className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-all cursor-pointer"
                                title="Quick Update Stock"
                              >
                                <PencilIcon className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                      {activeTab === 'pending' && !isVendor && (
                        <td className="px-4 py-3 text-center">
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                            💰 {product.commissionType === 'flat' ? `₹${product.commissionValue ?? 0}` : `${product.commissionValue ?? 10}%`}
                          </span>
                        </td>
                      )}
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => toggleStatus({ variables: { id: product._id } })}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                            product.isActive
                              ? 'bg-green-100 text-green-700 hover:bg-green-200'
                              : 'bg-red-100 text-red-600 hover:bg-red-200'
                          }`}
                        >
                          {product.isActive ? (
                            <>
                              <CheckIcon className="w-3 h-3" /> Active
                            </>
                          ) : (
                            <>
                              <XMarkIcon className="w-3 h-3" /> Inactive
                            </>
                          )}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {product.isFeatured ? (
                          <span className="text-amber-500 text-sm font-bold">⭐</span>
                        ) : (
                          <span className="text-dark-200 text-sm">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1.5">
                          {activeTab === 'pending' ? (
                            isVendor ? (
                              <>
                                <span className="px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-lg text-xs font-semibold flex items-center gap-1">
                                  ⏳ Pending Approval
                                </span>
                                <button
                                  onClick={() => {
                                    setEditProduct(product);
                                    setIsDuplicating(false);
                                    setShowModal(true);
                                  }}
                                  title="Edit Product"
                                  className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors cursor-pointer"
                                >
                                  <PencilIcon className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => setDeleteConfirm(product)}
                                  title="Delete Product"
                                  className="p-1.5 text-dark-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                                >
                                  <TrashIcon className="w-4 h-4" />
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  onClick={() => setReviewingProduct(product)}
                                  className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                                  title="Review details & set admin commission"
                                >
                                  <EyeIcon className="w-3.5 h-3.5" /> Review & Approve
                                </button>
                                <button
                                  onClick={() => {
                                    setRejectingProduct(product);
                                    setRejectReason('');
                                  }}
                                  className="px-2.5 py-1 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                                  title="Reject Product with Reason"
                                >
                                  <XMarkIcon className="w-3 h-3" /> Reject
                                </button>
                              </>
                            )
                          ) : (
                            <>
                              <button
                                onClick={() => {
                                  setEditProduct(product);
                                  setIsDuplicating(false);
                                  setShowModal(true);
                                }}
                                title="Edit Product"
                                className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                              >
                                <PencilIcon className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDuplicate(product)}
                                title="Duplicate Product"
                                className="p-1.5 text-dark-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                              >
                                <DocumentDuplicateIcon className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => setDeleteConfirm(product)}
                                title="Delete Product"
                                className="p-1.5 text-dark-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <TrashIcon className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </motion.tr>
                  ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div className="px-4 py-3 border-t border-dark-100 flex items-center justify-between">
            <p className="text-xs text-dark-400">
              Page {page} of {pages} · {total} results
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1 text-sm btn-secondary disabled:opacity-40"
              >
                ← Prev
              </button>
              <button
                onClick={() => setPage((p) => Math.min(pages, p + 1))}
                disabled={page === pages}
                className="px-3 py-1 text-sm btn-secondary disabled:opacity-40"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Full-Screen Product Form Modal */}
      <AnimatePresence>
        {showModal && (
          <FullScreenProductModal
            key={editProduct?._id || (isDuplicating ? 'duplicate' : 'create')}
            product={editProduct}
            isDuplicating={isDuplicating}
            categories={allCategories}
            defaultVertical={activeVertical !== 'all' ? activeVertical : 'shopping'}
            onClose={() => {
              setShowModal(false);
              setEditProduct(null);
              setIsDuplicating(false);
            }}
            onSuccess={() => {
              setShowModal(false);
              setEditProduct(null);
              setIsDuplicating(false);
              refetch();
              refetchPending?.();
            }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirm Modal */}
      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Product?"
        message={`Are you sure you want to delete "${deleteConfirm?.name}"? This action cannot be undone.`}
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteProduct({ variables: { id: deleteConfirm._id } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />

      {/* Reject Product Modal */}
      <AnimatePresence>
        {rejectingProduct && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="text-base font-bold text-dark-900">Reject Product Request</h3>
                <button onClick={() => setRejectingProduct(null)} className="p-1 text-gray-400 hover:text-gray-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div>
                <p className="text-xs text-dark-600 mb-2">
                  You are rejecting <span className="font-bold text-dark-900">"{rejectingProduct.name}"</span> submitted by <span className="font-bold text-dark-900">{rejectingProduct.vendor?.name || 'Vendor'}</span>.
                </p>
                <label className="text-xs font-bold text-dark-700 block mb-1">Reason for Rejection (Sent to Vendor)</label>
                <textarea
                  rows="3"
                  placeholder="e.g. Invalid product images, inaccurate pricing, or incomplete specifications..."
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="input-field text-xs resize-none"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectingProduct(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-dark-700 hover:bg-gray-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    updateApproval({
                      variables: {
                        id: rejectingProduct._id,
                        status: 'rejected',
                        reason: rejectReason,
                      },
                    });
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                >
                  Confirm Rejection
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Review Product Modal for Admin */}
      <AnimatePresence>
        {reviewingProduct && (
          <ReviewProductModal
            product={reviewingProduct}
            onClose={() => setReviewingProduct(null)}
            onApprove={(variables) => updateApproval({ variables })}
            onEdit={(prod) => {
              setEditProduct(prod);
              setIsDuplicating(false);
              setShowModal(true);
            }}
            onReject={(prod) => {
              setRejectingProduct(prod);
              setRejectReason('');
            }}
            approving={updatingApproval}
          />
        )}
      </AnimatePresence>

    </div>
  );
}

function FullScreenProductModal({
  product,
  isDuplicating,
  categories,
  onClose,
  onSuccess,
  defaultVertical = 'shopping',
}) {
  const { user } = useAuthStore();
  const { data: storeSettingsData } = useQuery(GET_STORE_SETTINGS, { fetchPolicy: 'cache-first' });
  const vendorStoreName = user?.role === 'vendor' ? (user?.name || '') : '';
  const { data: taxSettingsData } = useQuery(GET_TAX_SETTINGS, { variables: { activeOnly: true }, fetchPolicy: 'cache-first' });
  const allTaxSettings = taxSettingsData?.getTaxSettings || [];
  const isVendor = user?.role === 'vendor' && Boolean(user?.vendorVertical);
  const isEdit = Boolean(product && !isDuplicating);
  const initialVertical = isVendor
    ? user.vendorVertical
    : (product?.vertical || (product?.category ? getCategoryVertical(product.category) : null) || defaultVertical);

  const initialCategoryId = resolveCategoryId(product);

  const {
    register,
    handleSubmit,
    setValue,
    clearErrors,
    formState: { errors },
    watch,
    reset,
  } = useForm({
    defaultValues: product
      ? {
          name: product.name || '',
          description: product.description || '',
          shortDescription: product.shortDescription || '',
          price: product.price ?? '',
          comparePrice: product.comparePrice ?? '',
          stock: product.stock ?? 0,
          sku: product.sku || '',
          categoryId: initialCategoryId,
          images: product.images || [],
          tags: Array.isArray(product.tags) ? product.tags.join(', ') : (product.tags || ''),
          isFeatured: product.isFeatured || false,
          isDeals: product.isDeals || false,
          freeShipping: product.freeShipping || false,
          disableCOD: product.disableCOD || false,
          vertical: product.vertical || initialVertical || 'shopping',
          unitMeasure: product.unitMeasure || '',
          nutritionalHighlights: product.nutritionalHighlights?.join(', ') || '',
          isVeg: product.isVeg !== undefined ? product.isVeg : true,
          restaurantName: product.restaurantName && product.restaurantName.toLowerCase() !== 'suaaka' ? product.restaurantName : (user?.role === 'vendor' ? user?.name : ''),
          allowCookingInstructions: product.allowCookingInstructions !== undefined ? product.allowCookingInstructions : true,
          cuisine: product.cuisine?.join(', ') || '',
          preparationTime: product.preparationTime || 25,
          serviceDuration: product.serviceDuration || '',
          warranty: product.warranty || '',
          includedFeatures: product.includedFeatures?.join(', ') || '',
          commissionType: product.commissionType || 'percentage',
          commissionValue: product.commissionValue !== undefined ? product.commissionValue : 0,
          taxSettingId: product.taxSetting?._id || '',
        }
      : {
          vertical: initialVertical,
          isFeatured: false,
          isDeals: false,
          freeShipping: false,
          disableCOD: false,
          stock: 0,
          images: [],
          isVeg: true,
          restaurantName: vendorStoreName,
          allowCookingInstructions: true,
          preparationTime: 25,
          commissionType: 'percentage',
          commissionValue: 10,
          taxSettingId: '',
        },
  });

  // Auto-fill restaurantName with vendor's name for new products or if restaurantName was defaulted to Suaaka
  useEffect(() => {
    if (!product && !isDuplicating && vendorStoreName && (!watch('restaurantName') || watch('restaurantName').toLowerCase() === 'suaaka')) {
      setValue('restaurantName', vendorStoreName);
    }
  }, [vendorStoreName, product, isDuplicating, setValue, watch]);

  // Keep categoryId and vertical strictly in sync whenever product or categories load
  useEffect(() => {
    if (product) {
      const catId = resolveCategoryId(product);
      const prodVertical =
        product.vertical ||
        product.category?.vertical ||
        (product.category ? getCategoryVertical(product.category) : null) ||
        initialVertical ||
        'shopping';

      if (prodVertical && watch('vertical') !== prodVertical) {
        setValue('vertical', prodVertical);
      }
      if (catId && watch('categoryId') !== catId) {
        setValue('categoryId', catId, { shouldValidate: true });
      }
    }
  }, [product, categories, initialVertical, setValue, watch]);

  const selectedVertical = watch('vertical') || 'shopping';

  // State for Size and Color Matrix / Variants
  const [sizeOptions, setSizeOptions] = useState(() => {
    if (product?.variants && product.variants.length > 0) {
      return product.variants.map((v) => ({
        size: v.name,
        colors: (v.options || []).map((opt) => ({
          color: opt.label,
          stock: opt.stock !== undefined ? opt.stock : 0,
          price: opt.price !== undefined ? opt.price : 0,
          sku: opt.sku || '',
          thumbnail: opt.thumbnail || (opt.thumbnails?.[0] || ''),
          thumbnails: Array.isArray(opt.thumbnails) && opt.thumbnails.length > 0
            ? opt.thumbnails
            : (opt.thumbnail ? [opt.thumbnail] : []),
        })),
      }));
    }
    return [];
  });

  // State for Specifications (Key-Value attributes)
  const [specifications, setSpecifications] = useState(() => {
    if (product?.specifications && Array.isArray(product.specifications)) {
      return product.specifications.map((s) => ({ key: s.key || '', value: s.value || '' }));
    }
    return [];
  });

  // State for Product Highlights / Trust Badges
  const [highlights, setHighlights] = useState(() => {
    if (product?.highlights && Array.isArray(product.highlights) && product.highlights.length > 0) {
      return [...product.highlights];
    }
    return ['Fast Delivery Guaranteed', 'Authentic Guarantee', '30-Day Easy Returns'];
  });

  // State for Food Add-ons / Toppings
  const [addons, setAddons] = useState(() => {
    if (product?.addons && Array.isArray(product.addons) && product.addons.length > 0) {
      return product.addons.map((a) => ({ name: a.name || '', price: a.price || 0, icon: a.icon || '🍽️' }));
    }
    return [];
  });

  const autoExtractSpecifications = () => {
    const desc = watch('description') || '';
    if (!desc.trim()) {
      toast.error('Detailed Description is empty');
      return;
    }

    const plainText = desc.replace(/<[^>]*>/g, '\n');
    const lines = plainText.split('\n').map((l) => l.trim()).filter(Boolean);
    const extracted = [];

    lines.forEach((line) => {
      const cleanLine = line.replace(/^[-•*]\s*/, '');
      if (cleanLine.includes(':')) {
        const [k, ...vParts] = cleanLine.split(':');
        const v = vParts.join(':').trim();
        if (k.trim() && v) {
          extracted.push({ key: k.trim(), value: v });
        }
      } else if (cleanLine.includes(' - ') && !cleanLine.toLowerCase().startsWith('style number')) {
        const [k, ...vParts] = cleanLine.split(' - ');
        const v = vParts.join(' - ').trim();
        if (k.trim() && v) {
          extracted.push({ key: k.trim(), value: v });
        }
      } else if (cleanLine.includes('|')) {
        const parts = cleanLine.split('|').map((p) => p.trim()).filter(Boolean);
        parts.forEach((part) => {
          if (part.includes(':')) {
            const [k, ...vParts] = part.split(':');
            if (k.trim() && vParts.join(':').trim()) {
              extracted.push({ key: k.trim(), value: vParts.join(':').trim() });
            }
          }
        });
      }
    });

    if (extracted.length === 0) {
      toast.error('No key-value pairs (e.g. "Fabric: Cotton") found in description');
      return;
    }

    const merged = [...specifications.filter((s) => s.key.trim() && s.value.trim())];
    extracted.forEach((item) => {
      if (!merged.some((m) => m.key.toLowerCase() === item.key.toLowerCase())) {
        merged.push(item);
      }
    });

    setSpecifications(merged);
    toast.success(`Extracted ${extracted.length} specification(s) from description!`);
  };

  const [activeSizeIdx, setActiveSizeIdx] = useState(0);
  const [newSizeInput, setNewSizeInput] = useState('');
  const [variantUploadingMap, setVariantUploadingMap] = useState({});
  const [confirmState, setConfirmState] = useState(null);

  // Build clean hierarchical category options for the selected vertical
  const formattedCategoryOptions = useMemo(() => {
    const targetCatId = resolveCategoryId(product);

    const catMap = new Map();
    (categories || []).forEach((c) => catMap.set(String(c._id), c));

    // Categories matching the current vertical
    const verticalCats = (categories || []).filter((c) => {
      const v = c.vertical || getCategoryVertical(c);
      return v === selectedVertical;
    });

    const roots = verticalCats.filter((c) => !c.parent);
    const options = [];

    // Group children under roots
    roots.forEach((root) => {
      options.push({
        _id: String(root._id),
        name: root.name,
        displayName: root.name,
        isParent: true,
      });

      const children = (categories || []).filter((c) => {
        const pId = c.parent?._id || c.parent;
        return pId && String(pId) === String(root._id);
      });

      children.forEach((child) => {
        options.push({
          _id: String(child._id),
          name: child.name,
          displayName: `　└─ ${child.name}`,
          isParent: false,
        });
      });
    });

    // Include any subcategories in this vertical whose parent is in another group or not root
    verticalCats.forEach((c) => {
      if (c.parent && !options.some((o) => String(o._id) === String(c._id))) {
        const pDoc = catMap.get(String(c.parent?._id || c.parent));
        const pName = pDoc?.name ? `${pDoc.name} → ` : '';
        options.push({
          _id: String(c._id),
          name: c.name,
          displayName: `　└─ ${pName}${c.name}`,
          isParent: false,
        });
      }
    });

    // CRITICAL GUARANTEE: If the product has a category assigned, NEVER let it be missing from options!
    if (targetCatId && !options.some((o) => String(o._id) === String(targetCatId))) {
      const existing = catMap.get(String(targetCatId)) || (product?.category?.name ? product.category : null);
      if (existing) {
        options.unshift({
          _id: String(targetCatId),
          name: existing.name || 'Assigned Category',
          displayName: `★ ${existing.name || 'Assigned Category'}`,
          isParent: false,
        });
      }
    }

    return options;
  }, [categories, selectedVertical, product]);

  // Resilient category auto-selection: If editing a product or when options change, ensure a valid category is selected
  useEffect(() => {
    if (formattedCategoryOptions.length > 0) {
      const currentCat = watch('categoryId');
      const isValid = formattedCategoryOptions.some((c) => String(c._id) === String(currentCat));

      // If editing a product, or if an invalid category ID is currently selected
      if (!isValid && (isEdit || currentCat)) {
        // Look for matching category by product category name if available
        let bestMatch = null;
        if (product?.category?.name) {
          const prodCatName = product.category.name.toLowerCase().trim();
          bestMatch = formattedCategoryOptions.find((c) => c.name.toLowerCase().trim() === prodCatName);
        }

        // Otherwise pick the first child/leaf category or first category in the list
        if (!bestMatch) {
          bestMatch = formattedCategoryOptions.find((c) => !c.isParent) || formattedCategoryOptions[0];
        }

        if (bestMatch?._id) {
          setValue('categoryId', String(bestMatch._id), { shouldValidate: true });
        }
      }
    }
  }, [formattedCategoryOptions, isEdit, product, watch, setValue]);

  const [createProduct, { loading: creating }] = useMutation(CREATE_PRODUCT, {
    refetchQueries: [{ query: GET_ALL_PRODUCTS }, { query: GET_DASHBOARD_STATS }],
    onCompleted: () => {
      toast.success(isDuplicating ? 'Product duplicated successfully!' : 'Product created!');
      onSuccess();
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const [updateProduct, { loading: updating }] = useMutation(UPDATE_PRODUCT, {
    refetchQueries: [{ query: GET_ALL_PRODUCTS }, { query: GET_DASHBOARD_STATS }],
    onCompleted: () => {
      toast.success('Product updated!');
      onSuccess();
    },
    onError: (e) => toast.error(formatError(e)),
  });

  const loading = creating || updating;

  // Variant Helpers
  const addSizeOption = () => {
    const sizeName = newSizeInput.trim();
    if (!sizeName) return;
    if (sizeOptions.some((s) => s.size.toLowerCase() === sizeName.toLowerCase())) {
      toast.error('Size already exists');
      return;
    }

    const currentPrice = parseFloat(watch('price')) || 0;
    const currentStock = parseInt(watch('stock')) || 0;
    const currentSku = watch('sku') || 'PROD';
    const mainImages = watch('images') || [];
    const mainThumb = mainImages[0] || '';
    const mainThumbs = mainImages.length > 0 ? [...mainImages] : (mainThumb ? [mainThumb] : []);

    const updated = [
      ...sizeOptions,
      {
        size: sizeName,
        colors: [
          {
            color: 'Default',
            hex: '#1e293b',
            stock: currentStock,
            price: currentPrice,
            sku: `${currentSku}-${sizeName.replace(/\s+/g, '-').toUpperCase()}`,
            thumbnail: mainThumb,
            thumbnails: mainThumbs,
          },
        ],
      },
    ];
    setSizeOptions(updated);
    setActiveSizeIdx(updated.length - 1);
    setNewSizeInput('');
  };

  const removeSizeOption = (idx) => {
    const updated = sizeOptions.filter((_, i) => i !== idx);
    setSizeOptions(updated);
    if (activeSizeIdx >= updated.length) {
      setActiveSizeIdx(Math.max(0, updated.length - 1));
    }
  };

  const addColorOption = (sizeIdx) => {
    const currentSize = sizeOptions[sizeIdx];
    const firstColor = currentSize.colors[0];
    const currentPrice = parseFloat(watch('price')) || (firstColor?.price ?? 0);
    const currentStock = parseInt(watch('stock')) || (firstColor?.stock ?? 0);
    const baseSku = watch('sku') || 'PROD';
    const mainImages = watch('images') || [];
    const defaultThumb = mainImages[0] || firstColor?.thumbnail || '';
    const defaultThumbs = mainImages.length > 0
      ? [...mainImages]
      : (firstColor?.thumbnails || (defaultThumb ? [defaultThumb] : []));

    const newColor = {
      color: `Color ${currentSize.colors.length + 1}`,
      hex: '#1e293b',
      stock: currentStock,
      price: currentPrice,
      sku: `${baseSku}-${currentSize.size.toUpperCase()}-C${currentSize.colors.length + 1}`,
      thumbnail: defaultThumb,
      thumbnails: [...defaultThumbs],
    };
    const updated = [...sizeOptions];
    updated[sizeIdx].colors.push(newColor);
    setSizeOptions(updated);
  };

  const updateColorOption = (sizeIdx, colorIdx, field, val) => {
    const updated = [...sizeOptions];
    updated[sizeIdx].colors[colorIdx][field] = val;
    setSizeOptions(updated);
  };

  const removeColorOption = (sizeIdx, colorIdx) => {
    const updated = [...sizeOptions];
    updated[sizeIdx].colors = updated[sizeIdx].colors.filter((_, i) => i !== colorIdx);
    setSizeOptions(updated);
  };

  const duplicateColorsToAllSizes = (sourceSizeIdx) => {
    const sourceColors = sizeOptions[sourceSizeIdx]?.colors || [];
    if (sourceColors.length === 0) return;
    const updated = sizeOptions.map((s, idx) => {
      if (idx === sourceSizeIdx) return s;
      return {
        ...s,
        colors: sourceColors.map((c) => ({
          ...c,
          sku: `${watch('sku') || 'PROD'}-${s.size.toUpperCase()}-${c.color.toUpperCase()}`,
        })),
      };
    });
    setSizeOptions(updated);
    toast.success('Variant options replicated to all sizes!');
  };

  const onSubmit = (data) => {
    const tagsArr = data.tags?.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean) || [];

    const formattedSpecifications = specifications
      .filter((s) => s.key && s.key.trim() && s.value && s.value.trim())
      .map((s) => ({ key: s.key.trim(), value: s.value.trim() }));

    const formattedHighlights = highlights
      .map((h) => h.trim())
      .filter(Boolean);

    const formattedVariants = sizeOptions.map((s) => ({
      name: s.size,
      options: (s.colors || []).map((c) => {
        const thumbs = Array.isArray(c.thumbnails) && c.thumbnails.length > 0
          ? c.thumbnails
          : (c.thumbnail ? [c.thumbnail] : []);
        return {
          label: c.color || 'Default',
          price: parseFloat(c.price) || 0,
          stock: parseInt(c.stock) || 0,
          sku: c.sku || '',
          thumbnail: thumbs[0] || c.thumbnail || '',
          thumbnails: thumbs,
        };
      }),
    }));

    let finalStock = data.vertical === 'services' ? 999 : (parseInt(data.stock) || 0);
    if (data.vertical !== 'services' && formattedVariants.length > 0) {
      let varStockSum = 0;
      let hasVarOptions = false;
      for (const group of formattedVariants) {
        for (const opt of group.options || []) {
          varStockSum += (parseInt(opt.stock) || 0);
          hasVarOptions = true;
        }
      }
      if (hasVarOptions) {
        finalStock = varStockSum;
      }
    }

    const input = {
      name: data.name,
      description: data.description || data.name || 'Product description',
      ...(data.shortDescription && { shortDescription: data.shortDescription }),
      price: parseFloat(data.price),
      ...(data.comparePrice && { comparePrice: parseFloat(data.comparePrice) }),
      stock: finalStock,
      ...(data.sku && { sku: data.sku }),
      categoryId: data.categoryId,
      images: data.images?.length
        ? data.images
        : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'],
      ...(tagsArr.length > 0 && { tags: tagsArr }),
      isFeatured: Boolean(data.isFeatured),
      isDeals: Boolean(data.isDeals),
      freeShipping: Boolean(data.freeShipping),
      disableCOD: Boolean(data.disableCOD),
      isVeg: data.isVeg !== undefined ? Boolean(data.isVeg) : true,
      allowCookingInstructions: data.allowCookingInstructions !== undefined ? Boolean(data.allowCookingInstructions) : true,
      vertical: data.vertical || 'shopping',
      ...(data.unitMeasure && { unitMeasure: data.unitMeasure }),
      ...(data.restaurantName && { restaurantName: data.restaurantName }),
      ...(data.preparationTime && { preparationTime: parseInt(data.preparationTime) || 25 }),
      ...(data.cuisine && { cuisine: data.cuisine.split(',').map((s) => s.trim()).filter(Boolean) }),
      ...(data.vertical === 'services'
        ? {
            serviceDuration: data.serviceDuration || '',
            warranty: data.warranty || '',
            includedFeatures: data.includedFeatures
              ? (Array.isArray(data.includedFeatures) ? data.includedFeatures : data.includedFeatures.split(',').map((s) => s.trim()).filter(Boolean))
              : [],
            specifications: [],
            variants: [],
          }
        : {
            ...(data.serviceDuration && { serviceDuration: data.serviceDuration }),
            ...(data.warranty && { warranty: data.warranty }),
            ...(data.includedFeatures && {
              includedFeatures: Array.isArray(data.includedFeatures)
                ? data.includedFeatures
                : data.includedFeatures.split(',').map((s) => s.trim()).filter(Boolean),
            }),
            specifications: formattedSpecifications,
            variants: formattedVariants,
          }),
      highlights: formattedHighlights,
      ...(data.commissionType && { commissionType: data.commissionType }),
      ...(data.commissionValue !== undefined && data.commissionValue !== '' && { commissionValue: parseFloat(data.commissionValue) || 0 }),
      addons: addons.filter((a) => a.name && a.price >= 0).map((a) => ({ name: a.name, price: parseFloat(a.price) || 0, icon: a.icon || '🍽️' })),
      taxSettingId: data.taxSettingId || null,
    };

    if (isEdit && product?._id) {
      updateProduct({ variables: { id: product._id, input } });
    } else {
      createProduct({ variables: { input } });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex flex-col justify-between overflow-hidden"
    >
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 20, opacity: 0 }}
        className="w-full h-full bg-slate-50 flex flex-col overflow-hidden"
      >
        {/* Top Header Bar */}
        <header className="bg-white border-b border-slate-200 px-6 sm:px-8 py-4 flex items-center justify-between shadow-xs flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center font-black">
              {isDuplicating ? (
                <DocumentDuplicateIcon className="w-5 h-5" />
              ) : isEdit ? (
                <PencilIcon className="w-5 h-5" />
              ) : (
                <PlusIcon className="w-5 h-5" />
              )}
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-black text-slate-900">
                {isDuplicating ? 'Duplicate Product' : isEdit ? 'Edit Product' : 'Add New Product'}
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                {isDuplicating
                  ? 'Cloning product configuration with size, colors, and settings'
                  : 'Manage product details, pricing, inventory, categories & variations'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit(onSubmit)}
              disabled={loading}
              className="btn-primary px-6 py-2 text-sm font-bold shadow-md shadow-primary-500/20 disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? (
                <>
                  <ArrowPathIcon className="w-4 h-4 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : isDuplicating ? (
                <>
                  <DocumentDuplicateIcon className="w-4 h-4" />
                  <span>Save as New Product</span>
                </>
              ) : isEdit ? (
                <>
                  <CheckIcon className="w-4 h-4" />
                  <span>Update Product</span>
                </>
              ) : (
                <>
                  <PlusIcon className="w-4 h-4" />
                  <span>Publish Product</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl ml-1 transition-colors"
            >
              <XMarkIcon className="w-6 h-6" />
            </button>
          </div>
        </header>

        {/* Full Screen Scrollable Body */}
        <div className="flex-1 overflow-y-auto px-6 sm:px-8 py-8 custom-scrollbar">
          <div className="max-w-6xl mx-auto space-y-8">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* SECTION 1: Basic Information & Business Vertical */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2.5">
                    <span className="w-7 h-7 rounded-lg bg-primary-100 text-primary-700 font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <h3 className="font-extrabold text-base text-slate-900">General Information</h3>
                  </div>
                  <span className="text-xs font-semibold text-slate-400">Required attributes</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Business Vertical *
                    </label>
                    <select
                      {...register('vertical')}
                      value={watch('vertical') || 'shopping'}
                      disabled={isVendor}
                      onChange={(e) => {
                        const newV = e.target.value;
                        setValue('vertical', newV);
                        if (newV !== (product?.vertical || initialVertical)) {
                          setValue('categoryId', '');
                        }
                      }}
                      className="input-field font-semibold bg-slate-50 border-slate-200 disabled:bg-slate-100 disabled:text-slate-500 disabled:cursor-not-allowed"
                    >
                      <option value="shopping">🛍️ Shopping (Suaaka Mall)</option>
                      <option value="food">🍔 Food Delivery (Suaaka Food)</option>
                      <option value="grocery">🥦 Grocery (Suaaka Fresh)</option>
                      <option value="services">🛠️ Services (Suaaka Expert Services)</option>
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Product / Item Name *
                    </label>
                    <input
                      {...register('name', { required: 'Product name is required' })}
                      className="input-field font-medium"
                      placeholder="e.g. Slim-Fit Cotton Chino Pants / Organic Alphonso Mangoes"
                    />
                    {errors.name && <p className="text-xs text-rose-500 mt-1">{errors.name.message}</p>}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Price (₹) *
                    </label>
                    <input
                      {...register('price', { required: 'Price is required', min: 0 })}
                      type="number"
                      step="0.01"
                      className="input-field font-bold font-mono text-slate-900"
                      placeholder="499.00"
                    />
                    {errors.price && <p className="text-xs text-rose-500 mt-1">{errors.price.message}</p>}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Compare Price (₹)
                    </label>
                    <input
                      {...register('comparePrice')}
                      type="number"
                      step="0.01"
                      className="input-field font-mono"
                      placeholder="699.00 (Optional original price)"
                    />
                  </div>

                  {selectedVertical === 'services' ? (
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Service Timing / Duration *
                      </label>
                      <input
                        {...register('serviceDuration', {
                          required: selectedVertical === 'services' ? 'Service timing is required' : false,
                        })}
                        type="text"
                        className="input-field font-medium"
                        placeholder="e.g. 45 mins, 1-2 hours"
                      />
                      {errors.serviceDuration && (
                        <p className="text-xs text-rose-500 mt-1">{errors.serviceDuration.message}</p>
                      )}
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                        Base Stock / Inventory *
                      </label>
                      <input
                        {...register('stock', {
                          required: selectedVertical !== 'services' ? 'Stock is required' : false,
                          min: selectedVertical !== 'services' ? 0 : undefined,
                        })}
                        type="number"
                        className="input-field font-mono font-bold"
                        placeholder="50"
                      />
                      {errors.stock && <p className="text-xs text-rose-500 mt-1">{errors.stock.message}</p>}
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      {selectedVertical === 'services' ? 'Service Code (Optional)' : 'SKU (Stock Keeping Unit)'}
                    </label>
                    <input
                      {...register('sku')}
                      className="input-field uppercase font-mono"
                      placeholder={selectedVertical === 'services' ? 'e.g. SRV-AC-01' : 'e.g. SK-PNT-01'}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Category * ({selectedVertical.toUpperCase()})
                    </label>
                    <select
                      {...register('categoryId', { required: 'Category is required' })}
                      value={watch('categoryId') ? String(watch('categoryId')) : ''}
                      onChange={(e) =>
                        setValue('categoryId', e.target.value, { shouldValidate: true, shouldDirty: true })
                      }
                      className="input-field font-medium bg-slate-50"
                    >
                      <option value="">Select Category</option>
                      {formattedCategoryOptions.map((c) => (
                        <option key={String(c._id)} value={String(c._id)}>
                          {c.displayName}
                        </option>
                      ))}
                    </select>
                    {errors.categoryId && (
                      <p className="text-xs text-rose-500 mt-1">{errors.categoryId.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                      Search Tags (Comma separated)
                    </label>
                    <input
                      {...register('tags')}
                      className="input-field"
                      placeholder="fashion, cotton, kids, summer, casual"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Short Description
                  </label>
                  <input
                    {...register('shortDescription')}
                    className="input-field text-sm"
                    placeholder="Brief highlights shown on cards and summary..."
                  />
                </div>

                <RichTextEditor
                  value={watch('description') || ''}
                  onChange={(val) => setValue('description', val, { shouldValidate: true, shouldDirty: true })}
                  error={errors.description?.message}
                  label="Detailed Product Description"
                  required={true}
                  placeholder="Describe your product here... Type freely and format using the visual toolbar above."
                />

                {/* Product Specifications Manager (Physical Products Only - Hidden for Services) */}
                {selectedVertical !== 'services' && (
                  <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                          <span className="text-base">📋</span> Product Specifications
                        </h4>
                        <p className="text-[11px] text-slate-500 font-medium">
                          Key-value attributes shown on customer website under Specifications tab (e.g. Fabric: 100% Cotton)
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={autoExtractSpecifications}
                        className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1 shadow-2xs cursor-pointer"
                        title="Parse key-value pairs from description"
                      >
                        ✨ Extract Specs from Description
                      </button>
                    </div>

                    {/* Preset Quick Add Buttons */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[11px] font-bold text-slate-500">Quick Presets:</span>
                      {['Fabric', 'Fit', 'Style Number', 'Pattern', 'Neck', 'Sleeve', 'Care Instructions'].map((presetKey) => (
                        <button
                          key={presetKey}
                          type="button"
                          onClick={() => {
                            if (!specifications.some((s) => s.key.toLowerCase() === presetKey.toLowerCase())) {
                              setSpecifications([...specifications, { key: presetKey, value: '' }]);
                            }
                          }}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 shadow-2xs transition-all cursor-pointer"
                        >
                          + {presetKey}
                        </button>
                      ))}
                    </div>

                    {/* Specifications List */}
                    {specifications.length === 0 ? (
                      <div className="text-center py-4 border-2 border-dashed border-slate-200 rounded-xl bg-white">
                        <p className="text-xs text-slate-400 font-medium">No specifications added yet.</p>
                        <button
                          type="button"
                          onClick={() => setSpecifications([{ key: '', value: '' }])}
                          className="mt-2 text-xs font-bold text-primary-600 hover:text-primary-700 cursor-pointer"
                        >
                          + Add First Specification
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                        {specifications.map((spec, sIdx) => (
                          <div key={sIdx} className="flex items-center gap-2">
                            <input
                              type="text"
                              placeholder="Key (e.g. Fabric)"
                              value={spec.key}
                              onChange={(e) => {
                                const updated = [...specifications];
                                updated[sIdx].key = e.target.value;
                                setSpecifications(updated);
                              }}
                              className="w-1/3 input-field text-xs py-2 bg-white"
                            />
                            <input
                              type="text"
                              placeholder="Value (e.g. 100% Super Combed Cotton)"
                              value={spec.value}
                              onChange={(e) => {
                                const updated = [...specifications];
                                updated[sIdx].value = e.target.value;
                                setSpecifications(updated);
                              }}
                              className="flex-1 input-field text-xs py-2 bg-white"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                setSpecifications(specifications.filter((_, i) => i !== sIdx));
                              }}
                              className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-all cursor-pointer"
                              title="Remove specification"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    {specifications.length > 0 && (
                      <div className="flex justify-start">
                        <button
                          type="button"
                          onClick={() => setSpecifications([...specifications, { key: '', value: '' }])}
                          className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                        >
                          <PlusIcon className="w-3.5 h-3.5" /> Add Another Specification
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Product Highlights / Trust Badges Manager */}
                <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div>
                      <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                        <span className="text-base">🛡️</span> Product Highlights & Trust Badges
                      </h4>
                      <p className="text-[11px] text-slate-500 font-medium">
                        Custom badges displayed on customer product page (e.g. Fast Delivery Guaranteed, Authentic Guarantee, 30-Day Easy Returns)
                      </p>
                    </div>
                  </div>

                  {/* Preset Quick Add Buttons */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[11px] font-bold text-slate-500">Quick Presets:</span>
                    {[
                      'Fast Delivery Guaranteed',
                      'Authentic Guarantee',
                      '30-Day Easy Returns',
                      '7-Day Replacement',
                      '1-Year Warranty',
                      'COD Available',
                      '100% Handloom / Organic',
                      'Verified Seller',
                    ].map((presetText) => (
                      <button
                        key={presetText}
                        type="button"
                        onClick={() => {
                          if (!highlights.some((h) => h.toLowerCase() === presetText.toLowerCase())) {
                            setHighlights([...highlights, presetText]);
                          }
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 shadow-2xs transition-all cursor-pointer"
                      >
                        + {presetText}
                      </button>
                    ))}
                  </div>

                  {/* Highlights List */}
                  {highlights.length === 0 ? (
                    <div className="text-center py-4 border-2 border-dashed border-slate-200 rounded-xl bg-white">
                      <p className="text-xs text-slate-400 font-medium">No highlights added yet.</p>
                      <button
                        type="button"
                        onClick={() => setHighlights(['Fast Delivery Guaranteed', 'Authentic Guarantee', '30-Day Easy Returns'])}
                        className="mt-2 text-xs font-bold text-primary-600 hover:text-primary-700 cursor-pointer"
                      >
                        + Add Default Highlights
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                      {highlights.map((highlight, hIdx) => (
                        <div key={hIdx} className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-400 w-6 text-center">{hIdx + 1}.</span>
                          <input
                            type="text"
                            placeholder="e.g. Fast Delivery Guaranteed or 1 Year Warranty"
                            value={highlight}
                            onChange={(e) => {
                              const updated = [...highlights];
                              updated[hIdx] = e.target.value;
                              setHighlights(updated);
                            }}
                            className="flex-1 input-field text-xs py-2 bg-white"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              setHighlights(highlights.filter((_, i) => i !== hIdx));
                            }}
                            className="p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-all cursor-pointer"
                            title="Remove highlight"
                          >
                            <TrashIcon className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex justify-start">
                    <button
                      type="button"
                      onClick={() => setHighlights([...highlights, ''])}
                      className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <PlusIcon className="w-3.5 h-3.5" /> Add Highlight / Badge
                    </button>
                  </div>
                </div>

                {/* Admin Commission Settings (Visible to Vendor and Admin) */}
                <div className="p-5 bg-indigo-50/70 rounded-2xl border border-indigo-200/80 space-y-4">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-indigo-950 font-bold text-xs uppercase tracking-wider">
                      <SparklesIcon className="w-4 h-4 text-indigo-600" />
                      {user?.role === 'vendor' ? 'Admin Commission (Proposed Share)' : 'Admin Commission Settings'}
                    </div>
                    {user?.role === 'vendor' ? (
                      <span className="text-[11px] font-bold text-indigo-700 bg-white px-2.5 py-0.5 rounded-full border border-indigo-200 shadow-2xs">
                        Admin will review this in your request
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-slate-600 bg-white px-2.5 py-0.5 rounded-full border border-slate-200">
                        Admin Panel
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {user?.role === 'vendor'
                      ? 'Specify the commission percentage or flat fee you propose to share with the platform per order. Admin will review and verify this upon product approval.'
                      : 'Commission rate deducted from vendor payout upon successful customer orders.'}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Commission Type
                      </label>
                      <select
                        {...register('commissionType')}
                        className="input-field bg-white border-slate-200 font-semibold"
                      >
                        <option value="percentage">Percentage (%)</option>
                        <option value="flat">Flat Amount (₹)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Commission Value {watch('commissionType') === 'flat' ? '(₹)' : '(%)'}
                      </label>
                      <input
                        {...register('commissionValue')}
                        type="number"
                        step="0.01"
                        min="0"
                        className="input-field font-mono font-bold bg-white"
                        placeholder={watch('commissionType') === 'flat' ? '50.00' : '10.00'}
                      />
                    </div>
                  </div>

                  {/* Real-time calculated payout summary */}
                  {(() => {
                    const priceVal = parseFloat(watch('price')) || 0;
                    const cType = watch('commissionType') || 'percentage';
                    const cVal = parseFloat(watch('commissionValue')) || 0;
                    const commAmount = cType === 'flat' ? cVal : (priceVal * cVal) / 100;
                    const vendorShare = Math.max(0, priceVal - commAmount);
                    if (priceVal <= 0) return null;
                    return (
                      <div className="bg-white p-3.5 rounded-xl border border-indigo-100 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-slate-800">
                        <div>Price: <strong>₹{priceVal.toFixed(2)}</strong></div>
                        <div>Platform Fee ({cType === 'flat' ? `₹${cVal}` : `${cVal}%`}): <strong className="text-indigo-600">₹{commAmount.toFixed(2)}</strong></div>
                        <div>{user?.role === 'vendor' ? 'Your Net Payout' : 'Vendor Net'}: <strong className="text-emerald-600 font-bold">₹{vendorShare.toFixed(2)}</strong></div>
                      </div>
                    );
                  })()}
                </div>
              </div>

                {/* Tax Category Selection */}
                {allTaxSettings.length > 0 && (
                  <div className="p-5 bg-amber-50/70 rounded-2xl border border-amber-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-amber-950 font-bold text-xs uppercase tracking-wider">
                      <span className="text-sm">📋</span>
                      Tax Category
                    </div>
                    <p className="text-[11px] text-slate-600 leading-relaxed">
                      Select the applicable tax rate for this product. This will be used to calculate GST on customer orders.
                    </p>
                    <select
                      {...register('taxSettingId')}
                      className="input-field bg-white border-slate-200 font-semibold text-sm"
                    >
                      <option value="">No Tax / Default</option>
                      {allTaxSettings.map((tax) => (
                        <option key={tax._id} value={tax._id}>
                          {tax.name} — {tax.rate}% GST
                        </option>
                      ))}
                    </select>
                  </div>
                )}

              {/* SECTION 2: Vertical Specific Fields */}
              {selectedVertical === 'food' && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-orange-200 shadow-xs space-y-5 bg-gradient-to-br from-orange-50/40 to-white">
                  <div className="flex items-center gap-2.5 border-b border-orange-100 pb-3">
                    <span className="w-7 h-7 rounded-lg bg-orange-100 text-orange-700 font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="font-extrabold text-base text-orange-900">
                      Food & Restaurant Attributes
                    </h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Restaurant / Outlet Name
                      </label>
                      <input
                        {...register('restaurantName')}
                        className="input-field"
                        placeholder="e.g. Behrouz Biryani"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Cuisines (Comma separated)
                      </label>
                      <input
                        {...register('cuisine')}
                        className="input-field"
                        placeholder="Biryani, North Indian, Mughlai"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Preparation Time (Minutes)
                      </label>
                      <input
                        {...register('preparationTime')}
                        type="number"
                        className="input-field"
                        placeholder="25"
                      />
                    </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-2">
                      Dietary Classification *
                    </label>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => setValue('isVeg', true)}
                        className={`flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-bold transition-all ${
                          watch('isVeg') !== false
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span className="w-3.5 h-3.5 rounded-xs border-2 border-emerald-600 flex items-center justify-center bg-white">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
                        </span>
                        🟢 Pure Veg
                      </button>
                      <button
                        type="button"
                        onClick={() => setValue('isVeg', false)}
                        className={`flex-1 flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl border text-xs font-bold transition-all ${
                          watch('isVeg') === false
                            ? 'bg-red-50 border-red-500 text-red-800 shadow-xs'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span className="w-3.5 h-3.5 rounded-xs border-2 border-red-600 flex items-center justify-center bg-white">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-600" />
                        </span>
                        🔴 Non-Veg
                      </button>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-orange-100/80">
                    <label className="flex items-center justify-between cursor-pointer">
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">
                          🍳 Allow Cooking Instructions
                        </span>
                        <span className="text-[11px] text-slate-500 font-normal block">
                          Turn off for sweets, beverages, bakery, ice cream & pre-packaged items.
                        </span>
                      </div>
                      <input
                        type="checkbox"
                        {...register('allowCookingInstructions')}
                        defaultChecked={watch('allowCookingInstructions') !== false}
                        onChange={(e) => setValue('allowCookingInstructions', e.target.checked)}
                        className="w-4 h-4 rounded text-orange-600 focus:ring-orange-500 cursor-pointer"
                      />
                    </label>
                  </div>
                </div>

                  {/* Add-ons / Toppings Section */}
                  <div className="mt-5 pt-5 border-t border-orange-100">
                    <div className="flex items-center justify-between mb-3">
                      <label className="block text-xs font-bold text-slate-700">
                        🧀 Add-ons / Toppings (Optional extras customers can add)
                      </label>
                      <button
                        type="button"
                        onClick={() => setAddons([...addons, { name: '', price: 0, icon: '🍽️' }])}
                        className="px-3 py-1.5 bg-white hover:bg-orange-50 border border-orange-200 text-orange-700 text-xs font-bold rounded-xl shadow-2xs flex items-center gap-1 transition-all cursor-pointer"
                      >
                        <PlusIcon className="w-3.5 h-3.5" /> Add Item
                      </button>
                    </div>
                    {addons.length === 0 ? (
                      <p className="text-[11px] text-slate-400 italic">No add-ons configured. Click "Add Item" to add optional extras.</p>
                    ) : (
                      <div className="space-y-2">
                        {addons.map((addon, aIdx) => (
                          <div key={aIdx} className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-200">
                            {/* Emoji Icon Selector */}
                            <div className="relative group">
                              <button
                                type="button"
                                className="w-9 h-9 rounded-lg bg-orange-50 border border-orange-200 text-lg flex items-center justify-center hover:bg-orange-100 transition-all cursor-pointer"
                                title="Select icon"
                              >
                                {addon.icon || '🍽️'}
                              </button>
                              <div className="hidden group-hover:flex absolute top-full left-0 mt-1 z-10 bg-white border border-slate-200 rounded-xl shadow-lg p-2 gap-1 flex-wrap w-44">
                                {['🧀', '🌶️', '🥤', '🥫', '🍽️', '🥗', '🍟', '🧁', '🍕', '🥚', '🧈', '🍞', '🥩', '🍗', '🫕', '🍰'].map((emoji) => (
                                  <button
                                    key={emoji}
                                    type="button"
                                    onClick={() => {
                                      const updated = [...addons];
                                      updated[aIdx].icon = emoji;
                                      setAddons(updated);
                                    }}
                                    className={`w-8 h-8 rounded-lg text-base flex items-center justify-center hover:bg-orange-50 transition-all cursor-pointer ${
                                      addon.icon === emoji ? 'bg-orange-100 ring-2 ring-orange-400' : ''
                                    }`}
                                  >
                                    {emoji}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <input
                              type="text"
                              placeholder="Add-on name (e.g. Extra Cheese)"
                              value={addon.name}
                              onChange={(e) => {
                                const updated = [...addons];
                                updated[aIdx].name = e.target.value;
                                setAddons(updated);
                              }}
                              className="flex-1 input-field text-xs py-2"
                            />
                            <div className="flex items-center gap-1">
                              <span className="text-xs font-bold text-slate-500">₹</span>
                              <input
                                type="number"
                                placeholder="0"
                                min="0"
                                step="1"
                                value={addon.price}
                                onChange={(e) => {
                                  const updated = [...addons];
                                  updated[aIdx].price = e.target.value;
                                  setAddons(updated);
                                }}
                                className="w-20 input-field text-xs py-2 font-mono"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => setAddons(addons.filter((_, i) => i !== aIdx))}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-all cursor-pointer"
                              title="Remove add-on"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
              </div>
            )}

              {selectedVertical === 'grocery' && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-emerald-200 shadow-xs space-y-5 bg-gradient-to-br from-emerald-50/40 to-white">
                  <div className="flex items-center gap-2.5 border-b border-emerald-100 pb-3">
                    <span className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="font-extrabold text-base text-emerald-900">
                      Grocery & Fresh Produce Options
                    </h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Unit Measure (e.g. 500g, 1kg (4-5 pcs), 250g Bunch)
                      </label>
                      <input
                        {...register('unitMeasure')}
                        className="input-field"
                        placeholder="e.g. 500g (3-4 pcs)"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Nutritional Highlights (Comma separated)
                      </label>
                      <input
                        {...register('nutritionalHighlights')}
                        className="input-field"
                        placeholder="Healthy Fats, Vitamin C, Organic"
                      />
                    </div>
                  </div>
                </div>
              )}

              {selectedVertical === 'services' && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-200 shadow-xs space-y-5 bg-gradient-to-br from-blue-50/40 to-white">
                  <div className="flex items-center gap-2.5 border-b border-blue-100 pb-3">
                    <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="font-extrabold text-base text-blue-900">Service Guarantee & Inclusions</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Warranty / Guarantee Details
                      </label>
                      <input
                        {...register('warranty')}
                        className="input-field"
                        placeholder="e.g. 30 Days Warranty, 90 Days Spares Guarantee"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Included Features & Checklist (Comma separated)
                      </label>
                      <input
                        {...register('includedFeatures')}
                        className="input-field"
                        placeholder="Motor inspection, Drain pump descaling, PCB testing, Final quality check"
                      />
                      <p className="text-[11px] text-slate-400 mt-1">
                        List each feature included in this service package separated by commas. Shown as checkmarks on the website.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* SECTION 3: SIZE & COLOR VARIANT MATRIX (Shopping Section Only) */}
              {selectedVertical === 'shopping' && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-blue-200 shadow-sm space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                    <div className="flex items-center gap-2.5">
                      <span className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                        3
                      </span>
                      <div>
                        <h3 className="font-extrabold text-base text-slate-900">
                          Size & Color Variant Options
                        </h3>
                        <p className="text-xs text-slate-500 font-medium">
                          Create, edit, and manage sizes with dedicated colors, prices & stock
                        </p>
                      </div>
                    </div>

                    {/* Add Size Input */}
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={newSizeInput}
                        onChange={(e) => setNewSizeInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            addSizeOption();
                          }
                        }}
                        placeholder="e.g. S, M, L, XL, 5 Years..."
                        className="px-3.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 w-44"
                      />
                      <button
                        type="button"
                        onClick={addSizeOption}
                        className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1 transition-all active:scale-95"
                      >
                        <PlusIcon className="w-3.5 h-3.5" />
                        <span>Add Size</span>
                      </button>
                    </div>
                  </div>

                  {sizeOptions.length === 0 ? (
                    <div className="py-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                      <p className="text-2xl">📐</p>
                      <h4 className="text-sm font-bold text-slate-700">No Size & Color Variants</h4>
                      <p className="text-xs text-slate-400 max-w-sm mx-auto">
                        If this product comes in different sizes (e.g. S, M, L, 5 Years) or colors, type a size above and click <strong>Add Size</strong>.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {/* Size Tabs Row (Matching UI Reference) */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                        {sizeOptions.map((sizeItem, sIdx) => {
                          const isSelected = activeSizeIdx === sIdx;
                          return (
                            <div
                              key={sIdx}
                              onClick={() => setActiveSizeIdx(sIdx)}
                              className={`p-4 rounded-2xl border-2 transition-all cursor-pointer relative group flex flex-col justify-between ${
                                isSelected
                                  ? 'border-blue-600 bg-blue-50/50 shadow-xs'
                                  : 'border-slate-200 bg-white hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <h4 className="font-extrabold text-sm text-slate-900">
                                  {sizeItem.size}
                                </h4>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setConfirmState({
                                      title: `Delete Size "${sizeItem.size}"?`,
                                      message: `Are you sure you want to delete size "${sizeItem.size}" and all its color options?`,
                                      onConfirm: () => removeSizeOption(sIdx),
                                    });
                                  }}
                                  className="text-slate-300 hover:text-rose-600 transition-colors p-1"
                                  title="Delete size"
                                >
                                  <TrashIcon className="w-3.5 h-3.5" />
                                </button>
                              </div>
                              <span className="text-xs font-bold text-blue-600 mt-2">
                                {sizeItem.colors.length} {sizeItem.colors.length === 1 ? 'color' : 'colors'}
                              </span>
                            </div>
                          );
                        })}
                      </div>

                      {/* Active Size Scope Detail Card (Matching UI Reference) */}
                      {sizeOptions[activeSizeIdx] && (
                        <div className="bg-slate-50 border border-slate-200/90 rounded-3xl p-6 space-y-6">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
                            <div className="flex items-center gap-3">
                              <h3 className="text-xl font-black text-slate-900">
                                {sizeOptions[activeSizeIdx].size}
                              </h3>
                              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-700">
                                {sizeOptions[activeSizeIdx].colors.length} Colors
                              </span>
                              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700">
                                Active Tier
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              {sizeOptions.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => duplicateColorsToAllSizes(activeSizeIdx)}
                                  className="px-3.5 py-1.5 bg-white border border-slate-200 hover:border-blue-300 text-slate-700 hover:text-blue-700 rounded-xl text-xs font-bold shadow-2xs flex items-center gap-1.5 transition-all"
                                  title="Replicate this size's options to all other sizes"
                                >
                                  <DocumentDuplicateIcon className="w-3.5 h-3.5 text-blue-600" />
                                  <span>Replicate to all sizes</span>
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => addColorOption(activeSizeIdx)}
                                className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-2xs flex items-center gap-1.5 transition-all"
                              >
                                <PlusIcon className="w-3.5 h-3.5" />
                                <span>Add Color Option under {sizeOptions[activeSizeIdx].size}</span>
                              </button>
                            </div>
                          </div>

                          {/* Color Variants List */}
                          <div className="space-y-3">
                            {sizeOptions[activeSizeIdx].colors.map((colorItem, cIdx) => (
                              <div
                                key={cIdx}
                                className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xs hover:border-blue-300 transition-all"
                              >
                                <div className="flex items-center gap-3 flex-1 min-w-0">
                                  <div className="relative flex-shrink-0" title="Click to pick a color">
                                    <input
                                      type="color"
                                      value={colorItem.hex || '#1e293b'}
                                      onChange={(e) =>
                                        updateColorOption(activeSizeIdx, cIdx, 'hex', e.target.value)
                                      }
                                      className="absolute inset-0 opacity-0 w-9 h-9 cursor-pointer z-10"
                                    />
                                    <div
                                      style={{ backgroundColor: colorItem.hex || '#1e293b' }}
                                      className="w-9 h-9 rounded-full border-2 border-white shadow-md cursor-pointer hover:scale-105 transition-transform flex items-center justify-center"
                                    />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <input
                                      type="text"
                                      value={colorItem.color}
                                      onChange={(e) =>
                                        updateColorOption(activeSizeIdx, cIdx, 'color', e.target.value)
                                      }
                                      placeholder="Color name (e.g. Navy Blue, Crimson)"
                                      className="font-extrabold text-sm text-slate-900 bg-slate-50 hover:bg-white border border-slate-200 focus:border-blue-500 rounded-lg px-2.5 py-1 focus:outline-none w-full transition-all"
                                    />
                                    <div className="flex items-center gap-2 mt-1">
                                      <span className="text-[10px] uppercase font-bold text-slate-400">
                                        SKU:
                                      </span>
                                      <input
                                        type="text"
                                        value={colorItem.sku}
                                        onChange={(e) =>
                                          updateColorOption(activeSizeIdx, cIdx, 'sku', e.target.value)
                                        }
                                        placeholder="Color SKU"
                                        className="text-xs font-mono text-slate-600 border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none bg-transparent"
                                      />
                                    </div>
                                  </div>
                                </div>

                                <div className="flex items-center gap-4 flex-wrap sm:flex-nowrap">
                                  <div>
                                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                                      Units / Stock
                                    </span>
                                    <input
                                      type="number"
                                      value={colorItem.stock}
                                      onChange={(e) =>
                                        updateColorOption(
                                          activeSizeIdx,
                                          cIdx,
                                          'stock',
                                          parseInt(e.target.value) || 0
                                        )
                                      }
                                      className="w-24 px-3 py-1 text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                                    />
                                  </div>

                                  <div>
                                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                                      Price (₹)
                                    </span>
                                    <input
                                      type="number"
                                      step="0.01"
                                      value={colorItem.price}
                                      onChange={(e) =>
                                        updateColorOption(
                                          activeSizeIdx,
                                          cIdx,
                                          'price',
                                          parseFloat(e.target.value) || 0
                                        )
                                      }
                                      className="w-28 px-3 py-1 text-xs font-mono font-bold bg-slate-50 border border-slate-200 rounded-xl"
                                    />
                                  </div>

                                  {/* Variant Thumbnails */}
                                  <div>
                                    <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                                      Thumbnails / Images
                                    </span>
                                    <div className="flex items-center gap-2 flex-wrap">
                                      {(colorItem.thumbnails && colorItem.thumbnails.length > 0
                                        ? colorItem.thumbnails
                                        : (colorItem.thumbnail ? [colorItem.thumbnail] : [])
                                      ).map((imgUrl, imgIdx) => (
                                        <div key={imgIdx} className="relative group">
                                          <img
                                            src={imgUrl}
                                            alt={`variant-${imgIdx}`}
                                            className="w-10 h-10 rounded-lg object-cover border border-slate-200 shadow-2xs"
                                          />
                                          <button
                                            type="button"
                                            onClick={() => {
                                              setConfirmState({
                                                title: 'Remove Variant Image?',
                                                message: 'Are you sure you want to remove this variant thumbnail image?',
                                                onConfirm: () => {
                                                  const currentList = colorItem.thumbnails && colorItem.thumbnails.length > 0
                                                    ? colorItem.thumbnails
                                                    : (colorItem.thumbnail ? [colorItem.thumbnail] : []);
                                                  const updatedList = currentList.filter((_, i) => i !== imgIdx);
                                                  updateColorOption(activeSizeIdx, cIdx, 'thumbnails', updatedList);
                                                  updateColorOption(activeSizeIdx, cIdx, 'thumbnail', updatedList[0] || '');
                                                },
                                              });
                                            }}
                                            className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-rose-500 text-white rounded-full flex items-center justify-center text-[8px] font-bold hover:bg-rose-600 shadow-xs"
                                            title="Remove image"
                                          >
                                            ✕
                                          </button>
                                        </div>
                                      ))}

                                      {variantUploadingMap[`${activeSizeIdx}-${cIdx}`] !== undefined ? (
                                        <div
                                          className="w-10 h-10 rounded-lg border-2 border-blue-500 bg-blue-50 flex flex-col items-center justify-center relative overflow-hidden shadow-2xs"
                                          title={`Uploading... ${variantUploadingMap[`${activeSizeIdx}-${cIdx}`]}%`}
                                        >
                                          <ArrowPathIcon className="w-4 h-4 text-blue-600 animate-spin" />
                                          <span className="text-[8px] font-black text-blue-700 mt-0.5 leading-none">
                                            {variantUploadingMap[`${activeSizeIdx}-${cIdx}`]}%
                                          </span>
                                          <div
                                            className="absolute bottom-0 left-0 h-1 bg-blue-600 transition-all duration-150"
                                            style={{ width: `${variantUploadingMap[`${activeSizeIdx}-${cIdx}`]}%` }}
                                          />
                                        </div>
                                      ) : (
                                        <label
                                          className="w-10 h-10 rounded-lg border-2 border-dashed border-slate-300 hover:border-blue-400 flex items-center justify-center cursor-pointer bg-slate-50 hover:bg-blue-50 transition-colors"
                                          title="Add image(s) for this variant"
                                        >
                                          <span className="text-base">📷</span>
                                          <input
                                            type="file"
                                            accept="image/*"
                                            multiple
                                            className="hidden"
                                            onChange={(e) => {
                                              const files = Array.from(e.target.files || []);
                                              if (files.length === 0) return;

                                              const uploadKey = `${activeSizeIdx}-${cIdx}`;
                                              setVariantUploadingMap((prev) => ({ ...prev, [uploadKey]: 0 }));
                                              const toastId = toast.loading(`Uploading ${files.length} image(s)...`);

                                              const formData = new FormData();
                                              files.forEach((f) => formData.append('images', f));

                                              const token = localStorage.getItem('adminToken');
                                              const apiUrl = import.meta.env.VITE_API_URL
                                                ? import.meta.env.VITE_API_URL.replace('/graphql', '')
                                                : 'https://ecommerce-api-yak7.onrender.com';

                                              const xhr = new XMLHttpRequest();
                                              xhr.open('POST', `${apiUrl}/api/upload/multiple`);
                                              if (token) {
                                                xhr.setRequestHeader('Authorization', `Bearer ${token}`);
                                              }

                                              xhr.upload.onprogress = (event) => {
                                                if (event.lengthComputable) {
                                                  const percent = Math.round((event.loaded / event.total) * 100);
                                                  setVariantUploadingMap((prev) => ({ ...prev, [uploadKey]: percent }));
                                                  toast.loading(`Uploading variant image (${percent}%)...`, { id: toastId });
                                                }
                                              };

                                              xhr.onload = () => {
                                                if (xhr.status >= 200 && xhr.status < 300) {
                                                  try {
                                                    const data = JSON.parse(xhr.responseText);
                                                    if (data.urls && data.urls.length > 0) {
                                                      const currentList = colorItem.thumbnails && colorItem.thumbnails.length > 0
                                                        ? colorItem.thumbnails
                                                        : (colorItem.thumbnail ? [colorItem.thumbnail] : []);
                                                      const newList = [...currentList, ...data.urls];
                                                      updateColorOption(activeSizeIdx, cIdx, 'thumbnails', newList);
                                                      updateColorOption(activeSizeIdx, cIdx, 'thumbnail', newList[0] || '');
                                                      toast.success(`${data.urls.length} variant image(s) uploaded!`, { id: toastId });
                                                    } else {
                                                      throw new Error('No URLs returned');
                                                    }
                                                  } catch (err) {
                                                    toast.error(err.message || 'Upload failed', { id: toastId });
                                                  }
                                                } else {
                                                  toast.error('Upload failed', { id: toastId });
                                                }
                                                setVariantUploadingMap((prev) => {
                                                  const next = { ...prev };
                                                  delete next[uploadKey];
                                                  return next;
                                                });
                                              };

                                              xhr.onerror = () => {
                                                toast.error('Network error during upload', { id: toastId });
                                                setVariantUploadingMap((prev) => {
                                                  const next = { ...prev };
                                                  delete next[uploadKey];
                                                  return next;
                                                });
                                              };

                                              xhr.send(formData);
                                            }}
                                          />
                                        </label>
                                      )}
                                    </div>
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      setConfirmState({
                                        title: `Delete Color Option "${colorItem.color || 'Default'}"?`,
                                        message: `Are you sure you want to delete color option "${colorItem.color || 'Default'}" under ${sizeOptions[activeSizeIdx]?.size || 'this size'}?`,
                                        onConfirm: () => removeColorOption(activeSizeIdx, cIdx),
                                      });
                                    }}
                                    className="p-2 text-slate-300 hover:text-rose-600 rounded-xl hover:bg-rose-50 transition-colors self-end md:self-center"
                                    title="Remove color"
                                  >
                                    <TrashIcon className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* SECTION 4: Images & Media */}
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
                <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4">
                  <span className="w-7 h-7 rounded-lg bg-primary-100 text-primary-700 font-bold text-xs flex items-center justify-center">
                    4
                  </span>
                  <h3 className="font-extrabold text-base text-slate-900">Product Media & Gallery</h3>
                </div>

                <MultiImageUpload
                  label="Upload Photos (Drag & Drop or Click to browse)"
                  value={watch('images')}
                  onChange={(urls) => setValue('images', urls, { shouldDirty: true })}
                />
              </div>

              {/* SECTION 5: Flags & Settings (Admin & SuperAdmin Only) */}
              {user?.role !== 'vendor' && (
                <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-4">
                  <div className="flex items-center gap-2.5 border-b border-slate-100 pb-4">
                    <span className="w-7 h-7 rounded-lg bg-primary-100 text-primary-700 font-bold text-xs flex items-center justify-center">
                      5
                    </span>
                    <h3 className="font-extrabold text-base text-slate-900">Shipping & Store Flags</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { name: 'isFeatured', label: '⭐ Featured Product', desc: 'Highlighted on Homepage' },
                      { name: 'isDeals', label: '🔥 Daily Deal', desc: 'Featured in Flash Deals tab' },
                      { name: 'freeShipping', label: '🚚 Free Shipping', desc: 'Zero delivery fee banner' },
                      { name: 'disableCOD', label: '💳 Prepaid Only', desc: 'Disables Cash On Delivery' },
                    ].map((opt) => (
                      <label
                        key={opt.name}
                        className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 cursor-pointer flex items-start gap-3 transition-colors"
                      >
                        <input
                          {...register(opt.name)}
                          type="checkbox"
                          className="rounded text-primary-600 focus:ring-primary-500 mt-1"
                        />
                        <div>
                          <span className="font-bold text-xs text-slate-900 block">{opt.label}</span>
                          <span className="text-[11px] text-slate-500 block">{opt.desc}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              )}



              {/* Bottom Action Submit Button */}
              <div className="flex items-center justify-end gap-4 pt-4 pb-8">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 text-sm font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-2xl shadow-xs transition-all"
                >
                  Discard Changes
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary px-8 py-3 text-sm font-bold shadow-lg shadow-primary-500/25 disabled:opacity-50 flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <ArrowPathIcon className="w-5 h-5 animate-spin" />
                      <span>Saving Product...</span>
                    </>
                  ) : isDuplicating ? (
                    <>
                      <DocumentDuplicateIcon className="w-5 h-5" />
                      <span>Save as New Product</span>
                    </>
                  ) : isEdit ? (
                    <>
                      <CheckIcon className="w-5 h-5" />
                      <span>Save & Update</span>
                    </>
                  ) : (
                    <>
                      <PlusIcon className="w-5 h-5" />
                      <span>Publish Product</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
        <ConfirmModal
          isOpen={!!confirmState}
          title={confirmState?.title}
          message={confirmState?.message}
          confirmText={confirmState?.confirmText || 'Delete'}
          type={confirmState?.type || 'danger'}
          onConfirm={() => {
            if (confirmState?.onConfirm) confirmState.onConfirm();
            setConfirmState(null);
          }}
          onCancel={() => setConfirmState(null)}
        />
      </motion.div>
    </motion.div>
  );
}

function BulkCSVModal({ onClose, onSuccess }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleDownloadSample = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      'name,description,shortDescription,price,comparePrice,stock,sku,categoryId,tags,vertical,isFeatured,isDeals,freeShipping,unitMeasure,restaurantName\n' +
      'Fresh Farm Apples,Crispy sweet apples,Fresh red apples,120,150,50,APP-101,64a7c1b890a,fruit;fresh;organic,grocery,true,false,true,1kg,\n' +
      'Hyderabadi Chicken Biryani,Delicious dum cooked biryani,Spicy rice and chicken,250,300,20,BIR-202,64a7c1b890b,biryani;spicy;chicken,food,false,true,false,,Paradise Biryani';
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'sample_products_import.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUpload = async () => {
    if (!file) {
      toast.error('Please select a CSV file');
      return;
    }
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const token = localStorage.getItem('adminToken');
      const res = await fetch('https://ecommerce-api-yak7.onrender.com/api/products/bulk-upload', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message || 'Products imported successfully');
        onSuccess();
      } else {
        toast.error(data.message || 'Import failed');
      }
    } catch (err) {
      toast.error(err.message || 'Upload error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.95 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4"
      >
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-dark-900">Bulk Import Products (CSV)</h3>
          <button onClick={onClose} className="text-dark-400 hover:text-dark-700">
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>
        <p className="text-sm text-dark-500">
          Upload a structured CSV file containing your product catalog. Columns must include{' '}
          <code>name, price, stock, categoryId</code>.
        </p>
        <div>
          <button
            type="button"
            onClick={handleDownloadSample}
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 underline flex items-center gap-1"
          >
            <DocumentArrowUpIcon className="w-4 h-4" /> Download Sample Template (.CSV)
          </button>
        </div>
        <div className="border-2 border-dashed border-dark-200 rounded-xl p-6 text-center hover:border-emerald-500 transition-colors">
          <input
            type="file"
            accept=".csv"
            onChange={(e) => setFile(e.target.files[0])}
            className="hidden"
            id="csv-file-input"
          />
          <label htmlFor="csv-file-input" className="cursor-pointer space-y-2 block">
            <DocumentArrowUpIcon className="w-8 h-8 text-emerald-500 mx-auto" />
            <span className="text-sm font-medium text-dark-700 block">
              {file ? file.name : 'Click to browse .csv file'}
            </span>
            <span className="text-xs text-dark-400 block">Maximum file size: 5MB</span>
          </label>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 btn-secondary">
            Cancel
          </button>
          <button
            onClick={handleUpload}
            disabled={uploading || !file}
            className="flex-1 btn-primary bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
          >
            {uploading ? 'Processing...' : 'Start Import'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function BulkImagesModal({ onClose, onSuccess }) {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async () => {
    if (!file) {
      toast.error('Please select a ZIP file');
      return;
    }
    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const token = localStorage.getItem('adminToken');
      const res = await fetch('https://ecommerce-api-yak7.onrender.com/api/products/bulk-images', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message || 'Images attached successfully');
        onSuccess();
      } else {
        toast.error(data.message || 'Upload failed');
      }
    } catch (err) {
      toast.error(err.message || 'Upload error');
    } finally {
      setUploading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.95 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4"
      >
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold text-dark-900">Bulk Upload Images (ZIP)</h3>
          <button onClick={onClose} className="text-dark-400 hover:text-dark-700">
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>
        <p className="text-sm text-dark-500">
          Upload a <code>.zip</code> file with product image files named matching your SKU or Product ID (e.g.{' '}
          <code>APP-101.jpg</code> or <code>64a7c1b890a_1.jpg</code>).
        </p>
        <div className="border-2 border-dashed border-dark-200 rounded-xl p-6 text-center hover:border-indigo-500 transition-colors">
          <input
            type="file"
            accept=".zip,application/zip"
            onChange={(e) => setFile(e.target.files[0])}
            className="hidden"
            id="zip-file-input"
          />
          <label htmlFor="zip-file-input" className="cursor-pointer space-y-2 block">
            <PhotoIcon className="w-8 h-8 text-indigo-500 mx-auto" />
            <span className="text-sm font-medium text-dark-700 block">
              {file ? file.name : 'Click to browse .zip archive'}
            </span>
            <span className="text-xs text-dark-400 block">Max size: 50MB</span>
          </label>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={onClose} className="flex-1 btn-secondary">
            Cancel
          </button>
          <button
            onClick={handleUpload}
            disabled={uploading || !file}
            className="flex-1 btn-primary bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
          >
            {uploading ? 'Extracting & Uploading...' : 'Upload & Link'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function ReviewProductModal({ product, onClose, onApprove, onEdit, onReject, approving }) {
  const [commissionType, setCommissionType] = useState(product?.commissionType || 'percentage');
  const [commissionValue, setCommissionValue] = useState(
    product?.commissionValue !== undefined ? product.commissionValue : 10
  );
  const [selectedImg, setSelectedImg] = useState(0);

  const price = Number(product?.price || 0);
  const val = Number(commissionValue) || 0;
  const commAmount = commissionType === 'flat' ? val : (price * val) / 100;
  const vendorNet = Math.max(0, price - commAmount);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl space-y-6 p-6 sm:p-8"
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                ⏳ Pending Request Review
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-700 uppercase">
                {product?.vertical || 'retail'}
              </span>
            </div>
            <h2 className="text-xl font-black text-slate-900">{product?.name}</h2>
            <p className="text-xs text-slate-500 font-medium">
              Vendor Store: <strong className="text-slate-800">{product?.vendor?.name || 'Vendor'}</strong> ({product?.vendor?.email || 'N/A'})
            </p>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded-lg">
            <XMarkIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Left: Product Images */}
          <div className="space-y-3">
            <div className="aspect-square bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden">
              <img
                src={product?.images?.[selectedImg] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'}
                alt={product?.name}
                className="w-full h-full object-cover"
              />
            </div>
            {product?.images?.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImg(idx)}
                    className={`w-14 h-14 rounded-xl border-2 overflow-hidden flex-shrink-0 transition-all ${
                      selectedImg === idx ? 'border-blue-600 ring-2 ring-blue-100' : 'border-slate-200'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Overview */}
          <div className="space-y-4 text-xs text-slate-600">
            <div className="grid grid-cols-2 gap-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Product Price</span>
                <span className="text-base font-black text-slate-900 font-mono">₹{price.toLocaleString('en-IN')}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Initial Stock</span>
                <span className="text-base font-black text-slate-900 font-mono">{product?.stock || 0}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">SKU</span>
                <span className="font-mono font-bold text-slate-700">{product?.sku || 'N/A'}</span>
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Category</span>
                <span className="font-bold text-slate-700">{product?.category?.name || 'Uncategorized'}</span>
              </div>
            </div>

            {product?.description && (
              <div>
                <span className="font-extrabold text-slate-800 block mb-1">Description:</span>
                <p className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-600 line-clamp-4 leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}

            {/* Variants */}
            {product?.variants?.length > 0 && (
              <div>
                <span className="font-extrabold text-slate-800 block mb-1">
                  Product Variants ({product.variants.length} sizes):
                </span>
                <div className="max-h-32 overflow-y-auto space-y-1.5 p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {product.variants.map((v, vIdx) => (
                    <div key={vIdx} className="flex justify-between items-center bg-white p-2 rounded-lg border border-slate-100 text-[11px]">
                      <span className="font-bold text-slate-800">{v.name}</span>
                      <span className="text-slate-500">
                        {v.options?.map((o) => `${o.label} (₹${o.price}, stock: ${o.stock})`).join(' · ')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Admin Commission Card */}
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h4 className="text-sm font-black text-emerald-950 flex items-center gap-1.5">
              <span>💰 Admin Commission Review & Approval</span>
            </h4>
            <span className="text-xs font-bold text-indigo-700 bg-white px-3 py-1 rounded-full border border-indigo-200 shadow-2xs">
              Vendor Proposed: {product?.commissionType === 'flat' ? `₹${product?.commissionValue ?? 0}` : `${product?.commissionValue ?? 10}%`}
            </span>
          </div>
          <p className="text-xs text-emerald-800 font-medium">
            Vendor proposed <strong>{product?.commissionType === 'flat' ? `₹${product?.commissionValue ?? 0}` : `${product?.commissionValue ?? 10}%`}</strong> commission in their request. You can accept this or adjust the final commission before approving.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-emerald-900 mb-1">Commission Type</label>
              <select
                value={commissionType}
                onChange={(e) => setCommissionType(e.target.value)}
                className="input-field bg-white text-xs font-semibold"
              >
                <option value="percentage">Percentage (%)</option>
                <option value="flat">Flat Amount (₹)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-emerald-900 mb-1">Commission Value</label>
              <input
                type="number"
                step="0.01"
                value={commissionValue}
                onChange={(e) => setCommissionValue(e.target.value)}
                className="input-field bg-white text-xs font-mono font-bold"
                placeholder="e.g. 10 or 50"
              />
            </div>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-emerald-200 flex flex-wrap items-center justify-between gap-3 text-xs font-mono text-emerald-950">
            <div>Retail Price: <strong>₹{price.toFixed(2)}</strong></div>
            <div>Admin Fee ({commissionType === 'percentage' ? `${val}%` : `₹${val}`}): <strong className="text-emerald-700">₹{commAmount.toFixed(2)}</strong></div>
            <div>Vendor Payout: <strong className="text-blue-700">₹{vendorNet.toFixed(2)}</strong></div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => {
              onClose();
              onEdit(product);
            }}
            className="w-full sm:w-auto px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <PencilIcon className="w-4 h-4" />
            <span>Full Edit Mode</span>
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={() => {
                onClose();
                onReject(product);
              }}
              className="px-4 py-2 bg-rose-100 hover:bg-rose-200 text-rose-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <XMarkIcon className="w-4 h-4" />
              <span>Reject Request</span>
            </button>
            <button
              type="button"
              disabled={approving}
              onClick={() => {
                onApprove({
                  id: product._id,
                  status: 'approved',
                  commissionType,
                  commissionValue: parseFloat(commissionValue) || 0,
                });
              }}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              <CheckIcon className="w-4 h-4" />
              <span>{approving ? 'Approving...' : 'Approve & Publish Product'}</span>
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
