import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  TruckIcon,
  PhoneIcon,
  AdjustmentsHorizontalIcon,
  BanknotesIcon,
  XMarkIcon,
  MagnifyingGlassIcon,
  UserPlusIcon,
  PlusIcon,
  TrashIcon,
} from '@heroicons/react/24/outline';
import { StarIcon } from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_DELIVERY_BOYS } from '../../graphql/queries.js';
import { UPDATE_DELIVERY_PARTNER_PAYOUT_CONFIG, CREATE_USER } from '../../graphql/mutations.js';

export default function DeliveryPartners() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPartner, setSelectedPartner] = useState(null);
  const [addModalOpen, setAddModalOpen] = useState(false);

  // Edit Config Modal form state
  const [payoutType, setPayoutType] = useState('per_order');
  const [perOrderRate, setPerOrderRate] = useState('65');
  const [monthlySalary, setMonthlySalary] = useState('18000');
  const [dailyIncentive, setDailyIncentive] = useState('150');
  const [editVehicles, setEditVehicles] = useState([
    { vehicleType: '2_wheeler', registrationNumber: '', isPrimary: true },
  ]);

  // Add Partner Form state
  const [addName, setAddName] = useState('');
  const [addEmail, setAddEmail] = useState('');
  const [addPhone, setAddPhone] = useState('');
  const [addPassword, setAddPassword] = useState('');
  const [addPayoutType, setAddPayoutType] = useState('per_order');
  const [addPerOrderRate, setAddPerOrderRate] = useState('65');
  const [addMonthlySalary, setAddMonthlySalary] = useState('18000');
  const [addDailyIncentive, setAddDailyIncentive] = useState('150');
  const [addVehicles, setAddVehicles] = useState([
    { vehicleType: '2_wheeler', registrationNumber: '', isPrimary: true },
  ]);

  const { data, loading, refetch } = useQuery(GET_DELIVERY_BOYS, {
    pollInterval: 15000,
    fetchPolicy: 'cache-and-network',
  });

  const deliveryAgents = data?.getDeliveryAgents || [];

  const [updateConfig, { loading: savingConfig }] = useMutation(UPDATE_DELIVERY_PARTNER_PAYOUT_CONFIG, {
    onCompleted: () => {
      toast.success('Delivery partner vehicle & payout structure updated!');
      setSelectedPartner(null);
      refetch();
    },
    onError: (err) => {
      toast.error(err.message || 'Failed to update configuration');
    },
  });

  const [createPartner, { loading: creatingPartner }] = useMutation(CREATE_USER, {
    onCompleted: () => {
      toast.success('New Delivery Partner created successfully!');
      setAddModalOpen(false);
      resetAddForm();
      refetch();
    },
    onError: (err) => {
      toast.error(err.message || 'Failed to create delivery partner account');
    },
  });

  const resetAddForm = () => {
    setAddName('');
    setAddEmail('');
    setAddPhone('');
    setAddPassword('');
    setAddPayoutType('per_order');
    setAddPerOrderRate('65');
    setAddMonthlySalary('18000');
    setAddDailyIncentive('150');
    setAddVehicles([{ vehicleType: '2_wheeler', registrationNumber: '', isPrimary: true }]);
  };

  // Add Form Vehicle Handlers
  const handleAddVehicleToAddForm = () => {
    if (addVehicles.length >= 3) {
      toast.error('Maximum 3 vehicles allowed per delivery partner');
      return;
    }
    setAddVehicles([...addVehicles, { vehicleType: '2_wheeler', registrationNumber: '', isPrimary: false }]);
  };

  const handleRemoveVehicleFromAddForm = (index) => {
    if (addVehicles.length <= 1) {
      toast.error('At least 1 vehicle is required');
      return;
    }
    const updated = addVehicles.filter((_, i) => i !== index);
    if (!updated.some((v) => v.isPrimary) && updated.length > 0) {
      updated[0].isPrimary = true;
    }
    setAddVehicles(updated);
  };

  const handleUpdateAddVehicle = (index, field, value) => {
    const updated = [...addVehicles];
    updated[index] = { ...updated[index], [field]: value };
    setAddVehicles(updated);
  };

  const handleSetAddVehiclePrimary = (index) => {
    setAddVehicles(addVehicles.map((v, i) => ({ ...v, isPrimary: i === index })));
  };

  // Edit Form Vehicle Handlers
  const handleAddVehicleToEditForm = () => {
    if (editVehicles.length >= 3) {
      toast.error('Maximum 3 vehicles allowed per delivery partner');
      return;
    }
    setEditVehicles([...editVehicles, { vehicleType: '2_wheeler', registrationNumber: '', isPrimary: false }]);
  };

  const handleRemoveVehicleFromEditForm = (index) => {
    if (editVehicles.length <= 1) {
      toast.error('At least 1 vehicle is required');
      return;
    }
    const updated = editVehicles.filter((_, i) => i !== index);
    if (!updated.some((v) => v.isPrimary) && updated.length > 0) {
      updated[0].isPrimary = true;
    }
    setEditVehicles(updated);
  };

  const handleUpdateEditVehicle = (index, field, value) => {
    const updated = [...editVehicles];
    updated[index] = { ...updated[index], [field]: value };
    setEditVehicles(updated);
  };

  const handleSetEditVehiclePrimary = (index) => {
    setEditVehicles(editVehicles.map((v, i) => ({ ...v, isPrimary: i === index })));
  };

  const handleCreatePartnerSubmit = (e) => {
    e.preventDefault();
    if (!addName.trim() || !addEmail.trim() || !addPhone.trim() || !addPassword) {
      toast.error('Name, Email, Phone Number, and Password are required');
      return;
    }
    if (addPassword.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    const primaryVehicle = addVehicles.find((v) => v.isPrimary) || addVehicles[0];

    createPartner({
      variables: {
        input: {
          name: addName.trim(),
          email: addEmail.trim(),
          password: addPassword,
          role: 'delivery',
          phone: addPhone.trim() || undefined,
          deliveryPayoutType: addPayoutType,
          deliveryPerOrderRate: parseFloat(addPerOrderRate) || 65,
          deliveryMonthlySalary: parseFloat(addMonthlySalary) || 18000,
          deliveryDailyIncentive: parseFloat(addDailyIncentive) || 150,
          vehicleType: primaryVehicle?.vehicleType || '2_wheeler',
          vehicleRegistrationNumber: primaryVehicle?.registrationNumber.trim() || '',
          vehicles: addVehicles.slice(0, 3).map((v) => ({
            vehicleType: v.vehicleType,
            registrationNumber: v.registrationNumber.trim(),
            isPrimary: !!v.isPrimary,
          })),
        },
      },
    });
  };

  const openConfigModal = (partner) => {
    setSelectedPartner(partner);
    setPayoutType(partner.deliveryPayoutType || 'per_order');
    setPerOrderRate(String(partner.deliveryPerOrderRate ?? 65));
    setMonthlySalary(String(partner.deliveryMonthlySalary ?? 18000));
    setDailyIncentive(String(partner.deliveryDailyIncentive ?? 150));

    if (partner.vehicles && partner.vehicles.length > 0) {
      setEditVehicles(
        partner.vehicles.map((v) => ({
          vehicleType: v.vehicleType || '2_wheeler',
          registrationNumber: v.registrationNumber || '',
          isPrimary: !!v.isPrimary,
        }))
      );
    } else {
      setEditVehicles([
        {
          vehicleType: partner.vehicleType || '2_wheeler',
          registrationNumber: partner.vehicleRegistrationNumber || '',
          isPrimary: true,
        },
      ]);
    }
  };

  const handleSaveConfig = (e) => {
    e.preventDefault();
    if (!selectedPartner) return;

    const primaryVehicle = editVehicles.find((v) => v.isPrimary) || editVehicles[0];

    updateConfig({
      variables: {
        userId: selectedPartner._id,
        payoutType,
        perOrderRate: parseFloat(perOrderRate) || 0,
        monthlySalary: parseFloat(monthlySalary) || 0,
        dailyIncentive: parseFloat(dailyIncentive) || 0,
        vehicleType: primaryVehicle?.vehicleType || '2_wheeler',
        vehicleRegistrationNumber: primaryVehicle?.registrationNumber.trim() || '',
        vehicles: editVehicles.slice(0, 3).map((v) => ({
          vehicleType: v.vehicleType,
          registrationNumber: v.registrationNumber.trim(),
          isPrimary: !!v.isPrimary,
        })),
      },
    });
  };

  const filteredAgents = deliveryAgents.filter((agent) => {
    const term = searchTerm.toLowerCase();
    return (
      agent.name?.toLowerCase().includes(term) ||
      agent.phone?.toLowerCase().includes(term) ||
      agent.email?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* HEADER SECTION */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-dark-900 tracking-tight flex items-center gap-2.5">
            <TruckIcon className="w-7 h-7 text-emerald-600" />
            Delivery Partner Management
          </h1>
          <p className="text-xs text-dark-500 mt-1 font-medium">
            Manage delivery partner vehicle registrations (up to 3 max), fixed vs per-order payout rules, and daily shift allowances.
          </p>
        </div>

        <button
          onClick={() => {
            resetAddForm();
            setAddModalOpen(true);
          }}
          className="btn-primary text-xs font-bold px-4 py-2.5 flex items-center justify-center gap-2 shadow-xs"
        >
          <UserPlusIcon className="w-4 h-4" />
          Add Delivery Partner
        </button>
      </div>

      {/* SEARCH AND FILTER BAR */}
      <div className="bg-white p-4 rounded-2xl border border-dark-100 shadow-xs flex items-center gap-3">
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="w-4 h-4 text-dark-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search delivery partner by name, phone or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field text-xs pl-9 bg-dark-50/50 border-dark-200"
          />
        </div>
      </div>

      {/* DELIVERY PARTNERS LIST TABLE */}
      <div className="bg-white rounded-2xl border border-dark-100 shadow-xs overflow-hidden">
        {loading && deliveryAgents.length === 0 ? (
          <div className="p-12 text-center text-xs text-dark-400 font-medium">
            Loading delivery partner profiles...
          </div>
        ) : filteredAgents.length === 0 ? (
          <div className="p-12 text-center text-xs text-dark-400 font-medium">
            No delivery partners found matching your filter criteria.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-dark-50/50 text-dark-400 border-b border-dark-100 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="px-5 py-3.5">Driver</th>
                  <th className="px-5 py-3.5">Rating</th>
                  <th className="px-5 py-3.5">Assigned Vehicles (Max 3)</th>
                  <th className="px-5 py-3.5">Status</th>
                  <th className="px-5 py-3.5">Payout Model</th>
                  <th className="px-5 py-3.5">Configured Rates</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-100 font-medium text-dark-700">
                {filteredAgents.map((agent) => {
                  const isMonthly = agent.deliveryPayoutType === 'monthly';
                  const agentVehicles =
                    agent.vehicles && agent.vehicles.length > 0
                      ? agent.vehicles
                      : [
                          {
                            vehicleType: agent.vehicleType || '2_wheeler',
                            registrationNumber: agent.vehicleRegistrationNumber || '',
                            isPrimary: true,
                          },
                        ];

                  return (
                    <motion.tr
                      key={agent._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/60 transition-colors"
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-emerald-50 text-emerald-700 font-bold flex items-center justify-center border border-emerald-100 text-sm overflow-hidden flex-shrink-0">
                            {agent.avatar ? (
                              <img src={agent.avatar} alt={agent.name} className="w-full h-full object-cover" />
                            ) : (
                              agent.name?.charAt(0) || 'D'
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-dark-900">{agent.name}</p>
                            <div className="flex items-center gap-2 text-[11px] text-dark-400 font-mono mt-0.5">
                              {agent.phone && (
                                <span className="flex items-center gap-1">
                                  <PhoneIcon className="w-3 h-3 text-dark-400" />
                                  {agent.phone}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex items-center gap-1.5 bg-amber-50/90 text-amber-800 font-extrabold px-2.5 py-1 rounded-xl border border-amber-200/80 w-fit shadow-2xs">
                          <StarIcon className="w-4 h-4 text-amber-500 fill-amber-400 flex-shrink-0" />
                          <span className="text-xs">{agent.deliveryRating?.average ? Number(agent.deliveryRating.average).toFixed(1) : '4.8'}</span>
                          <span className="text-[10px] text-amber-600 font-semibold">({agent.deliveryRating?.count || 15})</span>
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="space-y-1.5">
                          {agentVehicles.map((v, idx) => {
                            const vTypeLabel =
                              v.vehicleType === '4_wheeler'
                                ? '🚗 4 Wheeler'
                                : v.vehicleType === 'bicycle'
                                ? '🚲 Bicycle'
                                : v.vehicleType === 'other'
                                ? '🚚 Other'
                                : '🛵 2 Wheeler';

                            return (
                              <div key={idx} className="flex items-center gap-1.5 flex-wrap">
                                <span
                                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold ${
                                    v.isPrimary
                                      ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                      : 'bg-slate-100 text-slate-700 border border-slate-200'
                                  }`}
                                >
                                  {vTypeLabel}
                                  {v.isPrimary && (
                                    <span className="text-[9px] bg-emerald-600 text-white px-1 rounded uppercase tracking-wider ml-0.5">
                                      Primary
                                    </span>
                                  )}
                                </span>
                                {v.registrationNumber ? (
                                  <span className="text-xs font-mono font-bold text-dark-900">
                                    {v.registrationNumber}
                                  </span>
                                ) : (
                                  <span className="text-[11px] text-dark-400 italic">No Reg.</span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <div className="flex flex-col gap-1 items-start">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                              agent.isActive
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-red-50 text-red-700 border border-red-200'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                agent.isActive ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'
                              }`}
                            />
                            {agent.isActive ? 'Active Staff' : 'Suspended'}
                          </span>

                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                              agent.isOnline
                                ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                : 'bg-dark-100 text-dark-500 border border-dark-200'
                            }`}
                          >
                            {agent.isOnline ? '🟢 On Duty' : '⚪ Offline'}
                          </span>
                        </div>
                      </td>

                      <td className="px-5 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold ${
                            isMonthly
                              ? 'bg-purple-50 text-purple-800 border border-purple-200'
                              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          }`}
                        >
                          {isMonthly ? (
                            <>
                              <BanknotesIcon className="w-3.5 h-3.5 text-purple-600" />
                              Fixed Monthly
                            </>
                          ) : (
                            <>
                              <TruckIcon className="w-3.5 h-3.5 text-emerald-600" />
                              Per Order Trip Rate
                            </>
                          )}
                        </span>
                      </td>

                      <td className="px-5 py-4 space-y-1">
                        {isMonthly ? (
                          <p className="font-bold text-dark-900 text-xs">
                            Base: <span className="text-purple-700">₹{agent.deliveryMonthlySalary ?? 18000}</span>
                            <span className="text-[11px] text-dark-400 font-normal"> / mo</span>
                          </p>
                        ) : (
                          <p className="font-bold text-dark-900 text-xs">
                            Trip Rate: <span className="text-emerald-700">₹{agent.deliveryPerOrderRate ?? 65}</span>
                            <span className="text-[11px] text-dark-400 font-normal"> / order</span>
                          </p>
                        )}
                        <p className="text-[11px] text-dark-500">
                          Shift Allowance: <span className="font-bold text-dark-800">₹{agent.deliveryDailyIncentive ?? 150}</span>
                          <span className="text-dark-400 font-normal"> / day</span>
                        </p>
                      </td>

                      <td className="px-5 py-4 text-right">
                        <button
                          onClick={() => openConfigModal(agent)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-dark-200 hover:border-emerald-500 hover:bg-emerald-50/50 text-dark-700 hover:text-emerald-700 font-bold transition-all text-xs"
                        >
                          <AdjustmentsHorizontalIcon className="w-4 h-4 text-emerald-600" />
                          Edit Vehicles & Payout
                        </button>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ADD DELIVERY PARTNER MODAL */}
      <AnimatePresence>
        {addModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-900/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl border border-dark-100 shadow-xl max-w-lg w-full overflow-hidden my-8"
            >
              <div className="flex items-center justify-between p-5 border-b border-dark-100 bg-dark-50/50">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                    <UserPlusIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-dark-900 text-sm">Add New Delivery Partner</h3>
                    <p className="text-[11px] text-dark-500">Create account & assign up to 3 vehicles</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setAddModalOpen(false);
                    resetAddForm();
                  }}
                  className="p-1 rounded-lg text-dark-400 hover:text-dark-700 hover:bg-dark-100"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreatePartnerSubmit} className="p-5 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Full Name *</label>
                    <input
                      type="text"
                      value={addName}
                      onChange={(e) => setAddName(e.target.value)}
                      placeholder="Driver Name"
                      className="input-field text-xs bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Email Address *</label>
                    <input
                      type="email"
                      value={addEmail}
                      onChange={(e) => setAddEmail(e.target.value)}
                      placeholder="driver@example.com"
                      className="input-field text-xs bg-white"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Phone Number *</label>
                    <input
                      type="text"
                      value={addPhone}
                      onChange={(e) => setAddPhone(e.target.value)}
                      placeholder="+91 9876543210"
                      className="input-field text-xs bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Password *</label>
                    <input
                      type="password"
                      value={addPassword}
                      onChange={(e) => setAddPassword(e.target.value)}
                      placeholder="Min 6 characters"
                      className="input-field text-xs bg-white"
                      required
                    />
                  </div>
                </div>

                {/* MULTI-VEHICLE MANAGEMENT SECTION */}
                <div className="pt-2 border-t border-dark-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="block font-bold text-dark-700 text-xs">Vehicles Management (Max 3)</label>
                      <p className="text-[11px] text-dark-400">Add up to 3 vehicles with registration numbers</p>
                    </div>
                    {addVehicles.length < 3 && (
                      <button
                        type="button"
                        onClick={handleAddVehicleToAddForm}
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
                      >
                        <PlusIcon className="w-3.5 h-3.5" />
                        Add Vehicle
                      </button>
                    )}
                  </div>

                  <div className="space-y-2.5">
                    {addVehicles.map((v, idx) => (
                      <div key={idx} className="p-3 bg-dark-50/50 rounded-xl border border-dark-100 relative space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-dark-700 text-[11px]">Vehicle #{idx + 1}</span>
                            <button
                              type="button"
                              onClick={() => handleSetAddVehiclePrimary(idx)}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                                v.isPrimary
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-dark-200 text-dark-600 hover:bg-dark-300'
                              }`}
                            >
                              {v.isPrimary ? 'Primary Vehicle' : 'Set as Primary'}
                            </button>
                          </div>
                          {addVehicles.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveVehicleFromAddForm(idx)}
                              className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Remove vehicle"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="block text-[10px] font-medium text-dark-500 mb-1">Type</label>
                            <select
                              value={v.vehicleType}
                              onChange={(e) => handleUpdateAddVehicle(idx, 'vehicleType', e.target.value)}
                              className="input-field text-xs bg-white py-1.5"
                            >
                              <option value="2_wheeler">🛵 2 Wheeler (Bike / Scooter)</option>
                              <option value="4_wheeler">🚗 4 Wheeler (Car / Van)</option>
                              <option value="bicycle">🚲 Bicycle</option>
                              <option value="other">🚚 Other Vehicle</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] font-medium text-dark-500 mb-1">Registration No.</label>
                            <input
                              type="text"
                              value={v.registrationNumber}
                              onChange={(e) => handleUpdateAddVehicle(idx, 'registrationNumber', e.target.value)}
                              placeholder="e.g. UP 15 AB 1234"
                              className="input-field text-xs bg-white font-mono uppercase py-1.5"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-dark-100">
                  <label className="block font-bold text-dark-700 mb-1.5">Initial Payout Model</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setAddPayoutType('per_order')}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                        addPayoutType === 'per_order'
                          ? 'border-emerald-500 bg-emerald-50/60 text-emerald-900 font-bold shadow-xs'
                          : 'border-dark-200 bg-white text-dark-600 font-medium'
                      }`}
                    >
                      <TruckIcon className="w-5 h-5 text-emerald-600" />
                      <span>Per Order (Trip)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setAddPayoutType('monthly')}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                        addPayoutType === 'monthly'
                          ? 'border-purple-500 bg-purple-50/60 text-purple-900 font-bold shadow-xs'
                          : 'border-dark-200 bg-white text-dark-600 font-medium'
                      }`}
                    >
                      <BanknotesIcon className="w-5 h-5 text-purple-600" />
                      <span>Fixed Monthly</span>
                    </button>
                  </div>
                </div>

                {addPayoutType === 'per_order' ? (
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Per Order Rate (₹)</label>
                    <input
                      type="number"
                      value={addPerOrderRate}
                      onChange={(e) => setAddPerOrderRate(e.target.value)}
                      placeholder="65"
                      className="input-field text-xs bg-white"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Fixed Monthly Salary (₹)</label>
                    <input
                      type="number"
                      value={addMonthlySalary}
                      onChange={(e) => setAddMonthlySalary(e.target.value)}
                      placeholder="18000"
                      className="input-field text-xs bg-white"
                    />
                  </div>
                )}

                <div>
                  <label className="block font-bold text-dark-700 mb-1">Daily Shift Incentive (₹)</label>
                  <input
                    type="number"
                    value={addDailyIncentive}
                    onChange={(e) => setAddDailyIncentive(e.target.value)}
                    placeholder="150"
                    className="input-field text-xs bg-white"
                  />
                </div>

                <div className="pt-3 flex justify-end gap-2 border-t border-dark-100">
                  <button
                    type="button"
                    onClick={() => {
                      setAddModalOpen(false);
                      resetAddForm();
                    }}
                    className="btn-secondary text-xs px-4 py-2"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creatingPartner}
                    className="btn-primary text-xs px-5 py-2 disabled:opacity-50"
                  >
                    {creatingPartner ? 'Creating...' : 'Create Partner Account'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* EDIT PAYOUT CONFIG & VEHICLES MODAL */}
      <AnimatePresence>
        {selectedPartner && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-900/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl border border-dark-100 shadow-xl max-w-lg w-full overflow-hidden my-8"
            >
              <div className="flex items-center justify-between p-5 border-b border-dark-100 bg-dark-50/50">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                    <TruckIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-dark-900 text-sm">{selectedPartner.name}</h3>
                    <p className="text-[11px] text-dark-500">Configure Earnings & Vehicles (Max 3)</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedPartner(null)}
                  className="p-1 rounded-lg text-dark-400 hover:text-dark-700 hover:bg-dark-100"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveConfig} className="p-5 space-y-4 text-xs">
                {/* MULTI-VEHICLE MANAGEMENT SECTION */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <label className="block font-bold text-dark-700 text-xs">Assigned Vehicles (Max 3)</label>
                      <p className="text-[11px] text-dark-400">Manage partner's active vehicles and primary selection</p>
                    </div>
                    {editVehicles.length < 3 && (
                      <button
                        type="button"
                        onClick={handleAddVehicleToEditForm}
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 hover:bg-emerald-100 px-2.5 py-1 rounded-lg border border-emerald-200 transition-colors"
                      >
                        <PlusIcon className="w-3.5 h-3.5" />
                        Add Vehicle
                      </button>
                    )}
                  </div>

                  <div className="space-y-2.5">
                    {editVehicles.map((v, idx) => (
                      <div key={idx} className="p-3 bg-dark-50/50 rounded-xl border border-dark-100 relative space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-dark-700 text-[11px]">Vehicle #{idx + 1}</span>
                            <button
                              type="button"
                              onClick={() => handleSetEditVehiclePrimary(idx)}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${
                                v.isPrimary
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-dark-200 text-dark-600 hover:bg-dark-300'
                              }`}
                            >
                              {v.isPrimary ? 'Primary Vehicle' : 'Set as Primary'}
                            </button>
                          </div>
                          {editVehicles.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveVehicleFromEditForm(idx)}
                              className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Remove vehicle"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          )}
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="block text-[10px] font-medium text-dark-500 mb-1">Type</label>
                            <select
                              value={v.vehicleType}
                              onChange={(e) => handleUpdateEditVehicle(idx, 'vehicleType', e.target.value)}
                              className="input-field text-xs bg-white py-1.5"
                            >
                              <option value="2_wheeler">🛵 2 Wheeler (Bike / Scooter)</option>
                              <option value="4_wheeler">🚗 4 Wheeler (Car / Van)</option>
                              <option value="bicycle">🚲 Bicycle</option>
                              <option value="other">🚚 Other Vehicle</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] font-medium text-dark-500 mb-1">Registration No.</label>
                            <input
                              type="text"
                              value={v.registrationNumber}
                              onChange={(e) => handleUpdateEditVehicle(idx, 'registrationNumber', e.target.value)}
                              placeholder="e.g. UP 15 AB 1234"
                              className="input-field text-xs bg-white font-mono uppercase py-1.5"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-dark-100">
                  <label className="block font-bold text-dark-700 mb-1.5">Payout Calculation Mode</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setPayoutType('per_order')}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                        payoutType === 'per_order'
                          ? 'border-emerald-500 bg-emerald-50/60 text-emerald-900 font-bold shadow-xs'
                          : 'border-dark-200 bg-white text-dark-600 font-medium'
                      }`}
                    >
                      <TruckIcon className="w-5 h-5 text-emerald-600" />
                      <span>Per Order (Trip Basis)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPayoutType('monthly')}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                        payoutType === 'monthly'
                          ? 'border-purple-500 bg-purple-50/60 text-purple-900 font-bold shadow-xs'
                          : 'border-dark-200 bg-white text-dark-600 font-medium'
                      }`}
                    >
                      <BanknotesIcon className="w-5 h-5 text-purple-600" />
                      <span>Fixed Monthly Salary</span>
                    </button>
                  </div>
                </div>

                {payoutType === 'per_order' ? (
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Per Order Rate (₹)</label>
                    <input
                      type="number"
                      value={perOrderRate}
                      onChange={(e) => setPerOrderRate(e.target.value)}
                      placeholder="e.g. 65"
                      className="input-field text-xs bg-white"
                      required
                    />
                    <p className="text-[11px] text-dark-400 mt-1">Driver earns this amount for every successfully delivered trip.</p>
                  </div>
                ) : (
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Fixed Monthly Salary (₹)</label>
                    <input
                      type="number"
                      value={monthlySalary}
                      onChange={(e) => setMonthlySalary(e.target.value)}
                      placeholder="e.g. 18000"
                      className="input-field text-xs bg-white"
                      required
                    />
                    <p className="text-[11px] text-dark-400 mt-1">Base monthly salary credited to driver.</p>
                  </div>
                )}

                <div>
                  <label className="block font-bold text-dark-700 mb-1">Daily Shift Incentive / Allowance (₹)</label>
                  <input
                    type="number"
                    value={dailyIncentive}
                    onChange={(e) => setDailyIncentive(e.target.value)}
                    placeholder="e.g. 150"
                    className="input-field text-xs bg-white"
                  />
                  <p className="text-[11px] text-dark-400 mt-1">Additional daily bonus paid when active on duty.</p>
                </div>

                <div className="pt-2 flex justify-end gap-2 border-t border-dark-100">
                  <button
                    type="button"
                    onClick={() => setSelectedPartner(null)}
                    className="btn-secondary text-xs px-4 py-2"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingConfig}
                    className="btn-primary text-xs px-5 py-2 disabled:opacity-50"
                  >
                    {savingConfig ? 'Saving...' : 'Save Configuration'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
