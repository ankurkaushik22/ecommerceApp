import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BanknotesIcon,
  TruckIcon,
  CheckCircleIcon,
  ClockIcon,
  ArrowPathIcon,
  CurrencyRupeeIcon,
  EyeIcon,
  XMarkIcon,
  PlusIcon,
  DocumentTextIcon,
} from '@heroicons/react/24/outline';
import { StarIcon } from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_DELIVERY_BOYS, GET_ALL_ORDERS } from '../../graphql/queries.js';
import { RECORD_DELIVERY_CASH_RECEIVED } from '../../graphql/mutations.js';

export default function DriverPayouts() {
  const [selectedDriverForDeliveries, setSelectedDriverForDeliveries] = useState(null);
  const [selectedDriverForCash, setSelectedDriverForCash] = useState(null);
  const [receiveCashModalOpen, setReceiveCashModalOpen] = useState(false);

  // Cash receive form state
  const [cashAmount, setCashAmount] = useState('');
  const [cashNotes, setCashNotes] = useState('');

  const { data: driversData, loading: loadingDrivers, refetch: refetchDrivers } = useQuery(GET_DELIVERY_BOYS, {
    pollInterval: 15000,
    fetchPolicy: 'cache-and-network',
  });

  const { data: ordersData, loading: loadingOrders } = useQuery(GET_ALL_ORDERS, {
    variables: { pagination: { limit: 1000 } },
    fetchPolicy: 'cache-and-network',
  });

  const [recordCashReceived, { loading: submittingCash }] = useMutation(RECORD_DELIVERY_CASH_RECEIVED, {
    onCompleted: (res) => {
      toast.success('Cash deposit logged successfully!');
      setReceiveCashModalOpen(false);
      setCashAmount('');
      setCashNotes('');
      refetchDrivers();
    },
    onError: (err) => {
      toast.error(err.message || 'Failed to record cash deposit');
    },
  });

  const drivers = driversData?.getDeliveryAgents || [];
  const allOrders = ordersData?.getAllOrders?.orders || ordersData?.getAllOrders || [];

  const handleOpenDeliveriesModal = (driver) => {
    setSelectedDriverForDeliveries(driver);
  };

  const handleOpenReceiveCashModal = (driver) => {
    setSelectedDriverForCash(driver);
    setCashAmount('');
    setCashNotes('');
    setReceiveCashModalOpen(true);
  };

  const handleCashSubmit = (e) => {
    e.preventDefault();
    if (!selectedDriverForCash) return;
    const numAmt = parseFloat(cashAmount);
    if (isNaN(numAmt) || numAmt <= 0) {
      toast.error('Please enter a valid cash amount');
      return;
    }

    recordCashReceived({
      variables: {
        userId: selectedDriverForCash._id,
        amount: numAmt,
        notes: cashNotes.trim() || 'Cash deposited at hub',
      },
    });
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-purple-100 text-purple-800 rounded-xl">
              <BanknotesIcon className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-dark-900">Driver Deliveries & Cash Collection</h1>
          </div>
          <p className="text-xs text-dark-500 mt-1">
            Review delivery partner order history, cash collected (COD), cash submissions, and net pending collections.
          </p>
        </div>

        <button
          onClick={() => refetchDrivers()}
          className="btn-secondary text-xs px-3 py-2 flex items-center gap-1.5 self-start sm:self-auto"
        >
          <ArrowPathIcon className="w-4 h-4" />
          <span>Refresh Data</span>
        </button>
      </div>

      {/* Driver Summary Table */}
      <div className="bg-white border border-dark-100 rounded-2xl shadow-xs overflow-hidden">
        {loadingDrivers || loadingOrders ? (
          <div className="p-8 text-center text-xs text-dark-400">Loading delivery partner collections...</div>
        ) : drivers.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <TruckIcon className="w-12 h-12 text-dark-300 mx-auto" />
            <p className="font-semibold text-dark-700 text-sm">No delivery partners found</p>
            <p className="text-xs text-dark-400">Add delivery agents in Delivery Partner Management.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-dark-50/50 text-dark-400 border-b border-dark-100 uppercase tracking-wider font-semibold">
                <tr>
                  <th className="px-5 py-3.5">Delivery Partner</th>
                  <th className="px-5 py-3.5 text-center">Total Deliveries</th>
                  <th className="px-5 py-3.5 text-right">Total COD Collected</th>
                  <th className="px-5 py-3.5 text-right">Cash Submitted</th>
                  <th className="px-5 py-3.5 text-right">Pending Cash Collection</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-100 font-medium text-dark-700">
                {drivers.map((driver) => {
                  const driverOrders = allOrders.filter(
                    (o) =>
                      o.deliveryAgent?._id === driver._id ||
                      o.deliveryBoy?._id === driver._id ||
                      o.deliveryAgent === driver._id ||
                      o.deliveryBoy === driver._id
                  );

                  const deliveredOrders = driverOrders.filter((o) =>
                    ['delivered', 'completed'].includes(o.status)
                  );

                  // Total COD Collected
                  const totalCodCollected = deliveredOrders
                    .filter((o) => o.paymentMethod?.toLowerCase() === 'cod' || o.paymentMethod?.toLowerCase() === 'cash')
                    .reduce((sum, o) => sum + (o.total || 0), 0);

                  const submittedCash = driver.submittedCash || 0;
                  const netPendingCash = Math.max(0, totalCodCollected - submittedCash);

                  return (
                    <motion.tr
                      key={driver._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/60 transition-colors"
                    >
                      <td className="px-5 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-purple-50 text-purple-700 font-bold flex items-center justify-center border border-purple-100 text-sm overflow-hidden flex-shrink-0">
                            {driver.avatar ? (
                              <img src={driver.avatar} alt={driver.name} className="w-full h-full object-cover" />
                            ) : (
                              driver.name?.charAt(0) || 'D'
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-dark-900">{driver.name}</p>
                            <p className="text-[11px] text-dark-400 font-mono">{driver.phone || 'No phone'}</p>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-4 text-center">
                        <span className="font-bold text-dark-900 text-xs bg-dark-100/60 px-2.5 py-1 rounded-lg">
                          {deliveredOrders.length} / {driverOrders.length}
                        </span>
                      </td>

                      <td className="px-5 py-4 text-right font-bold text-amber-700">
                        ₹{totalCodCollected.toLocaleString('en-IN')}
                      </td>

                      <td className="px-5 py-4 text-right font-bold text-emerald-600">
                        ₹{submittedCash.toLocaleString('en-IN')}
                      </td>

                      <td className="px-5 py-4 text-right">
                        <p
                          className={`font-black text-sm ${
                            netPendingCash > 0 ? 'text-red-600' : 'text-emerald-700'
                          }`}
                        >
                          ₹{netPendingCash.toLocaleString('en-IN')}
                        </p>
                        <p className="text-[10px] text-dark-400 font-normal">
                          {netPendingCash > 0 ? 'Unsubmitted Cash' : 'Fully Settled'}
                        </p>
                      </td>

                      <td className="px-5 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenDeliveriesModal(driver)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-dark-100 text-dark-800 rounded-xl text-xs font-semibold hover:bg-dark-200 transition-colors"
                            title="View all assigned deliveries & remarks"
                          >
                            <EyeIcon className="w-3.5 h-3.5" />
                            <span>View Deliveries</span>
                          </button>

                          <button
                            onClick={() => handleOpenReceiveCashModal(driver)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-semibold hover:bg-emerald-700 transition-colors shadow-2xs"
                            title="Record cash handed over by driver"
                          >
                            <PlusIcon className="w-3.5 h-3.5" />
                            <span>Receive Cash</span>
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ALL DELIVERIES MODAL */}
      <AnimatePresence>
        {selectedDriverForDeliveries && (() => {
          const modalDriverOrders = allOrders.filter(
            (o) =>
              o.deliveryAgent?._id === selectedDriverForDeliveries._id ||
              o.deliveryBoy?._id === selectedDriverForDeliveries._id ||
              o.deliveryAgent === selectedDriverForDeliveries._id ||
              o.deliveryBoy === selectedDriverForDeliveries._id
          );
          const modalDeliveredOrders = modalDriverOrders.filter(o => ['delivered', 'completed'].includes(o.status));
          const modalAvgRating = modalDeliveredOrders.length > 0
            ? (modalDeliveredOrders.reduce((sum, o) => sum + (o.deliveryRating || 5.0), 0) / modalDeliveredOrders.length).toFixed(1)
            : (selectedDriverForDeliveries.deliveryRating?.average ? Number(selectedDriverForDeliveries.deliveryRating.average).toFixed(1) : '5.0');

          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-900/60 backdrop-blur-xs">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white rounded-2xl border border-dark-100 shadow-xl max-w-4xl w-full overflow-hidden max-h-[90vh] flex flex-col"
              >
                <div className="flex items-center justify-between p-5 border-b border-dark-100 bg-dark-50/50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center justify-center text-sm">
                      {selectedDriverForDeliveries.name?.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-dark-900 text-base">{selectedDriverForDeliveries.name}'s Deliveries</h3>
                        <div className="flex items-center gap-1.5 bg-amber-50 text-amber-800 font-extrabold px-2.5 py-0.5 rounded-full border border-amber-200 text-xs">
                          <StarIcon className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                          <span>Partner Rating: {modalAvgRating} / 5.0</span>
                        </div>
                      </div>
                      <p className="text-xs text-dark-500 mt-0.5">Order breakdown, per-order customer ratings, cash collected (COD), and remarks/instructions</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedDriverForDeliveries(null)}
                    className="p-1.5 rounded-lg text-dark-400 hover:text-dark-700 hover:bg-dark-100"
                  >
                    <XMarkIcon className="w-5 h-5" />
                  </button>
                </div>

              {/* Deliveries List */}
              <div className="p-5 overflow-y-auto flex-1 space-y-4">
                {(() => {
                  const driverOrders = allOrders.filter(
                    (o) =>
                      o.deliveryAgent?._id === selectedDriverForDeliveries._id ||
                      o.deliveryBoy?._id === selectedDriverForDeliveries._id ||
                      o.deliveryAgent === selectedDriverForDeliveries._id ||
                      o.deliveryBoy === selectedDriverForDeliveries._id
                  );

                  if (driverOrders.length === 0) {
                    return (
                      <div className="p-12 text-center text-xs text-dark-400">
                        No deliveries assigned or completed by this driver yet.
                      </div>
                    );
                  }

                  const deliveredOrders = driverOrders.filter(o => ['delivered', 'completed'].includes(o.status));
                  const totalCash = deliveredOrders
                    .filter(o => o.paymentMethod?.toLowerCase() === 'cod' || o.paymentMethod?.toLowerCase() === 'cash')
                    .reduce((sum, o) => sum + (o.total || 0), 0);

                  const avgOrderRating = deliveredOrders.length > 0
                    ? (deliveredOrders.reduce((sum, o) => sum + (o.deliveryRating || 5.0), 0) / deliveredOrders.length).toFixed(1)
                    : '5.0';

                  return (
                    <div className="overflow-x-auto border border-dark-100 rounded-xl">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-dark-50 text-dark-500 font-semibold border-b border-dark-100">
                          <tr>
                            <th className="px-4 py-3">Order #</th>
                            <th className="px-4 py-3">Customer Info</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Payment</th>
                            <th className="px-4 py-3 text-right">Cash Collected</th>
                            <th className="px-4 py-3 text-center">Per Order Rating</th>
                            <th className="px-4 py-3">Remarks / Instructions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-dark-100 text-dark-700 font-medium">
                          {driverOrders.map((order) => {
                            const isCod = order.paymentMethod?.toLowerCase() === 'cod' || order.paymentMethod?.toLowerCase() === 'cash';
                            const isDelivered = ['delivered', 'completed'].includes(order.status);
                            const cashAmt = isCod && isDelivered ? (order.total || 0) : 0;
                            const orderRating = order.deliveryRating ? Number(order.deliveryRating).toFixed(1) : (isDelivered ? '5.0' : null);

                            return (
                              <tr key={order._id} className="hover:bg-dark-50/50">
                                <td className="px-4 py-3 font-mono font-bold text-dark-900">
                                  #{order.orderNumber || order._id?.slice(-6)}
                                  <p className="text-[10px] text-dark-400 font-normal mt-0.5">
                                    {new Date(order.createdAt).toLocaleDateString('en-IN', {
                                      day: 'numeric',
                                      month: 'short',
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })}
                                  </p>
                                </td>

                                <td className="px-4 py-3">
                                  <p className="font-bold text-dark-900">{order.customer?.name || order.shippingAddress?.fullName || 'Customer'}</p>
                                  <p className="text-[11px] text-dark-500">{order.customer?.phone || order.shippingAddress?.phone}</p>
                                  <p className="text-[10px] text-dark-400 truncate max-w-xs">{order.shippingAddress?.addressLine1}, {order.shippingAddress?.city}</p>
                                </td>

                                <td className="px-4 py-3">
                                  <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                                    isDelivered ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                                  }`}>
                                    {order.status?.replace(/_/g, ' ')}
                                  </span>
                                </td>

                                <td className="px-4 py-3 font-mono">
                                  <p className="font-bold text-dark-900">₹{(order.total || 0).toFixed(0)}</p>
                                  <span className={`text-[10px] font-bold ${isCod ? 'text-amber-700' : 'text-blue-700'}`}>
                                    {isCod ? 'COD (Cash)' : 'Online Paid'}
                                  </span>
                                </td>

                                <td className="px-4 py-3 text-right font-mono font-extrabold">
                                  {cashAmt > 0 ? (
                                    <span className="text-amber-700 bg-amber-50 px-2 py-1 rounded-md border border-amber-200/60">
                                      ₹{cashAmt.toFixed(0)}
                                    </span>
                                  ) : (
                                    <span className="text-dark-400">₹0</span>
                                  )}
                                </td>

                                <td className="px-4 py-3 text-center">
                                  {orderRating ? (
                                    <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 font-black px-2.5 py-1 rounded-lg border border-amber-200/80 shadow-2xs">
                                      <StarIcon className="w-3.5 h-3.5 text-amber-500 fill-amber-400 flex-shrink-0" />
                                      <span>{orderRating}</span>
                                    </span>
                                  ) : (
                                    <span className="text-dark-400 font-medium text-[11px]">Pending</span>
                                  )}
                                </td>

                                <td className="px-4 py-3 text-dark-600 text-[11px] max-w-xs">
                                  {order.deliveryInstructions ? (
                                    <p className="text-purple-800 font-semibold">
                                      📌 {order.deliveryInstructions}
                                    </p>
                                  ) : null}
                                  {order.vendorNotes ? (
                                    <p className="text-dark-500 italic mt-0.5">
                                      📝 {order.vendorNotes}
                                    </p>
                                  ) : null}
                                  {!order.deliveryInstructions && !order.vendorNotes && (
                                    <span className="text-dark-300 italic">No remarks</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot className="bg-dark-50/80 font-bold border-t border-dark-200 text-xs">
                          <tr>
                            <td colSpan={4} className="px-4 py-3 text-dark-900 font-bold">
                              Summary ({deliveredOrders.length} Delivered Orders)
                            </td>
                            <td className="px-4 py-3 text-right font-mono text-amber-800 font-black">
                              ₹{totalCash.toFixed(0)}
                            </td>
                            <td className="px-4 py-3 text-center">
                              <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 font-black px-2.5 py-1 rounded-lg border border-amber-200">
                                <StarIcon className="w-3.5 h-3.5 text-amber-600 fill-amber-500 flex-shrink-0" />
                                <span>{avgOrderRating} Avg</span>
                              </span>
                            </td>
                            <td className="px-4 py-3"></td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  );
                })()}
              </div>
            </motion.div>
          </div>
        );
      })()}
      </AnimatePresence>

      {/* RECEIVE CASH / SUBMISSION MODAL */}
      <AnimatePresence>
        {receiveCashModalOpen && selectedDriverForCash && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-900/60 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl border border-dark-100 shadow-xl max-w-lg w-full overflow-hidden max-h-[90vh] flex flex-col"
            >
              <div className="flex items-center justify-between p-5 border-b border-dark-100 bg-dark-50/50">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                    <CurrencyRupeeIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-dark-900 text-sm">Receive Cash - {selectedDriverForCash.name}</h3>
                    <p className="text-[11px] text-dark-500">Record cash handed over by delivery agent</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedDriverForCash(null)}
                  className="p-1 rounded-lg text-dark-400 hover:text-dark-700 hover:bg-dark-100"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div className="p-5 space-y-4 text-xs overflow-y-auto flex-1">
                {/* Cash Summary Banner */}
                {(() => {
                  const driverOrders = allOrders.filter(
                    (o) =>
                      ['delivered', 'completed'].includes(o.status) &&
                      (o.deliveryAgent?._id === selectedDriverForCash._id ||
                        o.deliveryBoy?._id === selectedDriverForCash._id ||
                        o.deliveryAgent === selectedDriverForCash._id ||
                        o.deliveryBoy === selectedDriverForCash._id)
                  );

                  const totalCod = driverOrders
                    .filter((o) => o.paymentMethod?.toLowerCase() === 'cod' || o.paymentMethod?.toLowerCase() === 'cash')
                    .reduce((sum, o) => sum + (o.total || 0), 0);

                  const submitted = selectedDriverForCash.submittedCash || 0;
                  const pending = Math.max(0, totalCod - submitted);

                  return (
                    <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200/80 text-center">
                      <div>
                        <p className="text-[10px] text-dark-400 font-bold uppercase">Total COD</p>
                        <p className="font-extrabold text-amber-700 text-sm mt-0.5">₹{totalCod.toLocaleString('en-IN')}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-dark-400 font-bold uppercase">Submitted</p>
                        <p className="font-extrabold text-emerald-600 text-sm mt-0.5">₹{submitted.toLocaleString('en-IN')}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-dark-400 font-bold uppercase">Pending</p>
                        <p className="font-black text-red-600 text-sm mt-0.5">₹{pending.toLocaleString('en-IN')}</p>
                      </div>
                    </div>
                  );
                })()}

                {/* Form to record new cash submission */}
                <form onSubmit={handleCashSubmit} className="space-y-3 bg-emerald-50/50 p-4 rounded-xl border border-emerald-100">
                  <h4 className="font-bold text-emerald-900 text-xs">Record New Cash Handover</h4>
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Amount Received (₹) *</label>
                    <input
                      type="number"
                      value={cashAmount}
                      onChange={(e) => setCashAmount(e.target.value)}
                      placeholder="e.g. 1500"
                      className="input-field text-xs bg-white"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-dark-700 mb-1">Receipt / Deposit Remarks</label>
                    <input
                      type="text"
                      value={cashNotes}
                      onChange={(e) => setCashNotes(e.target.value)}
                      placeholder="e.g. Cash submitted at main store counter"
                      className="input-field text-xs bg-white"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submittingCash}
                    className="btn-primary w-full text-xs py-2 disabled:opacity-50"
                  >
                    {submittingCash ? 'Recording...' : 'Update & Reduce Collection'}
                  </button>
                </form>

                {/* Cash Submission History Table */}
                {selectedDriverForCash.cashSubmissions?.length > 0 && (
                  <div className="space-y-2 pt-2">
                    <h4 className="font-bold text-dark-800 text-xs">Cash Submission History</h4>
                    <div className="overflow-x-auto border border-dark-100 rounded-xl">
                      <table className="w-full text-left text-[11px]">
                        <thead className="bg-dark-50 text-dark-400 font-semibold border-b border-dark-100">
                          <tr>
                            <th className="px-3 py-2">Date & Time</th>
                            <th className="px-3 py-2 text-right">Amount</th>
                            <th className="px-3 py-2">Received By</th>
                            <th className="px-3 py-2">Notes</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-dark-100 text-dark-700 font-medium">
                          {selectedDriverForCash.cashSubmissions.map((sub, idx) => (
                            <tr key={sub._id || idx}>
                              <td className="px-3 py-2 font-mono text-dark-500">
                                {new Date(sub.createdAt).toLocaleDateString('en-IN', {
                                  day: 'numeric',
                                  month: 'short',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </td>
                              <td className="px-3 py-2 text-right font-bold text-emerald-600 font-mono">
                                ₹{(sub.amount || 0).toLocaleString('en-IN')}
                              </td>
                              <td className="px-3 py-2 font-bold text-dark-800">{sub.receivedBy || 'Admin'}</td>
                              <td className="px-3 py-2 text-dark-500">{sub.notes || '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
