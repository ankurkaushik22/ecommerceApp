/**
 * Formats GraphQL, API, and Form validation errors into clean, human-readable user messages.
 * 
 * Example raw error:
 * Variable "$input" got invalid value { name: "baby wiped", ... }; Field "description" of required type "String!" was not provided.
 * 
 * Formatted output:
 * "Description" is required and was not provided.
 */
export function formatError(err) {
  if (!err) return 'An unexpected error occurred';

  let rawMsg = '';

  if (typeof err === 'string') {
    rawMsg = err;
  } else if (err?.graphQLErrors && Array.isArray(err.graphQLErrors) && err.graphQLErrors.length > 0) {
    rawMsg = err.graphQLErrors.map((e) => e.message).join(' | ');
  } else if (err?.message) {
    rawMsg = err.message;
  } else {
    rawMsg = String(err);
  }

  if (!rawMsg) return 'An unexpected error occurred';

  // 1. GraphQL missing required field error:
  // e.g. Field "description" of required type "String!" was not provided.
  const requiredFieldMatch = rawMsg.match(/Field ["']?([^"'\s:]+)["']? of required type [^\s;]+ was not provided/i);
  if (requiredFieldMatch && requiredFieldMatch[1]) {
    const fieldName = requiredFieldMatch[1];
    const prettyName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1).replace(/([A-Z])/g, ' $1');
    return `"${prettyName}" is required and was not provided.`;
  }

  // 2. GraphQL invalid field type or value error:
  // e.g. Field "price" got invalid value "abc"
  const fieldInvalidMatch = rawMsg.match(/Field ["']?([^"'\s:]+)["']? (got invalid value [^;]+|is invalid)/i);
  if (fieldInvalidMatch && fieldInvalidMatch[1]) {
    const fieldName = fieldInvalidMatch[1];
    const prettyName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1).replace(/([A-Z])/g, ' $1');
    return `Invalid value provided for "${prettyName}".`;
  }

  // 3. Mongoose Validation Errors:
  // e.g. Product validation failed: description: Path `description` is required.
  const mongooseMatch = rawMsg.match(/Path `([^`]+)` is required/i);
  if (mongooseMatch && mongooseMatch[1]) {
    const fieldName = mongooseMatch[1];
    const prettyName = fieldName.charAt(0).toUpperCase() + fieldName.slice(1).replace(/([A-Z])/g, ' $1');
    return `"${prettyName}" is required.`;
  }

  // 4. Raw GraphQL variable dump cleanup if no specific regex matched:
  // e.g. Variable "$input" got invalid value {...}; Field "description" of required type...
  if (rawMsg.includes('Variable "$input" got invalid value') || rawMsg.includes('got invalid value')) {
    const fieldIdx = rawMsg.indexOf('Field ');
    if (fieldIdx !== -1) {
      return rawMsg.substring(fieldIdx).trim();
    }
    const parts = rawMsg.split(';');
    if (parts.length > 1) {
      return parts[parts.length - 1].trim();
    }
  }

  // 5. Clean up standard Apollo / Network prefixes
  let cleanMsg = rawMsg
    .replace(/^GraphQL error:\s*/i, '')
    .replace(/^Network error:\s*/i, '')
    .trim();

  return cleanMsg || 'An unexpected error occurred';
}

export default formatError;
