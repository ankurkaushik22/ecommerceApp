import React, { useState, useRef, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';

export default function RichTextEditor({
  value = '',
  onChange,
  error,
  label = 'Detailed Product Description',
  required = true,
  placeholder = 'Type product description here... Highlight text or use the toolbar above to format without any code.',
  minHeight = '180px',
}) {
  const [activeMode, setActiveMode] = useState('visual'); // 'visual' | 'code'
  const [codeValue, setCodeValue] = useState(value);
  const [showColorMenu, setShowColorMenu] = useState(false);
  const [showHighlightMenu, setShowHighlightMenu] = useState(false);
  const [showTemplateMenu, setShowTemplateMenu] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [currentBlock, setCurrentBlock] = useState('p');

  const editorRef = useRef(null);
  const lastEmittedValue = useRef(value);

  // Active formatting state for highlighting toolbar buttons
  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    strike: false,
    ul: false,
    ol: false,
    alignLeft: true,
    alignCenter: false,
    alignRight: false,
    blockquote: false,
  });

  // Sync incoming value with editor innerHTML only if changed externally
  useEffect(() => {
    if (activeMode === 'visual' && editorRef.current) {
      if (value !== lastEmittedValue.current && value !== editorRef.current.innerHTML) {
        editorRef.current.innerHTML = value || '';
        lastEmittedValue.current = value;
      }
    }
    setCodeValue(value || '');
  }, [value, activeMode]);

  // Initial mount: set innerHTML
  useEffect(() => {
    if (editorRef.current && value) {
      editorRef.current.innerHTML = value;
      lastEmittedValue.current = value;
    }
  }, []);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (!e.target.closest('.rte-popover')) {
        setShowColorMenu(false);
        setShowHighlightMenu(false);
        setShowTemplateMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const updateActiveFormats = useCallback(() => {
    if (typeof document === 'undefined' || activeMode !== 'visual') return;
    try {
      setActiveFormats({
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        strike: document.queryCommandState('strikeThrough'),
        ul: document.queryCommandState('insertUnorderedList'),
        ol: document.queryCommandState('insertOrderedList'),
        alignLeft: document.queryCommandState('justifyLeft'),
        alignCenter: document.queryCommandState('justifyCenter'),
        alignRight: document.queryCommandState('justifyRight'),
        blockquote: document.queryCommandValue('formatBlock') === 'blockquote',
      });

      const block = document.queryCommandValue('formatBlock') || 'p';
      setCurrentBlock(block.toLowerCase());
    } catch {
      // ignore
    }
  }, [activeMode]);

  // Execute formatting command without losing focus or selection
  const exec = (command, commandValue = null) => {
    if (editorRef.current) {
      editorRef.current.focus();
    }
    document.execCommand(command, false, commandValue);
    handleEditorInput();
    updateActiveFormats();
  };

  const handleEditorInput = () => {
    if (!editorRef.current) return;
    const html = editorRef.current.innerHTML;
    // Normalize empty tags
    const cleanHtml =
      html === '<p><br></p>' || html === '<p></p>' || html === '<br>' || html.trim() === ''
        ? ''
        : html;
    lastEmittedValue.current = cleanHtml;
    setCodeValue(cleanHtml);
    if (onChange) {
      onChange(cleanHtml);
    }
  };

  const handleBlockChange = (tag) => {
    exec('formatBlock', `<${tag}>`);
    setCurrentBlock(tag);
  };

  const handleAddLink = () => {
    if (!linkUrl.trim()) return;
    let url = linkUrl.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://') && !url.startsWith('mailto:')) {
      url = `https://${url}`;
    }
    exec('createLink', url);
    setLinkUrl('');
    setShowLinkModal(false);
    toast.success('Link added');
  };

  const handleInsertTemplate = (templateHtml, name) => {
    if (editorRef.current) {
      editorRef.current.focus();
      const current = editorRef.current.innerHTML.trim();
      if (!current || current === '<p><br></p>' || current === '<br>') {
        editorRef.current.innerHTML = templateHtml;
      } else {
        document.execCommand('insertHTML', false, `<br/>${templateHtml}`);
      }
      handleEditorInput();
      setShowTemplateMenu(false);
      toast.success(`${name} template inserted!`);
    }
  };

  const handleInsertTable = () => {
    const tableHtml = `
      <table style="width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 13px;">
        <thead>
          <tr style="background-color: #f1f5f9; text-align: left;">
            <th style="border: 1px solid #cbd5e1; padding: 6px 10px; font-weight: 600;">Specification</th>
            <th style="border: 1px solid #cbd5e1; padding: 6px 10px; font-weight: 600;">Details</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="border: 1px solid #cbd5e1; padding: 6px 10px;">Material</td>
            <td style="border: 1px solid #cbd5e1; padding: 6px 10px;">100% Premium Cotton</td>
          </tr>
          <tr>
            <td style="border: 1px solid #cbd5e1; padding: 6px 10px;">Fit</td>
            <td style="border: 1px solid #cbd5e1; padding: 6px 10px;">Regular Fit</td>
          </tr>
        </tbody>
      </table>
      <p><br></p>
    `;
    if (editorRef.current) {
      editorRef.current.focus();
      document.execCommand('insertHTML', false, tableHtml);
      handleEditorInput();
      toast.success('Table template inserted');
    }
  };

  const handleSwitchToVisual = () => {
    setActiveMode('visual');
    if (editorRef.current) {
      editorRef.current.innerHTML = codeValue;
      lastEmittedValue.current = codeValue;
      if (onChange) onChange(codeValue);
    }
  };

  const handleSwitchToCode = () => {
    if (editorRef.current) {
      setCodeValue(editorRef.current.innerHTML);
    }
    setActiveMode('code');
  };

  const handleCodeChange = (e) => {
    const newVal = e.target.value;
    setCodeValue(newVal);
    lastEmittedValue.current = newVal;
    if (onChange) onChange(newVal);
  };

  return (
    <div className="space-y-2">
      {/* Top Header with Label and Mode Switcher */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-700">
            {label} {required && <span className="text-rose-500">*</span>}
          </label>
          <p className="text-[11px] text-slate-500 font-medium">
            Visual editor — style text freely with buttons. No HTML or coding required!
          </p>
        </div>

        {/* Mode Switcher */}
        <div className="inline-flex items-center p-0.5 bg-slate-100 border border-slate-200 rounded-xl">
          <button
            type="button"
            onClick={handleSwitchToVisual}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeMode === 'visual'
                ? 'bg-white text-primary-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>📝</span> Visual Editor
          </button>
          <button
            type="button"
            onClick={handleSwitchToCode}
            className={`px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
              activeMode === 'code'
                ? 'bg-white text-primary-700 shadow-xs border border-slate-200/80'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Switch to raw HTML view (for developers)"
          >
            <span>&lt;/&gt;</span> HTML Source
          </button>
        </div>
      </div>

      {/* Editor Main Container */}
      <div className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs focus-within:ring-2 focus-within:ring-primary-500/20 focus-within:border-primary-500 transition-all">
        {/* Visual Mode Toolbar */}
        {activeMode === 'visual' && (
          <div className="bg-slate-50 border-b border-slate-200 p-2 flex items-center flex-wrap gap-1 select-none">
            {/* Paragraph / Heading Dropdown */}
            <select
              value={currentBlock}
              onChange={(e) => handleBlockChange(e.target.value)}
              className="text-xs font-semibold bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-700 focus:outline-none focus:ring-1 focus:ring-primary-500 cursor-pointer shadow-2xs mr-1"
            >
              <option value="p">Normal Text (Paragraph)</option>
              <option value="h2">Large Title (H2)</option>
              <option value="h3">Medium Heading (H3)</option>
              <option value="h4">Small Heading (H4)</option>
            </select>

            <div className="h-5 w-px bg-slate-200 mx-1" />

            {/* Basic Formatting Buttons */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('bold');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                activeFormats.bold
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Bold (Ctrl+B)"
            >
              B
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('italic');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs font-serif italic font-bold transition-all cursor-pointer ${
                activeFormats.italic
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Italic (Ctrl+I)"
            >
              I
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('underline');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs underline font-bold transition-all cursor-pointer ${
                activeFormats.underline
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Underline (Ctrl+U)"
            >
              U
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('strikeThrough');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs line-through font-bold transition-all cursor-pointer ${
                activeFormats.strike
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Strikethrough"
            >
              S
            </button>

            <div className="h-5 w-px bg-slate-200 mx-1" />

            {/* Lists */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('insertUnorderedList');
              }}
              className={`px-2 h-7 flex items-center gap-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeFormats.ul
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Bullet Points"
            >
              <span className="text-sm">•</span> List
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('insertOrderedList');
              }}
              className={`px-2 h-7 flex items-center gap-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeFormats.ol
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Numbered List"
            >
              <span className="text-xs">1.</span> List
            </button>

            <div className="h-5 w-px bg-slate-200 mx-1" />

            {/* Alignment */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('justifyLeft');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs transition-all cursor-pointer ${
                activeFormats.alignLeft
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Align Left"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="3" y1="12" x2="15" y2="12" />
                <line x1="3" y1="18" x2="18" y2="18" />
              </svg>
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('justifyCenter');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs transition-all cursor-pointer ${
                activeFormats.alignCenter
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Align Center"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="6" y1="12" x2="18" y2="12" />
                <line x1="4" y1="18" x2="20" y2="18" />
              </svg>
            </button>

            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('justifyRight');
              }}
              className={`w-7 h-7 flex items-center justify-center rounded-lg text-xs transition-all cursor-pointer ${
                activeFormats.alignRight
                  ? 'bg-primary-100 text-primary-700 border border-primary-300 shadow-2xs'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
              title="Align Right"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="3" y1="6" x2="21" y2="6" />
                <line x1="9" y1="12" x2="21" y2="12" />
                <line x1="6" y1="18" x2="21" y2="18" />
              </svg>
            </button>

            <div className="h-5 w-px bg-slate-200 mx-1" />

            {/* Colors Menu Popover */}
            <div className="relative rte-popover">
              <button
                type="button"
                onClick={() => {
                  setShowColorMenu(!showColorMenu);
                  setShowHighlightMenu(false);
                }}
                className="px-2 h-7 flex items-center gap-1 rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
                title="Text Color"
              >
                <span className="text-red-500 font-extrabold">A</span>
                <span className="text-[10px]">▼</span>
              </button>

              {showColorMenu && (
                <div className="absolute left-0 top-8 z-30 bg-white border border-slate-200 rounded-xl p-2 shadow-lg flex gap-1.5 animate-fade-in">
                  {[
                    { color: '#0f172a', label: 'Dark' },
                    { color: '#4f46e5', label: 'Indigo' },
                    { color: '#059669', label: 'Green' },
                    { color: '#d97706', label: 'Amber' },
                    { color: '#dc2626', label: 'Red' },
                    { color: '#64748b', label: 'Muted' },
                  ].map((c) => (
                    <button
                      key={c.color}
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        exec('foreColor', c.color);
                        setShowColorMenu(false);
                      }}
                      className="w-5 h-5 rounded-full border border-slate-300 hover:scale-110 transition-transform cursor-pointer"
                      style={{ backgroundColor: c.color }}
                      title={c.label}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Highlighter Menu */}
            <div className="relative rte-popover">
              <button
                type="button"
                onClick={() => {
                  setShowHighlightMenu(!showHighlightMenu);
                  setShowColorMenu(false);
                }}
                className="px-2 h-7 flex items-center gap-1 rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
                title="Highlight Background Color"
              >
                <span className="bg-yellow-200 px-1 rounded text-slate-800 text-[11px] font-bold">🖍️</span>
              </button>

              {showHighlightMenu && (
                <div className="absolute left-0 top-8 z-30 bg-white border border-slate-200 rounded-xl p-2 shadow-lg flex gap-1.5 animate-fade-in">
                  {[
                    { color: '#fef08a', label: 'Yellow' },
                    { color: '#bbf7d0', label: 'Green' },
                    { color: '#bfdbfe', label: 'Blue' },
                    { color: '#fbcfe8', label: 'Pink' },
                    { color: 'transparent', label: 'Clear' },
                  ].map((h) => (
                    <button
                      key={h.color}
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        exec('hiliteColor', h.color);
                        setShowHighlightMenu(false);
                      }}
                      className="w-5 h-5 rounded border border-slate-300 hover:scale-110 transition-transform cursor-pointer flex items-center justify-center text-[10px]"
                      style={{ backgroundColor: h.color === 'transparent' ? '#fff' : h.color }}
                      title={h.label}
                    >
                      {h.color === 'transparent' ? '✕' : ''}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="h-5 w-px bg-slate-200 mx-1" />

            {/* Blockquote */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('formatBlock', '<blockquote>');
              }}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
              title="Quote Box"
            >
              ❝
            </button>

            {/* Horizontal Line */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('insertHorizontalRule');
              }}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
              title="Horizontal Divider Line"
            >
              ―
            </button>

            {/* Table */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                handleInsertTable();
              }}
              className="px-2 h-7 flex items-center gap-1 rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
              title="Insert Spec Table"
            >
              📊 Table
            </button>

            {/* Link */}
            <button
              type="button"
              onClick={() => setShowLinkModal(true)}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
              title="Insert Link"
            >
              🔗
            </button>

            {/* Clear Formatting */}
            <button
              type="button"
              onMouseDown={(e) => {
                e.preventDefault();
                exec('removeFormat');
              }}
              className="w-7 h-7 flex items-center justify-center rounded-lg text-xs font-bold bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
              title="Clear Styles / Formatting"
            >
              🧹
            </button>

            {/* 1-Click Quick Templates Menu */}
            <div className="relative ml-auto rte-popover">
              <button
                type="button"
                onClick={() => setShowTemplateMenu(!showTemplateMenu)}
                className="px-2.5 h-7 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-all cursor-pointer shadow-2xs"
                title="Insert ready-made description templates"
              >
                <span>✨</span> Quick Templates <span className="text-[9px]">▼</span>
              </button>

              {showTemplateMenu && (
                <div className="absolute right-0 top-8 z-30 w-56 bg-white border border-slate-200 rounded-xl p-1.5 shadow-xl animate-fade-in space-y-1">
                  <div className="px-2 py-1 text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                    Insert Ready Template:
                  </div>

                  <button
                    type="button"
                    onClick={() =>
                      handleInsertTemplate(
                        `<h3>Key Features & Highlights</h3>
<ul>
  <li><strong>Material & Build:</strong> Crafted with high-grade premium materials.</li>
  <li><strong>Comfort & Design:</strong> Ergonomic, comfortable and built for everyday use.</li>
  <li><strong>Performance:</strong> Tested rigorously to provide maximum durability.</li>
</ul>`,
                        'Product Highlights'
                      )
                    }
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 font-medium transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <span>🌟</span> Key Highlights
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleInsertTemplate(
                        `<h3>Care & Washing Instructions</h3>
<ul>
  <li>Machine wash cold with similar colors.</li>
  <li>Do not bleach or dry clean.</li>
  <li>Warm iron on reverse side if needed.</li>
</ul>`,
                        'Care Instructions'
                      )
                    }
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 font-medium transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <span>🧼</span> Care Instructions
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleInsertTemplate(
                        `<h3>Package Contents</h3>
<ul>
  <li>1 x Main Product Unit</li>
  <li>1 x User Manual & Warranty Card</li>
  <li>1 x Accessories Kit</li>
</ul>`,
                        'Package Contents'
                      )
                    }
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 font-medium transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <span>📦</span> Package Contents
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleInsertTemplate(
                        `<h3>Product Specifications</h3>
<ul>
  <li><strong>Fabric:</strong> 100% Combed Cotton</li>
  <li><strong>Fit Type:</strong> Regular Comfort Fit</li>
  <li><strong>Pattern:</strong> Solid Plain</li>
  <li><strong>Country of Origin:</strong> India</li>
</ul>`,
                        'Specifications List'
                      )
                    }
                    className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 font-medium transition-colors cursor-pointer flex items-center gap-2"
                  >
                    <span>📋</span> Specifications List
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Visual Content Editable Area */}
        {activeMode === 'visual' ? (
          <div className="relative">
            <div
              ref={editorRef}
              contentEditable={true}
              onInput={handleEditorInput}
              onKeyUp={updateActiveFormats}
              onMouseUp={updateActiveFormats}
              onTouchEnd={updateActiveFormats}
              onFocus={updateActiveFormats}
              className="w-full p-4 text-slate-800 text-sm leading-relaxed focus:outline-none overflow-y-auto rich-editor-content"
              style={{ minHeight }}
              data-placeholder={placeholder}
            />
          </div>
        ) : (
          /* HTML Source View (For Advanced/Dev Use) */
          <div className="relative">
            <div className="bg-slate-900 text-slate-300 text-[11px] px-3 py-1.5 font-mono flex items-center justify-between border-b border-slate-800">
              <span>HTML Source Code</span>
              <span className="text-slate-500">Edit directly or switch back to Visual Editor</span>
            </div>
            <textarea
              value={codeValue}
              onChange={handleCodeChange}
              rows={8}
              className="w-full p-4 font-mono text-xs text-slate-900 bg-slate-50 focus:outline-none border-0 resize-y"
              style={{ minHeight }}
              placeholder="Paste or write HTML tags here..."
            />
          </div>
        )}

        {/* Bottom Helper Bar */}
        <div className="px-3 py-2 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600">Tip:</span>
            <span>You can paste formatted text from Google Docs or Word directly.</span>
          </div>

          <div className="flex items-center gap-3">
            <span>Characters: {codeValue ? codeValue.replace(/<[^>]*>/g, '').length : 0}</span>
            <span>•</span>
            <span>Words: {codeValue ? codeValue.replace(/<[^>]*>/g, '').trim().split(/\s+/).filter(Boolean).length : 0}</span>
          </div>
        </div>
      </div>

      {/* Link Input Modal */}
      {showLinkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-xs p-4">
          <div className="bg-white rounded-2xl p-5 w-full max-w-sm shadow-2xl border border-slate-200 animate-scale-up space-y-4">
            <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span>🔗</span> Insert Web Link
            </h4>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Destination URL (e.g. Size Chart, Brand Guide)
              </label>
              <input
                type="text"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                placeholder="https://example.com/guide"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-primary-500 focus:outline-none"
                autoFocus
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddLink();
                  }
                }}
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowLinkModal(false);
                  setLinkUrl('');
                }}
                className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddLink}
                className="px-4 py-1.5 text-xs font-bold text-white bg-primary-600 hover:bg-primary-700 rounded-lg shadow-xs cursor-pointer"
              >
                Apply Link
              </button>
            </div>
          </div>
        </div>
      )}

      {error && <p className="text-xs text-rose-500 font-semibold mt-1">{error}</p>}
    </div>
  );
}
