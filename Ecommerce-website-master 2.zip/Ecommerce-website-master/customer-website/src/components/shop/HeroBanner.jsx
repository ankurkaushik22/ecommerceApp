'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeftIcon, ChevronRightIcon, SparklesIcon } from '@heroicons/react/24/outline';
import { useQuery } from '@apollo/client';
import { GET_BANNERS } from '../../graphql/queries';

const DEFAULT_FALLBACK_BANNERS = {
  food: [
    {
      _id: 'fb-food-1',
      title: 'Crave It. Get It Fast.',
      subtitle: 'Up to 50% OFF on Top Food Brands near you',
      tag: 'FOOD FESTIVAL',
      image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1400',
      link: '/food',
      discount: '50% OFF',
      vertical: 'food',
    },
    {
      _id: 'fb-food-2',
      title: 'Royal Biryani & Mughlai',
      subtitle: 'Authentic dum cooked biryanis starting @ ₹199',
      tag: 'CHEF SPECIAL',
      image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=1400',
      link: '/food',
      discount: 'FREE DELIVERY',
      vertical: 'food',
    },
  ],
  grocery: [
    {
      _id: 'fb-g-1',
      title: 'Fresh Greens, Lower Prices',
      subtitle: 'Farm fresh fruits & vegetables delivered in minutes',
      tag: 'WEEKLY DEALS',
      image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=1400',
      link: '/grocery',
      discount: 'UP TO 40% OFF',
      vertical: 'grocery',
    },
    {
      _id: 'fb-g-2',
      title: 'Daily Essentials & Dairy',
      subtitle: 'Fresh milk, artisan sourdough bread & pantry staples',
      tag: 'SUPER SAVINGS',
      image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=1400',
      link: '/grocery',
      discount: 'FLAT ₹100 OFF',
      vertical: 'grocery',
    },
  ],
  shopping: [
    {
      _id: 'fb-s-1',
      title: 'New Season Collections',
      subtitle: 'Discover trending fashion, electronics & lifestyle accessories',
      tag: 'FLASH SALE',
      image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1400',
      link: '/shop',
      discount: 'UP TO 60% OFF',
      vertical: 'shopping',
    },
  ],
};

export default function HeroBanner({ vertical }) {
  const [current, setCurrent] = useState(0);
  const { data, loading, error } = useQuery(GET_BANNERS, {
    variables: { platform: 'website', ...(vertical && { vertical }) },
    fetchPolicy: 'cache-and-network',
  });

  const fetchedSlides = data?.getBanners || [];
  const fallbacks = DEFAULT_FALLBACK_BANNERS[vertical] || DEFAULT_FALLBACK_BANNERS.shopping;
  const slides = fetchedSlides.length > 0 ? fetchedSlides : fallbacks;

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const prevSlide = () => setCurrent((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  const nextSlide = () => setCurrent((prev) => (prev + 1) % slides.length);

  if (loading && slides.length === 0) {
    return (
      <div className="relative w-full overflow-hidden rounded-3xl shadow-xl aspect-[16/9] sm:aspect-[21/9] md:aspect-[7/2] lg:aspect-[4/1] min-h-[220px] max-h-[360px] bg-gray-100 animate-pulse flex items-center justify-center">
        <span className="text-gray-400 font-medium text-sm">Loading promotional banners...</span>
      </div>
    );
  }

  if (slides.length === 0) return null;

  const currentSlide = slides[current] || slides[0];

  return (
    <div className="relative w-full overflow-hidden rounded-3xl shadow-xl aspect-[16/9] sm:aspect-[21/9] md:aspect-[7/2] lg:aspect-[4/1] min-h-[220px] max-h-[360px] bg-gray-900 group">
      <AnimatePresence mode="wait">
        <Link
          key={currentSlide._id || current}
          href={currentSlide.link || '#'}
          className="absolute inset-0 block group/link cursor-pointer"
        >
          <motion.div
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.7 }}
            className="relative w-full h-full"
          >
            {/* Background Image */}
            <img
              src={currentSlide.image}
              alt={currentSlide.title || 'Banner'}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover/link:scale-105"
            />

            {/* Gradient Overlay for Text Readability */}
            {(currentSlide.title || currentSlide.subtitle || currentSlide.tag) && (
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950/85 via-slate-950/45 to-transparent flex items-center p-6 sm:p-10 md:p-12">
                <div className="max-w-xl space-y-2 sm:space-y-3">
                  {currentSlide.tag && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] sm:text-xs font-black tracking-wider uppercase bg-emerald-500/90 text-white shadow-sm backdrop-blur-xs">
                      <SparklesIcon className="w-3.5 h-3.5" />
                      <span>{currentSlide.tag}</span>
                    </span>
                  )}
                  {currentSlide.title && (
                    <h2 className="text-xl sm:text-3xl md:text-4xl font-black text-white leading-tight drop-shadow-md">
                      {currentSlide.title}
                    </h2>
                  )}
                  {currentSlide.subtitle && (
                    <p className="text-xs sm:text-sm font-medium text-gray-200 line-clamp-2 drop-shadow-xs">
                      {currentSlide.subtitle}
                    </p>
                  )}
                  {currentSlide.discount && (
                    <div className="pt-1">
                      <span className="inline-block bg-orange-500 text-white text-xs sm:text-sm font-black px-4 py-1.5 rounded-xl shadow-md">
                        {currentSlide.discount}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </Link>
      </AnimatePresence>

      {/* Nav Controls */}
      {slides.length > 1 && (
        <>
          <button
            onClick={(e) => { e.preventDefault(); prevSlide(); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-md border border-white/20 transition-all z-20 opacity-0 group-hover:opacity-100 cursor-pointer"
            aria-label="Previous Slide"
          >
            <ChevronLeftIcon className="w-5 h-5 stroke-[2.5]" />
          </button>
          <button
            onClick={(e) => { e.preventDefault(); nextSlide(); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-md border border-white/20 transition-all z-20 opacity-0 group-hover:opacity-100 cursor-pointer"
            aria-label="Next Slide"
          >
            <ChevronRightIcon className="w-5 h-5 stroke-[2.5]" />
          </button>

          {/* Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={(e) => { e.preventDefault(); setCurrent(i); }}
                className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                  i === current ? 'w-8 bg-orange-500 shadow-sm' : 'w-2 bg-white/50 hover:bg-white/80'
                }`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
