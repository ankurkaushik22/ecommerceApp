'use client';
import Link from 'next/link';

export default function AppLandingPage({ settings }) {
  const storeName = settings?.storeName || 'Suaaka';
  const logoUrl = settings?.logoUrl;
  const appIconUrl = settings?.appIconUrl;
  
  const apkUrl = settings?.customerApkUrl || '#';
  const playStoreUrl = settings?.customerPlayStoreUrl || '#';
  const iosUrl = settings?.customerIosUrl || '#';

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Navbar */}
      <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {logoUrl ? (
              <img src={logoUrl} alt={storeName} className="h-10 w-auto object-contain" />
            ) : appIconUrl ? (
              <img src={appIconUrl} alt={storeName} className="h-10 w-10 rounded-xl" />
            ) : (
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-emerald-500/20">
                {storeName.charAt(0)}
              </div>
            )}
            <span className="text-xl font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
              {storeName}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/business/register"
              className="text-xs sm:text-sm font-bold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-4 py-2.5 rounded-full border border-slate-700/80 transition-all cursor-pointer"
            >
              Partner with us 💼
            </Link>
          </div>
        </div>
      </header>

      {/* Main Hero Section */}
      <main className="flex-1 flex flex-col justify-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left Column: Headlines & Download Buttons */}
            <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <span>📱</span> Official Customer Mobile App
              </div>

              <h1 className="text-4xl sm:text-6xl font-black tracking-tight leading-[1.1] text-white">
                Everything you need, <br />
                <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
                  delivered fast on mobile.
                </span>
              </h1>

              <p className="text-slate-400 text-base sm:text-lg max-w-2xl font-medium leading-relaxed mx-auto lg:mx-0">
                Download the official <strong className="text-slate-200">{storeName}</strong> Mobile App on Android and iOS. Shop retail products, order restaurant food, get instant grocery delivery, and book home services.
              </p>

              {/* Download Buttons Bar */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
                {/* Direct Android APK Download */}
                <a
                  href={apkUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group relative inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-sm shadow-xl shadow-emerald-500/25 transition-all duration-200 hover:scale-[1.03] active:scale-95 cursor-pointer border border-emerald-400/30"
                >
                  <span className="text-2xl">🤖</span>
                  <div className="text-left">
                    <div className="text-[10px] uppercase font-bold text-emerald-100 opacity-90">Direct Download</div>
                    <div className="text-base font-black leading-tight">Android APK</div>
                  </div>
                </a>

                {/* Google Play Store Link */}
                {playStoreUrl && playStoreUrl !== '#' && (
                  <a
                    href={playStoreUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-sm border border-slate-700/80 transition-all duration-200 hover:scale-[1.03] active:scale-95 cursor-pointer shadow-lg"
                  >
                    <span className="text-2xl">🛍️</span>
                    <div className="text-left">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Get it on</div>
                      <div className="text-base font-black leading-tight">Google Play</div>
                    </div>
                  </a>
                )}

                {/* Apple iOS App Store */}
                {iosUrl && iosUrl !== '#' && (
                  <a
                    href={iosUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-3 px-6 py-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-sm border border-slate-700/80 transition-all duration-200 hover:scale-[1.03] active:scale-95 cursor-pointer shadow-lg"
                  >
                    <span className="text-2xl">🍎</span>
                    <div className="text-left">
                      <div className="text-[10px] uppercase font-bold text-slate-400">Download on the</div>
                      <div className="text-base font-black leading-tight">App Store</div>
                    </div>
                  </a>
                )}
              </div>

              {/* Status Note */}
              <div className="flex items-center justify-center lg:justify-start gap-4 text-xs font-semibold text-slate-400 pt-2">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  Fast & Secure Install
                </span>
                <span>•</span>
                <span>Version 1.0.0</span>
                <span>•</span>
                <span>No Ads</span>
              </div>
            </div>

            {/* Right Column: Mobile App Preview Mockup */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="relative w-full max-w-sm">
                {/* Glow Backdrop */}
                <div className="absolute -inset-4 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 rounded-3xl blur-2xl opacity-75"></div>
                
                {/* Phone Frame */}
                <div className="relative bg-slate-800 border-4 border-slate-700/80 rounded-[40px] p-4 shadow-2xl space-y-4">
                  <div className="w-24 h-4 bg-slate-900 rounded-full mx-auto mb-2"></div>
                  
                  {/* Inside App Preview Card */}
                  <div className="bg-slate-900 rounded-[28px] p-5 border border-slate-700/60 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-emerald-500 flex items-center justify-center text-white font-black">
                          {storeName.charAt(0)}
                        </div>
                        <span className="font-extrabold text-sm text-white">{storeName} App</span>
                      </div>
                      <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full">LIVE</span>
                    </div>

                    {/* App Verticals Grid */}
                    <div className="grid grid-cols-2 gap-2.5">
                      <div className="bg-purple-500/10 border border-purple-500/20 p-3 rounded-2xl text-center space-y-1">
                        <span className="text-2xl">🛍️</span>
                        <div className="text-xs font-bold text-purple-300">Shopping</div>
                        <div className="text-[10px] text-slate-400">10k+ Products</div>
                      </div>
                      <div className="bg-amber-500/10 border border-amber-500/20 p-3 rounded-2xl text-center space-y-1">
                        <span className="text-2xl">🍔</span>
                        <div className="text-xs font-bold text-amber-300">Food</div>
                        <div className="text-[10px] text-slate-400">30 Min Delivery</div>
                      </div>
                      <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-2xl text-center space-y-1">
                        <span className="text-2xl">🥦</span>
                        <div className="text-xs font-bold text-emerald-300">Grocery</div>
                        <div className="text-[10px] text-slate-400">Fresh Staples</div>
                      </div>
                      <div className="bg-blue-500/10 border border-blue-500/20 p-3 rounded-2xl text-center space-y-1">
                        <span className="text-2xl">🛠️</span>
                        <div className="text-xs font-bold text-blue-300">Services</div>
                        <div className="text-[10px] text-slate-400">Book Experts</div>
                      </div>
                    </div>

                    <a
                      href={apkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block w-full py-3 text-center bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-colors cursor-pointer"
                    >
                      DOWNLOAD APK NOW
                    </a>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* 4 Category Highlights Grid Section */}
        <div className="border-t border-slate-800 bg-slate-950/60 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center space-y-2 mb-12">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Why Download {storeName}?</h2>
              <p className="text-sm text-slate-400">All four major super-app verticals built into one mobile experience.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* Shopping */}
              <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-2xl">
                  🛍️
                </div>
                <h3 className="text-lg font-bold text-white">Online Shopping</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Browse electronics, apparel, cosmetics, and accessories with instant checkout & fast shipping.
                </p>
              </div>

              {/* Food */}
              <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-2xl">
                  🍔
                </div>
                <h3 className="text-lg font-bold text-white">Food Delivery</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Order hot meals, snacks, and beverages from top local restaurants with live order tracking.
                </p>
              </div>

              {/* Grocery */}
              <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-2xl">
                  🥦
                </div>
                <h3 className="text-lg font-bold text-white">Fresh Grocery</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Fresh fruits, vegetables, dairy, meat, and everyday staples delivered right to your door.
                </p>
              </div>

              {/* Services */}
              <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-2xl">
                  🛠️
                </div>
                <h3 className="text-lg font-bold text-white">On-Demand Services</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Book verified home repair technicians, plumbers, electricians, cleaning & salon professionals.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} {storeName}. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link href="/business/register" className="hover:text-slate-300 transition-colors font-medium">
              Sell on {storeName}
            </Link>
            <Link href="/privacy" className="hover:text-slate-300 transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
