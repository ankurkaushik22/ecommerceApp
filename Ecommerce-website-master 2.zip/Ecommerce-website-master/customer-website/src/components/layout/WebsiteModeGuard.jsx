'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useQuery } from '@apollo/client';
import { GET_STORE_SETTINGS } from '@/graphql/queries';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import AppLandingPage from '@/components/layout/AppLandingPage';

function parseApkUrlTags(rawApkUrl) {
  if (!rawApkUrl) return { tagMode: null, cleanApkUrl: '', playUrl: '', iosUrl: '' };
  const modeMatch = rawApkUrl.match(/\[MODE:([^\]]+)\]/);
  const playMatch = rawApkUrl.match(/\[PLAY:([^\]]+)\]/);
  const iosMatch = rawApkUrl.match(/\[IOS:([^\]]+)\]/);
  const cleanApkUrl = rawApkUrl.replace(/\[MODE:[^\]]*\]/g, '').replace(/\[PLAY:[^\]]*\]/g, '').replace(/\[IOS:[^\]]*\]/g, '');
  return {
    tagMode: modeMatch ? modeMatch[1] : null,
    cleanApkUrl,
    playUrl: playMatch ? playMatch[1] : '',
    iosUrl: iosMatch ? iosMatch[1] : '',
  };
}

export default function WebsiteModeGuard({ children }) {
  const pathname = usePathname();
  const isAllowedPath = pathname?.startsWith('/business');

  const { data, loading } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });

  const [cachedMode, setCachedMode] = useState(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const urlMode = searchParams.get('mode');
      const savedMode = localStorage.getItem('websiteDisplayMode');
      return urlMode || savedMode || null;
    }
    return null;
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const searchParams = new URLSearchParams(window.location.search);
      const urlMode = searchParams.get('mode');
      const savedMode = localStorage.getItem('websiteDisplayMode');
      if (urlMode) {
        setCachedMode(urlMode);
      } else if (savedMode) {
        setCachedMode(savedMode);
      }
    }
  }, []);

  const settings = data?.getStoreSettings;
  const { tagMode, cleanApkUrl, playUrl, iosUrl } = parseApkUrlTags(settings?.customerApkUrl);

  useEffect(() => {
    const activeMode = tagMode || settings?.websiteDisplayMode;
    if (activeMode) {
      setCachedMode(activeMode);
      if (typeof window !== 'undefined') {
        localStorage.setItem('websiteDisplayMode', activeMode);
      }
    }
  }, [tagMode, settings?.websiteDisplayMode]);

  const effectiveMode = cachedMode || tagMode || settings?.websiteDisplayMode;
  const isLandingPageMode = effectiveMode === 'landing_page' || effectiveMode === 'landing';

  const effectiveSettings = settings ? {
    ...settings,
    customerApkUrl: cleanApkUrl || settings.customerApkUrl,
    customerPlayStoreUrl: playUrl || settings.customerPlayStoreUrl || '',
    customerIosUrl: iosUrl || settings.customerIosUrl || '',
  } : null;

  if (isLandingPageMode) {
    if (isAllowedPath) {
      const storeName = effectiveSettings?.storeName || 'Suaaka';
      return (
        <div className="min-h-screen bg-slate-900 text-white flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
          <header className="border-b border-slate-800/80 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
              <Link href="/" className="flex items-center gap-3">
                {effectiveSettings?.logoUrl ? (
                  <img src={effectiveSettings.logoUrl} alt={storeName} className="h-10 w-auto object-contain" />
                ) : (
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-emerald-500/20">
                    {storeName.charAt(0)}
                  </div>
                )}
                <span className="text-xl font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent flex items-center gap-2">
                  {storeName} <span className="text-emerald-400 font-extrabold text-xs uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20">Partner</span>
                </span>
              </Link>

              <Link
                href="/"
                className="text-xs sm:text-sm font-bold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-4 py-2.5 rounded-full border border-slate-700/80 transition-all cursor-pointer flex items-center gap-2"
              >
                <span>📲</span> Back to App Download
              </Link>
            </div>
          </header>

          <main className="flex-1 flex flex-col items-center pt-6 sm:pt-10 pb-16 px-4">
            {children}
          </main>
        </div>
      );
    }
    return <AppLandingPage settings={effectiveSettings} />;
  }

  // If loading settings and display mode is not yet known, show dark loading screen instead of flashing website storefront
  if ((loading && !settings && !cachedMode) || (!data && !cachedMode)) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <>
      <Header />
      <main className="flex-1 w-full max-w-full">
        {children}
      </main>
      <Footer />
    </>
  );
}
