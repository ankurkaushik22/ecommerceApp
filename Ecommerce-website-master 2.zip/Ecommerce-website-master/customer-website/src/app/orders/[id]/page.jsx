'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useSubscription, gql } from '@apollo/client';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import {
  CheckCircleIcon, ClockIcon, TruckIcon,
  XCircleIcon, MapPinIcon, PhoneIcon, UserIcon,
  ArrowLeftIcon, DocumentTextIcon, StarIcon,
  SparklesIcon, PrinterIcon, XMarkIcon,
  ShareIcon, EnvelopeIcon,
} from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_ORDER } from '@/graphql/queries';
import { CANCEL_ORDER, ADD_REVIEW, REQUEST_RETURN } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

const ORDER_SUBSCRIPTION = gql`
  subscription OnOrderStatusUpdated($orderId: ID!) {
    orderStatusUpdated(orderId: $orderId) {
      _id status paymentStatus deliverySlot vendorNotes trackingUpdates { status message timestamp location }
    }
  }
`;

const STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'We have received your order' },
  { key: 'accepted', label: 'Order Accepted', desc: 'Seller accepted the order' },
  { key: 'processing', label: 'Processing', desc: 'Item is being packed & prepared' },
  { key: 'ready_for_pickup', label: 'Ready for Pickup', desc: 'Package ready for courier' },
  { key: 'picked_up', label: 'Picked Up', desc: 'Courier agent picked up the package' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Courier agent is on the way' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered to your address' },
];

export default function OrderTrackingPage() {
  const params = useParams();
  const router = useRouter();
  const orderId = params?.id ? decodeURIComponent(params.id) : '';

  const [cancelReason, setCancelReason] = useState('');
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [returnReason, setReturnReason] = useState('');
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  // Review modal states
  const [reviewTab, setReviewTab] = useState('product'); // 'product' | 'delivery'
  const [selectedProductId, setSelectedProductId] = useState('');
  
  // Independent review states
  const [productRating, setProductRating] = useState(5);
  const [productTitle, setProductTitle] = useState('');
  const [productComment, setProductComment] = useState('');

  const [deliveryRating, setDeliveryRating] = useState(5);
  const [deliveryTitle, setDeliveryTitle] = useState('');
  const [deliveryComment, setDeliveryComment] = useState('');

  const { data, loading, error, refetch } = useQuery(GET_ORDER, {
    variables: { id: orderId },
    skip: !orderId,
    fetchPolicy: 'cache-and-network',
  });

  // Listen to live subscription updates
  const { data: subData } = useSubscription(ORDER_SUBSCRIPTION, {
    variables: { orderId },
    skip: !orderId,
  });

  const order = data?.getOrder;

  useEffect(() => {
    if (subData?.orderStatusUpdated) {
      if (order && subData.orderStatusUpdated.status !== order.status) {
        toast.success(`Order status updated to: ${subData.orderStatusUpdated.status.replace(/_/g, ' ')}`);
      }
      refetch();
    }
  }, [subData, order?.status, refetch]);

  const [cancelOrderMutation, { loading: cancelling }] = useMutation(CANCEL_ORDER, {
    onCompleted: () => {
      toast.success('Order cancelled');
      setShowCancelModal(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [requestReturnMutation, { loading: requestingReturn }] = useMutation(REQUEST_RETURN, {
    onCompleted: () => {
      toast.success('Return request submitted successfully');
      setShowReturnModal(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [addReviewMutation] = useMutation(ADD_REVIEW);
  const [submittingBoth, setSubmittingBoth] = useState(false);

  

  useEffect(() => {
    if (order?.items?.[0]?.product?._id) {
      setSelectedProductId(order.items[0].product._id);
    }
  }, [order]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
        <div className="h-48 bg-gray-100 rounded-3xl animate-pulse" />
        <div className="h-64 bg-gray-100 rounded-3xl animate-pulse" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-4xl">📦</p>
        <h2 className="text-2xl font-bold text-gray-900">
          {error ? 'Unable to Load Order' : 'Order Not Found'}
        </h2>
        <p className="text-xs text-gray-500 max-w-sm mx-auto">
          {error?.message || `We couldn't locate any order with reference "${orderId}". Please check the order number or link.`}
        </p>
        <div className="flex items-center justify-center gap-3 pt-2">
          {error && (
            <button onClick={() => refetch()} className="btn-brand text-xs font-bold px-4 py-2">
              Try Again
            </button>
          )}
          <button onClick={() => router.push('/orders')} className="btn-outline text-xs font-bold px-4 py-2">
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  const currentStepIndex = STEPS.findIndex((s) => s.key === order.status);
  const isCancelled = order.status === 'cancelled';
  const isDelivered = ['delivered', 'completed'].includes(order.status);

  const getStepUpdate = (stepKey) => {
    if (!order?.trackingUpdates || !Array.isArray(order.trackingUpdates)) return null;
    const matches = order.trackingUpdates.filter((u) => u.status === stepKey);
    return matches.length > 0 ? matches[matches.length - 1] : null;
  };

  const vendorUpdates = (order?.trackingUpdates || []).filter(
    (u) =>
      u.message &&
      !['Order placed successfully', 'Order cancelled', 'Your refund has been processed.'].includes(u.message) &&
      (!u.message.startsWith('Order status updated to ') || Boolean(order.vendorNotes))
  );
  const latestVendorUpdate = vendorUpdates[vendorUpdates.length - 1];
  const displayVendorNote =
    order.vendorNotes ||
    (latestVendorUpdate?.message &&
    !['Order placed successfully', 'Seller accepted the order', 'Order accepted'].includes(latestVendorUpdate.message)
      ? latestVendorUpdate.message
      : null);
  const rawInstructions = order?.deliveryInstructions || order?.notes || '';
  const slotMatch = rawInstructions.match(/\[Slot:\s*([^\]]+)\]/i);
  const effectiveDeliverySlot = order?.deliverySlot || (slotMatch ? slotMatch[1].trim() : null);
  const customerInstructions = rawInstructions
    .replace(/\[Slot:\s*[^\]]+\]/gi, '')
    .trim();

  const isRefundInitiated = Boolean(
    order?.status === 'refunded' ||
    order?.paymentStatus === 'refunded' ||
    order?.returnStatus === 'approved' ||
    order?.returnStatus === 'refunded' ||
    (order?.status === 'cancelled' && (order?.paymentStatus === 'paid' || order?.paymentStatus === 'refunded' || order?.paymentMethod !== 'cod')) ||
    order?.trackingUpdates?.some((u) => /refund/i.test(u?.message || u?.status || ''))
  );

  // Supply stage: goods dispatched/removed for delivery or beyond
  const isDispatchedOrBeyond = Boolean(
    ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(order?.status) ||
    order?.trackingUpdates?.some((u) => ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(u?.status))
  );

  // Payment received check:
  // For COD: payment is only received upon delivery/completion
  // For Online: payment is received when paymentStatus is 'paid' or 'refunded'
  const isCod = order?.paymentMethod === 'cod';
  const isPaymentReceived = Boolean(
    isCod
      ? (order?.paymentStatus === 'paid' || ['delivered', 'completed'].includes(order?.status))
      : (order?.paymentStatus === 'paid' || order?.paymentStatus === 'refunded')
  );

  // Cancelled before dispatch check
  const isCancelledBeforeDispatch = Boolean(order?.status === 'cancelled' && !isDispatchedOrBeyond);

  // Official Invoice is only generated when:
  // 1) Not cancelled before dispatch
  // 2) Payment received (upon delivery for COD, or prepaid for online)
  // 3) Reached the supply stage (dispatched or beyond)
  const isInvoiceGenerated = Boolean(!isCancelledBeforeDispatch && isPaymentReceived && isDispatchedOrBeyond);

  // Order Summary is available immediately after payment (or for active COD) before the official invoice is generated
  const isOrderSummaryAvailable = Boolean(!isCancelledBeforeDispatch && !isInvoiceGenerated);

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    const hasProductComment = Boolean(productComment.trim());
    const hasDeliveryComment = Boolean(deliveryComment.trim());

    if (!hasProductComment && !hasDeliveryComment) {
      toast.error('Please write a comment for Product or Delivery Agent');
      return;
    }

    setSubmittingBoth(true);
    let submittedCount = 0;
    const errors = [];

    // 1. Submit Product Review if filled
    if (hasProductComment) {
      try {
        const prodInput = {
          orderId: order._id,
          targetType: 'product',
          productId: selectedProductId || order.items?.[0]?.product?._id || order.items?.[0]?.product,
          rating: productRating,
          title: productTitle.trim() || 'Product Feedback',
          comment: productComment.trim(),
        };
        await addReviewMutation({ variables: { input: prodInput } });
        submittedCount++;
        setProductComment('');
        setProductTitle('');
        setProductRating(5);
      } catch (err) {
        errors.push(`Product: ${err.message}`);
      }
    }

    // 2. Submit Delivery Agent Review if filled
    if (hasDeliveryComment) {
      try {
        const delivInput = {
          orderId: order._id,
          targetType: 'delivery',
          deliveryAgentId: order.deliveryAgent?._id || order.deliveryAgent || order.deliveryBoy?._id || order.deliveryBoy || undefined,
          rating: deliveryRating,
          title: deliveryTitle.trim() || 'Delivery Agent Feedback',
          comment: deliveryComment.trim(),
        };
        await addReviewMutation({ variables: { input: delivInput } });
        submittedCount++;
        setDeliveryComment('');
        setDeliveryTitle('');
        setDeliveryRating(5);
      } catch (err) {
        errors.push(`Delivery: ${err.message}`);
      }
    }

    setSubmittingBoth(false);

    if (submittedCount > 0) {
      toast.success(
        submittedCount > 1
          ? 'Thank you! Both product and delivery reviews have been submitted.'
          : 'Thank you! Your review has been submitted.'
      );
      setShowReviewModal(false);
      refetch();
    }

    if (errors.length > 0) {
      errors.forEach((eMsg) => toast.error(eMsg));
    }
  };

  const documentLabel = isInvoiceGenerated ? 'Invoice' : 'Order Summary';
  const orderVertical = (
    order?.vertical ||
    order?.items?.[0]?.product?.vertical ||
    order?.items?.[0]?.vertical ||
    'food'
  ).toLowerCase();

  const handleShareInvoice = async () => {
    const refundNote = isRefundInitiated ? '\n*Refund Status:* Refund Initiated (Full refund to original payment method)' : '';
    const headerTitle = isInvoiceGenerated ? '🧾 *Suaaka Invoice*' : '📋 *Suaaka Order Summary*';
    const numLine = isInvoiceGenerated
      ? `Invoice No: ${order.invoiceNumber || `INV-${order.orderNumber}`}`
      : `Order Ref: #${order.orderNumber} (Awaiting Dispatch for GST Invoice)`;
    const invoiceSummary = `${headerTitle}\nOrder No: #${order.orderNumber}\n${numLine}\nGrand Total: ₹${order.total?.toLocaleString('en-IN')}${refundNote}\nBilled To: ${order.shippingAddress?.fullName || 'Customer'}\nItems: ${(order.items || []).map((i) => `${i.name} (Qty: ${i.quantity})`).join(', ')}\n\nView Order: ${typeof window !== 'undefined' ? window.location.href : ''}`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `${documentLabel} #${order.orderNumber} - Suaaka`,
          text: invoiceSummary,
          url: window.location.href,
        });
        toast.success(`${documentLabel} shared successfully!`);
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
      }
    }

    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(invoiceSummary);
      toast.success(`${documentLabel} details copied to clipboard!`);
    }
  };

  const handleEmailInvoice = () => {
    const subject = encodeURIComponent(`${documentLabel} for Order #${order.orderNumber} - Suaaka`);
    const refundNote = isRefundInitiated ? '\nRefund Status: Refund Initiated (Full refund to original payment method)' : '';
    const numLine = isInvoiceGenerated
      ? `Invoice Number: ${order.invoiceNumber || `INV-${order.orderNumber}`}`
      : `Order Reference: #${order.orderNumber} (Pre-Dispatch Summary)`;
    const body = encodeURIComponent(
      `Hello ${order.shippingAddress?.fullName || 'Customer'},\n\nHere is your ${documentLabel} for Order #${order.orderNumber}:\n\n${numLine}\nTotal Amount: INR ${order.total}${refundNote}\nPayment Method: ${order.paymentMethod?.toUpperCase()}\nDelivery Address: ${order.shippingAddress?.addressLine1}, ${order.shippingAddress?.city} - ${order.shippingAddress?.postalCode}\n\nItems:\n${(order.items || []).map((i) => `- ${i.name} x ${i.quantity} (INR ${i.price})`).join('\n')}\n\nYou can track and view full details here:\n${typeof window !== 'undefined' ? window.location.href : ''}\n\nThank you for shopping with Suaaka!`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
  };

  const handleWhatsAppInvoice = () => {
    const refundNote = isRefundInitiated ? '\n*Refund Status:* Refund Initiated' : '';
    const headerTitle = isInvoiceGenerated ? '🧾 *Suaaka Invoice*' : '📋 *Suaaka Order Summary*';
    const numLine = isInvoiceGenerated
      ? `Invoice No: ${order.invoiceNumber || `INV-${order.orderNumber}`}`
      : `Order Ref: #${order.orderNumber}`;
    const invoiceSummary = `${headerTitle}\nOrder No: #${order.orderNumber}\n${numLine}\nGrand Total: ₹${order.total?.toLocaleString('en-IN')}${refundNote}\nBilled To: ${order.shippingAddress?.fullName || 'Customer'}\n\nItems:\n${(order.items || []).map((i) => `• ${i.name} (Qty: ${i.quantity})`).join('\n')}\n\nTrack: ${typeof window !== 'undefined' ? window.location.href : ''}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(invoiceSummary)}`, '_blank');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <button
            onClick={() => router.push('/orders')}
            className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-brand-600 mb-2 font-medium"
          >
            <ArrowLeftIcon className="w-3.5 h-3.5" /> Back to My Orders
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-extrabold text-gray-900">
              Order #{order.orderNumber}
            </h1>
            <span
              className={`px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                order.status === 'delivered'
                  ? 'bg-emerald-100 text-emerald-800'
                  : order.status === 'cancelled'
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {order.status.replace(/_/g, ' ')}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Placed on {order.createdAt ? format(new Date(order.createdAt), 'PPP p') : 'Recently'}
            {isInvoiceGenerated && (
              <span> • Invoice #{order.invoiceNumber || `INV-${order.orderNumber}`}</span>
            )}
            {isOrderSummaryAvailable && (
              <span> • Order Summary</span>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Invoice or Order Summary or Cancelled State */}
          {isCancelledBeforeDispatch ? (
            <div className="flex flex-col sm:items-end bg-rose-50/90 border border-rose-200 px-3.5 py-1.5 rounded-xl shadow-xs">
              <span className="text-xs font-black text-rose-800 uppercase tracking-wide flex items-center gap-1.5">
                <XCircleIcon className="w-4 h-4 text-rose-600" />
                Order Cancelled
              </span>
              {isRefundInitiated ? (
                <span className="text-xs font-bold text-rose-700 mt-0.5">
                  Refund: ₹{order.total?.toLocaleString('en-IN')} initiated
                </span>
              ) : (
                <span className="text-[11px] text-gray-500 font-medium mt-0.5">
                  No payment charged
                </span>
              )}
            </div>
          ) : isInvoiceGenerated ? (
            <button
              onClick={() => setShowInvoiceModal(true)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <DocumentTextIcon className="w-4 h-4 text-gray-600" />
              <span>Invoice</span>
            </button>
          ) : isOrderSummaryAvailable ? (
            <button
              onClick={() => setShowInvoiceModal(true)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <DocumentTextIcon className="w-4 h-4 text-gray-600" />
              <span>Order Summary</span>
            </button>
          ) : null}

          {/* Rate & Review Button */}
          {isDelivered && (
            <button
              onClick={() => setShowReviewModal(true)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all"
            >
              <StarIcon className="w-4 h-4" />
              <span>Rate & Review</span>
            </button>
          )}

          {/* Cancel Order Button */}
          {['placed', 'accepted', 'processing'].includes(order.status) && (
            <button
              onClick={() => setShowCancelModal(true)}
              className="px-4 py-2 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold transition-colors"
            >
              Cancel Order
            </button>
          )}

          {/* Request Return Button */}
          {order.status === 'delivered' && (!order.returnStatus || order.returnStatus === 'none') && (
            <button
              onClick={() => setShowReturnModal(true)}
              className="px-4 py-2 bg-orange-100 text-orange-700 hover:bg-orange-200 rounded-xl text-xs font-bold transition-colors"
            >
              Request Return
            </button>
          )}

          {/* Return Status Badge */}
          {order.returnStatus && order.returnStatus !== 'none' && (
            <div className="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl text-xs font-bold capitalize border border-gray-200">
              Return: {order.returnStatus}
            </div>
          )}
        </div>
      </div>

      {/* Tracking Stepper */}
      {isDelivered ? (
        <div className="card p-8 bg-emerald-50/70 border border-emerald-200 text-center flex flex-col items-center justify-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-600/30">
            <CheckCircleIcon className="w-9 h-9" />
          </div>
          <h2 className="text-2xl font-black text-emerald-900">Delivered</h2>
          <p className="text-xs sm:text-sm text-emerald-700 font-medium max-w-md">
            {order.updatedAt
              ? `Package delivered on ${format(new Date(order.updatedAt), 'PPP p')}`
              : 'Package has been successfully delivered'}
          </p>
        </div>
      ) : !isCancelled ? (
        <div className="card p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-gray-900">Order Journey & Tracking</h2>
              <p className="text-xs text-gray-400">Live order progress and merchant updates</p>
            </div>
            {displayVendorNote && (
              <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-3 py-1 rounded-full">
                <span>💬</span>
                <span>Merchant Update Available</span>
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
            {STEPS.map((step, idx) => {
              const isCompleted = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              const stepUpdate = getStepUpdate(step.key);
              const hasCustomMsg =
                Boolean(stepUpdate?.message) &&
                stepUpdate.message !== step.desc &&
                !stepUpdate.message.startsWith('Order status updated to ');

              return (
                <div key={step.key} className="flex flex-col items-center text-center space-y-1.5 relative">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/30'
                        : 'bg-gray-100 text-gray-400'
                    } ${isCurrent ? 'ring-4 ring-brand-100 scale-105' : ''}`}
                  >
                    {isCompleted ? <CheckCircleIcon className="w-6 h-6" /> : <ClockIcon className="w-5 h-5" />}
                  </div>
                  <span className={`text-xs font-bold ${isCompleted ? 'text-gray-900' : 'text-gray-400'}`}>
                    {step.label}
                  </span>
                  <span className="text-[10px] text-gray-400 leading-tight hidden sm:block">
                    {step.desc}
                  </span>
                  {isCompleted && hasCustomMsg && (
                    <span
                      className="hidden sm:inline-block text-[10px] text-blue-800 bg-blue-50 border border-blue-200/80 px-1.5 py-0.5 rounded font-medium max-w-[120px] truncate"
                      title={stepUpdate.message}
                    >
                      💬 {stepUpdate.message}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : null}



      {/* Grid: Delivery Agent & Shipping Address */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Delivery Partner */}
        <div className="card p-6 space-y-3">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <TruckIcon className="w-4 h-4 text-brand-500" />
            <span>Delivery Information</span>
          </h3>
          {!isDelivered && (
            <div className="p-3 bg-brand-50/50 rounded-xl border border-brand-100/70 text-xs space-y-1">
              <p className="font-bold text-brand-900">
                Speed: {
                  order.deliveryOption?.name || (
                    orderVertical === 'food' ? 'Express Food Delivery' :
                    orderVertical === 'grocery' ? 'Instant Grocery Delivery' :
                    orderVertical === 'services' ? 'Home Service Booking' :
                    'Standard Delivery'
                  )
                }
              </p>
              <p className="text-gray-600">
                {
                  orderVertical === 'food' ? `Estimated delivery: ${order.estimatedDelivery || '25-35 mins'}` :
                  orderVertical === 'grocery' ? `Estimated delivery: ${order.estimatedDelivery || '10-20 mins'}` :
                  orderVertical === 'services' ? `Scheduled Slot: ${order.deliverySlot || 'As per selected slot'}` :
                  `Estimated transit: ${order.deliveryOption?.estimatedDays || '3-5 Business Days'}`
                }
              </p>
              {effectiveDeliverySlot && orderVertical !== 'services' && (
                <p className="text-brand-800 font-semibold flex items-center gap-1.5 pt-1.5 border-t border-brand-100/80">
                  <span>⏰</span>
                  <span>Delivery Slot: <strong className="font-bold text-brand-950">{effectiveDeliverySlot}</strong></span>
                </p>
              )}
            </div>
          )}
          {(order.deliveryAgent || order.deliveryBoy) ? (
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-brand-500 text-white font-bold flex items-center justify-center text-sm shadow-sm">
                  {(order.deliveryAgent?.name || order.deliveryBoy?.name)?.[0] || 'D'}
                </div>
                <div>
                  <p className="font-bold text-gray-900">{order.deliveryAgent?.name || order.deliveryBoy?.name}</p>
                  <p className="text-gray-500 text-[11px]">
                    {
                      orderVertical === 'food' ? 'Food Delivery Partner' :
                      orderVertical === 'grocery' ? 'Grocery Delivery Partner' :
                      orderVertical === 'services' ? 'Assigned Service Professional' :
                      'Assigned Courier Partner'
                    }
                  </p>
                </div>
              </div>
              {!isDelivered && (
                <a
                  href={`tel:${order.deliveryAgent?.phone || order.deliveryBoy?.phone || '+919876543210'}`}
                  className="btn-outline text-xs py-1.5 px-3 font-semibold flex items-center gap-1 text-gray-700 hover:text-brand-600 hover:border-brand-300"
                >
                  <PhoneIcon className="w-3.5 h-3.5" /> Call
                </a>
              )}
            </div>
          ) : !isDelivered ? (
            <p className="text-xs text-gray-400 italic">
              {
                orderVertical === 'food' ? 'A delivery partner will be assigned shortly to pick up your meal from the restaurant.' :
                orderVertical === 'grocery' ? 'A delivery partner will be assigned shortly to pick up your groceries.' :
                orderVertical === 'services' ? 'A service professional will be assigned to visit your location.' :
                'A delivery executive will be assigned once the package leaves the hub.'
              }
            </p>
          ) : null}
        </div>

        {/* Shipping Address */}
        <div className="card p-6 space-y-2">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <MapPinIcon className="w-4 h-4 text-brand-500" />
            <span>Shipping Destination</span>
          </h3>
          <div className="text-xs text-gray-600 space-y-0.5 pt-1">
            <p className="font-bold text-gray-900 text-sm">{order.shippingAddress?.fullName}</p>
            <p>{order.shippingAddress?.addressLine1} {order.shippingAddress?.addressLine2}</p>
            <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}</p>
            <p className="text-gray-400 pt-1">📞 {order.shippingAddress?.phone}</p>
          </div>
        </div>
      </div>

      {/* Seller / Vendor Note / Comment */}
      {Boolean(displayVendorNote) && (
        <div className="card p-5 bg-gradient-to-r from-blue-50/90 via-indigo-50/70 to-blue-50/90 border border-blue-200/80 rounded-2xl shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-base">🏪</span>
              <h3 className="font-bold text-xs uppercase tracking-wider text-blue-900">
                Seller / Vendor Note & Update
              </h3>
              <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-md border border-blue-200/70">
                {order.vendor?.name || 'Verified Seller'}
              </span>
            </div>
            {latestVendorUpdate?.timestamp && (
              <span className="text-[11px] font-medium text-blue-600">
                {format(new Date(latestVendorUpdate.timestamp), 'MMM d, h:mm a')}
              </span>
            )}
          </div>
          <p className="text-sm font-semibold text-blue-950 whitespace-pre-wrap pl-6">
            {displayVendorNote}
          </p>
        </div>
      )}

      {/* Delivery / Customer Instructions */}
      {Boolean(customerInstructions) && (
        <div className="card p-5 bg-amber-50/70 border border-amber-200/80 rounded-2xl shadow-sm space-y-1.5">
          <h3 className="font-bold text-xs uppercase tracking-wider text-amber-900 flex items-center gap-2">
            <span>{order.vertical === 'food' ? '🍳' : order.vertical === 'services' ? '🛠️' : '🚚'}</span>
            <span>
              {order.vertical === 'food'
                ? 'Special Instructions & Delivery Notes'
                : order.vertical === 'services'
                ? 'Service Instructions & Notes'
                : 'Delivery Instructions'}
            </span>
          </h3>
          <p className="text-sm font-semibold text-amber-950 whitespace-pre-wrap pl-6">
            {customerInstructions}
          </p>
        </div>
      )}

      {/* Submitted Reviews & Vendor/Staff Replies Section */}
      {((order.reviews && order.reviews.length > 0) || (isDelivered && order.deliveryRating)) && (
        <div className="card p-6 space-y-4 bg-gradient-to-br from-amber-50/40 via-white to-orange-50/20 border border-amber-200/60 shadow-sm">
          <div className="flex items-center justify-between border-b border-amber-100 pb-3">
            <div className="flex items-center gap-2.5">
              <span className="p-2 bg-amber-100 text-amber-800 rounded-xl text-lg">⭐</span>
              <div>
                <h3 className="font-extrabold text-gray-900 text-base">Your Review & Rating</h3>
                <p className="text-xs text-gray-500">Feedback & replies for this order</p>
              </div>
            </div>
            {isDelivered && (
              <button
                onClick={() => setShowReviewModal(true)}
                className="text-xs font-bold text-amber-800 bg-amber-100/80 hover:bg-amber-200/80 border border-amber-300/60 px-3.5 py-1.5 rounded-xl shadow-xs transition-all"
              >
                {order.reviews?.length > 0 ? 'Edit / Update Review' : 'Rate Order'}
              </button>
            )}
          </div>

          {order.reviews && order.reviews.length > 0 ? (
            <div className="space-y-4">
              {order.reviews.map((rev) => (
                <div key={rev._id} className="bg-white rounded-2xl p-4 border border-gray-100 shadow-xs space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-100 text-amber-900">
                        {rev.targetType === 'product' ? '🛍️ Product Review' : '🚚 Delivery Agent Review'}
                      </span>
                      <div className="flex text-amber-400 text-sm">
                        {'★'.repeat(rev.rating)}{'☆'.repeat(5 - rev.rating)}
                        <span className="ml-1 text-xs font-bold text-gray-800">{rev.rating}.0/5</span>
                      </div>
                    </div>
                    <span className="text-[11px] font-medium text-gray-400">
                      {rev.createdAt ? format(new Date(rev.createdAt), 'PP p') : ''}
                    </span>
                  </div>

                  {rev.title && <h4 className="font-bold text-xs text-gray-900">{rev.title}</h4>}
                  <p className="text-xs text-gray-700 whitespace-pre-wrap">{rev.comment}</p>

                  {/* Vendor / Staff Reply */}
                  {rev.reply && (
                    <div className="mt-3 bg-brand-50/80 border border-brand-200/80 rounded-xl p-3.5 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-black text-brand-900 flex items-center gap-1.5">
                          💬 {rev.reply.repliedBy?.name || 'Store / Support'} (Official Response)
                        </span>
                        <span className="text-[10px] text-brand-600 font-semibold">
                          {rev.reply.repliedAt ? format(new Date(rev.reply.repliedAt), 'PP') : ''}
                        </span>
                      </div>
                      <p className="text-xs text-brand-950 font-medium whitespace-pre-wrap pl-5">
                        {rev.reply.comment}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-gray-100">
              <div className="flex items-center gap-2">
                <span className="text-amber-500 text-lg">⭐</span>
                <div>
                  <span className="text-xs font-bold text-gray-900 block">Delivery Partner Rating: 5.0 / 5.0</span>
                  <span className="text-[11px] text-gray-500">Order delivered successfully</span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Items & Payment Breakdown */}
      <div className="card p-6 space-y-5">
        <h3 className="font-bold text-gray-900 text-base">Items in this Package</h3>
        <div className="divide-y divide-gray-100">
          {order.items?.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={item.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                  alt=""
                  className="w-14 h-14 object-cover rounded-xl border border-gray-100"
                />
                <div>
                  <h4 className="font-bold text-sm text-gray-900">{item.name}</h4>
                  {item.variantLabel && (
                    <span className="text-xs text-gray-500 block">{item.variantLabel}</span>
                  )}
                  {item.addons && item.addons.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {item.addons.map((addon, aIdx) => (
                        <span key={aIdx} className="text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/80 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                          <span>{addon.icon || '➕'}</span>
                          <span>{addon.name} (+₹{addon.price})</span>
                        </span>
                      ))}
                    </div>
                  )}
                  {item.instructions && (
                    <p className="text-xs text-blue-700 italic font-medium mt-1 bg-blue-50/70 border border-blue-200/60 px-2 py-0.5 rounded-md inline-block">
                      💬 Note: {item.instructions}
                    </p>
                  )}
                  <p className="text-xs text-gray-400 mt-0.5">
                    Qty: {item.quantity} × ₹{Number(item.price).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
              <span className="font-extrabold text-sm text-gray-900">
                ₹{(item.price * item.quantity).toLocaleString('en-IN')}
              </span>
            </div>
          ))}
        </div>

        {/* Pricing Totals */}
        <div className="border-t border-gray-100 pt-4 space-y-2 text-xs text-gray-600">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>₹{order.subtotal?.toLocaleString('en-IN')}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Discount</span>
              <span>-₹{order.discount?.toLocaleString('en-IN')}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Shipping ({order.deliveryOption?.name || 'Standard'})</span>
            <span>{(order.shippingCost === 0 || !order.shippingCost) ? <span className="text-emerald-600 font-semibold">FREE</span> : `₹${order.shippingCost}`}</span>
          </div>
          {order.tax > 0 && (
            <div className="flex justify-between">
              <span>GST ({order.taxDetails?.rate || 18}%)</span>
              <span>₹{order.tax?.toLocaleString('en-IN')}</span>
            </div>
          )}
          <div className="border-t border-gray-100 pt-2 flex justify-between text-base font-extrabold text-gray-900">
            <span>Total Paid ({order.paymentMethod?.toUpperCase()})</span>
            <span className="text-brand-600 font-bold">₹{order.total?.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* Invoice / Order Summary Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-xl font-extrabold text-gray-900">
                    {isInvoiceGenerated ? 'INVOICE' : 'ORDER SUMMARY'}
                  </h3>
                  {isRefundInitiated && isInvoiceGenerated && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-700 border border-rose-300 shadow-2xs">
                      <span>↩️</span>
                      <span>Refund Initiated</span>
                    </span>
                  )}
                  {!isInvoiceGenerated && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                      <span>Pre-Dispatch Summary</span>
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-500 font-mono">
                  {isInvoiceGenerated
                    ? `Invoice No: ${order.invoiceNumber || `INV-${order.orderNumber}`}`
                    : `Order Ref: #${order.orderNumber}`}
                </p>
              </div>
              <div className="flex items-center gap-2 flex-wrap justify-end">
                <button
                  onClick={handleShareInvoice}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title={`Share ${documentLabel}`}
                >
                  <ShareIcon className="w-4 h-4" /> Share
                </button>
                <button
                  onClick={handleEmailInvoice}
                  className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title={`Email ${documentLabel}`}
                >
                  <EnvelopeIcon className="w-4 h-4" /> Email
                </button>
                <button
                  onClick={handleWhatsAppInvoice}
                  className="px-3 py-1.5 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title="Share on WhatsApp"
                >
                  <span className="text-sm">💬</span> WhatsApp
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-brand-500 hover:bg-brand-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <PrinterIcon className="w-4 h-4" /> Print / PDF
                </button>
                <button
                  onClick={() => setShowInvoiceModal(false)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Pre-Dispatch Informative Notice */}
            {!isInvoiceGenerated && (
              <div className="p-3.5 bg-blue-50/90 border border-blue-200 rounded-2xl flex items-start gap-2.5 text-xs text-blue-900">
                <span className="text-base">ℹ️</span>
                <div>
                  <p className="font-bold">
                    {isCod ? 'Cash on Delivery (Pending Supply & Payment)' : 'Payment Received (Awaiting Dispatch)'}
                  </p>
                  <p className="text-blue-700 mt-0.5">
                    {isCod
                      ? 'Official GST Invoice will be issued upon delivery and cash payment receipt.'
                      : 'Your payment was successful. Official GST Invoice will be generated when your order is dispatched for delivery.'}
                  </p>
                </div>
              </div>
            )}

            {/* Refund Initiated Banner */}
            {isRefundInitiated && (
              <div className="p-3.5 bg-rose-50/90 border border-rose-200 rounded-2xl flex items-center justify-between gap-3 text-xs">
                <div className="flex items-start gap-2.5">
                  <span className="text-lg">🔄</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-extrabold text-rose-900 uppercase tracking-wide">
                        Refund Initiated
                      </p>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-200/80 text-rose-800">
                        {order.status === 'refunded' || order.paymentStatus === 'refunded' || order.returnStatus === 'refunded'
                          ? 'Refund Processed'
                          : 'In Progress'}
                      </span>
                    </div>
                    <p className="text-rose-700 text-xs mt-0.5 font-medium">
                      Full refund of <strong className="font-bold text-rose-950">₹{order.total?.toLocaleString('en-IN')}</strong> has been initiated to your original payment method ({order.paymentMethod?.toUpperCase() || 'Source Account'}).
                    </p>
                  </div>
                </div>
                <div className="text-right whitespace-nowrap hidden sm:block">
                  <span className="text-[10px] font-semibold text-rose-500 block uppercase">Status</span>
                  <span className="text-xs font-bold text-rose-800">Refund Initiated</span>
                </div>
              </div>
            )}

            {/* Seller & Customer Details */}
            <div className="grid grid-cols-2 gap-4 text-xs text-gray-600 p-4 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-gray-900 text-sm">Suaaka E-Commerce Pvt Ltd</p>
                <p>Plot 42, Tech City, Meerut, UP - 250001</p>
                <p className="font-semibold text-gray-800 mt-1">GSTIN: 09AAACH7409R1ZZ</p>
                <p>HSN Code: 9983</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900 text-sm">Billed To: {order.shippingAddress?.fullName}</p>
                <p>{order.shippingAddress?.addressLine1}</p>
                <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}</p>
                <p>Phone: {order.shippingAddress?.phone}</p>
                <p className="font-semibold text-gray-800 mt-1">Date: {order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : 'N/A'}</p>
              </div>
            </div>

            {/* Table */}
            <table className="w-full text-xs">
              <thead className="border-b border-gray-200 text-gray-500 font-semibold">
                <tr>
                  <th className="text-left py-2">Item Description</th>
                  <th className="text-center py-2">Qty</th>
                  <th className="text-right py-2">Price</th>
                  <th className="text-right py-2">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {order.items?.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-2.5 font-medium">{item.name}</td>
                    <td className="py-2.5 text-center">{item.quantity}</td>
                    <td className="py-2.5 text-right">₹{Number(item.price).toLocaleString('en-IN')}</td>
                    <td className="py-2.5 text-right font-bold">₹{(item.price * item.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* GST Summary */}
            <div className="border-t border-gray-200 pt-3 space-y-1.5 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Taxable Amount</span>
                <span>₹{(order.subtotal - (order.discount || 0)).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>CGST (9%)</span>
                <span>₹{(order.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>SGST (9%)</span>
                <span>₹{(order.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Charges</span>
                <span>{order.shippingCost === 0 ? 'FREE' : `₹${order.shippingCost}`}</span>
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-extrabold text-gray-900">
                <span>Grand Total (INR)</span>
                <span>₹{order.total?.toLocaleString('en-IN')}</span>
              </div>
              {isRefundInitiated && (
                <div className="pt-2 flex justify-between text-xs font-bold text-rose-700 border-t border-dashed border-rose-200 bg-rose-50/60 p-2 rounded-lg mt-1">
                  <span className="flex items-center gap-1.5">
                    <span>↩️</span>
                    <span>Refund Status</span>
                  </span>
                  <span className="font-extrabold text-rose-800 tracking-wide">
                    REFUND INITIATED (₹{order.total?.toLocaleString('en-IN')})
                  </span>
                </div>
              )}
            </div>

            <p className="text-[10px] text-gray-400 text-center">
              {isInvoiceGenerated
                ? 'This is a computer-generated invoice and does not require a physical signature.'
                : 'This is a computer-generated order summary for customer records.'}
            </p>
          </div>
        </div>
      )}

      {/* Multi-Target Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-lg font-bold text-gray-900">Rate & Review</h3>
              <button onClick={() => setShowReviewModal(false)} className="p-1 text-gray-400 hover:text-gray-700">
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Review Target Selector Tabs */}
            <div className="flex rounded-2xl bg-gray-100 p-1 gap-1">
              {[
                { key: 'product', label: '🛍️ Product' },
                { key: 'delivery', label: '🚚 Delivery Agent' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setReviewTab(tab.key)}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                    reviewTab === tab.key
                      ? 'bg-white text-brand-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              {/* Product selector if multiple items */}
              {reviewTab === 'product' && order.items?.length > 1 && (
                <div>
                  <label className="text-xs font-bold text-gray-700 block mb-1">Select Product to Review</label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="input-field text-xs"
                  >
                    {order.items.map((it) => (
                      <option key={it.product?._id || it.name} value={it.product?._id}>
                        {it.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Star Rating */}
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">
                  {reviewTab === 'product' ? 'Product Rating' : 'Delivery Agent Rating'}
                </label>
                <div className="flex gap-1.5 text-amber-400">
                  {[1, 2, 3, 4, 5].map((s) => {
                    const activeRating = reviewTab === 'product' ? productRating : deliveryRating;
                    return (
                      <button
                        type="button"
                        key={s}
                        onClick={() => (reviewTab === 'product' ? setProductRating(s) : setDeliveryRating(s))}
                        className="p-1 focus:outline-none hover:scale-110 transition-transform"
                      >
                        <StarIcon className={`w-7 h-7 ${s <= activeRating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Review Title</label>
                <input
                  type="text"
                  placeholder={reviewTab === 'product' ? 'e.g. High quality item' : 'e.g. Fast & polite delivery'}
                  value={reviewTab === 'product' ? productTitle : deliveryTitle}
                  onChange={(e) => (reviewTab === 'product' ? setProductTitle(e.target.value) : setDeliveryTitle(e.target.value))}
                  className="input-field text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Your Detailed Feedback</label>
                <textarea
                  placeholder={reviewTab === 'product' ? 'Share your experience with this product...' : 'Share your experience with the delivery partner...'}
                  value={reviewTab === 'product' ? productComment : deliveryComment}
                  onChange={(e) => (reviewTab === 'product' ? setProductComment(e.target.value) : setDeliveryComment(e.target.value))}
                  rows={3}
                  className="input-field text-xs resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingBoth}
                  className="flex-1 py-2.5 rounded-xl btn-brand text-xs font-bold"
                >
                  {submittingBoth ? 'Submitting...' : 'Submit Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancel Order Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Cancel Order #{order.orderNumber}?</h3>
            <p className="text-xs text-gray-500">
              Are you sure you want to cancel this order? This action cannot be reversed.
            </p>
            <textarea
              placeholder="Reason for cancellation (required)..."
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              rows={3}
              className="input-field text-xs resize-none"
            />
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowCancelModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Keep Order
              </button>
              <button
                onClick={() => {
                  if (!cancelReason.trim()) { toast.error('Please specify a cancellation reason'); return; }
                  cancelOrderMutation({ variables: { orderId: order._id, reason: cancelReason } });
                }}
                disabled={!cancelReason.trim() || cancelling}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 disabled:opacity-50"
              >
                {cancelling ? 'Cancelling...' : 'Yes, Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Request Return Modal */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Request Return for #{order.orderNumber}</h3>
            <p className="text-xs text-gray-500">
              Please provide a reason for returning this order. Our team will review your request.
            </p>
            <textarea
              placeholder="Reason for return (required)..."
              value={returnReason}
              onChange={(e) => setReturnReason(e.target.value)}
              rows={3}
              className="input-field text-xs resize-none"
            />
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowReturnModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Close
              </button>
              <button
                onClick={() => {
                  requestReturnMutation({ variables: { orderId: order._id, reason: returnReason } });
                }}
                disabled={!returnReason.trim() || requestingReturn}
                className="flex-1 py-2.5 rounded-xl bg-orange-600 text-white text-xs font-bold hover:bg-orange-700 disabled:opacity-50"
              >
                {requestingReturn ? 'Submitting...' : 'Submit Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
