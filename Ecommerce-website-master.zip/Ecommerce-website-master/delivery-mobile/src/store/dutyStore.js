import { create } from 'zustand';

export const useDutyStore = create((set) => ({
  isOnDuty: true,
  currentLocation: {
    latitude: 28.9845,
    longitude: 77.7064,
    heading: 0,
    speed: 0,
  },
  activeTrackingOrderId: null,

  setIsOnDuty: (isOnDuty) => set({ isOnDuty }),
  setCurrentLocation: (currentLocation) => set({ currentLocation }),
  setActiveTrackingOrderId: (id) => set({ activeTrackingOrderId: id }),
}));
