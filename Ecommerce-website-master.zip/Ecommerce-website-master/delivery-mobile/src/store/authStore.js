import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const useAuthStore = create((set, get) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,

  initializeAuth: async () => {
    try {
      const token = await AsyncStorage.getItem('delivery_auth_token');
      const userStr = await AsyncStorage.getItem('delivery_auth_user');

      if (!token || !userStr) {
        await get().logout();
        return;
      }

      let parsedUser = null;
      try {
        parsedUser = JSON.parse(userStr);
      } catch (e) {
        await get().logout();
        return;
      }

      // Temporarily set state so GraphQL authLink can include Authorization header
      set({ token, user: parsedUser, isAuthenticated: true });

      // Verify token & fetch fresh user data from server
      try {
        const { apolloClient } = await import('../lib/apolloClient');
        const { GET_ME } = await import('../graphql/queries');

        const res = await apolloClient.query({
          query: GET_ME,
          fetchPolicy: 'network-only',
        });

        const me = res?.data?.me;
        if (me && me._id) {
          const freshUser = { ...parsedUser, ...me };
          await AsyncStorage.setItem('delivery_auth_user', JSON.stringify(freshUser));
          set({ user: freshUser, token, isAuthenticated: true, isLoading: false });
        } else {
          await get().logout();
        }
      } catch (serverErr) {
        const errMsg = (serverErr?.message || '').toLowerCase();
        if (
          errMsg.includes('unauthenticated') ||
          errMsg.includes('context creation failed') ||
          errMsg.includes('jwt') ||
          errMsg.includes('invalid token') ||
          errMsg.includes('not authorized')
        ) {
          await get().logout();
        } else {
          // Offline / network issue: retain session for offline usage
          set({ token, user: parsedUser, isAuthenticated: true, isLoading: false });
        }
      }
    } catch (e) {
      await get().logout();
    }
  },

  setAuth: async (user, token) => {
    try {
      await AsyncStorage.setItem('delivery_auth_token', token);
      await AsyncStorage.setItem('delivery_auth_user', JSON.stringify(user));
    } catch (e) {}
    set({ user, token, isAuthenticated: true, isLoading: false });
  },

  updateUser: async (updatedUser) => {
    try {
      await AsyncStorage.setItem('delivery_auth_user', JSON.stringify(updatedUser));
    } catch (e) {}
    set((state) => ({ user: { ...state.user, ...updatedUser } }));
  },

  logout: async () => {
    try {
      await AsyncStorage.removeItem('delivery_auth_token');
      await AsyncStorage.removeItem('delivery_auth_user');
    } catch (e) {}
    set({ user: null, token: null, isAuthenticated: false, isLoading: false });
  },
}));
