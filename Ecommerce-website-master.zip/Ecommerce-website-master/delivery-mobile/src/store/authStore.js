import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const useAuthStore = create((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,

  initializeAuth: async () => {
    try {
      const token = await AsyncStorage.getItem('delivery_auth_token');
      const userStr = await AsyncStorage.getItem('delivery_auth_user');
      if (token && userStr) {
        set({
          token,
          user: JSON.parse(userStr),
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        set({ isLoading: false });
      }
    } catch (e) {
      set({ isLoading: false });
    }
  },

  setAuth: async (user, token) => {
    try {
      await AsyncStorage.setItem('delivery_auth_token', token);
      await AsyncStorage.setItem('delivery_auth_user', JSON.stringify(user));
    } catch (e) {}
    set({ user, token, isAuthenticated: true });
  },

  logout: async () => {
    try {
      await AsyncStorage.removeItem('delivery_auth_token');
      await AsyncStorage.removeItem('delivery_auth_user');
    } catch (e) {}
    set({ user: null, token: null, isAuthenticated: false });
  },
}));
