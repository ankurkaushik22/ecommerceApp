import { gql } from '@apollo/client';

export const LOGIN_MUTATION = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        role
        avatar
        phone
        vendorCategory
        vendorVertical
        vendorVerticals
        permissions
        isOnline
        isVerified
        deliveryRating {
          average
          count
        }
        currentLocation {
          latitude
          longitude
          heading
        }
      }
    }
  }
`;

export const UPDATE_DELIVERY_LOCATION = gql`
  mutation UpdateDeliveryLocation(
    $orderId: ID!
    $latitude: Float!
    $longitude: Float!
    $heading: Float
    $speed: Float
  ) {
    updateDeliveryLocation(
      orderId: $orderId
      latitude: $latitude
      longitude: $longitude
      heading: $heading
      speed: $speed
    ) {
      _id
      orderNumber
      status
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const UPDATE_DELIVERY_STATUS = gql`
  mutation UpdateDeliveryStatus(
    $orderId: ID!
    $status: String!
    $notes: String
    $latitude: Float
    $longitude: Float
  ) {
    updateDeliveryStatus(
      orderId: $orderId
      status: $status
      notes: $notes
      latitude: $latitude
      longitude: $longitude
    ) {
      _id
      orderNumber
      status
      deliveredAt
      paymentStatus
      liveLocation {
        latitude
        longitude
        heading
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const UPDATE_AGENT_DUTY_STATUS = gql`
  mutation UpdateAgentDutyStatus(
    $isOnline: Boolean!
    $latitude: Float
    $longitude: Float
  ) {
    updateAgentDutyStatus(
      isOnline: $isOnline
      latitude: $latitude
      longitude: $longitude
    ) {
      _id
      name
      isOnline
      currentLocation {
        latitude
        longitude
      }
    }
  }
`;

export const CHANGE_PASSWORD_MUTATION = gql`
  mutation ChangePassword($currentPassword: String!, $newPassword: String!) {
    changePassword(currentPassword: $currentPassword, newPassword: $newPassword)
  }
`;

export const FORGOT_PASSWORD_MUTATION = gql`
  mutation ForgotPassword($email: String!) {
    forgotPassword(email: $email) {
      success
      message
    }
  }
`;

export const VERIFY_RESET_OTP_MUTATION = gql`
  mutation VerifyResetOTP($email: String!, $otp: String!) {
    verifyResetOTP(email: $email, otp: $otp) {
      success
      message
      resetToken
    }
  }
`;

export const RESET_PASSWORD_MUTATION = gql`
  mutation ResetPassword($token: String!, $newPassword: String!) {
    resetPassword(token: $token, newPassword: $newPassword) {
      token
      refreshToken
      user {
        _id
        name
        email
        phone
        role
        avatar
      }
    }
  }
`;

export const UPDATE_PUSH_TOKEN = gql`
  mutation UpdatePushToken($token: String!) {
    updatePushToken(token: $token)
  }
`;

export const MARK_NOTIFICATION_READ = gql`
  mutation MarkNotificationRead($id: ID!) {
    markNotificationRead(id: $id) {
      _id
      isRead
    }
  }
`;

export const TOGGLE_PRODUCT_STATUS = gql`
  mutation ToggleProductStatus($id: ID!) {
    toggleProductStatus(id: $id) {
      _id
      isActive
    }
  }
`;

export const CREATE_PRODUCT = gql`
  mutation CreateProduct($input: ProductInput!) {
    createProduct(input: $input) {
      _id
      name
      price
      stock
      images
      isActive
      approvalStatus
    }
  }
`;

export const UPDATE_PRODUCT = gql`
  mutation UpdateProduct($id: ID!, $input: ProductInput!) {
    updateProduct(id: $id, input: $input) {
      _id
      name
      price
      stock
      isActive
    }
  }
`;

export const UPDATE_PRODUCT_APPROVAL = gql`
  mutation UpdateProductApproval($id: ID!, $status: String!, $reason: String, $commissionType: String, $commissionValue: Float) {
    updateProductApproval(id: $id, status: $status, reason: $reason, commissionType: $commissionType, commissionValue: $commissionValue) {
      _id
      approvalStatus
      isActive
      commissionType
      commissionValue
    }
  }
`;

export const UPDATE_ORDER_STATUS = gql`
  mutation UpdateOrderStatus(
    $orderId: ID!
    $status: String!
    $message: String
    $location: String
  ) {
    updateOrderStatus(
      orderId: $orderId
      status: $status
      message: $message
      location: $location
    ) {
      _id
      status
      trackingUpdates {
        status
        message
        timestamp
        location
      }
    }
  }
`;

export const REQUEST_PAYOUT = gql`
  mutation RequestVendorPayout($amount: Float) {
    requestVendorPayout(amount: $amount) {
      _id
      amount
      status
      createdAt
    }
  }
`;

export const REGISTER_MUTATION = gql`
  mutation Register($input: RegisterInput!) {
    register(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        phone
        role
        avatar
        vendorCategory
        vendorVertical
        isVerified
      }
    }
  }
`;

export const UPDATE_VENDOR_BANK_DETAILS = gql`
  mutation UpdateVendorBankDetails($input: BankDetailsInput!) {
    updateVendorBankDetails(input: $input) {
      accountHolderName
      accountNumber
      bankName
      ifscCode
      upiId
    }
  }
`;

export const ASSIGN_DELIVERY_BOY = gql`
  mutation AssignDeliveryBoy($orderId: ID!, $deliveryBoyId: ID!) {
    assignDeliveryBoy(orderId: $orderId, deliveryBoyId: $deliveryBoyId) {
      _id
      orderNumber
      status
      deliveryAgent {
        _id
        name
        phone
      }
      deliveryBoy {
        _id
        name
        phone
      }
    }
  }
`;

export const UPDATE_DUTY_STATUS = gql`
  mutation UpdateAgentDutyStatus($isOnline: Boolean!, $latitude: Float, $longitude: Float) {
    updateAgentDutyStatus(isOnline: $isOnline, latitude: $latitude, longitude: $longitude) {
      _id
      name
      email
      role
      isOnline
      vendorCategory
      vendorVertical
      vendorVerticals
    }
  }
`;






