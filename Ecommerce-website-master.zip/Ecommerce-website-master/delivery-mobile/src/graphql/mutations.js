import { gql } from '@apollo/client';

export const LOGIN_MUTATION = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        role
        avatar
        phone
        permissions
        isOnline
        currentLocation {
          latitude
          longitude
          heading
        }
      }
    }
  }
`;

export const UPDATE_DELIVERY_LOCATION = gql`
  mutation UpdateDeliveryLocation(
    $orderId: ID!
    $latitude: Float!
    $longitude: Float!
    $heading: Float
    $speed: Float
  ) {
    updateDeliveryLocation(
      orderId: $orderId
      latitude: $latitude
      longitude: $longitude
      heading: $heading
      speed: $speed
    ) {
      _id
      orderNumber
      status
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const UPDATE_DELIVERY_STATUS = gql`
  mutation UpdateDeliveryStatus(
    $orderId: ID!
    $status: String!
    $notes: String
    $latitude: Float
    $longitude: Float
  ) {
    updateDeliveryStatus(
      orderId: $orderId
      status: $status
      notes: $notes
      latitude: $latitude
      longitude: $longitude
    ) {
      _id
      orderNumber
      status
      deliveredAt
      paymentStatus
      liveLocation {
        latitude
        longitude
        heading
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const UPDATE_AGENT_DUTY_STATUS = gql`
  mutation UpdateAgentDutyStatus(
    $isOnline: Boolean!
    $latitude: Float
    $longitude: Float
  ) {
    updateAgentDutyStatus(
      isOnline: $isOnline
      latitude: $latitude
      longitude: $longitude
    ) {
      _id
      name
      isOnline
      currentLocation {
        latitude
        longitude
      }
    }
  }
`;
