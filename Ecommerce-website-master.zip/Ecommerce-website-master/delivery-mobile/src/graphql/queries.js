import { gql } from '@apollo/client';

export const GET_DELIVERY_AGENT_ORDERS = gql`
  query GetDeliveryAgentOrders($status: String) {
    getDeliveryAgentOrders(status: $status) {
      _id
      orderNumber
      status
      paymentMethod
      paymentStatus
      subtotal
      shippingCost
      discount
      tax
      total
      estimatedDelivery
      deliveredAt
      createdAt
      notes
      customer {
        _id
        name
        email
        phone
        avatar
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      items {
        product {
          _id
        }
        name
        price
        quantity
        image
        variantLabel
        total
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;

export const GET_ORDER_BY_ID = gql`
  query GetOrder($id: ID!) {
    getOrder(id: $id) {
      _id
      orderNumber
      status
      paymentMethod
      paymentStatus
      subtotal
      shippingCost
      tax
      total
      estimatedDelivery
      deliveredAt
      createdAt
      notes
      customer {
        _id
        name
        email
        phone
        avatar
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      items {
        product {
          _id
        }
        name
        price
        quantity
        image
        variantLabel
        total
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      destinationLocation {
        latitude
        longitude
        address
      }
      deliveryLocationUpdates {
        latitude
        longitude
        heading
        timestamp
        status
      }
      trackingUpdates {
        status
        message
        location
        timestamp
      }
    }
  }
`;
