import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  Alert,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DeliveryProfileScreen({ navigation }) {
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to end your delivery shift and log out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log Out',
        style: 'destructive',
        onPress: () => logout(),
      },
    ]);
  };

  const handleCallSupport = () => {
    Linking.openURL('tel:+919876543210');
  };

  return (
    <View style={styles.container}>
      <Header title="Partner Profile" subtitle="Executive ID & Logistics Info" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Agent Profile Card */}
        <View style={styles.profileCard}>
          <Image
            source={{
              uri:
                user?.avatar ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'Agent')}&background=059669&color=fff&size=200`,
            }}
            style={styles.avatar}
          />
          <View style={styles.profileInfo}>
            <Text style={styles.userName}>{user?.name || 'Delivery Executive'}</Text>
            <Text style={styles.userRole}>Logistics & Delivery Partner</Text>
            <Text style={styles.userEmail}>{user?.email || 'delivery@shopzone.com'}</Text>
          </View>
        </View>

        {/* Assigned Logistics Info */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Assigned Logistics Details</Text>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="business-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>Assigned Hub</Text>
            </View>
            <Text style={styles.rowVal}>ShopZone Central Hub #04</Text>
          </View>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="bicycle-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>Vehicle Type</Text>
            </View>
            <Text style={styles.rowVal}>Two-Wheeler (EV Scooter)</Text>
          </View>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="card-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>Vehicle Number</Text>
            </View>
            <Text style={styles.rowVal}>UP-15-EV-8842</Text>
          </View>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="shield-checkmark-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>KYC & Verification</Text>
            </View>
            <View style={styles.verifiedBadge}>
              <Text style={styles.verifiedText}>Verified Partner</Text>
            </View>
          </View>
        </View>

        {/* Payout & Banking */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Earnings & Payout Bank Account</Text>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="wallet-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>Payout Frequency</Text>
            </View>
            <Text style={styles.rowVal}>Daily Auto-Transfer</Text>
          </View>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="cash-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>Per Delivery Base</Text>
            </View>
            <Text style={[styles.rowVal, { color: COLORS.primary, fontWeight: '800' }]}>₹65 / Order</Text>
          </View>
        </View>

        {/* Support & Helpline */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Support & Assistance</Text>

          <TouchableOpacity style={styles.supportBtn} onPress={handleCallSupport}>
            <Ionicons name="headset-outline" size={20} color={COLORS.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.supportTitle}>Partner Helpline & Dispatcher</Text>
              <Text style={styles.supportSub}>Call immediate dispatch center</Text>
            </View>
            <Ionicons name="call" size={18} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color={COLORS.danger} />
          <Text style={styles.logoutBtnText}>End Shift & Sign Out</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>ShopZone Delivery Partner App • v1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.text,
  },
  userRole: {
    fontSize: 12,
    color: COLORS.primary,
    fontWeight: '700',
    marginTop: 2,
  },
  userEmail: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  rowLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  rowVal: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  verifiedBadge: {
    backgroundColor: COLORS.successLight,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  verifiedText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.success,
  },
  supportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: COLORS.primaryLight,
    borderRadius: 10,
    gap: 12,
  },
  supportTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  supportSub: {
    fontSize: 11,
    color: COLORS.primaryDark,
    marginTop: 1,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.dangerLight,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    borderWidth: 1,
    borderColor: '#FECACA',
    marginTop: 4,
  },
  logoutBtnText: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.danger,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 20,
  },
});
