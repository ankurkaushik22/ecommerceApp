import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  Alert,
  Linking,
  Modal,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMutation, useQuery } from '@apollo/client';
import { GET_ME } from '../../graphql/queries';
import { CHANGE_PASSWORD_MUTATION } from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DeliveryProfileScreen({ navigation }) {
  const { user, logout } = useAuthStore();
  const { data: meData } = useQuery(GET_ME, { fetchPolicy: 'cache-and-network' });
  const currentUser = meData?.me || user;

  const [modalVisible, setModalVisible] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [changePasswordMutation, { loading: savingPassword }] = useMutation(
    CHANGE_PASSWORD_MUTATION,
    {
      onCompleted: () => {
        Alert.alert('Success', 'Your password has been successfully updated!');
        setModalVisible(false);
        resetForm();
      },
      onError: (err) => {
        Alert.alert('Error', err.message || 'Failed to update password');
      },
    }
  );

  const resetForm = () => {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setShowPassword(false);
  };

  const handleChangePassword = () => {
    if (!currentPassword) {
      Alert.alert('Required', 'Please enter your current password');
      return;
    }
    if (!newPassword || newPassword.length < 6) {
      Alert.alert('Invalid Password', 'New password must be at least 6 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert('Mismatch', 'New passwords do not match');
      return;
    }

    changePasswordMutation({
      variables: { currentPassword, newPassword },
    });
  };

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log Out',
        style: 'destructive',
        onPress: () => logout(),
      },
    ]);
  };

  const handleCallSupport = () => {
    Linking.openURL('tel:+919876543210');
  };

  return (
    <View style={styles.container}>
      <Header title="Partner Profile" subtitle="Executive ID & Logistics Info" />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Agent Profile Card */}
        <View style={styles.profileCard}>
          <Image
            source={{
              uri:
                user?.avatar ||
                `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'Agent')}&background=059669&color=fff&size=200`,
            }}
            style={styles.avatar}
          />
          <View style={styles.profileInfo}>
            <Text style={styles.userName}>{user?.name || 'Delivery Executive'}</Text>
            <Text style={styles.userRole}>
              {user?.role === 'superadmin'
                ? 'Super Administrator'
                : user?.role === 'admin'
                ? 'Administrator'
                : user?.role === 'vendor'
                ? 'Vendor / Merchant'
                : 'Logistics & Delivery Partner'}
            </Text>
            <Text style={styles.userEmail}>{user?.phone || user?.email || '+91 9876543210'}</Text>
            <View style={styles.ratingBadgeHeader}>
              <Ionicons name="star" size={13} color="#F59E0B" />
              <Text style={styles.ratingBadgeText}>
                {user?.deliveryRating?.average ? Number(user.deliveryRating.average).toFixed(1) : (user?.rating || '4.8')} / 5.0
              </Text>
              <Text style={styles.ratingBadgeCount}>
                ({user?.deliveryRating?.count || 15} reviews)
              </Text>
            </View>
          </View>
        </View>

        {/* Assigned Logistics Info */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Assigned Logistics Details</Text>

          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="star-outline" size={18} color="#D97706" />
              <Text style={styles.rowLabel}>Partner Rating</Text>
            </View>
            <View style={styles.ratingRowBadge}>
              <Ionicons name="star" size={12} color="#D97706" />
              <Text style={styles.ratingRowText}>
                {user?.deliveryRating?.average ? Number(user.deliveryRating.average).toFixed(1) : '4.8'}
              </Text>
              <Text style={styles.ratingRowSub}>
                ({user?.deliveryRating?.count || 15} ratings)
              </Text>
            </View>
          </View>



          <View style={styles.row}>
            <View style={styles.rowLeft}>
              <Ionicons name="shield-checkmark-outline" size={18} color={COLORS.primary} />
              <Text style={styles.rowLabel}>KYC & Verification</Text>
            </View>
            <View
              style={[
                styles.verifiedBadge,
                { backgroundColor: currentUser?.isVerified ? '#DCFCE7' : '#FEF3C7' },
              ]}
            >
              <Text
                style={[
                  styles.verifiedText,
                  { color: currentUser?.isVerified ? '#059669' : '#D97706' },
                ]}
              >
                {currentUser?.isVerified ? 'Verified Partner' : 'Verification Pending'}
              </Text>
            </View>
          </View>
        </View>

        {/* Account Security & Password */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Account Security</Text>

          <TouchableOpacity style={styles.securityBtn} onPress={() => setModalVisible(true)}>
            <Ionicons name="key-outline" size={20} color={COLORS.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.securityTitle}>Update Password</Text>
              <Text style={styles.securitySub}>Change your login password</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* Support & Helpline */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Support & Assistance</Text>

          <TouchableOpacity style={styles.supportBtn} onPress={handleCallSupport}>
            <Ionicons name="headset-outline" size={20} color={COLORS.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.supportTitle}>Partner Helpline & Dispatcher</Text>
              <Text style={styles.supportSub}>Call immediate dispatch center</Text>
            </View>
            <Ionicons name="call" size={18} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color={COLORS.danger} />
          <Text style={styles.logoutBtnText}>Sign Out</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>Suaaka Delivery Partner App • v1.0.0</Text>
      </ScrollView>

      {/* UPDATE PASSWORD MODAL */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Ionicons name="key-outline" size={22} color={COLORS.primary} />
                <Text style={styles.modalTitle}>Update Password</Text>
              </View>
              <TouchableOpacity
                onPress={() => {
                  setModalVisible(false);
                  resetForm();
                }}
              >
                <Ionicons name="close" size={24} color={COLORS.textSecondary} />
              </TouchableOpacity>
            </View>

            <View style={{ marginTop: 14, gap: 12 }}>
              <View>
                <Text style={styles.inputLabel}>Current Password</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="lock-closed-outline" size={18} color={COLORS.textSecondary} style={{ marginRight: 8 }} />
                  <TextInput
                    style={styles.input}
                    placeholder="Enter current password"
                    placeholderTextColor={COLORS.textMuted}
                    secureTextEntry={!showPassword}
                    maxLength={15}
                    value={currentPassword}
                    onChangeText={setCurrentPassword}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                    <Ionicons name={showPassword ? 'eye-off-outline' : 'eye-outline'} size={18} color={COLORS.textSecondary} />
                  </TouchableOpacity>
                </View>
              </View>

              <View>
                <Text style={styles.inputLabel}>New Password</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="lock-closed-outline" size={18} color={COLORS.textSecondary} style={{ marginRight: 8 }} />
                  <TextInput
                    style={styles.input}
                    placeholder="Min 6 characters"
                    placeholderTextColor={COLORS.textMuted}
                    secureTextEntry={!showPassword}
                    maxLength={15}
                    value={newPassword}
                    onChangeText={setNewPassword}
                  />
                </View>
              </View>

              <View>
                <Text style={styles.inputLabel}>Confirm New Password</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="lock-closed-outline" size={18} color={COLORS.textSecondary} style={{ marginRight: 8 }} />
                  <TextInput
                    style={styles.input}
                    placeholder="Re-enter new password"
                    placeholderTextColor={COLORS.textMuted}
                    secureTextEntry={!showPassword}
                    maxLength={15}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                  />
                </View>
              </View>

              <TouchableOpacity
                style={[styles.savePassBtn, savingPassword && { opacity: 0.6 }]}
                onPress={handleChangePassword}
                disabled={savingPassword}
              >
                {savingPassword ? (
                  <ActivityIndicator color={COLORS.white} />
                ) : (
                  <Text style={styles.savePassBtnText}>Save New Password</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.text,
  },
  userRole: {
    fontSize: 12,
    color: COLORS.primary,
    fontWeight: '700',
    marginTop: 2,
  },
  userEmail: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  rowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  rowLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  rowVal: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  verifiedBadge: {
    backgroundColor: COLORS.successLight,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  verifiedText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.success,
  },
  securityBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: COLORS.surface,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    gap: 12,
  },
  securityTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  securitySub: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  supportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: COLORS.primaryLight,
    borderRadius: 10,
    gap: 12,
  },
  supportTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  supportSub: {
    fontSize: 11,
    color: COLORS.primaryDark,
    marginTop: 1,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.dangerLight,
    borderRadius: SIZES.radius,
    padding: 16,
    marginTop: 8,
    marginBottom: 16,
    gap: 8,
  },
  logoutBtnText: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.danger,
  },
  versionText: {
    textAlign: 'center',
    fontSize: 11,
    color: COLORS.textMuted,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    width: '100%',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 20,
    ...SHADOWS.medium,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    borderRadius: SIZES.radius,
    paddingHorizontal: 12,
    height: 44,
  },
  input: {
    flex: 1,
    fontSize: 13,
    color: COLORS.text,
  },
  savePassBtn: {
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radius,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  savePassBtnText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '800',
  },
  ratingBadgeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FEF3C7',
    borderColor: '#FDE68A',
    borderWidth: 1,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginTop: 6,
    alignSelf: 'flex-start',
  },
  ratingBadgeText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#92400E',
  },
  ratingBadgeCount: {
    fontSize: 10,
    fontWeight: '600',
    color: '#B45309',
  },
  ratingRowBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  ratingRowText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#92400E',
  },
  ratingRowSub: {
    fontSize: 10,
    color: '#B45309',
    fontWeight: '500',
  },
});
