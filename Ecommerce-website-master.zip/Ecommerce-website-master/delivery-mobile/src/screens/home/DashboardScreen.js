import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  RefreshControl,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_DELIVERY_AGENT_ORDERS } from '../../graphql/queries';
import { UPDATE_AGENT_DUTY_STATUS } from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import { useDutyStore } from '../../store/dutyStore';
import Header from '../../components/common/Header';
import DeliveryCard from '../../components/common/DeliveryCard';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DashboardScreen({ navigation }) {
  const user = useAuthStore((s) => s.user);
  const { isOnDuty, setIsOnDuty, currentLocation } = useDutyStore();
  const [selectedFilter, setSelectedFilter] = useState('all');

  const { data, loading, refetch } = useQuery(GET_DELIVERY_AGENT_ORDERS, {
    pollInterval: 10000, // Poll every 10 seconds for live new assignments
  });

  const [updateDutyStatus] = useMutation(UPDATE_AGENT_DUTY_STATUS);

  const handleToggleDuty = (val) => {
    setIsOnDuty(val);
    updateDutyStatus({
      variables: {
        isOnline: val,
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
      },
    });
  };

  const orders = data?.getDeliveryAgentOrders || [];

  // Metrics computation
  const activeOrders = orders.filter((o) =>
    ['confirmed', 'preparing', 'dispatched', 'out_for_delivery'].includes(o.status)
  );
  const deliveredToday = orders.filter((o) => o.status === 'delivered').length;
  const codToCollect = activeOrders
    .filter((o) => o.paymentMethod === 'cod')
    .reduce((sum, o) => sum + (o.total || 0), 0);
  const totalEarningsToday = deliveredToday * 65 + 150; // ₹65 per delivery + base incentive

  const filteredOrders = orders.filter((o) => {
    if (selectedFilter === 'active') {
      return ['confirmed', 'preparing', 'dispatched', 'out_for_delivery'].includes(o.status);
    }
    if (selectedFilter === 'out_for_delivery') {
      return o.status === 'out_for_delivery';
    }
    if (selectedFilter === 'delivered') {
      return o.status === 'delivered';
    }
    return true;
  });

  return (
    <View style={styles.container}>
      <Header
        title="Delivery Console"
        subtitle={`Partner ID: #${user?._id?.slice(-6) || '84920'}`}
        rightComponent={
          <View style={styles.dutyToggleWrap}>
            <Text style={[styles.dutyText, { color: isOnDuty ? COLORS.success : COLORS.textMuted }]}>
              {isOnDuty ? 'ON DUTY' : 'OFFLINE'}
            </Text>
            <Switch
              value={isOnDuty}
              onValueChange={handleToggleDuty}
              trackColor={{ false: '#CBD5E1', true: '#A7F3D0' }}
              thumbColor={isOnDuty ? COLORS.primary : '#F1F5F9'}
            />
          </View>
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} colors={[COLORS.primary]} />}
      >
        {/* Welcome & Live Status Banner */}
        <View style={[styles.dutyBanner, { backgroundColor: isOnDuty ? COLORS.primaryLight : '#F1F5F9' }]}>
          <View style={styles.dutyIconWrap}>
            <Ionicons
              name={isOnDuty ? 'radio' : 'pause-circle'}
              size={24}
              color={isOnDuty ? COLORS.primary : COLORS.textMuted}
            />
          </View>
          <View style={styles.dutyInfo}>
            <Text style={styles.dutyTitle}>
              {isOnDuty ? 'You are receiving delivery orders' : 'You are currently offline'}
            </Text>
            <Text style={styles.dutySub}>
              {isOnDuty ? 'GPS tracking is live for customers' : 'Toggle switch above to start receiving deliveries'}
            </Text>
          </View>
        </View>

        {/* Metrics Grid */}
        <View style={styles.metricsGrid}>
          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.primaryLight }]}>
              <Ionicons name="cube-outline" size={20} color={COLORS.primary} />
            </View>
            <Text style={styles.metricValue}>{activeOrders.length}</Text>
            <Text style={styles.metricLabel}>Active Orders</Text>
          </View>

          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.successLight }]}>
              <Ionicons name="checkmark-done-outline" size={20} color={COLORS.success} />
            </View>
            <Text style={styles.metricValue}>{deliveredToday}</Text>
            <Text style={styles.metricLabel}>Delivered Today</Text>
          </View>

          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.secondaryLight }]}>
              <Ionicons name="cash-outline" size={20} color={COLORS.secondary} />
            </View>
            <Text style={styles.metricValue}>₹{codToCollect.toFixed(0)}</Text>
            <Text style={styles.metricLabel}>COD to Collect</Text>
          </View>

          <View style={styles.metricCard}>
            <View style={[styles.metricIconCircle, { backgroundColor: COLORS.accentLight }]}>
              <Ionicons name="wallet-outline" size={20} color={COLORS.accent} />
            </View>
            <Text style={styles.metricValue}>₹{totalEarningsToday.toFixed(0)}</Text>
            <Text style={styles.metricLabel}>Today's Payout</Text>
          </View>
        </View>

        {/* Filter Pills */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Assigned Packages</Text>
          <Text style={styles.sectionCount}>{filteredOrders.length} Tasks</Text>
        </View>

        <View style={styles.pillRow}>
          {[
            { label: 'All Tasks', value: 'all' },
            { label: 'Pending Active', value: 'active' },
            { label: 'Out for Delivery', value: 'out_for_delivery' },
            { label: 'Delivered', value: 'delivered' },
          ].map((pill) => (
            <TouchableOpacity
              key={pill.value}
              style={[styles.pill, selectedFilter === pill.value && styles.pillActive]}
              onPress={() => setSelectedFilter(pill.value)}
            >
              <Text
                style={[
                  styles.pillText,
                  selectedFilter === pill.value && styles.pillTextActive,
                ]}
              >
                {pill.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="bicycle-outline" size={54} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Deliveries in this list</Text>
            <Text style={styles.emptySub}>
              {isOnDuty
                ? 'Stay nearby the hub. New orders will appear here automatically.'
                : 'Turn ON your duty switch to get assigned new orders.'}
            </Text>
          </View>
        ) : (
          filteredOrders.map((order) => (
            <DeliveryCard
              key={order._id}
              order={order}
              onPress={() => navigation.navigate('DeliveryDetail', { orderId: order._id })}
              onTrackPress={() => navigation.navigate('LiveTrackingNav', { orderId: order._id })}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  dutyToggleWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  dutyText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  dutyBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: SIZES.radiusLarge,
    padding: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  dutyIconWrap: {
    marginRight: 12,
  },
  dutyInfo: {
    flex: 1,
  },
  dutyTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  dutySub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  metricCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  metricIconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  metricValue: {
    fontSize: 20,
    fontWeight: '800',
    color: COLORS.text,
  },
  metricLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
    fontWeight: '500',
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  sectionCount: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.primary,
  },
  pillRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  pill: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  pillActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  pillText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  pillTextActive: {
    color: COLORS.white,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginTop: 10,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 12,
  },
  emptySub: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 18,
  },
});
