import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_DELIVERY_AGENT_ORDERS } from '../../graphql/queries';
import Header from '../../components/common/Header';
import DeliveryCard from '../../components/common/DeliveryCard';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DeliveryHistoryScreen({ navigation }) {
  const { data, loading, refetch } = useQuery(GET_DELIVERY_AGENT_ORDERS, {
    variables: { status: 'delivered' },
  });

  const orders = data?.getDeliveryAgentOrders || [];

  return (
    <View style={styles.container}>
      <Header title="Delivery History" subtitle="Completed & reconciled deliveries" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} colors={[COLORS.primary]} />}
      >
        {/* Performance Header Summary */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryValue}>{orders.length}</Text>
            <Text style={styles.summaryLabel}>Total Delivered</Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryValue}>100%</Text>
            <Text style={styles.summaryLabel}>Success Rate</Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryValue}>4.9 ★</Text>
            <Text style={styles.summaryLabel}>Rating</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Completed Orders</Text>

        {orders.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="checkmark-done-circle-outline" size={54} color={COLORS.textMuted} />
            <Text style={styles.emptyTitle}>No Completed Deliveries Yet</Text>
            <Text style={styles.emptySub}>
              Once you complete delivery tasks, your full trip history will appear here.
            </Text>
          </View>
        ) : (
          orders.map((order) => (
            <DeliveryCard
              key={order._id}
              order={order}
              onPress={() => navigation.navigate('DeliveryDetail', { orderId: order._id })}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  summaryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    padding: 18,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  summaryItem: {
    flex: 1,
    alignItems: 'center',
  },
  summaryDivider: {
    width: 1,
    height: 30,
    backgroundColor: COLORS.border,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.primary,
  },
  summaryLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 4,
    fontWeight: '600',
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLarge,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginTop: 10,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 12,
  },
  emptySub: {
    fontSize: 13,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 18,
  },
});
