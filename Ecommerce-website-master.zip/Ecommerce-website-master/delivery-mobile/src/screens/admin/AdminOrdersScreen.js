import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_ALL_ORDERS } from '../../graphql/queries';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

function formatDate(createdAt) {
  if (!createdAt) return 'N/A';
  const raw = typeof createdAt === 'string' && !isNaN(createdAt) ? Number(createdAt) : createdAt;
  const d = new Date(raw);
  if (isNaN(d.getTime())) return 'N/A';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatStatusLabel(status) {
  if (!status) return 'PENDING';
  return String(status).replace(/_/g, ' ').toUpperCase();
}

function getBadgeTextColor(status) {
  if (status === 'delivered' || status === 'completed') return '#047857';
  if (status === 'cancelled' || status === 'refunded') return '#B91C1C';
  return '#B45309';
}

const VERTICAL_TABS = [
  { id: 'all', label: 'All Verticals' },
  { id: 'shopping', label: 'Shopping' },
  { id: 'food', label: 'Food Delivery' },
  { id: 'grocery', label: 'Grocery' },
  { id: 'services', label: 'Services' },
];

export default function AdminOrdersScreen() {
  const insets = useSafeAreaInsets();
  const [activeStatus, setActiveStatus] = useState('all');
  const [selectedVertical, setSelectedVertical] = useState('all');

  const { data, loading, refetch } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: activeStatus === 'all' ? null : activeStatus,
      vertical: selectedVertical === 'all' ? null : selectedVertical,
    },
    pollInterval: 5000,
    fetchPolicy: 'cache-and-network',
  });

  const rawOrders = data?.getAllOrders || data?.getOrders;
  const orders = Array.isArray(rawOrders?.orders) ? rawOrders.orders : Array.isArray(rawOrders) ? rawOrders : [];

  return (
    <View style={[styles.container, { paddingTop: Math.max(insets.top, 16) }]}>
      <View style={styles.header}>
        <Text style={styles.title}>All Store Orders</Text>
        <TouchableOpacity style={styles.refreshBtn} onPress={() => refetch()}>
          <Ionicons name="refresh" size={20} color={COLORS.primary} />
        </TouchableOpacity>
      </View>

      {/* Vertical Selector Tabs */}
      <View style={{ marginBottom: 6 }}>
        <FlatList
          horizontal
          data={VERTICAL_TABS}
          keyExtractor={(item) => item.id}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 6 }}
          renderItem={({ item }) => {
            const isSelected = selectedVertical === item.id;
            return (
              <TouchableOpacity
                style={[styles.vChip, isSelected && styles.vChipActive]}
                onPress={() => setSelectedVertical(item.id)}
              >
                <Text style={[styles.vChipText, isSelected && styles.vChipTextActive]}>
                  {item.label}
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      {/* Status Filter Tabs */}
      <View style={styles.tabsWrapper}>
        <FlatList
          horizontal
          data={['all', 'pending', 'processing', 'out_for_delivery', 'delivered', 'cancelled']}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          renderItem={({ item }) => {
            const isSelected = activeStatus === item;
            return (
              <TouchableOpacity
                style={[styles.tab, isSelected && styles.activeTab]}
                onPress={() => setActiveStatus(item)}
              >
                <Text style={[styles.tabText, isSelected && styles.activeTabText]}>
                  {item.replace(/_/g, ' ').toUpperCase()}
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      {loading ? (
        <View style={styles.loaderBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
        </View>
      ) : orders.length === 0 ? (
        <View style={styles.emptyBox}>
          <Ionicons name="bag-remove-outline" size={48} color={COLORS.textMuted} />
          <Text style={styles.emptyText}>No orders found in this status</Text>
        </View>
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <View style={styles.orderCard}>
              <View style={styles.cardHeader}>
                <View style={{ flex: 1, marginRight: 8 }}>
                  <Text style={styles.orderNum} numberOfLines={1} ellipsizeMode="tail">
                    #{item.orderNumber}
                  </Text>
                  <Text style={styles.dateText}>
                    {formatDate(item.createdAt)}
                  </Text>
                </View>
                <View
                  style={[
                    styles.badge,
                    {
                      backgroundColor:
                        item.status === 'delivered' || item.status === 'completed'
                          ? '#D1FAE5'
                          : item.status === 'cancelled' || item.status === 'refunded'
                          ? '#FEE2E2'
                          : '#FEF3C7',
                    },
                  ]}
                >
                  <Text
                    style={[styles.badgeText, { color: getBadgeTextColor(item.status) }]}
                    numberOfLines={1}
                    ellipsizeMode="tail"
                  >
                    {formatStatusLabel(item.status)}
                  </Text>
                </View>
              </View>

              <View style={styles.divider} />

              <Text style={styles.customerText}>
                Customer: {item.customer?.name || item.shippingAddress?.fullName || 'Customer'}
              </Text>
              <Text style={styles.addressText}>
                📍 {item.shippingAddress?.addressLine1}, {item.shippingAddress?.city}
              </Text>

              <View style={styles.cardFooter}>
                <Text style={styles.totalAmount}>Total: ₹{(item.total || 0).toLocaleString('en-IN')}</Text>
                <Text style={styles.paymentMethod}>
                  {item.paymentMethod?.toUpperCase()} • {item.paymentStatus?.toUpperCase()}
                </Text>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.text,
  },
  refreshBtn: {
    padding: 6,
  },
  tabsWrapper: {
    marginBottom: 12,
  },
  tab: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  activeTab: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  tabText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  orderCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  orderNum: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
  },
  dateText: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    maxWidth: '48%',
    flexShrink: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#92400E',
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 10,
  },
  customerText: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.text,
  },
  addressText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
    marginBottom: 8,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  totalAmount: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.primary,
  },
  paymentMethod: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textMuted,
  },
  loaderBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  emptyText: {
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 8,
  },
  vChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  vChipActive: {
    backgroundColor: '#4F46E5',
    borderColor: '#4F46E5',
  },
  vChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  vChipTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
});
