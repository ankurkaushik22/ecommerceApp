import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Linking,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_ORDER_BY_ID } from '../../graphql/queries';
import { UPDATE_DELIVERY_LOCATION, UPDATE_DELIVERY_STATUS } from '../../graphql/mutations';
import { useDutyStore } from '../../store/dutyStore';
import Header from '../../components/common/Header';
import DeliveryMapView from '../../components/map/DeliveryMapView';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function LiveTrackingNavScreen({ route, navigation }) {
  const { orderId } = route.params || {};
  const { currentLocation, setCurrentLocation } = useDutyStore();
  const [isAutoNavigating, setIsAutoNavigating] = useState(false);
  const [speed, setSpeed] = useState(26);

  const { data, loading, refetch } = useQuery(GET_ORDER_BY_ID, {
    variables: { id: orderId },
    skip: !orderId,
  });

  const [updateLocation] = useMutation(UPDATE_DELIVERY_LOCATION);
  const [updateStatus] = useMutation(UPDATE_DELIVERY_STATUS, {
    onCompleted: () => {
      refetch();
    },
  });

  const order = data?.getOrder;

  // Auto GPS broadcasting loop when auto-navigation is on
  useEffect(() => {
    let interval = null;
    if (isAutoNavigating && order) {
      interval = setInterval(() => {
        const destLat = order.destinationLocation?.latitude || 28.995;
        const destLng = order.destinationLocation?.longitude || 77.718;

        // Move 10% closer to destination each tick
        const currLat = currentLocation.latitude;
        const currLng = currentLocation.longitude;

        const newLat = currLat + (destLat - currLat) * 0.15;
        const newLng = currLng + (destLng - currLng) * 0.15;

        const updated = {
          latitude: parseFloat(newLat.toFixed(5)),
          longitude: parseFloat(newLng.toFixed(5)),
          heading: 45,
          speed: Math.floor(22 + Math.random() * 8),
        };

        setCurrentLocation(updated);
        setSpeed(updated.speed);

        updateLocation({
          variables: {
            orderId: order._id,
            latitude: updated.latitude,
            longitude: updated.longitude,
            heading: updated.heading,
            speed: updated.speed,
          },
        });
      }, 3500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isAutoNavigating, order, currentLocation]);

  if (loading || !order) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Connecting to GPS tracking satellite...</Text>
      </View>
    );
  }

  const address = order.shippingAddress;
  const addressString = address
    ? `${address.addressLine1 || ''}, ${address.city || ''}`
    : 'Customer Address';

  const customerLat = order.destinationLocation?.latitude || 28.995;
  const customerLng = order.destinationLocation?.longitude || 77.718;

  const handleMarkDelivered = () => {
    Alert.alert('Confirm Delivery', 'Mark this order as successfully handed over to customer?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Confirm Delivered',
        onPress: () => {
          setIsAutoNavigating(false);
          updateStatus({
            variables: {
              orderId: order._id,
              status: 'delivered',
              notes: 'Package handed over to customer at doorstep.',
              latitude: currentLocation.latitude,
              longitude: currentLocation.longitude,
            },
          });
          Alert.alert('Success', 'Order completed! Great job.', [
            { text: 'OK', onPress: () => navigation.navigate('DashboardTab') },
          ]);
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <Header
        title={`Live Navigation #${order.orderNumber || order._id.slice(-6)}`}
        subtitle="Broadcasting real-time coordinates"
        showBack={true}
      />

      <View style={styles.content}>
        {/* Fullscreen Map View */}
        <DeliveryMapView
          agentLocation={currentLocation}
          customerLocation={{ latitude: customerLat, longitude: customerLng }}
          customerAddress={addressString}
          customerName={address?.fullName || order.customer?.name || 'Customer'}
          customerPhone={address?.phone || order.customer?.phone}
          orderNumber={order.orderNumber}
          orderStatus={order.status}
          isLiveBroadcasting={isAutoNavigating || order.status === 'out_for_delivery'}
        />

        {/* Live GPS Telemetry Overlay */}
        <View style={styles.telemetryCard}>
          <View style={styles.telemetryItem}>
            <Text style={styles.telemetryLabel}>GPS STATUS</Text>
            <View style={styles.statusPill}>
              <View
                style={[
                  styles.statusDot,
                  { backgroundColor: isAutoNavigating ? COLORS.success : COLORS.warning },
                ]}
              />
              <Text style={styles.statusPillText}>
                {isAutoNavigating ? 'STREAMING' : 'READY'}
              </Text>
            </View>
          </View>

          <View style={styles.telemetryItem}>
            <Text style={styles.telemetryLabel}>SPEED</Text>
            <Text style={styles.telemetryVal}>{isAutoNavigating ? speed : 0} km/h</Text>
          </View>

          <View style={styles.telemetryItem}>
            <Text style={styles.telemetryLabel}>COORDINATES</Text>
            <Text style={styles.telemetryVal} numberOfLines={1}>
              {currentLocation.latitude.toFixed(3)}, {currentLocation.longitude.toFixed(3)}
            </Text>
          </View>
        </View>

        {/* Live Navigation Controller Controls */}
        <View style={styles.controlSection}>
          <TouchableOpacity
            style={[
              styles.navToggleBtn,
              { backgroundColor: isAutoNavigating ? '#DC2626' : COLORS.primary },
            ]}
            onPress={() => setIsAutoNavigating(!isAutoNavigating)}
          >
            <Ionicons
              name={isAutoNavigating ? 'pause' : 'play'}
              size={20}
              color={COLORS.white}
            />
            <Text style={styles.navToggleBtnText}>
              {isAutoNavigating ? 'Pause GPS Broadcast' : 'Start Auto GPS Broadcast 🛰️'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.deliveredBtn} onPress={handleMarkDelivered}>
            <Ionicons name="checkmark-circle" size={20} color={COLORS.white} />
            <Text style={styles.deliveredBtnText}>Arrived & Hand Over Package</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.background,
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  content: {
    flex: 1,
    padding: 16,
    justifyContent: 'space-between',
  },
  telemetryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.surface,
    padding: 14,
    borderRadius: SIZES.radius,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
    marginVertical: 10,
  },
  telemetryItem: {
    alignItems: 'center',
  },
  telemetryLabel: {
    fontSize: 10,
    fontWeight: '800',
    color: COLORS.textMuted,
    marginBottom: 4,
  },
  telemetryVal: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  statusPillText: {
    fontSize: 12,
    fontWeight: '800',
    color: COLORS.text,
  },
  controlSection: {
    gap: 10,
    marginTop: 'auto',
  },
  navToggleBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  navToggleBtnText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '700',
  },
  deliveredBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.success,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  deliveredBtnText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '700',
  },
});
