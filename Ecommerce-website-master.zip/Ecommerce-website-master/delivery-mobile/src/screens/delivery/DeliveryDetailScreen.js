import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_ORDER_BY_ID } from '../../graphql/queries';
import { UPDATE_DELIVERY_STATUS, UPDATE_DELIVERY_LOCATION } from '../../graphql/mutations';
import { useDutyStore } from '../../store/dutyStore';
import Header from '../../components/common/Header';
import StatusBadge from '../../components/common/StatusBadge';
import DeliveryMapView from '../../components/map/DeliveryMapView';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DeliveryDetailScreen({ route, navigation }) {
  const { orderId } = route.params || {};
  const { currentLocation, setCurrentLocation } = useDutyStore();
  const [isSimulating, setIsSimulating] = useState(false);

  const { data, loading, refetch } = useQuery(GET_ORDER_BY_ID, {
    variables: { id: orderId },
    skip: !orderId,
    pollInterval: 5000,
  });

  const [updateStatus, { loading: updatingStatus }] = useMutation(UPDATE_DELIVERY_STATUS, {
    onCompleted: () => {
      refetch();
    },
    onError: (err) => {
      Alert.alert('Update Failed', err.message);
    },
  });

  const [updateLocation] = useMutation(UPDATE_DELIVERY_LOCATION);

  const order = data?.getOrder;

  if (loading || !order) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
        <Text style={styles.loadingText}>Loading delivery task details...</Text>
      </View>
    );
  }

  const address = order.shippingAddress;
  const addressString = address
    ? `${address.addressLine1 || ''}, ${address.addressLine2 ? address.addressLine2 + ', ' : ''}${address.city || ''}, ${address.state || ''} - ${address.postalCode || ''}`
    : 'Customer Address';

  const customerLat = order.destinationLocation?.latitude || 28.995;
  const customerLng = order.destinationLocation?.longitude || 77.718;

  const agentLat = order.liveLocation?.latitude || currentLocation.latitude;
  const agentLng = order.liveLocation?.longitude || currentLocation.longitude;

  // 1-Step Simulated movement towards customer
  const handleSimulateMove = () => {
    const nextLat = agentLat + (customerLat - agentLat) * 0.25;
    const nextLng = agentLng + (customerLng - agentLng) * 0.25;

    const newLoc = {
      latitude: parseFloat(nextLat.toFixed(5)),
      longitude: parseFloat(nextLng.toFixed(5)),
      heading: 45,
      speed: 28,
    };
    setCurrentLocation(newLoc);

    updateLocation({
      variables: {
        orderId: order._id,
        latitude: newLoc.latitude,
        longitude: newLoc.longitude,
        heading: newLoc.heading,
        speed: newLoc.speed,
      },
    });

    Alert.alert(
      'Live GPS Updated',
      `Broadcasted new coordinates: ${newLoc.latitude}, ${newLoc.longitude} to customer app.`
    );
  };

  const handleStatusChange = (nextStatus, message) => {
    Alert.alert(
      'Confirm Status Update',
      `Are you sure you want to mark this package as "${nextStatus.replace(/_/g, ' ').toUpperCase()}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Confirm',
          onPress: () => {
            updateStatus({
              variables: {
                orderId: order._id,
                status: nextStatus,
                notes: message,
                latitude: agentLat,
                longitude: agentLng,
              },
            });
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Header
        title={`Task #${order.orderNumber || order._id.slice(-6)}`}
        subtitle={order.status.replace(/_/g, ' ').toUpperCase()}
        showBack={true}
        rightComponent={
          <TouchableOpacity
            style={styles.navHeaderBtn}
            onPress={() => navigation.navigate('LiveTrackingNav', { orderId: order._id })}
          >
            <Ionicons name="map" size={18} color={COLORS.primary} />
            <Text style={styles.navHeaderBtnText}>Live Nav</Text>
          </TouchableOpacity>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Interactive Map View */}
        <DeliveryMapView
          agentLocation={{ latitude: agentLat, longitude: agentLng }}
          customerLocation={{ latitude: customerLat, longitude: customerLng }}
          customerAddress={addressString}
          customerName={address?.fullName || order.customer?.name || 'Customer'}
          customerPhone={address?.phone || order.customer?.phone}
          orderNumber={order.orderNumber}
          orderStatus={order.status}
          onSimulateMove={handleSimulateMove}
          isLiveBroadcasting={order.status === 'out_for_delivery'}
        />

        {/* Action Stepper Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Delivery Progress & Actions</Text>
          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>Current Status:</Text>
            <StatusBadge status={order.status} />
          </View>

          {/* Stepper Buttons based on status */}
          {['confirmed', 'preparing'].includes(order.status) && (
            <TouchableOpacity
              style={styles.actionBtnPrimary}
              onPress={() =>
                handleStatusChange(
                  'dispatched',
                  'Delivery agent accepted the task and picked up package from warehouse.'
                )
              }
              disabled={updatingStatus}
            >
              <Ionicons name="cube-outline" size={20} color={COLORS.white} />
              <Text style={styles.actionBtnText}>Accept & Pick Up Package</Text>
            </TouchableOpacity>
          )}

          {order.status === 'dispatched' && (
            <TouchableOpacity
              style={[styles.actionBtnPrimary, { backgroundColor: COLORS.secondary }]}
              onPress={() =>
                handleStatusChange(
                  'out_for_delivery',
                  'Delivery agent is heading towards customer address with the package.'
                )
              }
              disabled={updatingStatus}
            >
              <Ionicons name="bicycle" size={20} color={COLORS.white} />
              <Text style={styles.actionBtnText}>Start Journey: Out for Delivery</Text>
            </TouchableOpacity>
          )}

          {order.status === 'out_for_delivery' && (
            <View style={styles.outForDeliveryActions}>
              <TouchableOpacity
                style={styles.actionBtnSuccess}
                onPress={() =>
                  handleStatusChange(
                    'delivered',
                    'Package successfully handed over to customer. Payment reconciled.'
                  )
                }
                disabled={updatingStatus}
              >
                <Ionicons name="checkmark-circle" size={20} color={COLORS.white} />
                <Text style={styles.actionBtnText}>Mark as Successfully Delivered 🎉</Text>
              </TouchableOpacity>
            </View>
          )}

          {order.status === 'delivered' && (
            <View style={styles.deliveredBanner}>
              <Ionicons name="checkmark-done-circle" size={24} color={COLORS.success} />
              <Text style={styles.deliveredBannerText}>This order is completed and delivered.</Text>
            </View>
          )}
        </View>

        {/* Customer & Address Details */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Customer Information</Text>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Name</Text>
            <Text style={styles.infoValue}>
              {address?.fullName || order.customer?.name || 'Customer'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Phone</Text>
            <Text style={styles.infoValue}>
              {address?.phone || order.customer?.phone || 'Not provided'}
            </Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Delivery Address</Text>
            <Text style={[styles.infoValue, { flex: 1, textAlign: 'right' }]}>
              {addressString}
            </Text>
          </View>
        </View>

        {/* Package Items Breakdown */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Package Contents ({order.items?.length || 0} items)</Text>
          {order.items?.map((item, idx) => (
            <View key={item._id || idx} style={styles.itemRow}>
              {item.image ? (
                <Image source={{ uri: item.image }} style={styles.itemImage} />
              ) : (
                <View style={styles.itemPlaceholder}>
                  <Ionicons name="cube-outline" size={20} color={COLORS.textMuted} />
                </View>
              )}
              <View style={styles.itemInfo}>
                <Text style={styles.itemName} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={styles.itemQty}>Qty: {item.quantity || 1}</Text>
              </View>
              <Text style={styles.itemPrice}>₹{((item.price || 0) * (item.quantity || 1)).toFixed(0)}</Text>
            </View>
          ))}

          {/* Payment Summary */}
          <View style={styles.paymentSummary}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Payment Mode</Text>
              <Text style={styles.summaryValue}>
                {order.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : 'Prepaid Online'}
              </Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Total Payable Amount</Text>
              <Text style={styles.totalValue}>₹{order.total?.toFixed(0)}</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.background,
    gap: 12,
  },
  loadingText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  navHeaderBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    gap: 4,
  },
  navHeaderBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  scroll: {
    padding: 16,
    paddingBottom: 40,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statusLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  actionBtnPrimary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  actionBtnSuccess: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.success,
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    gap: 8,
    ...SHADOWS.medium,
  },
  actionBtnText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '700',
  },
  outForDeliveryActions: {
    gap: 10,
  },
  deliveredBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.successLight,
    padding: 12,
    borderRadius: 8,
    gap: 8,
  },
  deliveredBannerText: {
    color: COLORS.success,
    fontSize: 13,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  infoLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontWeight: '500',
  },
  infoValue: {
    fontSize: 13,
    color: COLORS.text,
    fontWeight: '700',
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  itemImage: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    marginRight: 10,
  },
  itemPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  itemQty: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  itemPrice: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  paymentSummary: {
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  summaryLabel: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  summaryValue: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '900',
    color: COLORS.primary,
  },
});
