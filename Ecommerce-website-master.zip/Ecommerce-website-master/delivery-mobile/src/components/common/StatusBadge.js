import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../../constants/theme';

export default function StatusBadge({ status }) {
  const getStatusConfig = () => {
    switch (status?.toLowerCase()) {
      case 'delivered':
        return {
          label: 'Delivered',
          bg: COLORS.successLight,
          color: COLORS.success,
        };
      case 'out_for_delivery':
        return {
          label: 'Out for Delivery',
          bg: COLORS.secondaryLight,
          color: COLORS.secondary,
        };
      case 'dispatched':
        return {
          label: 'Dispatched / In Transit',
          bg: COLORS.accentLight,
          color: COLORS.accent,
        };
      case 'preparing':
      case 'confirmed':
        return {
          label: 'Ready for Pickup',
          bg: COLORS.warningLight,
          color: COLORS.warning,
        };
      case 'cancelled':
        return {
          label: 'Cancelled',
          bg: COLORS.dangerLight,
          color: COLORS.danger,
        };
      default:
        return {
          label: status || 'Pending',
          bg: COLORS.background,
          color: COLORS.textSecondary,
        };
    }
  };

  const config = getStatusConfig();

  return (
    <View style={[styles.badge, { backgroundColor: config.bg }]}>
      <View style={[styles.dot, { backgroundColor: config.color }]} />
      <Text style={[styles.text, { color: config.color }]}>{config.label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  text: {
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'capitalize',
  },
});
