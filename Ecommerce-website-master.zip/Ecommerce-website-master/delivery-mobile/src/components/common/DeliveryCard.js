import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import StatusBadge from './StatusBadge';

export default function DeliveryCard({ order, onPress, onTrackPress }) {
  const address = order.shippingAddress;
  const addressText = address
    ? `${address.addressLine1 || ''}, ${address.city || ''}`
    : 'Customer Address';

  const itemCount = order.items?.reduce((sum, item) => sum + (item.quantity || 1), 0) || 1;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.85}>
      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.orderNumberWrap}>
          <Text style={styles.orderNumber}>#{order.orderNumber || order._id}</Text>
          <Text style={styles.itemCount}>
            {itemCount} {itemCount === 1 ? 'Item' : 'Items'} • ₹{order.total?.toFixed(0)}
          </Text>
        </View>
        <StatusBadge status={order.status} />
      </View>

      {/* Destination row */}
      <View style={styles.addressRow}>
        <View style={styles.addressIconWrap}>
          <Ionicons name="location-outline" size={18} color={COLORS.primary} />
        </View>
        <View style={styles.addressContent}>
          <Text style={styles.customerName}>{address?.fullName || order.customer?.name || 'Customer'}</Text>
          <Text style={styles.addressText} numberOfLines={1}>
            {addressText}
          </Text>
        </View>
      </View>

      {/* Footer Info & Actions */}
      <View style={styles.footer}>
        <View style={styles.paymentBadge}>
          <Ionicons
            name={order.paymentMethod === 'cod' ? 'cash-outline' : 'card-outline'}
            size={14}
            color={order.paymentMethod === 'cod' ? COLORS.secondary : COLORS.primary}
          />
          <Text
            style={[
              styles.paymentText,
              { color: order.paymentMethod === 'cod' ? COLORS.secondary : COLORS.primary },
            ]}
          >
            {order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Prepaid (Paid)'}
          </Text>
        </View>

        <TouchableOpacity style={styles.trackBtn} onPress={onTrackPress || onPress}>
          <Ionicons name="navigate-outline" size={14} color={COLORS.white} />
          <Text style={styles.trackBtnText}>Map & Actions</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.light,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  orderNumberWrap: {},
  orderNumber: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
  },
  itemCount: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
    fontWeight: '500',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  addressIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  addressContent: {
    flex: 1,
  },
  customerName: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  addressText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  paymentBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  paymentText: {
    fontSize: 12,
    fontWeight: '700',
  },
  trackBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    gap: 4,
  },
  trackBtnText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '700',
  },
});
