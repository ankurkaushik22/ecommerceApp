import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Platform,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

// Calculate distance between two coordinates in km using Haversine formula
function calculateDistance(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 2.4;
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

export default function DeliveryMapView({
  agentLocation = { latitude: 28.9845, longitude: 77.7064 },
  customerLocation = { latitude: 28.995, longitude: 77.718 },
  customerAddress = 'B-12, Green Park Avenue, Near Tech Hub',
  customerName = 'Customer',
  customerPhone = '+91 98765 43210',
  orderNumber = 'ORD-001',
  orderStatus = 'out_for_delivery',
  onSimulateMove = null,
  isLiveBroadcasting = false,
}) {
  const [pulse, setPulse] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulse((p) => !p);
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  const distanceKm = calculateDistance(
    agentLocation.latitude,
    agentLocation.longitude,
    customerLocation.latitude,
    customerLocation.longitude
  );

  // Estimate time: assuming average urban speed 25 km/h
  const etaMinutes = Math.max(3, Math.round((distanceKm / 25) * 60));

  const handleOpenNavigation = () => {
    const destLat = customerLocation.latitude || 28.995;
    const destLng = customerLocation.longitude || 77.718;
    const label = encodeURIComponent(customerAddress);
    
    let url = `https://www.google.com/maps/dir/?api=1&destination=${destLat},${destLng}&destination_place_id=${label}`;
    if (Platform.OS === 'ios') {
      url = `maps://?daddr=${destLat},${destLng}&q=${label}`;
    }
    Linking.openURL(url).catch(() => {
      Linking.openURL(`https://www.google.com/maps/search/?api=1&query=${destLat},${destLng}`);
    });
  };

  const handleCallCustomer = () => {
    if (customerPhone) {
      Linking.openURL(`tel:${customerPhone.replace(/[^0-9+]/g, '')}`);
    }
  };

  return (
    <View style={styles.container}>
      {/* Map Surface View */}
      <View style={styles.mapCanvas}>
        {/* Map Grid Pattern & Roads */}
        <View style={styles.roadHorizontal1} />
        <View style={styles.roadHorizontal2} />
        <View style={styles.roadVertical1} />
        <View style={styles.roadVertical2} />
        <View style={styles.roadDiagonal} />

        {/* Route Line Connecting Agent and Customer */}
        <View style={styles.routeContainer}>
          <View style={styles.routeDottedLine} />
        </View>

        {/* Agent Live Marker */}
        <View
          style={[
            styles.markerWrapper,
            styles.agentMarkerPos,
            pulse && styles.agentMarkerPulse,
          ]}
        >
          <View style={styles.agentMarker}>
            <Ionicons name="bicycle" size={20} color={COLORS.white} />
          </View>
          <View style={styles.markerBadge}>
            <Text style={styles.markerBadgeText}>You (Agent)</Text>
          </View>
        </View>

        {/* Customer Destination Marker */}
        <View style={[styles.markerWrapper, styles.customerMarkerPos]}>
          <View style={styles.customerMarker}>
            <Ionicons name="home" size={18} color={COLORS.white} />
          </View>
          <View style={[styles.markerBadge, styles.customerBadge]}>
            <Text style={styles.markerBadgeText}>{customerName}</Text>
          </View>
        </View>

        {/* Live Broadcast Pill */}
        <View style={styles.livePill}>
          <View
            style={[
              styles.liveDot,
              { backgroundColor: isLiveBroadcasting ? COLORS.success : COLORS.warning },
            ]}
          />
          <Text style={styles.liveText}>
            {isLiveBroadcasting ? 'GPS BROADCASTING LIVE' : 'GPS STANDBY'}
          </Text>
        </View>

        {/* Map Overlays (ETA & Distance) */}
        <View style={styles.etaCard}>
          <View style={styles.etaCol}>
            <Text style={styles.etaLabel}>ESTIMATED TIME</Text>
            <Text style={styles.etaValue}>{etaMinutes} mins</Text>
          </View>
          <View style={styles.etaDivider} />
          <View style={styles.etaCol}>
            <Text style={styles.etaLabel}>DISTANCE</Text>
            <Text style={styles.etaValue}>{distanceKm} km</Text>
          </View>
        </View>
      </View>

      {/* Destination & Action Bar */}
      <View style={styles.destinationCard}>
        <View style={styles.destinationHeader}>
          <View style={styles.destIconWrap}>
            <Ionicons name="location" size={22} color={COLORS.primary} />
          </View>
          <View style={styles.destTextWrap}>
            <Text style={styles.destTitle}>Delivery Destination</Text>
            <Text style={styles.destAddress} numberOfLines={2}>
              {customerAddress}
            </Text>
          </View>
        </View>

        {/* Quick Action Buttons */}
        <View style={styles.actionRow}>
          <TouchableOpacity style={styles.navButton} onPress={handleOpenNavigation}>
            <Ionicons name="navigate" size={18} color={COLORS.white} />
            <Text style={styles.navButtonText}>Start Navigation</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.callButton} onPress={handleCallCustomer}>
            <Ionicons name="call" size={18} color={COLORS.primary} />
            <Text style={styles.callButtonText}>Call Customer</Text>
          </TouchableOpacity>
        </View>

        {/* GPS Simulation Control */}
        {onSimulateMove && (
          <TouchableOpacity style={styles.simulateBtn} onPress={onSimulateMove}>
            <Ionicons name="speedometer-outline" size={16} color={COLORS.accent} />
            <Text style={styles.simulateBtnText}>Simulate 1-Step Driver Movement 📍</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: SIZES.radiusLarge,
    overflow: 'hidden',
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.medium,
    marginVertical: 12,
  },
  mapCanvas: {
    height: 240,
    backgroundColor: '#E5E7EB',
    position: 'relative',
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  roadHorizontal1: {
    position: 'absolute',
    top: 70,
    left: 0,
    right: 0,
    height: 16,
    backgroundColor: '#D1D5DB',
  },
  roadHorizontal2: {
    position: 'absolute',
    top: 160,
    left: 0,
    right: 0,
    height: 20,
    backgroundColor: '#D1D5DB',
  },
  roadVertical1: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 70,
    width: 16,
    backgroundColor: '#D1D5DB',
  },
  roadVertical2: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 90,
    width: 20,
    backgroundColor: '#D1D5DB',
  },
  roadDiagonal: {
    position: 'absolute',
    top: 40,
    bottom: 40,
    left: 60,
    right: 80,
    borderWidth: 3,
    borderColor: '#93C5FD',
    borderStyle: 'dashed',
    borderRadius: 8,
  },
  routeContainer: {
    position: 'absolute',
    top: 60,
    bottom: 70,
    left: 75,
    right: 95,
  },
  routeDottedLine: {
    flex: 1,
    borderWidth: 3,
    borderColor: COLORS.primary,
    borderStyle: 'solid',
    borderRadius: 12,
    opacity: 0.8,
  },
  markerWrapper: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
  },
  agentMarkerPos: {
    bottom: 50,
    left: 55,
  },
  customerMarkerPos: {
    top: 35,
    right: 70,
  },
  agentMarker: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: COLORS.white,
    ...SHADOWS.dark,
  },
  agentMarkerPulse: {
    transform: [{ scale: 1.08 }],
  },
  customerMarker: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: COLORS.secondary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: COLORS.white,
    ...SHADOWS.dark,
  },
  markerBadge: {
    backgroundColor: COLORS.surface,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
    marginTop: 4,
    ...SHADOWS.light,
  },
  customerBadge: {
    backgroundColor: '#1E293B',
  },
  markerBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.text,
  },
  livePill: {
    position: 'absolute',
    top: 12,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  liveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  liveText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  etaCard: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    ...SHADOWS.medium,
  },
  etaCol: {
    alignItems: 'center',
  },
  etaDivider: {
    width: 1,
    height: 24,
    backgroundColor: COLORS.border,
    marginHorizontal: 12,
  },
  etaLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
  etaValue: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.primary,
    marginTop: 1,
  },
  destinationCard: {
    padding: 16,
    backgroundColor: COLORS.surface,
  },
  destinationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 14,
  },
  destIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  destTextWrap: {
    flex: 1,
  },
  destTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.textSecondary,
    textTransform: 'uppercase',
  },
  destAddress: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 2,
    lineHeight: 20,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  navButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: SIZES.radius,
    gap: 6,
    ...SHADOWS.light,
  },
  navButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontWeight: '700',
  },
  callButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primaryLight,
    paddingVertical: 12,
    borderRadius: SIZES.radius,
    gap: 6,
    borderWidth: 1,
    borderColor: '#A7F3D0',
  },
  callButtonText: {
    color: COLORS.primaryDark,
    fontSize: 14,
    fontWeight: '700',
  },
  simulateBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: COLORS.accentLight,
    borderWidth: 1,
    borderColor: '#BFDBFE',
    gap: 6,
  },
  simulateBtnText: {
    color: COLORS.accent,
    fontSize: 12,
    fontWeight: '700',
  },
});
