# ShopZone Delivery Partner App (React Native + Expo)

A cross-platform delivery executive application for Android, iOS, and Web. Includes live GPS broadcasting, turn-by-turn interactive map navigation, customer address display, order status workflow transitions, and daily earnings tracking.

---

## 🚀 Features

1. **1-Tap Demo Login**:
   - Credentials: `delivery@shopzone.com` / `123456`
2. **Duty Toggle & Real-Time Tracking**:
   - On/Off duty status toggle with instant backend updates.
   - Continuous GPS coordinate broadcasting to GraphQL server (`updateDeliveryLocation`).
3. **Interactive Route Map & Navigation**:
   - Visual map showing delivery agent location and customer destination address pin.
   - 1-Tap turn-by-turn navigation via Google Maps / Apple Maps.
   - 1-Tap direct phone dialer for customer communication.
   - Built-in GPS simulator to test movements without physical travel.
4. **Order Status Workflow**:
   - `Accept & Pick Up` ➔ `Out for Delivery` ➔ `Mark as Delivered`.
5. **Earnings & Metric Dashboards**:
   - Active orders, completed deliveries, Cash on Delivery (COD) collection tally, and daily payout in **₹ INR**.

---

## 📱 How to Run

```bash
cd delivery-mobile
npm start
```

- Press `w` to open in browser (`http://localhost:8081`).
- Press `a` to run on connected Android emulator or scan QR code in **Expo Go**.
