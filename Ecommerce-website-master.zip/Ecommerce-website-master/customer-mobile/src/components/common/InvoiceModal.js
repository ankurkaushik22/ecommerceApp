import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Share,
  Linking,
  Vibration,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { format } from 'date-fns';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function InvoiceModal({ visible, onClose, order }) {
  const [sharingPdf, setSharingPdf] = useState(false);

  if (!order) return null;

  const invoiceNo = order.invoiceNumber || `INV-${order.orderNumber}`;
  const invoiceDate = order.createdAt
    ? format(new Date(order.createdAt), 'dd MMMM yyyy')
    : 'N/A';

  const subtotal = Number(order.subtotal || 0);
  const discount = Number(order.discount || 0);
  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = Number(order.tax || 0);
  const cgst = Number((tax / 2).toFixed(2));
  const sgst = Number((tax / 2).toFixed(2));
  const shippingCost = Number(order.shippingCost || 0);
  const total = Number(order.total || 0);

  const generateInvoiceHtml = () => {
    const itemsHtml = (order.items || [])
      .map(
        (it, idx) => `
        <tr>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: center;">${idx + 1}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; font-weight: 600; color: #0f172a;">
            ${it.name} ${it.variantLabel ? `<br/><span style="font-size: 11px; color: #64748b; font-weight: normal;">(${it.variantLabel})</span>` : ''}
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: center; color: #475569;">${it.quantity}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: right; color: #475569;">₹${Number(it.price).toLocaleString('en-IN')}</td>
          <td style="padding: 10px; border-bottom: 1px solid #e2e8f0; text-align: right; font-weight: 700; color: #0f172a;">₹${(Number(it.price) * Number(it.quantity)).toLocaleString('en-IN')}</td>
        </tr>
      `
      )
      .join('');

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Tax Invoice - ${invoiceNo}</title>
          <style>
            body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; color: #1e293b; padding: 32px; margin: 0; background: #ffffff; }
            .header-bar { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 3px solid #ea580c; padding-bottom: 16px; margin-bottom: 20px; }
            .brand-name { font-size: 26px; font-weight: 800; color: #ea580c; letter-spacing: -0.5px; }
            .company-info { font-size: 11px; color: #64748b; margin-top: 4px; line-height: 1.5; }
            .invoice-badge { background: #fff7ed; color: #c2410c; border: 1px solid #fed7aa; padding: 6px 12px; border-radius: 6px; font-size: 11px; font-weight: 800; letter-spacing: 0.5px; text-transform: uppercase; }
            .meta-grid { display: flex; justify-content: space-between; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 18px; margin-bottom: 24px; }
            .meta-col label { color: #64748b; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 3px; }
            .meta-col span { font-size: 13px; font-weight: 700; color: #0f172a; }
            .bill-section { background: #fdfbf7; border: 1px solid #fef3c7; border-radius: 8px; padding: 14px 18px; margin-bottom: 24px; }
            .bill-title { font-size: 11px; font-weight: 800; color: #d97706; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
            .customer-name { font-size: 15px; font-weight: 700; color: #0f172a; }
            .customer-details { font-size: 12px; color: #475569; margin-top: 4px; line-height: 1.6; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 12px; }
            th { background: #f1f5f9; color: #475569; padding: 10px; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; text-align: left; }
            .summary-box { width: 320px; margin-left: auto; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 18px; }
            .summary-row { display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px; color: #475569; }
            .total-row { display: flex; justify-content: space-between; font-size: 16px; font-weight: 800; color: #ea580c; border-top: 2px dashed #cbd5e1; padding-top: 10px; margin-top: 8px; }
            .footer-note { text-align: center; margin-top: 36px; font-size: 10px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 16px; }
          </style>
        </head>
        <body>
          <div class="header-bar">
            <div>
              <div class="brand-name">Suaaka E-Commerce</div>
              <div class="company-info">
                Plot 42, Tech City, Meerut, UP - 250001<br/>
                GSTIN: 09AAACH7409R1ZZ | PAN: AAACH7409R
              </div>
            </div>
            <div>
              <span class="invoice-badge">ORIGINAL TAX INVOICE</span>
            </div>
          </div>

          <div class="meta-grid">
            <div class="meta-col">
              <label>Invoice Number</label>
              <span>${invoiceNo}</span>
            </div>
            <div class="meta-col">
              <label>Order Reference</label>
              <span>#${order.orderNumber}</span>
            </div>
            <div class="meta-col">
              <label>Invoice Date</label>
              <span>${invoiceDate}</span>
            </div>
          </div>

          <div class="bill-section">
            <div class="bill-title">Billed & Shipped To</div>
            <div class="customer-name">${order.shippingAddress?.fullName || 'Valued Customer'}</div>
            <div class="customer-details">
              ${order.shippingAddress?.addressLine1 || ''}${order.shippingAddress?.addressLine2 ? ', ' + order.shippingAddress.addressLine2 : ''}<br/>
              ${order.shippingAddress?.city || ''}, ${order.shippingAddress?.state || ''} - ${order.shippingAddress?.postalCode || ''}<br/>
              Phone: ${order.shippingAddress?.phone || 'N/A'}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 36px; text-align: center;">#</th>
                <th>Item Description</th>
                <th style="width: 50px; text-align: center;">Qty</th>
                <th style="width: 100px; text-align: right;">Unit Price</th>
                <th style="width: 110px; text-align: right;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>

          <div class="summary-box">
            <div class="summary-row">
              <span>Taxable Amount</span>
              <span>₹${taxableAmount.toLocaleString('en-IN')}</span>
            </div>
            <div class="summary-row">
              <span>CGST (9%)</span>
              <span>₹${cgst.toLocaleString('en-IN')}</span>
            </div>
            <div class="summary-row">
              <span>SGST (9%)</span>
              <span>₹${sgst.toLocaleString('en-IN')}</span>
            </div>
            <div class="summary-row">
              <span>Shipping Charges</span>
              <span>${shippingCost === 0 ? 'FREE' : '₹' + shippingCost.toLocaleString('en-IN')}</span>
            </div>
            <div class="total-row">
              <span>Grand Total</span>
              <span>₹${total.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div class="footer-note">
            This is a computer-generated tax invoice issued by Suaaka E-Commerce and does not require a physical signature.
          </div>
        </body>
      </html>
    `;
  };

  const getInvoiceText = () => {
    const itemsList = (order.items || [])
      .map(
        (it, idx) =>
          `${idx + 1}. ${it.name} (Qty: ${it.quantity}) = ₹${(
            Number(it.price) * Number(it.quantity)
          ).toLocaleString('en-IN')}`
      )
      .join('\n');

    return `*SUAAKA TAX INVOICE*
-----------------------------
*Invoice No:* ${invoiceNo}
*Date:* ${invoiceDate}
*Order Ref:* #${order.orderNumber}

*Seller:* Suaaka E-Commerce
*GSTIN:* 09AAACH7409R1ZZ | *PAN:* AAACH7409R
Plot 42, Tech City, Meerut, UP - 250001

*Billed & Shipped To:*
${order.shippingAddress?.fullName || 'Valued Customer'}
${order.shippingAddress?.addressLine1 || ''} ${order.shippingAddress?.addressLine2 || ''}
${order.shippingAddress?.city || ''}, ${order.shippingAddress?.state || ''} - ${order.shippingAddress?.postalCode || ''}
Phone: ${order.shippingAddress?.phone || 'N/A'}

*Particulars / Items:*
${itemsList}

-----------------------------
*Taxable Amount:* ₹${taxableAmount.toLocaleString('en-IN')}
*CGST (9%):* ₹${cgst.toLocaleString('en-IN')}
*SGST (9%):* ₹${sgst.toLocaleString('en-IN')}
*Shipping Charges:* ${shippingCost === 0 ? 'FREE' : '₹' + shippingCost.toLocaleString('en-IN')}
*Grand Total (INR):* ₹${total.toLocaleString('en-IN')}
-----------------------------
_Computer-generated tax invoice from Suaaka E-Commerce._`;
  };

  const handleShareInvoice = async () => {
    Vibration.vibrate(60);
    setSharingPdf(true);
    try {
      const html = generateInvoiceHtml();
      const { uri } = await Print.printToFileAsync({ html });
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/pdf',
          dialogTitle: `Tax Invoice - ${invoiceNo}`,
          UTI: 'com.adobe.pdf',
        });
      } else {
        await Share.share({
          title: `Tax Invoice - ${invoiceNo}`,
          message: getInvoiceText(),
        });
      }
    } catch (error) {
      console.log('PDF generation/share error:', error.message);
      await Share.share({
        title: `Tax Invoice - ${invoiceNo}`,
        message: getInvoiceText(),
      });
    } finally {
      setSharingPdf(false);
    }
  };

  const handleEmailInvoice = async () => {
    Vibration.vibrate(60);
    handleShareInvoice();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.container}>
          {/* Top Header Bar */}
          <View style={styles.topBar}>
            <View style={styles.titleRow}>
              <Ionicons name="receipt-outline" size={20} color={COLORS.primary} style={{ marginRight: 8 }} />
              <Text style={styles.modalTitle}>Tax Invoice</Text>
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <TouchableOpacity
                onPress={handleShareInvoice}
                style={styles.shareIconBtn}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <Ionicons name="share-social-outline" size={19} color={COLORS.primary} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={onClose}
                style={styles.closeBtn}
                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
              >
                <Ionicons name="close" size={22} color={COLORS.text} />
              </TouchableOpacity>
            </View>
          </View>

          <ScrollView
            showsVerticalScrollIndicator={true}
            contentContainerStyle={styles.scrollContent}
            bounces={false}
          >
            {/* Header: Company Name & Badge */}
            <View style={styles.brandRow}>
              <View style={{ flex: 1, paddingRight: 8 }}>
                <Text style={styles.brandTitle}>Suaaka E-Commerce</Text>
                <Text style={styles.companySub}>Plot 42, Tech City, Meerut, UP - 250001</Text>
                <Text style={styles.companySub}>GSTIN: 09AAACH7409R1ZZ</Text>
                <Text style={styles.companySub}>PAN: AAACH7409R</Text>
              </View>
              <View style={styles.badgeContainer}>
                <Text style={styles.invoiceBadge}>ORIGINAL</Text>
              </View>
            </View>

            {/* Invoice Meta Box */}
            <View style={styles.metaCard}>
              <View style={styles.metaCol}>
                <Text style={styles.metaLabel}>Invoice No:</Text>
                <Text style={styles.metaNumber} numberOfLines={1} adjustsFontSizeToFit>
                  {invoiceNo}
                </Text>
              </View>
              <View style={[styles.metaCol, { alignItems: 'flex-end' }]}>
                <Text style={styles.metaLabel}>Date:</Text>
                <Text style={styles.metaDate}>{invoiceDate}</Text>
              </View>
            </View>

            <View style={styles.divider} />

            {/* Bill To */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>Billed & Shipped To:</Text>
              <Text style={styles.customerName}>{order.shippingAddress?.fullName || 'Valued Customer'}</Text>
              <Text style={styles.addressLine}>
                {order.shippingAddress?.addressLine1}
                {order.shippingAddress?.addressLine2 ? `, ${order.shippingAddress.addressLine2}` : ''}
              </Text>
              <Text style={styles.addressLine}>
                {order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}
              </Text>
              {order.shippingAddress?.phone ? (
                <Text style={styles.addressLine}>Phone: {order.shippingAddress.phone}</Text>
              ) : null}
            </View>

            <View style={styles.divider} />

            {/* Items Table */}
            <View style={styles.section}>
              <Text style={styles.sectionHeader}>Particulars / Items</Text>
              <View style={styles.tableHeader}>
                <Text style={[styles.colHeader, { flex: 2.2 }]}>Item</Text>
                <Text style={[styles.colHeader, { flex: 0.6, textAlign: 'center' }]}>Qty</Text>
                <Text style={[styles.colHeader, { flex: 1.1, textAlign: 'right' }]}>Price</Text>
                <Text style={[styles.colHeader, { flex: 1.1, textAlign: 'right' }]}>Amount</Text>
              </View>

              {order.items?.map((item, idx) => (
                <View key={idx} style={styles.tableRow}>
                  <Text style={[styles.cellText, { flex: 2.2 }]} numberOfLines={2}>
                    {item.name}
                  </Text>
                  <Text style={[styles.cellText, { flex: 0.6, textAlign: 'center', color: COLORS.textSecondary }]}>
                    {item.quantity}
                  </Text>
                  <Text style={[styles.cellText, { flex: 1.1, textAlign: 'right' }]}>
                    ₹{Number(item.price).toLocaleString('en-IN')}
                  </Text>
                  <Text style={[styles.cellText, styles.boldCell, { flex: 1.1, textAlign: 'right' }]}>
                    ₹{(Number(item.price) * Number(item.quantity)).toLocaleString('en-IN')}
                  </Text>
                </View>
              ))}
            </View>

            <View style={styles.divider} />

            {/* GST & Total Summary */}
            <View style={styles.summaryBox}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Taxable Amount</Text>
                <Text style={styles.summaryVal}>₹{taxableAmount.toLocaleString('en-IN')}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>CGST (9%)</Text>
                <Text style={styles.summaryVal}>₹{cgst.toLocaleString('en-IN')}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>SGST (9%)</Text>
                <Text style={styles.summaryVal}>₹{sgst.toLocaleString('en-IN')}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Shipping Charges</Text>
                <Text style={styles.summaryVal}>
                  {shippingCost === 0 ? 'FREE' : `₹${shippingCost.toLocaleString('en-IN')}`}
                </Text>
              </View>

              <View style={[styles.divider, { marginVertical: 8, backgroundColor: COLORS.border }]} />

              <View style={styles.summaryRow}>
                <Text style={styles.totalLabel}>Grand Total (INR)</Text>
                <Text style={styles.totalVal}>₹{total.toLocaleString('en-IN')}</Text>
              </View>
            </View>

            {/* Action Buttons: Share & Email */}
            <View style={styles.actionRow}>
              <TouchableOpacity
                style={[styles.shareActionBtn, sharingPdf && { opacity: 0.7 }]}
                activeOpacity={0.88}
                onPress={handleShareInvoice}
                disabled={sharingPdf}
              >
                {sharingPdf ? (
                  <ActivityIndicator size="small" color={COLORS.white} style={{ marginRight: 6 }} />
                ) : (
                  <Ionicons name="document-text-outline" size={17} color={COLORS.white} style={{ marginRight: 6 }} />
                )}
                <Text style={styles.shareActionText}>
                  {sharingPdf ? 'Generating PDF...' : 'Share PDF Invoice'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.emailActionBtn}
                activeOpacity={0.88}
                onPress={handleEmailInvoice}
                disabled={sharingPdf}
              >
                <Ionicons name="share-social-outline" size={17} color={COLORS.primary} style={{ marginRight: 6 }} />
                <Text style={styles.emailActionText}>Share Options</Text>
              </TouchableOpacity>
            </View>

            {/* Computer Generated Notice */}
            <Text style={styles.footerNotice}>
              This is a computer-generated tax invoice and requires no physical signature.
            </Text>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  container: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusLg,
    width: '100%',
    maxHeight: '90%',
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    backgroundColor: COLORS.white,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  closeBtn: {
    padding: 4,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 28,
  },
  brandRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  brandTitle: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.primary,
    marginBottom: 2,
  },
  companySub: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 1,
    lineHeight: 14,
  },
  badgeContainer: {
    alignItems: 'flex-end',
  },
  invoiceBadge: {
    backgroundColor: COLORS.primaryLight,
    color: COLORS.primaryDark,
    fontSize: 9,
    fontWeight: '800',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
    overflow: 'hidden',
    letterSpacing: 0.5,
  },
  metaCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    marginTop: 6,
  },
  metaCol: {
    flex: 1,
  },
  metaLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.textMuted,
    textTransform: 'uppercase',
    marginBottom: 1,
  },
  metaNumber: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.text,
  },
  metaDate: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 10,
  },
  section: {
    marginBottom: 4,
  },
  sectionHeader: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  customerName: {
    fontSize: SIZES.sm,
    fontWeight: '700',
    color: COLORS.text,
  },
  addressLine: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
    lineHeight: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: SIZES.radiusSm,
    marginTop: 4,
  },
  colHeader: {
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  tableRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  cellText: {
    fontSize: 11,
    color: COLORS.text,
  },
  boldCell: {
    fontWeight: '700',
    color: COLORS.text,
  },
  summaryBox: {
    backgroundColor: COLORS.background,
    padding: 12,
    borderRadius: SIZES.radiusMd,
    marginTop: 2,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 2.5,
  },
  summaryLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  summaryVal: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.text,
  },
  totalLabel: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  totalVal: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.primary,
  },
  footerNotice: {
    fontSize: 9,
    color: COLORS.textMuted,
    textAlign: 'center',
    marginTop: 14,
    marginBottom: 4,
    lineHeight: 13,
  },
  shareIconBtn: {
    padding: 6,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primaryLight,
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 12,
  },
  shareActionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 10,
    borderRadius: SIZES.radiusSm,
    ...SHADOWS.small,
  },
  shareActionText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.white,
  },
  emailActionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primaryLight,
    borderWidth: 1,
    borderColor: COLORS.primary,
    paddingVertical: 10,
    borderRadius: SIZES.radiusSm,
  },
  emailActionText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
});
