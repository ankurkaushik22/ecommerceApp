import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMutation } from '@apollo/client';
import { ADD_REVIEW } from '../../graphql/mutations';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function ReviewModal({
  visible,
  onClose,
  order,
  onReviewSubmitted,
}) {
  const [targetType, setTargetType] = useState('product'); // 'product' | 'seller' | 'delivery'
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [selectedProductId, setSelectedProductId] = useState(
    order?.items?.[0]?.product?._id || ''
  );

  const [addReview, { loading }] = useMutation(ADD_REVIEW, {
    onCompleted: () => {
      Alert.alert('Thank you!', 'Your review has been submitted successfully.');
      setTitle('');
      setComment('');
      setRating(5);
      if (onReviewSubmitted) onReviewSubmitted();
      onClose();
    },
    onError: (err) => {
      Alert.alert('Review Error', err.message);
    },
  });

  const handleSubmit = () => {
    if (!comment.trim()) {
      Alert.alert('Required', 'Please write your feedback comment.');
      return;
    }

    const input = {
      targetType,
      orderId: order?._id,
      rating,
      title:
        title.trim() ||
        `${targetType === 'product' ? 'Product' : targetType === 'seller' ? 'Seller' : 'Delivery'} Feedback`,
      comment: comment.trim(),
    };

    if (targetType === 'product') {
      input.productId = selectedProductId || order?.items?.[0]?.product?._id;
    }

    addReview({ variables: { input } });
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.modalContent}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Rate & Review</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Ionicons name="close" size={22} color={COLORS.textSecondary} />
            </TouchableOpacity>
          </View>

          {/* Target Tabs */}
          <View style={styles.tabBar}>
            {[
              { key: 'product', label: '🛍️ Product' },
              { key: 'seller', label: '🏬 Seller' },
              { key: 'delivery', label: '🚚 Delivery' },
            ].map((tab) => (
              <TouchableOpacity
                key={tab.key}
                style={[
                  styles.tabItem,
                  targetType === tab.key && styles.tabItemActive,
                ]}
                onPress={() => setTargetType(tab.key)}
              >
                <Text
                  style={[
                    styles.tabText,
                    targetType === tab.key && styles.tabTextActive,
                  ]}
                >
                  {tab.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Stars */}
          <View style={styles.starsRow}>
            {[1, 2, 3, 4, 5].map((star) => (
              <TouchableOpacity
                key={star}
                onPress={() => setRating(star)}
                style={styles.starButton}
              >
                <Ionicons
                  name={star <= rating ? 'star' : 'star-outline'}
                  size={32}
                  color={star <= rating ? COLORS.star : COLORS.border}
                />
              </TouchableOpacity>
            ))}
          </View>

          {/* Title Input */}
          <Text style={styles.inputLabel}>Review Title</Text>
          <TextInput
            style={styles.input}
            placeholder="e.g. Excellent quality, fast dispatch"
            placeholderTextColor={COLORS.textMuted}
            value={title}
            onChangeText={setTitle}
          />

          {/* Comment Input */}
          <Text style={styles.inputLabel}>Detailed Feedback *</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Share details about your experience with this item or service..."
            placeholderTextColor={COLORS.textMuted}
            multiline
            numberOfLines={4}
            value={comment}
            onChangeText={setComment}
          />

          {/* Submit Button */}
          <TouchableOpacity
            style={[styles.submitButton, loading && styles.submitButtonDisabled]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color={COLORS.white} />
            ) : (
              <Text style={styles.submitButtonText}>Submit Review</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: SIZES.radiusLg,
    borderTopRightRadius: SIZES.radiusLg,
    padding: SIZES.padding * 1.2,
    ...SHADOWS.medium,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusSm,
    padding: 3,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: SIZES.radiusSm - 2,
  },
  tabItemActive: {
    backgroundColor: COLORS.white,
    ...SHADOWS.small,
  },
  tabText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  tabTextActive: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  starsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginVertical: 12,
  },
  starButton: {
    padding: 4,
  },
  inputLabel: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 10,
    marginBottom: 4,
  },
  input: {
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: SIZES.sm,
    color: COLORS.text,
  },
  textArea: {
    height: 90,
    textAlignVertical: 'top',
  },
  submitButton: {
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusSm,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
    ...SHADOWS.glow,
  },
  submitButtonDisabled: {
    opacity: 0.7,
  },
  submitButtonText: {
    color: COLORS.white,
    fontSize: SIZES.md,
    fontWeight: '700',
  },
});
