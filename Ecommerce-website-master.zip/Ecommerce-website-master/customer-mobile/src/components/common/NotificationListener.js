import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_NOTIFICATIONS, GET_CART } from '../../graphql/queries';
import { UPDATE_PUSH_TOKEN, MARK_NOTIFICATION_READ } from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import { useCartStore } from '../../store/cartStore';

// Helper to clean underscores and format text into readable title format
const formatReadableText = (text) => {
  if (!text || typeof text !== 'string') return text || '';
  let cleaned = text.replace(/_/g, ' ');
  return cleaned.replace(/\b[A-Z]{2,}\b/g, (match) => 
    match.charAt(0) + match.slice(1).toLowerCase()
  );
};

// Safe attempt to register Expo Push Notifications
async function registerForPushNotificationsAsync() {
  if (Platform.OS === 'web') return null;
  try {
    const Notifications = require('expo-notifications');
    if (!Notifications || !Notifications.getPermissionsAsync) return null;

    try {
      Notifications.setNotificationHandler({
        handleNotification: async () => ({
          shouldShowAlert: false, // Suppress system status bar popup when app is open
          shouldPlaySound: true,
          shouldSetBadge: true,
        }),
      });
    } catch (e) {}

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'default',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: '#FF6B00',
        sound: 'default',
      });
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== 'granted') {
      return null;
    }

    const tokenData = await Notifications.getExpoPushTokenAsync().catch(() => null);
    return tokenData?.data || null;
  } catch (err) {
    console.log('Push notification registration bypassed:', err.message);
    return null;
  }
}

export default function NotificationListener({ navigation }) {
  const insets = useSafeAreaInsets();
  const user = useAuthStore((s) => s.user);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const [updatePushToken] = useMutation(UPDATE_PUSH_TOKEN);
  const [markRead] = useMutation(MARK_NOTIFICATION_READ);

  const [activeBanner, setActiveBanner] = useState(null);
  const slideAnim = useRef(new Animated.Value(-160)).current;
  const lastSeenIdRef = useRef(null);
  const registeredTokenRef = useRef(null);

  // 1. Register Push Token when logged in
  useEffect(() => {
    if (isAuthenticated && user) {
      registerForPushNotificationsAsync().then((token) => {
        if (token && token !== registeredTokenRef.current) {
          registeredTokenRef.current = token;
          updatePushToken({ variables: { token } }).catch(() => {});
        }
      });
    }
  }, [isAuthenticated, user]);

  const setCart = useCartStore((s) => s.setCart);
  const restoreCartFromStorage = useCartStore((s) => s.restoreCartFromStorage);

  useEffect(() => {
    restoreCartFromStorage();
  }, [restoreCartFromStorage]);

  const { data: cartData } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    pollInterval: 10000,
    fetchPolicy: 'cache-and-network',
  });

  useEffect(() => {
    if (cartData?.getCart) {
      setCart(cartData.getCart);
    }
  }, [cartData, setCart]);

  // 2. Poll Notifications for In-App Live Toasts
  const { data } = useQuery(GET_NOTIFICATIONS, {
    skip: !isAuthenticated,
    pollInterval: 8000, // Check for new notifications every 8s
    fetchPolicy: 'network-only',
  });

  useEffect(() => {
    if (!data?.getNotifications || data.getNotifications.length === 0) return;

    const latest = data.getNotifications[0];
    if (!latest) return;

    if (!latest.isRead && lastSeenIdRef.current && latest._id !== lastSeenIdRef.current) {
      showInAppToast(latest);
    }
    lastSeenIdRef.current = latest._id;
  }, [data]);

  const showInAppToast = (notif) => {
    // Only show custom in-app animated toast banner when app is open
    setActiveBanner(notif);
    Animated.spring(slideAnim, {
      toValue: 0,
      useNativeDriver: true,
      friction: 8,
      tension: 40,
    }).start();

    setTimeout(() => {
      dismissToast();
    }, 5000);
  };

  const dismissToast = () => {
    Animated.timing(slideAnim, {
      toValue: -160,
      duration: 250,
      useNativeDriver: true,
    }).start(() => {
      setActiveBanner(null);
    });
  };

  const handleBannerPress = () => {
    if (!activeBanner) return;
    const notif = activeBanner;
    dismissToast();
    if (notif._id) {
      markRead({ variables: { id: notif._id } }).catch(() => {});
    }
    if (navigation) {
      navigation.navigate('Notifications');
    }
  };

  if (!activeBanner) return null;

  const safeTop = Math.max(insets.top, 16) + 8;

  return (
    <Animated.View style={[styles.container, { top: safeTop, transform: [{ translateY: slideAnim }] }]}>
      <TouchableOpacity
        activeOpacity={0.9}
        style={styles.banner}
        onPress={handleBannerPress}
      >
        <View style={styles.iconBox}>
          <Ionicons name="notifications-sharp" size={20} color="#FFFFFF" />
        </View>

        <View style={styles.content}>
          <Text style={styles.title} numberOfLines={1}>
            {formatReadableText(activeBanner.title || 'New Notification')}
          </Text>
          <Text style={styles.message} numberOfLines={2}>
            {formatReadableText(activeBanner.message || activeBanner.content || '')}
          </Text>
        </View>

        <TouchableOpacity style={styles.closeBtn} onPress={dismissToast} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Ionicons name="close" size={18} color="#9CA3AF" />
        </TouchableOpacity>
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 999999,
    elevation: 999999,
  },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1E293B',
    borderRadius: 16,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.15)',
  },
  iconBox: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FF6B00',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  content: {
    flex: 1,
    marginRight: 8,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  message: {
    fontSize: 12,
    color: '#E2E8F0',
    lineHeight: 16,
  },
  closeBtn: {
    padding: 6,
  },
});
