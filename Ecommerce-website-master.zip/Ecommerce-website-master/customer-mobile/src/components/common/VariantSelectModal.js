import React, { useState, useEffect } from "react";
import {
  Modal,
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions,
  Vibration,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { COLORS, SIZES, SHADOWS } from "../../constants/theme";

export default function VariantSelectModal({ visible, onClose, product, onConfirmAddToCart }) {
  const navigation = useNavigation();
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);

  useEffect(() => {
    if (visible) {
      setSelectedVariantIndex(0);
    }
  }, [visible, product]);

  if (!product) return null;

  const rawVariants = product.variants?.[0]?.options || product.variants || [];
  const variantGroupName = product.variants?.[0]?.name || "Option";
  const selectedOption = rawVariants[selectedVariantIndex] || {};

  const currentPrice = Number(selectedOption.price ?? product.price ?? 0);
  const comparePrice = Number(product.comparePrice ?? 0);
  const discountPercent =
    comparePrice > currentPrice
      ? Math.round(((comparePrice - currentPrice) / comparePrice) * 100)
      : (product.discount || product.dealDiscount || 0);

  const imageUrl =
    product.images?.[0] ||
    "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400";

  const handleAdd = () => {
    Vibration.vibrate(75);
    if (onConfirmAddToCart) {
      onConfirmAddToCart(product, selectedVariantIndex);
    }
    onClose();
  };

  const handleViewDetails = () => {
    onClose();
    navigation.navigate("ProductDetail", { slug: product.slug, id: product._id });
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.overlay}>
        <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={onClose} />

        <View style={styles.sheetContainer}>
          {/* Header Row */}
          <View style={styles.header}>
            <Image source={{ uri: imageUrl }} style={styles.thumbImage} resizeMode="cover" />

            <View style={styles.headerInfo}>
              <Text style={styles.productTitle} numberOfLines={2}>
                {product.name}
              </Text>
              {selectedOption.label ? (
                <Text style={styles.selectedVariantSubtitle}>
                  {variantGroupName}: <Text style={styles.boldText}>{selectedOption.label}</Text>
                </Text>
              ) : null}
              <TouchableOpacity onPress={handleViewDetails} style={styles.detailsLink}>
                <Text style={styles.detailsLinkText}>See all item details</Text>
                <Ionicons name="chevron-forward" size={12} color="#2563EB" />
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={onClose} style={styles.closeBtn} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <Ionicons name="close" size={22} color={COLORS.text} />
            </TouchableOpacity>
          </View>

          <View style={styles.divider} />

          {/* Variant Selector Chips */}
          {rawVariants.length > 0 ? (
            <View style={styles.optionsSection}>
              <Text style={styles.sectionLabel}>
                {variantGroupName}: <Text style={styles.boldLabel}>{selectedOption.label || ("Option " + (selectedVariantIndex + 1))}</Text>
              </Text>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.chipsScroll}
              >
                {rawVariants.map((opt, idx) => {
                  const isSelected = selectedVariantIndex === idx;
                  const isOutOfStock = opt.stock !== undefined && opt.stock <= 0;

                  return (
                    <TouchableOpacity
                      key={idx}
                      style={[
                        styles.chip,
                        isSelected && styles.chipSelected,
                        isOutOfStock && styles.chipOutOfStock,
                      ]}
                      onPress={() => {
                        Vibration.vibrate(30);
                        setSelectedVariantIndex(idx);
                      }}
                      disabled={isOutOfStock}
                    >
                      <Text
                        style={[
                          styles.chipText,
                          isSelected && styles.chipTextSelected,
                          isOutOfStock && styles.chipTextOutOfStock,
                        ]}
                      >
                        {opt.label || opt.name || ("Option " + (idx + 1))}
                      </Text>
                      {opt.price && opt.price !== product.price ? (
                        <Text style={[styles.chipPrice, isSelected && styles.chipPriceSelected]}>
                          ?{Number(opt.price).toLocaleString("en-IN")}
                        </Text>
                      ) : null}
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          ) : null}

          {/* Pricing & Delivery Info */}
          <View style={styles.priceSection}>
            <View style={styles.priceRow}>
              <Text style={styles.currencySymbol}>?</Text>
              <Text style={styles.mainPrice}>{currentPrice.toLocaleString("en-IN")}</Text>

              {comparePrice > currentPrice ? (
                <View style={styles.compareWrapper}>
                  <Text style={styles.mrpText}>
                    M.R.P.: <Text style={styles.strikethrough}>?{comparePrice.toLocaleString("en-IN")}</Text>
                  </Text>
                  <Text style={styles.discountText}>({discountPercent}% off)</Text>
                </View>
              ) : null}
            </View>

            {/* Delivery badge */}
            <View style={styles.deliveryRow}>
              <Ionicons name="checkmark-circle" size={15} color={COLORS.success} />
              <Text style={styles.deliveryText}>
                {selectedOption.stock !== undefined && selectedOption.stock <= 3 && selectedOption.stock > 0
                  ? ("Only " + selectedOption.stock + " left in stock - order soon")
                  : "In Stock • Fast Delivery Available"}
              </Text>
            </View>
          </View>

          {/* Add to Cart Button */}
          <TouchableOpacity
            style={styles.addCartBtn}
            activeOpacity={0.88}
            onPress={handleAdd}
          >
            <Ionicons name="cart-outline" size={20} color={COLORS.white} style={{ marginRight: 8 }} />
            <Text style={styles.addCartBtnText}>Add to cart</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "flex-end",
  },
  backdrop: {
    flex: 1,
  },
  sheetContainer: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: SIZES.padding,
    paddingTop: 16,
    paddingBottom: 28,
    ...SHADOWS.medium,
  },
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  thumbImage: {
    width: 64,
    height: 64,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
  },
  headerInfo: {
    flex: 1,
    marginLeft: 12,
    paddingRight: 8,
  },
  productTitle: {
    fontSize: SIZES.sm,
    fontWeight: "700",
    color: COLORS.text,
    lineHeight: 18,
  },
  selectedVariantSubtitle: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  boldText: {
    fontWeight: "700",
    color: COLORS.text,
  },
  detailsLink: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  detailsLinkText: {
    fontSize: 11,
    fontWeight: "600",
    color: "#2563EB",
    marginRight: 2,
  },
  closeBtn: {
    padding: 4,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.background,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 12,
  },
  optionsSection: {
    marginBottom: 12,
  },
  sectionLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginBottom: 8,
  },
  boldLabel: {
    fontWeight: "700",
    color: COLORS.text,
  },
  chipsScroll: {
    gap: 8,
    paddingVertical: 2,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    backgroundColor: COLORS.background,
    alignItems: "center",
    justifyContent: "center",
  },
  chipSelected: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  chipOutOfStock: {
    opacity: 0.4,
    borderColor: COLORS.borderLight,
  },
  chipText: {
    fontSize: 12,
    fontWeight: "600",
    color: COLORS.text,
  },
  chipTextSelected: {
    fontWeight: "800",
    color: COLORS.primaryDark,
  },
  chipTextOutOfStock: {
    textDecorationLine: "line-through",
    color: COLORS.textMuted,
  },
  chipPrice: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  chipPriceSelected: {
    color: COLORS.primaryDark,
    fontWeight: "700",
  },
  priceSection: {
    marginVertical: 8,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "baseline",
  },
  currencySymbol: {
    fontSize: SIZES.md,
    fontWeight: "700",
    color: COLORS.text,
    marginRight: 1,
  },
  mainPrice: {
    fontSize: 22,
    fontWeight: "800",
    color: COLORS.text,
  },
  compareWrapper: {
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 8,
  },
  mrpText: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  strikethrough: {
    textDecorationLine: "line-through",
  },
  discountText: {
    fontSize: 11,
    fontWeight: "700",
    color: COLORS.primary,
    marginLeft: 4,
  },
  deliveryRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
    gap: 4,
  },
  deliveryText: {
    fontSize: 11,
    fontWeight: "600",
    color: COLORS.textSecondary,
  },
  addCartBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: SIZES.radiusFull,
    marginTop: 12,
    ...SHADOWS.small,
  },
  addCartBtnText: {
    fontSize: SIZES.md,
    fontWeight: "800",
    color: COLORS.white,
    letterSpacing: 0.3,
  },
});
