import React, { useRef } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { useCartStore } from '../../store/cartStore';
import { useWishlistStore } from '../../store/wishlistStore';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - SIZES.padding * 2 - 12) / 2;

export default function ProductCard({ product, onAddToCart }) {
  const navigation = useNavigation();
  const { toggleWishlist, isInWishlist } = useWishlistStore();
  const { items = [], updateQuantity } = useCartStore();

  const cartItem = items.find(
    (i) => (i.product?._id || i.productId || i._id) === product._id
  );
  const qty = cartItem ? cartItem.quantity : 0;

  const isFavorited = isInWishlist(product._id);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handleAddToCartPress = () => {
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 1.35, duration: 90, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, friction: 3, useNativeDriver: true }),
    ]).start();

    try {
      Vibration.vibrate([0, 40, 50, 40]);
    } catch {}

    if (onAddToCart) {
      onAddToCart(product);
    }
  };

  const price = Number(product.price || 0);
  const comparePrice = Number(product.comparePrice || 0);
  const discountPercent =
    comparePrice > price
      ? Math.round(((comparePrice - price) / comparePrice) * 100)
      : (product.discount || product.dealDiscount || 0);

  const imageUrl =
    product.images?.[0] ||
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400';

  const ratingAvg = Number(product.rating?.average ?? product.rating ?? 4.5).toFixed(1);
  const reviewCount = product.rating?.count ?? product.numReviews ?? 0;

  return (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.9}
      onPress={() => navigation.navigate('ProductDetail', { slug: product.slug, id: product._id })}
    >
      {/* Image & Badges */}
      <View style={styles.imageContainer}>
        <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="cover" />

        {discountPercent > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{discountPercent}% OFF</Text>
          </View>
        )}

        <TouchableOpacity
          style={styles.wishlistButton}
          onPress={() => toggleWishlist(product)}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons
            name={isFavorited ? 'heart' : 'heart-outline'}
            size={18}
            color={isFavorited ? COLORS.danger : COLORS.textSecondary}
          />
        </TouchableOpacity>
      </View>

      {/* Details */}
      <View style={styles.info}>
        {product.category?.name ? (
          <Text style={styles.category} numberOfLines={1}>
            {product.category.name}
          </Text>
        ) : null}

        <Text style={styles.title} numberOfLines={2}>
          {product.name}
        </Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Ionicons name="star" size={12} color={COLORS.star} />
          <Text style={styles.ratingText}>{ratingAvg}</Text>
          <Text style={styles.reviewsText}>({reviewCount})</Text>
        </View>

        {/* Price & Add to Cart */}
        <View style={styles.priceRow}>
          <View style={styles.priceColumn}>
            <Text style={styles.price}>₹{price.toLocaleString('en-IN')}</Text>
            {comparePrice > price && (
              <Text style={styles.comparePrice}>
                ₹{comparePrice.toLocaleString('en-IN')}
              </Text>
            )}
          </View>

          {onAddToCart && (
            qty === 0 ? (
              <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
                <TouchableOpacity
                  style={styles.cartButton}
                  onPress={handleAddToCartPress}
                  activeOpacity={0.8}
                >
                  <Ionicons name="add" size={18} color={COLORS.white} />
                </TouchableOpacity>
              </Animated.View>
            ) : (
              <View style={styles.cardStepper}>
                <TouchableOpacity
                  style={styles.cardStepperBtn}
                  onPress={() => updateQuantity(product._id, qty - 1)}
                  hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                >
                  <Ionicons name="remove" size={12} color={COLORS.white} />
                </TouchableOpacity>
                <Text style={styles.cardStepperText}>{qty}</Text>
                <TouchableOpacity
                  style={styles.cardStepperBtn}
                  onPress={() => updateQuantity(product._id, qty + 1)}
                  hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                >
                  <Ionicons name="add" size={12} color={COLORS.white} />
                </TouchableOpacity>
              </View>
            )
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  imageContainer: {
    width: '100%',
    height: CARD_WIDTH * 1.05,
    backgroundColor: COLORS.borderLight,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: COLORS.danger,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
  },
  discountText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  wishlistButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 28,
    height: 28,
    borderRadius: SIZES.radiusFull,
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    paddingHorizontal: 10,
    paddingTop: 8,
    paddingBottom: 10,
  },
  category: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.primary,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    marginBottom: 4,
    includeFontPadding: false,
  },
  title: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.text,
    lineHeight: 18,
    minHeight: 36,
    marginBottom: 4,
    includeFontPadding: false,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 4,
  },
  ratingText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.text,
    includeFontPadding: false,
  },
  reviewsText: {
    fontSize: 11,
    color: COLORS.textMuted,
    includeFontPadding: false,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  priceColumn: {
    flex: 1,
  },
  price: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    includeFontPadding: false,
  },
  comparePrice: {
    fontSize: 11,
    color: COLORS.textMuted,
    textDecorationLine: 'line-through',
    marginTop: 1,
    includeFontPadding: false,
  },
  cartButton: {
    width: 30,
    height: 30,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.glow,
  },
  cardStepper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusSm,
    paddingHorizontal: 4,
    paddingVertical: 2,
    gap: 6,
    ...SHADOWS.small,
  },
  cardStepperBtn: {
    padding: 3,
  },
  cardStepperText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '900',
    minWidth: 14,
    textAlign: 'center',
  },
});
