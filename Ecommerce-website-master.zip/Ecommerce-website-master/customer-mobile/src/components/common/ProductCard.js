import React, { useRef } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  Vibration,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useMutation } from '@apollo/client';
import { UPDATE_CART_ITEM, REMOVE_FROM_CART } from '../../graphql/mutations';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { getProductAvailableStock, getItemVertical } from '../../utils/cartHelpers';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - SIZES.padding * 2 - 12) / 2;

export default function ProductCard({ product, onAddToCart, showAddButton = true }) {
  const navigation = useNavigation();
  const { toggleWishlist, isInWishlist } = useWishlistStore();
  const { items = [], updateQuantity, setCart } = useCartStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const [updateCartItemMutation] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      if (res?.updateCartItem) setCart(res.updateCartItem);
    },
    onError: (e) => console.warn('ProductCard updateCartItem error:', e.message),
  });

  const [removeFromCartMutation] = useMutation(REMOVE_FROM_CART, {
    onCompleted: (res) => {
      if (res?.removeFromCart) setCart(res.removeFromCart);
    },
    onError: (e) => console.warn('ProductCard removeFromCart error:', e.message),
  });

  const cartItem = items.find(
    (i) => (i.product?._id || i.productId || i._id) === product._id
  );
  const qty = cartItem ? cartItem.quantity : 0;

  const isFavorited = isInWishlist(product._id);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handleAddToCartPress = () => {
    const availStock = getProductAvailableStock(product);
    if (availStock <= 0 || product.isAvailable === false) {
      Alert.alert('Out of Stock 🔴', 'This item is currently out of stock.');
      return;
    }

    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: 1.35, duration: 90, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, friction: 3, useNativeDriver: true }),
    ]).start();

    try {
      Vibration.vibrate([0, 40, 50, 40]);
    } catch {}

    if (onAddToCart) {
      onAddToCart(product);
    }
  };

  const price = Number(product.price || 0);
  const comparePrice = Number(product.comparePrice || 0);
  const discountPercent =
    comparePrice > price
      ? Math.round(((comparePrice - price) / comparePrice) * 100)
      : (product.discount || product.dealDiscount || 0);

  const imageUrl =
    product.images?.[0] ||
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400';

  const ratingAvg = Number(product.rating?.average ?? product.rating ?? 4.5).toFixed(1);
  const reviewCount = product.rating?.count ?? product.numReviews ?? 0;

  const isOffline = product.vendor?.role === 'vendor' && product.vendor?.isOnline === false;
  const maxStock = getProductAvailableStock(product);
  const isOutOfStock = maxStock <= 0 || product.isAvailable === false;

  const handleDecreaseQty = () => {
    const idToPass = product._id;
    const targetApiId = (cartItem?._id && !cartItem._id.startsWith('temp-'))
      ? cartItem._id
      : (cartItem?.product?._id || cartItem?.productId || product._id);

    if (qty <= 1) {
      updateQuantity(idToPass, 0);
      if (isAuthenticated && targetApiId) {
        removeFromCartMutation({ variables: { itemId: targetApiId } });
      }
    } else {
      updateQuantity(idToPass, qty - 1);
      if (isAuthenticated && targetApiId) {
        updateCartItemMutation({ variables: { itemId: targetApiId, quantity: qty - 1 } });
      }
    }
  };

  const handleIncreaseQty = () => {
    if (qty + 1 > maxStock) {
      Alert.alert('Stock Limit Reached', `Only ${maxStock} item${maxStock === 1 ? '' : 's'} available in stock.`);
      return;
    }

    const idToPass = product._id;
    const targetApiId = (cartItem?._id && !cartItem._id.startsWith('temp-'))
      ? cartItem._id
      : (cartItem?.product?._id || cartItem?.productId || product._id);

    updateQuantity(idToPass, qty + 1);
    if (isAuthenticated && targetApiId) {
      updateCartItemMutation({ variables: { itemId: targetApiId, quantity: qty + 1 } });
    }
  };

  return (
    <TouchableOpacity
      style={[styles.card, (isOffline || isOutOfStock) && styles.cardOffline]}
      activeOpacity={(isOffline || isOutOfStock) ? 1 : 0.9}
      disabled={isOffline || isOutOfStock}
      onPress={() => {
        if (!isOffline && !isOutOfStock) {
          navigation.navigate('ProductDetail', { slug: product.slug, id: product._id });
        }
      }}
    >
      {/* Image & Badges */}
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: imageUrl }}
          style={[styles.image, (isOffline || isOutOfStock) && { opacity: 0.55 }]}
          resizeMode="cover"
        />

        {isOffline ? (
          <View style={styles.offlineBadge}>
            <Text style={styles.offlineBadgeText}>STORE CLOSED</Text>
          </View>
        ) : isOutOfStock ? (
          <View style={[styles.offlineBadge, { backgroundColor: '#EF4444' }]}>
            <Text style={styles.offlineBadgeText}>OUT OF STOCK</Text>
          </View>
        ) : discountPercent > 0 ? (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{discountPercent}% OFF</Text>
          </View>
        ) : null}

        {product?.isVeg !== undefined && ['food', 'grocery'].includes(getItemVertical(product)) && (
          <View style={[styles.vegSquare, { borderColor: product.isVeg === false ? '#DC2626' : '#16A34A' }]}>
            <View style={[styles.vegDot, { backgroundColor: product.isVeg === false ? '#DC2626' : '#16A34A' }]} />
          </View>
        )}

        {!isOffline && !isOutOfStock && (
          <TouchableOpacity
            style={styles.wishlistButton}
            onPress={() => toggleWishlist(product)}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Ionicons
              name={isFavorited ? 'heart' : 'heart-outline'}
              size={18}
              color={isFavorited ? COLORS.danger : COLORS.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      {/* Details */}
      <View style={styles.info}>
        {product.category?.name ? (
          <Text style={[styles.category, (isOffline || isOutOfStock) && { color: '#64748B' }]} numberOfLines={1}>
            {product.category.name}
          </Text>
        ) : null}

        <Text style={[styles.title, (isOffline || isOutOfStock) && { color: '#64748B' }]} numberOfLines={2}>
          {product.name}
        </Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Ionicons name="star" size={12} color={(isOffline || isOutOfStock) ? '#94A3B8' : COLORS.star} />
          <Text style={[styles.ratingText, (isOffline || isOutOfStock) && { color: '#64748B' }]}>{ratingAvg}</Text>
          <Text style={[styles.reviewsText, (isOffline || isOutOfStock) && { color: '#94A3B8' }]}>({reviewCount})</Text>
        </View>

        {/* Price & Add to Cart */}
        <View style={styles.priceRow}>
          <View style={styles.priceColumn}>
            <Text style={[styles.price, (isOffline || isOutOfStock) && { color: '#64748B' }]}>₹{price.toLocaleString('en-IN')}</Text>
            {comparePrice > price && (
              <Text style={styles.comparePrice}>
                ₹{comparePrice.toLocaleString('en-IN')}
              </Text>
            )}
          </View>

          {isOffline ? (
            <View style={styles.closedPill}>
              <Text style={styles.closedPillText}>CLOSED</Text>
            </View>
          ) : isOutOfStock ? (
            <View style={[styles.closedPill, { backgroundColor: '#F1F5F9', borderColor: '#CBD5E1' }]}>
              <Text style={[styles.closedPillText, { color: '#EF4444', fontSize: 10, fontWeight: '700' }]}>OUT OF STOCK</Text>
            </View>
          ) : (showAddButton && onAddToCart) ? (
            qty === 0 ? (
              <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
                <TouchableOpacity
                  style={styles.cartButton}
                  onPress={handleAddToCartPress}
                  activeOpacity={0.8}
                >
                  <Ionicons name="add" size={18} color={COLORS.white} />
                </TouchableOpacity>
              </Animated.View>
            ) : (
              <View style={styles.cardStepper}>
                <TouchableOpacity
                  style={styles.cardStepperBtn}
                  onPress={handleDecreaseQty}
                  hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                >
                  <Ionicons name="remove" size={12} color={COLORS.white} />
                </TouchableOpacity>
                <Text style={styles.cardStepperText}>{qty}</Text>
                <TouchableOpacity
                  style={[styles.cardStepperBtn, (qty >= maxStock) && { opacity: 0.4 }]}
                  disabled={qty >= maxStock}
                  onPress={handleIncreaseQty}
                  hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                >
                  <Ionicons name="add" size={12} color={COLORS.white} />
                </TouchableOpacity>
              </View>
            )
          ) : null}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  imageContainer: {
    width: '100%',
    height: CARD_WIDTH * 1.05,
    backgroundColor: COLORS.borderLight,
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: COLORS.danger,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
  },
  discountText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  wishlistButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 28,
    height: 28,
    borderRadius: SIZES.radiusFull,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vegSquare: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    width: 12,
    height: 12,
    borderWidth: 1,
    borderRadius: 3,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    zIndex: 5,
  },
  vegDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  info: {
    paddingHorizontal: 10,
    paddingTop: 8,
    paddingBottom: 10,
  },
  category: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.primary,
    textTransform: 'uppercase',
    letterSpacing: 0.4,
    marginBottom: 4,
    includeFontPadding: false,
  },
  title: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.text,
    lineHeight: 18,
    minHeight: 36,
    marginBottom: 4,
    includeFontPadding: false,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    gap: 4,
  },
  ratingText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.text,
    includeFontPadding: false,
  },
  reviewsText: {
    fontSize: 11,
    color: COLORS.textMuted,
    includeFontPadding: false,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  priceColumn: {
    flex: 1,
  },
  price: {
    fontSize: 15,
    fontWeight: '800',
    color: COLORS.text,
    includeFontPadding: false,
  },
  comparePrice: {
    fontSize: 11,
    color: COLORS.textMuted,
    textDecorationLine: 'line-through',
    marginTop: 1,
    includeFontPadding: false,
  },
  cartButton: {
    width: 30,
    height: 30,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.glow,
  },
  cardStepper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusSm,
    paddingHorizontal: 4,
    paddingVertical: 2,
    gap: 6,
    ...SHADOWS.small,
  },
  cardStepperBtn: {
    padding: 3,
  },
  cardStepperText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '700',
    minWidth: 16,
    textAlign: 'center',
  },
  cardOffline: {
    opacity: 0.65,
    backgroundColor: '#F8FAFC',
    borderColor: '#CBD5E1',
  },
  offlineBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: '#475569',
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 4,
    zIndex: 10,
  },
  offlineBadgeText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  closedPill: {
    backgroundColor: '#E2E8F0',
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 6,
  },
  closedPillText: {
    color: '#64748B',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
});
