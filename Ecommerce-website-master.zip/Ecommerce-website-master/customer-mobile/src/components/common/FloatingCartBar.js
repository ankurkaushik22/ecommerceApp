import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useCartStore } from '../../store/cartStore';
import { COLORS, SHADOWS } from '../../constants/theme';

import { filterItemsByVertical } from '../../utils/cartHelpers';

export default function FloatingCartBar({ vertical = 'shopping' }) {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const items = useCartStore((s) => s.items || []);

  const displayItems = filterItemsByVertical(items || [], vertical);
  const totalItems = displayItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = displayItems.reduce((sum, i) => sum + ((i?.price || i?.product?.price || 0) * (i?.quantity || 0)), 0);

  if (totalItems === 0) return null;

  const barColor = vertical === 'food' ? '#EA580C' : vertical === 'grocery' ? '#059669' : COLORS.primary;

  return (
    <View style={[styles.floatingCart, { backgroundColor: barColor, bottom: insets.bottom + 12 }]}>
      <View>
        <Text style={styles.floatingCartCount}>
          {totalItems} {totalItems === 1 ? 'ITEM' : 'ITEMS'} ADDED
        </Text>
        <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
      </View>
      <TouchableOpacity
        onPress={() => navigation.navigate('CartTab', { vertical })}
        style={styles.viewCartButton}
        activeOpacity={0.85}
      >
        <Text style={styles.viewCartButtonText}>View Cart</Text>
        <Ionicons name="arrow-forward" size={16} color="#FFF" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 999,
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: 'rgba(255, 255, 255, 0.85)',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
});
