import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Vibration,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useMutation } from '@apollo/client';
import { CREATE_SUPPORT_TICKET } from '../../graphql/mutations';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const TOPICS = [
  { id: 'orders', label: 'Orders & Delivery', icon: 'cube-outline' },
  { id: 'payment', label: 'Payment & Refund', icon: 'card-outline' },
  { id: 'product', label: 'Product Inquiry', icon: 'pricetag-outline' },
  { id: 'account', label: 'Account & Login', icon: 'person-outline' },
  { id: 'other', label: 'General Query', icon: 'chatbubbles-outline' },
];

export default function SupportModal({ visible, onClose }) {
  const { user, isAuthenticated } = useAuthStore();
  const [selectedTopic, setSelectedTopic] = useState('orders');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submittedTicket, setSubmittedTicket] = useState(null);

  const [createTicket, { loading }] = useMutation(CREATE_SUPPORT_TICKET, {
    onCompleted: (res) => {
      Vibration.vibrate(75);
      setSubmittedTicket(res.createSupportTicket);
      setSubject('');
      setMessage('');
    },
    onError: (err) => {
      Vibration.vibrate([0, 50, 50, 50]);
      Alert.alert('Error', err.message || 'Failed to submit support request. Please try again.');
    },
  });

  const handleSubmit = () => {
    const trimmedSubject = subject.trim();
    const trimmedMessage = message.trim();

    if (!trimmedSubject) {
      Alert.alert('Subject Required', 'Please enter a brief subject for your query.');
      return;
    }
    if (!trimmedMessage) {
      Alert.alert('Message Required', 'Please describe your query or problem in detail.');
      return;
    }

    const topicItem = TOPICS.find((t) => t.id === selectedTopic);
    const finalSubject = `[${topicItem?.label || 'General'}] ${trimmedSubject}`;

    createTicket({
      variables: {
        input: {
          subject: finalSubject,
          message: trimmedMessage,
          category: selectedTopic,
          name: user?.name || 'Customer',
          email: user?.email || 'customer@example.com',
          phone: user?.phone,
        },
      },
    });
  };

  const handleClose = () => {
    setSubmittedTicket(null);
    setSubject('');
    setMessage('');
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={handleClose}>
      <KeyboardAvoidingView
        style={styles.overlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <TouchableOpacity style={styles.backdrop} activeOpacity={1} onPress={handleClose} />

        <View style={styles.sheetContainer}>
          {/* Top Bar */}
          <View style={styles.topBar}>
            <View style={styles.titleRow}>
              <View style={styles.iconCircle}>
                <Ionicons name="headset" size={18} color={COLORS.primary} />
              </View>
              <View>
                <Text style={styles.sheetTitle}>Customer Support</Text>
                <Text style={styles.sheetSub}>We are here to help you 24/7</Text>
              </View>
            </View>
            <TouchableOpacity onPress={handleClose} style={styles.closeBtn}>
              <Ionicons name="close" size={20} color={COLORS.text} />
            </TouchableOpacity>
          </View>

          {submittedTicket ? (
            /* Success View */
            <View style={styles.successBox}>
              <View style={styles.successIconCircle}>
                <Ionicons name="checkmark-circle" size={48} color="#16A34A" />
              </View>
              <Text style={styles.successTitle}>Request Sent to Admin!</Text>
              <Text style={styles.successSub}>
                Your ticket has been logged successfully. Our support team will review and respond shortly.
              </Text>

              <View style={styles.ticketBadge}>
                <Text style={styles.ticketBadgeLabel}>Ticket Reference ID</Text>
                <Text style={styles.ticketBadgeNum}>#{submittedTicket.ticketNumber || 'TKT-PENDING'}</Text>
              </View>

              <TouchableOpacity style={styles.doneBtn} onPress={handleClose}>
                <Text style={styles.doneBtnText}>Back to App</Text>
              </TouchableOpacity>
            </View>
          ) : (
            /* Support Form View */
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.formScroll}>
              {/* Category selector */}
              <Text style={styles.fieldLabel}>Select Issue Category</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.topicsRow}>
                {TOPICS.map((t) => {
                  const active = selectedTopic === t.id;
                  return (
                    <TouchableOpacity
                      key={t.id}
                      style={[styles.topicChip, active && styles.topicChipActive]}
                      onPress={() => setSelectedTopic(t.id)}
                    >
                      <Ionicons
                        name={t.icon}
                        size={14}
                        color={active ? COLORS.white : COLORS.textSecondary}
                        style={{ marginRight: 5 }}
                      />
                      <Text style={[styles.topicChipText, active && styles.topicChipTextActive]}>
                        {t.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>

              {/* Subject */}
              <Text style={[styles.fieldLabel, { marginTop: 14 }]}>Subject</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. Order delivery delayed or wrong item received"
                placeholderTextColor={COLORS.textMuted}
                value={subject}
                onChangeText={setSubject}
                maxLength={100}
              />

              {/* Message */}
              <Text style={[styles.fieldLabel, { marginTop: 14 }]}>Message Details</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Please describe your issue, order number, or question in detail..."
                placeholderTextColor={COLORS.textMuted}
                value={message}
                onChangeText={setMessage}
                multiline
                numberOfLines={4}
                textAlignVertical="top"
                maxLength={1000}
              />

              {/* User email note */}
              {user?.email && (
                <View style={styles.emailNote}>
                  <Ionicons name="information-circle-outline" size={14} color={COLORS.primary} />
                  <Text style={styles.emailNoteText}>
                    Reply will be sent to: <Text style={{ fontWeight: '700' }}>{user.email}</Text>
                  </Text>
                </View>
              )}

              {/* Submit button */}
              <TouchableOpacity
                style={[styles.submitBtn, loading && styles.submitBtnDisabled]}
                onPress={handleSubmit}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color={COLORS.white} size="small" />
                ) : (
                  <>
                    <Ionicons name="paper-plane" size={16} color={COLORS.white} style={{ marginRight: 6 }} />
                    <Text style={styles.submitBtnText}>Send Message to Admin</Text>
                  </>
                )}
              </TouchableOpacity>
            </ScrollView>
          )}
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  backdrop: {
    flex: 1,
  },
  sheetContainer: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    maxHeight: '85%',
    ...SHADOWS.large,
  },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  iconCircle: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sheetTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: COLORS.text,
  },
  sheetSub: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  formScroll: {
    paddingVertical: 14,
  },
  fieldLabel: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  topicsRow: {
    flexDirection: 'row',
    gap: 8,
    paddingVertical: 2,
  },
  topicChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  topicChipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  topicChipText: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  topicChipTextActive: {
    color: COLORS.white,
    fontWeight: '700',
  },
  input: {
    borderWidth: 1,
    borderColor: '#CBD5E1',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 13,
    color: COLORS.text,
    backgroundColor: '#F8FAFC',
  },
  textArea: {
    minHeight: 100,
  },
  emailNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#EEF2FF',
    padding: 10,
    borderRadius: 10,
    marginTop: 12,
  },
  emailNoteText: {
    fontSize: 11,
    color: COLORS.primaryDark,
    flex: 1,
  },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    paddingVertical: 14,
    borderRadius: 14,
    marginTop: 18,
    ...SHADOWS.small,
  },
  submitBtnDisabled: {
    opacity: 0.6,
  },
  submitBtnText: {
    color: COLORS.white,
    fontWeight: '800',
    fontSize: 14,
  },
  successBox: {
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 10,
  },
  successIconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#DCFCE7',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 6,
  },
  successSub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 18,
    maxWidth: 280,
    marginBottom: 20,
  },
  ticketBadge: {
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  ticketBadgeLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  ticketBadgeNum: {
    fontSize: 16,
    fontWeight: '900',
    color: COLORS.primary,
    marginTop: 2,
    letterSpacing: 1,
  },
  doneBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 36,
    paddingVertical: 12,
    borderRadius: 12,
  },
  doneBtnText: {
    color: COLORS.white,
    fontWeight: '700',
    fontSize: 14,
  },
});
