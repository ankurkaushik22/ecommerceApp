import { Platform, Linking } from 'react-native';
import * as IntentLauncher from 'expo-intent-launcher';

/**
 * Formats standard UPI URI deep link
 * Format: upi://pay?pa=<UPI_ID>&pn=<PAYEE_NAME>&tr=<REF_ID>&tn=<NOTE>&am=<AMOUNT>&cu=INR
 */
export function buildUpiUrl({
  upiId = 'shivam181197@upi',
  payeeName = 'Suaaka Store',
  transactionId = '',
  transactionRef = '',
  note = 'Order Payment',
  amount = 0,
}) {
  const cleanUpi = (upiId || 'shivam181197@upi').trim();
  const cleanName = encodeURIComponent((payeeName || 'Suaaka Store').trim());
  const cleanNote = encodeURIComponent((note || 'Order Payment').trim());
  const formattedAmount = Number(amount || 0).toFixed(2);
  const ref = transactionRef || transactionId || `ORD${Date.now()}`;

  return `upi://pay?pa=${cleanUpi}&pn=${cleanName}&tr=${ref}&tn=${cleanNote}&am=${formattedAmount}&cu=INR`;
}

/**
 * Parses response URL or query string returned by native Android UPI apps
 */
export function parseUpiResponse(rawString) {
  if (!rawString || typeof rawString !== 'string') {
    return { status: 'CANCELLED', raw: '' };
  }

  const params = {};
  const queryString = rawString.includes('?') ? rawString.split('?')[1] : rawString;
  const pairs = queryString.split('&');

  for (const pair of pairs) {
    const [key, val] = pair.split('=');
    if (key && val) {
      params[key.trim()] = decodeURIComponent(val.trim());
    }
  }

  const rawStatus = (params.Status || params.status || params.STATUS || '').toUpperCase();
  const responseCode = (params.responseCode || params.ResponseCode || params.resCode || '').trim();
  const txnId = params.txnId || params.txnid || params.ApprovalRefNo || params.txnRef || params.tr || '';

  let status = 'FAILURE';
  if (rawStatus === 'SUCCESS' || responseCode === '00' || responseCode === '0') {
    status = 'SUCCESS';
  } else if (rawStatus === 'SUBMITTED' || rawStatus === 'PENDING') {
    status = 'SUBMITTED';
  } else if (rawStatus === 'CANCELLED' || rawStatus === 'FAILURE' || responseCode === 'ZD') {
    status = 'CANCELLED';
  }

  return {
    status,
    rawStatus,
    responseCode,
    txnId,
    params,
    raw: rawString,
  };
}

/**
 * Launches native Android Intent Chooser for installed UPI apps (Google Pay, PhonePe, Paytm, BHIM, CRED)
 */
export async function launchUpiPayment({
  upiId = 'shivam181197@upi',
  payeeName = 'Suaaka Store',
  transactionId = '',
  transactionRef = '',
  note = 'Order Payment',
  amount = 0,
}) {
  const upiUrl = buildUpiUrl({
    upiId,
    payeeName,
    transactionId,
    transactionRef,
    note,
    amount,
  });

  if (Platform.OS === 'android') {
    try {
      // Launch ACTION_VIEW intent with upi://pay URI
      // Android OS displays native UPI App picker chooser with installed apps
      const result = await IntentLauncher.startActivityAsync('android.intent.action.VIEW', {
        data: upiUrl,
        flags: 0x10000000, // FLAG_ACTIVITY_NEW_TASK
      });

      if (result && result.data) {
        return parseUpiResponse(result.data);
      }

      // User pressed back button or cancelled without completing payment
      if (result && result.resultCode === 0) {
        return { status: 'CANCELLED', message: 'Payment cancelled by user' };
      }

      return parseUpiResponse(result?.data || '');
    } catch (error) {
      const errorMsg = (error.message || error.toString() || '').toLowerCase();
      
      // Try Linking fallback if available
      try {
        const supported = await Linking.canOpenURL(upiUrl);
        if (supported) {
          await Linking.openURL(upiUrl);
          return { status: 'SUBMITTED', message: 'Launched UPI App' };
        }
      } catch (linkingErr) {
        // ignore linking check error
      }

      if (errorMsg.includes('activitynotfoundexception') || errorMsg.includes('no activity found')) {
        throw new Error('No UPI app (Google Pay, PhonePe, Paytm, BHIM) found installed on this device. Please install a UPI app or select Cash on Delivery.');
      }
      throw new Error(error.message || 'Unable to launch UPI payment app on your device.');
    }
  } else {
    // iOS or other platforms
    try {
      const supported = await Linking.canOpenURL(upiUrl);
      if (supported) {
        await Linking.openURL(upiUrl);
        return { status: 'SUBMITTED', message: 'Launched UPI App' };
      }
      throw new Error('No supported UPI app found on your device.');
    } catch (err) {
      throw new Error('No supported UPI app (Google Pay, PhonePe, Paytm) found installed on your device.');
    }
  }
}

/**
 * react-native-allinone-upi compatible Promise API wrapper
 */
export async function startPayment(config = {}) {
  const upiId = config.upiId || config.pa || 'shivam181197@upi';
  const payeeName = config.name || config.payeeName || config.pn || 'Suaaka Store';
  const amount = config.amount || config.am || 0;
  const transactionRef = config.transactionRef || config.tr || config.transactionId || `ORD${Date.now()}`;
  const note = config.transactionNote || config.note || config.tn || 'Order Payment';

  return launchUpiPayment({
    upiId,
    payeeName,
    amount,
    transactionRef,
    note,
  });
}

/**
 * react-native-allinone-upi compatible callback API wrapper
 */
export function initializePayment(config = {}, successCallback, failureCallback) {
  startPayment(config)
    .then((res) => {
      if (res.status === 'SUCCESS') {
        if (typeof successCallback === 'function') successCallback(res);
      } else {
        if (typeof failureCallback === 'function') failureCallback(res);
      }
    })
    .catch((err) => {
      if (typeof failureCallback === 'function') failureCallback({ status: 'FAILURE', message: err.message });
    });
}
