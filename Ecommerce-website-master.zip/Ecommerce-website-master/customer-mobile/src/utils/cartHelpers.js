export function getItemVertical(item) {
  if (!item) return 'shopping';
  const prod = item.product || item;

  // 1. Explicit vertical on item, product, or category
  const vert = item.vertical || prod.vertical || prod.category?.vertical || item.category?.vertical;
  if (vert && ['food', 'grocery', 'services', 'shopping'].includes(vert)) {
    return vert;
  }

  // 2. Metadata indicators
  if (
    (Array.isArray(item.addons) && item.addons.length > 0) ||
    (Array.isArray(prod.addons) && prod.addons.length > 0) ||
    item.instructions ||
    prod.instructions
  ) {
    return 'food';
  }
  if (
    prod.restaurantName ||
    prod.restaurantId ||
    (Array.isArray(prod.cuisine) && prod.cuisine.length > 0) ||
    prod.isVeg !== undefined
  ) {
    return 'food';
  }
  if (prod.unitMeasure || (Array.isArray(prod.nutritionalHighlights) && prod.nutritionalHighlights.length > 0)) {
    return 'grocery';
  }
  if (prod.serviceDuration || (Array.isArray(prod.includedFeatures) && prod.includedFeatures.length > 0)) {
    return 'services';
  }

  // 3. Category & name string checks
  const cat = (item.category?.name || prod.category?.name || item.category?.slug || prod.category?.slug || '').toLowerCase();
  const name = (item.name || prod.name || '').toLowerCase();

  // If category matches food explicitly
  if (
    cat.includes('food') || cat.includes('restaurant') || cat.includes('dining') || cat.includes('dish') ||
    cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') || cat.includes('pasta') ||
    cat.includes('starter') || cat.includes('main course') || cat.includes('dessert') || cat.includes('beverage') ||
    cat.includes('snack') || cat.includes('south indian') || cat.includes('north indian') || cat.includes('fast food')
  ) {
    return 'food';
  }

  // If category matches grocery explicitly
  if (
    cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') ||
    cat.includes('meat') || cat.includes('poultry') || cat.includes('bakery') || cat.includes('seafood') ||
    cat.includes('staple') || cat.includes('spices')
  ) {
    return 'grocery';
  }

  // 4. Name matching: Food prepared dishes FIRST before raw grocery staples
  if (
    name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('pasta') ||
    name.includes('margherita') || name.includes('tikka') || name.includes('momo') || name.includes('shake') ||
    name.includes('wrap') || name.includes('roll') || name.includes('thali') || name.includes('dosa') ||
    name.includes('chhole') || name.includes('chowmein') || name.includes('makhni') || name.includes('tadka') ||
    name.includes('curry') || name.includes('gravy') || name.includes('kebab') || name.includes('tandoori') ||
    name.includes('noodle') || name.includes('manchurian') || name.includes('fried rice') || name.includes('pulao') ||
    name.includes('bhature') || name.includes('sandwich') || name.includes('naan') || name.includes('kulcha') ||
    name.includes('paratha') || name.includes('lassi') || name.includes('dal makh') || name.includes('dal fry') ||
    name.includes('dal tadka') || name.includes('paneer butter') || name.includes('kadhai paneer') || name.includes('shahi paneer') ||
    name.includes('butter chicken') || name.includes('hakka noodles') || name.includes('spring roll') ||
    name.includes('cake') || name.includes('pastry') || name.includes('brownie') || name.includes('ice cream') ||
    name.includes('icecream') || name.includes('dessert') || name.includes('lava cake') || name.includes('vendor product')
  ) {
    return 'food';
  }

  // Raw grocery ingredients heuristic
  if (
    name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('bread') ||
    name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') ||
    name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') ||
    name.includes('apple') || name.includes('avocado') || name.includes('avocados') || name.includes('spinach') ||
    name.includes('carrot') || name.includes('strawberry') || name.includes('strawberries') || name.includes('chicken') ||
    name.includes('mutton') || name.includes('meat') || name.includes('egg') || name.includes('eggs') ||
    name.includes('fish') || name.includes('prawn') || name.includes('tomato') || name.includes('tomatoes') ||
    name.includes('curry cut') || name.includes('boneless') || name.includes('paneer')
  ) {
    return 'grocery';
  }

  if (cat.includes('service') || name.includes('plumbing') || name.includes('cleaning') || name.includes('repair')) {
    return 'services';
  }

  return 'shopping';
}

export function filterItemsByVertical(items, vertical) {
  if (!items || items.length === 0) return [];
  return items.filter((item) => getItemVertical(item) === vertical);
}

export function isProductStockCompulsory(product) {
  if (!product) return false;
  if (product.isUnlimitedStock === true) return false;
  if (product.isStockCompulsory === false) return false;
  const vert = getItemVertical(product) || product.vertical;
  const isFoodOrService =
    vert === 'food' ||
    vert === 'services' ||
    Boolean(product.restaurantName) ||
    product.isVeg !== undefined ||
    (Array.isArray(product.cuisine) && product.cuisine.length > 0) ||
    (Array.isArray(product.addons) && product.addons.length > 0) ||
    Boolean(product.serviceDuration);

  if (isFoodOrService) {
    if (product.isStockCompulsory === true && product.isUnlimitedStock === false && typeof product.stock === 'number' && product.stock > 0) {
      return true;
    }
    return false;
  }
  if (product.isUnlimitedStock === false || product.isStockCompulsory === true) {
    return true;
  }
  return true;
}

export function getProductAvailableStock(product, variantIndex = -1) {
  if (!product) return 999999;
  if (!isProductStockCompulsory(product)) return 999999;

  if (variantIndex >= 0 && Array.isArray(product.variants) && product.variants.length > 0) {
    let flatIdx = 0;
    for (const vg of product.variants) {
      for (const opt of vg.options || []) {
        if (flatIdx === variantIndex) {
          if (opt.stock !== null && opt.stock !== undefined && typeof opt.stock === 'number') {
            return Number(opt.stock);
          }
          return 999999;
        }
        flatIdx++;
      }
    }
  }

  if (product.stock !== null && product.stock !== undefined && typeof product.stock === 'number') {
    return Number(product.stock);
  }

  return 999999;
}

export function getItemAvailableStock(item) {
  if (!item) return 999999;
  if (typeof item.availableStock === 'number') {
    return item.availableStock;
  }
  const p = item.product || item;
  const vIndex = item.variantIndex !== undefined ? item.variantIndex : (p.variantIndex ?? -1);
  return getProductAvailableStock(p, vIndex);
}
