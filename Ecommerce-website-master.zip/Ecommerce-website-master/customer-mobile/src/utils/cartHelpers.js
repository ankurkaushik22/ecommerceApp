export function getItemVertical(item) {
  if (!item) return 'shopping';
  const prod = item.product || item;

  const vert = item.vertical || prod.vertical || prod.category?.vertical;
  if (vert && ['food', 'grocery', 'services'].includes(vert)) {
    return vert;
  }

  if (prod.restaurantName || (prod.cuisine && prod.cuisine.length > 0)) {
    return 'food';
  }
  if (prod.unitMeasure || (prod.nutritionalHighlights && prod.nutritionalHighlights.length > 0)) {
    return 'grocery';
  }
  if (prod.serviceDuration || (prod.includedFeatures && prod.includedFeatures.length > 0)) {
    return 'services';
  }

  const name = (item.name || prod.name || '').toLowerCase();
  const cat = (item.category?.name || prod.category?.name || item.category?.slug || prod.category?.slug || '').toLowerCase();

  if (
    cat.includes('food') || cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') ||
    name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('tikka') ||
    name.includes('momo') || name.includes('shake') || name.includes('wrap') || name.includes('roll') ||
    name.includes('thali') || name.includes('paneer tikka') || name.includes('kathi wrap') || name.includes('kathi') ||
    name.includes('dosa') || name.includes('chhole') || name.includes('paneer') || name.includes('chowmein')
  ) {
    return 'food';
  }

  if (
    cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') ||
    cat.includes('meat') || cat.includes('poultry') || cat.includes('bakery') || cat.includes('seafood') ||
    name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('bread') ||
    name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') ||
    name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') ||
    name.includes('apple') || name.includes('avocado') || name.includes('spinach') || name.includes('carrot') ||
    name.includes('strawberry') || name.includes('chicken') || name.includes('mutton') || name.includes('meat') ||
    name.includes('egg') || name.includes('eggs') || name.includes('fish') || name.includes('prawn') ||
    name.includes('tomato') || name.includes('tomatoes') || name.includes('curry cut') || name.includes('boneless')
  ) {
    return 'grocery';
  }

  if (cat.includes('service') || name.includes('plumbing') || name.includes('cleaning') || name.includes('repair')) {
    return 'services';
  }

  return 'shopping';
}

export function filterItemsByVertical(items, vertical) {
  if (!items || items.length === 0) return [];
  return items.filter((item) => getItemVertical(item) === vertical);
}
