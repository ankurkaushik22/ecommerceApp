import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions,
  Vibration,
  Platform,
  StatusBar,
  Alert,
  BackHandler,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@apollo/client';
import { GET_ME, GET_NOTIFICATIONS, GET_STORE_SETTINGS } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import { useCartStore } from '../../store/cartStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - SIZES.padding * 2 - 14) / 2;

export default function SuperAppHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { user, isAuthenticated } = useAuthStore();
  const cartCount = useCartStore((s) => s.itemCount);
  const wishlistCount = useWishlistStore((s) => s.items?.length || 0);
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(0);

  useFocusEffect(
    useCallback(() => {
      const onBackPress = () => {
        Alert.alert('Exit App', 'Are you sure you want to exit Suaaka?', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Exit', style: 'destructive', onPress: () => BackHandler.exitApp() },
        ]);
        return true;
      };

      const subscription = BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => subscription.remove();
    }, [])
  );

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  const { data: meData } = useQuery(GET_ME, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const { data: notifData } = useQuery(GET_NOTIFICATIONS, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
    pollInterval: 30000,
  });

  const currentUser = meData?.me || user;
  const addresses = currentUser?.addresses || [];
  const currentAddress = addresses[selectedAddressIndex] || addresses[0] || {
    addressLine1: 'Home - Sector 45',
    city: 'Gurugram',
    state: 'Haryana',
    postalCode: '122003',
  };

  const unreadCount = (notifData?.getNotifications || []).filter((n) => !n.isRead).length;

  const handleCardPress = (route, params) => {
    Vibration.vibrate(50);
    if (route === 'Explore' || route === 'ExploreTab' || route === 'ShoppingMall') {
      navigation.navigate('ShoppingMall');
    } else {
      navigation.navigate(route, params);
    }
  };

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const topPadding = Platform.OS === 'web'
    ? 16
    : Math.max(insets.top, statusBarHeight, 24) + 6;

  return (
    <View style={styles.container}>
      {/* Top App Header */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        {/* Left Logo */}
        <TouchableOpacity
          activeOpacity={0.85}
          onPress={() => navigation.navigate('MainTabs')}
          style={{ alignItems: 'flex-start' }}
        >
          <Image
            source={require('../../../assets/logo.png')}
            style={{ width: 52, height: 52, borderRadius: 10 }}
            resizeMode="contain"
          />
        </TouchableOpacity>

        {/* Right Action Icons: Cart, Wishlist & Notification */}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <TouchableOpacity
            style={styles.headerBtn}
            onPress={() => {
              Vibration.vibrate(30);
              navigation.navigate('CartTab');
            }}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="cart-outline" size={22} color={COLORS.text} />
            {cartCount > 0 && (
              <View style={styles.notifBadge}>
                <Text style={styles.notifBadgeText}>{cartCount > 99 ? '99+' : cartCount}</Text>
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.headerBtn}
            onPress={() => {
              Vibration.vibrate(30);
              navigation.navigate('Wishlist');
            }}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="heart-outline" size={22} color={COLORS.text} />
            {wishlistCount > 0 && (
              <View style={[styles.notifBadge, { backgroundColor: '#EC4899' }]}>
                <Text style={styles.notifBadgeText}>{wishlistCount > 99 ? '99+' : wishlistCount}</Text>
              </View>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.headerBtn}
            onPress={() => {
              Vibration.vibrate(30);
              navigation.navigate('Notifications');
            }}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <Ionicons name="notifications-outline" size={22} color={COLORS.text} />
            {unreadCount > 0 && (
              <View style={styles.notifBadge}>
                <Text style={styles.notifBadgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Delivery Address Pill */}
        <View style={styles.deliveryCard}>
          <View style={styles.deliveryLeft}>
            <Ionicons name="location" size={18} color="#EA580C" style={{ marginRight: 6 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.deliveringLabel}>Delivering to</Text>
              <Text style={styles.addressText} numberOfLines={1}>
                {currentAddress.label || 'Home'} - {currentAddress.addressLine1 || 'Sector 45'}, {currentAddress.city || 'Gurugram'}{' '}
                <Ionicons name="chevron-down" size={13} color={COLORS.textSecondary} />
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={styles.changeBtn}
            onPress={() => {
              Vibration.vibrate(30);
              if (!isAuthenticated) navigation.navigate('Login', { redirect: 'Addresses' });
              else navigation.navigate('Addresses');
            }}
          >
            <Text style={styles.changeBtnText}>Change</Text>
          </TouchableOpacity>
        </View>

        {/* Hero Headline Section */}
        <View style={styles.heroSection}>
          <View style={styles.headlineRow}>
            <Text style={styles.headlineWordOrange}>Every</Text>
            <Text style={styles.headlineWordGreen}>thing </Text>
            <Text style={styles.headlineWordDark}>you need,</Text>
          </View>
          <Text style={styles.headlineLine2}>in one app.</Text>

          {/* Category Dots Subtitle */}
          <View style={styles.subtitleRow}>
            {!disabledVerticals.includes('shopping') && <Text style={[styles.subCatWord, { color: '#7C3AED' }]}>Shop</Text>}
            {!disabledVerticals.includes('shopping') && !disabledVerticals.includes('food') && <Text style={styles.dot}></Text>}
            {!disabledVerticals.includes('food') && <Text style={[styles.subCatWord, { color: '#EA580C' }]}>Eat</Text>}
            {(!disabledVerticals.includes('shopping') || !disabledVerticals.includes('food')) && !disabledVerticals.includes('grocery') && <Text style={styles.dot}></Text>}
            {!disabledVerticals.includes('grocery') && <Text style={[styles.subCatWord, { color: '#16A34A' }]}>Grocery</Text>}
            {(!disabledVerticals.includes('shopping') || !disabledVerticals.includes('food') || !disabledVerticals.includes('grocery')) && !disabledVerticals.includes('services') && <Text style={styles.dot}></Text>}
            {!disabledVerticals.includes('services') && <Text style={[styles.subCatWord, { color: '#2563EB' }]}>Services</Text>}
          </View>
        </View>

        {/* 4 Super-App 2x2 Gateway Cards (Filtered by Super Admin disabledVerticals) */}
        <View style={styles.gatewayGrid}>
          {/* 1. Shopping */}
          {!disabledVerticals.includes('shopping') && (
            <TouchableOpacity
              style={[styles.gatewayCard, { backgroundColor: '#FAF5FF', borderColor: '#E9D5FF' }]}
              activeOpacity={0.88}
              onPress={() => handleCardPress('ShoppingMall')}
            >
              <View style={styles.cardImageWrap}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=400' }}
                  style={styles.cardImage}
                  resizeMode="cover"
                />
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardTitle, { color: '#6D28D9' }]}>Shopping</Text>
                <Text style={styles.cardDesc}>Shop from top brands across categories</Text>
              </View>
              <View style={[styles.arrowCircle, { backgroundColor: '#7C3AED' }]}>
                <Ionicons name="arrow-forward" size={15} color={COLORS.white} />
              </View>
            </TouchableOpacity>
          )}

          {/* 2. Food Delivery */}
          {!disabledVerticals.includes('food') && (
            <TouchableOpacity
              style={[styles.gatewayCard, { backgroundColor: '#FFF7ED', borderColor: '#FED7AA' }]}
              activeOpacity={0.88}
              onPress={() => handleCardPress('FoodHome')}
            >
              <View style={styles.cardImageWrap}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400' }}
                  style={styles.cardImage}
                  resizeMode="cover"
                />
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardTitle, { color: '#EA580C' }]}>Food Delivery</Text>
                <Text style={styles.cardDesc}>Order from your favourite restaurants</Text>
              </View>
              <View style={[styles.arrowCircle, { backgroundColor: '#EA580C' }]}>
                <Ionicons name="arrow-forward" size={15} color={COLORS.white} />
              </View>
            </TouchableOpacity>
          )}

          {/* 3. Grocery */}
          {!disabledVerticals.includes('grocery') && (
            <TouchableOpacity
              style={[styles.gatewayCard, { backgroundColor: '#F0FDF4', borderColor: '#BBF7D0' }]}
              activeOpacity={0.88}
              onPress={() => handleCardPress('GroceryHome')}
            >
              <View style={styles.cardImageWrap}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400' }}
                  style={styles.cardImage}
                  resizeMode="cover"
                />
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardTitle, { color: '#16A34A' }]}>Grocery</Text>
                <Text style={styles.cardDesc}>Fresh groceries delivered to your door</Text>
              </View>
              <View style={[styles.arrowCircle, { backgroundColor: '#16A34A' }]}>
                <Ionicons name="arrow-forward" size={15} color={COLORS.white} />
              </View>
            </TouchableOpacity>
          )}

          {/* 4. Services */}
          {!disabledVerticals.includes('services') && (
            <TouchableOpacity
              style={[styles.gatewayCard, { backgroundColor: '#EFF6FF', borderColor: '#BFDBFE' }]}
              activeOpacity={0.88}
              onPress={() => handleCardPress('ServicesHome')}
            >
              <View style={styles.cardImageWrap}>
                <Image
                  source={{ uri: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400' }}
                  style={styles.cardImage}
                  resizeMode="cover"
                />
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardTitle, { color: '#2563EB' }]}>Services</Text>
                <Text style={styles.cardDesc}>Trusted services at your doorstep</Text>
              </View>
              <View style={[styles.arrowCircle, { backgroundColor: '#2563EB' }]}>
                <Ionicons name="arrow-forward" size={15} color={COLORS.white} />
              </View>
            </TouchableOpacity>
          )}
        </View>

        {/* Exclusive Offers Banner */}
        <TouchableOpacity
          style={styles.dealsBanner}
          activeOpacity={0.9}
          onPress={() => handleCardPress('Deals')}
        >
          <View style={styles.dealsTagCircle}>
            <Ionicons name="pricetag" size={24} color="#7C3AED" />
          </View>

          <View style={styles.dealsInfo}>
            <Text style={styles.dealsHeaderTag}>EXCLUSIVE OFFERS</Text>
            <Text style={styles.dealsTitle}>Best deals just for you!</Text>
            <Text style={styles.dealsSub}>Explore amazing offers across all categories.</Text>
          </View>

          <View style={styles.viewOffersPill}>
            <Text style={styles.viewOffersText}>View Offers</Text>
            <Ionicons name="chevron-forward" size={12} color="#7C3AED" />
          </View>
        </TouchableOpacity>

        <View style={{ height: 28 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAF9F8',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingBottom: 10,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#F0EFEB',
    ...SHADOWS.small,
  },
  headerBtn: {
    width: 40,
    height: 40,
    borderRadius: SIZES.radiusMd,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    position: 'relative',
    overflow: 'visible',
  },
  notifBadge: {
    position: 'absolute',
    top: -3,
    right: -3,
    backgroundColor: COLORS.danger,
    borderRadius: 9,
    minWidth: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
    zIndex: 10,
    elevation: 4,
  },
  notifBadgeText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
  },
  logoCenter: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  infinityLogoIcon: {
    width: 44,
    height: 24,
    marginBottom: 2,
  },
  brandTitleWrap: {
    alignItems: 'center',
  },
  brandTitle: {
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 2,
    color: '#0F172A',
  },
  brandTagline: {
    fontSize: 7.5,
    fontWeight: '700',
    color: '#64748B',
    letterSpacing: 0.5,
    marginTop: 1,
  },
  scrollContent: {
    padding: SIZES.padding,
    gap: 16,
  },
  deliveryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.white,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: SIZES.radiusFull,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    ...SHADOWS.small,
  },
  deliveryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 10,
  },
  deliveringLabel: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '500',
  },
  addressText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#1E293B',
    marginTop: 1,
  },
  changeBtn: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#CBD5E1',
    paddingHorizontal: 14,
    paddingVertical: 5,
    borderRadius: SIZES.radiusFull,
  },
  changeBtnText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#475569',
  },
  heroSection: {
    alignItems: 'center',
    marginTop: 6,
    marginBottom: 2,
  },
  headlineRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  headlineWordOrange: {
    fontSize: 24,
    fontWeight: '900',
    color: '#F97316',
    letterSpacing: -0.3,
  },
  headlineWordGreen: {
    fontSize: 24,
    fontWeight: '900',
    color: '#0D9488',
    letterSpacing: -0.3,
  },
  headlineWordDark: {
    fontSize: 24,
    fontWeight: '900',
    color: '#0F172A',
    letterSpacing: -0.3,
  },
  headlineLine2: {
    fontSize: 24,
    fontWeight: '900',
    color: '#0F172A',
    letterSpacing: -0.3,
    marginTop: 1,
  },
  subtitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
  },
  subCatWord: {
    fontSize: 13,
    fontWeight: '700',
  },
  dot: {
    fontSize: 12,
    color: '#94A3B8',
    fontWeight: '900',
  },
  gatewayGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 14,
  },
  gatewayCard: {
    width: CARD_WIDTH,
    borderRadius: 20,
    padding: 12,
    borderWidth: 1.5,
    minHeight: 180,
    justifyContent: 'space-between',
    position: 'relative',
    ...SHADOWS.small,
  },
  cardImageWrap: {
    width: '100%',
    height: 86,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: COLORS.white,
    marginBottom: 8,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardInfo: {
    paddingRight: 24,
  },
  cardTitle: {
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  cardDesc: {
    fontSize: 11,
    color: '#64748B',
    lineHeight: 14,
  },
  arrowCircle: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    width: 26,
    height: 26,
    borderRadius: SIZES.radiusFull,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.small,
  },
  dealsBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FAF5FF',
    borderWidth: 1.5,
    borderColor: '#E9D5FF',
    borderRadius: 20,
    padding: 14,
    marginTop: 4,
    ...SHADOWS.small,
  },
  dealsTagCircle: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: '#F3E8FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  dealsInfo: {
    flex: 1,
    marginRight: 8,
  },
  dealsHeaderTag: {
    fontSize: 9,
    fontWeight: '800',
    color: '#7C3AED',
    letterSpacing: 0.5,
  },
  dealsTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#1E293B',
    marginTop: 1,
  },
  dealsSub: {
    fontSize: 10,
    color: '#64748B',
    marginTop: 1,
  },
  viewOffersPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: SIZES.radiusFull,
    borderWidth: 1,
    borderColor: '#E9D5FF',
    gap: 3,
    ...SHADOWS.small,
  },
  viewOffersText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#7C3AED',
  },
});
