import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  RefreshControl,
  Dimensions,
  Alert,
  Platform,
  StatusBar,
  Vibration,
  BackHandler,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import {
  GET_PRODUCTS,
  GET_CATEGORIES,
  GET_DEALS,
  GET_FEATURED_PRODUCTS,
  GET_BANNERS,
  GET_ME,
  GET_STORE_SETTINGS,
} from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import ProductCard from '../../components/common/ProductCard';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical } from '../../utils/cartHelpers';

const { width } = Dimensions.get('window');

export default function HomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [activeBanner, setActiveBanner] = useState(0);
  const [variantModalProduct, setVariantModalProduct] = useState(null);
  const { setCart, addItem, items = [] } = useCartStore();
  const wishlistCount = useWishlistStore((s) => s.items?.length || 0);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const shoppingCartItems = filterItemsByVertical(items || [], 'shopping');
  const totalShoppingItems = shoppingCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = shoppingCartItems.reduce((sum, i) => sum + ((i?.price || i?.product?.price || 0) * (i?.quantity || 0)), 0);

  const { data: meData } = useQuery(GET_ME, { skip: !isAuthenticated });
  const currentUser = meData?.me;
  const defaultAddress = currentUser?.addresses?.find((a) => a.isDefault) || currentUser?.addresses?.[0];
  const locationLabel = defaultAddress
    ? `${defaultAddress.fullName || defaultAddress.addressLine1 || 'Home'} - ${defaultAddress.city || defaultAddress.state || ''}`
    : 'Select Delivery Location';

  const {
    data: prodData,
    loading: prodLoading,
    refetch: refetchProd,
  } = useQuery(GET_PRODUCTS, {
    variables: { pagination: { page: 1, limit: 10 } },
  });

  const { data: catData, refetch: refetchCat } = useQuery(GET_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });
  const { data: dealsData, refetch: refetchDeals } = useQuery(GET_DEALS);
  const { data: featData, refetch: refetchFeat } = useQuery(GET_FEATURED_PRODUCTS);
  const { data: bannerData, refetch: refetchBanners } = useQuery(GET_BANNERS, {
    variables: { platform: 'mobile' },
  });

  const [addToCartMutation] = useMutation(ADD_TO_CART, {
    onCompleted: (data) => {
      setCart(data.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
    onError: (err) => {
      Alert.alert('Cart Error', err.message);
    },
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addItem(product, 1);
    addToCartMutation({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex !== undefined ? forcedVariantIndex : undefined,
        },
      },
    });
  };

  const onRefresh = () => {
    refetchProd();
    refetchCat();
    refetchDeals();
    refetchFeat();
    refetchBanners();
  };

  const NON_SHOPPING_SLUGS = [
    'food-and-dining',
    'food-delivery',
    'services',
    'home-services',
    'grocery',
  ];

  const isShoppingProduct = (prod) => {
    const catSlug = (prod?.category?.slug || '').toLowerCase();
    const catName = (prod?.category?.name || '').toLowerCase();
    if (NON_SHOPPING_SLUGS.includes(catSlug)) return false;
    if (['grocery', 'food', 'dining', 'services', 'icecream'].some((k) => catName.includes(k) || catSlug.includes(k))) return false;
    return true;
  };

  const categories = (catData?.getCategories || []).filter(
    (c) =>
      !NON_SHOPPING_SLUGS.includes((c.slug || '').toLowerCase()) &&
      !['grocery', 'food', 'services'].some((k) => (c.name || '').toLowerCase().includes(k))
  );

  const products = (prodData?.getProducts?.products || []).filter(isShoppingProduct);
  const deals = (dealsData?.getDeals || []).filter(isShoppingProduct);
  const featured = (featData?.getFeaturedProducts || []).filter(isShoppingProduct);
  const banners = bannerData?.getBanners || [];

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const paddingTop = Platform.OS === 'web'
    ? 14
    : Math.max(insets.top, statusBarHeight, 14);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('shopping')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🛍️</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Shopping Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          Shopping is currently disabled. Please check back later or explore our other services!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Search & Location Top Bar */}
      <View style={[styles.topBar, { paddingTop }]}>
        <View style={styles.brandRow}>
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={() => navigation.navigate('MainTabs')}
            style={{ alignItems: 'flex-start' }}
          >
            <Image
              source={require('../../../assets/logo.png')}
              style={{ width: 52, height: 52, borderRadius: 10 }}
              resizeMode="contain"
            />
          </TouchableOpacity>

          <View style={styles.topActions}>
            <TouchableOpacity
              style={styles.actionIcon}
              onPress={() => navigation.navigate('MainTabs')}
            >
              <Ionicons name="home-outline" size={22} color={COLORS.text} />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionIcon}
              onPress={() => navigation.navigate('Wishlist')}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <Ionicons name="heart-outline" size={22} color={COLORS.text} />
              {wishlistCount > 0 && (
                <View style={[styles.notifBadge, { backgroundColor: '#EC4899' }]}>
                  <Text style={styles.notifBadgeText}>
                    {wishlistCount > 99 ? '99+' : wishlistCount}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.actionIcon}
              onPress={() => navigation.navigate('Notifications')}
            >
              <Ionicons name="notifications-outline" size={22} color={COLORS.text} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Search Input Button */}
        <TouchableOpacity
          style={styles.searchBar}
          activeOpacity={0.9}
          onPress={() => navigation.navigate('Explore')}
        >
          <Ionicons name="search-outline" size={20} color={COLORS.textSecondary} />
          <Text style={styles.searchPlaceholder}>Search for products, brands & more...</Text>
        </TouchableOpacity>

        {/* Location / Delivery Address Pill */}
        <TouchableOpacity
          style={styles.locationStrip}
          activeOpacity={0.8}
          onPress={() => {
            Vibration.vibrate(30);
            if (!isAuthenticated) {
              navigation.navigate('Login', { redirect: 'Addresses' });
            } else {
              navigation.navigate('Addresses');
            }
          }}
        >
          <View style={styles.locationLeftRow}>
            <Ionicons name="location" size={18} color="#EA580C" style={{ marginRight: 6 }} />
            <View style={{ flex: 1 }}>
              <Text style={styles.deliveringLabel}>Delivering to</Text>
              <Text style={styles.locationText} numberOfLines={1}>
                {locationLabel}{' '}
                <Ionicons name="chevron-down" size={13} color={COLORS.textSecondary} />
              </Text>
            </View>
          </View>
          <View style={styles.changeBtn}>
            <Text style={styles.changeBtnText}>Change</Text>
          </View>
        </TouchableOpacity>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={prodLoading} onRefresh={onRefresh} />}
      >
          {banners.length > 0 && (
            <View style={styles.carouselSection}>
              <ScrollView
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onScroll={(e) => {
                  const slide = Math.round(e.nativeEvent.contentOffset.x / (width - SIZES.padding * 2));
                  setActiveBanner(slide);
                }}
                scrollEventThrottle={16}
              >
                {banners.map((banner) => (
                  <TouchableOpacity
                    key={banner._id || banner.id}
                    style={styles.bannerCard}
                    activeOpacity={0.92}
                    onPress={() => navigation.navigate('Deals')}
                  >
                    {banner.image ? (
                      <Image
                        source={{ uri: banner.image }}
                        style={styles.bannerFullImg}
                        resizeMode="cover"
                      />
                    ) : (
                      <View style={[styles.bannerFallback, { backgroundColor: banner.bgHex || COLORS.primary }]}>
                        {banner.tag ? (
                          <View style={styles.bannerTag}>
                            <Text style={styles.bannerTagText}>{banner.tag}</Text>
                          </View>
                        ) : null}
                        <Text style={styles.bannerTitle}>{banner.title}</Text>
                        <Text style={styles.bannerSub}>{banner.subtitle}</Text>
                      </View>
                    )}
                  </TouchableOpacity>
                ))}
              </ScrollView>

              {/* Dots */}
              <View style={styles.dotsRow}>
                {banners.map((_, i) => (
                  <View
                    key={i}
                    style={[styles.dot, activeBanner === i && styles.dotActive]}
                  />
                ))}
              </View>
            </View>
          )}

        {/* Categories Section */}
        {categories.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Shop by Category</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Explore')}>
                <Text style={styles.seeAllText}>See All</Text>
              </TouchableOpacity>
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catList}>
              {categories.map((cat) => (
                <TouchableOpacity
                  key={cat._id}
                  style={styles.catItem}
                  onPress={() => navigation.navigate('CategoryProducts', { slug: cat.slug, name: cat.name })}
                >
                  <View style={styles.catIconWrap}>
                    <Image
                      source={{ uri: cat.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=120' }}
                      style={styles.catImg}
                    />
                  </View>
                  <Text style={styles.catName} numberOfLines={2}>
                    {cat.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Flash Deals / Special Offers */}
        {deals.length > 0 && (
          <View style={styles.section}>
            <View style={[styles.sectionHeader, { alignItems: 'center' }]}>
              <View style={styles.flashTitleRow}>
                <Ionicons name="flash" size={20} color={COLORS.primary} />
                <Text style={styles.sectionTitle}>Flash Deals</Text>
                <View style={styles.timerBadge}>
                  <Text style={styles.timerText}>HOT DEALS</Text>
                </View>
              </View>
              <TouchableOpacity onPress={() => navigation.navigate('Deals')}>
                <Text style={styles.seeAllText}>View All</Text>
              </TouchableOpacity>
            </View>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalProducts}>
              {deals.map((prod) => (
                <View key={prod._id} style={styles.horizontalCardWrap}>
                  <ProductCard product={prod} onAddToCart={handleAddToCart} />
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Featured Products */}
        {featured.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Featured Collections</Text>
            </View>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.horizontalProducts}>
              {featured.map((prod) => (
                <View key={prod._id} style={styles.horizontalCardWrap}>
                  <ProductCard product={prod} onAddToCart={handleAddToCart} />
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        {/* All Products Grid */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Popular Products</Text>
          </View>

          <View style={styles.grid}>
            {products.map((prod) => (
              <ProductCard
                key={prod._id}
                product={prod}
                onAddToCart={handleAddToCart}
              />
            ))}
          </View>
        </View>

        <View style={{ height: 30 }} />
      </ScrollView>

      {/* Quick Variant Selector Bottom Sheet */}
      <VariantSelectModal
        visible={!!variantModalProduct}
        product={variantModalProduct}
        onClose={() => setVariantModalProduct(null)}
        onConfirmAddToCart={(prod, varIdx) => handleAddToCart(prod, varIdx)}
      />

      {/* Floating Bottom Cart Bar */}
      {totalShoppingItems > 0 && (
        <View style={[styles.floatingCart, { bottom: insets.bottom + 12 }]}>
          <View>
            <Text style={styles.floatingCartCount}>{totalShoppingItems} {totalShoppingItems === 1 ? 'ITEM' : 'ITEMS'} ADDED</Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'shopping' })}
            style={styles.viewCartButton}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  topBar: {
    backgroundColor: COLORS.white,
    paddingTop: 12,
    paddingHorizontal: 12,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  logoMini: {
    width: 28,
    height: 28,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  brandName: {
    fontSize: SIZES.lg,
    fontWeight: '900',
    color: COLORS.text,
    letterSpacing: -0.5,
  },
  topActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 2,
    paddingRight: 2,
  },
  actionIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    overflow: 'visible',
  },
  notifBadge: {
    position: 'absolute',
    top: -3,
    right: -3,
    backgroundColor: '#EF4444',
    borderRadius: 9,
    minWidth: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
    zIndex: 10,
    elevation: 4,
  },
  notifBadgeText: {
    color: '#FFF',
    fontSize: 9,
    fontWeight: '900',
    textAlign: 'center',
    includeFontPadding: false,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 12,
    height: 44,
    borderWidth: 1,
    borderColor: COLORS.border,
    gap: 8,
  },
  searchPlaceholder: {
    fontSize: SIZES.sm,
    color: COLORS.textMuted,
  },
  locationStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
    backgroundColor: '#F8FAFC',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  locationLeftRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 8,
  },
  deliveringLabel: {
    fontSize: 9,
    fontWeight: '800',
    color: '#64748B',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  locationText: {
    fontSize: 12,
    color: COLORS.text,
    fontWeight: '700',
    marginTop: 1,
  },
  changeBtn: {
    backgroundColor: '#FFF',
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  changeBtnText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
  carouselSection: {
    padding: SIZES.padding,
  },
  bannerCard: {
    width: width - SIZES.padding * 2,
    height: (width - SIZES.padding * 2) * 0.36,
    borderRadius: SIZES.radiusLg,
    overflow: 'hidden',
    backgroundColor: COLORS.background,
    ...SHADOWS.medium,
  },
  bannerFullImg: {
    width: '100%',
    height: '100%',
  },
  bannerFallback: {
    width: '100%',
    height: '100%',
    padding: SIZES.padding,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bannerTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
    marginBottom: 6,
  },
  bannerTagText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: '800',
  },
  bannerTitle: {
    fontSize: SIZES.lg,
    fontWeight: '900',
    color: COLORS.white,
    lineHeight: 22,
  },
  bannerSub: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
    marginBottom: 10,
  },
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    marginTop: 10,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.border,
  },
  dotActive: {
    width: 18,
    backgroundColor: COLORS.primary,
  },
  section: {
    marginTop: 8,
    marginBottom: 14,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SIZES.padding,
    marginBottom: 12,
  },
  flashTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sectionTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  seeAllText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primary,
  },
  timerBadge: {
    backgroundColor: COLORS.dangerLight,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: SIZES.radiusSm,
  },
  timerText: {
    color: COLORS.danger,
    fontSize: 9,
    fontWeight: '800',
  },
  scroll: {
    paddingBottom: 140,
  },
  catList: {
    paddingHorizontal: SIZES.padding,
    gap: 14,
  },
  catItem: {
    alignItems: 'center',
    width: 80,
  },
  catIconWrap: {
    width: 60,
    height: 60,
    borderRadius: SIZES.radiusLg,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.small,
  },
  catImg: {
    width: '100%',
    height: '100%',
  },
  catName: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 6,
    textAlign: 'center',
  },
  horizontalProducts: {
    paddingHorizontal: SIZES.padding,
    gap: 12,
  },
  horizontalCardWrap: {
    width: 165,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: SIZES.padding,
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: COLORS.primary,
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#DBEAFE',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
});
