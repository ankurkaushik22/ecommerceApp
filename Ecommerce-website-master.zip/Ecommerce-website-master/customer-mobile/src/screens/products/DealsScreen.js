import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Vibration,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_DEALS } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import ProductCard from '../../components/common/ProductCard';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function DealsScreen({ navigation }) {
  const [variantModalProduct, setVariantModalProduct] = useState(null);
  const { setCart, addItem } = useCartStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data, loading } = useQuery(GET_DEALS);

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addItem(product, 1);
    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex !== undefined ? forcedVariantIndex : undefined,
        },
      },
    });
  };

  const deals = data?.getDeals || [];

  return (
    <View style={styles.container}>
      <Header title="Flash Deals & Offers" showBack showCart />

      {loading ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Loading deals...</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          {/* Banner */}
          <View style={styles.banner}>
            <View style={styles.bannerBadge}>
              <Ionicons name="flame" size={16} color={COLORS.danger} />
              <Text style={styles.bannerBadgeText}>MEGA DISCOUNTS</Text>
            </View>
            <Text style={styles.bannerTitle}>Limited Time Deals</Text>
            <Text style={styles.bannerSub}>Save big with verified merchant discounts and GST invoice.</Text>
          </View>

          <View style={styles.grid}>
            {deals.map((prod) => (
              <ProductCard
                key={prod._id}
                product={prod}
                onAddToCart={handleAddToCart}
              />
            ))}
          </View>
        </ScrollView>
      )}

      {/* Quick Variant Selector Bottom Sheet */}
      <VariantSelectModal
        visible={!!variantModalProduct}
        product={variantModalProduct}
        onClose={() => setVariantModalProduct(null)}
        onConfirmAddToCart={(prod, varIdx) => handleAddToCart(prod, varIdx)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    paddingBottom: 30,
  },
  banner: {
    backgroundColor: COLORS.primaryLight,
    borderWidth: 1,
    borderColor: COLORS.primary,
    borderRadius: SIZES.radiusLg,
    padding: SIZES.padding,
    marginBottom: 16,
    ...SHADOWS.small,
  },
  bannerBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.white,
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
    marginBottom: 6,
  },
  bannerBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    color: COLORS.danger,
  },
  bannerTitle: {
    fontSize: SIZES.lg,
    fontWeight: '900',
    color: COLORS.primaryDark,
  },
  bannerSub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
});
