import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Platform,
  StatusBar,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_CATEGORIES } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import ProductCard from '../../components/common/ProductCard';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const SORT_OPTIONS = [
  { label: 'Popular', value: 'popular' },
  { label: 'Price: Low to High', value: 'price_asc' },
  { label: 'Price: High to Low', value: 'price_desc' },
  { label: 'Newest', value: 'newest' },
  { label: 'Top Rated', value: 'rating' },
];

export default function ExploreScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedSort, setSelectedSort] = useState('popular');
  const [minRating, setMinRating] = useState(0);
  const [variantModalProduct, setVariantModalProduct] = useState(null);

  const { setCart, addItem } = useCartStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data: catData } = useQuery(GET_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });

  const { data, loading, refetch } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        search: search.trim() || undefined,
        category: selectedCategory !== 'all' ? selectedCategory : undefined,
        minRating: minRating > 0 ? minRating : undefined,
        sort: selectedSort,
      },
      pagination: { page: 1, limit: 30 },
    },
  });

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addItem(product, 1);
    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex !== undefined ? forcedVariantIndex : undefined,
        },
      },
    });
  };

  const categories = catData?.getCategories || [];
  const products = data?.getProducts?.products || [];

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const paddingTop = Platform.OS === 'web'
    ? 14
    : Math.max(insets.top, statusBarHeight, 14);

  return (
    <View style={styles.container}>
      {/* Search Header */}
      <View style={[styles.header, { paddingTop }]}>
        <View style={styles.searchBox}>
          <Ionicons name="search-outline" size={20} color={COLORS.textSecondary} />
          <TextInput
            style={styles.input}
            placeholder="Search products, brands, categories..."
            placeholderTextColor={COLORS.textMuted}
            value={search}
            onChangeText={setSearch}
            returnKeyType="search"
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color={COLORS.textSecondary} />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      {/* Category Pills Bar */}
      <View style={styles.pillsSection}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillsScroll}>
          <TouchableOpacity
            style={[
              styles.pill,
              selectedCategory === 'all' && styles.pillActive,
            ]}
            onPress={() => setSelectedCategory('all')}
          >
            <Text
              style={[
                styles.pillText,
                selectedCategory === 'all' && styles.pillTextActive,
              ]}
            >
              All Categories
            </Text>
          </TouchableOpacity>

          {categories.map((cat) => (
            <TouchableOpacity
              key={cat._id}
              style={[
                styles.pill,
                selectedCategory === cat.slug && styles.pillActive,
              ]}
              onPress={() => setSelectedCategory(cat.slug)}
            >
              <Text
                style={[
                  styles.pillText,
                  selectedCategory === cat.slug && styles.pillTextActive,
                ]}
              >
                {cat.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Sort / Filter Toolbar */}
      <View style={styles.sortBar}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sortScroll}>
          {SORT_OPTIONS.map((opt) => (
            <TouchableOpacity
              key={opt.value}
              style={[
                styles.sortPill,
                selectedSort === opt.value && styles.sortPillActive,
              ]}
              onPress={() => setSelectedSort(opt.value)}
            >
              <Text
                style={[
                  styles.sortText,
                  selectedSort === opt.value && styles.sortTextActive,
                ]}
              >
                {opt.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Products Grid or Empty/Loading State */}
      {loading ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Finding products...</Text>
        </View>
      ) : products.length === 0 ? (
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>🔍</Text>
          <Text style={styles.emptyTitle}>No matching products</Text>
          <Text style={styles.emptySub}>
            Try changing your search terms or clearing your category filters.
          </Text>
          <TouchableOpacity
            style={styles.clearBtn}
            onPress={() => {
              setSearch('');
              setSelectedCategory('all');
              setSelectedSort('popular');
            }}
          >
            <Text style={styles.clearBtnText}>Reset All Filters</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.grid} showsVerticalScrollIndicator={false}>
          <Text style={styles.resultsCount}>
            Showing {products.length} {products.length === 1 ? 'result' : 'results'}
          </Text>
          <View style={styles.cardsRow}>
            {products.map((prod) => (
              <ProductCard
                key={prod._id}
                product={prod}
                onAddToCart={handleAddToCart}
              />
            ))}
          </View>
        </ScrollView>
      )}

      {/* Quick Variant Selector Bottom Sheet */}
      <VariantSelectModal
        visible={!!variantModalProduct}
        product={variantModalProduct}
        onClose={() => setVariantModalProduct(null)}
        onConfirmAddToCart={(prod, varIdx) => handleAddToCart(prod, varIdx)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    backgroundColor: COLORS.white,
    paddingHorizontal: SIZES.padding,
    paddingTop: 12,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 12,
    height: 46,
    borderWidth: 1,
    borderColor: COLORS.border,
    gap: 8,
  },
  input: {
    flex: 1,
    fontSize: SIZES.sm,
    color: COLORS.text,
  },
  pillsSection: {
    backgroundColor: COLORS.white,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  pillsScroll: {
    paddingHorizontal: SIZES.padding,
    gap: 8,
  },
  pill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  pillActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  pillText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  pillTextActive: {
    color: COLORS.white,
    fontWeight: '700',
  },
  sortBar: {
    backgroundColor: COLORS.white,
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  sortScroll: {
    paddingHorizontal: SIZES.padding,
    gap: 6,
  },
  sortPill: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
  },
  sortPillActive: {
    backgroundColor: COLORS.primaryLight,
  },
  sortText: {
    fontSize: 11,
    color: COLORS.textSecondary,
    fontWeight: '600',
  },
  sortTextActive: {
    color: COLORS.primaryDark,
    fontWeight: '800',
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
    maxWidth: 240,
  },
  clearBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: SIZES.radiusMd,
  },
  clearBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
  grid: {
    padding: SIZES.padding,
    paddingBottom: 40,
  },
  resultsCount: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 12,
  },
  cardsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
});
