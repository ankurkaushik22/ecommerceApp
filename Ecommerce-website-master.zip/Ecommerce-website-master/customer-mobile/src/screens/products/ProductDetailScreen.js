import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ActivityIndicator,
  Alert,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useQuery, useMutation } from '@apollo/client';
import { format } from 'date-fns';
import { GET_PRODUCT_BY_SLUG } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

export default function ProductDetailScreen({ route, navigation }) {
  const { slug, id } = route.params || {};
  const lookupKey = slug || id || '';
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSizeIndex, setSelectedSizeIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);

  // Reset image carousel index to 0 whenever size or color variant changes
  useEffect(() => {
    setActiveImageIndex(0);
  }, [selectedSizeIndex, selectedColorIndex]);

  const { setCart, addItem } = useCartStore();
  const { toggleWishlist, isInWishlist } = useWishlistStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data, loading, error } = useQuery(GET_PRODUCT_BY_SLUG, {
    variables: { slug: lookupKey },
    skip: !lookupKey,
    errorPolicy: 'all',
  });

  const [addToCart, { loading: adding }] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
    },
    onError: (err) => {
      Alert.alert('Cart Error', err.message);
    },
  });

  const product = data?.getProduct || data?.getProductBySlug || route.params?.initialProduct;

  if (loading) return <LoadingSpinner message="Loading product details..." />;
  if (!product) {
    return (
      <View style={styles.notFoundContainer}>
        <Header title="Product Details" showBack />
        <View style={styles.centerBox}>
          <Text style={styles.notFoundEmoji}>🛍️</Text>
          <Text style={styles.notFoundTitle}>Product Not Found</Text>
          <Text style={styles.notFoundSub}>This product may have been moved or is currently unavailable.</Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backBtnText}>Browse Products</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const isFavorited = isInWishlist(product._id);
  const activeVariantOption = product?.variants?.[selectedSizeIndex]?.options?.[selectedColorIndex];
  const price = Number(activeVariantOption?.price ?? product.price ?? 0);
  const comparePrice = Number(product.comparePrice || 0);
  const discountPercent =
    comparePrice > price
      ? Math.round(((comparePrice - price) / comparePrice) * 100)
      : product.dealDiscount || 0;

  const baseImages = product.images?.length
    ? product.images
    : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'];
  const rawThumbs = activeVariantOption?.thumbnails?.length
    ? activeVariantOption.thumbnails
    : (activeVariantOption?.thumbnail ? [activeVariantOption.thumbnail] : []);
  const variantThumbs = rawThumbs.filter(Boolean);
  const images = variantThumbs.length > 0 ? variantThumbs : baseImages;

  const getFlatVariantIdx = () => {
    if (!product.variants?.length) return undefined;
    let idx = 0;
    for (let i = 0; i < selectedSizeIndex && i < product.variants.length; i++) {
      idx += product.variants[i]?.options?.length || 0;
    }
    return idx + selectedColorIndex;
  };

  const handleAddToCart = () => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }
    const flatIdx = getFlatVariantIdx();
    addItem(product, quantity, flatIdx !== undefined ? flatIdx : -1);
    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity,
          variantIndex: flatIdx,
        },
      },
    });
  };

  const handleBuyNow = () => {
    const flatIdx = getFlatVariantIdx();
    if (!isAuthenticated) {
      AsyncStorage.setItem(
        'pending_cart_item',
        JSON.stringify({
          productId: product._id,
          quantity,
          variantIndex: flatIdx,
        })
      ).catch(() => {});

      Alert.alert('Sign In Required', 'Please sign in to continue with checkout.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => navigation.navigate('Login') },
      ]);
      return;
    }
    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity,
          variantIndex: flatIdx,
        },
      },
    }).then(() => {
      navigation.navigate('CartTab');
    });
  };

  return (
    <View style={styles.container}>
      <Header
        title={product.category?.name || 'Product Details'}
        showBack
        showCart
        rightComponent={
          <TouchableOpacity
            onPress={() => toggleWishlist(product)}
            style={styles.headerWishlistBtn}
          >
            <Ionicons
              name={isFavorited ? 'heart' : 'heart-outline'}
              size={22}
              color={isFavorited ? COLORS.danger : COLORS.text}
            />
          </TouchableOpacity>
        }
      />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Image Slider */}
        <View style={styles.gallery}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={(e) => {
              const slide = Math.round(e.nativeEvent.contentOffset.x / width);
              setActiveImageIndex(slide);
            }}
            scrollEventThrottle={16}
          >
            {images.map((img, idx) => (
              <Image key={idx} source={{ uri: img }} style={styles.sliderImage} resizeMode="cover" />
            ))}
          </ScrollView>

          {images.length > 1 && (
            <View style={styles.dotsRow}>
              {images.map((_, i) => (
                <View
                  key={i}
                  style={[styles.dot, activeImageIndex === i && styles.dotActive]}
                />
              ))}
            </View>
          )}

          {discountPercent > 0 && (
            <View style={styles.discountBadge}>
              <Text style={styles.discountText}>{discountPercent}% OFF</Text>
            </View>
          )}
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          {/* Seller / Store Header (Amazon Style) */}
          <View style={styles.storeHeaderRow}>
            <TouchableOpacity
              style={styles.storeLeft}
              activeOpacity={0.8}
              onPress={() => {
                navigation.navigate('SellerStore', {
                  sellerId: product.vendor?._id,
                  sellerName: product.vendor?.name || product.brand || 'Official Store',
                  vendor: product.vendor,
                });
              }}
            >
              <View style={styles.storeLogoBox}>
                {product.vendor?.avatar ? (
                  <Image source={{ uri: product.vendor.avatar }} style={styles.storeLogoImg} />
                ) : (
                  <Ionicons name="storefront" size={18} color={COLORS.primary} />
                )}
              </View>
              <View style={styles.storeTextCol}>
                <Text style={styles.storeNameText} numberOfLines={1}>
                  {product.vendor?.name || product.brand || 'Suaaka Verified Store'}
                </Text>
                <Text style={styles.visitStoreLink}>
                  Visit the store <Ionicons name="chevron-forward" size={11} color="#0284c7" />
                </Text>
              </View>
            </TouchableOpacity>

            <View style={styles.ratingBadgeRight}>
              <View style={styles.ratingBadgeInner}>
                <Text style={styles.ratingScore}>
                  {Number(product.rating?.average ?? product.rating ?? 4.3).toFixed(1)}
                </Text>
                <Ionicons name="star" size={11} color="#f59e0b" />
              </View>
              <Text style={styles.reviewsCountMini}>
                ({product.rating?.count ?? product.numReviews ?? 14})
              </Text>
            </View>
          </View>

          {product.brand && <Text style={styles.brand}>{product.brand}</Text>}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 }}>
            <View
              style={{
                width: 15,
                height: 15,
                borderWidth: 1.5,
                borderColor: product.isVeg !== false ? '#16A34A' : '#DC2626',
                borderRadius: 3,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: '#FFF',
              }}
            >
              <View
                style={{
                  width: 7,
                  height: 7,
                  borderRadius: 3.5,
                  backgroundColor: product.isVeg !== false ? '#16A34A' : '#DC2626',
                }}
              />
            </View>
            <Text
              style={{
                fontSize: 10,
                fontWeight: '900',
                color: product.isVeg !== false ? '#16A34A' : '#DC2626',
                letterSpacing: 0.4,
              }}
            >
              {product.isVeg !== false ? 'PURE VEG' : 'NON-VEG'}
            </Text>
          </View>
          <Text style={styles.title}>{product.name}</Text>

          {/* Ratings */}
          <View style={styles.ratingRow}>
            <View style={styles.ratingBadge}>
              <Text style={styles.ratingBadgeText}>
                {Number(product.rating?.average ?? product.rating ?? 4.5).toFixed(1)}
              </Text>
              <Ionicons name="star" size={12} color={COLORS.white} />
            </View>
            <Text style={styles.ratingCount}>
              {product.rating?.count ?? product.numReviews ?? 0} Ratings & Reviews
            </Text>
          </View>

          {/* Pricing */}
          <View style={styles.priceRow}>
            <Text style={styles.price}>₹{price.toLocaleString('en-IN')}</Text>
            {comparePrice > price && (
              <Text style={styles.comparePrice}>
                ₹{comparePrice.toLocaleString('en-IN')}
              </Text>
            )}
            <Text style={styles.taxInclusive}>Inclusive of all GST taxes</Text>
          </View>

          {/* Stock status */}
          <View style={styles.stockRow}>
            <Ionicons
              name={product.stock > 0 ? 'checkmark-circle' : 'close-circle'}
              size={18}
              color={product.stock > 0 ? COLORS.success : COLORS.danger}
            />
            <Text style={[styles.stockText, { color: product.stock > 0 ? COLORS.success : COLORS.danger }]}>
              {product.stock > 0
                ? product.stock < 5
                  ? `Only ${product.stock} left in stock - order fast!`
                  : 'In Stock (Ready to dispatch)'
                : 'Out of Stock'}
            </Text>
          </View>
        </View>

        {/* Variants */}
        {product.variants?.length > 1 ? (
          <View style={styles.sectionCard}>
            <Text style={styles.sectionHeader}>1. Select Size / Variant</Text>
            <View style={styles.variantList}>
              {product.variants.map((vGroup, sIdx) => {
                const isSelected = selectedSizeIndex === sIdx;
                return (
                  <TouchableOpacity
                    key={sIdx}
                    style={[
                      styles.variantPill,
                      isSelected && styles.variantPillActive,
                    ]}
                    onPress={() => {
                      setSelectedSizeIndex(sIdx);
                      setSelectedColorIndex(0);
                    }}
                  >
                    <Text style={[styles.variantText, isSelected && styles.variantTextActive]}>
                      {vGroup.name}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {product.variants[selectedSizeIndex]?.options?.length > 0 && (
              <View style={{ marginTop: 12 }}>
                <Text style={styles.sectionHeader}>2. Select Color / Option</Text>
                <View style={styles.variantList}>
                  {product.variants[selectedSizeIndex].options.map((opt, cIdx) => {
                    const isSelected = selectedColorIndex === cIdx;
                    return (
                      <TouchableOpacity
                        key={cIdx}
                        style={[
                          styles.variantPill,
                          isSelected && styles.variantPillActive,
                          { flexDirection: 'row', alignItems: 'center', gap: 6 },
                        ]}
                        onPress={() => setSelectedColorIndex(cIdx)}
                      >
                        {opt.thumbnail ? (
                          <Image source={{ uri: opt.thumbnail }} style={{ width: 22, height: 22, borderRadius: 11 }} />
                        ) : null}
                        <Text style={[styles.variantText, isSelected && styles.variantTextActive]}>
                          {opt.label} {opt.price ? `(₹${opt.price})` : ''}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            )}
          </View>
        ) : product.variants?.length === 1 && product.variants[0]?.options?.length > 0 ? (
          <View style={styles.sectionCard}>
            <Text style={styles.sectionHeader}>Select Option / Color</Text>
            <View style={styles.variantList}>
              {product.variants[0].options.map((opt, cIdx) => {
                const isSelected = selectedColorIndex === cIdx;
                return (
                  <TouchableOpacity
                    key={cIdx}
                    style={[
                      styles.variantPill,
                      isSelected && styles.variantPillActive,
                      { flexDirection: 'row', alignItems: 'center', gap: 6 },
                    ]}
                    onPress={() => setSelectedColorIndex(cIdx)}
                  >
                    {opt.thumbnail ? (
                      <Image source={{ uri: opt.thumbnail }} style={{ width: 22, height: 22, borderRadius: 11 }} />
                    ) : null}
                    <Text style={[styles.variantText, isSelected && styles.variantTextActive]}>
                      {opt.label} {opt.price ? `(₹${opt.price})` : ''}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Quantity Stepper */}
        <View style={styles.sectionCard}>
          <View style={styles.qtyRow}>
            <Text style={styles.sectionHeader}>Quantity</Text>
            <View style={styles.stepper}>
              <TouchableOpacity
                style={styles.stepperBtn}
                onPress={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Ionicons name="remove" size={16} color={COLORS.text} />
              </TouchableOpacity>
              <Text style={styles.qtyText}>{quantity}</Text>
              <TouchableOpacity
                style={styles.stepperBtn}
                onPress={() => setQuantity(Math.min(product.stock || 10, quantity + 1))}
              >
                <Ionicons name="add" size={16} color={COLORS.text} />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Description */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionHeader}>Product Details & Specifications</Text>
          <Text style={styles.description}>
            {product.description
              ? product.description.replace(/<[^>]*>/g, '\n').replace(/\n+/g, '\n').trim()
              : 'No additional specifications provided for this product.'}
          </Text>
        </View>

        {/* Seller Info */}
        {product.vendor && (
          <View style={styles.sectionCard}>
            <View style={styles.sellerRow}>
              <View style={styles.sellerIcon}>
                <Ionicons name="storefront" size={20} color={COLORS.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.sellerName}>{product.vendor.name || 'Verified Suaaka Seller'}</Text>
                <Text style={styles.sellerSub}>Verified Merchant • 100% Genuine Guarantee</Text>
              </View>
            </View>
          </View>
        )}

        {/* Customer Reviews Section */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionHeader}>Customer Reviews ({product.reviews?.length || 0})</Text>

          {product.reviews?.length > 0 ? (
            product.reviews.map((rev) => (
              <View key={rev._id} style={styles.reviewItem}>
                <View style={styles.reviewHeader}>
                  <View style={styles.reviewerAvatar}>
                    <Text style={styles.reviewerLetter}>{rev.user?.name?.[0] || 'U'}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.reviewerName}>{rev.user?.name || 'Customer'}</Text>
                    <Text style={styles.reviewDate}>
                      {rev.createdAt ? format(new Date(rev.createdAt), 'dd MMM yyyy') : 'Recent'}
                    </Text>
                  </View>
                  <View style={styles.starPill}>
                    <Ionicons name="star" size={10} color={COLORS.white} />
                    <Text style={styles.starPillText}>{rev.rating}</Text>
                  </View>
                </View>

                {rev.title && <Text style={styles.reviewTitle}>{rev.title}</Text>}
                <Text style={styles.reviewComment}>{rev.comment}</Text>

                {/* Seller Reply if any */}
                {(rev.reply || rev.vendorReply) && (
                  <View style={styles.replyBox}>
                    <Text style={styles.replyTitle}>Seller Response:</Text>
                    <Text style={styles.replyText}>{rev.reply?.comment || rev.vendorReply?.comment}</Text>
                  </View>
                )}
              </View>
            ))
          ) : (
            <Text style={styles.noReviews}>No customer reviews yet. Be the first to review!</Text>
          )}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Sticky Bottom Actions */}
      <View style={styles.bottomBar}>
        <TouchableOpacity
          style={[styles.cartBtn, adding && styles.disabledBtn]}
          onPress={handleAddToCart}
          disabled={adding || product.stock <= 0}
        >
          {adding ? (
            <ActivityIndicator color={COLORS.primary} />
          ) : (
            <>
              <Ionicons name="cart-outline" size={20} color={COLORS.primary} />
              <Text style={styles.cartBtnText}>Add to Cart</Text>
            </>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.buyBtn, product.stock <= 0 && styles.disabledBtn]}
          onPress={handleBuyNow}
          disabled={product.stock <= 0}
        >
          <Text style={styles.buyBtnText}>Buy Now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    paddingBottom: 20,
  },
  headerWishlistBtn: {
    width: 38,
    height: 38,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  gallery: {
    width: '100%',
    height: width * 0.95,
    backgroundColor: COLORS.white,
    position: 'relative',
  },
  sliderImage: {
    width: width,
    height: '100%',
  },
  dotsRow: {
    position: 'absolute',
    bottom: 12,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: SIZES.radiusFull,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  dotActive: {
    width: 16,
    backgroundColor: COLORS.primary,
  },
  discountBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: COLORS.danger,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: SIZES.radiusSm,
  },
  discountText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: '800',
  },
  infoCard: {
    backgroundColor: COLORS.white,
    padding: SIZES.padding,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  storeHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 10,
    marginBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  storeLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 8,
    marginRight: 8,
  },
  storeLogoBox: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  storeLogoImg: {
    width: '100%',
    height: '100%',
  },
  storeTextCol: {
    flex: 1,
  },
  storeNameText: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
  },
  visitStoreLink: {
    fontSize: 11,
    fontWeight: '700',
    color: '#0284c7',
    marginTop: 1,
  },
  ratingBadgeRight: {
    alignItems: 'flex-end',
  },
  ratingBadgeInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
  },
  ratingScore: {
    fontSize: 12,
    fontWeight: '800',
    color: COLORS.text,
  },
  reviewsCountMini: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  brand: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primary,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  title: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
    lineHeight: 24,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 8,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.success,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: SIZES.radiusSm,
    gap: 3,
  },
  ratingBadgeText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '800',
  },
  ratingCount: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 12,
    gap: 10,
    flexWrap: 'wrap',
  },
  price: {
    fontSize: SIZES.title,
    fontWeight: '900',
    color: COLORS.text,
  },
  comparePrice: {
    fontSize: SIZES.md,
    color: COLORS.textMuted,
    textDecorationLine: 'line-through',
  },
  taxInclusive: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  stockRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    gap: 6,
  },
  stockText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
  sectionCard: {
    backgroundColor: COLORS.white,
    padding: SIZES.padding,
    marginTop: 8,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: COLORS.borderLight,
  },
  sectionHeader: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 10,
  },
  variantList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  variantPill: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.background,
  },
  variantPillActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  variantText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.text,
  },
  variantTextActive: {
    color: COLORS.primaryDark,
    fontWeight: '800',
  },
  qtyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusSm,
  },
  stepperBtn: {
    padding: 8,
    backgroundColor: COLORS.background,
  },
  qtyText: {
    paddingHorizontal: 16,
    fontSize: SIZES.md,
    fontWeight: '700',
    color: COLORS.text,
  },
  description: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    lineHeight: 22,
  },
  sellerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  sellerIcon: {
    width: 44,
    height: 44,
    borderRadius: SIZES.radiusMd,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sellerName: {
    fontSize: SIZES.sm,
    fontWeight: '700',
    color: COLORS.text,
  },
  sellerSub: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  reviewItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  reviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  reviewerAvatar: {
    width: 32,
    height: 32,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.secondaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  reviewerLetter: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.secondary,
  },
  reviewerName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  reviewDate: {
    fontSize: 10,
    color: COLORS.textMuted,
  },
  starPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.star,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: SIZES.radiusSm,
    gap: 2,
  },
  starPillText: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: '800',
  },
  reviewTitle: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  reviewComment: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    lineHeight: 18,
  },
  replyBox: {
    backgroundColor: COLORS.background,
    padding: 8,
    borderRadius: SIZES.radiusSm,
    marginTop: 6,
  },
  replyTitle: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.primary,
  },
  replyText: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  noReviews: {
    fontSize: SIZES.xs,
    color: COLORS.textMuted,
    fontStyle: 'italic',
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.white,
    flexDirection: 'row',
    padding: SIZES.padding,
    gap: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.borderLight,
    ...SHADOWS.medium,
  },
  cartBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: COLORS.primaryLight,
    borderWidth: 1,
    borderColor: COLORS.primary,
    borderRadius: SIZES.radiusMd,
    height: 48,
  },
  cartBtnText: {
    color: COLORS.primary,
    fontSize: SIZES.sm,
    fontWeight: '700',
  },
  buyBtn: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radiusMd,
    height: 48,
    ...SHADOWS.glow,
  },
  buyBtnText: {
    color: COLORS.white,
    fontSize: SIZES.sm,
    fontWeight: '700',
  },
  disabledBtn: {
    opacity: 0.5,
  },
  notFoundContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  notFoundEmoji: {
    fontSize: 50,
    marginBottom: 12,
  },
  notFoundTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  notFoundSub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
  },
  backBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: SIZES.radiusMd,
  },
  backBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
});
