import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Vibration,
  Alert,
} from 'react-native';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import ProductCard from '../../components/common/ProductCard';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import FloatingCartBar from '../../components/common/FloatingCartBar';
import { COLORS, SIZES } from '../../constants/theme';

export default function CategoryProductsScreen({ route, navigation }) {
  const { slug, name } = route.params || {};
  const [variantModalProduct, setVariantModalProduct] = useState(null);

  const { setCart, addItem } = useCartStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { category: slug },
      pagination: { page: 1, limit: 30 },
    },
    skip: !slug,
  });

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addItem(product, 1);
    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex !== undefined ? forcedVariantIndex : undefined,
        },
      },
    });
  };

  const products = data?.getProducts?.products || [];

  return (
    <View style={styles.container}>
      <Header title={name || 'Category Products'} showBack showCart />

      {loading ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Loading products...</Text>
        </View>
      ) : products.length === 0 ? (
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>📦</Text>
          <Text style={styles.emptyTitle}>No products found</Text>
          <Text style={styles.emptySub}>
            There are no products listed in this category right now.
          </Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          <Text style={styles.headerInfo}>
            {products.length} {products.length === 1 ? 'product' : 'products'} found
          </Text>
          <View style={styles.grid}>
            {products.map((prod) => (
              <ProductCard
                key={prod._id}
                product={prod}
                onAddToCart={handleAddToCart}
              />
            ))}
          </View>
        </ScrollView>
      )}

      {/* Quick Variant Selector Bottom Sheet */}
      <VariantSelectModal
        visible={!!variantModalProduct}
        product={variantModalProduct}
        onClose={() => setVariantModalProduct(null)}
        onConfirmAddToCart={(prod, varIdx) => handleAddToCart(prod, varIdx)}
      />

      <FloatingCartBar vertical="shopping" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    paddingBottom: 140,
  },
  headerInfo: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 12,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
  },
});
