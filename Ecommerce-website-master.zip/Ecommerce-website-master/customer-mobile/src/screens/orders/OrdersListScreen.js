import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { format } from 'date-fns';
import { GET_ORDERS } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const STATUS_COLORS = {
  placed: { bg: '#FEF3C7', text: '#92400E' },
  accepted: { bg: '#DBEAFE', text: '#1E40AF' },
  pending: { bg: '#FEF3C7', text: '#92400E' },
  confirmed: { bg: '#DBEAFE', text: '#1E40AF' },
  processing: { bg: '#E0E7FF', text: '#3730A3' },
  ready_for_pickup: { bg: '#F3E8FF', text: '#6B21A8' },
  picked_up: { bg: '#F3E8FF', text: '#6B21A8' },
  dispatched: { bg: '#F3E8FF', text: '#6B21A8' },
  out_for_delivery: { bg: '#FFEDD5', text: '#9A3412' },
  delivered: { bg: '#D1FAE5', text: '#065F46' },
  cancelled: { bg: '#FEE2E2', text: '#991B1B' },
  refunded: { bg: '#FEE2E2', text: '#991B1B' },
};

const TIME_FILTERS = [
  { key: 'all', label: 'All Time' },
  { key: '30_days', label: 'Last 30 days' },
  { key: '3_months', label: 'Past 3 months' },
  { key: '2026', label: '2026' },
  { key: '2025', label: '2025' },
  { key: '2024', label: '2024' },
];

const STATUS_FILTERS = [
  { key: 'all', label: 'All Orders' },
  { key: 'open', label: 'Open / In Transit' },
  { key: 'delivered', label: 'Delivered' },
  { key: 'cancelled', label: 'Cancelled / Returned' },
];

export default function OrdersListScreen({ navigation }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilterModal, setShowFilterModal] = useState(false);
  
  // Applied filters
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedTime, setSelectedTime] = useState('all');

  // Staged modal filters
  const [tempStatus, setTempStatus] = useState('all');
  const [tempTime, setTempTime] = useState('all');

  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data, loading, refetch } = useQuery(GET_ORDERS, {
    variables: {
      pagination: { page: 1, limit: 50 },
    },
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const rawOrders = data?.getOrders?.orders || [];

  // Filter and search logic
  const filteredOrders = useMemo(() => {
    return rawOrders.filter((order) => {
      // 1. Status Filter
      if (selectedStatus === 'open') {
        const openStatuses = ['placed', 'accepted', 'pending', 'confirmed', 'processing', 'ready_for_pickup', 'picked_up', 'dispatched', 'out_for_delivery'];
        if (!openStatuses.includes(order.status)) return false;
      } else if (selectedStatus === 'delivered') {
        if (order.status !== 'delivered') return false;
      } else if (selectedStatus === 'cancelled') {
        if (!['cancelled', 'refunded'].includes(order.status)) return false;
      }

      // 2. Time Filter
      if (order.createdAt && selectedTime !== 'all') {
        const orderDate = new Date(order.createdAt);
        const now = new Date();
        if (selectedTime === '30_days') {
          const diffDays = (now - orderDate) / (1000 * 60 * 60 * 24);
          if (diffDays > 30 || diffDays < 0) return false;
        } else if (selectedTime === '3_months') {
          const diffDays = (now - orderDate) / (1000 * 60 * 60 * 24);
          if (diffDays > 90 || diffDays < 0) return false;
        } else if (/^\d{4}$/.test(selectedTime)) {
          if (orderDate.getFullYear() !== parseInt(selectedTime, 10)) return false;
        }
      }

      // 3. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const orderNo = (order.orderNumber || '').toLowerCase();
        const status = (order.status || '').toLowerCase();
        const hasItemMatch = (order.items || []).some((it) =>
          (it.name || '').toLowerCase().includes(q)
        );
        if (!orderNo.includes(q) && !status.includes(q) && !hasItemMatch) {
          return false;
        }
      }

      return true;
    });
  }, [rawOrders, selectedStatus, selectedTime, searchQuery]);

  const openModal = () => {
    setTempStatus(selectedStatus);
    setTempTime(selectedTime);
    setShowFilterModal(true);
  };

  const applyModalFilters = () => {
    setSelectedStatus(tempStatus);
    setSelectedTime(tempTime);
    setShowFilterModal(false);
  };

  if (!isAuthenticated) {
    return (
      <View style={styles.container}>
        <Header title="Your Orders" showBack={true} />
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>📦</Text>
          <Text style={styles.emptyTitle}>Sign in to view Orders</Text>
          <Text style={styles.emptySub}>
            Sign in to track your shipments, view tax invoices, and rate delivered items.
          </Text>
          <TouchableOpacity
            style={styles.signInBtn}
            onPress={() => navigation.navigate('Login', { redirect: 'OrdersList' })}
          >
            <Text style={styles.signInBtnText}>Sign In Now</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const isFilterActive = selectedStatus !== 'all' || selectedTime !== 'all';

  return (
    <View style={styles.container}>
      <Header title="Your Orders" showBack={true} />

      {/* Amazon-Style Search & Filter Row */}
      <View style={styles.searchFilterRow}>
        <View style={styles.searchBarBox}>
          <Ionicons name="search-outline" size={18} color={COLORS.textSecondary} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search all orders"
            placeholderTextColor={COLORS.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Ionicons name="close-circle" size={18} color={COLORS.textSecondary} />
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity
          style={[styles.filterBtn, isFilterActive && styles.filterBtnActive]}
          onPress={openModal}
          activeOpacity={0.8}
        >
          <Text style={[styles.filterBtnText, isFilterActive && styles.filterBtnTextActive]}>
            Filter
          </Text>
          <Ionicons
            name="chevron-forward"
            size={14}
            color={isFilterActive ? COLORS.primary : COLORS.text}
          />
          {isFilterActive && <View style={styles.activeDot} />}
        </TouchableOpacity>
      </View>

      {/* Active Filter Chips (if applied) */}
      {isFilterActive && (
        <View style={styles.activeFiltersChipRow}>
          {selectedStatus !== 'all' && (
            <View style={styles.chip}>
              <Text style={styles.chipText}>
                Status: {STATUS_FILTERS.find((f) => f.key === selectedStatus)?.label}
              </Text>
              <TouchableOpacity onPress={() => setSelectedStatus('all')}>
                <Ionicons name="close" size={14} color={COLORS.primary} />
              </TouchableOpacity>
            </View>
          )}
          {selectedTime !== 'all' && (
            <View style={styles.chip}>
              <Text style={styles.chipText}>
                Time: {TIME_FILTERS.find((f) => f.key === selectedTime)?.label}
              </Text>
              <TouchableOpacity onPress={() => setSelectedTime('all')}>
                <Ionicons name="close" size={14} color={COLORS.primary} />
              </TouchableOpacity>
            </View>
          )}
          <TouchableOpacity
            onPress={() => {
              setSelectedStatus('all');
              setSelectedTime('all');
            }}
          >
            <Text style={styles.clearAllText}>Clear All</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Orders List */}
      {loading && rawOrders.length === 0 ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Fetching orders...</Text>
        </View>
      ) : filteredOrders.length === 0 ? (
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>🛍️</Text>
          <Text style={styles.emptyTitle}>
            {searchQuery || isFilterActive ? 'No matching orders found' : 'No orders yet'}
          </Text>
          <Text style={styles.emptySub}>
            {searchQuery || isFilterActive
              ? 'Try adjusting your search terms or clearing filters.'
              : 'Browse products to make your first purchase!'}
          </Text>
          {searchQuery || isFilterActive ? (
            <TouchableOpacity
              style={styles.browseBtn}
              onPress={() => {
                setSearchQuery('');
                setSelectedStatus('all');
                setSelectedTime('all');
              }}
            >
              <Text style={styles.browseBtnText}>Reset Filters</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              style={styles.browseBtn}
              onPress={() => navigation.navigate('HomeTab')}
            >
              <Text style={styles.browseBtnText}>Explore Shop</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scroll}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} />}
        >
          {filteredOrders.map((order) => {
            const badgeStyle = STATUS_COLORS[order.status] || {
              bg: COLORS.background,
              text: COLORS.text,
            };
            const firstItem = order.items?.[0];

            return (
              <TouchableOpacity
                key={order._id}
                style={styles.orderCard}
                activeOpacity={0.9}
                onPress={() => navigation.navigate('OrderDetail', { orderId: order._id })}
              >
                {/* Header */}
                <View style={styles.orderHeader}>
                  <View style={styles.orderHeaderLeft}>
                    <Text style={styles.orderNumber} numberOfLines={1} ellipsizeMode="tail">
                      Order #{order.orderNumber}
                    </Text>
                    <Text style={styles.orderDate}>
                      Placed on {order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : 'Recent'}
                    </Text>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: badgeStyle.bg }]}>
                    <Text style={[styles.statusBadgeText, { color: badgeStyle.text }]} numberOfLines={1}>
                      {order.status?.replace(/_/g, ' ')?.toUpperCase()}
                    </Text>
                  </View>
                </View>

                {/* Body / Items Preview */}
                <View style={styles.orderBody}>
                  {firstItem && (
                    <Image
                      source={{
                        uri:
                          firstItem.image ||
                          'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=120',
                      }}
                      style={styles.itemThumb}
                    />
                  )}
                  <View style={styles.itemInfo}>
                    <Text style={styles.firstItemName} numberOfLines={1}>
                      {firstItem?.name || 'Order Package'}
                    </Text>
                    {order.items?.length > 1 && (
                      <Text style={styles.moreItemsText}>
                        + {order.items.length - 1} more item(s)
                      </Text>
                    )}
                    <Text style={styles.orderTotal}>
                      Total: ₹{Number(order.total || 0).toLocaleString('en-IN')}
                    </Text>
                  </View>
                </View>

                {/* Footer */}
                <View style={styles.orderFooter}>
                  <Text style={styles.trackText}>View Tracking & Details</Text>
                  <Ionicons name="chevron-forward" size={16} color={COLORS.primary} />
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      )}

      {/* Filter Modal */}
      <Modal visible={showFilterModal} transparent animationType="fade" onRequestClose={() => setShowFilterModal(false)}>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Filter Orders</Text>
              <TouchableOpacity onPress={() => setShowFilterModal(false)}>
                <Ionicons name="close" size={22} color={COLORS.text} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} style={styles.modalBody}>
              {/* Order Status */}
              <Text style={styles.filterSectionTitle}>Order Status</Text>
              <View style={styles.filterOptionsGrid}>
                {STATUS_FILTERS.map((f) => (
                  <TouchableOpacity
                    key={f.key}
                    style={[
                      styles.filterOptionPill,
                      tempStatus === f.key && styles.filterOptionPillActive,
                    ]}
                    onPress={() => setTempStatus(f.key)}
                  >
                    <Text
                      style={[
                        styles.filterOptionText,
                        tempStatus === f.key && styles.filterOptionTextActive,
                      ]}
                    >
                      {f.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Time Period */}
              <Text style={[styles.filterSectionTitle, { marginTop: 18 }]}>Time Period</Text>
              <View style={styles.filterOptionsGrid}>
                {TIME_FILTERS.map((f) => (
                  <TouchableOpacity
                    key={f.key}
                    style={[
                      styles.filterOptionPill,
                      tempTime === f.key && styles.filterOptionPillActive,
                    ]}
                    onPress={() => setTempTime(f.key)}
                  >
                    <Text
                      style={[
                        styles.filterOptionText,
                        tempTime === f.key && styles.filterOptionTextActive,
                      ]}
                    >
                      {f.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>

            {/* Modal Actions */}
            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={styles.resetModalBtn}
                onPress={() => {
                  setTempStatus('all');
                  setTempTime('all');
                }}
              >
                <Text style={styles.resetModalText}>Reset</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.applyModalBtn}
                onPress={applyModalFilters}
              >
                <Text style={styles.applyModalText}>Apply Filters</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  searchFilterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
    gap: 10,
  },
  searchBarBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    paddingHorizontal: 10,
    height: 42,
  },
  searchIcon: {
    marginRight: 6,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: COLORS.text,
    paddingVertical: 0,
  },
  filterBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    height: 42,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    backgroundColor: COLORS.white,
    position: 'relative',
  },
  filterBtnActive: {
    borderColor: COLORS.primary,
    backgroundColor: '#EEF2FF',
  },
  filterBtnText: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  filterBtnTextActive: {
    color: COLORS.primary,
  },
  activeDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.primary,
  },
  activeFiltersChipRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: '#F8FAFC',
    gap: 8,
    flexWrap: 'wrap',
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#EEF2FF',
    borderWidth: 1,
    borderColor: '#C7D2FE',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  chipText: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.primary,
  },
  clearAllText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#EF4444',
    marginLeft: 4,
  },
  scroll: {
    padding: 14,
    gap: 12,
    paddingBottom: 30,
  },
  orderCard: {
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    ...SHADOWS.small,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 8,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  orderHeaderLeft: {
    flex: 1,
    marginRight: 6,
  },
  orderNumber: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
  },
  orderDate: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3.5,
    borderRadius: 8,
    flexShrink: 0,
  },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  orderBody: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 12,
  },
  itemThumb: {
    width: 54,
    height: 54,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
  },
  itemInfo: {
    flex: 1,
  },
  firstItemName: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  moreItemsText: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  orderTotal: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
    marginTop: 4,
  },
  orderFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  trackText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
    gap: 8,
  },
  loadingText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 8,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: 6,
  },
  emptyTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
    maxWidth: 260,
    lineHeight: 18,
  },
  signInBtn: {
    marginTop: 12,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  signInBtnText: {
    color: COLORS.white,
    fontWeight: '700',
    fontSize: 14,
  },
  browseBtn: {
    marginTop: 12,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 12,
  },
  browseBtnText: {
    color: COLORS.white,
    fontWeight: '700',
    fontSize: 13,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: COLORS.white,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    maxHeight: '75%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: COLORS.text,
  },
  modalBody: {
    paddingVertical: 14,
  },
  filterSectionTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  filterOptionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  filterOptionPill: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  filterOptionPillActive: {
    backgroundColor: '#EEF2FF',
    borderColor: COLORS.primary,
  },
  filterOptionText: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  filterOptionTextActive: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  modalFooter: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  resetModalBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  resetModalText: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
  },
  applyModalBtn: {
    flex: 2,
    backgroundColor: COLORS.primary,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  applyModalText: {
    fontSize: 14,
    fontWeight: '800',
    color: COLORS.white,
  },
});
