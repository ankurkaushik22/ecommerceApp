import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function OrderSuccessScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { orderId, orderNumber } = route.params || {};

  const paddingTop = Platform.OS === 'ios' || Platform.OS === 'android'
    ? Math.max(insets.top, 24)
    : 24;

  return (
    <View style={[styles.container, { paddingTop }]}>
      <View style={styles.content}>
        <View style={styles.checkCircle}>
          <Ionicons name="checkmark" size={48} color={COLORS.white} />
        </View>

        <Text style={styles.title}>Order Confirmed!</Text>
        <Text style={styles.subtitle}>
          Thank you for your purchase. We are preparing your shipment with fast dispatch.
        </Text>

        <View style={styles.orderBadge}>
          <Text style={styles.orderLabel}>Order Reference</Text>
          <Text style={styles.orderNumber}>#{orderNumber || orderId}</Text>
        </View>

        <TouchableOpacity
          style={styles.trackBtn}
          onPress={() => {
            const targetId = orderId || orderNumber;
            if (targetId) {
              navigation.replace('OrderDetail', { orderId: targetId });
            } else {
              navigation.replace('OrdersList');
            }
          }}
        >
          <Ionicons name="location-outline" size={20} color={COLORS.white} />
          <Text style={styles.trackBtnText}>Track Order Status</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.homeBtn}
          onPress={() => navigation.replace('MainTabs')}
        >
          <Text style={styles.homeBtnText}>Continue Shopping</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
    justifyContent: 'center',
    padding: SIZES.padding * 1.5,
  },
  content: {
    alignItems: 'center',
  },
  checkCircle: {
    width: 84,
    height: 84,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.success,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    ...SHADOWS.glow,
  },
  title: {
    fontSize: SIZES.title,
    fontWeight: '900',
    color: COLORS.text,
  },
  subtitle: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 20,
    maxWidth: 280,
  },
  orderBadge: {
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'center',
    marginVertical: 24,
  },
  orderLabel: {
    fontSize: 11,
    color: COLORS.textMuted,
    textTransform: 'uppercase',
    fontWeight: '700',
  },
  orderNumber: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.primary,
    marginTop: 2,
  },
  trackBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: COLORS.primary,
    width: '100%',
    height: 50,
    borderRadius: SIZES.radiusMd,
    justifyContent: 'center',
    ...SHADOWS.glow,
  },
  trackBtnText: {
    color: COLORS.white,
    fontSize: SIZES.sm,
    fontWeight: '700',
  },
  homeBtn: {
    paddingVertical: 14,
    marginTop: 10,
  },
  homeBtnText: {
    fontSize: SIZES.sm,
    fontWeight: '700',
    color: COLORS.textSecondary,
  },
});
