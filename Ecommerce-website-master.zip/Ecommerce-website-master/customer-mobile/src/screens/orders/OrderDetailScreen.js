import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Linking,
  BackHandler,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { format } from 'date-fns';
import { GET_ORDER } from '../../graphql/queries';
import { CANCEL_ORDER } from '../../graphql/mutations';
import Header from '../../components/common/Header';
import ReviewModal from '../../components/common/ReviewModal';
import InvoiceModal from '../../components/common/InvoiceModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const TRACKING_STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'We have received your order' },
  { key: 'accepted', label: 'Order Accepted', desc: 'Seller accepted the order' },
  { key: 'processing', label: 'Processing', desc: 'Item is being packed & prepared' },
  { key: 'ready_for_pickup', label: 'Ready for Pickup', desc: 'Package ready for courier' },
  { key: 'picked_up', label: 'Picked Up', desc: 'Courier agent picked up the package' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Courier agent is on the way' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered to your address' },
];

function formatEstimatedDeliveryDisplay(order) {
  if (!order) return 'Estimated delivery: N/A';

  const orderVertical = (
    order?.vertical ||
    order?.items?.[0]?.product?.vertical ||
    order?.items?.[0]?.vertical ||
    'food'
  ).toLowerCase();

  const est = order?.estimatedDelivery;
  const slot = order?.deliverySlot;

  if (orderVertical === 'services') {
    if (slot) return `Scheduled Slot: ${slot}`;
    if (!est) return 'Scheduled Slot: As per selected slot';
  }

  if (!est) {
    if (orderVertical === 'food') return 'Estimated delivery: 25-35 mins';
    if (orderVertical === 'grocery') return 'Estimated delivery: 10-20 mins';
    return `Estimated transit: ${order?.deliveryOption?.estimatedDays || '3-5 Business Days'}`;
  }

  const strVal = String(est).trim();

  if (/\b(min|mins|minute|minutes|hour|hours|day|days|business)\b/i.test(strVal)) {
    return `Estimated delivery: ${strVal}`;
  }

  const dateObj = new Date(isNaN(strVal) ? strVal : Number(strVal));
  if (!isNaN(dateObj.getTime())) {
    const formattedDate = dateObj.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
    const formattedTime = dateObj.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const now = new Date();
    const isToday = dateObj.toDateString() === now.toDateString();

    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const isTomorrow = dateObj.toDateString() === tomorrow.toDateString();

    let readableDateStr = `${formattedDate} at ${formattedTime}`;
    if (isToday) {
      readableDateStr = `Today by ${formattedTime}`;
    } else if (isTomorrow) {
      readableDateStr = `Tomorrow by ${formattedTime}`;
    }

    if (orderVertical === 'food') {
      const createdAtDate = order?.createdAt ? new Date(isNaN(order.createdAt) ? order.createdAt : Number(order.createdAt)) : null;
      const baseTime = createdAtDate && !isNaN(createdAtDate.getTime()) ? createdAtDate.getTime() : now.getTime();
      const diffHours = (dateObj.getTime() - baseTime) / (1000 * 60 * 60);

      if (diffHours > 24) {
        return 'Estimated delivery: 25-35 mins';
      }
      return `Estimated delivery: ${readableDateStr}`;
    }

    if (orderVertical === 'grocery') {
      const createdAtDate = order?.createdAt ? new Date(isNaN(order.createdAt) ? order.createdAt : Number(order.createdAt)) : null;
      const baseTime = createdAtDate && !isNaN(createdAtDate.getTime()) ? createdAtDate.getTime() : now.getTime();
      const diffHours = (dateObj.getTime() - baseTime) / (1000 * 60 * 60);

      if (diffHours > 24) {
        return 'Estimated delivery: 10-20 mins';
      }
      return `Estimated delivery: ${readableDateStr}`;
    }

    return `Estimated delivery: ${readableDateStr}`;
  }

  return `Estimated delivery: ${strVal}`;
}

const STATUS_TO_STEP_INDEX = {
  placed: 0,
  pending: 0,
  payment_pending: 0,

  accepted: 1,
  confirmed: 1,

  processing: 2,
  preparing: 2,
  in_kitchen: 2,
  packed: 2,

  ready_for_pickup: 3,
  ready: 3,

  picked_up: 4,
  dispatched: 4,
  shipped: 4,

  out_for_delivery: 5,
  on_the_way: 5,

  delivered: 6,
  completed: 6,
};

export default function OrderDetailScreen({ route, navigation }) {
  const { orderId, id, orderNumber } = route.params || {};
  const queryId = orderId || id || orderNumber;
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  const handleBackPress = useCallback(() => {
    const state = navigation.getState?.();
    const routes = state?.routes || [];
    const prevRoute = routes.length >= 2 ? routes[routes.length - 2]?.name : null;

    if (
      route?.params?.fromCheckout ||
      prevRoute === 'Cart' ||
      prevRoute === 'CartTab' ||
      prevRoute === 'Checkout' ||
      prevRoute === 'OrderSuccess' ||
      !navigation.canGoBack()
    ) {
      navigation.navigate('MainTabs', { screen: 'HomeTab' });
    } else {
      navigation.goBack();
    }
  }, [navigation, route?.params]);

  useFocusEffect(
    useCallback(() => {
      const onHardwareBack = () => {
        handleBackPress();
        return true;
      };
      const subscription = BackHandler.addEventListener('hardwareBackPress', onHardwareBack);
      return () => subscription.remove();
    }, [handleBackPress])
  );

  const { data, loading, error, refetch } = useQuery(GET_ORDER, {
    variables: { id: queryId },
    skip: !queryId,
    fetchPolicy: 'cache-and-network',
    pollInterval: 4000, // Live poll for delivery partner location updates
  });

  const [cancelOrder, { loading: cancelling }] = useMutation(CANCEL_ORDER, {
    onCompleted: () => {
      Alert.alert('Order Cancelled', 'Your order has been cancelled.');
      refetch();
    },
    onError: (err) => Alert.alert('Error', err.message),
  });

  const order = data?.getOrder;

  if (loading && !order) {
    return (
      <View style={styles.container}>
        <Header title="Order Tracking" showBack onBack={handleBackPress} />
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Fetching order journey...</Text>
        </View>
      </View>
    );
  }

  if (error || !order) {
    return (
      <View style={styles.container}>
        <Header title="Order Tracking" showBack onBack={handleBackPress} />
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>📦</Text>
          <Text style={styles.emptyTitle}>Order Not Found</Text>
          <Text style={styles.emptySub}>
            {error?.message || `No order found with reference "${orderId}".`}
          </Text>
          <TouchableOpacity style={styles.backBtn} onPress={handleBackPress}>
            <Text style={styles.backBtnText}>Back to Orders</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const rawStepIndex = STATUS_TO_STEP_INDEX[order.status];
  const currentStepIndex = rawStepIndex !== undefined
    ? rawStepIndex
    : TRACKING_STEPS.findIndex((s) => s.key === order.status);
  const effectiveStepIndex = currentStepIndex >= 0 ? currentStepIndex : (order.status !== 'cancelled' ? 0 : -1);
  const isDelivered = ['delivered', 'completed'].includes(order.status);
  const isCancelled = order.status === 'cancelled';
  const orderVertical = (
    order?.vertical ||
    order?.items?.[0]?.product?.vertical ||
    order?.items?.[0]?.vertical ||
    ''
  ).toLowerCase();
  const isFoodOrder =
    orderVertical === 'food' ||
    Boolean(order?.isFood) ||
    Boolean(order?.speed?.toLowerCase()?.includes('food'));
  const canCancel =
    !isFoodOrder &&
    ['placed', 'pending', 'accepted', 'processing'].includes(order?.status);

  const getStepUpdate = (stepKey) => {
    if (!order?.trackingUpdates || !Array.isArray(order.trackingUpdates)) return null;
    const matches = order.trackingUpdates.filter((u) => u.status === stepKey);
    return matches.length > 0 ? matches[matches.length - 1] : null;
  };

  const vendorUpdates = (order?.trackingUpdates || []).filter(
    (u) =>
      u.message &&
      !['Order placed successfully', 'Order cancelled', 'Your refund has been processed.'].includes(u.message) &&
      (!u.message.startsWith('Order status updated to ') || Boolean(order.vendorNotes))
  );
  const latestVendorUpdate = vendorUpdates[vendorUpdates.length - 1];
  const displayVendorNote =
    order.vendorNotes ||
    (latestVendorUpdate?.message &&
    !['Order placed successfully', 'Seller accepted the order', 'Order accepted'].includes(latestVendorUpdate.message)
      ? latestVendorUpdate.message
      : null);

  const rawInstructions = order?.deliveryInstructions || order?.notes || order?.tableOrNotes || '';
  const slotMatch = rawInstructions.match(/\[Slot:\s*([^\]]+)\]/i);
  const effectiveDeliverySlot = order?.deliverySlot || (slotMatch ? slotMatch[1].trim() : null);
  const customerInstructions = rawInstructions
    .replace(/\[Slot:\s*[^\]]+\]/gi, '')
    .trim();


  const isRefundInitiated = Boolean(
    order?.status === 'refunded' ||
    order?.paymentStatus === 'refunded' ||
    order?.returnStatus === 'approved' ||
    order?.returnStatus === 'refunded' ||
    (order?.status === 'cancelled' && (order?.paymentStatus === 'paid' || order?.paymentStatus === 'refunded' || order?.paymentMethod !== 'cod')) ||
    order?.trackingUpdates?.some((u) => /refund/i.test(u?.message || u?.status || ''))
  );

  const isDispatchedOrBeyond = Boolean(
    ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(order?.status) ||
    order?.trackingUpdates?.some((u) => ['dispatched', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed'].includes(u?.status))
  );

  const isCod = order?.paymentMethod === 'cod';
  const isPaymentReceived = Boolean(
    isCod
      ? (order?.paymentStatus === 'paid' || ['delivered', 'completed'].includes(order?.status))
      : (order?.paymentStatus === 'paid' || order?.paymentStatus === 'refunded')
  );

  const isCancelledBeforeDispatch = Boolean(order?.status === 'cancelled' && !isDispatchedOrBeyond);
  const isInvoiceGenerated = Boolean(!isCancelledBeforeDispatch && isPaymentReceived && isDispatchedOrBeyond);
  const isOrderSummaryAvailable = Boolean(!isCancelledBeforeDispatch && !isInvoiceGenerated);

  const handleCancelPress = () => {
    Alert.alert(
      'Cancel Order',
      'Are you sure you want to cancel this order? This cannot be undone.',
      [
        { text: 'No, Keep Order', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: () =>
            cancelOrder({
              variables: { orderId: order._id, reason: 'Customer requested cancellation from mobile app' },
            }),
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Header title={`Order #${order.orderNumber}`} showBack onBack={handleBackPress} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Top Header Card */}
        <View style={styles.card}>
          <View style={styles.topInfoRow}>
            <View style={{ flex: 1, paddingRight: 8 }}>
              <Text style={styles.orderTitle}>Order #{order.orderNumber}</Text>
              <Text style={styles.placedDate}>
                Placed on {order.createdAt ? format(new Date(order.createdAt), 'PPP p') : 'Recently'}
                {isInvoiceGenerated ? ` • Invoice #${order.invoiceNumber || `INV-${order.orderNumber}`}` : isOrderSummaryAvailable ? ' • Order Summary' : ''}
              </Text>
            </View>
            <View
              style={[
                styles.statusBadge,
                isDelivered
                  ? styles.badgeSuccess
                  : isCancelled
                  ? styles.badgeDanger
                  : styles.badgeWarning,
              ]}
            >
              <Text
                style={[
                  styles.statusBadgeText,
                  isDelivered
                    ? styles.badgeTextSuccess
                    : isCancelled
                    ? styles.badgeTextDanger
                    : styles.badgeTextWarning,
                ]}
              >
                {order.status?.replace(/_/g, ' ')}
              </Text>
            </View>
          </View>

          {/* Quick Action Buttons */}
          <View style={styles.actionButtonsRow}>
            {isCancelledBeforeDispatch ? (
              <View style={styles.cancelledRefundBadge}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Ionicons name="close-circle" size={14} color="#BE123C" />
                  <Text style={styles.cancelledBadgeTitle}>Order Cancelled</Text>
                </View>
                {isRefundInitiated ? (
                  <Text style={styles.cancelledRefundText}>
                    Refund: ₹{order.total?.toLocaleString('en-IN')} initiated
                  </Text>
                ) : (
                  <Text style={styles.cancelledSubText}>No payment charged</Text>
                )}
              </View>
            ) : isInvoiceGenerated ? (
              <TouchableOpacity
                style={styles.invoiceBtn}
                onPress={() => setShowInvoiceModal(true)}
              >
                <Ionicons name="document-text-outline" size={16} color={COLORS.text} />
                <Text style={styles.invoiceBtnText}>Invoice</Text>
              </TouchableOpacity>
            ) : isOrderSummaryAvailable ? (
              <TouchableOpacity
                style={styles.invoiceBtn}
                onPress={() => setShowInvoiceModal(true)}
              >
                <Ionicons name="document-text-outline" size={16} color={COLORS.text} />
                <Text style={styles.invoiceBtnText}>Order Summary</Text>
              </TouchableOpacity>
            ) : null}

            {isDelivered && (
              <TouchableOpacity
                style={styles.reviewBtn}
                onPress={() => setShowReviewModal(true)}
              >
                <Ionicons name="star" size={16} color={COLORS.white} />
                <Text style={styles.reviewBtnText}>Rate & Review</Text>
              </TouchableOpacity>
            )}

            {canCancel && (
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={handleCancelPress}
                disabled={cancelling}
              >
                <Text style={styles.cancelBtnText}>Cancel Order</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>



        {/* Cancelled Order Banner */}
        {isCancelled && (
          <View style={[styles.card, { backgroundColor: '#FEF2F2', borderColor: '#FECACA', borderWidth: 1 }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 }}>
              <Ionicons name="close-circle" size={20} color="#DC2626" />
              <Text style={{ fontSize: 14, fontWeight: '800', color: '#991B1B' }}>Order Cancelled</Text>
            </View>
            <Text style={{ fontSize: 12, color: '#B91C1C', lineHeight: 18 }}>
              This order has been cancelled. Any payment made will be refunded to your source account within 3-5 business days.
            </Text>
          </View>
        )}

        {/* Live Journey Stepper */}
        {isDelivered ? (
          <View style={[styles.card, { backgroundColor: '#F0FDF4', borderColor: '#BBF7D0', borderWidth: 1, alignItems: 'center', paddingVertical: 24 }]}>
            <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: '#16A34A', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
              <Ionicons name="checkmark-sharp" size={32} color="#FFFFFF" />
            </View>
            <Text style={{ fontSize: 20, fontWeight: '800', color: '#15803D', marginBottom: 4 }}>
              Delivered
            </Text>
            <Text style={{ fontSize: 13, color: '#166534', textAlign: 'center', fontWeight: '500', paddingHorizontal: 16 }}>
              {order.updatedAt ? `Package delivered on ${format(new Date(order.updatedAt), 'PPP p')}` : 'Package has been successfully delivered'}
            </Text>
          </View>
        ) : !isCancelled ? (
          <View style={styles.card}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <Text style={[styles.sectionTitle, { flex: 1, marginRight: 8, marginBottom: 0 }]} numberOfLines={1}>Order Journey & Tracking</Text>
              <View style={{ backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, borderWidth: 1, borderColor: '#FDE68A', flexShrink: 0 }}>
                <Text style={{ fontSize: 10, fontWeight: '800', color: '#92400E', textTransform: 'uppercase' }}>
                  {order.status?.replace(/_/g, ' ')}
                </Text>
              </View>
            </View>

            <View style={styles.stepperContainer}>
              {TRACKING_STEPS.map((step, idx) => {
                const isDone = idx <= effectiveStepIndex;
                const isCurrent = idx === effectiveStepIndex;
                const stepUpdate = getStepUpdate(step.key);
                const hasCustomMsg =
                  Boolean(stepUpdate?.message) &&
                  stepUpdate.message !== step.desc &&
                  !stepUpdate.message.startsWith('Order status updated to ');

                return (
                  <View key={step.key} style={styles.stepItem}>
                    <View style={styles.stepLeft}>
                      <View
                        style={[
                          styles.stepIconWrap,
                          isDone && styles.stepIconWrapDone,
                          isCurrent && styles.stepIconWrapCurrent,
                        ]}
                      >
                        <Ionicons
                          name={isDone ? 'checkmark' : 'time-outline'}
                          size={13}
                          color={isDone ? COLORS.white : COLORS.textMuted}
                        />
                      </View>
                      {idx < TRACKING_STEPS.length - 1 && (
                        <View
                          style={[
                            styles.stepConnector,
                            idx < effectiveStepIndex && styles.stepConnectorDone,
                          ]}
                        />
                      )}
                    </View>

                    <View style={styles.stepContent}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                        <Text
                          style={[
                            styles.stepLabel,
                            isDone && styles.stepLabelDone,
                            isCurrent && styles.stepLabelCurrent,
                          ]}
                        >
                          {step.label}
                        </Text>
                        {isCurrent && (
                          <View style={styles.currentBadge}>
                            <Text style={styles.currentBadgeText}>CURRENT</Text>
                          </View>
                        )}
                      </View>
                      <Text style={[styles.stepDesc, isCurrent && { color: COLORS.textSecondary, fontWeight: '500' }]}>
                        {step.desc}
                      </Text>
                      {isDone && hasCustomMsg && (
                        <View style={{ backgroundColor: '#EFF6FF', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, marginTop: 4, alignSelf: 'flex-start', borderWidth: 1, borderColor: '#BFDBFE' }}>
                          <Text style={{ fontSize: 11, color: '#1D4ED8', fontWeight: '600' }}>
                            💬 {stepUpdate.message}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        ) : null}

        {/* Delivery Executive Details */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Delivery Information</Text>
          {!isDelivered && (
            <View style={styles.deliverySpeedBox}>
              <Text style={styles.speedTitle}>
                Speed: {
                  order.deliveryOption?.name || (
                    orderVertical === 'food' ? 'Express Food Delivery' :
                    orderVertical === 'grocery' ? 'Instant Grocery Delivery' :
                    orderVertical === 'services' ? 'Home Service Booking' :
                    'Standard Delivery'
                  )
                }
              </Text>
              <Text style={styles.speedSub}>
                {formatEstimatedDeliveryDisplay(order)}
              </Text>
              {Boolean(effectiveDeliverySlot) && orderVertical !== 'services' && (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6, paddingTop: 6, borderTopWidth: 1, borderTopColor: '#DBEAFE' }}>
                  <Ionicons name="time-outline" size={15} color="#1D4ED8" />
                  <Text style={{ fontSize: 12, color: '#1E40AF', fontWeight: '700' }}>
                    Delivery Slot: {effectiveDeliverySlot}
                  </Text>
                </View>
              )}
            </View>
          )}

          {order.deliveryAgent || order.deliveryBoy ? (
            <View style={styles.agentCard}>
              <View style={styles.agentAvatar}>
                <Text style={styles.agentAvatarLetter}>
                  {(order.deliveryAgent?.name || order.deliveryBoy?.name)?.[0] || 'D'}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.agentName}>
                  {order.deliveryAgent?.name || order.deliveryBoy?.name}
                </Text>
                <Text style={styles.agentSub}>
                  {
                    orderVertical === 'food' ? 'Food Delivery Partner' :
                    orderVertical === 'grocery' ? 'Grocery Delivery Partner' :
                    orderVertical === 'services' ? 'Assigned Service Professional' :
                    'Assigned Courier Partner'
                  }
                </Text>
              </View>
              {!isDelivered && (
                <TouchableOpacity
                  style={styles.callBtn}
                  onPress={() => {
                    const phoneNum = order.deliveryAgent?.phone || order.deliveryBoy?.phone || '+919876543210';
                    Linking.openURL(`tel:${phoneNum}`);
                  }}
                >
                  <Ionicons name="call" size={16} color={COLORS.white} />
                  <Text style={styles.callBtnText}>Call</Text>
                </TouchableOpacity>
              )}
            </View>
          ) : !isDelivered ? (
            <Text style={styles.noAgentText}>
              {
                orderVertical === 'food' ? 'A delivery partner will be assigned shortly to pick up your meal from the restaurant.' :
                orderVertical === 'grocery' ? 'A delivery partner will be assigned shortly to pick up your groceries.' :
                orderVertical === 'services' ? 'A service professional will be assigned to visit your location.' :
                'A delivery executive will be assigned once the package leaves the hub.'
              }
            </Text>
          ) : null}
        </View>

        {/* Seller / Vendor Note Card */}
        {Boolean(displayVendorNote) && (
          <View style={styles.card}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Ionicons name="storefront" size={18} color="#2563EB" />
                <Text style={[styles.sectionTitle, { color: '#1E40AF', marginBottom: 0 }]}>
                  Seller / Vendor Note
                </Text>
              </View>
              <View style={{ backgroundColor: '#DBEAFE', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 }}>
                <Text style={{ fontSize: 10, fontWeight: '700', color: '#1E40AF' }}>
                  {order.vendor?.name || 'Verified Seller'}
                </Text>
              </View>
            </View>
            <View
              style={{
                backgroundColor: '#EFF6FF',
                padding: 12,
                borderRadius: 10,
                borderWidth: 1,
                borderColor: '#BFDBFE',
              }}
            >
              <Text style={{ fontSize: 13, color: '#1E3A8A', fontWeight: '600', lineHeight: 20 }}>
                {displayVendorNote}
              </Text>
              {latestVendorUpdate?.timestamp && (
                <Text style={{ fontSize: 10, color: '#3B82F6', marginTop: 6, textAlign: 'right' }}>
                  {new Date(latestVendorUpdate.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </Text>
              )}
            </View>
          </View>
        )}

        {/* Delivery / Special Instructions */}
        {Boolean(customerInstructions) && (
          <View style={styles.card}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
              <Ionicons
                name={order.vertical === 'food' ? 'restaurant-outline' : order.vertical === 'services' ? 'build-outline' : 'chatbox-ellipses'}
                size={18}
                color="#D97706"
              />
              <Text style={styles.sectionTitle}>
                {order.vertical === 'food'
                  ? 'Special Instructions & Delivery Notes'
                  : order.vertical === 'services'
                  ? 'Service Instructions & Notes'
                  : 'Delivery Instructions'}
              </Text>
            </View>
            <View
              style={{
                backgroundColor: '#FEF3C7',
                padding: 12,
                borderRadius: 10,
                borderWidth: 1,
                borderColor: '#FDE68A',
              }}
            >
              <Text style={{ fontSize: 13, color: '#92400E', fontWeight: '600', lineHeight: 20 }}>
                {customerInstructions}
              </Text>
            </View>
          </View>
        )}

        {/* Shipping Destination */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Shipping Destination</Text>
          <Text style={styles.destName}>{order.shippingAddress?.fullName}</Text>
          <Text style={styles.destAddress}>
            {order.shippingAddress?.addressLine1} {order.shippingAddress?.addressLine2}
          </Text>
          <Text style={styles.destAddress}>
            {order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}
          </Text>
          <Text style={styles.destPhone}>📞 {order.shippingAddress?.phone}</Text>
        </View>

        {/* Your Review & Rating Section */}
        {((order.reviews && order.reviews.length > 0) || (isDelivered && order.deliveryRating)) && (
          <View style={[styles.card, { backgroundColor: '#FFFBEB', borderColor: '#FDE68A' }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#FEF3C7', paddingBottom: 10, marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Ionicons name="star" size={20} color="#D97706" />
                <View>
                  <Text style={{ fontSize: SIZES.md, fontWeight: '800', color: COLORS.text }}>Your Review & Rating</Text>
                  <Text style={{ fontSize: SIZES.xs, color: COLORS.textSecondary }}>Submitted feedback & replies</Text>
                </View>
              </View>
              {isDelivered && (
                <TouchableOpacity
                  onPress={() => setShowReviewModal(true)}
                  style={{ backgroundColor: '#FEF3C7', paddingHorizontal: 10, paddingVertical: 6, borderRadius: SIZES.radiusSm, borderWidth: 1, borderColor: '#FCD34D' }}
                >
                  <Text style={{ fontSize: SIZES.xs, fontWeight: '700', color: '#92400E' }}>
                    {order.reviews?.length > 0 ? 'Edit Review' : 'Rate Order'}
                  </Text>
                </TouchableOpacity>
              )}
            </View>

            {order.reviews && order.reviews.length > 0 ? (
              order.reviews.map((rev) => (
                <View key={rev._id} style={{ backgroundColor: COLORS.white, borderRadius: SIZES.radiusSm, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#F3F4F6' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Text style={{ fontSize: 10, fontWeight: '800', color: '#92400E', backgroundColor: '#FEF3C7', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, textTransform: 'uppercase' }}>
                        {rev.targetType === 'product' ? '🛍️ Product' : '🚚 Delivery'}
                      </Text>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Ionicons
                            key={s}
                            name={s <= rev.rating ? 'star' : 'star-outline'}
                            size={14}
                            color="#F59E0B"
                          />
                        ))}
                        <Text style={{ fontSize: 11, fontWeight: '700', color: COLORS.text, marginLeft: 4 }}>{rev.rating}.0/5</Text>
                      </View>
                    </View>
                  </View>

                  {rev.title ? <Text style={{ fontSize: SIZES.xs, fontWeight: '700', color: COLORS.text, marginBottom: 2 }}>{rev.title}</Text> : null}
                  <Text style={{ fontSize: SIZES.xs, color: COLORS.textSecondary }}>{rev.comment}</Text>

                  {/* Vendor / Staff Reply */}
                  {rev.reply && (
                    <View style={{ marginTop: 8, backgroundColor: '#EFF6FF', borderWidth: 1, borderColor: '#BFDBFE', borderRadius: SIZES.radiusSm, padding: 10 }}>
                      <Text style={{ fontSize: SIZES.xs, fontWeight: '800', color: '#1E40AF', marginBottom: 2 }}>
                        💬 {rev.reply.repliedBy?.name || 'Seller / Support'} (Official Response):
                      </Text>
                      <Text style={{ fontSize: SIZES.xs, color: '#1E3A8A', fontWeight: '500' }}>
                        {rev.reply.comment}
                      </Text>
                    </View>
                  )}
                </View>
              ))
            ) : (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: COLORS.white, padding: 12, borderRadius: SIZES.radiusSm }}>
                <Ionicons name="star" size={18} color="#F59E0B" />
                <View>
                  <Text style={{ fontSize: SIZES.xs, fontWeight: '700', color: COLORS.text }}>Delivery Partner Rating: 5.0 / 5.0</Text>
                  <Text style={{ fontSize: 11, color: COLORS.textMuted }}>Order completed</Text>
                </View>
              </View>
            )}
          </View>
        )}

        {/* Ordered Items List */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Items in this Package</Text>
          {order.items?.map((item, idx) => (
            <View key={idx} style={styles.itemRow}>
              <Image
                source={{
                  uri:
                    item.image ||
                    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=120',
                }}
                style={styles.itemImg}
              />
              <View style={{ flex: 1 }}>
                <Text style={styles.itemName} numberOfLines={2}>
                  {item.name}
                </Text>
                {item.variantLabel ? (
                  <View style={{ backgroundColor: '#EFF6FF', borderColor: '#BFDBFE', borderWidth: 1, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, alignSelf: 'flex-start', marginTop: 3 }}>
                    <Text style={{ fontSize: 11, fontWeight: '700', color: '#1D4ED8' }}>
                      Variant: {item.variantLabel}
                    </Text>
                  </View>
                ) : null}
                {item.addons && item.addons.length > 0 && (
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 3 }}>
                    {item.addons.map((addon, aIdx) => (
                      <View key={aIdx} style={{ backgroundColor: '#ECFDF5', borderColor: '#A7F3D0', borderWidth: 1, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 }}>
                        <Text style={{ fontSize: 10, fontWeight: '700', color: '#047857' }}>
                          {addon.icon || '➕'} {addon.name} (+₹{addon.price})
                        </Text>
                      </View>
                    ))}
                  </View>
                )}
                {item.instructions ? (
                  <View style={{ backgroundColor: '#EFF6FF', borderColor: '#BFDBFE', borderWidth: 1, paddingHorizontal: 6, paddingVertical: 3, borderRadius: 6, marginTop: 4, alignSelf: 'flex-start' }}>
                    <Text style={{ fontSize: 11, fontStyle: 'italic', color: '#1D4ED8', fontWeight: '600' }}>
                      💬 Note: {item.instructions}
                    </Text>
                  </View>
                ) : null}
                <Text style={styles.itemQtyPrice}>
                  Qty: {item.quantity} × ₹{Number(item.price).toLocaleString('en-IN')}
                </Text>
              </View>
              <Text style={styles.itemTotal}>
                ₹{(Number(item.price) * Number(item.quantity)).toLocaleString('en-IN')}
              </Text>
            </View>
          ))}

          {/* Pricing breakdown */}
          <View style={styles.priceBreakdown}>
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>Subtotal</Text>
              <Text style={styles.breakdownVal}>₹{Number(order.subtotal || 0).toLocaleString('en-IN')}</Text>
            </View>
            {(order.discount > 0 || order.couponCode) && (
              <View style={styles.breakdownRow}>
                <Text style={[styles.breakdownLabel, { color: '#059669', fontWeight: '700' }]}>
                  Discount {order.couponCode ? `(🎟️ ${order.couponCode})` : ''}
                </Text>
                <Text style={[styles.breakdownVal, { color: '#059669', fontWeight: '700' }]}>
                  -₹{Number(order.discount || 0).toLocaleString('en-IN')}
                </Text>
              </View>
            )}
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>GST Tax</Text>
              <Text style={styles.breakdownVal}>₹{Number(order.tax || 0).toLocaleString('en-IN')}</Text>
            </View>
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>Shipping</Text>
              <Text style={styles.breakdownVal}>
                {Number(order.shippingCost || 0) === 0 ? 'FREE' : `₹${order.shippingCost}`}
              </Text>
            </View>
            <View style={styles.breakdownDivider} />
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownTotalLabel}>Total Paid (INR)</Text>
              <Text style={styles.breakdownTotalVal}>₹{Number(order.total || 0).toLocaleString('en-IN')}</Text>
            </View>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Review Modal */}
      <ReviewModal
        visible={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        order={order}
        onReviewSubmitted={refetch}
      />

      {/* Invoice Modal */}
      <InvoiceModal
        visible={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        order={order}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    gap: 12,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  topInfoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  orderTitle: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  placedDate: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
    flexShrink: 0,
  },
  badgeSuccess: { backgroundColor: '#D1FAE5' },
  badgeWarning: { backgroundColor: '#FEF3C7' },
  badgeDanger: { backgroundColor: '#FEE2E2' },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  badgeTextSuccess: { color: '#065F46' },
  badgeTextWarning: { color: '#92400E' },
  badgeTextDanger: { color: '#991B1B' },
  actionButtonsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  cancelledRefundBadge: {
    backgroundColor: '#FFF1F2',
    borderWidth: 1,
    borderColor: '#FECDD3',
    borderRadius: SIZES.radiusSm,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  cancelledBadgeTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: '#BE123C',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  cancelledRefundText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#9F1239',
    marginTop: 2,
  },
  cancelledSubText: {
    fontSize: 10,
    color: '#881337',
    marginTop: 2,
  },
  invoiceBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
  },
  invoiceBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  reviewBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: COLORS.warning,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    ...SHADOWS.small,
  },
  reviewBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.white,
  },
  cancelBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.danger,
    backgroundColor: COLORS.dangerLight,
  },
  cancelBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.danger,
  },
  sectionTitle: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  stepperContainer: {
    paddingLeft: 4,
  },
  stepItem: {
    flexDirection: 'row',
    minHeight: 52,
  },
  stepLeft: {
    alignItems: 'center',
    width: 24,
    marginRight: 12,
  },
  currentBadge: {
    backgroundColor: '#FFEDD5',
    paddingHorizontal: 6,
    paddingVertical: 1.5,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  currentBadgeText: {
    fontSize: 9,
    fontWeight: '800',
    color: '#C2410C',
    letterSpacing: 0.5,
  },
  stepIconWrap: {
    width: 26,
    height: 26,
    borderRadius: SIZES.radiusFull,
    backgroundColor: '#F1F5F9',
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepIconWrapDone: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  stepIconWrapCurrent: {
    backgroundColor: COLORS.primary,
    borderColor: '#FFEDD5',
    borderWidth: 3,
  },
  stepConnector: {
    flex: 1,
    width: 2,
    backgroundColor: '#E2E8F0',
    marginVertical: 2,
  },
  stepConnectorDone: {
    backgroundColor: '#10B981',
  },
  stepContent: {
    flex: 1,
    paddingBottom: 16,
  },
  stepLabel: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.textMuted,
  },
  stepLabelDone: {
    color: COLORS.text,
  },
  stepLabelCurrent: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  stepDesc: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 2,
    lineHeight: 15,
  },
  deliverySpeedBox: {
    backgroundColor: COLORS.primaryLight,
    padding: 10,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: 'rgba(255, 107, 0, 0.2)',
    marginBottom: 10,
  },
  speedTitle: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  speedSub: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  agentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
    gap: 10,
  },
  agentAvatar: {
    width: 36,
    height: 36,
    borderRadius: SIZES.radiusFull,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  agentAvatarLetter: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: '#065F46',
  },
  agentName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  agentSub: {
    fontSize: 10,
    color: COLORS.textMuted,
  },
  callBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.success,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: SIZES.radiusSm,
  },
  callBtnText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.white,
  },
  noAgentText: {
    fontSize: 11,
    color: COLORS.textMuted,
    fontStyle: 'italic',
  },
  destName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  destAddress: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  destPhone: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 3,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    gap: 10,
  },
  itemImg: {
    width: 44,
    height: 44,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
  },
  itemName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  itemQtyPrice: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  itemTotal: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  priceBreakdown: {
    marginTop: 10,
    paddingTop: 8,
  },
  breakdownRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 2,
  },
  breakdownLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  breakdownVal: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.text,
  },
  breakdownDivider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 6,
  },
  breakdownTotalLabel: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  breakdownTotalVal: {
    fontSize: SIZES.sm,
    fontWeight: '900',
    color: COLORS.primary,
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  emptyEmoji: {
    fontSize: 50,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
    maxWidth: 240,
  },
  backBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: SIZES.radiusMd,
  },
  backBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
  trackingMapCard: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLg || 16,
    marginBottom: SIZES.margin,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  trackingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: '#0F172A',
  },
  trackingHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  liveBeaconDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  trackingHeaderTitle: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  trackingHeaderEta: {
    color: '#34D399',
    fontSize: 11,
    fontWeight: '800',
  },
  miniMapCanvas: {
    height: 140,
    backgroundColor: '#E2E8F0',
    position: 'relative',
    overflow: 'hidden',
    justifyContent: 'center',
  },
  miniRoadH: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    height: 14,
    backgroundColor: '#CBD5E1',
  },
  miniRoadV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: '50%',
    width: 14,
    backgroundColor: '#CBD5E1',
  },
  miniRouteLine: {
    position: 'absolute',
    top: 40,
    bottom: 40,
    left: 45,
    right: 45,
    borderWidth: 2.5,
    borderColor: COLORS.primary,
    borderStyle: 'dashed',
    borderRadius: 8,
  },
  miniAgentMarker: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
    ...SHADOWS.light,
  },
  miniDestMarker: {
    position: 'absolute',
    top: 30,
    right: 40,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#FF6B00',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
    ...SHADOWS.light,
  },
  partnerFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: COLORS.surface,
  },
  partnerInfoWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  partnerAvatarCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  partnerName: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
  },
  partnerSubtitle: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  callAgentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
    gap: 4,
  },
  callAgentBtnText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '700',
  },
});
