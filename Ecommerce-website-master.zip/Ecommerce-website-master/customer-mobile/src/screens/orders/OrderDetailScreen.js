import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { format } from 'date-fns';
import { GET_ORDER } from '../../graphql/queries';
import { CANCEL_ORDER } from '../../graphql/mutations';
import Header from '../../components/common/Header';
import ReviewModal from '../../components/common/ReviewModal';
import InvoiceModal from '../../components/common/InvoiceModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const TRACKING_STEPS = [
  { key: 'pending', label: 'Order Placed', desc: 'Received & verified' },
  { key: 'confirmed', label: 'Confirmed', desc: 'Approved for packing' },
  { key: 'dispatched', label: 'Dispatched', desc: 'Left warehouse' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Agent on the way' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered to address' },
];

export default function OrderDetailScreen({ route, navigation }) {
  const { orderId, id, orderNumber } = route.params || {};
  const queryId = orderId || id || orderNumber;
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  const { data, loading, error, refetch } = useQuery(GET_ORDER, {
    variables: { id: queryId },
    skip: !queryId,
    fetchPolicy: 'cache-and-network',
    pollInterval: 4000, // Live poll for delivery partner location updates
  });

  const [cancelOrder, { loading: cancelling }] = useMutation(CANCEL_ORDER, {
    onCompleted: () => {
      Alert.alert('Order Cancelled', 'Your order has been cancelled.');
      refetch();
    },
    onError: (err) => Alert.alert('Error', err.message),
  });

  const order = data?.getOrder;

  if (loading && !order) {
    return (
      <View style={styles.container}>
        <Header title="Order Tracking" showBack />
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Fetching order journey...</Text>
        </View>
      </View>
    );
  }

  if (error || !order) {
    return (
      <View style={styles.container}>
        <Header title="Order Tracking" showBack />
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>📦</Text>
          <Text style={styles.emptyTitle}>Order Not Found</Text>
          <Text style={styles.emptySub}>
            {error?.message || `No order found with reference "${orderId}".`}
          </Text>
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backBtnText}>Back to Orders</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const currentStepIndex = TRACKING_STEPS.findIndex((s) => s.key === order.status);
  const isDelivered = order.status === 'delivered';
  const isCancelled = order.status === 'cancelled';
  const canCancel = ['pending', 'confirmed'].includes(order.status);

  const handleCancelPress = () => {
    Alert.alert(
      'Cancel Order',
      'Are you sure you want to cancel this order? This cannot be undone.',
      [
        { text: 'No, Keep Order', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: () =>
            cancelOrder({
              variables: { orderId: order._id, reason: 'Customer requested cancellation from mobile app' },
            }),
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Header title={`Order #${order.orderNumber}`} showBack />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Top Header Card */}
        <View style={styles.card}>
          <View style={styles.topInfoRow}>
            <View>
              <Text style={styles.orderTitle}>Order #{order.orderNumber}</Text>
              <Text style={styles.placedDate}>
                Placed on {order.createdAt ? format(new Date(order.createdAt), 'PPP p') : 'Recently'}
              </Text>
            </View>
            <View
              style={[
                styles.statusBadge,
                isDelivered
                  ? styles.badgeSuccess
                  : isCancelled
                  ? styles.badgeDanger
                  : styles.badgeWarning,
              ]}
            >
              <Text
                style={[
                  styles.statusBadgeText,
                  isDelivered
                    ? styles.badgeTextSuccess
                    : isCancelled
                    ? styles.badgeTextDanger
                    : styles.badgeTextWarning,
                ]}
              >
                {order.status?.replace(/_/g, ' ')}
              </Text>
            </View>
          </View>

          {/* Quick Action Buttons */}
          <View style={styles.actionButtonsRow}>
            <TouchableOpacity
              style={styles.invoiceBtn}
              onPress={() => setShowInvoiceModal(true)}
            >
              <Ionicons name="document-text-outline" size={16} color={COLORS.text} />
              <Text style={styles.invoiceBtnText}>Tax Invoice</Text>
            </TouchableOpacity>

            {isDelivered && (
              <TouchableOpacity
                style={styles.reviewBtn}
                onPress={() => setShowReviewModal(true)}
              >
                <Ionicons name="star" size={16} color={COLORS.white} />
                <Text style={styles.reviewBtnText}>Rate & Review</Text>
              </TouchableOpacity>
            )}

            {canCancel && (
              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={handleCancelPress}
                disabled={cancelling}
              >
                <Text style={styles.cancelBtnText}>Cancel Order</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Live Delivery Partner Tracking Map Card */}
        {['dispatched', 'out_for_delivery'].includes(order.status) && (
          <View style={styles.trackingMapCard}>
            <View style={styles.trackingHeader}>
              <View style={styles.trackingHeaderLeft}>
                <View style={styles.liveBeaconDot} />
                <Text style={styles.trackingHeaderTitle}>LIVE DELIVERY TRACKING</Text>
              </View>
              <Text style={styles.trackingHeaderEta}>
                {order.status === 'out_for_delivery' ? 'Arriving in ~15 mins' : 'Dispatched from Hub'}
              </Text>
            </View>

            {/* Visual Mini Map Canvas */}
            <View style={styles.miniMapCanvas}>
              <View style={styles.miniRoadH} />
              <View style={styles.miniRoadV} />
              <View style={styles.miniRouteLine} />

              {/* Delivery Agent Marker */}
              <View style={styles.miniAgentMarker}>
                <Ionicons name="bicycle" size={16} color={COLORS.white} />
              </View>

              {/* Customer Destination Marker */}
              <View style={styles.miniDestMarker}>
                <Ionicons name="home" size={14} color={COLORS.white} />
              </View>
            </View>

            {/* Partner Info Footer */}
            <View style={styles.partnerFooter}>
              <View style={styles.partnerInfoWrap}>
                <View style={styles.partnerAvatarCircle}>
                  <Ionicons name="person" size={18} color={COLORS.primary} />
                </View>
                <View>
                  <Text style={styles.partnerName}>
                    {order.deliveryAgent?.name || order.deliveryBoy?.name || 'ShopZone Delivery Partner'}
                  </Text>
                  <Text style={styles.partnerSubtitle}>
                    {order.liveLocation
                      ? `Last updated GPS • ${order.liveLocation.speed || 24} km/h`
                      : 'Assigned & Heading to Destination'}
                  </Text>
                </View>
              </View>

              {(order.deliveryAgent?.phone || order.deliveryBoy?.phone) && (
                <TouchableOpacity
                  style={styles.callAgentBtn}
                  onPress={() =>
                    Linking.openURL(
                      `tel:${(order.deliveryAgent?.phone || order.deliveryBoy?.phone || '').replace(
                        /[^0-9+]/g,
                        ''
                      )}`
                    )
                  }
                >
                  <Ionicons name="call" size={16} color={COLORS.white} />
                  <Text style={styles.callAgentBtnText}>Call</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        )}

        {/* Live Journey Stepper */}
        {!isCancelled && (
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Order Journey & Tracking</Text>
            <View style={styles.stepperContainer}>
              {TRACKING_STEPS.map((step, idx) => {
                const isDone = idx <= currentStepIndex;
                const isCurrent = idx === currentStepIndex;

                return (
                  <View key={step.key} style={styles.stepItem}>
                    <View style={styles.stepLeft}>
                      <View
                        style={[
                          styles.stepIconWrap,
                          isDone && styles.stepIconWrapDone,
                          isCurrent && styles.stepIconWrapCurrent,
                        ]}
                      >
                        <Ionicons
                          name={isDone ? 'checkmark' : 'time-outline'}
                          size={14}
                          color={isDone ? COLORS.white : COLORS.textMuted}
                        />
                      </View>
                      {idx < TRACKING_STEPS.length - 1 && (
                        <View
                          style={[
                            styles.stepConnector,
                            idx < currentStepIndex && styles.stepConnectorDone,
                          ]}
                        />
                      )}
                    </View>

                    <View style={styles.stepContent}>
                      <Text
                        style={[
                          styles.stepLabel,
                          isDone && styles.stepLabelDone,
                          isCurrent && styles.stepLabelCurrent,
                        ]}
                      >
                        {step.label}
                      </Text>
                      <Text style={styles.stepDesc}>{step.desc}</Text>
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Delivery Executive Details */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Delivery Information</Text>
          <View style={styles.deliverySpeedBox}>
            <Text style={styles.speedTitle}>Speed: {order.deliveryOption?.name || 'Standard Courier'}</Text>
            <Text style={styles.speedSub}>Estimated transit: {order.deliveryOption?.estimatedDays || '3-5 Business Days'}</Text>
          </View>

          {order.deliveryAgent || order.deliveryBoy ? (
            <View style={styles.agentCard}>
              <View style={styles.agentAvatar}>
                <Text style={styles.agentAvatarLetter}>
                  {(order.deliveryAgent?.name || order.deliveryBoy?.name)?.[0] || 'D'}
                </Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.agentName}>
                  {order.deliveryAgent?.name || order.deliveryBoy?.name}
                </Text>
                <Text style={styles.agentSub}>Assigned Courier Partner</Text>
              </View>
              <TouchableOpacity
                style={styles.callBtn}
                onPress={() => {
                  const phoneNum = order.deliveryAgent?.phone || order.deliveryBoy?.phone || '+919876543210';
                  Linking.openURL(`tel:${phoneNum}`);
                }}
              >
                <Ionicons name="call" size={16} color={COLORS.white} />
                <Text style={styles.callBtnText}>Call</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <Text style={styles.noAgentText}>
              A delivery executive will be assigned once the package leaves the hub.
            </Text>
          )}
        </View>

        {/* Shipping Destination */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Shipping Destination</Text>
          <Text style={styles.destName}>{order.shippingAddress?.fullName}</Text>
          <Text style={styles.destAddress}>
            {order.shippingAddress?.addressLine1} {order.shippingAddress?.addressLine2}
          </Text>
          <Text style={styles.destAddress}>
            {order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}
          </Text>
          <Text style={styles.destPhone}>📞 {order.shippingAddress?.phone}</Text>
        </View>

        {/* Ordered Items List */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Items in this Package</Text>
          {order.items?.map((item, idx) => (
            <View key={idx} style={styles.itemRow}>
              <Image
                source={{
                  uri:
                    item.image ||
                    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=120',
                }}
                style={styles.itemImg}
              />
              <View style={{ flex: 1 }}>
                <Text style={styles.itemName} numberOfLines={2}>
                  {item.name}
                </Text>
                {item.variantLabel ? (
                  <Text style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>
                    {item.variantLabel}
                  </Text>
                ) : null}
                <Text style={styles.itemQtyPrice}>
                  Qty: {item.quantity} × ₹{Number(item.price).toLocaleString('en-IN')}
                </Text>
              </View>
              <Text style={styles.itemTotal}>
                ₹{(Number(item.price) * Number(item.quantity)).toLocaleString('en-IN')}
              </Text>
            </View>
          ))}

          {/* Pricing breakdown */}
          <View style={styles.priceBreakdown}>
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>Subtotal</Text>
              <Text style={styles.breakdownVal}>₹{Number(order.subtotal || 0).toLocaleString('en-IN')}</Text>
            </View>
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>GST Tax</Text>
              <Text style={styles.breakdownVal}>₹{Number(order.tax || 0).toLocaleString('en-IN')}</Text>
            </View>
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownLabel}>Shipping</Text>
              <Text style={styles.breakdownVal}>
                {Number(order.shippingCost || 0) === 0 ? 'FREE' : `₹${order.shippingCost}`}
              </Text>
            </View>
            <View style={styles.breakdownDivider} />
            <View style={styles.breakdownRow}>
              <Text style={styles.breakdownTotalLabel}>Total Paid (INR)</Text>
              <Text style={styles.breakdownTotalVal}>₹{Number(order.total || 0).toLocaleString('en-IN')}</Text>
            </View>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Review Modal */}
      <ReviewModal
        visible={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        order={order}
        onReviewSubmitted={refetch}
      />

      {/* Invoice Modal */}
      <InvoiceModal
        visible={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        order={order}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    gap: 12,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  topInfoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  orderTitle: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  placedDate: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: SIZES.radiusSm,
  },
  badgeSuccess: { backgroundColor: '#D1FAE5' },
  badgeWarning: { backgroundColor: '#FEF3C7' },
  badgeDanger: { backgroundColor: '#FEE2E2' },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '800',
    textTransform: 'uppercase',
  },
  badgeTextSuccess: { color: '#065F46' },
  badgeTextWarning: { color: '#92400E' },
  badgeTextDanger: { color: '#991B1B' },
  actionButtonsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  invoiceBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
  },
  invoiceBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  reviewBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: COLORS.warning,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    ...SHADOWS.small,
  },
  reviewBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.white,
  },
  cancelBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.danger,
    backgroundColor: COLORS.dangerLight,
  },
  cancelBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.danger,
  },
  sectionTitle: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
    marginBottom: 12,
  },
  stepperContainer: {
    paddingLeft: 4,
  },
  stepItem: {
    flexDirection: 'row',
    minHeight: 52,
  },
  stepLeft: {
    alignItems: 'center',
    width: 24,
    marginRight: 12,
  },
  stepIconWrap: {
    width: 24,
    height: 24,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepIconWrapDone: {
    backgroundColor: COLORS.primary,
  },
  stepIconWrapCurrent: {
    borderWidth: 2,
    borderColor: COLORS.primaryLight,
  },
  stepConnector: {
    flex: 1,
    width: 2,
    backgroundColor: COLORS.border,
    marginVertical: 2,
  },
  stepConnectorDone: {
    backgroundColor: COLORS.primary,
  },
  stepContent: {
    flex: 1,
    paddingBottom: 14,
  },
  stepLabel: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.textMuted,
  },
  stepLabelDone: {
    color: COLORS.text,
  },
  stepLabelCurrent: {
    color: COLORS.primary,
    fontWeight: '800',
  },
  stepDesc: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 1,
  },
  deliverySpeedBox: {
    backgroundColor: COLORS.primaryLight,
    padding: 10,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: 'rgba(255, 107, 0, 0.2)',
    marginBottom: 10,
  },
  speedTitle: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  speedSub: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  agentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 8,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
    gap: 10,
  },
  agentAvatar: {
    width: 36,
    height: 36,
    borderRadius: SIZES.radiusFull,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  agentAvatarLetter: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: '#065F46',
  },
  agentName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  agentSub: {
    fontSize: 10,
    color: COLORS.textMuted,
  },
  callBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.success,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: SIZES.radiusSm,
  },
  callBtnText: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.white,
  },
  noAgentText: {
    fontSize: 11,
    color: COLORS.textMuted,
    fontStyle: 'italic',
  },
  destName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  destAddress: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  destPhone: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 3,
  },
  itemRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
    gap: 10,
  },
  itemImg: {
    width: 44,
    height: 44,
    borderRadius: SIZES.radiusSm,
    backgroundColor: COLORS.background,
  },
  itemName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  itemQtyPrice: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 2,
  },
  itemTotal: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  priceBreakdown: {
    marginTop: 10,
    paddingTop: 8,
  },
  breakdownRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 2,
  },
  breakdownLabel: {
    fontSize: 11,
    color: COLORS.textSecondary,
  },
  breakdownVal: {
    fontSize: 11,
    fontWeight: '600',
    color: COLORS.text,
  },
  breakdownDivider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 6,
  },
  breakdownTotalLabel: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  breakdownTotalVal: {
    fontSize: SIZES.sm,
    fontWeight: '900',
    color: COLORS.primary,
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  emptyEmoji: {
    fontSize: 50,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
    maxWidth: 240,
  },
  backBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: SIZES.radiusMd,
  },
  backBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
  trackingMapCard: {
    backgroundColor: COLORS.surface,
    borderRadius: SIZES.radiusLg || 16,
    marginBottom: SIZES.margin,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  trackingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: '#0F172A',
  },
  trackingHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  liveBeaconDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  trackingHeaderTitle: {
    color: COLORS.white,
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  trackingHeaderEta: {
    color: '#34D399',
    fontSize: 11,
    fontWeight: '800',
  },
  miniMapCanvas: {
    height: 140,
    backgroundColor: '#E2E8F0',
    position: 'relative',
    overflow: 'hidden',
    justifyContent: 'center',
  },
  miniRoadH: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    height: 14,
    backgroundColor: '#CBD5E1',
  },
  miniRoadV: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: '50%',
    width: 14,
    backgroundColor: '#CBD5E1',
  },
  miniRouteLine: {
    position: 'absolute',
    top: 40,
    bottom: 40,
    left: 45,
    right: 45,
    borderWidth: 2.5,
    borderColor: COLORS.primary,
    borderStyle: 'dashed',
    borderRadius: 8,
  },
  miniAgentMarker: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
    ...SHADOWS.light,
  },
  miniDestMarker: {
    position: 'absolute',
    top: 30,
    right: 40,
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#FF6B00',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: COLORS.white,
    ...SHADOWS.light,
  },
  partnerFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: COLORS.surface,
  },
  partnerInfoWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  partnerAvatarCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#D1FAE5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  partnerName: {
    fontSize: 13,
    fontWeight: '800',
    color: COLORS.text,
  },
  partnerSubtitle: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  callAgentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
    gap: 4,
  },
  callAgentBtnText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '700',
  },
});
