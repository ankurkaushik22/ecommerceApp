import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Dimensions,
  Platform,
  StatusBar,
  Modal,
  Vibration,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_ME, GET_STORE_SETTINGS } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

const SERVICE_CATEGORIES = [
  { id: 'all', name: 'All Services', icon: '✨' },
  { id: 'ac', name: 'AC & Appliances', icon: '❄️' },
  { id: 'cleaning', name: 'Home Cleaning', icon: '🧹' },
  { id: 'salon', name: 'Women Salon', icon: '💆‍♀️' },
  { id: 'electrician', name: 'Electrician', icon: '⚡' },
  { id: 'painting', name: 'Painting', icon: '🎨' },
];

const TIME_SLOTS = [
  '09:00 AM - 11:00 AM',
  '11:00 AM - 01:00 PM',
  '02:00 PM - 04:00 PM',
  '04:00 PM - 06:00 PM',
  '06:00 PM - 08:00 PM',
];

const FALLBACK_SERVICES = [
  {
    _id: 'serv-fb-1',
    name: 'AC Power Foam Jet Deep Service',
    slug: 'ac-power-foam-jet-deep-service',
    price: 499,
    comparePrice: 799,
    serviceDuration: '45 mins',
    warranty: '30 Days Service Warranty',
    includedFeatures: [
      'High pressure water jet spray',
      'Foam wash on indoor cooling coils',
      'Outdoor unit dust and debris wash',
      'Gas leak & cooling check',
    ],
    images: ['https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=500'],
    rating: { average: 4.8, count: 3200 },
    description: 'High-pressure water jet and chemical foam cleaning of cooling coil, blower, drain tray, and condenser.',
  },
  {
    _id: 'serv-fb-2',
    name: 'Complete Full Home Deep Cleaning',
    slug: 'complete-full-home-deep-cleaning',
    price: 1999,
    comparePrice: 2999,
    serviceDuration: '4 hours',
    warranty: '100% Quality Guarantee',
    includedFeatures: [
      'Kitchen chimney & countertop degreasing',
      'Bathroom tiles descaling & sanitization',
      'Floor buffing with single-disc machine',
      'Balcony & window grill wiping',
    ],
    images: ['https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=500'],
    rating: { average: 4.9, count: 2150 },
    description: 'Intensive mechanized cleaning including scrubbers, steam sterilization of kitchen tiles and bathroom de-scaling.',
  },
  {
    _id: 'serv-fb-3',
    name: 'O3+ Diamond Glow Facial & Waxing',
    slug: 'o3-diamond-glow-facial-waxing-package',
    price: 999,
    comparePrice: 1599,
    serviceDuration: '90 mins',
    warranty: '100% Sealed Single-Use Kits',
    includedFeatures: [
      'O3+ Diamond Brightening Facial',
      'Rica Waxing for Arms & Underarms',
      'Face Cleanup & Dead Skin Removal',
      'Relaxing 15-min Acupressure Massage',
    ],
    images: ['https://images.unsplash.com/photo-1560066984-138dadb4c035?w=500'],
    rating: { average: 4.8, count: 4100 },
    description: 'Luxury salon service at home by verified female estheticians using single-use sealed kits.',
  },
  {
    _id: 'serv-fb-4',
    name: 'On-Demand Verified Electrician Inspection',
    slug: 'on-demand-verified-electrician-inspection',
    price: 199,
    comparePrice: 299,
    serviceDuration: '60 mins',
    warranty: '30 Days Post-Service Warranty',
    includedFeatures: [
      'Fault diagnosis & circuit testing',
      'Repair of up to 2 switchboards or sockets',
      'Earthing & voltage stability check',
      'Procurement assistance for ISI parts',
    ],
    images: ['https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=500'],
    rating: { average: 4.7, count: 1250 },
    description: 'Doorstep electrical diagnosis for short circuits, tripping MCBs, wiring faults, and switchboard repairs.',
  },
  {
    _id: 'serv-fb-5',
    name: 'Washing Machine Complete Repair',
    slug: 'washing-machine-complete-repair-servicing',
    price: 349,
    comparePrice: 599,
    serviceDuration: '45 mins',
    warranty: '90 Days Spare Parts Warranty',
    includedFeatures: [
      'Motor & transmission belt inspection',
      'Drain pump & inlet valve descaling',
      'Shock absorber & balance ring check',
      'PCB electronic control board testing',
    ],
    images: ['https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=500'],
    rating: { average: 4.6, count: 880 },
    description: 'Comprehensive diagnostic check and repair for top-load and front-load washing machines.',
  },
];

export default function ServicesHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  // Booking Modal State
  const [bookingModalVisible, setBookingModalVisible] = useState(false);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState('Today'); // 'Today', 'Tomorrow', 'Day After'
  const [selectedSlot, setSelectedSlot] = useState(TIME_SLOTS[0]);

  const { items = [], addItem } = useCartStore();
  const { isAuthenticated } = useAuthStore();
  const [addToCartMutation] = useMutation(ADD_TO_CART);

  // Store Settings (Service booking mode & phone)
  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;
  const bookingMode = storeSettings?.serviceBookingMode || 'call_now';
  const contactPhone = storeSettings?.serviceContactPhone || '+91 98765 43210';

  const handleServiceAction = (service) => {
    if (bookingMode === 'call_now') {
      const cleanPhone = contactPhone.replace(/[^\d+]/g, '');
      Linking.openURL(`tel:${cleanPhone}`);
    } else {
      openBookingModal(service);
    }
  };

  // Fetch Services Products
  const { data, loading, refetch } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'services',
        search: search.trim() || undefined,
      },
      pagination: { page: 1, limit: 30 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products;
  const services = (rawProducts && rawProducts.length > 0) ? rawProducts : FALLBACK_SERVICES;

  const filteredServices = useMemo(() => {
    return services.filter((s) => {
      if (selectedCat !== 'all') {
        const q = selectedCat.toLowerCase();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesDesc = s.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesDesc = s.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) return false;
      }
      return true;
    });
  }, [services, selectedCat, search]);

  const openBookingModal = (service) => {
    setSelectedService(service);
    setBookingModalVisible(true);
  };

  const confirmBooking = async () => {
    if (!selectedService) return;
    try {
      Vibration.vibrate(50);
    } catch {}

    const serviceDateFormatted = selectedDate === 'Today'
      ? new Date().toISOString().split('T')[0]
      : selectedDate === 'Tomorrow'
      ? new Date(Date.now() + 86400000).toISOString().split('T')[0]
      : new Date(Date.now() + 172800000).toISOString().split('T')[0];

    addItem({
      _id: selectedService._id,
      name: selectedService.name,
      price: selectedService.price,
      image: selectedService.images?.[0],
      stock: 10,
      vertical: 'services',
      serviceDate: serviceDateFormatted,
      serviceTimeSlot: selectedSlot,
    });

    if (isAuthenticated) {
      try {
        await addToCartMutation({
          variables: { input: { productId: selectedService._id, quantity: 1 } },
        });
      } catch (err) {
        console.warn('Cart sync error:', err.message);
      }
    }

    setBookingModalVisible(false);
    navigation.navigate('Cart');
  };

  const totalItems = (items || []).reduce((sum, i) => sum + (i?.quantity || 0), 0);

  const disabledVerticals = storeSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('services')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🛠️</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Services Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting service bookings. Please check back later or explore our other products!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />

      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={22} color="#1F2937" />
          </TouchableOpacity>
          <View>
            <View style={styles.brandRow}>
              <Text style={styles.brandTitle}>SUAAKA SERVICES</Text>
              <View style={styles.shieldBadge}>
                <Ionicons name="shield-checkmark" size={12} color="#2563EB" />
                <Text style={styles.shieldText}>VERIFIED</Text>
              </View>
            </View>
            <Text style={styles.brandSubtitle}>Home services by certified professionals</Text>
          </View>
        </View>
      </View>

      {/* Search Bar */}
      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Ionicons name="search-outline" size={18} color="#9CA3AF" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search AC repair, deep cleaning, salon..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={16} color="#9CA3AF" />
            </TouchableOpacity>
          ) : null}
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {/* Suaaka Assurance Bar */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.assuranceBarContainer}
          contentContainerStyle={styles.assuranceBarContent}
        >
          <View style={styles.assuranceItem}>
            <Ionicons name="star" size={14} color="#F59E0B" />
            <Text style={styles.assuranceText}>4.8+ Rated Pros</Text>
          </View>
          <View style={styles.assuranceDivider} />
          <View style={styles.assuranceItem}>
            <Ionicons name="shield-checkmark" size={14} color="#2563EB" />
            <Text style={styles.assuranceText}>30-Day Warranty</Text>
          </View>
          <View style={styles.assuranceDivider} />
          <View style={styles.assuranceItem}>
            <Ionicons name="pricetag" size={14} color="#10B981" />
            <Text style={styles.assuranceText}>Fixed Upfront Price</Text>
          </View>
        </ScrollView>

        {/* Hero Banner */}
        <View style={styles.heroBanner}>
          <View style={styles.heroLeft}>
            <View style={styles.heroTag}>
              <Text style={styles.heroTagText}>SUMMER ESSENTIAL</Text>
            </View>
            <Text style={styles.heroTitle}>AC Foam Jet Service</Text>
            <Text style={styles.heroSubtitle}>2X deeper cooling & 30% power savings</Text>
            <TouchableOpacity
              onPress={() => handleServiceAction(services[0])}
              style={styles.heroBookBtn}
            >
              <Text style={styles.heroBookBtnText}>
                {bookingMode === 'call_now' ? 'Call Now' : 'Book at ₹499'}
              </Text>
              <Ionicons name={bookingMode === 'call_now' ? 'call' : 'arrow-forward'} size={14} color="#FFF" />
            </TouchableOpacity>
          </View>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400' }}
            style={styles.heroImage}
          />
        </View>

        {/* Category Pills Carousel */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Explore Categories</Text>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoryScroll}
        >
          {SERVICE_CATEGORIES.map((cat) => {
            const isSelected = selectedCat === cat.id;
            return (
              <TouchableOpacity
                key={cat.id}
                onPress={() => setSelectedCat(cat.id)}
                style={[styles.categoryCard, isSelected && styles.categoryCardActive]}
              >
                <Text style={styles.categoryEmoji}>{cat.icon}</Text>
                <Text style={[styles.categoryName, isSelected && styles.categoryNameActive]}>
                  {cat.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Popular Service Packages */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            Trending Service Packages ({filteredServices.length})
          </Text>
        </View>

        <View style={styles.servicesList}>
          {filteredServices.map((service) => (
            <View key={service._id} style={styles.serviceCard}>
              <View style={styles.serviceCardTop}>
                <View style={styles.serviceInfo}>
                  <View style={styles.serviceTagRow}>
                    {service.rating?.average ? (
                      <View style={styles.ratingBadge}>
                        <Ionicons name="star" size={11} color="#FFF" />
                        <Text style={styles.ratingText}>{service.rating.average.toFixed(1)}</Text>
                        <Text style={styles.ratingCount}>({service.rating.count || 500}+)</Text>
                      </View>
                    ) : null}
                    {service.serviceDuration ? (
                      <View style={styles.durationBadge}>
                        <Ionicons name="time-outline" size={12} color="#4B5563" />
                        <Text style={styles.durationText}>{service.serviceDuration}</Text>
                      </View>
                    ) : null}
                  </View>

                  <Text style={styles.serviceName}>{service.name}</Text>
                  <Text style={styles.serviceDescription} numberOfLines={2}>
                    {service.description}
                  </Text>

                  <View style={styles.priceRow}>
                    <Text style={styles.servicePrice}>₹{service.price}</Text>
                    {service.comparePrice > service.price && (
                      <Text style={styles.serviceComparePrice}>₹{service.comparePrice}</Text>
                    )}
                    {service.warranty && (
                      <View style={styles.warrantyBadge}>
                        <Text style={styles.warrantyText}>🛡️ {service.warranty}</Text>
                      </View>
                    )}
                  </View>
                </View>

                <View style={styles.serviceImgWrapper}>
                  <Image
                    source={{ uri: service.images?.[0] || 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=300' }}
                    style={styles.serviceImg}
                  />
                  <TouchableOpacity
                    onPress={() => handleServiceAction(service)}
                    style={[styles.bookNowBtn, bookingMode === 'call_now' && styles.callNowBtn]}
                  >
                    <Ionicons name={bookingMode === 'call_now' ? 'call' : 'calendar'} size={12} color="#FFF" style={{ marginRight: 4 }} />
                    <Text style={styles.bookNowBtnText}>
                      {bookingMode === 'call_now' ? 'CALL NOW' : 'BOOK NOW'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Inclusions Checklist */}
              {service.includedFeatures && service.includedFeatures.length > 0 && (
                <View style={styles.inclusionsBox}>
                  <Text style={styles.inclusionsTitle}>What's included:</Text>
                  <View style={styles.inclusionsGrid}>
                    {service.includedFeatures.map((feat, idx) => (
                      <View key={idx} style={styles.inclusionItem}>
                        <Ionicons name="checkmark-circle" size={14} color="#16A34A" />
                        <Text style={styles.inclusionText} numberOfLines={1}>{feat}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </View>
          ))}
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>

      {/* Appointment Slot Booking Modal */}
      <Modal
        visible={bookingModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setBookingModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={[styles.modalSheet, { paddingBottom: insets.bottom + 16 }]}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Select Appointment Slot</Text>
                <Text style={styles.modalSubtitle}>{selectedService?.name}</Text>
              </View>
              <TouchableOpacity
                onPress={() => setBookingModalVisible(false)}
                style={styles.modalCloseBtn}
              >
                <Ionicons name="close" size={20} color="#4B5563" />
              </TouchableOpacity>
            </View>

            {/* Date Selection */}
            <Text style={styles.modalSectionTitle}>Choose Date</Text>
            <View style={styles.dateSelectorRow}>
              {['Today', 'Tomorrow', 'Day After'].map((d) => {
                const isSelected = selectedDate === d;
                return (
                  <TouchableOpacity
                    key={d}
                    onPress={() => setSelectedDate(d)}
                    style={[styles.dateCard, isSelected && styles.dateCardActive]}
                  >
                    <Ionicons
                      name="calendar"
                      size={18}
                      color={isSelected ? '#2563EB' : '#6B7280'}
                    />
                    <Text style={[styles.dateText, isSelected && styles.dateTextActive]}>
                      {d}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Time Slots */}
            <Text style={styles.modalSectionTitle}>Choose Arrival Time Slot</Text>
            <View style={styles.slotsGrid}>
              {TIME_SLOTS.map((slot) => {
                const isSelected = selectedSlot === slot;
                return (
                  <TouchableOpacity
                    key={slot}
                    onPress={() => setSelectedSlot(slot)}
                    style={[styles.slotCard, isSelected && styles.slotCardActive]}
                  >
                    <Text style={[styles.slotText, isSelected && styles.slotTextActive]}>
                      {slot}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Booking Summary & Confirm */}
            <View style={styles.modalFooter}>
              <View>
                <Text style={styles.footerPriceLabel}>Total Payable</Text>
                <Text style={styles.footerPrice}>₹{selectedService?.price}</Text>
              </View>
              <TouchableOpacity onPress={confirmBooking} style={styles.confirmBookingBtn}>
                <Text style={styles.confirmBookingBtnText}>Confirm Slot & Proceed</Text>
                <Ionicons name="arrow-forward" size={16} color="#FFF" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  backButton: {
    padding: 6,
    marginRight: 8,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  brandTitle: {
    fontSize: 14,
    fontWeight: '900',
    color: '#0F172A',
    letterSpacing: 0.5,
  },
  shieldBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  shieldText: {
    fontSize: 9,
    fontWeight: '800',
    color: '#2563EB',
  },
  brandSubtitle: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 1,
  },
  cartButton: {
    position: 'relative',
    padding: 6,
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#2563EB',
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  searchSection: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFF',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 14,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#0F172A',
    fontWeight: '500',
  },
  scrollContent: {
    paddingBottom: 24,
  },
  assuranceBarContainer: {
    marginHorizontal: 16,
    marginTop: 12,
    backgroundColor: '#FFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    ...SHADOWS.light,
  },
  assuranceBarContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 14,
    gap: 12,
  },
  assuranceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  assuranceText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#334155',
  },
  assuranceDivider: {
    width: 1,
    height: 14,
    backgroundColor: '#CBD5E1',
  },
  heroBanner: {
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 20,
    backgroundColor: '#1E293B',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 18,
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  heroLeft: {
    flex: 1,
    paddingRight: 10,
  },
  heroTag: {
    backgroundColor: '#3B82F6',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  heroTagText: {
    color: '#FFF',
    fontSize: 9,
    fontWeight: '900',
  },
  heroTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
    lineHeight: 24,
    marginBottom: 2,
  },
  heroSubtitle: {
    color: '#94A3B8',
    fontSize: 11,
    marginTop: 2,
    lineHeight: 16,
  },
  heroBookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563EB',
    alignSelf: 'flex-start',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    marginTop: 10,
    gap: 6,
  },
  heroBookBtnText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '800',
  },
  heroImage: {
    width: 90,
    height: 90,
    borderRadius: 16,
  },
  sectionHeader: {
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A',
  },
  categoryScroll: {
    paddingHorizontal: 16,
    gap: 10,
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 6,
  },
  categoryCardActive: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
    borderWidth: 1.5,
  },
  categoryEmoji: {
    fontSize: 18,
  },
  categoryName: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
  },
  categoryNameActive: {
    color: '#2563EB',
    fontWeight: '800',
  },
  servicesList: {
    paddingHorizontal: 16,
    gap: 16,
  },
  serviceCard: {
    backgroundColor: '#FFF',
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    ...SHADOWS.light,
  },
  serviceCardTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  serviceInfo: {
    flex: 1,
    paddingRight: 12,
  },
  serviceTagRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#16A34A',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    gap: 3,
  },
  ratingText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '800',
  },
  ratingCount: {
    color: '#DCFCE7',
    fontSize: 9,
    fontWeight: '600',
  },
  durationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    gap: 3,
  },
  durationText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#475569',
  },
  serviceName: {
    fontSize: 15,
    fontWeight: '800',
    color: '#0F172A',
  },
  serviceDescription: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 4,
    lineHeight: 16,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    flexWrap: 'wrap',
  },
  servicePrice: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A',
  },
  serviceComparePrice: {
    fontSize: 12,
    color: '#94A3B8',
    textDecorationLine: 'line-through',
  },
  warrantyBadge: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  warrantyText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#2563EB',
  },
  serviceImgWrapper: {
    alignItems: 'center',
    width: 100,
  },
  serviceImg: {
    width: 100,
    height: 100,
    borderRadius: 14,
    backgroundColor: '#F1F5F9',
  },
  bookNowBtn: {
    position: 'absolute',
    bottom: -10,
    backgroundColor: '#2563EB',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    ...SHADOWS.medium,
  },
  callNowBtn: {
    backgroundColor: '#16A34A',
  },
  bookNowBtnText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '900',
  },
  inclusionsBox: {
    marginTop: 14,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  inclusionsTitle: {
    fontSize: 11,
    fontWeight: '800',
    color: '#334155',
    marginBottom: 6,
  },
  inclusionsGrid: {
    gap: 4,
  },
  inclusionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  inclusionText: {
    fontSize: 11,
    color: '#475569',
    fontWeight: '500',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalSheet: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 17,
    fontWeight: '900',
    color: '#0F172A',
  },
  modalSubtitle: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '600',
    marginTop: 2,
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalSectionTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#334155',
    marginBottom: 10,
    marginTop: 12,
  },
  dateSelectorRow: {
    flexDirection: 'row',
    gap: 10,
  },
  dateCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    backgroundColor: '#F8FAFC',
  },
  dateCardActive: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
    borderWidth: 2,
  },
  dateText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
  },
  dateTextActive: {
    color: '#2563EB',
    fontWeight: '800',
  },
  slotsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  slotCard: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#CBD5E1',
    backgroundColor: '#F8FAFC',
  },
  slotCardActive: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
    borderWidth: 2,
  },
  slotText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#475569',
  },
  slotTextActive: {
    color: '#2563EB',
    fontWeight: '800',
  },
  modalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 24,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  footerPriceLabel: {
    fontSize: 11,
    color: '#64748B',
    fontWeight: '700',
  },
  footerPrice: {
    fontSize: 18,
    fontWeight: '900',
    color: '#0F172A',
  },
  confirmBookingBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2563EB',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 6,
  },
  confirmBookingBtnText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
});
