import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import {
  GET_PRODUCTS,
  GET_ME,
  GET_STORE_SETTINGS,
  GET_BANNERS,
  GET_CATEGORIES,
  GET_CART,
} from '../../graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical, getProductAvailableStock } from '../../utils/cartHelpers';
import VariantSelectModal from '../../components/common/VariantSelectModal';

const { width } = Dimensions.get('window');
const GRID_PADDING = 16;
const GRID_GAP = 10;
const COL_WIDTH_4 = Math.floor((width - (GRID_PADDING * 2) - (GRID_GAP * 3)) / 4);
const CARD_WIDTH_3 = Math.floor((width - (GRID_PADDING * 2) - (GRID_GAP * 2)) / 3);

const PASTEL_BG_COLORS = [
  '#E0F2FE', // soft blue
  '#DCFCE7', // soft green
  '#FEF3C7', // soft yellow/amber
  '#FCE7F3', // soft pink
  '#F3E8FF', // soft purple
  '#FFEDD5', // soft orange
  '#CCFBF1', // soft teal
  '#E0E7FF', // soft indigo
];

const DEFAULT_CATEGORY_IMAGES = {
  'vegetables': 'https://images.unsplash.com/photo-1610832958506-aa56368176cf?w=300',
  'fruits': 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=300',
  'atta': 'https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=300',
  'rice': 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=300',
  'oil': 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=300',
  'dairy': 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=300',
  'milk': 'https://images.unsplash.com/photo-1563636619-e9143da7973b?w=300',
  'bakery': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=300',
  'biscuits': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=300',
  'drinks': 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=300',
  'chips': 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=300',
  'snacks': 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=300',
  'tea': 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=300',
  'coffee': 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=300',
  'instant': 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=300',
  'meat': 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=300',
  'chicken': 'https://images.unsplash.com/photo-1587593810167-a84920ea0781?w=300',
  'appliances': 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?w=300',
};

const ALL_GROCERY_FALLBACKS = [
  {
    _id: 'g-fizzy-1',
    name: 'Diet Coke Diets & Lights',
    slug: 'diet-coke-diets-lights',
    unitMeasure: '330 ml',
    optionsCount: 2,
    price: 50,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.8, count: 210 },
  },
  {
    _id: 'g-fizzy-2',
    name: 'Thums Up Soft Drink',
    slug: 'thums-up-soft-drink-750ml',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 39,
    comparePrice: 40,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.9, count: 340 },
  },
  {
    _id: 'g-pop-1',
    name: 'Organic Robusta Bananas',
    slug: 'organic-robusta-bananas',
    unitMeasure: '500g Pack',
    optionsCount: null,
    price: 39,
    comparePrice: 59,
    discountTag: '33% OFF',
    isVeg: true,
    tagBadge: 'Organic',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.8, count: 85 },
  },
  {
    _id: 'g-pop-2',
    name: 'Farm Fresh Pure Whole Cow Milk',
    slug: 'farm-fresh-pure-whole-cow-milk',
    unitMeasure: '1 Litre Pouch',
    optionsCount: null,
    price: 65,
    comparePrice: 75,
    discountTag: '13% OFF',
    isVeg: true,
    tagBadge: 'Fresh',
    deliveryMins: '10 mins',
    images: ['https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400'],
    category: { slug: 'dairy', name: 'Dairy, Bread & Eggs' },
    rating: { average: 4.9, count: 320 },
  },
  {
    _id: 'g-pop-3',
    name: 'Artisan Sourdough Country Loaf',
    slug: 'artisan-sourdough-country-loaf',
    unitMeasure: '400g Loaf',
    optionsCount: null,
    price: 99,
    comparePrice: 130,
    discountTag: '23% OFF',
    isVeg: true,
    tagBadge: 'Freshly Baked',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=400'],
    category: { slug: 'bakery', name: 'Bakery & Biscuits' },
    rating: { average: 4.7, count: 64 },
  },
];

export default function GroceryHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const scrollViewRef = useRef(null);

  const { user, isAuthenticated } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTopTab, setSelectedTopTab] = useState('all');

  const items = useCartStore((s) => s.items || []);
  const setCart = useCartStore((s) => s.setCart);
  const addItem = useCartStore((s) => s.addItem);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const { toggleWishlist, isInWishlist } = useWishlistStore();

  const groceryCartItems = filterItemsByVertical(items || [], 'grocery');
  const totalGroceryItems = groceryCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = groceryCartItems.reduce(
    (sum, i) => sum + (i?.price || i?.product?.price || 0) * (i?.quantity || 0),
    0
  );

  const { data: meData } = useQuery(GET_ME, { skip: !isAuthenticated });

  const { data: cartData, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  useEffect(() => {
    if (cartData?.getCart) {
      setCart(cartData.getCart);
    }
  }, [cartData, setCart]);

  useFocusEffect(
    useCallback(() => {
      if (isAuthenticated) {
        refetchCart?.();
      }
    }, [isAuthenticated, refetchCart])
  );

  const { data: productsData, loading: productsLoading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vertical: 'grocery' },
      pagination: { page: 1, limit: 50 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: bannerData } = useQuery(GET_BANNERS, {
    variables: { platform: 'mobile', vertical: 'grocery' },
    fetchPolicy: 'cache-and-network',
  });

  const { data: catData, loading: catLoading } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'grocery' },
    fetchPolicy: 'cache-and-network',
  });

  const dbCategories = catData?.getCategories || [];

  const groceryBanners = useMemo(() => {
    const fetched = bannerData?.getBanners || [];
    const active = fetched.filter(
      (b) => b.isActive !== false && (b.vertical === 'grocery' || b.vertical === 'all' || !b.vertical)
    );
    if (active.length > 0) return active;
    return [
      {
        _id: 'g-hero-fb-1',
        title: 'Fresh Groceries Daily',
        subtitle: 'Get superfast 10-minute delivery to your doorstep',
        tag: 'INSTANT DELIVERY',
        image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800',
        bgHex: '#059669',
      },
    ];
  }, [bannerData]);

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [variantModalProduct, setVariantModalProduct] = useState(null);

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      if (res?.addToCart) setCart(res.addToCart);
      Vibration.vibrate(50);
    },
    onError: (err, clientOptions) => {
      const pId = clientOptions?.variables?.input?.productId || clientOptions?.variables?.productId;
      if (pId) {
        useCartStore.getState().removeItem(pId);
      }
      refetchCart?.();
      Alert.alert('Out of Stock 🔴', err?.message || 'This item is out of stock.');
    },
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      if (res?.updateCartItem) setCart(res.updateCartItem);
    },
    onError: (err) => {
      refetchCart?.();
      Alert.alert('Cart Error 🔴', err?.message || 'Unable to update cart.');
    },
  });

  const serverProducts = productsData?.getProducts?.products || [];

  const allProducts = useMemo(() => {
    return serverProducts;
  }, [serverProducts]);

  const filteredProducts = useMemo(() => {
    return allProducts.filter((item) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const mName = (item.name || '').toLowerCase().includes(q);
        const mCat = (item.category?.name || '').toLowerCase().includes(q);
        const mUnit = (item.unitMeasure || '').toLowerCase().includes(q);
        if (!mName && !mCat && !mUnit) return false;
      }

      if (selectedTopTab !== 'all') {
        const cName = (item.category?.name || '').toLowerCase();
        const cSlug = (item.category?.slug || item.category?._id || '').toLowerCase();
        const target = selectedTopTab.toLowerCase();
        const matches = cName.includes(target) || cSlug.includes(target) || (item.name || '').toLowerCase().includes(target);
        if (!matches) return false;
      }
      return true;
    });
  }, [allProducts, searchQuery, selectedTopTab]);

  const currentUser = meData?.me || user;
  const currentAddress = currentUser?.addresses?.find((a) => a.isDefault) || currentUser?.addresses?.[0] || {
    addressLine1: '123 Maple St',
  };

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('grocery')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🥦</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Grocery Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting grocery orders. Please check back later!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Top filter bar tabs fetched dynamically from Admin categories
  const topTabs = useMemo(() => {
    const defaultAll = { id: 'all', name: 'All', icon: 'apps-outline' };
    if (!dbCategories || dbCategories.length === 0) {
      return [defaultAll];
    }
    return [
      defaultAll,
      ...dbCategories.map((cat) => ({
        id: cat.slug || cat._id,
        name: cat.name,
        icon: cat.icon || 'basket-outline',
        slug: cat.slug || cat._id,
      })),
    ];
  }, [dbCategories]);

  // Group Admin categories into sections (matching reference image style: Grocery & Kitchen, Snacks & Drinks, etc.)
  const categorySections = useMemo(() => {
    if (!dbCategories || dbCategories.length === 0) {
      return [];
    }

    const groceryKitchenKeywords = ['vegetable', 'fruit', 'atta', 'rice', 'dal', 'oil', 'ghee', 'masala', 'dairy', 'bread', 'egg', 'bakery', 'biscuit', 'dry fruit', 'cereal', 'chicken', 'meat', 'fish', 'kitchen', 'appliance'];
    const snacksDrinksKeywords = ['chip', 'namkeen', 'sweet', 'chocolate', 'drink', 'juice', 'tea', 'coffee', 'milk', 'instant', 'sauce', 'spread', 'ice cream', 'dessert', 'paan', 'beverage'];

    const groceryKitchen = [];
    const snacksDrinks = [];
    const otherCats = [];

    dbCategories.forEach((cat) => {
      const name = (cat.name || '').toLowerCase();
      if (groceryKitchenKeywords.some((k) => name.includes(k))) {
        groceryKitchen.push(cat);
      } else if (snacksDrinksKeywords.some((k) => name.includes(k))) {
        snacksDrinks.push(cat);
      } else {
        otherCats.push(cat);
      }
    });

    const sections = [];
    if (groceryKitchen.length > 0) {
      sections.push({ id: 'grocery-kitchen', title: 'Grocery & Kitchen', items: groceryKitchen });
    }
    if (snacksDrinks.length > 0) {
      sections.push({ id: 'snacks-drinks', title: 'Snacks & Drinks', items: snacksDrinks });
    }
    if (otherCats.length > 0 || sections.length === 0) {
      sections.push({
        id: 'beauty-household',
        title: sections.length > 0 ? 'Beauty, Household & More' : 'Grocery Categories',
        items: otherCats.length > 0 ? otherCats : dbCategories,
      });
    }

    return sections;
  }, [dbCategories]);

  // Helper to match category image from DB or fallback
  const getCategoryImageUrl = (cat) => {
    if (cat.image) return cat.image;
    if (cat.icon && cat.icon.startsWith('http')) return cat.icon;
    const name = (cat.name || '').toLowerCase();
    for (const [k, url] of Object.entries(DEFAULT_CATEGORY_IMAGES)) {
      if (name.includes(k)) return url;
    }
    return 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=300';
  };

  const renderCategoryTile = (cat, idx) => {
    const tileBg = PASTEL_BG_COLORS[idx % PASTEL_BG_COLORS.length];
    const imgUrl = getCategoryImageUrl(cat);

    return (
      <TouchableOpacity
        key={cat._id || cat.id || idx}
        style={styles.gridCategoryCard}
        activeOpacity={0.82}
        onPress={() =>
          navigation.navigate('GroceryCategory', {
            title: cat.name,
            categorySlug: cat.slug || cat.categorySlug || cat._id,
          })
        }
      >
        <View style={[styles.gridCategoryBg, { backgroundColor: tileBg }]}>
          <Image
            source={{ uri: imgUrl }}
            style={styles.gridCategoryImg}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.gridCategoryLabel} numberOfLines={2}>
          {cat.name}
        </Text>
      </TouchableOpacity>
    );
  };

  const statusBarHeight = StatusBar.currentHeight || 0;
  const topPadding = Platform.OS === 'web' ? 16 : Math.max(insets.top, statusBarHeight, 20);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />

      {/* Top Delivery Header */}
      <View style={[styles.topHeader, { paddingTop: topPadding }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
          <TouchableOpacity
            onPress={() => {
              if (navigation.canGoBack()) {
                navigation.goBack();
              } else {
                navigation.navigate('MainTabs');
              }
            }}
            style={{ paddingRight: 10, paddingVertical: 4 }}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            activeOpacity={0.7}
          >
            <Ionicons name="arrow-back" size={24} color="#0F172A" />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.addressRow}
            onPress={() => {
              Vibration.vibrate(30);
              if (!isAuthenticated) navigation.navigate('Login', { redirect: 'Addresses' });
              else navigation.navigate('Addresses');
            }}
            activeOpacity={0.8}
          >
            <Ionicons name="location-sharp" size={18} color="#059669" />
            <View style={styles.addressTextWrap}>
              <Text style={styles.deliverToLabel}>Deliver to:</Text>
              <Text style={styles.addressText} numberOfLines={1}>
                {currentAddress.label || 'Home'} - {currentAddress.addressLine1 || 'Sector 45'}, {currentAddress.city || 'Gurugram'}
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>

      {/* Fixed Non-Scrollable Search Bar with Mic Icon */}
      <View style={styles.searchBarContainer}>
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={20} color="#334155" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search for atta, dal, coke and more"
            placeholderTextColor="#94A3B8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            onSubmitEditing={() =>
              navigation.navigate('GroceryCategory', {
                title: searchQuery || 'Search Groceries',
                search: searchQuery,
              })
            }
          />
          <TouchableOpacity activeOpacity={0.7} onPress={() => {}}>
            <Ionicons name="mic-outline" size={20} color="#334155" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView ref={scrollViewRef} showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>


        {/* Dynamic Promotional Banner Carousel */}
        {groceryBanners.length > 0 && (
          <View style={styles.carouselSection}>
            <ScrollView
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onScroll={(e) => {
                const slide = Math.round(e.nativeEvent.contentOffset.x / (width - 32));
                if (slide !== activeBannerIdx) setActiveBannerIdx(slide);
              }}
              scrollEventThrottle={16}
            >
              {groceryBanners.map((banner, bIdx) => (
                <TouchableOpacity
                  key={banner._id || banner.id || bIdx}
                  style={styles.bannerCard}
                  activeOpacity={0.92}
                  onPress={() => navigation.navigate('GroceryCategory', { isDeals: true })}
                >
                  {banner.image ? (
                    <Image
                      source={{ uri: banner.image }}
                      style={styles.bannerFullImg}
                      resizeMode="cover"
                    />
                  ) : (
                    <View style={[styles.bannerFallback, { backgroundColor: banner.bgHex || '#059669' }]}>
                      {banner.tag ? (
                        <View style={styles.bannerTag}>
                          <Text style={styles.bannerTagText}>{banner.tag}</Text>
                        </View>
                      ) : null}
                      <Text style={styles.bannerTitle}>{banner.title}</Text>
                      <Text style={styles.bannerSub}>{banner.subtitle}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>

            {groceryBanners.length > 1 && (
              <View style={styles.dotsRow}>
                {groceryBanners.map((_, i) => (
                  <View
                    key={i}
                    style={[styles.dot, activeBannerIdx === i && styles.dotActive]}
                  />
                ))}
              </View>
            )}
          </View>
        )}

        {/* Dynamic Category Grid Sections */}
        {catLoading && dbCategories.length === 0 ? (
          <View style={styles.sectionContainer}>
            <View style={{ width: 140, height: 18, backgroundColor: '#E2E8F0', borderRadius: 4, marginBottom: 16 }} />
            <View style={styles.fourColGrid}>
              {Array.from({ length: 8 }).map((_, idx) => (
                <View key={`cat-skel-${idx}`} style={styles.gridCategoryCard}>
                  <View style={[styles.gridCategoryBg, { backgroundColor: '#F1F5F9' }]} />
                  <View style={{ width: '70%', height: 12, backgroundColor: '#E2E8F0', borderRadius: 4, marginTop: 6 }} />
                </View>
              ))}
            </View>
          </View>
        ) : (
          categorySections.map((sec) => (
            <View key={sec.id} style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>{sec.title}</Text>
              <View style={styles.fourColGrid}>
                {sec.items.map((cat, idx) => renderCategoryTile(cat, idx))}
              </View>
            </View>
          ))
        )}

        {/* Products Grid: Showing All Grocery Products */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>
              {selectedTopTab === 'all'
                ? 'All Grocery Products'
                : `${topTabs.find((t) => t.id === selectedTopTab)?.name || 'Grocery'} Products`}
            </Text>
            <Text style={styles.itemCountBadge}>{filteredProducts.length} items</Text>
          </View>

          <View style={styles.threeColGrid}>
            {productsLoading && serverProducts.length === 0 ? (
              Array.from({ length: 6 }).map((_, idx) => (
                <View key={`prod-skel-${idx}`} style={styles.zomatoCard}>
                  <View style={{ width: '100%', height: 90, backgroundColor: '#F1F5F9', borderRadius: 12, marginBottom: 8 }} />
                  <View style={{ width: '80%', height: 12, backgroundColor: '#E2E8F0', borderRadius: 4, marginBottom: 4 }} />
                  <View style={{ width: '40%', height: 10, backgroundColor: '#E2E8F0', borderRadius: 4, marginBottom: 8 }} />
                  <View style={{ width: '50%', height: 24, backgroundColor: '#F1F5F9', borderRadius: 6 }} />
                </View>
              ))
            ) : filteredProducts.length === 0 ? (
              <View style={{ padding: 32, alignItems: 'center', width: '100%', alignSelf: 'center' }}>
                <Text style={{ fontSize: 24, marginBottom: 8 }}>🥦</Text>
                <Text style={{ fontSize: 15, fontWeight: '700', color: '#1E293B', marginBottom: 4 }}>No grocery items available</Text>
                <Text style={{ fontSize: 13, color: '#64748B', textAlign: 'center' }}>Try switching category or clearing search filters.</Text>
              </View>
            ) : (
              filteredProducts.map((item) => {
                const isFav = isInWishlist(item._id);
                const cartItem = items.find(
                  (i) => (i.product?._id || i.productId || i._id) === item._id
                );
                const qty = cartItem ? cartItem.quantity : 0;
                const hasOptions = item.optionsCount || (item.variants && item.variants.length > 0);
                const isOffline = item.vendor?.role === 'vendor' && item.vendor?.isOnline === false;
                const availStock = getProductAvailableStock(item);
                const isOutOfStock = availStock <= 0 || item.isAvailable === false;

                return (
                  <TouchableOpacity
                    key={item._id}
                    style={[styles.zomatoCard, (isOffline || isOutOfStock) && { opacity: 0.88 }]}
                    activeOpacity={(isOffline || isOutOfStock) ? 1 : 0.92}
                    disabled={isOffline || isOutOfStock}
                    onPress={() => {
                      if (!isOffline && !isOutOfStock) {
                        navigation.navigate('GroceryProductDetail', {
                          slug: item.slug || item._id,
                          product: item,
                        });
                      }
                    }}
                  >
                    {!isOffline && !isOutOfStock && (
                      <TouchableOpacity
                        style={styles.cardHeartBtn}
                        onPress={() => toggleWishlist(item)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Ionicons
                          name={isFav ? 'heart' : 'heart-outline'}
                          size={16}
                          color={isFav ? '#EF4444' : '#94A3B8'}
                        />
                      </TouchableOpacity>
                    )}

                    <View style={styles.cardImgWrap}>
                      <Image
                        source={{ uri: item.images?.[0] || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300' }}
                        style={[styles.cardImg, (isOffline || isOutOfStock) && { opacity: 0.55 }]}
                        resizeMode="contain"
                      />
                      {isOffline ? (
                        <View style={{
                          position: 'absolute',
                          top: 0, left: 0, right: 0, bottom: 0,
                          backgroundColor: 'rgba(0,0,0,0.45)',
                          justifyContent: 'center',
                          alignItems: 'center',
                          borderRadius: 12,
                        }}>
                          <Text style={{ color: '#FFF', fontWeight: '900', fontSize: 10, letterSpacing: 0.5 }}>STORE CLOSED</Text>
                        </View>
                      ) : isOutOfStock ? (
                        <View style={{
                          position: 'absolute',
                          top: 0, left: 0, right: 0, bottom: 0,
                          backgroundColor: 'rgba(0,0,0,0.45)',
                          justifyContent: 'center',
                          alignItems: 'center',
                          borderRadius: 12,
                        }}>
                          <Text style={{ color: '#FFF', fontWeight: '900', fontSize: 9, letterSpacing: 0.5 }}>OUT OF STOCK</Text>
                        </View>
                      ) : null}
                      <View style={styles.vegSquare}>
                        <View style={[styles.vegDot, { backgroundColor: item.isVeg === false ? '#DC2626' : '#16A34A' }]} />
                      </View>
                    </View>

                    <Text style={styles.cardTitle} numberOfLines={2}>{item.name}</Text>
                    <Text style={styles.cardUnitText} numberOfLines={1}>{item.unitMeasure || '1 unit'}</Text>

                    <View style={styles.priceRow}>
                      <Text style={styles.cardPrice}>₹{item.price}</Text>
                      {item.comparePrice ? (
                        <Text style={styles.cardComparePrice}>₹{item.comparePrice}</Text>
                      ) : null}
                    </View>

                    {qty === 0 ? (
                      <TouchableOpacity
                        style={[styles.zomatoAddBtn, (isOffline || isOutOfStock) && { backgroundColor: '#94A3B8', borderColor: '#94A3B8' }]}
                        activeOpacity={(isOffline || isOutOfStock) ? 1 : 0.8}
                        disabled={isOffline || isOutOfStock}
                        onPress={() => {
                          if (isOffline) {
                            Alert.alert('Store Closed 🔴', 'This store is currently offline.');
                            return;
                          }
                          if (isOutOfStock) {
                            Alert.alert('Out of Stock 🔴', 'This item is currently out of stock.');
                            return;
                          }
                          if (hasOptions) {
                            setVariantModalProduct(item);
                            return;
                          }
                          addItem({ ...item, vertical: 'grocery' });
                          if (isAuthenticated) {
                            addToCart({
                              variables: {
                                input: { productId: item._id, quantity: 1 },
                              },
                            }).catch(() => {});
                          }
                        }}
                      >
                        <Text style={styles.zomatoAddBtnText}>
                          {isOffline ? 'OFFLINE' : isOutOfStock ? 'OUT OF STOCK' : 'ADD'}
                        </Text>
                        {hasOptions && !isOffline && !isOutOfStock && (
                          <Text style={styles.zomatoOptionsText}>
                            {item.optionsCount || item.variants?.length || 2} options
                          </Text>
                        )}
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.zomatoStepperRow}>
                        <TouchableOpacity
                          style={styles.zomatoStepBtn}
                          onPress={() => {
                            updateQuantity(item._id, qty - 1);
                            if (isAuthenticated && cartItem?._id && !cartItem._id.startsWith('temp-')) {
                              updateCartItem({
                                variables: { itemId: cartItem._id, quantity: qty - 1 },
                              }).catch(() => {});
                            }
                          }}
                        >
                          <Ionicons name="remove" size={14} color="#FFF" />
                        </TouchableOpacity>
                        <Text style={styles.zomatoQtyText}>{qty}</Text>
                        <TouchableOpacity
                          style={[styles.zomatoStepBtn, (qty >= availStock || isOffline || isOutOfStock) && { opacity: 0.4 }]}
                          disabled={qty >= availStock || isOffline || isOutOfStock}
                          onPress={() => {
                            if (isOffline) {
                              Alert.alert('Store Closed 🔴', 'This store is currently offline.');
                              return;
                            }
                            if (qty + 1 > availStock) {
                              Alert.alert('Stock Limit Reached', `Only ${availStock} item${availStock === 1 ? '' : 's'} available in stock.`);
                              return;
                            }
                            updateQuantity(item._id, qty + 1);
                            if (isAuthenticated) {
                              addToCart({
                                variables: {
                                  input: { productId: item._id, quantity: 1 },
                                },
                              }).catch(() => {});
                            }
                          }}
                        >
                          <Ionicons name="add" size={14} color="#FFF" />
                        </TouchableOpacity>
                      </View>
                    )}
                  </TouchableOpacity>
                );
              })
            )}
          </View>
        </View>


      </ScrollView>

      {/* Floating Cart Bar */}
      {totalGroceryItems > 0 && (
        <View style={[styles.floatingCart, { bottom: Math.max(insets.bottom, 12) }]}>
          <View>
            <Text style={styles.floatingCartCount}>
              {totalGroceryItems} {totalGroceryItems === 1 ? 'ITEM' : 'ITEMS'} ADDED
            </Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'grocery' })}
            style={styles.viewCartButton}
            activeOpacity={0.85}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}

      {/* Variant Selection Modal */}
      {variantModalProduct && (
        <VariantSelectModal
          visible={!!variantModalProduct}
          product={variantModalProduct}
          onClose={() => setVariantModalProduct(null)}
          onConfirmAddToCart={(prod, optIndex) => {
            const availStock = getProductAvailableStock(prod, optIndex);
            if (availStock <= 0) {
              Alert.alert('Out of Stock 🔴', 'Selected variant option is currently out of stock.');
              return;
            }
            const getOpts = (p) => {
              if (p?.variants?.[0]?.options?.length > 0) return p.variants[0].options;
              return p?.variants || [];
            };
            const rawOpts = getOpts(prod);
            const chosenOpt = rawOpts[optIndex] || {};
            const chosenLabel = chosenOpt.label || chosenOpt.name || undefined;

            addItem({ ...prod, vertical: 'grocery', variantIndex: optIndex, variantLabel: chosenLabel });
            if (isAuthenticated) {
              addToCart({
                variables: {
                  input: {
                    productId: prod._id,
                    quantity: 1,
                    variantIndex: optIndex,
                    variantLabel: chosenLabel,
                  },
                },
              });
            }
          }}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  topHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 8,
    backgroundColor: '#FFFFFF',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  addressTextWrap: {
    flexShrink: 1,
  },
  deliverToLabel: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '600',
  },
  addressText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F172A',
  },
  scroll: {
    paddingBottom: 90,
  },
  searchBarContainer: {
    paddingHorizontal: 16,
    marginTop: 6,
    marginBottom: 8,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 10,
    ...SHADOWS.small,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#0F172A',
    fontWeight: '500',
  },
  topTabsScroll: {
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 12,
    gap: 18,
  },
  topTabBtn: {
    alignItems: 'center',
    position: 'relative',
    paddingBottom: 6,
  },
  topTabIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  topTabIconWrapActive: {
    backgroundColor: '#F1F5F9',
  },
  topTabText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
  },
  topTabTextActive: {
    color: '#0F172A',
    fontWeight: '900',
  },
  activeTabLine: {
    position: 'absolute',
    bottom: 0,
    width: 24,
    height: 3,
    backgroundColor: '#0F172A',
    borderRadius: 2,
  },
  sectionContainer: {
    marginTop: 18,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#0F172A',
    marginBottom: 12,
    letterSpacing: -0.2,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  itemCountBadge: {
    fontSize: 11,
    fontWeight: '700',
    color: '#64748B',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  fourColGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: GRID_GAP,
    justifyContent: 'flex-start',
  },
  gridCategoryCard: {
    width: COL_WIDTH_4,
    alignItems: 'center',
    marginBottom: 14,
  },
  gridCategoryBg: {
    width: '100%',
    height: COL_WIDTH_4,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  gridCategoryImg: {
    width: '82%',
    height: '82%',
  },
  gridCategoryLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: '#1E293B',
    textAlign: 'center',
    marginTop: 6,
    lineHeight: 14,
  },
  threeColGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: GRID_GAP,
  },
  zomatoCard: {
    width: CARD_WIDTH_3,
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 6,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    marginBottom: 12,
    position: 'relative',
    ...SHADOWS.small,
  },
  cardHeartBtn: {
    position: 'absolute',
    top: 6,
    right: 6,
    zIndex: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardImgWrap: {
    width: '100%',
    height: 85,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F8FAFC',
    borderRadius: 10,
    position: 'relative',
    marginBottom: 4,
  },
  cardImg: {
    width: '80%',
    height: '80%',
  },
  vegSquare: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 12,
    height: 12,
    borderWidth: 1,
    borderColor: '#16A34A',
    borderRadius: 3,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF',
  },
  vegDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#16A34A',
  },
  cardTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: '#1E293B',
    lineHeight: 15,
    minHeight: 30,
  },
  cardUnitText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#64748B',
    marginTop: 2,
    marginBottom: 4,
    lineHeight: 14,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    marginBottom: 6,
  },
  cardPrice: {
    fontSize: 13,
    fontWeight: '900',
    color: '#0F172A',
  },
  cardComparePrice: {
    fontSize: 10,
    color: '#94A3B8',
    textDecorationLine: 'line-through',
  },
  zomatoAddBtn: {
    borderWidth: 1,
    borderColor: '#16A34A',
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    paddingVertical: 5,
    alignItems: 'center',
  },
  zomatoAddBtnText: {
    color: '#16A34A',
    fontSize: 12,
    fontWeight: '900',
  },
  zomatoOptionsText: {
    fontSize: 8,
    fontWeight: '600',
    color: '#64748B',
    marginTop: 1,
  },
  zomatoStepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#16A34A',
    borderRadius: 8,
    paddingHorizontal: 6,
    paddingVertical: 4,
  },
  zomatoStepBtn: {
    width: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  zomatoQtyText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '900',
  },
  freeDeliveryBannerWrap: {
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 10,
  },
  freeDeliveryBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 10,
    ...SHADOWS.small,
  },
  scooterIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#EFF6FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  freeDeliveryText: {
    fontSize: 12,
    color: '#475569',
    fontWeight: '600',
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#059669',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 999,
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#D1FAE5',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  carouselSection: {
    paddingHorizontal: 16,
    marginTop: 10,
    marginBottom: 8,
  },
  bannerCard: {
    width: width - 32,
    height: (width - 32) * 0.38,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: '#F1F5F9',
    position: 'relative',
    ...SHADOWS.medium,
  },
  bannerFullImg: {
    width: '100%',
    height: '100%',
  },
  bannerFallback: {
    width: '100%',
    height: '100%',
    padding: 16,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  bannerTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  bannerTagText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '800',
  },
  bannerTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#FFF',
  },
  bannerSub: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.9)',
    marginTop: 4,
  },
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    marginTop: 10,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#CBD5E1',
  },
  dotActive: {
    width: 18,
    backgroundColor: '#059669',
  },
});
