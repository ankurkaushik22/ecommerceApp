import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_ME, GET_NOTIFICATIONS, GET_STORE_SETTINGS } from '../../graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical } from '../../utils/cartHelpers';

const { width } = Dimensions.get('window');

const GROCERY_CATEGORIES = [
  { id: 'fruits', name: 'Fruits', icon: 'nutrition-outline', querySlug: 'fruits' },
  { id: 'veggies', name: 'Veggies', icon: 'leaf-outline', querySlug: 'vegetables' },
  { id: 'meat', name: 'Meat', icon: 'fish-outline', querySlug: 'meat' },
  { id: 'bakery', name: 'Bakery', icon: 'restaurant-outline', querySlug: 'bakery' },
];

const FALLBACK_POPULAR_GROCERIES = [
  {
    _id: 'g-pop-1',
    name: 'Organic Robusta Bananas',
    slug: 'organic-robusta-bananas',
    unitMeasure: '500g Pack',
    price: 39,
    comparePrice: 59,
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400'],
    rating: { average: 4.8, count: 85 },
  },
  {
    _id: 'g-pop-2',
    name: 'Whole Milk Dairy Pure',
    slug: 'whole-milk-dairy-pure',
    unitMeasure: '1 Litre Pack',
    price: 65,
    comparePrice: 75,
    images: ['https://images.unsplash.com/photo-1563636619-e9143da7973b?w=400'],
    rating: { average: 4.9, count: 120 },
  },
  {
    _id: 'g-pop-3',
    name: 'Artisan Sourdough Loaf',
    slug: 'artisan-sourdough-loaf',
    unitMeasure: 'Freshly Baked',
    price: 120,
    comparePrice: 150,
    images: ['https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=400'],
    rating: { average: 4.7, count: 64 },
  },
  {
    _id: 'g-pop-4',
    name: 'Ready-to-eat Hass Avocados',
    slug: 'ready-to-eat-hass-avocados',
    unitMeasure: '2 pcs pack',
    price: 249,
    comparePrice: 320,
    images: ['https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=400'],
    rating: { average: 4.9, count: 128 },
  },
];

export default function GroceryHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const { user, isAuthenticated } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');

  const cartCount = useCartStore((s) => s.itemCount);
  const items = useCartStore((s) => s.items || []);
  const setCart = useCartStore((s) => s.setCart);
  const addItem = useCartStore((s) => s.addItem);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const { toggleWishlist, isInWishlist } = useWishlistStore();

  const groceryCartItems = filterItemsByVertical(items || [], 'grocery');
  const totalGroceryItems = groceryCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = groceryCartItems.reduce((sum, i) => sum + ((i?.price || i?.product?.price || 0) * (i?.quantity || 0)), 0);

  const { data: meData } = useQuery(GET_ME, { skip: !isAuthenticated });
  const { data: notifData } = useQuery(GET_NOTIFICATIONS, { skip: !isAuthenticated, pollInterval: 30000 });
  const unreadCount = (notifData?.getNotifications || []).filter((n) => !n.isRead).length;

  const { data: productsData } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vertical: 'grocery' },
      pagination: { page: 1, limit: 20 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(50);
    },
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      setCart(res.updateCartItem);
    },
  });

  const popularItems = productsData?.getProducts?.products?.length > 0
    ? productsData.getProducts.products
    : FALLBACK_POPULAR_GROCERIES;

  const currentUser = meData?.me || user;
  const currentAddress = currentUser?.addresses?.find((a) => a.isDefault) || currentUser?.addresses?.[0] || {
    addressLine1: '123 Maple St',
  };

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('grocery')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🥦</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Grocery Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting grocery orders. Please check back later or explore our other products!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Top Header matching reference */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        {/* Deliver to address with location pin */}
        <TouchableOpacity
          style={styles.addressRow}
          onPress={() => {
            if (!isAuthenticated) navigation.navigate('Login', { redirect: 'Addresses' });
            else navigation.navigate('Addresses');
          }}
          activeOpacity={0.8}
        >
          <Ionicons name="location-sharp" size={18} color="#059669" />
          <View style={styles.addressTextWrap}>
            <Text style={styles.deliverToLabel}>Deliver to:</Text>
            <Text style={styles.addressText} numberOfLines={1}>
              {currentAddress.label || 'Home'} - {currentAddress.addressLine1 || 'Sector 45'}, {currentAddress.city || 'Gurugram'}
            </Text>
          </View>
        </TouchableOpacity>

        {/* Center Logo */}
        <View style={styles.logoWrap}>
          <Text style={styles.logoText}>SUAAKA FRESH</Text>
        </View>

        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Search Bar */}
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={20} color="#64748B" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search fresh groceries..."
            placeholderTextColor="#94A3B8"
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            onSubmitEditing={() =>
              navigation.navigate('GroceryCategory', {
                title: searchQuery || 'Fresh Groceries',
                search: searchQuery,
              })
            }
          />
        </View>

        {/* Quick Category Icons (Matching Image 1: soft blue rounded cards) */}
        <View style={styles.categoriesRow}>
          {GROCERY_CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat.id}
              style={styles.categoryCard}
              activeOpacity={0.8}
              onPress={() =>
                navigation.navigate('GroceryCategory', {
                  title: cat.name,
                  categorySlug: cat.querySlug,
                })
              }
            >
              <View style={styles.categoryIconCircle}>
                <Ionicons name={cat.icon} size={24} color="#0F172A" />
              </View>
              <Text style={styles.categoryName}>{cat.name}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Hero Banner: WEEKLY DEALS */}
        <View style={styles.bannerContainer}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800' }}
            style={styles.bannerImage}
            resizeMode="cover"
          />
          <View style={styles.bannerOverlay}>
            <Text style={styles.bannerTag}>WEEKLY DEALS</Text>
            <Text style={styles.bannerHeading}>Fresh Greens,{"\n"}Lower Prices</Text>
            <TouchableOpacity
              style={styles.bannerBtn}
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate('GroceryCategory', {
                  title: 'Weekly Deals',
                  isDeals: true,
                })
              }
            >
              <Text style={styles.bannerBtnText}>Shop Deals</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Popular Near You Section Header */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>Popular Near You</Text>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('GroceryCategory', { title: 'Popular Groceries' })
            }
          >
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>

        {/* Popular Products Horizontal Scroll Shelf */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.popularScroll}
        >
          {popularItems.map((item) => {
            const isFav = isInWishlist(item._id);
            const cartItem = items.find(
              (i) => (i.product?._id || i.productId || i._id) === item._id
            );
            const qty = cartItem ? cartItem.quantity : 0;

            return (
              <TouchableOpacity
                key={item._id}
                style={styles.productCard}
                activeOpacity={0.92}
                onPress={() =>
                  navigation.navigate('GroceryProductDetail', {
                    slug: item.slug || item._id,
                    product: item,
                  })
                }
              >
                {/* Heart Button */}
                <TouchableOpacity
                  style={styles.heartBtn}
                  onPress={() => toggleWishlist(item)}
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                >
                  <Ionicons
                    name={isFav ? 'heart' : 'heart-outline'}
                    size={18}
                    color={isFav ? '#EF4444' : '#94A3B8'}
                  />
                </TouchableOpacity>

                {/* Product Image */}
                <View style={styles.productImageWrap}>
                  <Image
                    source={{ uri: item.images?.[0] || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300' }}
                    style={styles.productImage}
                    resizeMode="contain"
                  />
                </View>

                {/* Info */}
                <View style={styles.productInfo}>
                  <Text style={styles.productTitle} numberOfLines={1}>
                    {item.name}
                  </Text>
                  <Text style={styles.productUnit}>
                    {item.unitMeasure || '1 unit'}
                  </Text>
                  <View style={styles.priceAddRow}>
                    <Text style={styles.productPrice}>₹{Number(item.price).toLocaleString('en-IN')}</Text>
                    {qty === 0 ? (
                      <TouchableOpacity
                        style={styles.addBtnCircle}
                        activeOpacity={0.8}
                        onPress={() => {
                          addItem({ ...item, vertical: 'grocery' });
                          if (isAuthenticated) {
                            addToCart({
                              variables: {
                                input: { productId: item._id, quantity: 1 },
                              },
                            });
                          }
                        }}
                      >
                        <Ionicons name="add" size={16} color={COLORS.white} />
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.qtyStepperRow}>
                        <TouchableOpacity
                          style={styles.qtyBtn}
                          onPress={() => {
                            updateQuantity(item._id, qty - 1);
                            if (isAuthenticated && cartItem?._id && !cartItem._id.startsWith('temp-')) {
                              updateCartItem({
                                variables: { itemId: cartItem._id, quantity: qty - 1 },
                              });
                            }
                          }}
                          hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                        >
                          <Ionicons name="remove" size={12} color={COLORS.white} />
                        </TouchableOpacity>
                        <Text style={styles.qtyText}>{qty}</Text>
                        <TouchableOpacity
                          style={styles.qtyBtn}
                          onPress={() => {
                            updateQuantity(item._id, qty + 1);
                            if (isAuthenticated) {
                              addToCart({
                                variables: {
                                  input: { productId: item._id, quantity: 1 },
                                },
                              });
                            }
                          }}
                          hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                        >
                          <Ionicons name="add" size={12} color={COLORS.white} />
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </ScrollView>

      {/* Floating Bottom Cart Bar */}
      {totalGroceryItems > 0 && (
        <View style={[styles.floatingCart, { bottom: insets.bottom + 12 }]}>
          <View>
            <Text style={styles.floatingCartCount}>{totalGroceryItems} {totalGroceryItems === 1 ? 'ITEM' : 'ITEMS'} ADDED</Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'grocery' })}
            style={styles.viewCartButton}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    maxWidth: width * 0.35,
  },
  addressTextWrap: {
    flexShrink: 1,
  },
  deliverToLabel: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '600',
  },
  addressText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#0F172A',
  },
  logoWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 2,
    color: '#0F172A',
  },
  headerBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notifBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  notifBadgeText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: 'bold',
  },
  scroll: {
    paddingBottom: 40,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    marginHorizontal: 16,
    marginTop: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 10,
    ...SHADOWS.small,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#0F172A',
    fontWeight: '500',
  },
  categoriesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginTop: 16,
    gap: 10,
  },
  categoryCard: {
    flex: 1,
    backgroundColor: '#E0F2FE',
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  categoryIconCircle: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  categoryName: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
  },
  bannerContainer: {
    marginHorizontal: 16,
    marginTop: 18,
    height: 160,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
    ...SHADOWS.medium,
  },
  bannerImage: {
    width: '100%',
    height: '100%',
  },
  bannerOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(15, 23, 42, 0.45)',
    padding: 16,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  bannerTag: {
    fontSize: 11,
    fontWeight: '800',
    color: '#4ADE80',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  bannerHeading: {
    fontSize: 18,
    fontWeight: '900',
    color: COLORS.white,
    lineHeight: 24,
    marginBottom: 12,
  },
  bannerBtn: {
    backgroundColor: '#10B981',
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 10,
  },
  bannerBtnText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '800',
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginTop: 22,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#0F172A',
  },
  seeAllText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#059669',
  },
  popularScroll: {
    paddingHorizontal: 16,
    gap: 12,
  },
  productCard: {
    width: 145,
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 10,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    position: 'relative',
    ...SHADOWS.small,
  },
  heartBtn: {
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 2,
    backgroundColor: 'rgba(255,255,255,0.85)',
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productImageWrap: {
    width: '100%',
    height: 100,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 4,
  },
  productImage: {
    width: '100%',
    height: '100%',
  },
  productInfo: {
    marginTop: 4,
  },
  productTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#0F172A',
  },
  productUnit: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
    marginBottom: 4,
  },
  priceAddRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 2,
  },
  productPrice: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
  },
  addBtnCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: '#059669',
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyStepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#059669',
    borderRadius: 16,
    height: 26,
    paddingHorizontal: 6,
    gap: 4,
    ...SHADOWS.small,
  },
  qtyBtn: {
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyText: {
    color: COLORS.white,
    fontSize: 12,
    fontWeight: '800',
    minWidth: 14,
    textAlign: 'center',
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#059669',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#D1FAE5',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
});
