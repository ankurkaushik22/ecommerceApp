import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCT_BY_SLUG } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { getProductAvailableStock } from '../../utils/cartHelpers';
import { useCartStore } from '../../store/cartStore';
import { useWishlistStore } from '../../store/wishlistStore';

const stripHtml = (html) => {
  if (!html) return '';
  return String(html)
    .replace(/<br\s*[\/]?>/gi, ' ')
    .replace(/<\/p>/gi, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
};

const { width } = Dimensions.get('window');

const FALLBACK_PRODUCT = {
  _id: 'g-hass-avocado',
  name: 'Organic Hass Avocados',
  slug: 'organic-hass-avocados',
  price: 4.99,
  unitMeasure: 'for 2',
  rating: { average: 4.9, count: 128 },
  category: { name: 'FRESH FRUIT' },
  description:
    'Creamy, rich, and perfectly ripe. These organic Hass avocados are packed with flavor and healthy fats, making them ideal for everything from classic avocado toast and zesty guacamole to blending into smooth, nutritious smoothies.',
  nutritionalHighlights: ['Healthy Fats', 'High Fiber', 'Rich in Potassium'],
  images: [
    'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=800',
    'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400',
    'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400',
  ],
};

function getGroceryVariantOptions(product) {
  if (!product || !Array.isArray(product.variants) || product.variants.length === 0) return [];
  const firstGroup = product.variants[0];
  if (firstGroup && Array.isArray(firstGroup.options) && firstGroup.options.length > 0) {
    const groupName = firstGroup.name || 'Pack Size';
    return firstGroup.options.map((opt, idx) => ({
      index: idx,
      groupName,
      label: opt.label || opt.name || `Option ${idx + 1}`,
      price: typeof opt.price === 'number' && opt.price > 0 ? opt.price : (product.price || 0),
      stock: opt.stock,
    }));
  }
  return product.variants.map((v, idx) => ({
    index: idx,
    groupName: (v.name && v.label) ? v.name : 'Pack Size',
    label: v.label || v.name || `Option ${idx + 1}`,
    price: typeof v.price === 'number' && v.price > 0 ? v.price : (v.option?.price || product.price || 0),
    stock: v.stock || v.option?.stock,
  }));
}

export default function GroceryProductDetailScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { slug, product: initialProduct } = route.params || {};

  const [quantity, setQuantity] = useState(1);
  const [selectedImgIndex, setSelectedImgIndex] = useState(0);
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);

  const setCart = useCartStore((s) => s.setCart);
  const { toggleWishlist, isInWishlist } = useWishlistStore();

  const { data } = useQuery(GET_PRODUCT_BY_SLUG, {
    variables: { slug: slug || '' },
    skip: !slug,
  });

  const [addToCart, { loading: adding }] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(60);
      navigation.navigate('MainTabs', { screen: 'CartTab' });
    },
  });

  const product = data?.getProduct || initialProduct || FALLBACK_PRODUCT;
  const variantOptions = getGroceryVariantOptions(product);

  const activeVariant = variantOptions[selectedVariantIndex] || null;
  const currentPrice = activeVariant ? activeVariant.price : Number(product.price || 0);
  const currentUnitMeasure = activeVariant ? activeVariant.label : (product.unitMeasure || '');

  const isOffline = product?.vendor?.role === 'vendor' && product.vendor?.isOnline === false;
  const isFav = isInWishlist(product._id);
  const images = product.images?.length > 0 ? product.images : FALLBACK_PRODUCT.images;
  const highlights = product.nutritionalHighlights?.length > 0
    ? product.nutritionalHighlights
    : FALLBACK_PRODUCT.nutritionalHighlights;

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const topPadding = Platform.OS === 'web' ? 16 : Math.max(insets.top, statusBarHeight, 24) + 6;

  return (
    <View style={styles.container}>
      {/* Top Header matching reference Image 3 */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <TouchableOpacity
          style={styles.headerBtn}
          onPress={() => navigation.goBack()}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="arrow-back" size={24} color="#0F172A" />
        </TouchableOpacity>

        <View style={styles.logoWrap}>
          <Text style={styles.logoText}>S U A A K A</Text>
        </View>

        <TouchableOpacity
          style={styles.headerBtn}
          onPress={() => toggleWishlist(product)}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons
            name={isFav ? 'heart' : 'heart-outline'}
            size={22}
            color={isFav ? '#EF4444' : '#0F172A'}
          />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {isOffline && (
          <View style={styles.offlineHeaderBanner}>
            <Ionicons name="alert-circle" size={16} color="#FFF" style={{ marginRight: 6 }} />
            <Text style={styles.offlineHeaderBannerText}>STORE CLOSED — Currently Offline</Text>
          </View>
        )}
        {/* Main Product Hero Image */}
        <View style={styles.heroImageContainer}>
          <Image
            source={{ uri: images[selectedImgIndex] || images[0] }}
            style={styles.heroImage}
            resizeMode="cover"
          />
        </View>

        {/* Thumbnail Gallery Row */}
        {images.length > 1 && (
          <View style={styles.thumbRow}>
            {images.slice(0, 3).map((imgUrl, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.thumbBox, selectedImgIndex === idx && styles.thumbBoxActive]}
                activeOpacity={0.8}
                onPress={() => setSelectedImgIndex(idx)}
              >
                <Image source={{ uri: imgUrl }} style={styles.thumbImg} resizeMode="cover" />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Breadcrumbs */}
        <View style={styles.contentPadding}>
          <Text style={styles.breadcrumbs}>
            PRODUCE &gt; {product.category?.name?.toUpperCase() || 'FRESH FRUIT'}
          </Text>

          {/* Title */}
          <Text style={styles.title}>{product.name}</Text>

          {/* Ratings */}
          <View style={styles.ratingsRow}>
            <View style={styles.starsRow}>
              {[...Array(5)].map((_, i) => (
                <Ionicons key={i} name="star" size={15} color="#F59E0B" style={{ marginRight: 2 }} />
              ))}
            </View>
            <Text style={styles.reviewsText}>
              ({product.rating?.count || 128} Reviews)
            </Text>
          </View>

          {/* Price with Unit */}
          <View style={styles.priceRow}>
            <Text style={styles.price}>₹{currentPrice.toLocaleString('en-IN')}</Text>
            {currentUnitMeasure ? <Text style={styles.priceUnit}>{currentUnitMeasure}</Text> : null}
          </View>

          {/* Select Pack Size / Variants */}
          {variantOptions.length > 0 && (
            <View style={styles.variantSection}>
              <Text style={styles.sectionHeading}>
                Select Pack Size ({variantOptions[0]?.groupName || 'Options'})
              </Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.variantChipsContainer}
              >
                {variantOptions.map((opt) => {
                  const isSelected = selectedVariantIndex === opt.index;
                  const isOutOfStock = typeof opt.stock === 'number' && opt.stock !== null && opt.stock <= 0;
                  return (
                    <TouchableOpacity
                      key={opt.index}
                      style={[
                        styles.variantChip,
                        isSelected && styles.variantChipActive,
                        isOutOfStock && styles.variantChipOutOfStock,
                      ]}
                      disabled={isOutOfStock}
                      onPress={() => {
                        Vibration.vibrate(30);
                        setSelectedVariantIndex(opt.index);
                      }}
                    >
                      <Text
                        style={[
                          styles.variantChipText,
                          isSelected && styles.variantChipTextActive,
                          isOutOfStock && styles.variantChipTextOutOfStock,
                        ]}
                      >
                        {opt.label}
                      </Text>
                      <Text
                        style={[
                          styles.variantChipPrice,
                          isSelected && styles.variantChipPriceActive,
                        ]}
                      >
                        ₹{Number(opt.price).toLocaleString('en-IN')}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>
            </View>
          )}

          {/* Description */}
          <Text style={styles.description}>
            {stripHtml(product.description || FALLBACK_PRODUCT.description)}
          </Text>

          {/* Nutritional Highlights Section matching Image 3 */}
          <Text style={styles.sectionHeading}>Nutritional Highlights</Text>
          <View style={styles.highlightsGrid}>
            {highlights.map((tag, i) => (
              <View key={i} style={styles.highlightPill}>
                <Ionicons
                  name={i % 2 === 0 ? 'heart-outline' : 'sparkles-outline'}
                  size={14}
                  color="#10B981"
                />
                <Text style={styles.highlightText}>{tag}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Sticky Bottom Bar with Stepper and Green Add to Cart Button (Image 3) */}
      <View style={[styles.bottomBar, { paddingBottom: Math.max(insets.bottom, 14) }]}>
        {/* Quantity Stepper */}
        <View style={styles.stepperBox}>
          <TouchableOpacity
            style={styles.stepperBtn}
            onPress={() => setQuantity((q) => Math.max(1, q - 1))}
          >
            <Ionicons name="remove" size={16} color="#0F172A" />
          </TouchableOpacity>
          <Text style={styles.stepperValue}>{quantity}</Text>
          <TouchableOpacity
            style={[styles.stepperBtn, (quantity >= getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) || isOffline || getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false) && { opacity: 0.4 }]}
            disabled={quantity >= getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) || isOffline || getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false}
            onPress={() => {
              const maxStock = getProductAvailableStock(product, activeVariant ? activeVariant.index : -1);
              if (quantity + 1 > maxStock) {
                Alert.alert('Stock Limit Reached', `Only ${maxStock} available in stock.`);
                return;
              }
              setQuantity((q) => q + 1);
            }}
          >
            <Ionicons name="add" size={16} color="#0F172A" />
          </TouchableOpacity>
        </View>

        {/* Add to Cart Button */}
        <TouchableOpacity
          style={[styles.addToCartBtn, (isOffline || getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false) && { backgroundColor: '#94A3B8' }]}
          activeOpacity={0.88}
          disabled={adding || isOffline || getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false}
          onPress={() => {
            if (isOffline) {
              Alert.alert('Store Offline 🔴', 'This store is currently offline and not accepting orders.');
              return;
            }
            const maxStock = getProductAvailableStock(product, activeVariant ? activeVariant.index : -1);
            if (maxStock <= 0 || product.isAvailable === false) {
              Alert.alert('Out of Stock 🔴', 'This item is currently out of stock.');
              return;
            }
            if (quantity > maxStock) {
              Alert.alert('Stock Limit Reached', `Only ${maxStock} available in stock.`);
              return;
            }
            addToCart({
              variables: {
                input: {
                  productId: product._id,
                  quantity,
                  variantIndex: activeVariant ? activeVariant.index : -1,
                  variantLabel: currentUnitMeasure || undefined,
                },
              },
            });
          }}
        >
          <Ionicons name={(getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false) ? "ban-outline" : "cart"} size={18} color={COLORS.white} style={{ marginRight: 8 }} />
          <Text style={styles.addToCartText}>
            {isOffline ? 'Store Offline' : (getProductAvailableStock(product, activeVariant ? activeVariant.index : -1) <= 0 || product.isAvailable === false) ? 'OUT OF STOCK' : adding ? 'Adding...' : 'Add to Cart'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  offlineHeaderBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#DC2626',
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 12,
  },
  offlineHeaderBannerText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 13,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  headerBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 2,
    color: '#0F172A',
  },
  scroll: {
    paddingBottom: 100,
  },
  heroImageContainer: {
    width: width - 32,
    height: width * 0.75,
    marginHorizontal: 16,
    marginTop: 14,
    borderRadius: 22,
    overflow: 'hidden',
    position: 'relative',
    backgroundColor: COLORS.white,
    ...SHADOWS.small,
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  organicBadge: {
    position: 'absolute',
    top: 14,
    left: 14,
    backgroundColor: '#10B981',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  organicBadgeText: {
    color: COLORS.white,
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 1,
  },
  thumbRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginHorizontal: 16,
    marginTop: 12,
    gap: 10,
  },
  thumbBox: {
    width: 60,
    height: 60,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    overflow: 'hidden',
    backgroundColor: COLORS.white,
  },
  thumbBoxActive: {
    borderColor: '#10B981',
  },
  thumbImg: {
    width: '100%',
    height: '100%',
  },
  contentPadding: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  breadcrumbs: {
    fontSize: 11,
    fontWeight: '800',
    color: '#64748B',
    letterSpacing: 1,
    marginBottom: 6,
  },
  title: {
    fontSize: 22,
    fontWeight: '900',
    color: '#0F172A',
    marginBottom: 8,
  },
  ratingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  starsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 6,
  },
  reviewsText: {
    fontSize: 13,
    color: '#64748B',
    fontWeight: '600',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 14,
  },
  price: {
    fontSize: 26,
    fontWeight: '900',
    color: '#0F172A',
    marginRight: 8,
  },
  priceUnit: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748B',
  },
  variantSection: {
    marginBottom: 18,
  },
  variantChipsContainer: {
    gap: 8,
    paddingVertical: 4,
  },
  variantChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  variantChipActive: {
    borderColor: '#059669',
    backgroundColor: '#ECFDF5',
  },
  variantChipOutOfStock: {
    opacity: 0.4,
    borderColor: '#E2E8F0',
  },
  variantChipText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#334155',
  },
  variantChipTextActive: {
    color: '#047857',
    fontWeight: '800',
  },
  variantChipTextOutOfStock: {
    textDecorationLine: 'line-through',
    color: '#94A3B8',
  },
  variantChipPrice: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
    fontWeight: '600',
  },
  variantChipPriceActive: {
    color: '#059669',
    fontWeight: '700',
  },
  description: {
    fontSize: 14,
    lineHeight: 22,
    color: '#475569',
    marginBottom: 20,
  },
  sectionHeading: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A',
    marginBottom: 12,
  },
  highlightsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 20,
  },
  highlightPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#A7F3D0',
  },
  highlightText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#065F46',
    marginLeft: 6,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.white,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
    paddingHorizontal: 16,
    paddingTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    ...SHADOWS.medium,
  },
  stepperBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    paddingHorizontal: 6,
    paddingVertical: 4,
  },
  stepperBtn: {
    width: 32,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperValue: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A',
    minWidth: 24,
    textAlign: 'center',
  },
  addToCartBtn: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#059669',
    borderRadius: 14,
    height: 46,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.small,
  },
  addToCartText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '800',
  },
});
