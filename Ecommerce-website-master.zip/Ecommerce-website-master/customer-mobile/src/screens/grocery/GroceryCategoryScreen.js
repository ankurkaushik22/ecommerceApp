import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  FlatList,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_NOTIFICATIONS } from '../../graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import FloatingCartBar from '../../components/common/FloatingCartBar';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 32 - 12) / 2;



const FALLBACK_CATEGORY_ITEMS = [
  {
    _id: 'g-cat-1',
    name: 'Organic Yellow Bananas',
    slug: 'organic-yellow-bananas',
    unitMeasure: '500g',
    price: 49,
    comparePrice: 69,
    badge: null,
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400'],
    rating: { average: 4.8, count: 90 },
  },
  {
    _id: 'g-cat-2',
    name: 'Crisp Red Fuji Apples',
    slug: 'crisp-red-fuji-apples',
    unitMeasure: '1kg (Approx 5 pcs)',
    price: 180,
    comparePrice: 220,
    badge: 'SALE',
    images: ['https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400'],
    rating: { average: 4.9, count: 145 },
  },
  {
    _id: 'g-cat-3',
    name: 'Ready-to-eat Hass Avocados',
    slug: 'ready-to-eat-hass-avocados',
    unitMeasure: '2 pcs',
    price: 249,
    comparePrice: 320,
    badge: 'ORGANIC',
    images: ['https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=400'],
    rating: { average: 4.9, count: 128 },
  },
  {
    _id: 'g-cat-4',
    name: 'Fresh Baby Spinach',
    slug: 'fresh-baby-spinach',
    unitMeasure: '250g Bunch',
    price: 39,
    comparePrice: 59,
    badge: null,
    images: ['https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400'],
    rating: { average: 4.7, count: 52 },
  },
  {
    _id: 'g-cat-5',
    name: 'Organic Carrots with Tops',
    slug: 'organic-carrots-with-tops',
    unitMeasure: '500g',
    price: 59,
    comparePrice: 79,
    badge: 'ORGANIC',
    images: ['https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400'],
    rating: { average: 4.8, count: 74 },
  },
  {
    _id: 'g-cat-6',
    name: 'Sweet Farm Strawberries',
    slug: 'sweet-farm-strawberries',
    unitMeasure: '250g Punnet',
    price: 149,
    comparePrice: 199,
    badge: 'SALE',
    images: ['https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=400'],
    rating: { average: 4.9, count: 110 },
  },
];

export default function GroceryCategoryScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const { title = 'Fruits & Vegetables', categorySlug, search, isDeals } = route.params || {};

  const [activeFilter, setActiveFilter] = useState('all');
  const setCart = useCartStore((s) => s.setCart);
  const cartItems = useCartStore((s) => s.items || []);
  const addItem = useCartStore((s) => s.addItem);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const { toggleWishlist, isInWishlist } = useWishlistStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data: notifData } = useQuery(GET_NOTIFICATIONS, { skip: !isAuthenticated, pollInterval: 30000 });
  const unreadCount = (notifData?.getNotifications || []).filter((n) => !n.isRead).length;

  const { data: productsData, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'grocery',
        category: categorySlug || undefined,
        search: search || undefined,
        isDeals: isDeals || undefined,
      },
      pagination: { page: 1, limit: 40 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(50);
    },
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      setCart(res.updateCartItem);
    },
  });

  const fetchedProducts = productsData?.getProducts?.products;
  const products = (fetchedProducts && fetchedProducts.length > 0) ? fetchedProducts : FALLBACK_CATEGORY_ITEMS;

  const filteredProducts = products.filter((p) => {
    if (activeFilter === 'organic') {
      return (
        p.name?.toLowerCase().includes('organic') ||
        p.badge === 'ORGANIC' ||
        p.tags?.includes('organic')
      );
    }
    if (activeFilter === 'fresh') {
      return (
        p.name?.toLowerCase().includes('fresh') ||
        p.name?.toLowerCase().includes('spinach') ||
        p.name?.toLowerCase().includes('carrot')
      );
    }
    if (activeFilter === 'deals') {
      return Boolean(p.comparePrice && p.comparePrice > p.price);
    }
    return true;
  });

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const topPadding = Platform.OS === 'web' ? 16 : Math.max(insets.top, statusBarHeight, 24) + 6;

  return (
    <View style={styles.container}>
      {/* Top Header matching reference */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <TouchableOpacity
          style={styles.headerBtn}
          onPress={() => navigation.goBack()}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="arrow-back" size={24} color="#0F172A" />
        </TouchableOpacity>

        <View style={styles.logoWrap}>
          <Text style={styles.logoText}>S U A A K A</Text>
        </View>

        <View style={{ width: 24 }} />
      </View>

      {/* Screen Title */}
      <View style={styles.titleContainer}>
        <Text style={styles.mainTitle}>{title}</Text>
      </View>



      {/* 2-Column Product Grid (Matching Image 2) */}
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item._id}
        numColumns={2}
        contentContainerStyle={styles.gridContent}
        columnWrapperStyle={styles.gridRow}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => {
          const isFav = isInWishlist(item._id);
          const badgeText = item.badge || (item.comparePrice > item.price ? 'SALE' : null);
          const isSale = badgeText === 'SALE';
          const isOrganic = badgeText === 'ORGANIC';

          const cartItem = cartItems.find(
            (i) => (i.product?._id || i.productId || i._id) === item._id
          );
          const qty = cartItem ? cartItem.quantity : 0;

          return (
            <TouchableOpacity
              style={styles.gridCard}
              activeOpacity={0.92}
              onPress={() =>
                navigation.navigate('GroceryProductDetail', {
                  slug: item.slug || item._id,
                  product: item,
                })
              }
            >
              {/* Badge Tag (e.g. SALE in orange, ORGANIC in green) */}
              {badgeText && (
                <View style={[styles.badgeTag, isSale ? styles.saleBadge : styles.organicBadge]}>
                  <Text style={[styles.badgeText, isSale ? styles.saleBadgeText : styles.organicBadgeText]}>
                    {badgeText}
                  </Text>
                </View>
              )}

              {/* Heart Wishlist Button */}
              <TouchableOpacity
                style={styles.cardHeartBtn}
                onPress={() => toggleWishlist(item)}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <Ionicons
                  name={isFav ? 'heart' : 'heart-outline'}
                  size={18}
                  color={isFav ? '#EF4444' : '#94A3B8'}
                />
              </TouchableOpacity>

              {/* Product Image */}
              <View style={styles.cardImageContainer}>
                <Image
                  source={{ uri: item.images?.[0] || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400' }}
                  style={styles.cardImage}
                  resizeMode="contain"
                />
              </View>

              {/* Weight / Unit above title */}
              <Text style={styles.cardUnitText}>{item.unitMeasure || '500g'}</Text>

              {/* Title */}
              <Text style={styles.cardTitle} numberOfLines={2}>
                {item.name}
              </Text>

              {/* Price Row with Strikethrough & Green Circular + Button */}
              <View style={styles.cardFooter}>
                <View style={styles.pricesColumn}>
                  {item.comparePrice && item.comparePrice > item.price && (
                    <Text style={styles.comparePriceText}>
                      ₹{Number(item.comparePrice).toLocaleString('en-IN')}
                    </Text>
                  )}
                  <Text style={[styles.priceText, item.comparePrice ? styles.priceDiscounted : null]}>
                    ₹{Number(item.price).toLocaleString('en-IN')}
                  </Text>
                </View>

                {qty === 0 ? (
                  <TouchableOpacity
                    style={styles.quickAddBtn}
                    activeOpacity={0.8}
                    onPress={() => {
                      addItem({ ...item, vertical: 'grocery' });
                      if (isAuthenticated) {
                        addToCart({
                          variables: {
                            input: { productId: item._id, quantity: 1 },
                          },
                        });
                      }
                    }}
                  >
                    <Ionicons name="add" size={18} color={COLORS.white} />
                  </TouchableOpacity>
                ) : (
                  <View style={styles.qtyStepperRow}>
                    <TouchableOpacity
                      style={styles.qtyBtn}
                      onPress={() => {
                        updateQuantity(item._id, qty - 1);
                        if (isAuthenticated && cartItem?._id && !cartItem._id.startsWith('temp-')) {
                          updateCartItem({
                            variables: { itemId: cartItem._id, quantity: qty - 1 },
                          });
                        }
                      }}
                      hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                    >
                      <Ionicons name="remove" size={12} color={COLORS.white} />
                    </TouchableOpacity>
                    <Text style={styles.qtyText}>{qty}</Text>
                    <TouchableOpacity
                      style={styles.qtyBtn}
                      onPress={() => {
                        updateQuantity(item._id, qty + 1);
                        if (isAuthenticated) {
                          addToCart({
                            variables: {
                              input: { productId: item._id, quantity: 1 },
                            },
                          });
                        }
                      }}
                      hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
                    >
                      <Ionicons name="add" size={12} color={COLORS.white} />
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </TouchableOpacity>
          );
        }}
      />

      <FloatingCartBar vertical="grocery" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: COLORS.white,
  },
  headerBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 2,
    color: '#0F172A',
  },
  notifBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifBadgeText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: 'bold',
  },
  titleContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },
  mainTitle: {
    fontSize: 22,
    fontWeight: '900',
    color: '#0F172A',
  },
  filterPillsRow: {
    marginBottom: 14,
  },
  filterScroll: {
    paddingHorizontal: 16,
    gap: 8,
  },
  filterPill: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  filterPillActive: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  filterPillText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#334155',
  },
  filterPillTextActive: {
    color: COLORS.white,
    fontWeight: '700',
  },
  gridContent: {
    paddingHorizontal: 16,
    paddingBottom: 140,
  },
  gridRow: {
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  gridCard: {
    width: CARD_WIDTH,
    backgroundColor: COLORS.white,
    borderRadius: 18,
    padding: 12,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    position: 'relative',
    ...SHADOWS.small,
  },
  badgeTag: {
    position: 'absolute',
    top: 10,
    left: 10,
    zIndex: 2,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 8,
  },
  saleBadge: {
    backgroundColor: '#F59E0B',
  },
  organicBadge: {
    backgroundColor: '#10B981',
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  saleBadgeText: {
    color: COLORS.white,
  },
  organicBadgeText: {
    color: COLORS.white,
  },
  cardHeartBtn: {
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 2,
    backgroundColor: 'rgba(255,255,255,0.9)',
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardImageContainer: {
    width: '100%',
    height: 125,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 4,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardUnitText: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 4,
    fontWeight: '600',
  },
  cardTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
    marginTop: 2,
    minHeight: 34,
    lineHeight: 17,
  },
  cardFooter: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: 6,
  },
  pricesColumn: {
    flex: 1,
  },
  comparePriceText: {
    fontSize: 11,
    color: '#94A3B8',
    textDecorationLine: 'line-through',
  },
  priceText: {
    fontSize: 15,
    fontWeight: '900',
    color: '#0F172A',
  },
  priceDiscounted: {
    color: '#059669',
  },
  quickAddBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#059669',
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.small,
  },
  qtyStepperRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#059669',
    borderRadius: 16,
    height: 32,
    paddingHorizontal: 8,
    gap: 6,
    ...SHADOWS.small,
  },
  qtyBtn: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyText: {
    color: COLORS.white,
    fontSize: 13,
    fontWeight: '800',
    minWidth: 16,
    textAlign: 'center',
  },
});
