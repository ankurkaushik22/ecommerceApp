import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useMutation, useQuery } from '@apollo/client';
import { LOGIN_MUTATION, ADD_TO_CART, SEND_LOGIN_OTP, LOGIN_WITH_OTP } from '../../graphql/mutations';
import { GET_STORE_SETTINGS } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen({ navigation, route }) {
  const insets = useSafeAreaInsets();
  const [loginMethod, setLoginMethod] = useState('password'); // 'password' or 'otp'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // OTP state
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');

  const setAuth = useAuthStore((s) => s.setAuth);
  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;

  const [addToCartMutation] = useMutation(ADD_TO_CART);

  const handleLoginSuccess = async (user, token) => {
    await setAuth(user, token);
    try {
      const pendingRaw = await AsyncStorage.getItem('pending_cart_item');
      if (pendingRaw) {
        const pending = JSON.parse(pendingRaw);
        await AsyncStorage.removeItem('pending_cart_item');
        if (pending?.productId) {
          await addToCartMutation({
            variables: { input: pending },
          });
        }
      }
    } catch (err) {
      console.error('Pending cart item error:', err);
    }

    const redirectTarget = route.params?.redirect;
    const redirectParams = route.params?.redirectParams || {};

    const tabScreens = ['HomeTab', 'OrdersTab', 'WishlistTab', 'ProfileTab', 'CartTab'];

    if (redirectTarget) {
      if (tabScreens.includes(redirectTarget)) {
        navigation.replace('MainTabs', { screen: redirectTarget, params: redirectParams });
      } else if (redirectTarget === 'OrdersList') {
        navigation.replace('MainTabs', { screen: 'OrdersTab', params: redirectParams });
      } else {
        navigation.replace(redirectTarget, redirectParams);
      }
    } else if (navigation.canGoBack()) {
      navigation.goBack();
    } else {
      navigation.replace('MainTabs');
    }
  };

  const [loginMutation, { loading: loggingIn }] = useMutation(LOGIN_MUTATION, {
    onCompleted: async (data) => {
      const { user, token } = data.login;
      await handleLoginSuccess(user, token);
    },
    onError: (err) => {
      Alert.alert('Login Failed', err.message || 'Invalid email or password');
    },
  });

  const [sendOtpMutation, { loading: sendingOtp }] = useMutation(SEND_LOGIN_OTP, {
    onCompleted: (data) => {
      Alert.alert('OTP Sent', data.sendLoginOTP?.message || 'Check your WhatsApp or Email for OTP');
      setOtpSent(true);
    },
    onError: (err) => {
      Alert.alert('Failed to send OTP', err.message || 'Could not send OTP');
    },
  });

  const [loginOtpMutation, { loading: loggingInOtp }] = useMutation(LOGIN_WITH_OTP, {
    onCompleted: async (data) => {
      const { user, token } = data.loginWithOTP;
      await handleLoginSuccess(user, token);
    },
    onError: (err) => {
      Alert.alert('OTP Verification Failed', err.message || 'Invalid OTP');
    },
  });

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }
    loginMutation({
      variables: {
        input: { email: email.trim(), password: password.trim() },
      },
    });
  };

  const handleSendOtp = () => {
    if (!email.trim()) {
      Alert.alert('Required Field', 'Please enter your email address');
      return;
    }
    sendOtpMutation({
      variables: { email: email.trim() },
    });
  };

  const handleLoginWithOtp = () => {
    if (!otpCode.trim()) {
      Alert.alert('Required Field', 'Please enter the OTP code');
      return;
    }
    loginOtpMutation({
      variables: { email: email.trim(), otp: otpCode.trim() },
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingTop: Math.max(insets.top, 20) },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Logo / Header */}
        <View style={styles.header}>
          <View style={styles.logoBadge}>
            <Ionicons name="bag-handle" size={32} color={COLORS.white} />
          </View>
          <Text style={styles.title}>Sign in or create account</Text>
          <Text style={styles.subtitle}>
            Manage orders, cart & account on {storeSettings?.storeName || 'Suaaka'}
          </Text>
        </View>

        {/* Tab Switcher: Password | OTP */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tabBtn, loginMethod === 'password' && styles.activeTabBtn]}
            onPress={() => {
              setLoginMethod('password');
              setOtpSent(false);
            }}
          >
            <Text style={[styles.tabText, loginMethod === 'password' && styles.activeTabText]}>
              Password
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.tabBtn, loginMethod === 'otp' && styles.activeTabBtn]}
            onPress={() => setLoginMethod('otp')}
          >
            <Text style={[styles.tabText, loginMethod === 'otp' && styles.activeTabText]}>
              WhatsApp OTP
            </Text>
          </TouchableOpacity>
        </View>

        {/* Card Body */}
        <View style={styles.card}>
          {loginMethod === 'password' ? (
            <>
              {/* Email Input */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Enter mobile number or email</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="mail-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="name@example.com or phone"
                    placeholderTextColor={COLORS.textMuted}
                    keyboardType="default"
                    autoCapitalize="none"
                    maxLength={50}
                    value={email}
                    onChangeText={setEmail}
                  />
                </View>
              </View>

              {/* Password Input */}
              <View style={styles.inputGroup}>
                <View style={styles.labelRow}>
                  <Text style={styles.label}>Password</Text>
                  <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
                    <Text style={styles.forgotText}>Forgot Password?</Text>
                  </TouchableOpacity>
                </View>
                <View style={styles.inputBox}>
                  <Ionicons name="lock-closed-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="Enter your password"
                    placeholderTextColor={COLORS.textMuted}
                    secureTextEntry={!showPassword}
                    maxLength={15}
                    value={password}
                    onChangeText={setPassword}
                  />
                  <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
                    <Ionicons
                      name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                      size={20}
                      color={COLORS.textSecondary}
                    />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Submit Button */}
              <TouchableOpacity
                style={[styles.loginBtn, loggingIn && styles.disabledBtn]}
                onPress={handleLogin}
                disabled={loggingIn}
              >
                {loggingIn ? (
                  <ActivityIndicator color={COLORS.white} />
                ) : (
                  <Text style={styles.loginBtnText}>Continue</Text>
                )}
              </TouchableOpacity>
            </>
          ) : (
            <>
              {/* Email / Mobile Input */}
              <View style={styles.inputGroup}>
                <Text style={styles.label}>WhatsApp Phone number or Email</Text>
                <View style={styles.inputBox}>
                  <Ionicons name="logo-whatsapp" size={20} color="#25D366" style={styles.inputIcon} />
                  <TextInput
                    style={styles.input}
                    placeholder="+919876543210 or name@example.com"
                    placeholderTextColor={COLORS.textMuted}
                    keyboardType="default"
                    autoCapitalize="none"
                    editable={!otpSent}
                    maxLength={50}
                    value={email}
                    onChangeText={setEmail}
                  />
                </View>
              </View>

              {/* OTP Field if Sent */}
              {otpSent && (
                <View style={styles.inputGroup}>
                  <Text style={styles.label}>OTP Code</Text>
                  <View style={styles.inputBox}>
                    <Ionicons name="key-outline" size={20} color={COLORS.textSecondary} style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="Enter 6-digit OTP code"
                      placeholderTextColor={COLORS.textMuted}
                      keyboardType="number-pad"
                      value={otpCode}
                      onChangeText={setOtpCode}
                    />
                  </View>
                </View>
              )}

              {/* Submit Button */}
              <TouchableOpacity
                style={[styles.loginBtn, (sendingOtp || loggingInOtp) && styles.disabledBtn]}
                onPress={otpSent ? handleLoginWithOtp : handleSendOtp}
                disabled={sendingOtp || loggingInOtp}
              >
                {sendingOtp || loggingInOtp ? (
                  <ActivityIndicator color={COLORS.white} />
                ) : (
                  <Text style={styles.loginBtnText}>{otpSent ? 'Login with OTP' : 'Send OTP'}</Text>
                )}
              </TouchableOpacity>

              {otpSent && (
                <TouchableOpacity
                  style={styles.resendBtn}
                  onPress={() => {
                    setOtpSent(false);
                    setOtpCode('');
                  }}
                >
                  <Text style={styles.resendText}>Change Email / Resend OTP</Text>
                </TouchableOpacity>
              )}
            </>
          )}

          {/* Terms & Privacy Notice */}
          <Text style={styles.termsText}>
            By continuing, you agree to {storeSettings?.storeName || 'Suaaka'}'s{' '}
            <Text
              style={styles.linkText}
              onPress={() => navigation.navigate('LegalPage', { slug: 'terms-and-conditions', title: 'Conditions of Use' })}
            >
              Conditions of Use
            </Text>
            {' '}and{' '}
            <Text
              style={styles.linkText}
              onPress={() => navigation.navigate('LegalPage', { slug: 'privacy-policy', title: 'Privacy Notice' })}
            >
              Privacy Notice
            </Text>.
          </Text>

          {/* Buying for work section */}
          <View style={styles.businessDivider} />
          <Text style={styles.businessHeader}>Buying for work?</Text>
          <TouchableOpacity
            style={styles.businessLinkBtn}
            onPress={() => navigation.navigate('BusinessRegister')}
          >
            <Text style={styles.businessLinkText}>Create a free business account</Text>
          </TouchableOpacity>
        </View>

        {/* Regular Register Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>Don't have an account? </Text>
          <TouchableOpacity onPress={() => navigation.navigate('Register')}>
            <Text style={styles.registerText}>Create Account</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scroll: {
    paddingHorizontal: 20,
    paddingBottom: 40,
    justifyContent: 'center',
    minHeight: '100%',
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logoBadge: {
    width: 60,
    height: 60,
    borderRadius: SIZES.radiusLg,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
    ...SHADOWS.glow,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: COLORS.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#E2E8F0',
    borderRadius: 12,
    padding: 4,
    marginBottom: 16,
  },
  tabBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTabBtn: {
    backgroundColor: COLORS.white,
    ...SHADOWS.card,
  },
  tabText: {
    fontSize: SIZES.sm,
    fontWeight: '600',
    color: COLORS.textSecondary,
  },
  activeTabText: {
    color: COLORS.text,
    fontWeight: '800',
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusLg,
    padding: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    ...SHADOWS.card,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 6,
  },
  labelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  forgotText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: '#2563EB',
  },
  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusMd,
    paddingHorizontal: 12,
    height: 48,
  },
  inputIcon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: SIZES.sm,
    color: COLORS.text,
  },
  eyeBtn: {
    padding: 6,
  },
  loginBtn: {
    backgroundColor: '#2563EB',
    borderRadius: SIZES.radiusMd,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
    ...SHADOWS.glow,
  },
  disabledBtn: {
    opacity: 0.7,
  },
  loginBtnText: {
    color: COLORS.white,
    fontSize: SIZES.md,
    fontWeight: '700',
  },
  resendBtn: {
    alignItems: 'center',
    marginTop: 10,
  },
  resendText: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: '#2563EB',
  },
  termsText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    lineHeight: 18,
    marginTop: 16,
  },
  linkText: {
    color: '#2563EB',
    fontWeight: '600',
  },
  businessDivider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginTop: 20,
    marginBottom: 16,
  },
  businessHeader: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 4,
  },
  businessLinkBtn: {
    paddingVertical: 4,
  },
  businessLinkText: {
    fontSize: SIZES.sm,
    fontWeight: '600',
    color: '#2563EB',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 24,
  },
  footerText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
  },
  registerText: {
    fontSize: SIZES.sm,
    fontWeight: '700',
    color: '#2563EB',
  },
});
