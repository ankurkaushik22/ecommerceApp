import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ActivityIndicator,
  Modal,
  Alert,
  Dimensions,
  Vibration,
  StatusBar,
  Switch,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_ME, GET_CATEGORIES, GET_STORE_SETTINGS, GET_BANNERS, GET_ORDERS, GET_CART } from '../../graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM, REMOVE_FROM_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical, getProductAvailableStock } from '../../utils/cartHelpers';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

const stripHtml = (html) => {
  if (!html) return '';
  return String(html)
    .replace(/<br\s*[\/]?>/gi, ' ')
    .replace(/<\/p>/gi, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim();
};

const isCookingInstructionDisabled = (dish) => {
  if (!dish) return false;
  if (dish.allowCookingInstructions === false || dish.hideCookingInstructions === true) return true;

  const name = (dish.name || '').toLowerCase();
  const cat = typeof dish.category === 'string' ? dish.category.toLowerCase() : (dish.category?.name || '').toLowerCase();
  const subcat = typeof dish.subcategory === 'string' ? dish.subcategory.toLowerCase() : (dish.subcategory?.name || '').toLowerCase();
  const cuisineStr = Array.isArray(dish.cuisine) ? dish.cuisine.join(' ').toLowerCase() : (dish.cuisine || '').toLowerCase();
  const tagsStr = Array.isArray(dish.tags) ? dish.tags.join(' ').toLowerCase() : '';

  const keywords = [
    'sweet', 'petha', 'mithai', 'dessert', 'halwa', 'ladoo', 'laddu', 'barfi', 'burfi',
    'gulab jamun', 'rasgulla', 'kaju katli', 'jalebi', 'ice cream', 'beverage', 'drink',
    'shake', 'cold drink', 'soda', 'bakery', 'cake', 'pastry'
  ];

  return keywords.some(kw => name.includes(kw) || cat.includes(kw) || subcat.includes(kw) || cuisineStr.includes(kw) || tagsStr.includes(kw));
};

const CUISINES = [
  {
    id: 'all',
    name: 'All',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
  },
  {
    id: 'biryani',
    name: 'Biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300',
  },
  {
    id: 'pizza',
    name: 'Pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
  },
  {
    id: 'burgers',
    name: 'Burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300',
  },
  {
    id: 'north-indian',
    name: 'North Indian',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=300',
  },
  {
    id: 'chinese',
    name: 'Chinese',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=300',
  },
  {
    id: 'desserts',
    name: 'Desserts',
    image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=300',
  },
  {
    id: 'rolls',
    name: 'Rolls',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=300',
  },
];

const FEATURED_RESTAURANTS = [
  {
    id: 'r1',
    name: 'Behrouz Royal Biryani',
    cuisines: 'Biryani, Mughlai, Kebabs',
    cuisineTags: ['biryani', 'mughlai', 'kebabs', 'north indian', 'hyderabadi'],
    rating: 4.6,
    ratingVal: 4.6,
    time: '25-30 mins',
    prepMinutes: 28,
    price: '₹350 for two',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r2',
    name: "La Pino'z Pizza",
    cuisines: 'Pizzas, Garlic Bread, Pastas',
    cuisineTags: ['pizza', 'pizzas', 'italian', 'pasta', 'fast food', 'garlic bread'],
    rating: 4.4,
    ratingVal: 4.4,
    time: '20-25 mins',
    prepMinutes: 22,
    price: '₹300 for two',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r3',
    name: 'The Burger Club',
    cuisines: 'Burgers, American, Shakes',
    cuisineTags: ['burger', 'burgers', 'american', 'shakes', 'fast food'],
    rating: 4.5,
    ratingVal: 4.5,
    time: '15-20 mins',
    prepMinutes: 18,
    price: '₹250 for two',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r4',
    name: 'Punjab Grill Express',
    cuisines: 'North Indian, Dal Makhani, Paneer Tikka',
    cuisineTags: ['north indian', 'curry', 'punjabi', 'paneer', 'thali', 'indian', 'dal makhani'],
    rating: 4.7,
    ratingVal: 4.7,
    time: '20-25 mins',
    prepMinutes: 20,
    price: '₹320 for two',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=600',
    isVeg: true,
    hasDeals: true,
  },
  {
    id: 'r5',
    name: 'Wow! Momo Magic',
    cuisines: 'Momos, Chinese, Tibetan, Snacks',
    cuisineTags: ['chinese', 'momos', 'momo', 'tibetan', 'asian', 'noodles', 'dimsum'],
    rating: 4.5,
    ratingVal: 4.5,
    time: '15-20 mins',
    prepMinutes: 15,
    price: '₹200 for two',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r6',
    name: 'Rolls Mania Express',
    cuisines: 'Kathi Rolls, Wraps, Fast Food',
    cuisineTags: ['rolls & wraps', 'rolls', 'wraps', 'kathi', 'rolls mania', 'fast food'],
    rating: 4.6,
    ratingVal: 4.6,
    time: '15-20 mins',
    prepMinutes: 15,
    price: '₹180 for two',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600',
    isVeg: false,
    hasDeals: true,
  },
];

const FALLBACK_FOOD = [
  {
    _id: 'food-fb-1',
    name: 'Hyderabadi Chicken Dum Biryani',
    slug: 'hyderabadi-chicken-dum-biryani',
    restaurantName: 'Behrouz Royal Biryani',
    cuisine: ['Biryani', 'Hyderabadi'],
    price: 349,
    comparePrice: 429,
    isVeg: false,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500'],
    rating: { average: 4.6, count: 1420 },
    description: 'Authentic dum cooked long grain basmati rice layered with aromatic spices and tender bone-in chicken.',
    vertical: 'food',
    variants: [
      {
        name: 'Portion / Size',
        options: [
          { label: 'Half Portion', price: 199 },
          { label: 'Full Portion', price: 349 },
          { label: 'Family Jumbo Pack', price: 649 },
        ],
      },
    ],
    addons: [
      { name: 'Extra Salan & Raita', price: 30, icon: '🥣' },
      { name: 'Extra Boiled Egg', price: 20, icon: '🥚' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'food-fb-2',
    name: 'Paneer Tikka Butter Masala',
    slug: 'paneer-tikka-butter-masala',
    restaurantName: 'Punjab Grill Express',
    cuisine: ['North Indian', 'Curry'],
    price: 289,
    comparePrice: 349,
    isVeg: true,
    preparationTime: 20,
    images: ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=500'],
    rating: { average: 4.5, count: 890 },
    description: 'Tandoori cottage cheese cubes simmered in a rich tomato, cashew nut and butter gravy.',
    vertical: 'food',
    variants: [
      {
        name: 'Portion Size',
        options: [
          { label: 'Half Portion (300ml)', price: 169 },
          { label: 'Full Portion (600ml)', price: 289 },
        ],
      },
    ],
    addons: [
      { name: 'Extra Butter Naan', price: 40, icon: '🫓' },
      { name: 'Jeera Rice Cup', price: 60, icon: '🍚' },
      { name: 'Extra Amul Butter', price: 20, icon: '🧈' },
    ],
  },
  {
    _id: 'food-fb-3',
    name: 'Farmhouse Loaded Italian Pizza',
    slug: 'farmhouse-loaded-italian-pizza',
    restaurantName: "La Pino'z Pizza",
    cuisine: ['Pizza', 'Italian'],
    price: 379,
    comparePrice: 499,
    isVeg: true,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500'],
    rating: { average: 4.4, count: 750 },
    description: 'Crisp hand-stretched crust topped with marinara, mozzarella, bell peppers and olives.',
    vertical: 'food',
    variants: [
      {
        name: 'Crust & Size',
        options: [
          { label: 'Personal 7"', price: 199 },
          { label: 'Medium 10"', price: 379 },
          { label: 'Large 12"', price: 549 },
        ],
      },
    ],
    addons: [
      { name: 'Extra Mozzarella Cheese', price: 45, icon: '🧀' },
      { name: 'Garlic Dip', price: 25, icon: '🧄' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'food-fb-4',
    name: 'Crispy Double Patty Chicken Burger',
    slug: 'crispy-double-patty-chicken-burger',
    restaurantName: 'The Burger Club',
    cuisine: ['Burger', 'Fast Food'],
    price: 219,
    comparePrice: 279,
    isVeg: false,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500'],
    rating: { average: 4.5, count: 1100 },
    description: 'Two golden fried chicken fillets with smoky chipotle mayo on toasted brioche bun.',
    vertical: 'food',
    variants: [
      {
        name: 'Patty Count',
        options: [
          { label: 'Single Patty Burger', price: 149 },
          { label: 'Double Patty Burger', price: 219 },
        ],
      },
    ],
    addons: [
      { name: 'Cheddar Cheese Slice', price: 30, icon: '🧀' },
      { name: 'Crispy Peri Peri Fries', price: 59, icon: '🍟' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'food-fb-5',
    name: 'Steamed Himalayan Veg Momos',
    slug: 'steamed-himalayan-veg-darjeeling-momos',
    restaurantName: 'Wow! Momo Magic',
    cuisine: ['Chinese', 'Tibetan'],
    price: 139,
    comparePrice: 179,
    isVeg: true,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=500'],
    rating: { average: 4.3, count: 620 },
    description: 'Thin wrapper dumplings packed with veggies, served with fiery red chili chutney.',
    vertical: 'food',
    variants: [
      {
        name: 'Quantity',
        options: [
          { label: 'Half Plate (6 Pcs)', price: 139 },
          { label: 'Full Plate (10 Pcs)', price: 199 },
        ],
      },
    ],
    addons: [
      { name: 'Extra Schezwan Chutney', price: 20, icon: '🌶️' },
      { name: 'Mayonnaise Dip', price: 20, icon: '🥣' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'food-fb-6',
    name: 'Belgian Dark Chocolate Thick Shake',
    slug: 'belgian-dark-chocolate-thick-shake',
    restaurantName: 'Keventers Thick Shakes',
    cuisine: ['Desserts', 'Beverages'],
    price: 199,
    comparePrice: 249,
    isVeg: true,
    preparationTime: 10,
    images: ['https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=500'],
    rating: { average: 4.7, count: 530 },
    description: 'Rich and creamy thick shake blended with imported Belgian cocoa and dark chocolate fudge.',
    vertical: 'food',
    variants: [
      {
        name: 'Glass Size',
        options: [
          { label: 'Regular 350ml', price: 149 },
          { label: 'Large 500ml', price: 199 },
        ],
      },
    ],
    addons: [
      { name: 'Extra Vanilla Scoop', price: 40, icon: '🍨' },
      { name: 'Extra Roasted Nuts', price: 30, icon: '🥜' },
    ],
  },
];

export default function FoodHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const mainScrollViewRef = useRef(null);
  const [dishesLayoutY, setDishesLayoutY] = useState(0);
  const [search, setSearch] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('all');
  const [dietaryFilter, setDietaryFilter] = useState('all'); // 'all' | 'veg' | 'non-veg'
  const [activeFilter, setActiveFilter] = useState('all'); // all, rating, fast, offers
  const [vegModalVisible, setVegModalVisible] = useState(false);
  const [vegChoice, setVegChoice] = useState('all'); // 'all' | 'veg_only'
  const [rememberChoice, setRememberChoice] = useState(true);
  const [customizingDish, setCustomizingDish] = useState(null);
  const [selectedVariantOption, setSelectedVariantOption] = useState(null);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [itemInstructions, setItemInstructions] = useState('');
  const [hideInstructionsLocal, setHideInstructionsLocal] = useState(false);

  const [selectedRestaurant, setSelectedRestaurant] = useState(null);

  const [cuisinesLayoutY, setCuisinesLayoutY] = useState(0);

  const scrollToCuisines = () => {
    if (mainScrollViewRef.current && cuisinesLayoutY > 0) {
      mainScrollViewRef.current.scrollTo({ y: Math.max(0, cuisinesLayoutY - 10), animated: true });
    }
  };

  const handleSelectRestaurant = (restaurantName) => {
    if (selectedRestaurant === restaurantName) {
      setSelectedRestaurant(null);
    } else {
      setSelectedRestaurant(restaurantName);
      if (mainScrollViewRef.current && dishesLayoutY > 0) {
        mainScrollViewRef.current.scrollTo({ y: Math.max(0, dishesLayoutY - 10), animated: true });
      }
    }
  };

  const handleSelectCuisine = (cuisineId) => {
    setSelectedCuisine(cuisineId);
    scrollToCuisines();
  };

  useEffect(() => {
    if (AsyncStorage && typeof AsyncStorage.getItem === 'function') {
      AsyncStorage.getItem('saved_veg_preference')
        .then((val) => {
          if (val === 'veg_only') {
            setDietaryFilter('veg');
            setVegChoice('veg_only');
          }
        })
        .catch(() => {});
    }
  }, []);

  const { items = [], addItem, updateQuantity, setCart } = useCartStore();
  const { isAuthenticated } = useAuthStore();
  const { toggleWishlist, isInWishlist } = useWishlistStore();

  const { data: userData } = useQuery(GET_ME, { skip: !isAuthenticated });
  const user = userData?.me;

  const { data: cartQueryData, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  useEffect(() => {
    if (cartQueryData?.getCart) {
      setCart(cartQueryData.getCart);
    }
  }, [cartQueryData, setCart]);

  useFocusEffect(
    useCallback(() => {
      if (isAuthenticated) {
        refetchCart?.();
      }
    }, [isAuthenticated, refetchCart])
  );

  const [addToCartMutation] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      if (res?.addToCart) setCart(res.addToCart);
    },
    onError: (err) => {
      Alert.alert('Notice 🔴', err?.message || 'Item is currently unavailable.');
    },
  });

  const [updateCartItemMutation] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      if (res?.updateCartItem) setCart(res.updateCartItem);
    },
    onError: (err) => {
      Alert.alert('Notice 🔴', err?.message || 'Unable to update cart.');
    },
  });

  const [removeFromCartMutation] = useMutation(REMOVE_FROM_CART, {
    onCompleted: (res) => {
      if (res?.removeFromCart) setCart(res.removeFromCart);
    },
    onError: (err) => {
      Alert.alert('Notice 🔴', err?.message || 'Unable to remove item.');
    },
  });

  // Fetch admin banners managed for Food vertical
  const { data: bannerData } = useQuery(GET_BANNERS, {
    variables: { platform: 'mobile', vertical: 'food' },
    fetchPolicy: 'cache-and-network',
  });

  // Fetch past orders for Reorder / Past Orders filter
  const { data: pastOrdersData } = useQuery(GET_ORDERS, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const pastOrderDishNames = useMemo(() => {
    const ordersList = pastOrdersData?.getOrders?.orders || (Array.isArray(pastOrdersData?.getOrders) ? pastOrdersData.getOrders : []);
    const namesSet = new Set();
    ordersList.forEach((o) => {
      (o.items || []).forEach((it) => {
        if (it.name) namesSet.add(it.name.toLowerCase().trim());
      });
    });
    return Array.from(namesSet);
  }, [pastOrdersData]);

  const adminFoodBanners = useMemo(() => {
    const fetched = bannerData?.getBanners || [];
    const active = fetched.filter((b) => b.isActive !== false);
    if (active.length > 0) return active;
    // Fallback hero banner matching reference image 2 if no admin banner uploaded yet
    return [
      {
        _id: 'hero-fb-1',
        title: 'ITEMS AT',
        discountText: '50% OFF',
        image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=600',
        bgHex: '#DC2626',
        buttonText: 'Order now ›',
        isFallback: true,
      },
    ];
  }, [bannerData]);

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  // Fetch categories scoped to Food vertical
  const { data: catData, loading: categoriesLoading } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'food' },
    fetchPolicy: 'cache-and-network',
  });

  const dynamicCuisines = useMemo(() => {
    const fetched = catData?.getCategories || [];
    // Don't fall back to static CUISINES while loading — return empty to show skeleton
    if (!fetched.length) return [];

    const formatted = fetched.map((c) => ({
      id: c.slug || c._id,
      _id: c._id,
      slug: c.slug,
      name: c.name,
      children: c.children || [],
      image: c.image || c.icon || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
    }));
    return [
      { id: 'all', name: 'All', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300' },
      ...formatted,
    ];
  }, [catData]);

  // Fetch products scoped to Food vertical
  const { data, loading, refetch } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'food',
        search: search.trim() || undefined,
        isVeg: dietaryFilter === 'veg' ? true : dietaryFilter === 'non-veg' ? false : undefined,
      },
      pagination: { page: 1, limit: 50 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products;
  const products = rawProducts || [];

  // Filter products by cuisine and pill
  const filteredProducts = useMemo(() => {
    const activeCuisineObj = dynamicCuisines.find(
      (c) => c.id === selectedCuisine || c.slug === selectedCuisine || c._id === selectedCuisine || c.name === selectedCuisine
    );

    return products.filter((item) => {
      if (selectedRestaurant) {
        const target = selectedRestaurant.toLowerCase();
        const rName = (item.restaurantName || '').toLowerCase();
        const pName = (item.name || '').toLowerCase();
        const matchesRest = rName.includes(target) || target.includes(rName) || pName.includes(target);
        if (!matchesRest) return false;
      }

      if (dietaryFilter === 'veg' && item.isVeg === false) return false;
      if (dietaryFilter === 'non-veg' && item.isVeg !== false) return false;

      if (selectedCuisine !== 'all') {
        const catId = item.category?._id?.toString();
        const catSlug = item.category?.slug?.toLowerCase();
        const catName = item.category?.name?.toLowerCase();

        const subcatId = item.subcategory?._id?.toString();
        const subcatSlug = item.subcategory?.slug?.toLowerCase();
        const subcatName = item.subcategory?.name?.toLowerCase();

        const parentCatId = (item.category?.parent?._id || item.category?.parent)?.toString();
        const parentCatSlug = item.category?.parent?.slug?.toLowerCase();
        const parentCatName = item.category?.parent?.name?.toLowerCase();

        const activeId = activeCuisineObj?._id?.toString();
        const activeSlug = activeCuisineObj?.slug?.toLowerCase() || activeCuisineObj?.id?.toLowerCase();
        const activeName = activeCuisineObj?.name?.toLowerCase();

        let matchesCuisine = false;

        // Check direct category / subcategory / parent IDs, Slugs, and Names
        if (activeId && (catId === activeId || subcatId === activeId || parentCatId === activeId)) {
          matchesCuisine = true;
        } else if (activeSlug && (catSlug === activeSlug || subcatSlug === activeSlug || parentCatSlug === activeSlug)) {
          matchesCuisine = true;
        } else if (activeName && (catName === activeName || subcatName === activeName || parentCatName === activeName)) {
          matchesCuisine = true;
        }

        // Check if item category is one of the children subcategories of the selected category tab
        if (!matchesCuisine && activeCuisineObj?.children && activeCuisineObj.children.length > 0) {
          const childIds = activeCuisineObj.children.map((ch) => ch._id?.toString());
          const childSlugs = activeCuisineObj.children.map((ch) => ch.slug?.toLowerCase());
          const childNames = activeCuisineObj.children.map((ch) => ch.name?.toLowerCase());

          if ((catId && childIds.includes(catId)) || (subcatId && childIds.includes(subcatId))) {
            matchesCuisine = true;
          } else if ((catSlug && childSlugs.includes(catSlug)) || (subcatSlug && childSlugs.includes(subcatSlug))) {
            matchesCuisine = true;
          } else if ((catName && childNames.includes(catName)) || (subcatName && childNames.includes(subcatName))) {
            matchesCuisine = true;
          }
        }

        // Fallback matching logic on dish name, description, restaurant, and cuisine array
        if (!matchesCuisine) {
          const dishCuisines = (item.cuisine || []).map((c) => c.toLowerCase().replace(/[-_&]/g, ' '));
          const dishName = (item.name || '').toLowerCase();
          const dishRest = (item.restaurantName || '').toLowerCase();

          const normCuisine = (activeName || selectedCuisine).replace(/[-_&]/g, ' ').toLowerCase();

          if (normCuisine.includes('pizza')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('pizza') || c.includes('italian')) ||
              dishName.includes('pizza');
          } else if (normCuisine.includes('biryani')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('biryani') || c.includes('mughlai') || c.includes('hyderabadi')) ||
              dishName.includes('biryani');
          } else if (normCuisine.includes('burg')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('burger') || c.includes('american')) ||
              dishName.includes('burger');
          } else {
            matchesCuisine =
              dishCuisines.some((c) => c.includes(normCuisine) || normCuisine.includes(c)) ||
              dishName.includes(normCuisine) ||
              dishRest.includes(normCuisine) ||
              (catName && catName.includes(normCuisine)) ||
              (subcatName && subcatName.includes(normCuisine));
          }
        }

        if (!matchesCuisine) return false;
      }

      if (activeFilter === 'rating' && (item.rating?.average || 0) < 4.4) return false;
      if (activeFilter === 'fast' && (item.preparationTime || 30) > 20) return false;
      if (activeFilter === 'offers') {
        const hasOffer = (item.comparePrice && item.comparePrice > item.price) || item.hasDeals || (item.discount && item.discount > 0);
        if (!hasOffer) return false;
      }
      if (activeFilter === 'past_orders') {
        if (pastOrderDishNames.length > 0) {
          const pName = (item.name || '').toLowerCase().trim();
          const matchesPast = pastOrderDishNames.some((n) => pName.includes(n) || n.includes(pName));
          if (!matchesPast) return false;
        }
      }

      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesRest = item.restaurantName?.toLowerCase().includes(q);
        if (!matchesName && !matchesRest) return false;
      }

      return true;
    });
  }, [products, dietaryFilter, selectedCuisine, activeFilter, search, selectedRestaurant, pastOrderDishNames]);

  const filteredRestaurants = useMemo(() => {
    const list = Array.isArray(FEATURED_RESTAURANTS) ? FEATURED_RESTAURANTS : [];
    return list.filter((rest) => {
      if (!rest) return false;
      const restName = (rest.name || '').toLowerCase();
      const restCuisines = (rest.cuisines || '').toLowerCase();

      // 1. Dietary filter
      if (dietaryFilter === 'veg' && !rest.isVeg) {
        const hasVegProduct = (products || []).some(
          (p) => (p.restaurantName || '').toLowerCase().includes(restName) && p.isVeg
        );
        if (!hasVegProduct) return false;
      }

      // 2. Active filter (rating, fast, offers)
      const rRating = rest.ratingVal || rest.rating || 0;
      if (activeFilter === 'rating' && rRating < 4.4) return false;
      if (activeFilter === 'fast' && (rest.prepMinutes || 30) > 20) return false;
      if (activeFilter === 'offers' && !rest.hasDeals) return false;

      // 3. Cuisine filter
      if (selectedCuisine && selectedCuisine !== 'all') {
        const activeName = selectedCuisine.toLowerCase().replace(/[-_&]/g, ' ').trim();
        const matchesTag = (rest.cuisineTags || []).some((tag) => tag.includes(activeName) || activeName.includes(tag));
        if (!matchesTag && !restName.includes(activeName) && !restCuisines.includes(activeName)) {
          return false;
        }
      }

      // 4. Search query filter
      if (search.trim()) {
        const q = search.toLowerCase().trim();
        const matchesName = restName.includes(q);
        const matchesCuisines = restCuisines.includes(q);
        const matchesTag = (rest.cuisineTags || []).some((tag) => tag.includes(q) || q.includes(tag));
        const matchesProduct = (products || []).some(
          (p) => (p.restaurantName || '').toLowerCase().includes(restName) &&
            ((p.name || '').toLowerCase().includes(q) ||
             (p.description || '').toLowerCase().includes(q))
        );
        if (!matchesName && !matchesCuisines && !matchesTag && !matchesProduct) return false;
      }

      return true;
    });
  }, [dietaryFilter, activeFilter, selectedCuisine, search, products]);

  const handleAddToCart = async (product) => {
    const pId = product._id || product.productId;
    const currentQty = getItemQuantity(pId);
    const availStock = getProductAvailableStock(product);
    if (availStock <= 0) {
      Alert.alert('Out of Stock 🔴', 'Sorry, this dish is currently out of stock.');
      return;
    }
    if (currentQty + 1 > availStock) {
      Alert.alert('Stock Limit Reached', `Only ${availStock} available in stock.`);
      return;
    }

    try {
      Vibration.vibrate(40);
    } catch {}

    const foodProduct = { ...product, vertical: 'food' };

    addItem(foodProduct);

    if (isAuthenticated) {
      const isMongoId = /^[0-9a-fA-F]{24}$/.test(product._id || product.productId);
      if (isMongoId) {
        try {
          const vIdx = product.variantIndex !== undefined ? product.variantIndex : (product.selectedVariantIndex !== undefined ? product.selectedVariantIndex : -1);
          const vLabel = product.variantLabel || (product.selectedVariantOption ? (product.selectedVariantOption.label || product.selectedVariantOption.name) : undefined);
          await addToCartMutation({
            variables: {
              input: {
                productId: product._id || product.productId,
                quantity: 1,
                variantIndex: vIdx >= 0 ? vIdx : undefined,
                variantLabel: vLabel || undefined,
                addons: (product.addons || []).map((a) => ({ name: a.name, price: a.price, icon: a.icon })),
                instructions: product.instructions || '',
                customPrice: product.price,
              },
            },
          });
        } catch (err) {
          console.warn('Backend cart sync error:', err.message);
        }
      }
    }
  };

  const getItemQuantity = (productId) => {
    const item = items.find((i) => i.product?._id === productId || i.productId === productId || i._id === productId);
    return item ? item.quantity : 0;
  };

  const foodCartItems = filterItemsByVertical(items || [], 'food');
  const totalFoodItems = foodCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = foodCartItems.reduce((sum, i) => sum + ((i?.price || i?.product?.price || 0) * (i?.quantity || 0)), 0);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('food')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🍔</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Food Delivery Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting food orders. Please check back later or explore our other products!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />

      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity
            onPress={() => {
              if (navigation.canGoBack()) {
                navigation.goBack();
              } else {
                navigation.navigate('MainTabs');
              }
            }}
            style={styles.backButton}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="arrow-back" size={22} color="#1F2937" />
          </TouchableOpacity>
          <View style={styles.deliveryLocation}>
            <View style={styles.locationTitleRow}>
              <Ionicons name="location-sharp" size={16} color="#EA580C" />
              <Text style={styles.deliveryToText}>DELIVER TO</Text>
              <Ionicons name="chevron-down" size={14} color="#6B7280" />
            </View>
            <Text style={styles.addressText} numberOfLines={1}>
              {user?.addresses?.find((a) => a.isDefault)?.city || 'Home • MG Road, Central City'}
            </Text>
          </View>
        </View>

      </View>

      {/* Swiggy-style Veg Choice Modal */}
      <Modal
        visible={vegModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setVegModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity
            style={StyleSheet.absoluteFill}
            activeOpacity={1}
            onPress={() => setVegModalVisible(false)}
          />
          <View style={styles.vegModalCard}>
            {/* Top Close Button & Graphic */}
            <View style={styles.modalHeaderRow}>
              <Text style={styles.modalHeaderTitle}>
                I want to see veg{'\n'}choices from
              </Text>
              <View style={styles.modalHeaderRight}>
                <Image
                  source={{ uri: 'https://cdn-icons-png.flaticon.com/512/3480/3480823.png' }}
                  style={styles.modalBowlImg}
                />
                <TouchableOpacity
                  onPress={() => setVegModalVisible(false)}
                  style={styles.modalCloseBtn}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Ionicons name="close" size={20} color="#64748B" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Radio Options */}
            <View style={styles.radioOptionsGroup}>
              {/* Option 1: All restaurants */}
              <TouchableOpacity
                style={styles.radioRow}
                activeOpacity={0.8}
                onPress={() => setVegChoice('all')}
              >
                <Text style={[styles.radioLabelText, vegChoice === 'all' && styles.radioLabelTextSelected]}>
                  All restaurants
                </Text>
                <View style={[styles.radioOuter, vegChoice === 'all' && styles.radioOuterSelected]}>
                  {vegChoice === 'all' && <View style={styles.radioInnerGreen} />}
                </View>
              </TouchableOpacity>

              {/* Option 2: Pure veg restaurants only */}
              <TouchableOpacity
                style={styles.radioRow}
                activeOpacity={0.8}
                onPress={() => setVegChoice('veg_only')}
              >
                <Text style={[styles.radioLabelText, vegChoice === 'veg_only' && styles.radioLabelTextSelected]}>
                  Pure veg restaurants only
                </Text>
                <View style={[styles.radioOuter, vegChoice === 'veg_only' && styles.radioOuterSelected]}>
                  {vegChoice === 'veg_only' && <View style={styles.radioInnerGreen} />}
                </View>
              </TouchableOpacity>
            </View>

            {/* Dotted Line Divider */}
            <View style={styles.dottedDivider} />

            {/* Remember my choice checkbox */}
            <TouchableOpacity
              style={styles.checkboxRow}
              activeOpacity={0.8}
              onPress={() => setRememberChoice(!rememberChoice)}
            >
              <Text style={styles.checkboxLabelText}>Remember my choice going forward</Text>
              <View style={[styles.checkboxBox, rememberChoice && styles.checkboxBoxChecked]}>
                {rememberChoice && <Ionicons name="checkmark" size={13} color="#059669" />}
              </View>
            </TouchableOpacity>

            {/* Apply Button */}
            <TouchableOpacity
              style={styles.applyVegBtn}
              activeOpacity={0.88}
              onPress={async () => {
                try {
                  Vibration.vibrate(40);
                } catch {}

                if (vegChoice === 'veg_only') {
                  setDietaryFilter('veg');
                } else {
                  setDietaryFilter('all');
                }

                if (rememberChoice && AsyncStorage && typeof AsyncStorage.setItem === 'function') {
                  AsyncStorage.setItem('saved_veg_preference', vegChoice).catch(() => {});
                } else if (AsyncStorage && typeof AsyncStorage.removeItem === 'function') {
                  AsyncStorage.removeItem('saved_veg_preference').catch(() => {});
                }
                setVegModalVisible(false);
              }}
            >
              <Text style={styles.applyVegBtnText}>Show restaurants</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Customization & Add-ons Bottom Sheet Modal */}
      <Modal
        visible={!!customizingDish}
        transparent
        animationType="slide"
        onRequestClose={() => setCustomizingDish(null)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity
            style={StyleSheet.absoluteFill}
            activeOpacity={1}
            onPress={() => setCustomizingDish(null)}
          />
          <View style={[styles.vegModalCard, { maxHeight: '85%', padding: 20 }]}>
            {customizingDish && (
              <>
                <View style={styles.modalHeaderRow}>
                  <View style={{ flex: 1, paddingRight: 10 }}>
                    <View style={styles.vegIndicatorRow}>
                      <View style={[styles.vegBox, customizingDish.isVeg !== false ? styles.vegBoxGreen : styles.vegBoxRed]}>
                        <View style={[styles.vegInner, customizingDish.isVeg !== false ? styles.vegInnerGreen : styles.vegInnerRed]} />
                      </View>
                      <Text style={[styles.vegLabelText, customizingDish.isVeg !== false ? { color: '#16A34A' } : { color: '#DC2626' }]}>
                        {customizingDish.isVeg !== false ? 'VEG' : 'NON-VEG'}
                      </Text>
                    </View>
                    <Text style={[styles.dishName, { fontSize: 17, marginTop: 4 }]}>{customizingDish.name}</Text>
                    <Text style={styles.dishPrice}>₹{customizingDish.price}</Text>
                  </View>
                  <TouchableOpacity onPress={() => setCustomizingDish(null)} style={styles.modalCloseBtn}>
                    <Ionicons name="close" size={20} color="#64748B" />
                  </TouchableOpacity>
                </View>

                <ScrollView showsVerticalScrollIndicator={false} style={{ marginVertical: 10 }}>
                  {/* Food Variants / Portion Size Section */}
                  {Boolean(customizingDish.variants && customizingDish.variants.length > 0) && (
                    <View style={{ marginBottom: 16 }}>
                      <Text style={styles.customSectionTitle}>
                        {customizingDish.variants[0]?.name?.toUpperCase() || 'SELECT VARIANT / PORTION'}
                      </Text>
                      {customizingDish.variants.map((vGroup, vGroupIdx) => (
                        <View key={vGroupIdx} style={{ gap: 8 }}>
                          {(vGroup.options || []).map((opt, optIdx) => {
                            const isSelected =
                              (selectedVariantOption?.label || selectedVariantOption?.name) === (opt.label || opt.name) ||
                              (!selectedVariantOption && optIdx === 0);
                            return (
                              <TouchableOpacity
                                key={optIdx}
                                style={[
                                  styles.addonRow,
                                  isSelected && { borderColor: '#EA580C', backgroundColor: '#FFF7ED' },
                                ]}
                                activeOpacity={0.8}
                                onPress={() => setSelectedVariantOption(opt)}
                              >
                                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                                  <View style={[styles.radioOuter, isSelected && styles.radioOuterSelected]}>
                                    {isSelected && <View style={styles.radioInnerGreen} />}
                                  </View>
                                  <Text style={[styles.addonName, isSelected && { fontWeight: '800', color: '#EA580C' }]}>
                                    {opt.label || opt.name}
                                  </Text>
                                </View>
                                <Text style={styles.addonPrice}>₹{opt.price}</Text>
                              </TouchableOpacity>
                            );
                          })}
                        </View>
                      ))}
                    </View>
                  )}

                  {customizingDish.addons && customizingDish.addons.length > 0 && (
                    <>
                      <Text style={styles.customSectionTitle}>ADD-ONS & EXTRAS</Text>
                      {customizingDish.addons.map((addon, aIdx) => {
                        const isSelected = selectedAddons.some((a) => a.name === addon.name);
                        return (
                          <TouchableOpacity
                            key={addon._id || addon.name || aIdx}
                            style={styles.addonRow}
                            activeOpacity={0.8}
                            onPress={() => {
                              if (isSelected) {
                                setSelectedAddons(selectedAddons.filter((a) => a.name !== addon.name));
                              } else {
                                setSelectedAddons([...selectedAddons, addon]);
                              }
                            }}
                          >
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                              <Text style={{ fontSize: 18 }}>{addon.icon || '🍽️'}</Text>
                              <Text style={styles.addonName}>{addon.name}</Text>
                            </View>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                              <Text style={styles.addonPrice}>+₹{addon.price}</Text>
                              <View style={[styles.checkboxBox, isSelected && styles.checkboxBoxChecked]}>
                                {isSelected && <Ionicons name="checkmark" size={13} color="#059669" />}
                              </View>
                            </View>
                          </TouchableOpacity>
                        );
                      })}
                    </>
                  )}

                  {/* Instructions Section */}
                  <View style={{ marginTop: 14 }}>
                    <Text style={[styles.customSectionTitle, { marginBottom: 8 }]}>
                      INSTRUCTIONS
                    </Text>
                    <TextInput
                      style={styles.customInstructionInput}
                      placeholder="e.g. Less oil, extra sauce, make it crispy..."
                      placeholderTextColor="#9CA3AF"
                      value={itemInstructions}
                      onChangeText={setItemInstructions}
                      multiline
                    />

                    {/* Quick Chips */}
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                      {['Less spicy', 'Extra sauce', 'Make it crispy', 'No onion/garlic'].map((chip) => (
                        <TouchableOpacity
                          key={chip}
                          onPress={() => {
                            if (!itemInstructions.includes(chip)) {
                              setItemInstructions((prev) => (prev ? `${prev}, ${chip}` : chip));
                            }
                          }}
                          style={styles.instructionChip}
                        >
                          <Text style={styles.instructionChipText}>+ {chip}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                </ScrollView>

                <TouchableOpacity
                  style={styles.applyVegBtn}
                  activeOpacity={0.88}
                  onPress={() => {
                    const currentBasePrice = selectedVariantOption ? selectedVariantOption.price : customizingDish.price;
                    const addonTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
                    const finalPrice = currentBasePrice + addonTotal;
                    const customizedProduct = {
                      ...customizingDish,
                      price: finalPrice,
                      variantLabel: selectedVariantOption ? (selectedVariantOption.label || selectedVariantOption.name) : undefined,
                      addons: selectedAddons,
                      instructions: itemInstructions,
                    };
                    handleAddToCart(customizedProduct);
                    setCustomizingDish(null);
                  }}
                >
                  <Text style={styles.applyVegBtnText}>
                    ADD ITEM • ₹{(selectedVariantOption ? selectedVariantOption.price : customizingDish.price) + selectedAddons.reduce((sum, a) => sum + a.price, 0)}
                  </Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Fixed Non-Scrollable Search Bar & VEG MODE Toggle Header */}
      <View style={styles.stickyFilterHeader}>
        <View style={styles.zomatoSearchRow}>
          <View style={styles.zomatoSearchBox}>
            <Ionicons name="search-outline" size={20} color="#E11D48" style={{ marginRight: 8 }} />
            <TextInput
              style={styles.zomatoSearchInput}
              placeholder='Search "curries", "pizza", "biryani"...'
              placeholderTextColor="#9CA3AF"
              value={search}
              onChangeText={setSearch}
            />
            {search ? (
              <TouchableOpacity onPress={() => setSearch('')}>
                <Ionicons name="close-circle" size={16} color="#9CA3AF" />
              </TouchableOpacity>
            ) : null}
          </View>

          {/* VEG MODE Toggle */}
          <View style={styles.vegModeContainer}>
            <Text style={styles.vegModeText}>VEG{'\n'}MODE</Text>
            <Switch
              value={dietaryFilter === 'veg'}
              onValueChange={(val) => setDietaryFilter(val ? 'veg' : 'all')}
              trackColor={{ false: '#E2E8F0', true: '#10B981' }}
              thumbColor={dietaryFilter === 'veg' ? '#059669' : '#94A3B8'}
            />
          </View>
        </View>
      </View>

      <ScrollView
        ref={mainScrollViewRef}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >

        {/* Child 1: Promotional Hero Banner Carousel (Positioned directly BELOW the search bar) */}
        <View style={styles.zomatoBannerWrapper}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={(e) => {
              const slide = Math.round(e.nativeEvent.contentOffset.x / (width - 32));
              if (slide !== activeBannerIdx) setActiveBannerIdx(slide);
            }}
            scrollEventThrottle={16}
          >
            {adminFoodBanners.map((b, bIdx) => {
              const showFullImg = Boolean(b.image && (!b.isFallback || (!b.title && !b.discountText)));
              return (
                <TouchableOpacity
                  key={b._id || bIdx}
                  activeOpacity={0.92}
                  style={styles.zomatoBannerCard}
                  onPress={() => setActiveFilter(activeFilter === 'offers' ? 'all' : 'offers')}
                >
                  {showFullImg ? (
                    <Image
                      source={{ uri: b.image }}
                      style={styles.bannerFullImg}
                      resizeMode="cover"
                    />
                  ) : (
                    <View style={[styles.zomatoBannerContentWrap, { backgroundColor: b.bgHex || '#DC2626' }]}>
                      <View style={styles.zomatoBannerLeft}>
                        {b.tag ? (
                          <View style={styles.bannerTagPill}>
                            <Text style={styles.bannerTagPillText}>{b.tag}</Text>
                          </View>
                        ) : null}
                        <Text style={styles.zomatoBannerTitle}>{b.title || 'ITEMS AT'}</Text>
                        <Text style={styles.zomatoBannerDiscount}>{b.discount || b.discountText || '50% OFF'}</Text>
                        <View style={styles.zomatoBannerBtn}>
                          <Text style={styles.zomatoBannerBtnText}>{b.buttonText || 'Order now ›'}</Text>
                        </View>
                      </View>

                      {b.image ? (
                        <Image
                          source={{ uri: b.image }}
                          style={styles.zomatoBannerImg}
                          resizeMode="cover"
                        />
                      ) : null}
                    </View>
                  )}
                </TouchableOpacity>
              );
            })}
          </ScrollView>

          {/* Carousel Pagination Dots */}
          {adminFoodBanners.length > 1 && (
            <View style={styles.bannerDotsRow}>
              {adminFoodBanners.map((_, i) => (
                <View
                  key={i}
                  style={[styles.bannerDot, i === activeBannerIdx && styles.bannerDotActive]}
                />
              ))}
            </View>
          )}
        </View>

        {/* Child 2: Cuisines / Categories Horizontal Scroll Bar & Filter Chips Bar */}
        <View style={{ backgroundColor: '#FFF', borderBottomWidth: 1, borderBottomColor: '#F1F5F9' }}>
          {/* Zomato-style Cuisines / Category Horizontal Scroll Bar */}
          <View style={{ paddingVertical: 8 }}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cuisinesScroll}
            >
              {categoriesLoading && dynamicCuisines.length === 0
                ? Array.from({ length: 6 }).map((_, i) => (
                    <View key={`skel-${i}`} style={styles.cuisineItem}>
                      <View style={[styles.cuisineIconBox, { backgroundColor: '#E5E7EB' }]} />
                      <View style={{ marginTop: 6, width: 48, height: 10, borderRadius: 4, backgroundColor: '#E5E7EB' }} />
                    </View>
                  ))
                : dynamicCuisines.map((item) => {
                    const isSelected = selectedCuisine === item.id;
                    return (
                      <TouchableOpacity
                        key={item.id}
                        onPress={() => handleSelectCuisine(item.id)}
                        style={styles.cuisineItem}
                      >
                        <View style={[styles.cuisineIconBox, isSelected && styles.cuisineIconBoxActive]}>
                          <Image source={{ uri: item.image }} style={styles.cuisineImg} resizeMode="cover" />
                        </View>
                        <Text
                          style={[styles.cuisineName, isSelected && styles.cuisineNameActive]}
                          numberOfLines={2}
                        >
                          {item.name}
                        </Text>
                        {isSelected && <View style={styles.activeCuisineLine} />}
                      </TouchableOpacity>
                    );
                  })}
            </ScrollView>
          </View>

          {/* Zomato Quick Filter Chips Bar */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.zomatoFilterBar}
          >
            <TouchableOpacity
              style={[styles.zomatoFilterChip, activeFilter === 'offers' && styles.zomatoFilterChipActive]}
              onPress={() => setActiveFilter(activeFilter === 'offers' ? 'all' : 'offers')}
            >
              <Ionicons name="pricetag" size={13} color={activeFilter === 'offers' ? '#10B981' : '#E11D48'} />
              <Text style={[styles.zomatoFilterChipText, activeFilter === 'offers' && styles.zomatoFilterChipTextActive]}>
                Offers
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.zomatoFilterChip, activeFilter === 'past_orders' && styles.zomatoFilterChipActive]}
              onPress={() => setActiveFilter(activeFilter === 'past_orders' ? 'all' : 'past_orders')}
            >
              <Ionicons name="time-outline" size={13} color={activeFilter === 'past_orders' ? '#10B981' : '#374151'} />
              <Text style={[styles.zomatoFilterChipText, activeFilter === 'past_orders' && styles.zomatoFilterChipTextActive]}>
                Past Orders
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.zomatoFilterChip, activeFilter === 'fast' && styles.zomatoFilterChipActive]}
              onPress={() => setActiveFilter(activeFilter === 'fast' ? 'all' : 'fast')}
            >
              <Ionicons name="flash" size={13} color="#10B981" />
              <Text style={styles.zomatoFilterChipText}>Near & Fast</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.zomatoFilterChip, activeFilter === 'rating' && styles.zomatoFilterChipActive]}
              onPress={() => setActiveFilter(activeFilter === 'rating' ? 'all' : 'rating')}
            >
              <Text style={styles.zomatoFilterChipText}>Rating 4.0+</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.zomatoFilterChip, dietaryFilter === 'veg' && styles.zomatoFilterChipActive]}
              onPress={() => setDietaryFilter(dietaryFilter === 'veg' ? 'all' : 'veg')}
            >
              <Text style={styles.zomatoFilterChipText}>Pure Veg</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>

        {/* Child 2: RECOMMENDED FOR YOU Header */}
        <View style={styles.sectionHeader}>
          <Text style={styles.zomatoSectionTitle}>RECOMMENDED FOR YOU</Text>
        </View>

        {/* Zomato-Style 2-Column Grid */}
        <View style={styles.zomatoGridContainer}>
          {loading && products.length === 0 ? (
            Array.from({ length: 4 }).map((_, i) => (
              <View key={`skel-prod-${i}`} style={styles.zomatoGridCard}>
                <View style={{ width: '100%', height: 140, backgroundColor: '#F1F5F9', borderRadius: 12 }} />
                <View style={{ padding: 10 }}>
                  <View style={{ width: '80%', height: 14, backgroundColor: '#F1F5F9', borderRadius: 4, marginBottom: 6 }} />
                  <View style={{ width: '50%', height: 12, backgroundColor: '#F1F5F9', borderRadius: 4, marginBottom: 8 }} />
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <View style={{ width: 40, height: 14, backgroundColor: '#F1F5F9', borderRadius: 4 }} />
                    <View style={{ width: 60, height: 28, backgroundColor: '#F1F5F9', borderRadius: 6 }} />
                  </View>
                </View>
              </View>
            ))
          ) : filteredProducts.length === 0 ? (
            <View style={{ padding: 32, alignItems: 'center', width: '100%', alignSelf: 'center' }}>
              <Text style={{ fontSize: 24, marginBottom: 8 }}>🍲</Text>
              <Text style={{ fontSize: 15, fontWeight: '700', color: '#1E293B', marginBottom: 4 }}>No food items available</Text>
              <Text style={{ fontSize: 13, color: '#64748B', textAlign: 'center' }}>Try switching category or clearing search filters.</Text>
            </View>
          ) : (
            filteredProducts.map((dish, idx) => {
              const qty = getItemQuantity(dish._id);
              const offerTag =
                idx % 3 === 0
                  ? '50% OFF select items'
                  : idx % 3 === 1
                  ? '₹60 OFF above ₹149'
                  : '₹50 OFF above ₹199';
              const ratingVal = (dish.rating?.average || 4.2).toFixed(1);
              const prepTime = dish.preparationTime || (25 + (idx % 4) * 5);
              const isDishOffline = dish.vendor?.role === 'vendor' && dish.vendor?.isOnline === false;
              const availStock = getProductAvailableStock(dish);
              const isDishOutOfStock = availStock <= 0 || dish.isAvailable === false;
              const isFav = isInWishlist(dish._id);

              return (
              <View key={dish._id} style={styles.zomatoGridCard}>
                <TouchableOpacity
                  activeOpacity={(isDishOffline || isDishOutOfStock) ? 1 : 0.85}
                  disabled={isDishOffline || isDishOutOfStock}
                  onPress={() => {
                    if (!isDishOffline && !isDishOutOfStock) {
                      navigation.navigate('ProductDetail', {
                        slug: dish.slug,
                        id: dish._id,
                        initialProduct: dish,
                      });
                    }
                  }}
                >
                  <View style={styles.zomatoCardImgWrapper}>
                    <Image
                      source={{
                        uri:
                          dish.images?.[0] ||
                          'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400',
                      }}
                      style={[styles.zomatoCardImg, (isDishOffline || isDishOutOfStock) && { opacity: 0.55 }]}
                    />
                    {!isDishOffline && !isDishOutOfStock && (
                      <TouchableOpacity
                        style={styles.cardHeartBtn}
                        onPress={() => toggleWishlist(dish)}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Ionicons
                          name={isFav ? 'heart' : 'heart-outline'}
                          size={16}
                          color={isFav ? '#EF4444' : '#94A3B8'}
                        />
                      </TouchableOpacity>
                    )}
                    {isDishOffline ? (
                      <View style={{
                        position: 'absolute',
                        top: 0, left: 0, right: 0, bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.45)',
                        justifyContent: 'center',
                        alignItems: 'center',
                        borderRadius: 14,
                      }}>
                        <Text style={{ color: '#FFF', fontWeight: '900', fontSize: 10, letterSpacing: 0.5 }}>STORE CLOSED</Text>
                      </View>
                    ) : isDishOutOfStock ? (
                      <View style={{
                        position: 'absolute',
                        top: 0, left: 0, right: 0, bottom: 0,
                        backgroundColor: 'rgba(0,0,0,0.45)',
                        justifyContent: 'center',
                        alignItems: 'center',
                        borderRadius: 14,
                      }}>
                        <Text style={{ color: '#FFF', fontWeight: '900', fontSize: 9, letterSpacing: 0.5 }}>OUT OF STOCK</Text>
                      </View>
                    ) : (
                      <View style={styles.zomatoOfferOverlay}>
                        <Text style={styles.zomatoOfferOverlayText} numberOfLines={1}>
                          {offerTag}
                        </Text>
                      </View>
                    )}
                    <View style={[styles.vegSquare, { borderColor: dish.isVeg === false ? '#DC2626' : '#16A34A' }]}>
                      <View style={[styles.vegDot, { backgroundColor: dish.isVeg === false ? '#DC2626' : '#16A34A' }]} />
                    </View>
                  </View>
                </TouchableOpacity>

                <View style={styles.zomatoCardContent}>
                  <View style={styles.zomatoRatingPill}>
                    <Ionicons name="star" size={10} color="#FFF" />
                    <Text style={styles.zomatoRatingText}>{ratingVal}</Text>
                  </View>
                  <Text style={styles.zomatoCardTitle} numberOfLines={1}>
                    {dish.name}
                  </Text>
                  <View style={styles.zomatoDeliveryRow}>
                    <Ionicons name="time-outline" size={12} color="#6B7280" />
                    <Text style={styles.zomatoDeliveryText}>
                      {prepTime}-{prepTime + 5} mins
                    </Text>
                  </View>

                  <View style={styles.zomatoCardFooter}>
                    <Text style={styles.zomatoPriceText}>₹{dish.price}</Text>
                    {qty === 0 ? (
                      <TouchableOpacity
                        style={[styles.zomatoAddBtn, (isDishOffline || isDishOutOfStock) && { backgroundColor: '#94A3B8' }]}
                        disabled={isDishOffline || isDishOutOfStock}
                        onPress={() => {
                          if (isDishOffline) {
                            Alert.alert('Store Offline 🔴', 'This restaurant is currently offline.');
                            return;
                          }
                          if (isDishOutOfStock) {
                            Alert.alert('Out of Stock 🔴', 'This dish is currently out of stock.');
                            return;
                          }
                          setCustomizingDish(dish);
                          setSelectedAddons([]);
                          setItemInstructions('');
                          if (
                            dish?.variants &&
                            dish.variants.length > 0 &&
                            dish.variants[0]?.options?.length > 0
                          ) {
                            setSelectedVariantOption(dish.variants[0].options[0]);
                          } else {
                            setSelectedVariantOption(null);
                          }
                        }}
                      >
                        <Text style={styles.zomatoAddBtnText}>
                          {isDishOffline ? 'OFFLINE' : isDishOutOfStock ? 'OUT OF STOCK' : 'ADD'}
                        </Text>
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.zomatoStepper}>
                        <TouchableOpacity
                          onPress={() => {
                            const cartItem = items.find((i) => i.product?._id === dish._id || i.productId === dish._id || i._id === dish._id);
                            const idToPass = dish._id;
                            const targetApiId = (cartItem?._id && !cartItem._id.startsWith('temp-'))
                              ? cartItem._id
                              : (cartItem?.product?._id || cartItem?.productId || dish._id);

                            if (qty <= 1) {
                              updateQuantity(idToPass, 0);
                              if (isAuthenticated && targetApiId) {
                                removeFromCartMutation({ variables: { itemId: targetApiId } });
                              }
                            } else {
                              updateQuantity(idToPass, qty - 1);
                              if (isAuthenticated && targetApiId) {
                                updateCartItemMutation({ variables: { itemId: targetApiId, quantity: qty - 1 } });
                              }
                            }
                          }}
                          style={{ paddingHorizontal: 4 }}
                        >
                          <Ionicons name="remove" size={12} color="#FFF" />
                        </TouchableOpacity>
                        <Text style={{ color: '#FFF', fontWeight: '900', fontSize: 11 }}>
                          {qty}
                        </Text>
                        <TouchableOpacity
                          disabled={qty >= availStock || isDishOffline || isDishOutOfStock}
                          onPress={() => {
                            if (isDishOffline) {
                              Alert.alert('Store Offline 🔴', 'This restaurant is currently offline.');
                              return;
                            }
                            if (qty + 1 > availStock) {
                              Alert.alert('Stock Limit Reached', `Only ${availStock} available in stock.`);
                              return;
                            }
                            setCustomizingDish(dish);
                            setSelectedAddons([]);
                            setItemInstructions('');
                            if (
                              dish?.variants &&
                              dish.variants.length > 0 &&
                              dish.variants[0]?.options?.length > 0
                            ) {
                              setSelectedVariantOption(dish.variants[0].options[0]);
                            } else {
                              setSelectedVariantOption(null);
                            }
                          }}
                          style={[{ paddingHorizontal: 4 }, (qty >= availStock || isDishOffline || isDishOutOfStock) && { opacity: 0.4 }]}
                        >
                          <Ionicons name="add" size={12} color="#FFF" />
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            );
          })
          )}
        </View>



        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Floating Bottom Cart Bar */}
      {totalFoodItems > 0 && (
        <View style={[styles.floatingCart, { bottom: insets.bottom + 12 }]}>
          <View>
            <Text style={styles.floatingCartCount}>{totalFoodItems} {totalFoodItems === 1 ? 'ITEM' : 'ITEMS'} ADDED</Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'food' })}
            style={styles.viewCartButton}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  backButton: {
    padding: 6,
    marginRight: 6,
  },
  deliveryLocation: {
    flex: 1,
  },
  locationTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  deliveryToText: {
    fontSize: 11,
    fontWeight: '900',
    color: '#EA580C',
    letterSpacing: 0.5,
  },
  addressText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 1,
  },
  cartButton: {
    position: 'relative',
    padding: 6,
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#EA580C',
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  searchSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFF',
    gap: 10,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 14,
    paddingHorizontal: 12,
    height: 42,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#1F2937',
    fontWeight: '500',
  },
  vegToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    paddingHorizontal: 10,
    height: 42,
    gap: 6,
  },
  vegToggleActive: {
    borderColor: '#16A34A',
    backgroundColor: '#F0FDF4',
  },
  vegDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#9CA3AF',
  },
  vegDotActive: {
    backgroundColor: '#16A34A',
  },
  vegToggleText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#4B5563',
  },
  vegToggleTextActive: {
    color: '#16A34A',
  },
  scrollContent: {
    paddingBottom: 24,
  },
  bannerCard: {
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 20,
    backgroundColor: '#EA580C',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  bannerLeft: {
    flex: 1,
    paddingRight: 10,
  },
  bannerTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  bannerTagText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '900',
  },
  bannerTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  bannerSubtitle: {
    color: '#FED7AA',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
  bannerImage: {
    width: 80,
    height: 80,
    borderRadius: 16,
  },
  sectionHeader: {
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: '#111827',
  },
  cuisinesScroll: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 14,
  },
  cuisineItem: {
    alignItems: 'center',
    width: 84,
  },
  cuisineIconBox: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    overflow: 'hidden',
    ...SHADOWS.light,
  },
  cuisineIconBoxActive: {
    borderColor: '#EA580C',
    borderWidth: 2.5,
  },
  cuisineImg: {
    width: '100%',
    height: '100%',
    borderRadius: 32,
  },
  cuisineName: {
    fontSize: 11,
    fontWeight: '700',
    color: '#4B5563',
    marginTop: 6,
    textAlign: 'center',
    lineHeight: 14,
  },
  cuisineNameActive: {
    color: '#EA580C',
    fontWeight: '900',
  },
  filtersScroll: {
    paddingHorizontal: 16,
    gap: 8,
    marginTop: 16,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterChipActive: {
    backgroundColor: '#111827',
    borderColor: '#111827',
  },
  filterChipText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#4B5563',
  },
  filterChipTextActive: {
    color: '#FFF',
  },
  restaurantScroll: {
    paddingHorizontal: 16,
    gap: 14,
  },
  restaurantCard: {
    width: 240,
    backgroundColor: '#FFF',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    ...SHADOWS.light,
  },
  restaurantImg: {
    width: '100%',
    height: 125,
    backgroundColor: '#E5E7EB',
  },
  restaurantTimeBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  restaurantTimeText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '700',
  },
  restaurantInfo: {
    padding: 12,
  },
  restaurantTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  restaurantName: {
    fontSize: 14,
    fontWeight: '800',
    color: '#111827',
    flex: 1,
    marginRight: 6,
  },
  ratingBadge: {
    backgroundColor: '#16A34A',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  ratingBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  restaurantCuisines: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 3,
  },
  restaurantPrice: {
    fontSize: 11,
    fontWeight: '600',
    color: '#9CA3AF',
    marginTop: 2,
  },
  dishesList: {
    paddingHorizontal: 16,
    gap: 16,
  },
  dishCard: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: '#F3F4F6',
    ...SHADOWS.light,
  },
  dishDetails: {
    flex: 1,
    paddingRight: 12,
  },
  vegIndicatorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  vegBox: {
    width: 15,
    height: 15,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 3,
  },
  vegBoxGreen: {
    borderColor: '#16A34A',
  },
  vegBoxRed: {
    borderColor: '#DC2626',
  },
  vegInner: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  vegInnerGreen: {
    backgroundColor: '#16A34A',
  },
  vegInnerRed: {
    backgroundColor: '#DC2626',
  },
  starRatingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 4,
  },
  starRatingText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#B45309',
  },
  prepTimeText: {
    fontSize: 10,
    color: '#6B7280',
    fontWeight: '600',
  },
  dishName: {
    fontSize: 15,
    fontWeight: '800',
    color: '#111827',
  },
  dishRestaurant: {
    fontSize: 11,
    fontWeight: '600',
    color: '#EA580C',
    marginTop: 1,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  dishPrice: {
    fontSize: 15,
    fontWeight: '900',
    color: '#111827',
  },
  dishComparePrice: {
    fontSize: 12,
    color: '#9CA3AF',
    textDecorationLine: 'line-through',
  },
  dishDescription: {
    fontSize: 12,
    color: '#6B7280',
    lineHeight: 16,
    marginTop: 4,
  },
  dishImageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 105,
  },
  dishImage: {
    width: 105,
    height: 105,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
  },
  actionBtnContainer: {
    position: 'absolute',
    bottom: -10,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#EA580C',
    ...SHADOWS.medium,
  },
  addButtonText: {
    fontSize: 12,
    fontWeight: '900',
    color: '#EA580C',
  },
  stepperContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EA580C',
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 4,
    gap: 8,
    ...SHADOWS.medium,
  },
  stepperBtn: {
    padding: 2,
  },
  stepperText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '900',
    minWidth: 16,
    textAlign: 'center',
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#16A34A',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#DCFCE7',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  dietaryBar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 8,
  },
  dietaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  dietaryPillActiveAll: {
    backgroundColor: '#1E293B',
    borderColor: '#1E293B',
  },
  dietaryPillActiveVeg: {
    backgroundColor: '#F0FDF4',
    borderColor: '#16A34A',
  },
  dietaryPillActiveNonVeg: {
    backgroundColor: '#FEF2F2',
    borderColor: '#DC2626',
  },
  dietaryPillText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#4B5563',
  },
  dietaryPillTextActiveAll: {
    color: '#FFF',
  },
  dietaryPillTextActiveVeg: {
    color: '#15803D',
  },
  dietaryPillTextActiveNonVeg: {
    color: '#B91C1C',
  },
  vegLabelText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  swiggyVegBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#F8FAFC',
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
  },
  swiggyVegBtnActive: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  swiggyVegBtnText: {
    fontSize: 11,
    fontWeight: '900',
    color: '#64748B',
    letterSpacing: 0.5,
  },
  swiggyVegBtnTextActive: {
    color: '#059669',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  vegModalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    width: '100%',
    maxWidth: 360,
    padding: 22,
    ...SHADOWS.large,
  },
  modalHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  modalHeaderTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: '#1E293B',
    lineHeight: 26,
    letterSpacing: -0.3,
  },
  modalHeaderRight: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  modalBowlImg: {
    width: 48,
    height: 48,
    borderRadius: 12,
  },
  modalCloseBtn: {
    backgroundColor: '#F1F5F9',
    padding: 6,
    borderRadius: 16,
  },
  radioOptionsGroup: {
    gap: 16,
    marginBottom: 16,
  },
  radioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  radioLabelText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#475569',
  },
  radioLabelTextSelected: {
    fontWeight: '800',
    color: '#0F172A',
  },
  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioOuterSelected: {
    borderColor: '#10B981',
  },
  radioInnerGreen: {
    width: 11,
    height: 11,
    borderRadius: 5.5,
    backgroundColor: '#10B981',
  },
  dottedDivider: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderStyle: 'dashed',
    marginVertical: 14,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 8,
  },
  checkboxLabelText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748B',
  },
  checkboxBox: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxBoxChecked: {
    borderColor: '#10B981',
    backgroundColor: '#ECFDF5',
  },
  applyVegBtn: {
    backgroundColor: '#10B981',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
    ...SHADOWS.medium,
  },
  applyVegBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  customizableText: {
    fontSize: 10,
    color: '#EA580C',
    fontWeight: '800',
    marginTop: 6,
  },
  customSectionTitle: {
    fontSize: 12,
    fontWeight: '900',
    color: '#64748B',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  addonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  addonName: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1E293B',
  },
  addonPrice: {
    fontSize: 13,
    fontWeight: '800',
    color: '#059669',
  },
  customInstructionInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 13,
    color: '#1E293B',
    minHeight: 60,
  },
  instructionChip: {
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 16,
  },
  instructionChipText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#475569',
  },

  /* Zomato Header Search & VEG MODE Switch */
  zomatoSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFFFFF',
    gap: 12,
  },
  zomatoSearchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    borderWidth: 1.2,
    borderColor: '#E2E8F0',
    borderRadius: 16,
    paddingHorizontal: 12,
    height: 44,
  },
  zomatoSearchInput: {
    flex: 1,
    fontSize: 13,
    fontWeight: '600',
    color: '#1E293B',
  },
  vegModeContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  vegModeText: {
    fontSize: 8,
    fontWeight: '900',
    color: '#475569',
    textAlign: 'center',
    lineHeight: 10,
    marginBottom: 2,
  },

  /* Admin Managed Hero Banner (Reference Image 2) */
  zomatoBannerWrapper: {
    marginHorizontal: 16,
    marginVertical: 10,
  },
  zomatoBannerCard: {
    width: width - 32,
    height: Math.floor((width - 32) * 0.38),
    borderRadius: 18,
    backgroundColor: '#F1F5F9',
    overflow: 'hidden',
    position: 'relative',
    ...SHADOWS.medium,
  },
  bannerFullImg: {
    width: '100%',
    height: '100%',
  },
  zomatoBannerContentWrap: {
    width: '100%',
    height: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  zomatoBannerLeft: {
    flex: 1,
    paddingRight: 10,
    justifyContent: 'center',
  },
  bannerTagPill: {
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  bannerTagPillText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '900',
  },
  zomatoBannerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  zomatoBannerDiscount: {
    color: '#FEF08A',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    marginTop: -2,
  },
  zomatoBannerBtn: {
    backgroundColor: '#000000',
    alignSelf: 'flex-start',
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    marginTop: 8,
  },
  zomatoBannerBtnText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },
  zomatoBannerImg: {
    width: 120,
    height: 120,
    borderRadius: 16,
  },
  bannerDotsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 8,
  },
  bannerDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#CBD5E1',
  },
  bannerDotActive: {
    width: 16,
    backgroundColor: '#E11D48',
  },

  /* Zomato Gold / Free Delivery Banner */
  zomatoGoldBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#FDE68A',
  },
  goldBannerText: {
    fontSize: 11.5,
    color: '#78350F',
    flex: 1,
  },

  /* Explore Promo Card */
  explorePromoCard: {
    width: 82,
    height: 82,
    borderRadius: 20,
    backgroundColor: '#3B82F6',
    padding: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 6,
  },
  explorePromoSub: {
    fontSize: 8,
    fontWeight: '900',
    color: '#DBEAFE',
    textAlign: 'center',
  },
  explorePromoPrice: {
    fontSize: 16,
    fontWeight: '900',
    color: '#FFFFFF',
    marginTop: 1,
  },
  exploreBtnPill: {
    backgroundColor: '#1E40AF',
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginTop: 4,
  },
  exploreBtnPillText: {
    fontSize: 9,
    fontWeight: '800',
    color: '#FFFFFF',
  },

  activeCuisineLine: {
    width: 28,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: '#E11D48',
    marginTop: 4,
  },

  /* Zomato Quick Filter Chips */
  zomatoFilterBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFFFFF',
    gap: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  zomatoFilterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  zomatoFilterChipActive: {
    backgroundColor: '#F0FDF4',
    borderColor: '#10B981',
  },
  zomatoFilterChipText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#374151',
  },

  /* Zomato Section Title */
  zomatoSectionTitle: {
    fontSize: 12,
    fontWeight: '900',
    color: '#64748B',
    letterSpacing: 1,
  },

  /* 2-Column Recommended Grid */
  zomatoGridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 12,
    gap: 12,
  },
  zomatoGridCard: {
    width: (width - 36) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#F1F5F9',
    ...SHADOWS.light,
  },
  zomatoCardImgWrapper: {
    width: '100%',
    height: 120,
    backgroundColor: '#F1F5F9',
    position: 'relative',
  },
  cardHeartBtn: {
    position: 'absolute',
    top: 6,
    right: 6,
    zIndex: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vegSquare: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    width: 12,
    height: 12,
    borderWidth: 1,
    borderRadius: 3,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    zIndex: 5,
  },
  vegDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  zomatoCardImg: {
    width: '100%',
    height: '100%',
  },
  zomatoOfferOverlay: {
    position: 'absolute',
    top: 8,
    left: 8,
    right: 8,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 3,
  },
  zomatoOfferOverlayText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '900',
    textAlign: 'center',
  },
  zomatoCardContent: {
    padding: 10,
  },
  zomatoRatingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: '#16A34A',
    alignSelf: 'flex-start',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginBottom: 6,
  },
  zomatoRatingText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '900',
  },
  zomatoCardTitle: {
    fontSize: 13.5,
    fontWeight: '800',
    color: '#0F172A',
  },
  zomatoDeliveryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 3,
    marginBottom: 8,
  },
  zomatoDeliveryText: {
    fontSize: 11,
    color: '#64748B',
    fontWeight: '600',
  },
  zomatoCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  zomatoPriceText: {
    fontSize: 14,
    fontWeight: '900',
    color: '#0F172A',
  },
  zomatoAddBtn: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1.5,
    borderColor: '#E11D48',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  zomatoAddBtnText: {
    color: '#E11D48',
    fontSize: 11,
    fontWeight: '900',
  },
  zomatoStepper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E11D48',
    borderRadius: 8,
    paddingHorizontal: 6,
    paddingVertical: 4,
    gap: 6,
  },

  /* EXPLORE MORE Row */
  exploreMoreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    marginTop: 8,
  },
  exploreMoreItem: {
    alignItems: 'center',
    width: (width - 64) / 4,
  },
  exploreMoreIconBg: {
    width: 52,
    height: 52,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  exploreMoreText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#475569',
  },
  stickyFilterHeader: {
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
    zIndex: 30,
    elevation: 4,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
});
