import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  TextInput,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
  Modal,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS, GET_ME, GET_CATEGORIES, GET_STORE_SETTINGS } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';
import { filterItemsByVertical } from '../../utils/cartHelpers';

const { width } = Dimensions.get('window');

const CUISINES = [
  {
    id: 'all',
    name: 'All',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
  },
  {
    id: 'biryani',
    name: 'Biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300',
  },
  {
    id: 'pizza',
    name: 'Pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
  },
  {
    id: 'burgers',
    name: 'Burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300',
  },
  {
    id: 'north-indian',
    name: 'North Indian',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=300',
  },
  {
    id: 'chinese',
    name: 'Chinese',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=300',
  },
  {
    id: 'desserts',
    name: 'Desserts',
    image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=300',
  },
  {
    id: 'rolls',
    name: 'Rolls',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=300',
  },
];

const FALLBACK_FOOD = [
  {
    _id: 'food-fb-1',
    name: 'Hyderabadi Chicken Dum Biryani',
    slug: 'hyderabadi-chicken-dum-biryani',
    restaurantName: 'Behrouz Royal Biryani',
    cuisine: ['Biryani', 'Hyderabadi'],
    price: 349,
    comparePrice: 429,
    isVeg: false,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=500'],
    rating: { average: 4.6, count: 1420 },
    description: 'Authentic dum cooked long grain basmati rice layered with aromatic spices and tender bone-in chicken.',
    vertical: 'food',
  },
  {
    _id: 'food-fb-2',
    name: 'Paneer Tikka Butter Masala',
    slug: 'paneer-tikka-butter-masala',
    restaurantName: 'Punjab Grill Express',
    cuisine: ['North Indian', 'Curry'],
    price: 289,
    comparePrice: 349,
    isVeg: true,
    preparationTime: 20,
    images: ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=500'],
    rating: { average: 4.5, count: 890 },
    description: 'Tandoori cottage cheese cubes simmered in a rich tomato, cashew nut and butter gravy.',
    vertical: 'food',
  },
  {
    _id: 'food-fb-3',
    name: 'Farmhouse Loaded Italian Pizza',
    slug: 'farmhouse-loaded-italian-pizza',
    restaurantName: "La Pino'z Pizza",
    cuisine: ['Pizza', 'Italian'],
    price: 379,
    comparePrice: 499,
    isVeg: true,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500'],
    rating: { average: 4.4, count: 750 },
    description: 'Crisp hand-stretched crust topped with marinara, mozzarella, bell peppers and olives.',
    vertical: 'food',
  },
  {
    _id: 'food-fb-4',
    name: 'Crispy Double Patty Chicken Burger',
    slug: 'crispy-double-patty-chicken-burger',
    restaurantName: 'The Burger Club',
    cuisine: ['Burger', 'Fast Food'],
    price: 219,
    comparePrice: 279,
    isVeg: false,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500'],
    rating: { average: 4.5, count: 1100 },
    description: 'Two golden fried chicken fillets with smoky chipotle mayo on toasted brioche bun.',
    vertical: 'food',
  },
  {
    _id: 'food-fb-5',
    name: 'Steamed Himalayan Veg Momos',
    slug: 'steamed-himalayan-veg-darjeeling-momos',
    restaurantName: 'Wow! Momo Magic',
    cuisine: ['Chinese', 'Tibetan'],
    price: 139,
    comparePrice: 179,
    isVeg: true,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=500'],
    rating: { average: 4.3, count: 620 },
    description: 'Thin wrapper dumplings packed with veggies, served with fiery red chili chutney.',
    vertical: 'food',
  },
  {
    _id: 'food-fb-6',
    name: 'Belgian Dark Chocolate Thick Shake',
    slug: 'belgian-dark-chocolate-thick-shake',
    restaurantName: 'Keventers Thick Shakes',
    cuisine: ['Desserts', 'Beverages'],
    price: 199,
    comparePrice: 249,
    isVeg: true,
    preparationTime: 10,
    images: ['https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=500'],
    rating: { average: 4.7, count: 530 },
    description: 'Rich and creamy thick shake blended with imported Belgian cocoa and dark chocolate fudge.',
    vertical: 'food',
  },
];

export default function FoodHomeScreen({ navigation }) {
  const insets = useSafeAreaInsets();
  const mainScrollViewRef = useRef(null);
  const [dishesLayoutY, setDishesLayoutY] = useState(0);
  const [search, setSearch] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('all');
  const [dietaryFilter, setDietaryFilter] = useState('all'); // 'all' | 'veg' | 'non-veg'
  const [activeFilter, setActiveFilter] = useState('all'); // all, rating, fast, offers
  const [vegModalVisible, setVegModalVisible] = useState(false);
  const [vegChoice, setVegChoice] = useState('all'); // 'all' | 'veg_only'
  const [rememberChoice, setRememberChoice] = useState(true);
  const [customizingDish, setCustomizingDish] = useState(null);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [itemInstructions, setItemInstructions] = useState('');

  const [selectedRestaurant, setSelectedRestaurant] = useState(null);

  const [cuisinesLayoutY, setCuisinesLayoutY] = useState(0);

  const scrollToCuisines = () => {
    if (mainScrollViewRef.current && cuisinesLayoutY > 0) {
      mainScrollViewRef.current.scrollTo({ y: Math.max(0, cuisinesLayoutY - 10), animated: true });
    }
  };

  const handleSelectRestaurant = (restaurantName) => {
    if (selectedRestaurant === restaurantName) {
      setSelectedRestaurant(null);
    } else {
      setSelectedRestaurant(restaurantName);
      if (mainScrollViewRef.current && dishesLayoutY > 0) {
        mainScrollViewRef.current.scrollTo({ y: Math.max(0, dishesLayoutY - 10), animated: true });
      }
    }
  };

  const handleSelectCuisine = (cuisineId) => {
    setSelectedCuisine(cuisineId);
    scrollToCuisines();
  };

  useEffect(() => {
    AsyncStorage.getItem('saved_veg_preference')
      .then((val) => {
        if (val === 'veg_only') {
          setDietaryFilter('veg');
          setVegChoice('veg_only');
        }
      })
      .catch(() => {});
  }, []);

  const { items = [], addItem, updateQuantity } = useCartStore();
  const { isAuthenticated } = useAuthStore();

  const { data: userData } = useQuery(GET_ME, { skip: !isAuthenticated });
  const user = userData?.me;

  const [addToCartMutation] = useMutation(ADD_TO_CART);

  // Fetch categories scoped to Food vertical
  const { data: catData, loading: categoriesLoading } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'food' },
    fetchPolicy: 'cache-and-network',
  });

  const dynamicCuisines = useMemo(() => {
    const fetched = catData?.getCategories || [];
    // Don't fall back to static CUISINES while loading — return empty to show skeleton
    if (!fetched.length) return [];

    const formatted = fetched.map((c) => ({
      id: c.slug || c._id,
      _id: c._id,
      slug: c.slug,
      name: c.name,
      children: c.children || [],
      image: c.image || c.icon || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
    }));
    return [
      { id: 'all', name: 'All', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300' },
      ...formatted,
    ];
  }, [catData]);

  // Fetch products scoped to Food vertical
  const { data, loading, refetch } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'food',
        search: search.trim() || undefined,
        isVeg: dietaryFilter === 'veg' ? true : dietaryFilter === 'non-veg' ? false : undefined,
      },
      pagination: { page: 1, limit: 50 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products;
  const products = (rawProducts && rawProducts.length > 0) ? rawProducts : FALLBACK_FOOD;

  // Filter products by cuisine and pill
  const filteredProducts = useMemo(() => {
    const activeCuisineObj = dynamicCuisines.find(
      (c) => c.id === selectedCuisine || c.slug === selectedCuisine || c._id === selectedCuisine || c.name === selectedCuisine
    );

    return products.filter((item) => {
      if (selectedRestaurant) {
        const target = selectedRestaurant.toLowerCase();
        const rName = (item.restaurantName || '').toLowerCase();
        const pName = (item.name || '').toLowerCase();
        const matchesRest = rName.includes(target) || target.includes(rName) || pName.includes(target);
        if (!matchesRest) return false;
      }

      if (dietaryFilter === 'veg' && item.isVeg === false) return false;
      if (dietaryFilter === 'non-veg' && item.isVeg !== false) return false;

      if (selectedCuisine !== 'all') {
        const catId = item.category?._id?.toString();
        const catSlug = item.category?.slug?.toLowerCase();
        const catName = item.category?.name?.toLowerCase();

        const subcatId = item.subcategory?._id?.toString();
        const subcatSlug = item.subcategory?.slug?.toLowerCase();
        const subcatName = item.subcategory?.name?.toLowerCase();

        const parentCatId = (item.category?.parent?._id || item.category?.parent)?.toString();
        const parentCatSlug = item.category?.parent?.slug?.toLowerCase();
        const parentCatName = item.category?.parent?.name?.toLowerCase();

        const activeId = activeCuisineObj?._id?.toString();
        const activeSlug = activeCuisineObj?.slug?.toLowerCase() || activeCuisineObj?.id?.toLowerCase();
        const activeName = activeCuisineObj?.name?.toLowerCase();

        let matchesCuisine = false;

        // Check direct category / subcategory / parent IDs, Slugs, and Names
        if (activeId && (catId === activeId || subcatId === activeId || parentCatId === activeId)) {
          matchesCuisine = true;
        } else if (activeSlug && (catSlug === activeSlug || subcatSlug === activeSlug || parentCatSlug === activeSlug)) {
          matchesCuisine = true;
        } else if (activeName && (catName === activeName || subcatName === activeName || parentCatName === activeName)) {
          matchesCuisine = true;
        }

        // Check if item category is one of the children subcategories of the selected category tab
        if (!matchesCuisine && activeCuisineObj?.children && activeCuisineObj.children.length > 0) {
          const childIds = activeCuisineObj.children.map((ch) => ch._id?.toString());
          const childSlugs = activeCuisineObj.children.map((ch) => ch.slug?.toLowerCase());
          const childNames = activeCuisineObj.children.map((ch) => ch.name?.toLowerCase());

          if ((catId && childIds.includes(catId)) || (subcatId && childIds.includes(subcatId))) {
            matchesCuisine = true;
          } else if ((catSlug && childSlugs.includes(catSlug)) || (subcatSlug && childSlugs.includes(subcatSlug))) {
            matchesCuisine = true;
          } else if ((catName && childNames.includes(catName)) || (subcatName && childNames.includes(subcatName))) {
            matchesCuisine = true;
          }
        }

        // Fallback matching logic on dish name, description, restaurant, and cuisine array
        if (!matchesCuisine) {
          const dishCuisines = (item.cuisine || []).map((c) => c.toLowerCase().replace(/[-_&]/g, ' '));
          const dishName = (item.name || '').toLowerCase();
          const dishRest = (item.restaurantName || '').toLowerCase();

          const normCuisine = (activeName || selectedCuisine).replace(/[-_&]/g, ' ').toLowerCase();

          if (normCuisine.includes('pizza')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('pizza') || c.includes('italian')) ||
              dishName.includes('pizza');
          } else if (normCuisine.includes('biryani')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('biryani') || c.includes('mughlai') || c.includes('hyderabadi')) ||
              dishName.includes('biryani');
          } else if (normCuisine.includes('burg')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('burger') || c.includes('american')) ||
              dishName.includes('burger');
          } else {
            matchesCuisine =
              dishCuisines.some((c) => c.includes(normCuisine) || normCuisine.includes(c)) ||
              dishName.includes(normCuisine) ||
              dishRest.includes(normCuisine) ||
              (catName && catName.includes(normCuisine)) ||
              (subcatName && subcatName.includes(normCuisine));
          }
        }

        if (!matchesCuisine) return false;
      }

      if (activeFilter === 'rating' && (item.rating?.average || 0) < 4.4) return false;
      if (activeFilter === 'fast' && (item.preparationTime || 30) > 20) return false;
      if (activeFilter === 'offers' && !item.comparePrice) return false;

      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesRest = item.restaurantName?.toLowerCase().includes(q);
        if (!matchesName && !matchesRest) return false;
      }

      return true;
    });
  }, [products, dietaryFilter, selectedCuisine, activeFilter, search, selectedRestaurant]);

  const handleAddToCart = async (product) => {
    try {
      Vibration.vibrate(40);
    } catch {}

    const foodProduct = { ...product, vertical: 'food' };

    addItem(foodProduct);

    if (isAuthenticated) {
      try {
        await addToCartMutation({
          variables: { input: { productId: product._id, quantity: 1 } },
        });
      } catch (err) {
        console.warn('Backend cart sync error:', err.message);
      }
    }
  };

  const getItemQuantity = (productId) => {
    const item = items.find((i) => i.product?._id === productId || i.productId === productId || i._id === productId);
    return item ? item.quantity : 0;
  };

  const foodCartItems = filterItemsByVertical(items || [], 'food');
  const totalFoodItems = foodCartItems.reduce((sum, i) => sum + (i?.quantity || 0), 0);
  const totalAmount = foodCartItems.reduce((sum, i) => sum + ((i?.price || i?.product?.price || 0) * (i?.quantity || 0)), 0);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-and-network',
  });
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  if (disabledVerticals.includes('food')) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 24 }]}>
        <Text style={{ fontSize: 64, marginBottom: 16 }}>🍔</Text>
        <Text style={{ fontSize: 22, fontWeight: '700', color: COLORS.textDark, textAlign: 'center', marginBottom: 8 }}>
          Food Delivery Currently Unavailable
        </Text>
        <Text style={{ fontSize: 14, color: COLORS.textMuted, textAlign: 'center', maxWidth: 300, marginBottom: 24, lineHeight: 20 }}>
          We are currently not accepting food orders. Please check back later or explore our other products!
        </Text>
        <TouchableOpacity
          style={{ backgroundColor: COLORS.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 }}
          onPress={() => navigation.navigate('MainTabs')}
        >
          <Text style={{ color: '#FFF', fontWeight: '700', fontSize: 15 }}>Return to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFF" />

      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={22} color="#1F2937" />
          </TouchableOpacity>
          <View style={styles.deliveryLocation}>
            <View style={styles.locationTitleRow}>
              <Ionicons name="location-sharp" size={16} color="#EA580C" />
              <Text style={styles.deliveryToText}>DELIVER TO</Text>
              <Ionicons name="chevron-down" size={14} color="#6B7280" />
            </View>
            <Text style={styles.addressText} numberOfLines={1}>
              {user?.addresses?.find((a) => a.isDefault)?.city || 'Home • MG Road, Central City'}
            </Text>
          </View>
        </View>

      </View>

      {/* Search Bar & Swiggy-style VEG Toggle Button */}
      <View style={styles.searchSection}>
        <View style={styles.searchContainer}>
          <Ionicons name="search-outline" size={18} color="#9CA3AF" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search dishes, restaurants or cuisines..."
            placeholderTextColor="#9CA3AF"
            value={search}
            onChangeText={setSearch}
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={16} color="#9CA3AF" />
            </TouchableOpacity>
          ) : null}
        </View>

        <TouchableOpacity
          onPress={() => {
            setVegChoice(dietaryFilter === 'veg' ? 'veg_only' : 'all');
            setVegModalVisible(true);
          }}
          style={[styles.swiggyVegBtn, dietaryFilter === 'veg' && styles.swiggyVegBtnActive]}
          activeOpacity={0.8}
        >
          <Text style={[styles.swiggyVegBtnText, dietaryFilter === 'veg' && styles.swiggyVegBtnTextActive]}>
            VEG
          </Text>
          <View style={[styles.vegBox, styles.vegBoxGreen, { width: 11, height: 11, borderWidth: 1.2 }]}>
            <View style={[styles.vegInner, styles.vegInnerGreen, { width: 4.5, height: 4.5 }]} />
          </View>
        </TouchableOpacity>
      </View>

      {/* Dietary Filters Pill Bar */}
      <View style={styles.dietaryBar}>
        <TouchableOpacity
          onPress={() => {
            setDietaryFilter('all');
            scrollToCuisines();
          }}
          style={[styles.dietaryPill, dietaryFilter === 'all' && styles.dietaryPillActiveAll]}
        >
          <Text style={[styles.dietaryPillText, dietaryFilter === 'all' && styles.dietaryPillTextActiveAll]}>
            All
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setDietaryFilter(dietaryFilter === 'veg' ? 'all' : 'veg');
            scrollToCuisines();
          }}
          style={[styles.dietaryPill, dietaryFilter === 'veg' && styles.dietaryPillActiveVeg]}
        >
          <View style={[styles.vegBox, styles.vegBoxGreen, { width: 12, height: 12, borderWidth: 1.2 }]}>
            <View style={[styles.vegInner, styles.vegInnerGreen, { width: 5, height: 5 }]} />
          </View>
          <Text style={[styles.dietaryPillText, dietaryFilter === 'veg' && styles.dietaryPillTextActiveVeg]}>
            Veg
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setDietaryFilter(dietaryFilter === 'non-veg' ? 'all' : 'non-veg');
            scrollToCuisines();
          }}
          style={[styles.dietaryPill, dietaryFilter === 'non-veg' && styles.dietaryPillActiveNonVeg]}
        >
          <View style={[styles.vegBox, styles.vegBoxRed, { width: 12, height: 12, borderWidth: 1.2 }]}>
            <View style={[styles.vegInner, styles.vegInnerRed, { width: 5, height: 5 }]} />
          </View>
          <Text style={[styles.dietaryPillText, dietaryFilter === 'non-veg' && styles.dietaryPillTextActiveNonVeg]}>
            Non-Veg
          </Text>
        </TouchableOpacity>
      </View>

      {/* Swiggy-style Veg Choice Modal */}
      <Modal
        visible={vegModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setVegModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity
            style={StyleSheet.absoluteFill}
            activeOpacity={1}
            onPress={() => setVegModalVisible(false)}
          />
          <View style={styles.vegModalCard}>
            {/* Top Close Button & Graphic */}
            <View style={styles.modalHeaderRow}>
              <Text style={styles.modalHeaderTitle}>
                I want to see veg{'\n'}choices from
              </Text>
              <View style={styles.modalHeaderRight}>
                <Image
                  source={{ uri: 'https://cdn-icons-png.flaticon.com/512/3480/3480823.png' }}
                  style={styles.modalBowlImg}
                />
                <TouchableOpacity
                  onPress={() => setVegModalVisible(false)}
                  style={styles.modalCloseBtn}
                  hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                >
                  <Ionicons name="close" size={20} color="#64748B" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Radio Options */}
            <View style={styles.radioOptionsGroup}>
              {/* Option 1: All restaurants */}
              <TouchableOpacity
                style={styles.radioRow}
                activeOpacity={0.8}
                onPress={() => setVegChoice('all')}
              >
                <Text style={[styles.radioLabelText, vegChoice === 'all' && styles.radioLabelTextSelected]}>
                  All restaurants
                </Text>
                <View style={[styles.radioOuter, vegChoice === 'all' && styles.radioOuterSelected]}>
                  {vegChoice === 'all' && <View style={styles.radioInnerGreen} />}
                </View>
              </TouchableOpacity>

              {/* Option 2: Pure veg restaurants only */}
              <TouchableOpacity
                style={styles.radioRow}
                activeOpacity={0.8}
                onPress={() => setVegChoice('veg_only')}
              >
                <Text style={[styles.radioLabelText, vegChoice === 'veg_only' && styles.radioLabelTextSelected]}>
                  Pure veg restaurants only
                </Text>
                <View style={[styles.radioOuter, vegChoice === 'veg_only' && styles.radioOuterSelected]}>
                  {vegChoice === 'veg_only' && <View style={styles.radioInnerGreen} />}
                </View>
              </TouchableOpacity>
            </View>

            {/* Dotted Line Divider */}
            <View style={styles.dottedDivider} />

            {/* Remember my choice checkbox */}
            <TouchableOpacity
              style={styles.checkboxRow}
              activeOpacity={0.8}
              onPress={() => setRememberChoice(!rememberChoice)}
            >
              <Text style={styles.checkboxLabelText}>Remember my choice going forward</Text>
              <View style={[styles.checkboxBox, rememberChoice && styles.checkboxBoxChecked]}>
                {rememberChoice && <Ionicons name="checkmark" size={13} color="#059669" />}
              </View>
            </TouchableOpacity>

            {/* Apply Button */}
            <TouchableOpacity
              style={styles.applyVegBtn}
              activeOpacity={0.88}
              onPress={async () => {
                try {
                  Vibration.vibrate(40);
                } catch {}

                if (vegChoice === 'veg_only') {
                  setDietaryFilter('veg');
                } else {
                  setDietaryFilter('all');
                }

                if (rememberChoice) {
                  AsyncStorage.setItem('saved_veg_preference', vegChoice).catch(() => {});
                } else {
                  AsyncStorage.removeItem('saved_veg_preference').catch(() => {});
                }
                setVegModalVisible(false);
              }}
            >
              <Text style={styles.applyVegBtnText}>Show restaurants</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Customization & Add-ons Bottom Sheet Modal */}
      <Modal
        visible={!!customizingDish}
        transparent
        animationType="slide"
        onRequestClose={() => setCustomizingDish(null)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity
            style={StyleSheet.absoluteFill}
            activeOpacity={1}
            onPress={() => setCustomizingDish(null)}
          />
          <View style={[styles.vegModalCard, { maxHeight: '85%', padding: 20 }]}>
            {customizingDish && (
              <>
                <View style={styles.modalHeaderRow}>
                  <View style={{ flex: 1, paddingRight: 10 }}>
                    <View style={styles.vegIndicatorRow}>
                      <View style={[styles.vegBox, customizingDish.isVeg !== false ? styles.vegBoxGreen : styles.vegBoxRed]}>
                        <View style={[styles.vegInner, customizingDish.isVeg !== false ? styles.vegInnerGreen : styles.vegInnerRed]} />
                      </View>
                      <Text style={[styles.vegLabelText, customizingDish.isVeg !== false ? { color: '#16A34A' } : { color: '#DC2626' }]}>
                        {customizingDish.isVeg !== false ? 'VEG' : 'NON-VEG'}
                      </Text>
                    </View>
                    <Text style={[styles.dishName, { fontSize: 17, marginTop: 4 }]}>{customizingDish.name}</Text>
                    <Text style={styles.dishPrice}>₹{customizingDish.price}</Text>
                  </View>
                  <TouchableOpacity onPress={() => setCustomizingDish(null)} style={styles.modalCloseBtn}>
                    <Ionicons name="close" size={20} color="#64748B" />
                  </TouchableOpacity>
                </View>

                <ScrollView showsVerticalScrollIndicator={false} style={{ marginVertical: 10 }}>
                  <Text style={styles.customSectionTitle}>ADD-ONS & EXTRAS</Text>
                  {[
                    { id: 'cheese', name: 'Extra Cheese', price: 30, icon: '🧀' },
                    { id: 'toppings', name: 'Extra Toppings / Paneer', price: 40, icon: '🍅' },
                    { id: 'spicy', name: 'Extra Spicy Chilli', price: 15, icon: '🌶️' },
                    { id: 'coke', name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
                  ].map((addon) => {
                    const isSelected = selectedAddons.some((a) => a.id === addon.id);
                    return (
                      <TouchableOpacity
                        key={addon.id}
                        style={styles.addonRow}
                        activeOpacity={0.8}
                        onPress={() => {
                          if (isSelected) {
                            setSelectedAddons(selectedAddons.filter((a) => a.id !== addon.id));
                          } else {
                            setSelectedAddons([...selectedAddons, addon]);
                          }
                        }}
                      >
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                          <Text style={{ fontSize: 18 }}>{addon.icon}</Text>
                          <Text style={styles.addonName}>{addon.name}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                          <Text style={styles.addonPrice}>+₹{addon.price}</Text>
                          <View style={[styles.checkboxBox, isSelected && styles.checkboxBoxChecked]}>
                            {isSelected && <Ionicons name="checkmark" size={13} color="#059669" />}
                          </View>
                        </View>
                      </TouchableOpacity>
                    );
                  })}

                  <Text style={[styles.customSectionTitle, { marginTop: 18 }]}>COOKING INSTRUCTIONS</Text>
                  <TextInput
                    style={styles.customInstructionInput}
                    placeholder="e.g. Less oil, extra sauce, make it crispy..."
                    placeholderTextColor="#9CA3AF"
                    value={itemInstructions}
                    onChangeText={setItemInstructions}
                    multiline
                  />

                  {/* Quick Chips */}
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                    {['Less spicy', 'Extra sauce', 'Make it crispy', 'No onion/garlic'].map((chip) => (
                      <TouchableOpacity
                        key={chip}
                        onPress={() => {
                          if (!itemInstructions.includes(chip)) {
                            setItemInstructions((prev) => (prev ? `${prev}, ${chip}` : chip));
                          }
                        }}
                        style={styles.instructionChip}
                      >
                        <Text style={styles.instructionChipText}>+ {chip}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </ScrollView>

                <TouchableOpacity
                  style={styles.applyVegBtn}
                  activeOpacity={0.88}
                  onPress={() => {
                    const addonTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
                    const finalPrice = customizingDish.price + addonTotal;
                    const customizedProduct = {
                      ...customizingDish,
                      price: finalPrice,
                      addons: selectedAddons,
                      instructions: itemInstructions,
                    };
                    handleAddToCart(customizedProduct);
                    setCustomizingDish(null);
                  }}
                >
                  <Text style={styles.applyVegBtnText}>
                    ADD ITEM • ₹{customizingDish.price + selectedAddons.reduce((sum, a) => sum + a.price, 0)}
                  </Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>

      <ScrollView
        ref={mainScrollViewRef}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Suaaka Food Promotional Banner */}
        <View style={styles.bannerCard}>
          <View style={styles.bannerLeft}>
            <View style={styles.bannerTag}>
              <Text style={styles.bannerTagText}>⚡ SUPER FAST</Text>
            </View>
            <Text style={styles.bannerTitle}>50% OFF UP TO ₹120</Text>
            <Text style={styles.bannerSubtitle}>On top restaurants near you with free delivery</Text>
          </View>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400' }}
            style={styles.bannerImage}
          />
        </View>

        {/* Featured Restaurants Shelf */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Top Outlets Near You</Text>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.restaurantScroll}
        >
          {[
            {
              id: 'rest-1',
              name: 'Behrouz Royal Biryani',
              cuisines: 'Biryani • Mughlai',
              rating: '4.6 ★',
              time: '25-30 mins',
              price: '₹350 for two',
              image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400',
            },
            {
              id: 'rest-2',
              name: "La Pino'z Gourmet Pizza",
              cuisines: 'Pizza • Italian • Garlic Bread',
              rating: '4.4 ★',
              time: '20-25 mins',
              price: '₹300 for two',
              image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400',
            },
            {
              id: 'rest-3',
              name: 'The Burger Club',
              cuisines: 'Crispy Burgers • Fries',
              rating: '4.5 ★',
              time: '15-20 mins',
              price: '₹250 for two',
              image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400',
            },
          ].map((r) => {
            const isSelected = selectedRestaurant === r.name;
            return (
              <TouchableOpacity
                key={r.id}
                activeOpacity={0.8}
                onPress={() => handleSelectRestaurant(r.name)}
                style={[
                  styles.restaurantCard,
                  isSelected && { borderColor: COLORS.primary, borderWidth: 2 },
                ]}
              >
                <Image source={{ uri: r.image }} style={styles.restaurantImg} />
                <View style={styles.restaurantTimeBadge}>
                  <Ionicons name="time-outline" size={12} color="#FFF" />
                  <Text style={styles.restaurantTimeText}>{r.time}</Text>
                </View>
                <View style={styles.restaurantInfo}>
                  <View style={styles.restaurantTitleRow}>
                    <Text style={styles.restaurantName} numberOfLines={1}>{r.name}</Text>
                    <View style={styles.ratingBadge}>
                      <Text style={styles.ratingBadgeText}>{r.rating}</Text>
                    </View>
                  </View>
                  <Text style={styles.restaurantCuisines} numberOfLines={1}>{r.cuisines}</Text>
                  <Text style={styles.restaurantPrice}>{r.price}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Cuisines Carousel - Eat What Makes You Happy */}
        <View
          style={styles.sectionHeader}
          onLayout={(e) => setCuisinesLayoutY(e.nativeEvent.layout.y)}
        >
          <Text style={styles.sectionTitle}>Eat What Makes You Happy</Text>
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cuisinesScroll}
        >
          {categoriesLoading && dynamicCuisines.length === 0
            ? /* Skeleton placeholders while loading */
              Array.from({ length: 7 }).map((_, i) => (
                <View key={`skel-${i}`} style={styles.cuisineItem}>
                  <View style={[styles.cuisineIconBox, { backgroundColor: '#E5E7EB' }]} />
                  <View style={{ marginTop: 6, width: 48, height: 10, borderRadius: 4, backgroundColor: '#E5E7EB' }} />
                </View>
              ))
            : dynamicCuisines.map((item) => {
                const isSelected = selectedCuisine === item.id;
                return (
                  <TouchableOpacity
                    key={item.id}
                    onPress={() => handleSelectCuisine(item.id)}
                    style={styles.cuisineItem}
                  >
                    <View style={[styles.cuisineIconBox, isSelected && styles.cuisineIconBoxActive]}>
                      <Image source={{ uri: item.image }} style={styles.cuisineImg} resizeMode="cover" />
                    </View>
                    <Text
                      style={[styles.cuisineName, isSelected && styles.cuisineNameActive]}
                      numberOfLines={2}
                    >
                      {item.name}
                    </Text>
                  </TouchableOpacity>
                );
              })
          }
        </ScrollView>

        {/* Active Restaurant Filter Banner */}
        {selectedRestaurant && (
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, marginVertical: 8, backgroundColor: '#FFF7ED', paddingVertical: 10, borderRadius: 8, marginHorizontal: 16, borderLeftWidth: 4, borderLeftColor: COLORS.primary }}>
            <Text style={{ fontSize: 13, fontWeight: '600', color: COLORS.textDark }}>
              Showing dishes from: <Text style={{ color: COLORS.primary, fontWeight: '700' }}>{selectedRestaurant}</Text>
            </Text>
            <TouchableOpacity onPress={() => setSelectedRestaurant(null)}>
              <Ionicons name="close-circle" size={20} color={COLORS.textMuted} />
            </TouchableOpacity>
          </View>
        )}

        {/* Popular Dishes List */}
        <View
          style={styles.sectionHeader}
          onLayout={(e) => setDishesLayoutY(e.nativeEvent.layout.y)}
        >
          <Text style={styles.sectionTitle}>
            Popular Dishes ({filteredProducts.length})
          </Text>
        </View>

        <View style={styles.dishesList}>
          {filteredProducts.map((dish) => {
            const qty = getItemQuantity(dish._id);
            return (
              <View key={dish._id} style={styles.dishCard}>
                <TouchableOpacity
                  activeOpacity={0.8}
                  style={styles.dishDetails}
                  onPress={() => navigation.navigate('ProductDetail', { slug: dish.slug, id: dish._id, initialProduct: dish })}
                >
                  {/* Veg / Non-Veg Marker */}
                  <View style={styles.vegIndicatorRow}>
                    <View style={[styles.vegBox, dish.isVeg !== false ? styles.vegBoxGreen : styles.vegBoxRed]}>
                      <View style={[styles.vegInner, dish.isVeg !== false ? styles.vegInnerGreen : styles.vegInnerRed]} />
                    </View>
                    <Text
                      style={[
                        styles.vegLabelText,
                        dish.isVeg !== false ? { color: '#16A34A' } : { color: '#DC2626' },
                      ]}
                    >
                      {dish.isVeg !== false ? 'VEG' : 'NON-VEG'}
                    </Text>
                    {dish.rating?.average ? (
                      <View style={styles.starRatingBadge}>
                        <Ionicons name="star" size={10} color="#D97706" />
                        <Text style={styles.starRatingText}>{dish.rating.average.toFixed(1)}</Text>
                      </View>
                    ) : null}
                    {dish.preparationTime ? (
                      <Text style={styles.prepTimeText}>⏱️ {dish.preparationTime} mins</Text>
                    ) : null}
                  </View>

                  <Text style={styles.dishName}>{dish.name}</Text>
                  {dish.restaurantName && (
                    <Text style={styles.dishRestaurant}>by {dish.restaurantName}</Text>
                  )}

                  <View style={styles.priceRow}>
                    <Text style={styles.dishPrice}>₹{dish.price}</Text>
                    {dish.comparePrice > dish.price && (
                      <Text style={styles.dishComparePrice}>₹{dish.comparePrice}</Text>
                    )}
                  </View>

                  {dish.description && (
                    <Text style={styles.dishDescription} numberOfLines={2}>
                      {dish.description}
                    </Text>
                  )}
                  <Text style={styles.customizableText}>Customizable • Tap for details</Text>
                </TouchableOpacity>

                {/* Dish Image & Add Button */}
                <View style={styles.dishImageContainer}>
                  <TouchableOpacity
                    activeOpacity={0.8}
                    onPress={() => navigation.navigate('ProductDetail', { slug: dish.slug, id: dish._id, initialProduct: dish })}
                  >
                    <Image
                      source={{ uri: dish.images?.[0] || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300' }}
                      style={styles.dishImage}
                    />
                  </TouchableOpacity>

                  <View style={styles.actionBtnContainer}>
                    {qty === 0 ? (
                      <TouchableOpacity
                        onPress={() => {
                          setCustomizingDish(dish);
                          setSelectedAddons([]);
                          setItemInstructions('');
                        }}
                        style={styles.addButton}
                      >
                        <Text style={styles.addButtonText}>ADD</Text>
                        <Ionicons name="add" size={14} color="#EA580C" style={{ marginLeft: 2 }} />
                      </TouchableOpacity>
                    ) : (
                      <View style={styles.stepperContainer}>
                        <TouchableOpacity
                          onPress={() => updateQuantity(dish._id, qty - 1)}
                          style={styles.stepperBtn}
                        >
                          <Ionicons name="remove" size={14} color="#FFF" />
                        </TouchableOpacity>
                        <Text style={styles.stepperText}>{qty}</Text>
                        <TouchableOpacity
                          onPress={() => {
                            setCustomizingDish(dish);
                            setSelectedAddons([]);
                            setItemInstructions('');
                          }}
                          style={styles.stepperBtn}
                        >
                          <Ionicons name="add" size={14} color="#FFF" />
                        </TouchableOpacity>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Floating Bottom Cart Bar */}
      {totalFoodItems > 0 && (
        <View style={[styles.floatingCart, { bottom: insets.bottom + 12 }]}>
          <View>
            <Text style={styles.floatingCartCount}>{totalFoodItems} {totalFoodItems === 1 ? 'ITEM' : 'ITEMS'} ADDED</Text>
            <Text style={styles.floatingCartTotal}>₹{totalAmount.toLocaleString('en-IN')}</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('CartTab', { vertical: 'food' })}
            style={styles.viewCartButton}
          >
            <Text style={styles.viewCartButtonText}>View Cart</Text>
            <Ionicons name="arrow-forward" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  backButton: {
    padding: 6,
    marginRight: 6,
  },
  deliveryLocation: {
    flex: 1,
  },
  locationTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  deliveryToText: {
    fontSize: 11,
    fontWeight: '900',
    color: '#EA580C',
    letterSpacing: 0.5,
  },
  addressText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#1F2937',
    marginTop: 1,
  },
  cartButton: {
    position: 'relative',
    padding: 6,
  },
  badge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#EA580C',
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  badgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  searchSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: '#FFF',
    gap: 10,
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    borderRadius: 14,
    paddingHorizontal: 12,
    height: 42,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 13,
    color: '#1F2937',
    fontWeight: '500',
  },
  vegToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    paddingHorizontal: 10,
    height: 42,
    gap: 6,
  },
  vegToggleActive: {
    borderColor: '#16A34A',
    backgroundColor: '#F0FDF4',
  },
  vegDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#9CA3AF',
  },
  vegDotActive: {
    backgroundColor: '#16A34A',
  },
  vegToggleText: {
    fontSize: 12,
    fontWeight: '800',
    color: '#4B5563',
  },
  vegToggleTextActive: {
    color: '#16A34A',
  },
  scrollContent: {
    paddingBottom: 24,
  },
  bannerCard: {
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 20,
    backgroundColor: '#EA580C',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    overflow: 'hidden',
    ...SHADOWS.medium,
  },
  bannerLeft: {
    flex: 1,
    paddingRight: 10,
  },
  bannerTag: {
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginBottom: 6,
  },
  bannerTagText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '900',
  },
  bannerTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  bannerSubtitle: {
    color: '#FED7AA',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
  bannerImage: {
    width: 80,
    height: 80,
    borderRadius: 16,
  },
  sectionHeader: {
    paddingHorizontal: 16,
    marginTop: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '900',
    color: '#111827',
  },
  cuisinesScroll: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 14,
  },
  cuisineItem: {
    alignItems: 'center',
    width: 78,
  },
  cuisineIconBox: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#FFF',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    overflow: 'hidden',
    ...SHADOWS.light,
  },
  cuisineIconBoxActive: {
    borderColor: '#EA580C',
    borderWidth: 2.5,
  },
  cuisineImg: {
    width: '100%',
    height: '100%',
    borderRadius: 32,
  },
  cuisineName: {
    fontSize: 11,
    fontWeight: '700',
    color: '#4B5563',
    marginTop: 6,
    textAlign: 'center',
  },
  cuisineNameActive: {
    color: '#EA580C',
    fontWeight: '900',
  },
  filtersScroll: {
    paddingHorizontal: 16,
    gap: 8,
    marginTop: 16,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  filterChipActive: {
    backgroundColor: '#111827',
    borderColor: '#111827',
  },
  filterChipText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#4B5563',
  },
  filterChipTextActive: {
    color: '#FFF',
  },
  restaurantScroll: {
    paddingHorizontal: 16,
    gap: 14,
  },
  restaurantCard: {
    width: 240,
    backgroundColor: '#FFF',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    ...SHADOWS.light,
  },
  restaurantImg: {
    width: '100%',
    height: 125,
    backgroundColor: '#E5E7EB',
  },
  restaurantTimeBadge: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(17, 24, 39, 0.8)',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  restaurantTimeText: {
    color: '#FFF',
    fontSize: 11,
    fontWeight: '700',
  },
  restaurantInfo: {
    padding: 12,
  },
  restaurantTitleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  restaurantName: {
    fontSize: 14,
    fontWeight: '800',
    color: '#111827',
    flex: 1,
    marginRight: 6,
  },
  ratingBadge: {
    backgroundColor: '#16A34A',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  ratingBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  restaurantCuisines: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 3,
  },
  restaurantPrice: {
    fontSize: 11,
    fontWeight: '600',
    color: '#9CA3AF',
    marginTop: 2,
  },
  dishesList: {
    paddingHorizontal: 16,
    gap: 16,
  },
  dishCard: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: '#F3F4F6',
    ...SHADOWS.light,
  },
  dishDetails: {
    flex: 1,
    paddingRight: 12,
  },
  vegIndicatorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  vegBox: {
    width: 15,
    height: 15,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 3,
  },
  vegBoxGreen: {
    borderColor: '#16A34A',
  },
  vegBoxRed: {
    borderColor: '#DC2626',
  },
  vegInner: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  vegInnerGreen: {
    backgroundColor: '#16A34A',
  },
  vegInnerRed: {
    backgroundColor: '#DC2626',
  },
  starRatingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 4,
  },
  starRatingText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#B45309',
  },
  prepTimeText: {
    fontSize: 10,
    color: '#6B7280',
    fontWeight: '600',
  },
  dishName: {
    fontSize: 15,
    fontWeight: '800',
    color: '#111827',
  },
  dishRestaurant: {
    fontSize: 11,
    fontWeight: '600',
    color: '#EA580C',
    marginTop: 1,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  dishPrice: {
    fontSize: 15,
    fontWeight: '900',
    color: '#111827',
  },
  dishComparePrice: {
    fontSize: 12,
    color: '#9CA3AF',
    textDecorationLine: 'line-through',
  },
  dishDescription: {
    fontSize: 12,
    color: '#6B7280',
    lineHeight: 16,
    marginTop: 4,
  },
  dishImageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 105,
  },
  dishImage: {
    width: 105,
    height: 105,
    borderRadius: 16,
    backgroundColor: '#F3F4F6',
  },
  actionBtnContainer: {
    position: 'absolute',
    bottom: -10,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: '#EA580C',
    ...SHADOWS.medium,
  },
  addButtonText: {
    fontSize: 12,
    fontWeight: '900',
    color: '#EA580C',
  },
  stepperContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EA580C',
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 4,
    gap: 8,
    ...SHADOWS.medium,
  },
  stepperBtn: {
    padding: 2,
  },
  stepperText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '900',
    minWidth: 16,
    textAlign: 'center',
  },
  floatingCart: {
    position: 'absolute',
    left: 16,
    right: 16,
    backgroundColor: '#16A34A',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    ...SHADOWS.large,
  },
  floatingCartCount: {
    color: '#DCFCE7',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  floatingCartTotal: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '900',
  },
  viewCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 6,
  },
  viewCartButtonText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: '800',
  },
  dietaryBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    gap: 8,
  },
  dietaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  dietaryPillActiveAll: {
    backgroundColor: '#1E293B',
    borderColor: '#1E293B',
  },
  dietaryPillActiveVeg: {
    backgroundColor: '#F0FDF4',
    borderColor: '#16A34A',
  },
  dietaryPillActiveNonVeg: {
    backgroundColor: '#FEF2F2',
    borderColor: '#DC2626',
  },
  dietaryPillText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#4B5563',
  },
  dietaryPillTextActiveAll: {
    color: '#FFF',
  },
  dietaryPillTextActiveVeg: {
    color: '#15803D',
  },
  dietaryPillTextActiveNonVeg: {
    color: '#B91C1C',
  },
  vegLabelText: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  swiggyVegBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#F8FAFC',
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
  },
  swiggyVegBtnActive: {
    backgroundColor: '#ECFDF5',
    borderColor: '#10B981',
  },
  swiggyVegBtnText: {
    fontSize: 11,
    fontWeight: '900',
    color: '#64748B',
    letterSpacing: 0.5,
  },
  swiggyVegBtnTextActive: {
    color: '#059669',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  vegModalCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    width: '100%',
    maxWidth: 360,
    padding: 22,
    ...SHADOWS.large,
  },
  modalHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  modalHeaderTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: '#1E293B',
    lineHeight: 26,
    letterSpacing: -0.3,
  },
  modalHeaderRight: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  modalBowlImg: {
    width: 48,
    height: 48,
    borderRadius: 12,
  },
  modalCloseBtn: {
    backgroundColor: '#F1F5F9',
    padding: 6,
    borderRadius: 16,
  },
  radioOptionsGroup: {
    gap: 16,
    marginBottom: 16,
  },
  radioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  radioLabelText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#475569',
  },
  radioLabelTextSelected: {
    fontWeight: '800',
    color: '#0F172A',
  },
  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioOuterSelected: {
    borderColor: '#10B981',
  },
  radioInnerGreen: {
    width: 11,
    height: 11,
    borderRadius: 5.5,
    backgroundColor: '#10B981',
  },
  dottedDivider: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderStyle: 'dashed',
    marginVertical: 14,
  },
  checkboxRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: 8,
  },
  checkboxLabelText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#64748B',
  },
  checkboxBox: {
    width: 20,
    height: 20,
    borderRadius: 6,
    borderWidth: 1.5,
    borderColor: '#CBD5E1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxBoxChecked: {
    borderColor: '#10B981',
    backgroundColor: '#ECFDF5',
  },
  applyVegBtn: {
    backgroundColor: '#10B981',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 18,
    ...SHADOWS.medium,
  },
  applyVegBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  customizableText: {
    fontSize: 10,
    color: '#EA580C',
    fontWeight: '800',
    marginTop: 6,
  },
  customSectionTitle: {
    fontSize: 12,
    fontWeight: '900',
    color: '#64748B',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  addonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  addonName: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1E293B',
  },
  addonPrice: {
    fontSize: 13,
    fontWeight: '800',
    color: '#059669',
  },
  customInstructionInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 13,
    color: '#1E293B',
    minHeight: 60,
  },
  instructionChip: {
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 16,
  },
  instructionChipText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#475569',
  },
});
