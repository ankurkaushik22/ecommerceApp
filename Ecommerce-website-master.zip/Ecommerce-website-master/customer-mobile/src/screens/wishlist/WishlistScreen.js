import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Vibration,
} from 'react-native';
import { useMutation } from '@apollo/client';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useWishlistStore } from '../../store/wishlistStore';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import ProductCard from '../../components/common/ProductCard';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import { COLORS, SIZES } from '../../constants/theme';

export default function WishlistScreen({ navigation }) {
  const [variantModalProduct, setVariantModalProduct] = useState(null);
  const { items, loadWishlist } = useWishlistStore();
  const setCart = useCartStore((s) => s.setCart);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  useEffect(() => {
    loadWishlist();
  }, [loadWishlist]);

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
    onError: (err) => Alert.alert('Error', err.message),
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      Alert.alert('Sign In Required', 'Please sign in to add items to your cart.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => navigation.navigate('Login') },
      ]);
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex !== undefined ? forcedVariantIndex : undefined,
        },
      },
    });
  };

  return (
    <View style={styles.container}>
      <Header title={`My Wishlist (${items.length})`} showBack={true} />

      {items.length === 0 ? (
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>💖</Text>
          <Text style={styles.emptyTitle}>Your Wishlist is Empty</Text>
          <Text style={styles.emptySub}>
            Tap the heart icon on any product to save it here for later.
          </Text>
          <TouchableOpacity
            style={styles.browseBtn}
            onPress={() => navigation.navigate('HomeTab')}
          >
            <Text style={styles.browseBtnText}>Discover Products</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          <Text style={styles.resultsCount}>
            {items.length} {items.length === 1 ? 'saved item' : 'saved items'}
          </Text>
          <View style={styles.grid}>
            {items.map((prod) => (
              <ProductCard
                key={prod._id}
                product={prod}
                onAddToCart={handleAddToCart}
              />
            ))}
          </View>
        </ScrollView>
      )}

      {/* Quick Variant Selector Bottom Sheet */}
      <VariantSelectModal
        visible={!!variantModalProduct}
        product={variantModalProduct}
        onClose={() => setVariantModalProduct(null)}
        onConfirmAddToCart={(prod, varIdx) => handleAddToCart(prod, varIdx)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    paddingBottom: 30,
  },
  resultsCount: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 12,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  emptyEmoji: {
    fontSize: 50,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
  },
  emptySub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 20,
    maxWidth: 240,
  },
  browseBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: SIZES.radiusMd,
  },
  browseBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
});
