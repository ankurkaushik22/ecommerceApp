import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { GET_ME } from '../../graphql/queries';
import { useAuthStore } from '../../store/authStore';
import { useWishlistStore } from '../../store/wishlistStore';
import Header from '../../components/common/Header';
import SupportModal from '../../components/common/SupportModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function ProfileScreen({ navigation }) {
  const [supportModalVisible, setSupportModalVisible] = useState(false);
  const { user, isAuthenticated, logout } = useAuthStore();
  const wishlistItems = useWishlistStore((s) => s.items);

  const { data } = useQuery(GET_ME, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const currentUser = data?.me || user;

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out of Suaaka?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out',
        style: 'destructive',
        onPress: () => {
          logout();
          navigation.navigate('HomeTab');
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <Header title="My Account" showBack={false} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* User Card */}
        {isAuthenticated && currentUser ? (
          <View style={styles.userCard}>
            <View style={styles.avatarCircle}>
              <Text style={styles.avatarLetter}>
                {currentUser.name?.[0]?.toUpperCase() || 'U'}
              </Text>
            </View>
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{currentUser.name}</Text>
              <Text style={styles.userEmail}>{currentUser.email}</Text>
              <View style={styles.roleBadge}>
                <Ionicons
                  name={currentUser.role === 'vendor' ? 'business-outline' : currentUser.role === 'admin' || currentUser.role === 'superadmin' ? 'shield-checkmark-outline' : 'person-circle-outline'}
                  size={13}
                  color={COLORS.primary}
                />
                <Text style={styles.roleText}>
                  {currentUser.role === 'customer' || !currentUser.role
                    ? 'Customer Account'
                    : currentUser.role === 'vendor'
                    ? 'Merchant / Seller'
                    : `${currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1)} Account`}
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.guestCard}>
            <View style={styles.guestIcon}>
              <Ionicons name="person-outline" size={32} color={COLORS.primary} />
            </View>
            <Text style={styles.guestTitle}>Welcome to Suaaka</Text>
            <Text style={styles.guestSub}>Sign in to view orders, save addresses & manage profile.</Text>
            <TouchableOpacity
              style={styles.loginBtn}
              onPress={() => navigation.navigate('Login')}
            >
              <Text style={styles.loginBtnText}>Sign In / Register</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Account Menu */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionHeader}>Quick Links & Orders</Text>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => {
              if (!isAuthenticated) navigation.navigate('Login', { redirect: 'OrdersList' });
              else navigation.navigate('OrdersList');
            }}
          >
            <View style={[styles.menuIconWrap, { backgroundColor: '#EFF6FF' }]}>
              <Ionicons name="cube-outline" size={20} color="#2563EB" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>My Orders</Text>
              <Text style={styles.menuSub}>Track packages, view history & tax invoices</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('WishlistTab')}
          >
            <View style={[styles.menuIconWrap, { backgroundColor: '#FDF2F8' }]}>
              <Ionicons name="heart-outline" size={20} color="#DB2777" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Wishlist ({wishlistItems.length})</Text>
              <Text style={styles.menuSub}>Saved items & favorites</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => {
              if (!isAuthenticated) navigation.navigate('Login', { redirect: 'Addresses' });
              else navigation.navigate('Addresses');
            }}
          >
            <View style={[styles.menuIconWrap, { backgroundColor: '#F0FDF4' }]}>
              <Ionicons name="location-outline" size={20} color="#16A34A" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Saved Addresses</Text>
              <Text style={styles.menuSub}>Manage delivery addresses & defaults</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.menuItem}
            onPress={() => navigation.navigate('Notifications')}
          >
            <View style={[styles.menuIconWrap, { backgroundColor: '#FFFBEB' }]}>
              <Ionicons name="notifications-outline" size={20} color="#D97706" />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Notifications</Text>
              <Text style={styles.menuSub}>Order updates & promotional alerts</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
          </TouchableOpacity>
        </View>

        {/* App Info & Settings */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionHeader}>Customer Support & App</Text>

          <TouchableOpacity
            style={[
              styles.menuItem,
              {
                borderBottomWidth: 1,
                borderBottomColor: COLORS.borderLight,
                paddingBottom: 14,
                marginBottom: 8,
              },
            ]}
            onPress={() => {
              if (!isAuthenticated) {
                navigation.navigate('Login');
              } else {
                setSupportModalVisible(true);
              }
            }}
          >
            <View style={[styles.menuIconWrap, { backgroundColor: COLORS.primaryLight }]}>
              <Ionicons name="headset-outline" size={20} color={COLORS.primary} />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Help & Customer Support</Text>
              <Text style={styles.menuSub}>Send query/feedback directly to admin</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
          </TouchableOpacity>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Currency Standard</Text>
            <Text style={styles.infoVal}>Indian Rupee (₹ INR)</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Tax Engine</Text>
            <Text style={styles.infoVal}>GST Compliant (CGST + SGST)</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Version</Text>
            <Text style={styles.infoVal}>v1.0.0 (Expo React Native)</Text>
          </View>
        </View>

        {/* Logout Button */}
        {isAuthenticated && (
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={18} color={COLORS.danger} />
            <Text style={styles.logoutBtnText}>Sign Out of Suaaka</Text>
          </TouchableOpacity>
        )}

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Help & Support Modal */}
      <SupportModal
        visible={supportModalVisible}
        onClose={() => setSupportModalVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    gap: 14,
  },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  avatarCircle: {
    width: 54,
    height: 54,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.glow,
  },
  avatarLetter: {
    fontSize: SIZES.xl,
    fontWeight: '900',
    color: COLORS.white,
  },
  userInfo: {
    marginLeft: 14,
    flex: 1,
  },
  userName: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.text,
  },
  userEmail: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  roleBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.primaryLight,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: SIZES.radiusSm,
    alignSelf: 'flex-start',
    marginTop: 6,
  },
  roleText: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.primaryDark,
  },
  guestCard: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  guestIcon: {
    width: 60,
    height: 60,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  guestTitle: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.text,
  },
  guestSub: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 4,
    marginBottom: 16,
    maxWidth: 240,
  },
  loginBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: SIZES.radiusMd,
    ...SHADOWS.glow,
  },
  loginBtnText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '700',
  },
  menuSection: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  sectionHeader: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.textSecondary,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  menuIconWrap: {
    width: 38,
    height: 38,
    borderRadius: SIZES.radiusSm,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  menuSub: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 1,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.borderLight,
  },
  infoLabel: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
  },
  infoVal: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: COLORS.dangerLight,
    borderWidth: 1,
    borderColor: COLORS.danger,
    paddingVertical: 12,
    borderRadius: SIZES.radiusMd,
    marginTop: 4,
  },
  logoutBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.danger,
  },
});
