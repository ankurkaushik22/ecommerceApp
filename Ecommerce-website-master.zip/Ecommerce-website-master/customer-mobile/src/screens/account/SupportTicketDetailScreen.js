import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from '@apollo/client';
import { format } from 'date-fns';
import { GET_SUPPORT_TICKET } from '../../graphql/queries';
import Header from '../../components/common/Header';
import SupportModal from '../../components/common/SupportModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function SupportTicketDetailScreen({ route, navigation }) {
  const { ticketId, ticketNumber } = route.params || {};
  const targetId = ticketId || ticketNumber;
  const [supportModalVisible, setSupportModalVisible] = useState(false);

  const { data, loading, error, refetch } = useQuery(GET_SUPPORT_TICKET, {
    variables: { id: targetId },
    skip: !targetId,
    fetchPolicy: 'cache-and-network',
  });

  const ticket = data?.getSupportTicket;

  const getStatusBadgeStyle = (status) => {
    switch (status?.toLowerCase()) {
      case 'in_progress':
        return { bg: '#FFFBEB', text: '#D97706', label: 'IN PROGRESS', icon: 'time-outline' };
      case 'resolved':
        return { bg: '#F0FDF4', text: '#16A34A', label: 'RESOLVED', icon: 'checkmark-circle-outline' };
      case 'closed':
        return { bg: '#F1F5F9', text: '#64748B', label: 'CLOSED', icon: 'lock-closed-outline' };
      default:
        return { bg: '#EFF6FF', text: '#2563EB', label: 'OPEN', icon: 'ellipse-outline' };
    }
  };

  const statusStyle = getStatusBadgeStyle(ticket?.status);

  return (
    <View style={styles.container}>
      <Header title={ticket?.ticketNumber || 'Support Ticket'} showBack />

      {loading && !ticket ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Loading support details...</Text>
        </View>
      ) : error || !ticket ? (
        <View style={styles.centerBox}>
          <Ionicons name="alert-circle-outline" size={48} color={COLORS.danger} />
          <Text style={styles.errorTitle}>Ticket Not Found</Text>
          <Text style={styles.errorSub}>
            {error?.message || 'We could not locate this support request.'}
          </Text>
          <TouchableOpacity style={styles.retryBtn} onPress={() => refetch()}>
            <Text style={styles.retryBtnText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scroll}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={refetch} />}
        >
          {/* Status Header Banner */}
          <View style={[styles.statusBanner, { backgroundColor: statusStyle.bg }]}>
            <View style={{ flex: 1 }}>
              <Text style={styles.ticketNumText}>Ticket #{ticket.ticketNumber}</Text>
              <Text style={styles.ticketDateText}>
                Logged on {ticket.createdAt ? format(new Date(ticket.createdAt), 'dd MMMM yyyy, hh:mm a') : 'Recently'}
              </Text>
            </View>
            <View style={[styles.statusBadge, { borderColor: statusStyle.text }]}>
              <Ionicons name={statusStyle.icon} size={14} color={statusStyle.text} />
              <Text style={[styles.statusText, { color: statusStyle.text }]}>
                {statusStyle.label}
              </Text>
            </View>
          </View>

          {/* User Query Card */}
          <View style={styles.card}>
            <View style={styles.cardHeader}>
              <Ionicons name="chatbox-ellipses-outline" size={18} color={COLORS.primary} />
              <Text style={styles.cardTitle}>Your Issue & Details</Text>
              {ticket.category && (
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryText}>{ticket.category.toUpperCase()}</Text>
                </View>
              )}
            </View>

            <Text style={styles.subjectText}>{ticket.subject}</Text>
            <View style={styles.divider} />
            <Text style={styles.messageText}>{ticket.message}</Text>
          </View>

          {/* Admin / Team Reply Card */}
          {ticket.adminReply ? (
            <View style={[styles.card, styles.replyCard]}>
              <View style={styles.replyHeader}>
                <View style={styles.adminAvatarCircle}>
                  <Ionicons name="headset" size={16} color={COLORS.white} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.replyAuthor}>
                    {ticket.repliedBy?.name || 'Suaaka Support Team'}
                  </Text>
                  <Text style={styles.replyTime}>
                    {ticket.repliedAt ? format(new Date(ticket.repliedAt), 'dd MMM yyyy, hh:mm a') : 'Recently'}
                  </Text>
                </View>
                <View style={styles.adminTag}>
                  <Text style={styles.adminTagText}>OFFICIAL RESPONSE</Text>
                </View>
              </View>

              <View style={styles.replyDivider} />

              <Text style={styles.replyContentText}>{ticket.adminReply}</Text>

              {ticket.status === 'resolved' || ticket.status === 'closed' ? (
                <View style={styles.resolvedNote}>
                  <Ionicons name="checkmark-circle" size={16} color="#16A34A" />
                  <Text style={styles.resolvedNoteText}>
                    This ticket has been marked as {ticket.status?.toUpperCase()}.
                  </Text>
                </View>
              ) : null}
            </View>
          ) : ticket.status === 'closed' || ticket.status === 'resolved' ? (
            <View style={[styles.pendingCard, { backgroundColor: '#F8FAFC', borderColor: '#CBD5E1' }]}>
              <Ionicons name="checkmark-circle-outline" size={24} color="#64748B" />
              <View style={{ flex: 1 }}>
                <Text style={[styles.pendingTitle, { color: '#334155' }]}>
                  Ticket {ticket.status?.toUpperCase()}
                </Text>
                <Text style={[styles.pendingSub, { color: '#64748B' }]}>
                  This support request has been marked as {ticket.status?.toLowerCase()}. If you need further assistance, you can submit a new query below.
                </Text>
              </View>
            </View>
          ) : ticket.status === 'in_progress' ? (
            <View style={[styles.pendingCard, { backgroundColor: '#FFFBEB', borderColor: '#FDE68A' }]}>
              <Ionicons name="time-outline" size={24} color="#D97706" />
              <View style={{ flex: 1 }}>
                <Text style={styles.pendingTitle}>In Progress</Text>
                <Text style={styles.pendingSub}>
                  Our support team is actively looking into your request and will provide an update here shortly.
                </Text>
              </View>
            </View>
          ) : (
            <View style={styles.pendingCard}>
              <Ionicons name="time-outline" size={24} color="#D97706" />
              <View style={{ flex: 1 }}>
                <Text style={styles.pendingTitle}>Under Review</Text>
                <Text style={styles.pendingSub}>
                  Our support team is reviewing your ticket and will post a response here shortly. You will also get a notification.
                </Text>
              </View>
            </View>
          )}

          {/* New Query Button */}
          <TouchableOpacity
            style={styles.newTicketBtn}
            onPress={() => setSupportModalVisible(true)}
          >
            <Ionicons name="add-circle-outline" size={18} color={COLORS.primary} />
            <Text style={styles.newTicketBtnText}>Need More Help? Submit New Ticket</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {/* Support Modal for creating new ticket */}
      <SupportModal
        visible={supportModalVisible}
        onClose={() => setSupportModalVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
    gap: 14,
  },
  statusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 14,
    borderRadius: SIZES.radiusMd,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  ticketNumText: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  ticketDateText: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: '#FFF',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '800',
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    ...SHADOWS.small,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  cardTitle: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    flex: 1,
  },
  categoryBadge: {
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#475569',
  },
  subjectText: {
    fontSize: SIZES.md,
    fontWeight: '800',
    color: COLORS.text,
    lineHeight: 22,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 12,
  },
  messageText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    lineHeight: 20,
  },
  replyCard: {
    borderColor: '#BFDBFE',
    backgroundColor: '#F8FAFC',
    borderLeftWidth: 4,
    borderLeftColor: COLORS.primary,
  },
  replyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  adminAvatarCircle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  replyAuthor: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  replyTime: {
    fontSize: 10,
    color: COLORS.textMuted,
    marginTop: 1,
  },
  adminTag: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  adminTagText: {
    fontSize: 9,
    fontWeight: '900',
    color: COLORS.primary,
  },
  replyDivider: {
    height: 1,
    backgroundColor: '#E2E8F0',
    marginVertical: 12,
  },
  replyContentText: {
    fontSize: SIZES.sm,
    color: '#1E293B',
    lineHeight: 22,
    fontWeight: '500',
  },
  resolvedNote: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#DCFCE7',
    padding: 10,
    borderRadius: 10,
    marginTop: 14,
  },
  resolvedNoteText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#15803D',
  },
  pendingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FFFBEB',
    padding: 16,
    borderRadius: SIZES.radiusMd,
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  pendingTitle: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: '#B45309',
  },
  pendingSub: {
    fontSize: 11,
    color: '#78350F',
    marginTop: 2,
    lineHeight: 16,
  },
  newTicketBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: COLORS.white,
    paddingVertical: 14,
    borderRadius: SIZES.radiusMd,
    borderWidth: 1,
    borderColor: COLORS.primary,
    marginTop: 8,
  },
  newTicketBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.primary,
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 12,
  },
  errorTitle: {
    fontSize: SIZES.lg,
    fontWeight: '800',
    color: COLORS.text,
    marginTop: 12,
  },
  errorSub: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    marginTop: 4,
  },
  retryBtn: {
    backgroundColor: COLORS.primary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: SIZES.radiusSm,
    marginTop: 16,
  },
  retryBtnText: {
    color: COLORS.white,
    fontWeight: '700',
  },
});
