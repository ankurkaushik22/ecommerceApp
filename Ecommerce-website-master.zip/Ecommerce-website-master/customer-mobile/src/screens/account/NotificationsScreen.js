import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { useNavigation } from '@react-navigation/native';
import { format } from 'date-fns';
import { GET_NOTIFICATIONS } from '../../graphql/queries';
import { MARK_NOTIFICATION_READ, MARK_ALL_NOTIFICATIONS_READ } from '../../graphql/mutations';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function NotificationsScreen() {
  const navigation = useNavigation();

  const { data, loading, refetch } = useQuery(GET_NOTIFICATIONS, {
    fetchPolicy: 'cache-and-network',
  });

  const [markRead] = useMutation(MARK_NOTIFICATION_READ, {
    onCompleted: () => refetch(),
  });

  const [markAllRead, { loading: markingAll }] = useMutation(MARK_ALL_NOTIFICATIONS_READ, {
    onCompleted: () => {
      refetch();
    },
    onError: (err) => {
      Alert.alert('Error', err.message || 'Could not mark notifications as read');
    },
  });

  const notifications = data?.getNotifications || [];
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleNotificationPress = (n) => {
    // Mark as read if unread
    if (!n.isRead) {
      markRead({ variables: { id: n._id } });
    }

    // Check for support ticket notification
    let ticketTarget = n.data?.ticketId || n.data?.ticketNumber;
    if (
      !ticketTarget &&
      (n.title?.toLowerCase().includes('ticket') || n.message?.toLowerCase().includes('ticket'))
    ) {
      const match = (n.message + ' ' + n.title).match(/#?(TKT-[0-9A-Za-z_-]+)/i);
      if (match && match[1]) {
        ticketTarget = match[1];
      }
    }

    if (ticketTarget) {
      const cleanTicketId = ticketTarget.toString().replace('#', '').trim();
      navigation.navigate('SupportTicketDetail', { ticketId: cleanTicketId });
      return;
    }

    // Try to extract order information
    let rawTarget = n.data?.orderId || n.data?.orderNumber || n.data?._id;

    if (
      !rawTarget &&
      (n.type === 'order' ||
        n.title?.toLowerCase().includes('order') ||
        n.message?.toLowerCase().includes('order'))
    ) {
      const match = (n.message + ' ' + n.title).match(/#?(ORD-[0-9A-Za-z_-]+)/i);
      if (match && match[1]) {
        rawTarget = match[1];
      }
    }

    if (rawTarget) {
      const cleanOrderId = rawTarget.toString().replace('#', '').trim();
      navigation.navigate('OrderDetail', { orderId: cleanOrderId });
    } else if (n.type === 'promotion') {
      navigation.navigate('Explore');
    }
  };

  const renderRightComponent = () => {
    if (unreadCount === 0) return null;
    return (
      <TouchableOpacity
        onPress={() => markAllRead()}
        disabled={markingAll}
        style={styles.markAllHeaderBtn}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        {markingAll ? (
          <ActivityIndicator size="small" color={COLORS.primary} />
        ) : (
          <View style={styles.markAllContent}>
            <Ionicons name="checkmark-done-outline" size={16} color={COLORS.primary} />
            <Text style={styles.markAllText}>Mark all read</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Header title="Notifications" showBack rightComponent={renderRightComponent()} />

      {loading && notifications.length === 0 ? (
        <View style={styles.centerBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>Loading notifications...</Text>
        </View>
      ) : notifications.length === 0 ? (
        <View style={styles.centerBox}>
          <Text style={styles.emptyEmoji}>🔔</Text>
          <Text style={styles.emptyTitle}>No Notifications</Text>
          <Text style={styles.emptySub}>
            You're all caught up! Order updates and promotional offers will appear here.
          </Text>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {unreadCount > 0 && (
            <View style={styles.topStatusBar}>
              <Text style={styles.unreadCountText}>
                {unreadCount} unread notification{unreadCount > 1 ? 's' : ''}
              </Text>
              <TouchableOpacity
                onPress={() => markAllRead()}
                disabled={markingAll}
                style={styles.inlineMarkAllBtn}
              >
                <Ionicons name="checkmark-done" size={15} color={COLORS.primary} />
                <Text style={styles.inlineMarkAllText}>Mark all as read</Text>
              </TouchableOpacity>
            </View>
          )}

          {notifications.map((n) => {
            const isTicket =
              n.data?.ticketId ||
              n.data?.ticketNumber ||
              n.title?.toLowerCase().includes('ticket') ||
              n.message?.toLowerCase().includes('ticket');
            const isOrder =
              n.type === 'order' ||
              n.title?.toLowerCase().includes('order') ||
              n.message?.toLowerCase().includes('order');

            let iconName = 'pricetag-outline';
            let iconBg = '#FFFBEB';
            let iconColor = '#D97706';

            if (isTicket) {
              iconName = 'headset-outline';
              iconBg = '#F0FDF4';
              iconColor = '#16A34A';
            } else if (isOrder) {
              iconName = 'cube-outline';
              iconBg = '#EFF6FF';
              iconColor = '#2563EB';
            }

            return (
              <TouchableOpacity
                key={n._id}
                style={[styles.itemCard, !n.isRead && styles.itemCardUnread]}
                activeOpacity={0.7}
                onPress={() => handleNotificationPress(n)}
              >
                <View style={[styles.iconWrap, { backgroundColor: iconBg }]}>
                  <Ionicons name={iconName} size={20} color={iconColor} />
                </View>

                <View style={{ flex: 1 }}>
                  <View style={styles.titleRow}>
                    <Text
                      style={[styles.title, !n.isRead && styles.titleUnread]}
                      numberOfLines={1}
                    >
                      {n.title}
                    </Text>
                    {!n.isRead && <View style={styles.unreadDot} />}
                  </View>
                  <Text style={styles.message}>{n.message}</Text>
                  <View style={styles.bottomRow}>
                    <Text style={styles.timestamp}>
                      {n.createdAt ? format(new Date(n.createdAt), 'dd MMM, hh:mm a') : 'Recently'}
                    </Text>
                    {isTicket ? (
                      <View style={[styles.viewOrderTag, { backgroundColor: '#F0FDF4' }]}>
                        <Text style={[styles.viewOrderText, { color: '#16A34A' }]}>
                          View Ticket
                        </Text>
                      </View>
                    ) : isOrder ? (
                      <View style={styles.viewOrderTag}>
                        <Text style={styles.viewOrderText}>View Order</Text>
                      </View>
                    ) : null}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  markAllHeaderBtn: {
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: SIZES.radiusSm,
  },
  markAllContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  markAllText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
  topStatusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFF7ED',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: '#FED7AA',
    marginBottom: 4,
  },
  unreadCountText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#C2410C',
  },
  inlineMarkAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  inlineMarkAllText: {
    fontSize: 12,
    fontWeight: '700',
    color: COLORS.primary,
  },
  scroll: {
    padding: SIZES.padding,
    gap: 10,
  },
  itemCard: {
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    gap: 12,
    ...SHADOWS.small,
  },
  itemCardUnread: {
    borderColor: '#FED7AA',
    backgroundColor: '#FFFCF8',
    borderLeftWidth: 3.5,
    borderLeftColor: COLORS.primary,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: SIZES.radiusSm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
    flex: 1,
  },
  titleUnread: {
    fontWeight: '800',
    color: COLORS.primaryDark,
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primary,
    marginLeft: 6,
  },
  message: {
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 3,
    lineHeight: 18,
  },
  bottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 6,
  },
  timestamp: {
    fontSize: 10,
    color: COLORS.textMuted,
  },
  viewOrderTag: {
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderRadius: 6,
  },
  viewOrderText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#2563EB',
  },
  centerBox: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: SIZES.padding * 2,
  },
  loadingText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginTop: 10,
  },
  emptyEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyTitle: {
    fontSize: SIZES.lg,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 6,
  },
  emptySub: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
});
