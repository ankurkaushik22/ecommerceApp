import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  ActivityIndicator,
  Image,
  TouchableOpacity,
  Vibration,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_PRODUCTS } from '../../graphql/queries';
import { ADD_TO_CART } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import Header from '../../components/common/Header';
import ProductCard from '../../components/common/ProductCard';
import VariantSelectModal from '../../components/common/VariantSelectModal';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function SellerStoreScreen({ route, navigation }) {
  const { sellerId, sellerName, vendor } = route.params || {};
  const [variantModalProduct, setVariantModalProduct] = useState(null);

  const setCart = useCartStore((s) => s.setCart);
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vendorId: sellerId },
      pagination: { page: 1, limit: 40 },
    },
    skip: !sellerId,
  });

  const [addToCart] = useMutation(ADD_TO_CART, {
    onCompleted: (res) => {
      setCart(res.addToCart);
      Vibration.vibrate(75);
      setVariantModalProduct(null);
    },
  });

  const handleAddToCart = (product, forcedVariantIndex) => {
    if (!isAuthenticated) {
      navigation.navigate('Login');
      return;
    }

    const hasMultipleVariants =
      (product.variants?.[0]?.options?.length > 1) ||
      (product.variants?.length > 1);

    if (hasMultipleVariants && forcedVariantIndex === undefined) {
      setVariantModalProduct(product);
      return;
    }

    addToCart({
      variables: {
        input: {
          productId: product._id,
          quantity: 1,
          variantIndex: forcedVariantIndex,
        },
      },
    });
  };

  const products = data?.getProducts?.products || [];
  const displayVendor = vendor || products[0]?.vendor;
  const storeTitle = sellerName || displayVendor?.name || 'Seller Store';

  return (
    <View style={styles.container}>
      <Header title={storeTitle} showBack showCart />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Store Banner & Profile Header */}
        <View style={styles.profileCard}>
          <View style={styles.avatarRow}>
            <View style={styles.avatarWrapper}>
              {displayVendor?.avatar ? (
                <Image source={{ uri: displayVendor.avatar }} style={styles.avatarImg} />
              ) : (
                <Ionicons name="storefront" size={28} color={COLORS.primary} />
              )}
            </View>
            <View style={styles.profileTextCol}>
              <View style={styles.nameBadgeRow}>
                <Text style={styles.storeName}>{storeTitle}</Text>
                <View style={styles.verifiedBadge}>
                  <Ionicons name="checkmark-circle" size={14} color="#0284c7" />
                  <Text style={styles.verifiedText}>Verified</Text>
                </View>
              </View>
              <Text style={styles.storeSub}>Official Store on Suaaka • 100% Genuine</Text>
            </View>
          </View>

          <View style={styles.statsStrip}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>⭐ 4.8</Text>
              <Text style={styles.statLabel}>Store Rating</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{products.length}</Text>
              <Text style={styles.statLabel}>Products</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>⚡ Fast</Text>
              <Text style={styles.statLabel}>Delivery</Text>
            </View>
          </View>
        </View>

        {/* Products Grid Header */}
        <View style={styles.sectionHeaderRow}>
          <Text style={styles.sectionTitle}>All Products ({products.length})</Text>
        </View>

        {loading ? (
          <View style={styles.loadingBox}>
            <ActivityIndicator size="large" color={COLORS.primary} />
            <Text style={styles.loadingText}>Loading store products...</Text>
          </View>
        ) : products.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyEmoji}>📦</Text>
            <Text style={styles.emptyTitle}>No Products Found</Text>
            <Text style={styles.emptyText}>This seller currently has no active products listed.</Text>
          </View>
        ) : (
          <View style={styles.productGrid}>
            {products.map((item) => (
              <View key={item._id} style={styles.productCol}>
                <ProductCard
                  product={item}
                  onPress={() => navigation.navigate('ProductDetail', { slug: item.slug })}
                  onAddToCart={() => handleAddToCart(item)}
                />
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Variant Selector Modal */}
      {variantModalProduct && (
        <VariantSelectModal
          visible={!!variantModalProduct}
          product={variantModalProduct}
          onClose={() => setVariantModalProduct(null)}
          onConfirm={(optIndex) => handleAddToCart(variantModalProduct, optIndex)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scroll: {
    paddingBottom: 40,
  },
  profileCard: {
    backgroundColor: COLORS.white,
    margin: 16,
    borderRadius: 20,
    padding: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    ...SHADOWS.small,
  },
  avatarRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatarWrapper: {
    width: 60,
    height: 60,
    borderRadius: 16,
    backgroundColor: '#EEF2FF',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#E0E7FF',
  },
  avatarImg: {
    width: '100%',
    height: '100%',
  },
  profileTextCol: {
    flex: 1,
  },
  nameBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flexWrap: 'wrap',
  },
  storeName: {
    fontSize: 17,
    fontWeight: '800',
    color: COLORS.text,
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: '#E0F2FE',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
  },
  verifiedText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#0369A1',
  },
  storeSub: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statsStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.text,
  },
  statLabel: {
    fontSize: 10,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statDivider: {
    width: 1,
    height: 20,
    backgroundColor: '#E2E8F0',
  },
  sectionHeaderRow: {
    paddingHorizontal: 16,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  productGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 10,
  },
  productCol: {
    width: '50%',
    padding: 6,
  },
  loadingBox: {
    padding: 40,
    alignItems: 'center',
    gap: 10,
  },
  loadingText: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  emptyBox: {
    padding: 40,
    alignItems: 'center',
    gap: 8,
  },
  emptyEmoji: {
    fontSize: 36,
  },
  emptyTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  emptyText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    textAlign: 'center',
  },
});
