import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from '@apollo/client';
import { GET_CART, GET_ME, GET_DELIVERY_OPTIONS } from '../../graphql/queries';
import { PLACE_ORDER } from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import Header from '../../components/common/Header';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

export default function CheckoutScreen({ route, navigation }) {
  const { deliverySlot: initialSlot } = route.params || {};
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(0);
  const [useNewAddress, setUseNewAddress] = useState(false);

  // New address fields
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');

  // Delivery option & payment
  const [selectedDeliveryOptionId, setSelectedDeliveryOptionId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' | 'stripe' | 'upi'
  const [instructionsText, setInstructionsText] = useState('');
  const [saveAsDefault, setSaveAsDefault] = useState(true);

  const selectedVertical = route.params?.vertical;

  const storeItems = useCartStore((s) => s.items) || [];
  const removeItem = useCartStore((s) => s.removeItem);
  const clearCartState = useCartStore((s) => s.clearCartState);

  const getItemVertical = (item) => {
    if (item.vertical && item.vertical !== 'shopping') return item.vertical;
    if (item.product?.vertical && item.product.vertical !== 'shopping') return item.product.vertical;
    if (item.vertical) return item.vertical;
    if (item.product?.vertical) return item.product.vertical;

    const name = (item.name || item.product?.name || '').toLowerCase();
    const cat = (item.category?.name || item.product?.category?.name || item.category?.slug || '').toLowerCase();

    if (cat.includes('food') || cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') ||
        name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('tikka') || name.includes('momo') || name.includes('shake') || name.includes('wrap') || name.includes('roll') || name.includes('thali')) {
      return 'food';
    }
    if (cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') ||
        name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('paneer') || name.includes('bread') || name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') || name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') || name.includes('apple') || name.includes('avocado') || name.includes('spinach') || name.includes('carrot') || name.includes('strawberry')) {
      return 'grocery';
    }
    return 'shopping';
  };

  const { data: cartData } = useQuery(GET_CART);
  const { data: meData } = useQuery(GET_ME);
  const { data: deliveryOptionsData } = useQuery(GET_DELIVERY_OPTIONS, {
    onCompleted: (res) => {
      const opts = res?.getDeliveryOptions || [];
      if (opts.length > 0 && !selectedDeliveryOptionId) {
        setSelectedDeliveryOptionId(opts[0]._id);
      }
    },
  });

  const cart = cartData?.getCart;
  const rawItems = cart?.items && cart.items.length > 0 ? cart.items : storeItems;
  const effectiveVertical = selectedVertical || (rawItems.length > 0 ? getItemVertical(rawItems[0]) : 'shopping');
  const checkoutItems = rawItems.filter((i) => getItemVertical(i) === effectiveVertical);

  const [placeOrderMutation, { loading: placingOrder }] = useMutation(PLACE_ORDER, {
    refetchQueries: [{ query: GET_CART }],
    awaitRefetchQueries: true,
    update: (cache) => {
      try {
        if (!selectedVertical || checkoutItems.length === rawItems.length) {
          cache.writeQuery({
            query: GET_CART,
            data: {
              getCart: {
                __typename: 'Cart',
                _id: 'cleared-cart',
                items: [],
                subtotal: 0,
                discount: 0,
                shippingCost: 0,
                tax: 0,
                total: 0,
                couponCode: null,
              },
            },
          });
        }
      } catch (e) {
        console.warn('Cache update error on placeOrder:', e);
      }
    },
    onCompleted: (res) => {
      try {
        if (selectedVertical && checkoutItems.length < rawItems.length) {
          checkoutItems.forEach((item) => {
            const pId = item.product?._id || item._id;
            if (pId) removeItem(pId);
          });
        } else {
          clearCartState();
        }
        const order = res?.placeOrder;
        if (order && (order._id || order.orderNumber)) {
          navigation.replace('OrderSuccess', { orderId: order._id, orderNumber: order.orderNumber });
        } else {
          Alert.alert('Order Placed', 'Your order has been placed successfully!');
          navigation.replace('MainTabs');
        }
      } catch (err) {
        console.error('Order success navigation error:', err);
        navigation.replace('MainTabs');
      }
    },
    onError: (err) => {
      Alert.alert('Checkout Failed', err.message || 'Unable to place order. Please try again.');
    },
  });

  const addresses = meData?.me?.addresses || [];
  const deliveryOptions = deliveryOptionsData?.getDeliveryOptions || [
    { _id: 'std', name: 'Standard Delivery', estimatedDays: '3-5 Business Days', price: 0 },
    { _id: 'exp', name: 'Express Courier', estimatedDays: '1-2 Days', price: 99 },
  ];

  const handlePlaceOrder = () => {
    if (!checkoutItems || checkoutItems.length === 0) {
      Alert.alert('Empty Cart', 'Your cart is empty or has no items for this category.');
      return;
    }

    let addressInput = undefined;
    let shippingAddressId = undefined;

    if (useNewAddress || addresses.length === 0) {
      if (!fullName.trim() || !phone.trim() || !addressLine1.trim() || !city.trim() || !state.trim() || !postalCode.trim()) {
        Alert.alert('Incomplete Address', 'Please fill in all required shipping address fields.');
        return;
      }
      addressInput = {
        fullName: fullName.trim(),
        phone: phone.trim(),
        addressLine1: addressLine1.trim(),
        addressLine2: addressLine2.trim() || undefined,
        city: city.trim(),
        state: state.trim(),
        postalCode: postalCode.trim(),
        country: 'India',
      };
    } else {
      const selected = addresses[selectedAddressIndex];
      if (!selected) {
        Alert.alert('Address Error', 'Please select a valid delivery address.');
        return;
      }
      shippingAddressId = selected._id;
    }

    placeOrderMutation({
      variables: {
        input: {
          paymentMethod,
          shippingAddressId,
          deliveryOptionId: selectedDeliveryOptionId || undefined,
          deliverySlot: initialSlot || undefined,
          notes: instructionsText.trim() || undefined,
          vertical: effectiveVertical,
          saveAsDefault,
        },
        address: addressInput,
      },
    });
  };

  const calculatedSubtotal = checkoutItems.reduce((acc, item) => {
    const price = Number(item.price || item.product?.price || 0);
    const qty = Number(item.quantity || 1);
    return acc + price * qty;
  }, 0);

  const subtotal = checkoutItems.length < rawItems.length
    ? calculatedSubtotal
    : Number(cart?.subtotal || calculatedSubtotal);

  const rawDiscount = Number(cart?.discount || 0);
  const discount = checkoutItems.length < rawItems.length
    ? 0
    : rawDiscount;

  const selectedOption = deliveryOptions.find((o) => o._id === selectedDeliveryOptionId) || deliveryOptions[0];
  const freeThreshold = selectedOption?.minOrderForFree != null && Number(selectedOption.minOrderForFree) > 0
    ? Number(selectedOption.minOrderForFree)
    : 499;
  const isFreeDelivery = subtotal >= freeThreshold;
  const effectiveShipping = isFreeDelivery ? 0 : Number(selectedOption?.price ?? 0);
  const taxableAmount = Math.max(0, subtotal - discount);
  const tax = Math.round((taxableAmount * 0.18) * 100) / 100;
  const total = Math.round((taxableAmount + effectiveShipping + tax) * 100) / 100;

  return (
    <View style={styles.container}>
      <Header title="Checkout" showBack />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Step 1: Shipping Address */}
        <View style={styles.card}>
          <View style={styles.stepHeader}>
            <View style={styles.stepBadge}>
              <Text style={styles.stepBadgeText}>1</Text>
            </View>
            <Text style={styles.stepTitle}>Delivery Destination</Text>
          </View>

          {addresses.length > 0 && !useNewAddress ? (
            <View style={styles.addressList}>
              {addresses.map((addr, idx) => (
                <TouchableOpacity
                  key={addr._id}
                  style={[
                    styles.addressItem,
                    selectedAddressIndex === idx && styles.addressItemActive,
                  ]}
                  onPress={() => setSelectedAddressIndex(idx)}
                >
                  <View style={styles.radio}>
                    {selectedAddressIndex === idx && <View style={styles.radioInner} />}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.addressName}>{addr.fullName}</Text>
                    <Text style={styles.addressSub}>{addr.addressLine1} {addr.addressLine2}</Text>
                    <Text style={styles.addressSub}>
                      {addr.city}, {addr.state} - {addr.postalCode}
                    </Text>
                    <Text style={styles.addressPhone}>📞 {addr.phone}</Text>
                  </View>
                </TouchableOpacity>
              ))}

              <TouchableOpacity
                style={styles.newAddrBtn}
                onPress={() => setUseNewAddress(true)}
              >
                <Ionicons name="add-circle-outline" size={18} color={COLORS.primary} />
                <Text style={styles.newAddrBtnText}>Ship to a Different Address</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.newAddrForm}>
              {addresses.length > 0 && (
                <TouchableOpacity
                  style={styles.savedAddrToggle}
                  onPress={() => setUseNewAddress(false)}
                >
                  <Text style={styles.savedAddrToggleText}>← Choose from Saved Addresses</Text>
                </TouchableOpacity>
              )}

              <Text style={styles.inputLabel}>Full Name *</Text>
              <TextInput
                style={styles.input}
                placeholder="Receiver's name"
                placeholderTextColor={COLORS.textMuted}
                value={fullName}
                onChangeText={setFullName}
              />

              <Text style={styles.inputLabel}>Mobile Phone *</Text>
              <TextInput
                style={styles.input}
                placeholder="+91 98765 43210"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="phone-pad"
                value={phone}
                onChangeText={setPhone}
              />

              <Text style={styles.inputLabel}>Street Address Line 1 *</Text>
              <TextInput
                style={styles.input}
                placeholder="House / Flat / Building No."
                placeholderTextColor={COLORS.textMuted}
                value={addressLine1}
                onChangeText={setAddressLine1}
              />

              <Text style={styles.inputLabel}>Address Line 2 (Optional)</Text>
              <TextInput
                style={styles.input}
                placeholder="Landmark / Area / Colony"
                placeholderTextColor={COLORS.textMuted}
                value={addressLine2}
                onChangeText={setAddressLine2}
              />

              <View style={styles.rowInputs}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.inputLabel}>City *</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Mumbai"
                    placeholderTextColor={COLORS.textMuted}
                    value={city}
                    onChangeText={setCity}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.inputLabel}>State *</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="e.g. Maharashtra"
                    placeholderTextColor={COLORS.textMuted}
                    value={state}
                    onChangeText={setState}
                  />
                </View>
              </View>

              <Text style={styles.inputLabel}>PIN / Postal Code *</Text>
              <TextInput
                style={styles.input}
                placeholder="e.g. 400001"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="number-pad"
                value={postalCode}
                onChangeText={setPostalCode}
              />
            </View>
          )}

          {/* Save Address Option */}
          <TouchableOpacity
            style={{ flexDirection: 'row', alignItems: 'center', marginTop: 12, paddingTop: 10, borderTopWidth: 1, borderTopColor: COLORS.borderLight }}
            onPress={() => setSaveAsDefault(!saveAsDefault)}
            activeOpacity={0.7}
          >
            <Ionicons
              name={saveAsDefault ? 'checkbox' : 'square-outline'}
              size={20}
              color={saveAsDefault ? COLORS.primary : COLORS.textMuted}
            />
            <Text style={{ marginLeft: 8, fontSize: 13, fontWeight: '600', color: COLORS.textDark }}>
              Save as default delivery address
            </Text>
          </TouchableOpacity>
        </View>

        {/* Step 2: Delivery Speed Option */}
        <View style={styles.card}>
          <View style={styles.stepHeader}>
            <View style={styles.stepBadge}>
              <Text style={styles.stepBadgeText}>2</Text>
            </View>
            <Text style={styles.stepTitle}>Delivery Speed</Text>
          </View>

          <View style={styles.deliveryList}>
            {deliveryOptions.map((opt) => {
              const optLimit = opt?.minOrderForFree != null && Number(opt.minOrderForFree) > 0
                ? Number(opt.minOrderForFree)
                : 499;
              const isOptFree = Number(opt.price || 0) === 0 || subtotal >= optLimit;
              return (
                <TouchableOpacity
                  key={opt._id}
                  style={[
                    styles.deliveryItem,
                    selectedDeliveryOptionId === opt._id && styles.deliveryItemActive,
                  ]}
                  onPress={() => setSelectedDeliveryOptionId(opt._id)}
                >
                  <View style={styles.radio}>
                    {selectedDeliveryOptionId === opt._id && <View style={styles.radioInner} />}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.deliveryName}>{opt.name}</Text>
                    <Text style={styles.deliverySub}>Estimated: {opt.estimatedDays}</Text>
                  </View>
                  <Text style={[styles.deliveryPrice, isOptFree && { color: COLORS.success }]}>
                    {isOptFree ? 'FREE' : `₹${opt.price}`}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Step 3: Payment Method */}
        <View style={styles.card}>
          <View style={styles.stepHeader}>
            <View style={styles.stepBadge}>
              <Text style={styles.stepBadgeText}>3</Text>
            </View>
            <Text style={styles.stepTitle}>Payment Method</Text>
          </View>

          <View style={styles.paymentList}>
            {[
              { key: 'cod', label: 'Cash on Delivery (COD)', desc: 'Pay cash / UPI upon package arrival', icon: 'cash-outline' },
              { key: 'stripe', label: 'Credit / Debit Card (Stripe)', desc: 'Instant Visa, MasterCard & RuPay', icon: 'card-outline' },
              { key: 'upi', label: 'UPI / NetBanking', desc: 'Google Pay, PhonePe, Paytm', icon: 'phone-portrait-outline' },
            ].map((p) => (
              <TouchableOpacity
                key={p.key}
                style={[
                  styles.paymentItem,
                  paymentMethod === p.key && styles.paymentItemActive,
                ]}
                onPress={() => setPaymentMethod(p.key)}
              >
                <View style={styles.radio}>
                  {paymentMethod === p.key && <View style={styles.radioInner} />}
                </View>
                <Ionicons name={p.icon} size={22} color={COLORS.primary} style={{ marginRight: 8 }} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.paymentName}>{p.label}</Text>
                  <Text style={styles.paymentSub}>{p.desc}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Step 4: Cooking & Delivery Instructions */}
        <View style={styles.card}>
          <View style={styles.stepHeader}>
            <View style={styles.stepBadge}>
              <Text style={styles.stepBadgeText}>4</Text>
            </View>
            <Text style={styles.stepTitle}>Cooking & Delivery Instructions</Text>
          </View>

          {/* Quick Instruction Chips */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 10 }}>
            <View style={{ flexDirection: 'row', gap: 6 }}>
              {[
                "🚪 Don't ring doorbell",
                "🏠 Leave at gate",
                "🌶️ Less spicy",
                "🍴 Provide cutlery",
                "📞 Call before delivery",
              ].map((chip) => {
                const isAdded = instructionsText.includes(chip);
                return (
                  <TouchableOpacity
                    key={chip}
                    onPress={() => {
                      if (isAdded) {
                        setInstructionsText((prev) => prev.replace(chip, '').replace(/^,\s*|,\s*$/, '').trim());
                      } else {
                        setInstructionsText((prev) => (prev ? `${prev}, ${chip}` : chip));
                      }
                    }}
                    style={{
                      backgroundColor: isAdded ? '#FFEDD5' : '#F8FAFC',
                      borderWidth: 1,
                      borderColor: isAdded ? '#EA580C' : '#E2E8F0',
                      paddingHorizontal: 10,
                      paddingVertical: 6,
                      borderRadius: 16,
                    }}
                  >
                    <Text style={{ fontSize: 11, fontWeight: '700', color: isAdded ? '#C2410C' : '#475569' }}>
                      {chip}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </ScrollView>

          <TextInput
            style={[styles.input, { height: 60, textAlignVertical: 'top', paddingTop: 8 }]}
            placeholder="Add special notes, extra toppings request, or delivery instructions..."
            placeholderTextColor={COLORS.textMuted}
            multiline
            value={instructionsText}
            onChangeText={setInstructionsText}
          />
        </View>

        {/* Step 5: Tax & Final Summary */}
        <View style={styles.card}>
          <Text style={styles.summaryTitle}>Order Bill Breakdown</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Subtotal</Text>
            <Text style={styles.summaryVal}>₹{subtotal.toLocaleString('en-IN')}</Text>
          </View>
          {discount > 0 && (
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: COLORS.success }]}>Discount</Text>
              <Text style={[styles.summaryVal, { color: COLORS.success }]}>-₹{discount.toLocaleString('en-IN')}</Text>
            </View>
          )}
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>GST (18%)</Text>
            <Text style={styles.summaryVal}>₹{tax.toLocaleString('en-IN')}</Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryLabel}>Delivery Fee</Text>
            <Text style={[styles.summaryVal, effectiveShipping === 0 && { color: COLORS.success }]}>
              {effectiveShipping === 0 ? 'FREE' : `₹${effectiveShipping.toLocaleString('en-IN')}`}
            </Text>
          </View>

          <View style={styles.divider} />

          <View style={styles.summaryRow}>
            <Text style={styles.grandTotalLabel}>Total Amount (INR)</Text>
            <Text style={styles.grandTotalVal}>₹{total.toLocaleString('en-IN')}</Text>
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Bottom CTA */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.bottomLabel}>Amount Payable</Text>
          <Text style={styles.bottomTotal}>₹{total.toLocaleString('en-IN')}</Text>
        </View>

        <TouchableOpacity
          style={[styles.placeOrderBtn, placingOrder && styles.disabledBtn]}
          onPress={handlePlaceOrder}
          disabled={placingOrder}
        >
          {placingOrder ? (
            <ActivityIndicator color={COLORS.white} />
          ) : (
            <>
              <Text style={styles.placeOrderBtnText}>Place Order</Text>
              <Ionicons name="shield-checkmark" size={18} color={COLORS.white} />
            </>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scroll: {
    padding: SIZES.padding,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: SIZES.radiusMd,
    padding: 14,
    borderWidth: 1,
    borderColor: COLORS.borderLight,
    marginBottom: 14,
    ...SHADOWS.small,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  stepBadge: {
    width: 24,
    height: 24,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepBadgeText: {
    color: COLORS.white,
    fontSize: SIZES.xs,
    fontWeight: '800',
  },
  stepTitle: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  addressList: {
    gap: 8,
  },
  addressItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 10,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.background,
  },
  addressItemActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  radio: {
    width: 18,
    height: 18,
    borderRadius: SIZES.radiusFull,
    borderWidth: 2,
    borderColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
    marginTop: 2,
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: SIZES.radiusFull,
    backgroundColor: COLORS.primary,
  },
  addressName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  addressSub: {
    fontSize: 11,
    color: COLORS.textSecondary,
    marginTop: 1,
  },
  addressPhone: {
    fontSize: 11,
    color: COLORS.textMuted,
    marginTop: 3,
  },
  newAddrBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    marginTop: 4,
  },
  newAddrBtnText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primary,
  },
  newAddrForm: {
    gap: 8,
  },
  savedAddrToggle: {
    marginBottom: 6,
  },
  savedAddrToggleText: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.primary,
  },
  inputLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.text,
    marginTop: 4,
  },
  input: {
    backgroundColor: COLORS.background,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: SIZES.radiusSm,
    paddingHorizontal: 10,
    height: 40,
    fontSize: SIZES.xs,
    color: COLORS.text,
  },
  rowInputs: {
    flexDirection: 'row',
    gap: 10,
  },
  deliveryList: {
    gap: 8,
  },
  deliveryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.background,
  },
  deliveryItemActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  deliveryName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  deliverySub: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  deliveryPrice: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.text,
  },
  paymentList: {
    gap: 8,
  },
  paymentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: SIZES.radiusSm,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: COLORS.background,
  },
  paymentItemActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primaryLight,
  },
  paymentName: {
    fontSize: SIZES.xs,
    fontWeight: '700',
    color: COLORS.text,
  },
  paymentSub: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  summaryTitle: {
    fontSize: SIZES.xs,
    fontWeight: '800',
    color: COLORS.textSecondary,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 3,
  },
  summaryLabel: {
    fontSize: SIZES.xs,
    color: COLORS.textSecondary,
  },
  summaryVal: {
    fontSize: SIZES.xs,
    fontWeight: '600',
    color: COLORS.text,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.borderLight,
    marginVertical: 8,
  },
  grandTotalLabel: {
    fontSize: SIZES.sm,
    fontWeight: '800',
    color: COLORS.text,
  },
  grandTotalVal: {
    fontSize: SIZES.md,
    fontWeight: '900',
    color: COLORS.primary,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SIZES.padding,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.borderLight,
    ...SHADOWS.medium,
  },
  bottomLabel: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  bottomTotal: {
    fontSize: SIZES.lg,
    fontWeight: '900',
    color: COLORS.text,
  },
  placeOrderBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: SIZES.radiusMd,
    ...SHADOWS.glow,
  },
  placeOrderBtnText: {
    color: COLORS.white,
    fontSize: SIZES.sm,
    fontWeight: '700',
  },
  disabledBtn: {
    opacity: 0.5,
  },
});
