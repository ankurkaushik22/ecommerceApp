import React from 'react';
import { View, Text, ScrollView, StyleSheet, useWindowDimensions } from 'react-native';
import { useQuery } from '@apollo/client';
import { GET_LEGAL_PAGE } from '../../graphql/queries';
import { COLORS, SIZES } from '../../constants/theme';
import Header from '../../components/common/Header';
import LoadingSpinner from '../../components/common/LoadingSpinner';

export default function LegalPageScreen({ route, navigation }) {
  const { slug, title } = route.params;
  const { width } = useWindowDimensions();

  const { data, loading, error } = useQuery(GET_LEGAL_PAGE, {
    variables: { slug },
  });

  if (loading) {
    return (
      <View style={styles.container}>
        <Header title={title || 'Legal Information'} showBack />
        <View style={styles.center}>
          <LoadingSpinner />
        </View>
      </View>
    );
  }

  if (error || !data?.getLegalPage) {
    return (
      <View style={styles.container}>
        <Header title={title || 'Legal Information'} showBack />
        <View style={styles.center}>
          <Text style={styles.errorText}>Failed to load content.</Text>
        </View>
      </View>
    );
  }

  const page = data.getLegalPage;
  const cleanContent = page.content.replace(/<[^>]*>/g, '\n').replace(/\n\s*\n/g, '\n\n').trim();

  return (
    <View style={styles.container}>
      <Header title={page.title || title} showBack />
      <ScrollView contentContainerStyle={styles.scroll}>
        {page.updatedAt && (
          <Text style={styles.dateText}>
            Last updated: {new Date(parseInt(page.updatedAt) || page.updatedAt).toLocaleDateString()}
          </Text>
        )}
        <Text style={styles.contentText}>{cleanContent}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scroll: {
    padding: SIZES.padding,
    paddingBottom: 40,
  },
  errorText: {
    color: COLORS.danger,
    fontSize: SIZES.md,
  },
  dateText: {
    fontSize: SIZES.sm,
    color: COLORS.textSecondary,
    marginBottom: SIZES.padding,
  },
  contentText: {
    fontSize: SIZES.md,
    color: COLORS.text,
    lineHeight: 24,
  },
});
