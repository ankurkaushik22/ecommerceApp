import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  ActivityIndicator,
  Alert,
  Dimensions,
  Platform,
  StatusBar,
  Vibration,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery, useMutation } from '@apollo/client';
import { GET_CART, GET_ME, GET_NOTIFICATIONS } from '../../graphql/queries';
import {
  UPDATE_CART_ITEM,
  REMOVE_FROM_CART,
  APPLY_COUPON,
  REMOVE_COUPON,
} from '../../graphql/mutations';
import { useCartStore } from '../../store/cartStore';
import { useAuthStore } from '../../store/authStore';
import { COLORS, SIZES, SHADOWS } from '../../constants/theme';

const { width } = Dimensions.get('window');

const DELIVERY_SLOTS = [
  { id: 'today-3-5', day: 'Today', time: '3PM - 5PM', label: 'Today: 3PM - 5PM' },
  { id: 'tomorrow-9-11', day: 'Tomorrow', time: '9AM - 11AM', label: 'Tomorrow: 9AM - 11AM' },
  { id: 'tomorrow-5-7', day: 'Tomorrow', time: '5PM - 7PM', label: 'Tomorrow: 5PM - 7PM' },
];

export default function CartScreen({ route, navigation }) {
  const insets = useSafeAreaInsets();
  const [couponCode, setCouponCode] = useState('');
  const [activeVertical, setActiveVertical] = useState(route.params?.vertical || 'shopping');
  const [selectedSlot, setSelectedSlot] = useState(DELIVERY_SLOTS[0]);

  const setCart = useCartStore((s) => s.setCart);
  const { user, isAuthenticated } = useAuthStore();

  const { data: meData } = useQuery(GET_ME, { skip: !isAuthenticated });
  const { data: notifData } = useQuery(GET_NOTIFICATIONS, { skip: !isAuthenticated, pollInterval: 30000 });
  const unreadCount = (notifData?.getNotifications || []).filter((n) => !n.isRead).length;

  const { data, loading } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
    onCompleted: (res) => {
      if (res.getCart) setCart(res.getCart);
    },
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: (res) => {
      setCart(res.updateCartItem);
      Vibration.vibrate(40);
    },
    onError: (e) => Alert.alert('Error', e.message),
  });

  const [removeFromCart] = useMutation(REMOVE_FROM_CART, {
    onCompleted: (res) => {
      setCart(res.removeFromCart);
      Vibration.vibrate(60);
    },
    onError: (e) => Alert.alert('Error', e.message),
  });

  const [applyCoupon, { loading: applyingCoupon }] = useMutation(APPLY_COUPON, {
    onCompleted: (res) => {
      setCart(res.applyCoupon);
      Vibration.vibrate(60);
      Alert.alert('Coupon Applied', `Code ${couponCode.toUpperCase()} applied successfully!`);
      setCouponCode('');
    },
    onError: (e) => Alert.alert('Coupon Error', e.message),
  });

  const [removeCoupon, { loading: removingCoupon }] = useMutation(REMOVE_COUPON, {
    onCompleted: (res) => {
      setCart(res.removeCoupon);
      Alert.alert('Coupon Removed', 'Promo discount has been removed.');
    },
    onError: (e) => Alert.alert('Coupon Error', e.message),
  });

  const storeItems = useCartStore((s) => s.items) || [];
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeItem = useCartStore((s) => s.removeItem);

  React.useEffect(() => {
    if (route.params?.vertical) {
      setActiveVertical(route.params.vertical);
    }
  }, [route.params?.vertical]);

  const currentUser = meData?.me || user;
  const currentAddress = currentUser?.addresses?.find((a) => a.isDefault) || currentUser?.addresses?.[0] || {
    addressLine1: '123 Maple St',
  };

  const statusBarHeight = Platform.OS === 'android' ? (StatusBar.currentHeight || 28) : 0;
  const topPadding = Platform.OS === 'web' ? 16 : Math.max(insets.top, statusBarHeight, 24) + 6;

  if (!isAuthenticated) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: topPadding }]}>
          <Text style={styles.logoText}>S U A A K A</Text>
        </View>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyEmoji}>🛒</Text>
          <Text style={styles.emptyTitle}>Sign in to view your Cart</Text>
          <Text style={styles.emptySub}>
            Sign in to sync your saved cart items across mobile & web.
          </Text>
          <TouchableOpacity
            style={styles.signInBtn}
            onPress={() => navigation.navigate('Login', { redirect: 'CartTab' })}
          >
            <Text style={styles.signInBtnText}>Sign In Now</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const cart = data?.getCart;
  const backendItems = cart?.items || [];
  const items = backendItems.length > 0 ? backendItems : storeItems;

  if (loading && !cart && storeItems.length === 0) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: topPadding }]}>
          <Text style={styles.logoText}>S U A A K A</Text>
        </View>
        <View style={styles.emptyContainer}>
          <ActivityIndicator size="large" color="#059669" />
          <Text style={styles.emptySub}>Loading your cart...</Text>
        </View>
      </View>
    );
  }

  const getItemVertical = (item) => {
    if (item.vertical && item.vertical !== 'shopping') return item.vertical;
    if (item.product?.vertical && item.product.vertical !== 'shopping') return item.product.vertical;
    if (item.vertical) return item.vertical;
    if (item.product?.vertical) return item.product.vertical;

    const name = (item.name || item.product?.name || '').toLowerCase();
    const cat = (item.category?.name || item.product?.category?.name || item.category?.slug || '').toLowerCase();

    if (cat.includes('food') || cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') ||
        name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('tikka') || name.includes('momo') || name.includes('shake') || name.includes('wrap') || name.includes('roll') || name.includes('thali')) {
      return 'food';
    }
    if (cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') ||
        name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('paneer') || name.includes('bread') || name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') || name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') || name.includes('apple') || name.includes('avocado') || name.includes('spinach') || name.includes('carrot') || name.includes('strawberry')) {
      return 'grocery';
    }
    return 'shopping';
  };

  // Filter items by vertical bucket
  const shoppingItems = items.filter((i) => getItemVertical(i) === 'shopping');
  const foodItems = items.filter((i) => getItemVertical(i) === 'food');
  const groceryItems = items.filter((i) => getItemVertical(i) === 'grocery');
  const servicesItems = items.filter((i) => getItemVertical(i) === 'services');

  const displayItems = activeVertical === 'food'
    ? foodItems
    : activeVertical === 'grocery'
    ? groceryItems
    : activeVertical === 'services'
    ? servicesItems
    : shoppingItems;

  const subtotal = displayItems.reduce((sum, i) => sum + (Number(i.price || i.product?.price || 0) * (i.quantity || 1)), 0);
  const discount = Number(cart?.discount || 0);
  const shippingCost = Number(subtotal > 499 || subtotal === 0 ? 0 : 49);
  const total = Math.max(0, subtotal - discount + shippingCost);

  return (
    <View style={styles.container}>
      {/* Top Header matching reference Image 4 */}
      <View style={[styles.header, { paddingTop: topPadding }]}>
        <TouchableOpacity
          style={styles.addressRow}
          onPress={() => navigation.navigate('Addresses')}
          activeOpacity={0.8}
        >
          <Ionicons name="location-sharp" size={18} color="#059669" />
        </TouchableOpacity>

        <View style={styles.logoWrap}>
          <Image
            source={require('../../../assets/logo.png')}
            style={{ width: 44, height: 44, borderRadius: 8 }}
            resizeMode="contain"
          />
        </View>

        <TouchableOpacity
          style={styles.headerBtn}
          onPress={() => navigation.navigate('Notifications')}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <Ionicons name="notifications-outline" size={22} color="#0F172A" />
          {unreadCount > 0 && (
            <View style={styles.notifBadge}>
              <Text style={styles.notifBadgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Main Title & Vertical Tabs */}
        <Text style={styles.mainTitle}>Your Cart</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 8, marginBottom: 16 }}>
          <TouchableOpacity
            style={[styles.verticalTab, activeVertical === 'shopping' && styles.verticalTabActive]}
            onPress={() => setActiveVertical('shopping')}
          >
            <Ionicons name="bag-handle-outline" size={15} color={activeVertical === 'shopping' ? '#FFF' : '#475569'} />
            <Text style={[styles.verticalTabText, activeVertical === 'shopping' && styles.verticalTabTextActive]}>
              Shopping ({shoppingItems.length})
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.verticalTab, activeVertical === 'food' && styles.verticalTabActiveFood]}
            onPress={() => setActiveVertical('food')}
          >
            <Ionicons name="restaurant-outline" size={15} color={activeVertical === 'food' ? '#FFF' : '#475569'} />
            <Text style={[styles.verticalTabText, activeVertical === 'food' && styles.verticalTabTextActive]}>
              Food ({foodItems.length})
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.verticalTab, activeVertical === 'grocery' && styles.verticalTabActiveGrocery]}
            onPress={() => setActiveVertical('grocery')}
          >
            <Ionicons name="leaf-outline" size={15} color={activeVertical === 'grocery' ? '#FFF' : '#475569'} />
            <Text style={[styles.verticalTabText, activeVertical === 'grocery' && styles.verticalTabTextActive]}>
              Grocery ({groceryItems.length})
            </Text>
          </TouchableOpacity>

          {servicesItems.length > 0 && (
            <TouchableOpacity
              style={[styles.verticalTab, activeVertical === 'services' && styles.verticalTabActive]}
              onPress={() => setActiveVertical('services')}
            >
              <Ionicons name="construct-outline" size={15} color={activeVertical === 'services' ? '#FFF' : '#475569'} />
              <Text style={[styles.verticalTabText, activeVertical === 'services' && styles.verticalTabTextActive]}>
                Services ({servicesItems.length})
              </Text>
            </TouchableOpacity>
          )}
        </ScrollView>

        {/* Cart Items List */}
        <View style={styles.itemsList}>
          {displayItems.length === 0 ? (
            <View style={styles.emptyCardBox}>
              <Text style={styles.emptyCardEmoji}>🛒</Text>
              <Text style={styles.emptyCardTitle}>
                Your {activeVertical.charAt(0).toUpperCase() + activeVertical.slice(1)} Cart is empty
              </Text>
              <Text style={styles.emptyCardSub}>
                Explore items in our {activeVertical} store and add them to your cart.
              </Text>
              <TouchableOpacity
                style={styles.browseBtn}
                onPress={() => {
                  if (activeVertical === 'food') navigation.navigate('FoodHome');
                  else if (activeVertical === 'grocery') navigation.navigate('GroceryHome');
                  else navigation.navigate('ShoppingMall');
                }}
              >
                <Text style={styles.browseBtnText}>
                  Explore {activeVertical.charAt(0).toUpperCase() + activeVertical.slice(1)}
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            displayItems.map((item) => {
              const itemName = item.product?.name || item.name || 'Product Item';
              const itemImage =
                item.image ||
                item.product?.images?.[0] ||
                'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=300';
              const itemPrice = Number(item.price || item.product?.price || 0);
              const itemTotal = (itemPrice * (item.quantity || 1)).toFixed(2);
              const itemIdKey = item._id || item.productId || `item-${Math.random()}`;

              return (
                <View key={itemIdKey} style={styles.itemCard}>
                  {/* Product Image */}
                  <View style={styles.itemImageWrap}>
                    <Image
                      source={{ uri: itemImage }}
                      style={styles.itemImage}
                      resizeMode="contain"
                    />
                  </View>

                  {/* Item Details */}
                  <View style={styles.itemInfo}>
                    <Text style={styles.itemName} numberOfLines={2}>
                      {itemName}
                    </Text>
                    {item.variantLabel ? (
                      <Text style={{ fontSize: 11, color: '#059669', fontWeight: '600', marginTop: 2 }}>
                        {item.variantLabel}
                      </Text>
                    ) : null}
                    <Text style={styles.itemUnit}>
                      ₹{itemPrice.toLocaleString('en-IN')}{' '}
                      {item.product?.unitMeasure ? `/ ${item.product.unitMeasure}` : ''}
                    </Text>
                  </View>

                  {/* Right: Total Price & Stepper */}
                  <View style={styles.itemRightCol}>
                    <Text style={styles.itemTotalPrice}>₹{Number(itemTotal).toLocaleString('en-IN')}</Text>
                    <View style={styles.stepperPill}>
                      <TouchableOpacity
                        style={styles.stepperBtn}
                        onPress={() => {
                          const idToPass = item.productId || item.product?._id || item._id;
                          if (item.quantity <= 1) {
                            removeItem(idToPass);
                            if (isAuthenticated && item._id && !item._id.startsWith('temp-')) {
                              removeFromCart({ variables: { itemId: item._id } });
                            }
                          } else {
                            updateQuantity(idToPass, item.quantity - 1);
                            if (isAuthenticated && item._id && !item._id.startsWith('temp-')) {
                              updateCartItem({ variables: { itemId: item._id, quantity: item.quantity - 1 } });
                            }
                          }
                        }}
                      >
                        <Ionicons
                          name={item.quantity <= 1 ? 'trash-outline' : 'remove'}
                          size={14}
                          color="#0F172A"
                        />
                      </TouchableOpacity>
                      <Text style={styles.stepperQty}>{item.quantity}</Text>
                      <TouchableOpacity
                        style={styles.stepperBtn}
                        onPress={() => {
                          const idToPass = item.productId || item.product?._id || item._id;
                          updateQuantity(idToPass, item.quantity + 1);
                          if (isAuthenticated && item._id && !item._id.startsWith('temp-')) {
                            updateCartItem({ variables: { itemId: item._id, quantity: item.quantity + 1 } });
                          }
                        }}
                      >
                        <Ionicons name="add" size={14} color="#059669" />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              );
            })
          )}
        </View>

        {displayItems.length > 0 && (
          <>
            {/* Promo Code Input Box matching Image 4 */}
            <View style={styles.sectionWrap}>
              {cart?.couponCode ? (
                <View style={styles.appliedPromoBox}>
                  <View style={styles.appliedPromoLeft}>
                    <Ionicons name="pricetag" size={18} color="#059669" />
                    <View>
                      <Text style={styles.appliedCodeText}>{cart.couponCode.toUpperCase()}</Text>
                      <Text style={styles.appliedDescText}>Promo applied to your order</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    onPress={() => removeCoupon()}
                    disabled={removingCoupon}
                    hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  >
                    <Text style={styles.removePromoBtn}>Remove</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <View style={styles.promoInputBox}>
                  <Ionicons name="pricetag-outline" size={18} color="#64748B" style={styles.promoIcon} />
                  <TextInput
                    style={styles.promoInput}
                    placeholder="Promo Code"
                    placeholderTextColor="#94A3B8"
                    autoCapitalize="characters"
                    value={couponCode}
                    onChangeText={setCouponCode}
                  />
                  <TouchableOpacity
                    style={styles.promoApplyBtn}
                    onPress={() => {
                      if (couponCode.trim()) {
                        applyCoupon({ variables: { code: couponCode.trim().toUpperCase() } });
                      }
                    }}
                    disabled={!couponCode.trim() || applyingCoupon}
                  >
                    {applyingCoupon ? (
                      <ActivityIndicator size="small" color="#059669" />
                    ) : (
                      <Text
                        style={[
                          styles.promoApplyText,
                          !couponCode.trim() && { opacity: 0.5 },
                        ]}
                      >
                        Apply
                      </Text>
                    )}
                  </TouchableOpacity>
                </View>
              )}
            </View>

            {/* Order Bill Summary matching Image 4 */}
            <View style={styles.summaryCard}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>₹{subtotal.toLocaleString('en-IN')}</Text>
              </View>

              {discount > 0 && (
                <View style={styles.summaryRow}>
                  <Text style={[styles.summaryLabel, { color: '#059669' }]}>Promo Discount</Text>
                  <Text style={[styles.summaryValue, { color: '#059669' }]}>
                    -₹{discount.toLocaleString('en-IN')}
                  </Text>
                </View>
              )}

              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Delivery Fee</Text>
                <Text style={[styles.summaryValue, shippingCost === 0 && { color: '#059669' }]}>
                  {shippingCost === 0 ? 'FREE' : `₹${shippingCost.toLocaleString('en-IN')}`}
                </Text>
              </View>

              <View style={styles.summaryDivider} />

              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>₹{total.toLocaleString('en-IN')}</Text>
              </View>
            </View>
          </>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Sticky Bottom Proceed to Checkout CTA matching Image 4 */}
      {displayItems.length > 0 && (
        <View style={[styles.bottomCtaBar, { paddingBottom: Math.max(insets.bottom, 14) }]}>
          <TouchableOpacity
            style={styles.checkoutBtn}
            activeOpacity={0.88}
            onPress={() =>
              navigation.navigate('Checkout', {
                deliverySlot: selectedSlot.label,
                vertical: activeVertical,
              })
            }
          >
            <Text style={styles.checkoutBtnText}>Proceed to Checkout</Text>
            <Ionicons name="arrow-forward" size={18} color={COLORS.white} style={{ marginLeft: 6 }} />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  addressRow: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoText: {
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 2,
    color: '#0F172A',
  },
  headerBtn: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#EF4444',
    borderRadius: 8,
    minWidth: 16,
    height: 16,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  notifBadgeText: {
    color: COLORS.white,
    fontSize: 9,
    fontWeight: 'bold',
  },
  scroll: {
    paddingBottom: 40,
  },
  mainTitle: {
    fontSize: 22,
    fontWeight: '900',
    color: '#0F172A',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
  },
  itemsList: {
    paddingHorizontal: 16,
    gap: 12,
  },
  itemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 18,
    padding: 12,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    ...SHADOWS.small,
  },
  itemImageWrap: {
    width: 65,
    height: 65,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  itemImage: {
    width: '100%',
    height: '100%',
  },
  itemInfo: {
    flex: 1,
    marginLeft: 12,
    justifyContent: 'center',
  },
  itemName: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
    lineHeight: 18,
  },
  itemUnit: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 4,
    fontWeight: '600',
  },
  itemRightCol: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 55,
  },
  itemTotalPrice: {
    fontSize: 15,
    fontWeight: '900',
    color: '#0F172A',
  },
  stepperPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    borderRadius: 16,
    paddingHorizontal: 6,
    paddingVertical: 2,
    gap: 8,
  },
  stepperBtn: {
    width: 22,
    height: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepperQty: {
    fontSize: 13,
    fontWeight: '800',
    color: '#0F172A',
  },
  sectionWrap: {
    paddingHorizontal: 16,
    marginTop: 20,
  },
  sectionHeader: {
    fontSize: 14,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 10,
  },
  slotsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  slotCard: {
    flex: 1,
    backgroundColor: COLORS.white,
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotCardActive: {
    borderColor: '#059669',
    backgroundColor: '#F0FDF4',
  },
  slotTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 4,
  },
  slotDayText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#334155',
  },
  slotDayTextActive: {
    color: '#059669',
    fontWeight: '800',
  },
  slotTimeText: {
    fontSize: 11,
    color: '#64748B',
    fontWeight: '600',
  },
  slotTimeTextActive: {
    color: '#059669',
    fontWeight: '700',
  },
  promoInputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: '#E2E8F0',
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  promoIcon: {
    marginRight: 10,
  },
  promoInput: {
    flex: 1,
    fontSize: 14,
    color: '#0F172A',
    fontWeight: '600',
  },
  promoApplyBtn: {
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  promoApplyText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#059669',
  },
  appliedPromoBox: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#F0FDF4',
    borderWidth: 1,
    borderColor: '#BBF7D0',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  appliedPromoLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  appliedCodeText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#059669',
  },
  appliedDescText: {
    fontSize: 11,
    color: '#64748B',
  },
  removePromoBtn: {
    fontSize: 12,
    fontWeight: '700',
    color: '#EF4444',
  },
  summaryCard: {
    marginHorizontal: 16,
    marginTop: 20,
    backgroundColor: COLORS.white,
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    ...SHADOWS.small,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 13,
    color: '#64748B',
    fontWeight: '600',
  },
  summaryValue: {
    fontSize: 13,
    color: '#0F172A',
    fontWeight: '700',
  },
  summaryDivider: {
    height: 1,
    backgroundColor: '#F1F5F9',
    marginVertical: 10,
  },
  totalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '900',
    color: '#0F172A',
  },
  totalValue: {
    fontSize: 20,
    fontWeight: '900',
    color: '#0F172A',
  },
  bottomCtaBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: COLORS.white,
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    ...SHADOWS.medium,
  },
  checkoutBtn: {
    flexDirection: 'row',
    backgroundColor: '#059669',
    borderRadius: 14,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    ...SHADOWS.small,
  },
  checkoutBtnText: {
    color: COLORS.white,
    fontSize: 15,
    fontWeight: '800',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  emptyEmoji: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 8,
  },
  emptySub: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 19,
    marginBottom: 24,
  },
  signInBtn: {
    backgroundColor: '#059669',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  signInBtnText: {
    color: COLORS.white,
    fontWeight: '800',
    fontSize: 14,
  },
  browseBtn: {
    backgroundColor: '#059669',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  browseBtnText: {
    color: COLORS.white,
    fontWeight: '800',
    fontSize: 14,
  },
  verticalTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F1F5F9',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 6,
  },
  verticalTabActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  verticalTabActiveFood: {
    backgroundColor: '#EA580C',
    borderColor: '#EA580C',
  },
  verticalTabActiveGrocery: {
    backgroundColor: '#059669',
    borderColor: '#059669',
  },
  verticalTabText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
  },
  verticalTabTextActive: {
    color: '#FFF',
  },
  emptyCardBox: {
    padding: 24,
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 20,
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: '#F1F5F9',
    ...SHADOWS.small,
  },
  emptyCardEmoji: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyCardTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#0F172A',
    marginBottom: 6,
  },
  emptyCardSub: {
    fontSize: 13,
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 16,
  },
});
