import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const useWishlistStore = create((set, get) => ({
  items: [],

  loadWishlist: async () => {
    try {
      const data = await AsyncStorage.getItem('user_wishlist');
      if (data) {
        set({ items: JSON.parse(data) });
      }
    } catch (e) {}
  },

  toggleWishlist: async (product) => {
    const current = get().items;
    const exists = current.some((item) => item._id === product._id);
    let updated;
    if (exists) {
      updated = current.filter((item) => item._id !== product._id);
    } else {
      updated = [...current, product];
    }
    set({ items: updated });
    try {
      await AsyncStorage.setItem('user_wishlist', JSON.stringify(updated));
    } catch (e) {}
  },

  isInWishlist: (productId) => {
    return get().items.some((item) => item._id === productId);
  },

  removeFromWishlist: async (productId) => {
    const updated = get().items.filter((item) => item._id !== productId);
    set({ items: updated });
    try {
      await AsyncStorage.setItem('user_wishlist', JSON.stringify(updated));
    } catch (e) {}
  },
}));
