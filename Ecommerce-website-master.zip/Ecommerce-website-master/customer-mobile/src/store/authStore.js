import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

const decodeJwtPayload = (token) => {
  try {
    if (!token || typeof token !== 'string') return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let str = base64.replace(/=+$/, '');
    let output = '';
    for (
      let bc = 0, bs = 0, buffer, idx = 0;
      (buffer = str.charAt(idx++));
      ~buffer && ((bs = bc % 4 ? bs * 64 + buffer : buffer), bc++ % 4)
        ? (output += String.fromCharCode(255 & (bs >> ((-2 * bc) & 6))))
        : 0
    ) {
      buffer = chars.indexOf(buffer);
    }
    return JSON.parse(output);
  } catch (e) {
    return null;
  }
};

export const useAuthStore = create((set, get) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  isLoading: true,

  setAuth: async (user, token) => {
    try {
      if (token) await AsyncStorage.setItem('auth_token', token);
      if (user) await AsyncStorage.setItem('auth_user', JSON.stringify(user));
      set({ user, token, isAuthenticated: !!token, isLoading: false });
    } catch (e) {
      console.error('Error saving auth to storage', e);
    }
  },

  logout: async () => {
    try {
      await AsyncStorage.removeItem('auth_token');
      await AsyncStorage.removeItem('auth_user');
      set({ user: null, token: null, isAuthenticated: false, isLoading: false });
    } catch (e) {
      console.error('Error clearing auth storage', e);
    }
  },

  restoreAuth: async () => {
    try {
      const token = await AsyncStorage.getItem('auth_token');
      const userJson = await AsyncStorage.getItem('auth_user');
      if (token && userJson) {
        // Proactively check if token is expired
        const payload = decodeJwtPayload(token);
        if (payload && payload.exp && payload.exp * 1000 < Date.now()) {
          await AsyncStorage.removeItem('auth_token');
          await AsyncStorage.removeItem('auth_user');
          set({ token: null, user: null, isAuthenticated: false, isLoading: false });
          return;
        }
        const user = JSON.parse(userJson);
        set({
          token,
          user,
          isAuthenticated: true,
          isLoading: false,
        });
      } else {
        set({ token: null, user: null, isAuthenticated: false, isLoading: false });
      }
    } catch (e) {
      set({ token: null, user: null, isAuthenticated: false, isLoading: false });
    }
  },

  updateUser: (updatedFields) => {
    const currentUser = get().user;
    if (currentUser) {
      const newUser = { ...currentUser, ...updatedFields };
      AsyncStorage.setItem('auth_user', JSON.stringify(newUser)).catch(() => {});
      set({ user: newUser });
    }
  },
}));
