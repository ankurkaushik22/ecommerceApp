import { create } from 'zustand';
import { Vibration } from 'react-native';

export const useCartStore = create((set, get) => ({
  cart: null,
  items: [],
  itemCount: 0,

  setCart: (cartData) => {
    const rawItems = cartData?.items || [];
    const count = rawItems.reduce((acc, item) => acc + (item?.quantity || 0), 0);
    set({ cart: cartData, items: rawItems, itemCount: count });
  },

  addItem: (product, qty = 1) => {
    const currentItems = get().items || [];
    const prodId = product._id || product.id || product.productId;
    const vertical = product.vertical || product.category?.vertical || 'shopping';

    const existingIndex = currentItems.findIndex(
      (i) => (i.product?._id || i.productId || i._id) === prodId
    );

    let updated;
    if (existingIndex > -1) {
      updated = currentItems.map((item, idx) =>
        idx === existingIndex
          ? {
              ...item,
              quantity: (item.quantity || 0) + qty,
              vertical: item.vertical || vertical,
              product: { ...(item.product || product), vertical: item.product?.vertical || vertical },
            }
          : item
      );
    } else {
      const formattedProd = { ...product, vertical };
      updated = [
        ...currentItems,
        {
          _id: `temp-${Date.now()}`,
          product: formattedProd,
          productId: prodId,
          quantity: qty,
          price: product.price || 0,
          vertical,
        },
      ];
    }

    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
    try {
      Vibration.vibrate(60);
    } catch {}
  },

  updateQuantity: (productId, newQty) => {
    const currentItems = get().items || [];
    let updated;
    if (newQty <= 0) {
      updated = currentItems.filter(
        (i) => (i.product?._id || i.productId || i._id) !== productId
      );
    } else {
      updated = currentItems.map((item) =>
        (item.product?._id || item.productId || item._id) === productId
          ? { ...item, quantity: newQty }
          : item
      );
    }
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
  },

  removeItem: (productId) => {
    const currentItems = get().items || [];
    const updated = currentItems.filter(
      (i) => (i.product?._id || i.productId || i._id) !== productId
    );
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
  },

  clearCartState: () => {
    set({ cart: null, items: [], itemCount: 0 });
  },
}));
