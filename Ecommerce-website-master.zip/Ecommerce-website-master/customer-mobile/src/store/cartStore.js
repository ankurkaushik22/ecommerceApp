import { create } from 'zustand';
import { Vibration } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LOCAL_CART_KEY = 'customer_mobile_guest_cart';

const saveItemsToStorage = async (items) => {
  try {
    if (!items || items.length === 0) {
      await AsyncStorage.removeItem(LOCAL_CART_KEY);
    } else {
      await AsyncStorage.setItem(LOCAL_CART_KEY, JSON.stringify(items));
    }
  } catch (e) {}
};

export const useCartStore = create((set, get) => ({
  cart: null,
  items: [],
  itemCount: 0,

  restoreCartFromStorage: async () => {
    try {
      const raw = await AsyncStorage.getItem(LOCAL_CART_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0 && (get().items || []).length === 0) {
          const count = parsed.reduce((acc, item) => acc + (item?.quantity || 0), 0);
          set({ items: parsed, itemCount: count });
        }
      }
    } catch (e) {}
  },

  setCart: (cartData) => {
    const rawItems = cartData?.items || [];
    const count = rawItems.reduce((acc, item) => acc + (item?.quantity || 0), 0);
    set({ cart: cartData, items: rawItems, itemCount: count });
    saveItemsToStorage(rawItems);
  },

  addItem: (product, qty = 1) => {
    const currentItems = get().items || [];
    const prodId = product._id || product.id || product.productId;
    const vertical = product.vertical || product.category?.vertical || 'shopping';

    const getAddonsKey = (p) => (p?.addons || []).map(a => a.name).sort().join('|');
    const pAddonsKey = getAddonsKey(product);
    const pInstructions = (product.instructions || '').trim();
    const pVariant = (product.variantLabel || product.selectedVariant?.label || product.selectedVariantOption?.label || product.selectedVariantOption?.name || '').trim();

    const existingIndex = currentItems.findIndex((i) => {
      const iProdId = i.product?._id || i.productId || i._id;
      const iAddonsKey = getAddonsKey(i.product || i);
      const iInstructions = (i.instructions || i.product?.instructions || '').trim();
      const iVariant = (i.variantLabel || i.selectedVariant?.label || i.product?.variantLabel || i.selectedVariantOption?.label || i.selectedVariantOption?.name || '').trim();
      return iProdId === prodId && iAddonsKey === pAddonsKey && iInstructions === pInstructions && iVariant === pVariant;
    });

    let updated;
    if (existingIndex > -1) {
      updated = currentItems.map((item, idx) =>
        idx === existingIndex
          ? {
              ...item,
              quantity: (item.quantity || 0) + qty,
              price: product.price || item.price,
              vertical: item.vertical || vertical,
              product: { ...product, vertical },
            }
          : item
      );
    } else {
      const formattedProd = { ...product, vertical };
      updated = [
        ...currentItems,
        {
          _id: `temp-${Date.now()}`,
          product: formattedProd,
          productId: prodId,
          quantity: qty,
          price: product.price || 0,
          addons: product.addons || [],
          instructions: pInstructions,
          variantLabel: pVariant,
          variantIndex: product.variantIndex ?? -1,
          vertical,
        },
      ];
    }

    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
    saveItemsToStorage(updated);
    try {
      Vibration.vibrate(60);
    } catch {}
  },

  updateQuantity: (itemId, newQty) => {
    const currentItems = get().items || [];
    let updated;
    if (newQty <= 0) {
      updated = currentItems.filter(
        (i) => i._id !== itemId && i.product?._id !== itemId && i.productId !== itemId
      );
    } else {
      updated = currentItems.map((item) =>
        (item._id === itemId || item.product?._id === itemId || item.productId === itemId)
          ? { ...item, quantity: newQty }
          : item
      );
    }
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
    saveItemsToStorage(updated);
  },

  removeItem: (itemId) => {
    const currentItems = get().items || [];
    const updated = currentItems.filter(
      (i) => i._id !== itemId && i.product?._id !== itemId && i.productId !== itemId
    );
    const count = updated.reduce((acc, item) => acc + (item.quantity || 0), 0);
    set({ items: updated, itemCount: count });
    saveItemsToStorage(updated);
  },

  clearCartState: () => {
    set({ cart: null, items: [], itemCount: 0 });
    saveItemsToStorage([]);
  },
}));
