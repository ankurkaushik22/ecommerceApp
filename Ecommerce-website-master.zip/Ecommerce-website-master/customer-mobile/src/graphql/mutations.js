import { gql } from '@apollo/client';

export const LOGIN_MUTATION = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        role
        avatar
        phone
        permissions
      }
    }
  }
`;

export const REGISTER_MUTATION = gql`
  mutation Register($input: RegisterInput!) {
    register(input: $input) {
      token
      refreshToken
      user {
        _id
        name
        email
        role
      }
    }
  }
`;

export const FORGOT_PASSWORD_MUTATION = gql`
  mutation ForgotPassword($email: String!) {
    forgotPassword(email: $email) {
      success
      message
    }
  }
`;

export const RESET_PASSWORD_MUTATION = gql`
  mutation ResetPassword($token: String!, $newPassword: String!) {
    resetPassword(token: $token, newPassword: $newPassword) {
      success
      message
    }
  }
`;

export const ADD_TO_CART = gql`
  mutation AddToCart($input: CartItemInput!) {
    addToCart(input: $input) {
      _id
      items {
        _id
        product {
          _id
          name
          slug
          price
          images
          stock
        }
        quantity
        price
        variantIndex
      }
      subtotal
      discount
      shippingCost
      tax
      total
    }
  }
`;

export const SYNC_CART = gql`
  mutation SyncCart($items: [CartItemInput!]!) {
    syncCart(items: $items) {
      _id
      items {
        _id
        product {
          _id
          name
          slug
          price
          images
          stock
        }
        quantity
        price
        variantIndex
      }
      subtotal
      discount
      shippingCost
      tax
      total
    }
  }
`;

export const UPDATE_CART_ITEM = gql`
  mutation UpdateCartItem($itemId: ID!, $quantity: Int!) {
    updateCartItem(itemId: $itemId, quantity: $quantity) {
      _id
      items {
        _id
        product {
          _id
          name
          slug
          price
          images
          stock
        }
        quantity
        price
        variantIndex
      }
      subtotal
      discount
      shippingCost
      tax
      total
    }
  }
`;

export const REMOVE_FROM_CART = gql`
  mutation RemoveFromCart($itemId: ID!) {
    removeFromCart(itemId: $itemId) {
      _id
      items {
        _id
        product {
          _id
          name
          slug
          price
          images
          stock
        }
        quantity
        price
        variantIndex
      }
      subtotal
      discount
      shippingCost
      tax
      total
    }
  }
`;

export const CLEAR_CART = gql`
  mutation ClearCart {
    clearCart {
      _id
      items {
        _id
      }
      subtotal
      total
    }
  }
`;

export const APPLY_COUPON = gql`
  mutation ApplyCoupon($code: String!) {
    applyCoupon(code: $code) {
      _id
      discount
      total
      couponCode
    }
  }
`;

export const REMOVE_COUPON = gql`
  mutation RemoveCoupon {
    removeCoupon {
      _id
      discount
      total
      couponCode
    }
  }
`;

export const PLACE_ORDER = gql`
  mutation PlaceOrder($input: PlaceOrderInput!, $address: OrderAddressInput) {
    placeOrder(input: $input, address: $address) {
      _id
      orderNumber
      invoiceNumber
      status
      deliverySlot
      total
      subtotal
      discount
      shippingCost
      tax
      createdAt
      items {
        name
        price
        quantity
        image
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        city
        state
        postalCode
      }
    }
  }
`;

export const CANCEL_ORDER = gql`
  mutation CancelOrder($orderId: ID!, $reason: String) {
    cancelOrder(orderId: $orderId, reason: $reason) {
      _id
      orderNumber
      status
      cancelReason
    }
  }
`;

export const ADD_REVIEW = gql`
  mutation AddReview($input: ReviewInput!) {
    addReview(input: $input) {
      _id
      rating
      title
      comment
      createdAt
    }
  }
`;

export const ADD_ADDRESS = gql`
  mutation AddAddress($input: AddressInput!) {
    addAddress(input: $input) {
      _id
      addresses {
        _id
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
        isDefault
      }
    }
  }
`;

export const UPDATE_ADDRESS = gql`
  mutation UpdateAddress($addressId: ID!, $input: AddressInput!) {
    updateAddress(addressId: $addressId, input: $input) {
      _id
      addresses {
        _id
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
        isDefault
      }
    }
  }
`;

export const DELETE_ADDRESS = gql`
  mutation DeleteAddress($addressId: ID!) {
    deleteAddress(addressId: $addressId) {
      _id
      addresses {
        _id
        fullName
        phone
        addressLine1
        city
        state
        postalCode
        isDefault
      }
    }
  }
`;

export const SET_DEFAULT_ADDRESS = gql`
  mutation SetDefaultAddress($addressId: ID!) {
    setDefaultAddress(addressId: $addressId) {
      _id
      addresses {
        _id
        fullName
        isDefault
      }
    }
  }
`;

export const MARK_NOTIFICATION_READ = gql`
  mutation MarkNotificationRead($id: ID!) {
    markNotificationRead(id: $id) {
      _id
      isRead
    }
  }
`;

export const MARK_ALL_NOTIFICATIONS_READ = gql`
  mutation MarkAllNotificationsRead {
    markAllNotificationsRead
  }
`;

export const CREATE_SUPPORT_TICKET = gql`
  mutation CreateSupportTicket($input: CreateSupportTicketInput!) {
    createSupportTicket(input: $input) {
      _id
      ticketNumber
      subject
      message
      status
      createdAt
    }
  }
`;
