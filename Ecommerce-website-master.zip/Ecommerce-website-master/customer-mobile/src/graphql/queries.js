import { gql } from '@apollo/client';

export const GET_PRODUCTS = gql`
  query GetProducts($filter: ProductFilterInput, $sort: ProductSortInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, sort: $sort, pagination: $pagination) {
      products {
        _id
        name
        slug
        description
        price
        comparePrice
        images
        stock
        category {
          _id
          name
          slug
          parent {
            _id
            name
            slug
          }
        }
        subcategory {
          _id
          name
          slug
        }
        rating {
          average
          count
        }
        variants {
          name
          options {
            label
            price
            stock
            sku
            thumbnail
            thumbnails
          }
        }
        isFeatured
        isDeals
        discount
        unitMeasure
        nutritionalHighlights
        vertical
        isVeg
        cuisine
        preparationTime
        restaurantName
        serviceDuration
        includedFeatures
        warranty
        highlights
        vendor {
          _id
          name
          email
          avatar
        }
      }
      total
      page
      pages
    }
  }
`;

export const GET_PRODUCT_BY_SLUG = gql`
  query GetProductBySlug($slug: String!) {
    getProduct(slug: $slug) {
      _id
      name
      slug
      description
      price
      comparePrice
      images
      stock
      category {
        _id
        name
        slug
      }
      sku
      rating {
        average
        count
      }
      unitMeasure
      nutritionalHighlights
      vertical
      isVeg
      cuisine
      preparationTime
      restaurantName
      serviceDuration
      includedFeatures
      warranty
      highlights
      variants {
        name
        options {
          label
          price
          stock
          sku
          thumbnail
        }
      }
      vendor {
        _id
        name
        email
        avatar
      }
      reviews {
        _id
        user {
          _id
          name
          avatar
        }
        rating
        title
        comment
        createdAt
        reply {
          comment
          repliedAt
        }
      }
      isFeatured
      isDeals
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories($vertical: String) {
    getCategories(vertical: $vertical) {
      _id
      name
      slug
      image
      icon
      vertical
      isActive
      productCount
      parent {
        _id
        name
        slug
      }
      children {
        _id
        name
        slug
      }
    }
  }
`;

export const GET_DEALS = gql`
  query GetDeals {
    getDeals {
      _id
      name
      slug
      price
      comparePrice
      images
      discount
      stock
      rating {
        average
        count
      }
      variants {
        name
        options {
          label
          price
          stock
          sku
        }
      }
    }
  }
`;

export const GET_FEATURED_PRODUCTS = gql`
  query GetFeaturedProducts {
    getFeaturedProducts {
      _id
      name
      slug
      price
      comparePrice
      images
      stock
      rating {
        average
        count
      }
      variants {
        name
        options {
          label
          price
          stock
          sku
          thumbnail
        }
      }
    }
  }
`;

export const GET_CART = gql`
  query GetCart {
    getCart {
      _id
      items {
        _id
        product {
          _id
          name
          slug
          price
          images
          stock
        }
        quantity
        price
        variantIndex
        image
        variantLabel
      }
      subtotal
      discount
      shippingCost
      tax
      total
      couponCode
    }
  }
`;

export const GET_ORDERS = gql`
  query GetOrders($status: String, $pagination: PaginationInput) {
    getOrders(status: $status, pagination: $pagination) {
      orders {
        _id
        orderNumber
        invoiceNumber
        status
        paymentMethod
        paymentStatus
        total
        subtotal
        discount
        shippingCost
        tax
        createdAt
        estimatedDelivery
        items {
          name
          image
          price
          quantity
          variantLabel
          total
        }
        shippingAddress {
          fullName
          city
          state
          postalCode
          phone
        }
      }
      total
      page
      pages
    }
  }
`;

export const GET_ORDER = gql`
  query GetOrder($id: ID!) {
    getOrder(id: $id) {
      _id
      orderNumber
      invoiceNumber
      invoiceDate
      status
      paymentMethod
      paymentStatus
      subtotal
      discount
      shippingCost
      tax
      total
      createdAt
      estimatedDelivery
      deliveredAt
      couponCode
      customer {
        _id
        name
        email
        phone
      }
      vendor {
        _id
        name
      }
      deliveryAgent {
        _id
        name
        phone
      }
      deliveryBoy {
        _id
        name
        phone
      }
      deliveryOption {
        name
        estimatedDays
        price
      }
      taxDetails {
        rate
        cgst
        sgst
        igst
        taxAmount
      }
      items {
        product {
          _id
          name
          slug
          images
        }
        name
        image
        price
        quantity
        variantLabel
        total
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      destinationLocation {
        latitude
        longitude
        address
      }
      trackingUpdates {
        status
        message
        timestamp
        location
      }
    }
  }
`;

export const GET_DELIVERY_OPTIONS = gql`
  query GetDeliveryOptions {
    getDeliveryOptions {
      _id
      name
      estimatedDays
      price
      minOrderForFree
      description
      isDefault
      isActive
    }
  }
`;

export const GET_ME = gql`
  query GetMe {
    me {
      _id
      name
      email
      role
      avatar
      phone
      addresses {
        _id
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
        isDefault
      }
    }
  }
`;

export const GET_NOTIFICATIONS = gql`
  query GetNotifications {
    getNotifications {
      _id
      title
      message
      type
      data
      isRead
      createdAt
    }
  }
`;

export const GET_LEGAL_PAGE = gql`
  query GetLegalPage($slug: String!) {
    getLegalPage(slug: $slug) {
      _id
      slug
      title
      content
      version
      updatedAt
    }
  }
`;

export const GET_BANNERS = gql`
  query GetBanners($platform: String) {
    getBanners(platform: $platform) {
      _id title subtitle tag image link discount platform bgGradient bgHex buttonColor accentColor isActive order createdAt
    }
  }
`;

export const GET_UNREAD_NOTIFICATION_COUNT = gql`
  query GetUnreadNotificationCount {
    getNotifications {
      _id
      isRead
    }
  }
`;

export const GET_STORE_SETTINGS = gql`
  query GetStoreSettings {
    getStoreSettings {
      _id
      storeName
      disabledVerticals
      serviceBookingMode
      serviceContactPhone
    }
  }
`;

export const GET_SUPPORT_TICKET = gql`
  query GetSupportTicket($id: ID!) {
    getSupportTicket(id: $id) {
      _id
      ticketNumber
      subject
      message
      category
      status
      priority
      adminReply
      repliedAt
      repliedBy {
        _id
        name
      }
      createdAt
      updatedAt
    }
  }
`;

export const GET_MY_SUPPORT_TICKETS = gql`
  query GetMySupportTickets {
    getMySupportTickets {
      _id
      ticketNumber
      subject
      message
      category
      status
      priority
      adminReply
      repliedAt
      createdAt
    }
  }
`;



