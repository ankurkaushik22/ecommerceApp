import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import TabNavigator from './TabNavigator';
import HomeScreen from '../screens/home/HomeScreen';
import ExploreScreen from '../screens/products/ExploreScreen';
import CartScreen from '../screens/cart/CartScreen';
import ProductDetailScreen from '../screens/products/ProductDetailScreen';
import CategoryProductsScreen from '../screens/products/CategoryProductsScreen';
import DealsScreen from '../screens/products/DealsScreen';
import CheckoutScreen from '../screens/checkout/CheckoutScreen';
import OrderSuccessScreen from '../screens/orders/OrderSuccessScreen';
import OrdersListScreen from '../screens/orders/OrdersListScreen';
import OrderDetailScreen from '../screens/orders/OrderDetailScreen';
import AddressesScreen from '../screens/account/AddressesScreen';
import NotificationsScreen from '../screens/account/NotificationsScreen';
import SupportTicketDetailScreen from '../screens/account/SupportTicketDetailScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';
import ResetPasswordScreen from '../screens/auth/ResetPasswordScreen';
import LegalPageScreen from '../screens/legal/LegalPageScreen';
import SellerStoreScreen from '../screens/store/SellerStoreScreen';
import GroceryHomeScreen from '../screens/grocery/GroceryHomeScreen';
import GroceryCategoryScreen from '../screens/grocery/GroceryCategoryScreen';
import GroceryProductDetailScreen from '../screens/grocery/GroceryProductDetailScreen';
import FoodHomeScreen from '../screens/food/FoodHomeScreen';
import ServicesHomeScreen from '../screens/services/ServicesHomeScreen';
import WishlistScreen from '../screens/wishlist/WishlistScreen';

const Stack = createNativeStackNavigator();

export default function RootNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="MainTabs"
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
      }}
    >
      {/* Main Tabs Entry */}
      <Stack.Screen name="MainTabs" component={TabNavigator} />

      {/* Shopping Mall & Search */}
      <Stack.Screen name="ShoppingMall" component={HomeScreen} />
      <Stack.Screen name="Explore" component={ExploreScreen} />
      <Stack.Screen name="ExploreTab" component={ExploreScreen} />
      <Stack.Screen name="Cart" component={CartScreen} />

      {/* Product & Store Screens */}
      <Stack.Screen name="ProductDetail" component={ProductDetailScreen} />
      <Stack.Screen name="SellerStore" component={SellerStoreScreen} />
      <Stack.Screen name="CategoryProducts" component={CategoryProductsScreen} />
      <Stack.Screen name="Deals" component={DealsScreen} />

      {/* Grocery / Suaaka Fresh Screens */}
      <Stack.Screen name="GroceryHome" component={GroceryHomeScreen} />
      <Stack.Screen name="GroceryCategory" component={GroceryCategoryScreen} />
      <Stack.Screen name="GroceryProductDetail" component={GroceryProductDetailScreen} />

      {/* Food Delivery Screens */}
      <Stack.Screen name="FoodHome" component={FoodHomeScreen} />

      {/* Services Screens */}
      <Stack.Screen name="ServicesHome" component={ServicesHomeScreen} />

      {/* Cart & Checkout */}
      <Stack.Screen name="Checkout" component={CheckoutScreen} />
      <Stack.Screen name="OrderSuccess" component={OrderSuccessScreen} />

      {/* Orders & Tracking */}
      <Stack.Screen name="OrdersList" component={OrdersListScreen} />
      <Stack.Screen name="OrderDetail" component={OrderDetailScreen} />
      <Stack.Screen name="OrderTracking" component={OrderDetailScreen} />

      {/* Account Screens */}
      <Stack.Screen name="Addresses" component={AddressesScreen} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="SupportTicketDetail" component={SupportTicketDetailScreen} />
      <Stack.Screen name="Wishlist" component={WishlistScreen} />

      {/* Auth Flow */}
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="ResetPassword" component={ResetPasswordScreen} />
      
      {/* Legal */}
      <Stack.Screen name="LegalPage" component={LegalPageScreen} />
    </Stack.Navigator>
  );
}
