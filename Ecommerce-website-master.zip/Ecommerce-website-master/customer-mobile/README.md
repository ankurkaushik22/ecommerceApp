# ShopZone Customer Mobile App (React Native + Expo)

A cross-platform e-commerce mobile application for iOS, Android, and Web powered by Expo, React Native, Apollo Client, and Zustand.

---

## 📱 Features

1. **Storefront & Catalog**:
   - Dynamic Hero Banner with promotional tags
   - Horizontal Category Scroller
   - Flash Deals & Limited-Time Discounts
   - Featured Collections & Popular Products Grid
   - All product prices formatted in **Indian Rupee (₹ INR)** with MRP comparison and GST tax inclusive note.

2. **Search, Filter & Sort**:
   - Real-time search with clear button
   - Category filtering pills
   - Sort by Popular, Price Low to High, Price High to Low, Top Rated, and Newest.

3. **Product Details**:
   - Multi-image gallery carousel with pagination dots
   - Stock level indicators (with low-stock alerts)
   - Variant selection pills (sizes / models)
   - Verified Merchant seller card
   - Customer ratings & reviews with seller reply support
   - Sticky bottom bar with 1-tap "Add to Cart" and "Buy Now".

4. **Cart & Multi-Step Checkout**:
   - Itemized cart with quantity steppers and delete
   - Promo coupon code redemption with instant validation
   - Detailed price breakdown (Subtotal, GST, Delivery Fee, Discount, Grand Total)
   - Step 1: Delivery Address (select saved or add new address)
   - Step 2: Delivery Speed (Standard, Express, Same-Day)
   - Step 3: Payment Method (Cash on Delivery, Cards, UPI)
   - Step 4: Tax Invoice & Order confirmation.

5. **Live Order Journey & Tracking**:
   - Real-time 5-stage Journey Stepper: Placed -> Confirmed -> Dispatched -> Out for Delivery -> Delivered
   - Courier partner card with direct phone dial action
   - Multi-Target Rating & Review (Product, Seller, Delivery Partner)
   - Itemized Tax Invoice popup with GST / CGST / SGST breakdown
   - Order cancellation (for pending and confirmed orders).

6. **Account & Authentication**:
   - Login with 1-tap Demo Customer credentials (`john@example.com` / `John@123`)
   - Registration with password validation
   - Forgot Password & Reset Password with Token / OTP
   - Saved Addresses management (Add, Edit, Delete, Set Default)
   - Notification Center with unread badges
   - Wishlist with 1-tap move-to-cart.

---

## 🚀 Running the App

### 1. Install Dependencies
```bash
cd customer-mobile
npm install
```

### 2. Start Expo Development Server
```bash
# Start bundler for iOS / Android (Expo Go)
npm start

# Or start directly in web browser
npm run web
```

---

## 🔐 Demo Credentials
- **Email**: `john@example.com`
- **Password**: `John@123`
- **Or tap**: *"1-Tap Sign In as Demo Customer"* on the Login screen.
