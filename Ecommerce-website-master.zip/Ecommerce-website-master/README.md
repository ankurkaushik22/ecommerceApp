# 🛒 Full-Stack Enterprise E-Commerce Platform (Amazon/Flipkart Style)

An enterprise-grade, high-performance E-Commerce platform built with **Node.js, Apollo Server GraphQL, Next.js 14, React 18, Tailwind CSS, Framer Motion, and MongoDB**.

---

## 🏗️ Architecture & Tech Stack

| Component | Technology | Description |
| :--- | :--- | :--- |
| **Backend API** | Node.js + Apollo Server 4 + Express | Full GraphQL API with Subscriptions & JWT Auth |
| **Customer Website** | Next.js 14 (App Router) + Tailwind CSS + Framer Motion | High SEO, responsive storefront with real-time tracking |
| **Admin Panel** | React 18 + Vite + Tailwind CSS + Recharts | Full administrative dashboard with analytics & live CRUD |
| **Database** | MongoDB + Mongoose | Robust document models with full indexing |
| **Caching** | Redis (with graceful fallback) | High-speed cache for performance optimization |
| **Payments** | Stripe + Cash on Delivery (COD) | Flexible payment gateway support |
| **Real-time Engine**| GraphQL WebSocket (`graphql-ws`) | Live order tracking and instant status broadcasts |

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js**: v18+ installed
- **MongoDB**: Local instance running on `mongodb://localhost:27017` or MongoDB Atlas URI in `.env`

---

### 2. Seed Database with Realistic Data
Seed products, categories, coupons, and test accounts:
```bash
cd backend
npm run seed
```

---

### 3. Running All Applications

#### **Start Backend GraphQL Server (Port 4000)**
```bash
cd backend
npm run dev
```
- GraphQL Playground: [http://localhost:4000/graphql](http://localhost:4000/graphql)
- Health Check: [http://localhost:4000/health](http://localhost:4000/health)

#### **Start Admin Panel (Port 5173)**
```bash
cd admin-panel
npm run dev
```
- Admin URL: [http://localhost:5173](http://localhost:5173)

#### **Start Customer Web Storefront (Port 3000)**
```bash
cd customer-website
npm run dev
```
- Customer Storefront: [http://localhost:3000](http://localhost:3000)

---

## 🔑 Pre-Configured Test Accounts

| Role | Email | Password |
| :--- | :--- | :--- |
| **Admin** | `admin@shopzone.com` | `Admin@123` |
| **Vendor / Seller** | `vendor@shopzone.com` | `Vendor@123` |
| **Delivery Agent** | `delivery@shopzone.com` | `Delivery@123` |
| **Customer** | `john@example.com` | `John@123` |

---

## 🏷️ Test Coupons Included
- `FLASH50` — **50% OFF**
- `SAVE20` — **20% OFF**
- `SAVE10` — **10% OFF**
- `FREESHIP` — **Free Shipping**
- `NEWUSER` — **15% OFF for new users**

---

## ✨ Features Implemented

### 🛍️ Customer Website (Next.js 14)
- **Modern Homepage**: Animated hero carousel, trust badges, categories showcase, flash deals, and featured items.
- **Faceted Product Catalog**: Filter by category, price slider, minimum rating, stock availability, and multi-sort.
- **Rich Product Details**: Image gallery, variant selection (size, color), specifications table, review rating distribution breakdown, and customer review submissions.
- **Live Cart & Checkout**: Slide-out cart drawer, dynamic subtotal calculations, coupon code validation, and Stripe & COD checkout flows.
- **Real-Time Order Tracking**: 6-step animated status stepper powered by live GraphQL WebSocket subscriptions.
- **Customer Account Area**: Address book management, wishlist collection, notifications, and profile settings.

### 🛡️ Admin Dashboard (React + Vite)
- **Executive Dashboard**: Key metrics (Revenue, Orders, Customers, Products) + interactive Recharts area and bar graphs.
- **Product Management**: Full CRUD modal, multi-image URL management, stock control, variant config, and quick active toggle.
- **Category Hierarchy**: Root and subcategory tree management with emoji icons.
- **Order Processing**: Detailed order viewer, status progression updates, and delivery agent assignment.
- **User & Role Administration**: Role assignments (`admin`, `vendor`, `delivery`, `customer`) and account suspension toggles.
- **Coupon Manager**: Percentage & fixed-discount coupon generation with expiration dates and usage limits.
- **Advanced Analytics**: Revenue distribution by category, orders by status pie chart, and daily sales trends.
