import { Routes, Route, Navigate } from 'react-router-dom';
import useAuthStore from './store/authStore.js';
import AdminLayout from './components/layout/AdminLayout.jsx';
import Login from './pages/auth/Login.jsx';
import Dashboard from './pages/dashboard/Dashboard.jsx';
import Products from './pages/products/Products.jsx';
import Categories from './pages/categories/Categories.jsx';
import Orders from './pages/orders/Orders.jsx';
import Returns from './pages/orders/Returns.jsx';
import Users from './pages/users/Users.jsx';
import UserDetail from './pages/users/UserDetail.jsx';
import Vendors from './pages/users/Vendors.jsx';
import Roles from './pages/roles/Roles.jsx';
import DeliveryOptions from './pages/delivery/DeliveryOptions.jsx';
import Taxes from './pages/taxes/Taxes.jsx';
import Invoices from './pages/invoices/Invoices.jsx';
import Reviews from './pages/reviews/Reviews.jsx';
import Coupons from './pages/coupons/Coupons.jsx';
import CommissionReceived from './pages/finance/CommissionReceived.jsx';
import VendorPayouts from './pages/finance/VendorPayouts.jsx';
import Settings from './pages/settings/Settings.jsx';
import Banners from './pages/settings/Banners.jsx';
import LegalPages from './pages/settings/LegalPages.jsx';
import SupportTickets from './pages/support/SupportTickets.jsx';

const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const user = useAuthStore((s) => s.user);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user && (user.role === 'customer' || user.isActive === false)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-dark-900">Access Denied</h1>
          <p className="text-dark-500 mt-2">Your account does not have permission to access the management portal.</p>
        </div>
      </div>
    );
  }
  return children;
};

const PublicRoute = ({ children }) => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  if (isAuthenticated) return <Navigate to="/dashboard" replace />;
  return children;
};

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
      <Route path="/" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="products" element={<Products />} />
        <Route path="categories" element={<Categories />} />
        <Route path="orders" element={<Orders />} />
        <Route path="returns" element={<Returns />} />
        <Route path="support" element={<SupportTickets />} />
        <Route path="users" element={<Users />} />
        <Route path="users/:id" element={<UserDetail />} />
        <Route path="vendors" element={<Vendors />} />
        <Route path="roles" element={<Roles />} />
        <Route path="delivery" element={<DeliveryOptions />} />
        <Route path="taxes" element={<Taxes />} />
        <Route path="invoices" element={<Invoices />} />
        <Route path="finance/commissions" element={<CommissionReceived />} />
        <Route path="finance/payouts" element={<VendorPayouts />} />
        <Route path="reviews" element={<Reviews />} />
        <Route path="coupons" element={<Coupons />} />
        <Route path="promotions" element={<Coupons />} />
        <Route path="settings" element={<Settings />} />
        <Route path="settings/banners" element={<Banners />} />
        <Route path="settings/legal" element={<LegalPages />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
