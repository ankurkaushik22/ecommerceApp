import { Routes, Route, Navigate } from 'react-router-dom';
import useAuthStore from './store/authStore.js';
import AdminLayout from './components/layout/AdminLayout.jsx';
import Login from './pages/auth/Login.jsx';
import Dashboard from './pages/dashboard/Dashboard.jsx';
import Products from './pages/products/Products.jsx';
import Categories from './pages/categories/Categories.jsx';
import Orders from './pages/orders/Orders.jsx';
import Users from './pages/users/Users.jsx';
import Coupons from './pages/coupons/Coupons.jsx';
import Analytics from './pages/analytics/Analytics.jsx';
import Settings from './pages/settings/Settings.jsx';

const ProtectedRoute = ({ children }) => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const user = useAuthStore((s) => s.user);
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (user && !['admin', 'vendor'].includes(user.role)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-dark-900">Access Denied</h1>
          <p className="text-dark-500 mt-2">You don't have permission to access this panel.</p>
        </div>
      </div>
    );
  }
  return children;
};

const PublicRoute = ({ children }) => {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  if (isAuthenticated) return <Navigate to="/dashboard" replace />;
  return children;
};

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
      <Route path="/" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="products" element={<Products />} />
        <Route path="categories" element={<Categories />} />
        <Route path="orders" element={<Orders />} />
        <Route path="users" element={<Users />} />
        <Route path="coupons" element={<Coupons />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
