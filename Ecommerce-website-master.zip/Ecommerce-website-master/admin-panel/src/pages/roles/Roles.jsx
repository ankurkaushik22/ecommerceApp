import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  ShieldCheckIcon,
  PlusIcon,
  CheckIcon,
  PencilSquareIcon,
  TrashIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import useAuthStore from '../../store/authStore.js';
import { GET_ROLES } from '../../graphql/queries.js';
import { SAVE_ROLE_PERMISSIONS, DELETE_ROLE } from '../../graphql/mutations.js';
import ConfirmModal from '../../components/common/ConfirmModal';

const AVAILABLE_MODULES = [
  { id: 'dashboard', label: '📊 Dashboard & Overview' },
  { id: 'products', label: '🛍️ Products & Inventory' },
  { id: 'categories', label: '🏷️ View Categories' },
  { id: 'add_categories', label: '➕ Add & Create Categories (Show/Hide Add Category Button)' },
  { id: 'orders', label: '📦 Orders & Dispatch' },
  { id: 'users', label: '👥 User & Staff Management' },
  { id: 'roles', label: '🛡️ Role & Permission Access' },
  { id: 'coupons', label: '🎫 Promo Codes & Discounts' },
  { id: 'delivery', label: '🚚 Delivery Options & Speeds' },
  { id: 'taxes', label: '💰 Tax & GST Rates' },
  { id: 'invoices', label: '🧾 GST Tax Invoices' },
  { id: 'commissions', label: '💵 Vendor Commissions' },
  { id: 'payouts', label: '💳 Vendor Payout Requests' },
  { id: 'reviews', label: '⭐ Customer Ratings & Replies' },
  { id: 'banners', label: '🖼️ Banners & Promotions' },
  { id: 'support', label: '🎧 Customer Support Tickets' },
  { id: 'returns', label: '🔄 Returns Management' },
  { id: 'vendors', label: '🏪 Vendor Management' },
  { id: 'settings', label: '⚙️ Store Settings' },
];

export default function Roles() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const currentUser = useAuthStore((s) => s.user);
  const isSuperAdmin = currentUser?.role === 'superadmin';

  const [editingRole, setEditingRole] = useState(null);
  const [roleName, setRoleName] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedModules, setSelectedModules] = useState([]);

  const { data, loading, refetch } = useQuery(GET_ROLES);

  const [saveRoleMutation, { loading: saving }] = useMutation(SAVE_ROLE_PERMISSIONS, {
    onCompleted: () => {
      toast.success('Role permissions saved successfully!');
      setEditingRole(null);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteRoleMutation] = useMutation(DELETE_ROLE, {
    onCompleted: () => {
      toast.success('Role deleted');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const roles = data?.getRoles || [];

  // Filter roles: Hide superadmin role from regular admins
  const visibleRoles = useMemo(() => {
    return roles.filter((r) => {
      if (!isSuperAdmin && r.roleName === 'superadmin') return false;
      return true;
    });
  }, [roles, isSuperAdmin]);

  const handleEdit = (role) => {
    setEditingRole(role);
    setRoleName(role.roleName);
    setDisplayName(role.displayName);
    setDescription(role.description || '');
    setSelectedModules(role.modules || []);
  };

  const handleCreateNew = () => {
    setEditingRole('new');
    setRoleName('');
    setDisplayName('');
    setDescription('');
    setSelectedModules(['dashboard', 'orders']);
  };

  const toggleModule = (modId) => {
    if (selectedModules.includes(modId)) {
      setSelectedModules(selectedModules.filter((m) => m !== modId));
    } else {
      setSelectedModules([...selectedModules, modId]);
    }
  };

  const handleSave = (e) => {
    e.preventDefault();
    const cleanRoleName = roleName.trim().toLowerCase();
    if (!cleanRoleName || !displayName.trim()) {
      toast.error('Role name and display title are required');
      return;
    }

    if (cleanRoleName === 'superadmin' && !isSuperAdmin) {
      toast.error('Only super administrators can manage the superadmin role');
      return;
    }

    saveRoleMutation({
      variables: {
        input: {
          roleName: cleanRoleName,
          displayName: displayName.trim(),
          description: description.trim(),
          modules: selectedModules,
        },
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Roles & Module Access Control</h1>
          <p className="text-sm text-dark-500 mt-1">
            Configure system permissions and module access for Administrators, Vendors, Delivery Agents, and Custom Roles
          </p>
        </div>

        <button
          onClick={handleCreateNew}
          className="btn-primary flex items-center gap-2 text-sm shadow-md"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add Custom Role</span>
        </button>
      </div>

      {/* Roles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="card p-6 h-56 animate-pulse bg-gray-100 rounded-2xl" />
          ))
        ) : (
          visibleRoles.map((role) => (
            <motion.div
              key={role._id || role.roleName}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-6 space-y-4 hover:shadow-lg transition-all border border-gray-100 relative flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-sm ${
                      role.roleName === 'superadmin' ? 'bg-amber-100 text-amber-900' : 'bg-primary-50 text-primary-600'
                    }`}>
                      <ShieldCheckIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-dark-900">{role.displayName}</h3>
                      <span className="text-[11px] font-mono font-semibold text-primary-600 bg-primary-50 px-2 py-0.5 rounded-md">
                        {role.roleName}
                      </span>
                    </div>
                  </div>
                  {role.isSystem && (
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                      System Core
                    </span>
                  )}
                </div>

                <p className="text-xs text-dark-500 leading-relaxed min-h-[36px]">
                  {role.description || 'Custom role with configured module privileges.'}
                </p>

                {/* Modules Badges */}
                <div className="pt-2">
                  <p className="text-[11px] font-bold text-gray-400 uppercase mb-1.5">
                    Authorized Modules ({role.modules?.filter((m) => m !== 'analytics')?.length || 0}):
                  </p>
                  <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                    {role.modules?.filter((m) => m !== 'analytics')?.map((m) => (
                      <span
                        key={m}
                        className="px-2 py-0.5 bg-gray-100 text-gray-700 text-[10px] font-medium rounded-lg"
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                <button
                  onClick={() => handleEdit(role)}
                  className="text-xs font-bold text-primary-600 hover:text-primary-700 flex items-center gap-1"
                >
                  <PencilSquareIcon className="w-4 h-4" /> Edit Permissions
                </button>

                {!role.isSystem && (
                  <button
                    onClick={() => setDeleteConfirm(role)}
                    className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg transition-colors"
                  >
                    <TrashIcon className="w-4 h-4" />
                  </button>
                )}
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Edit / Create Role Modal */}
      {editingRole && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-xl w-full space-y-5 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h3 className="text-lg font-bold text-dark-900">
                  {editingRole === 'new' ? 'Create Custom Role' : `Edit Permissions for ${displayName}`}
                </h3>
                <p className="text-xs text-dark-500">Enable or disable module privileges</p>
              </div>
              <button onClick={() => setEditingRole(null)} className="p-1 text-gray-400 hover:text-gray-700">
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Role Identifier Key *</label>
                  <input
                    type="text"
                    placeholder="e.g. manager, support_agent"
                    value={roleName}
                    onChange={(e) => setRoleName(e.target.value)}
                    disabled={editingRole !== 'new' && editingRole?.isSystem}
                    className="input-field text-xs disabled:bg-gray-100"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Display Title *</label>
                  <input
                    type="text"
                    placeholder="e.g. Store Operations Manager"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="input-field text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Description</label>
                <input
                  type="text"
                  placeholder="Summary of responsibilities and scope..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field text-xs"
                />
              </div>

              {/* Module Permissions Checkbox Matrix */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-dark-800 uppercase tracking-wider block">
                    Assigned Module Permissions:
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedModules.length === AVAILABLE_MODULES.length) setSelectedModules([]);
                      else setSelectedModules(AVAILABLE_MODULES.map((m) => m.id));
                    }}
                    className="text-[11px] font-bold text-primary-600 hover:underline"
                  >
                    {selectedModules.length === AVAILABLE_MODULES.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 p-3 bg-gray-50 rounded-2xl border border-gray-100 max-h-60 overflow-y-auto">
                  {AVAILABLE_MODULES.map((mod) => {
                    const isChecked = selectedModules.includes(mod.id);
                    return (
                      <div
                        key={mod.id}
                        onClick={() => toggleModule(mod.id)}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          isChecked
                            ? 'bg-white border-primary-500 ring-1 ring-primary-500/20 text-primary-900 font-semibold'
                            : 'bg-white/60 border-gray-200 text-gray-600 hover:bg-white'
                        }`}
                      >
                        <span className="text-xs">{mod.label}</span>
                        <div
                          className={`w-4 h-4 rounded-md flex items-center justify-center border transition-all ${
                            isChecked ? 'bg-primary-600 border-primary-600 text-white' : 'border-gray-300'
                          }`}
                        >
                          {isChecked && <CheckIcon className="w-3 h-3 stroke-[3]" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setEditingRole(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold"
                >
                  {saving ? 'Saving...' : 'Save Role Permissions'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Custom Role?"
        message={`Are you sure you want to delete custom role "${deleteConfirm?.displayName}"?`}
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteRoleMutation({ variables: { id: deleteConfirm._id } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
