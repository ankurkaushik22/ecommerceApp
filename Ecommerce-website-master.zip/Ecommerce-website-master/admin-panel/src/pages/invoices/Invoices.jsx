import { useState } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  DocumentTextIcon,
  PrinterIcon,
  MagnifyingGlassIcon,
  EyeIcon,
  XMarkIcon,
  ArrowDownTrayIcon,
} from '@heroicons/react/24/outline';
import { format } from 'date-fns';
import { GET_ALL_ORDERS } from '../../graphql/queries.js';

export default function Invoices() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: statusFilter === 'all' ? undefined : statusFilter,
      pagination: { limit: 100 },
    },
    fetchPolicy: 'network-only',
  });

  const orders = (data?.getAllOrders?.orders || []).filter(Boolean);

  const filteredOrders = orders.filter((o) => {
    const term = searchTerm.toLowerCase();
    return (
      o.orderNumber?.toLowerCase().includes(term) ||
      o.customer?.name?.toLowerCase().includes(term) ||
      o.customer?.email?.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">GST Invoice Management</h1>
          <p className="text-sm text-dark-500 mt-1">
            Generate, inspect, print, and export official GST compliant Tax Invoices for customer orders
          </p>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="card p-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-gray-100">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            placeholder="Search by order # or customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 text-xs"
          />
          <MagnifyingGlassIcon className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="input-field text-xs w-full sm:w-44"
          >
            <option value="all">All Orders</option>
            <option value="delivered">Delivered (Completed)</option>
            <option value="dispatched">Dispatched</option>
            <option value="confirmed">Confirmed</option>
            <option value="pending">Pending</option>
          </select>
        </div>
      </div>

      {/* Invoices Table */}
      <div className="card overflow-hidden bg-white border border-gray-100 shadow-sm rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 border-b border-gray-100 text-dark-500 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">Invoice #</th>
                <th className="py-3.5 px-4">Order #</th>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Billed Customer</th>
                <th className="py-3.5 px-4 text-right">Taxable Amt</th>
                <th className="py-3.5 px-4 text-right">GST (18%)</th>
                <th className="py-3.5 px-4 text-right">Total (₹)</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-dark-800 font-medium">
              {loading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={9} className="py-4 px-4 bg-gray-50/50" />
                  </tr>
                ))
              ) : filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-gray-400">
                    No matching invoices found.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const taxable = Math.max(0, (order.subtotal || 0) - (order.discount || 0));
                  const taxAmount = order.tax || Math.round(taxable * 0.18 * 100) / 100;
                  return (
                    <tr key={order._id} className="hover:bg-gray-50/80 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-primary-600">
                        INV-{order?.orderNumber || '—'}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-semibold text-dark-700">
                        #{order?.orderNumber || '—'}
                      </td>
                      <td className="py-3.5 px-4 text-gray-500">
                        {order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : '—'}
                      </td>
                      <td className="py-3.5 px-4">
                        <p className="font-bold text-dark-900">{order.customer?.name || order.shippingAddress?.fullName || 'Customer'}</p>
                        <p className="text-[11px] text-gray-400">{order.customer?.email}</p>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono">
                        ₹{taxable.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-amber-700 font-semibold">
                        ₹{taxAmount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-dark-900">
                        ₹{order.total?.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                            order.paymentStatus === 'paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {order.paymentStatus || 'Pending'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="px-3 py-1.5 rounded-xl bg-primary-50 hover:bg-primary-100 text-primary-700 font-bold text-xs flex items-center gap-1.5 ml-auto transition-colors"
                        >
                          <EyeIcon className="w-4 h-4" /> View Invoice
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Viewer Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <div>
                <h3 className="text-xl font-extrabold text-gray-900">TAX INVOICE</h3>
                <p className="text-xs text-gray-500 font-mono">INV-{selectedOrder?.orderNumber || '—'}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-primary-600 hover:bg-primary-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <PrinterIcon className="w-4 h-4" /> Print / PDF
                </button>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Seller & Customer Details */}
            <div className="grid grid-cols-2 gap-4 text-xs text-gray-600 p-4 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-gray-900 text-sm">ShopZone E-Commerce Pvt Ltd</p>
                <p>Plot 42, Tech City, Meerut, UP - 250001</p>
                <p className="font-semibold text-gray-800 mt-1">GSTIN: 09AAACH7409R1ZZ</p>
                <p>PAN: AAACH7409R</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900 text-sm">Billed To: {selectedOrder.shippingAddress?.fullName || selectedOrder.customer?.name}</p>
                <p>{selectedOrder.shippingAddress?.addressLine1}</p>
                <p>{selectedOrder.shippingAddress?.city}, {selectedOrder.shippingAddress?.state} - {selectedOrder.shippingAddress?.postalCode}</p>
                <p>Phone: {selectedOrder.shippingAddress?.phone}</p>
                <p className="font-semibold text-gray-800 mt-1">
                  Date: {selectedOrder.createdAt ? format(new Date(selectedOrder.createdAt), 'dd MMM yyyy') : 'N/A'}
                </p>
              </div>
            </div>

            {/* Table */}
            <table className="w-full text-xs">
              <thead className="border-b border-gray-200 text-gray-500 font-semibold">
                <tr>
                  <th className="text-left py-2">Item Description</th>
                  <th className="text-center py-2">Qty</th>
                  <th className="text-right py-2">Price</th>
                  <th className="text-right py-2">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {selectedOrder.items?.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-2.5 font-medium">{item.name}</td>
                    <td className="py-2.5 text-center">{item.quantity}</td>
                    <td className="py-2.5 text-right font-mono">₹{Number(item.price).toLocaleString('en-IN')}</td>
                    <td className="py-2.5 text-right font-mono font-bold">₹{(item.price * item.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* GST Summary */}
            <div className="border-t border-gray-200 pt-3 space-y-1.5 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Taxable Subtotal</span>
                <span className="font-mono">₹{(selectedOrder.subtotal - (selectedOrder.discount || 0)).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>CGST (9%)</span>
                <span className="font-mono">₹{(selectedOrder.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>SGST (9%)</span>
                <span className="font-mono">₹{(selectedOrder.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Charges</span>
                <span className="font-mono">{selectedOrder.shippingCost === 0 ? 'FREE' : `₹${selectedOrder.shippingCost}`}</span>
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-extrabold text-gray-900">
                <span>Grand Total (INR)</span>
                <span className="font-mono text-primary-600">₹{selectedOrder.total?.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <p className="text-[10px] text-gray-400 text-center">
              This is an authentic computer-generated GST tax invoice for official records.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
