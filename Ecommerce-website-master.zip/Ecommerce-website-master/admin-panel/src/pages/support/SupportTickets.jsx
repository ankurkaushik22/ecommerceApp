import { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import { format } from 'date-fns';
import {
  ChatBubbleLeftRightIcon,
  CheckCircleIcon,
  ClockIcon,
  ExclamationCircleIcon,
  MagnifyingGlassIcon,
  XMarkIcon,
  UserCircleIcon,
  EnvelopeIcon,
  PhoneIcon,
} from '@heroicons/react/24/outline';

const GET_ALL_SUPPORT_TICKETS = gql`
  query GetAllSupportTickets($status: String) {
    getAllSupportTickets(status: $status) {
      _id
      ticketNumber
      name
      email
      phone
      subject
      message
      status
      priority
      adminNotes
      createdAt
      updatedAt
      user {
        _id
        name
        email
      }
    }
  }
`;

const UPDATE_TICKET_STATUS = gql`
  mutation UpdateSupportTicketStatus($id: ID!, $status: String!, $adminNotes: String) {
    updateSupportTicketStatus(id: $id, status: $status, adminNotes: $adminNotes) {
      _id
      ticketNumber
      status
      adminNotes
      updatedAt
    }
  }
`;

const STATUS_COLORS = {
  open: 'bg-amber-50 text-amber-700 border-amber-200',
  in_progress: 'bg-blue-50 text-blue-700 border-blue-200',
  resolved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  closed: 'bg-gray-50 text-gray-700 border-gray-200',
};

const PRIORITY_BADGES = {
  low: 'bg-gray-100 text-gray-700',
  medium: 'bg-blue-100 text-blue-700',
  high: 'bg-orange-100 text-orange-700',
  urgent: 'bg-red-100 text-red-700 font-bold',
};

export default function SupportTickets() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [newStatus, setNewStatus] = useState('');

  const { data, loading, refetch } = useQuery(GET_ALL_SUPPORT_TICKETS, {
    variables: { status: statusFilter === 'all' ? undefined : statusFilter },
    fetchPolicy: 'network-only',
  });

  const [updateStatus, { loading: updating }] = useMutation(UPDATE_TICKET_STATUS, {
    onCompleted: () => {
      refetch();
      setSelectedTicket(null);
    },
  });

  const tickets = data?.getAllSupportTickets || [];

  const filteredTickets = tickets.filter((t) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      t.ticketNumber?.toLowerCase().includes(q) ||
      t.subject?.toLowerCase().includes(q) ||
      t.name?.toLowerCase().includes(q) ||
      t.email?.toLowerCase().includes(q)
    );
  });

  const handleOpenDetail = (ticket) => {
    setSelectedTicket(ticket);
    setAdminNotes(ticket.adminNotes || '');
    setNewStatus(ticket.status);
  };

  const handleSaveStatus = (e) => {
    e.preventDefault();
    if (!selectedTicket) return;
    updateStatus({
      variables: {
        id: selectedTicket._id,
        status: newStatus,
        adminNotes,
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Support & Helpdesk Tickets</h1>
          <p className="text-dark-500 text-sm mt-1">
            Review and respond to inquiries, queries, and feedback submitted by mobile and web customers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <MagnifyingGlassIcon className="w-5 h-5 text-dark-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search tickets, email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 pr-4 py-2 border border-dark-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 bg-white"
            />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-dark-200 pb-3">
        {['all', 'open', 'in_progress', 'resolved', 'closed'].map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-4 py-2 text-sm font-semibold rounded-lg capitalize transition-all ${
              statusFilter === st
                ? 'bg-primary-600 text-white shadow-sm'
                : 'bg-dark-100 text-dark-600 hover:bg-dark-200'
            }`}
          >
            {st.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Tickets List */}
      <div className="bg-white rounded-xl border border-dark-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-dark-400">Loading support tickets...</div>
        ) : filteredTickets.length === 0 ? (
          <div className="p-12 text-center">
            <ChatBubbleLeftRightIcon className="w-12 h-12 text-dark-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-dark-800">No Support Tickets Found</h3>
            <p className="text-sm text-dark-500 mt-1">When customers submit queries via the app or website, they will appear here.</p>
          </div>
        ) : (
          <div className="divide-y divide-dark-100">
            {filteredTickets.map((ticket) => (
              <div
                key={ticket._id}
                onClick={() => handleOpenDetail(ticket)}
                className="p-5 hover:bg-dark-50/70 transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-primary-600 bg-primary-50 px-2 py-0.5 rounded">
                      #{ticket.ticketNumber}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full border capitalize font-semibold ${
                        STATUS_COLORS[ticket.status] || 'bg-gray-50'
                      }`}
                    >
                      {ticket.status.replace('_', ' ')}
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded uppercase font-bold ${PRIORITY_BADGES[ticket.priority]}`}>
                      {ticket.priority}
                    </span>
                    <span className="text-xs text-dark-400">
                      {ticket.createdAt ? format(new Date(ticket.createdAt), 'dd MMM yyyy, hh:mm a') : ''}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-dark-900">{ticket.subject}</h3>
                  <p className="text-sm text-dark-600 line-clamp-2">{ticket.message}</p>

                  <div className="flex items-center gap-4 text-xs text-dark-500 pt-1">
                    <span className="flex items-center gap-1 font-medium text-dark-700">
                      <UserCircleIcon className="w-4 h-4 text-dark-400" />
                      {ticket.name}
                    </span>
                    <span className="flex items-center gap-1">
                      <EnvelopeIcon className="w-3.5 h-3.5 text-dark-400" />
                      {ticket.email}
                    </span>
                    {ticket.phone ? (
                      <span className="flex items-center gap-1">
                        <PhoneIcon className="w-3.5 h-3.5 text-dark-400" />
                        {ticket.phone}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="flex md:flex-col items-end justify-between gap-2">
                  <button className="text-xs font-semibold text-primary-600 hover:text-primary-800 bg-primary-50 px-3 py-1.5 rounded-md">
                    View & Respond
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Ticket Details & Action Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
            <div className="p-6 border-b border-dark-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <div className="flex items-center gap-3">
                <span className="font-mono text-sm font-bold text-primary-600 bg-primary-50 px-2.5 py-1 rounded">
                  #{selectedTicket.ticketNumber}
                </span>
                <h2 className="text-lg font-bold text-dark-900">Ticket Details</h2>
              </div>
              <button
                onClick={() => setSelectedTicket(null)}
                className="p-2 text-dark-400 hover:text-dark-700 rounded-full hover:bg-dark-100"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Sender info */}
              <div className="bg-dark-50 p-4 rounded-xl space-y-2 border border-dark-100">
                <div className="text-xs font-bold uppercase tracking-wider text-dark-500">Customer Details</div>
                <div className="flex flex-wrap gap-y-2 gap-x-6 text-sm">
                  <div>
                    <span className="text-dark-500">Name:</span>{' '}
                    <span className="font-bold text-dark-900">{selectedTicket.name}</span>
                  </div>
                  <div>
                    <span className="text-dark-500">Email:</span>{' '}
                    <a href={`mailto:${selectedTicket.email}`} className="font-semibold text-primary-600 hover:underline">
                      {selectedTicket.email}
                    </a>
                  </div>
                  {selectedTicket.phone ? (
                    <div>
                      <span className="text-dark-500">Phone:</span>{' '}
                      <span className="font-medium text-dark-800">{selectedTicket.phone}</span>
                    </div>
                  ) : null}
                  <div>
                    <span className="text-dark-500">Submitted:</span>{' '}
                    <span className="text-dark-700">
                      {selectedTicket.createdAt ? format(new Date(selectedTicket.createdAt), 'dd MMMM yyyy, hh:mm a') : 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Subject & Message */}
              <div className="space-y-3">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-dark-500 mb-1">Subject</div>
                  <div className="text-base font-bold text-dark-900 bg-white p-3 rounded-lg border border-dark-200">
                    {selectedTicket.subject}
                  </div>
                </div>

                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-dark-500 mb-1">Message</div>
                  <div className="text-sm text-dark-800 bg-dark-50/50 p-4 rounded-lg border border-dark-200 whitespace-pre-wrap leading-relaxed">
                    {selectedTicket.message}
                  </div>
                </div>
              </div>

              {/* Admin Status update form */}
              <form onSubmit={handleSaveStatus} className="space-y-4 pt-4 border-t border-dark-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-dark-700 mb-1">
                      Ticket Status
                    </label>
                    <select
                      value={newStatus}
                      onChange={(e) => setNewStatus(e.target.value)}
                      className="w-full px-3 py-2 border border-dark-200 rounded-lg text-sm bg-white focus:ring-2 focus:ring-primary-500 font-semibold"
                    >
                      <option value="open">Open (Awaiting action)</option>
                      <option value="in_progress">In Progress</option>
                      <option value="resolved">Resolved</option>
                      <option value="closed">Closed</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-dark-700 mb-1">
                    Internal Admin Notes / Action Taken
                  </label>
                  <textarea
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    rows={3}
                    placeholder="Add internal resolution notes, refund reference ID, customer callback log, etc..."
                    className="w-full p-3 border border-dark-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500 bg-white"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedTicket(null)}
                    className="px-4 py-2 text-sm font-semibold text-dark-700 hover:bg-dark-100 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={updating}
                    className="px-6 py-2 text-sm font-bold text-white bg-primary-600 hover:bg-primary-700 rounded-lg shadow-sm disabled:opacity-50"
                  >
                    {updating ? 'Saving...' : 'Update Ticket'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
