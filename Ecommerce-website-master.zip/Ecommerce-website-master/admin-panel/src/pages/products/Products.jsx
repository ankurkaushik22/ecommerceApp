import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { PlusIcon, PencilIcon, TrashIcon, MagnifyingGlassIcon, FunnelIcon, ArrowPathIcon, CheckIcon, XMarkIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_PRODUCTS, GET_ALL_CATEGORIES } from '../../graphql/queries.js';
import { CREATE_PRODUCT, UPDATE_PRODUCT, DELETE_PRODUCT, TOGGLE_PRODUCT_STATUS } from '../../graphql/mutations.js';

const PAGE_SIZE = 15;

export default function Products() {
  const [search, setSearch] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_PRODUCTS, {
    variables: {
      filter: { ...(search && { search }), ...(categoryId && { categoryId }) },
      pagination: { page, limit: PAGE_SIZE },
      sort: { field: 'newest', order: 'desc' },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: catData } = useQuery(GET_ALL_CATEGORIES);

  const [toggleStatus] = useMutation(TOGGLE_PRODUCT_STATUS, {
    onCompleted: () => { toast.success('Status updated'); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const [deleteProduct] = useMutation(DELETE_PRODUCT, {
    onCompleted: () => { toast.success('Product deleted'); setDeleteConfirm(null); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const products = data?.getProducts?.products || [];
  const total = data?.getProducts?.total || 0;
  const pages = data?.getProducts?.pages || 1;
  const categories = catData?.getAllCategories || [];

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Products</h2>
          <p className="text-sm text-dark-500">{total} products total</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
          onClick={() => { setEditProduct(null); setShowModal(true); }}
          className="flex items-center gap-2 btn-primary"
        >
          <PlusIcon className="w-4 h-4" /> Add Product
        </motion.button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search products..."
            className="input-field pl-9"
          />
        </div>
        <select
          value={categoryId}
          onChange={(e) => { setCategoryId(e.target.value); setPage(1); }}
          className="input-field sm:w-48"
        >
          <option value="">All Categories</option>
          {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
        </select>
        <button onClick={() => refetch()} className="flex items-center gap-2 btn-secondary whitespace-nowrap">
          <ArrowPathIcon className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Products Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Product</th>
                <th className="px-4 py-3 text-left">Category</th>
                <th className="px-4 py-3 text-right">Price</th>
                <th className="px-4 py-3 text-right">Stock</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Featured</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(7)].map((_, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-dark-100 rounded animate-pulse" /></td>
                      ))}
                    </tr>
                  ))
                : products.map((product) => (
                    <motion.tr
                      key={product._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/50 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={product.images?.[0]}
                            alt={product.name}
                            className="w-10 h-10 object-cover rounded-lg border border-dark-100"
                          />
                          <div>
                            <p className="text-sm font-medium text-dark-800 line-clamp-1 max-w-[180px]">{product.name}</p>
                            <p className="text-xs text-dark-400">SKU: {product.sku || 'N/A'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-dark-600">{product.category?.name}</td>
                      <td className="px-4 py-3 text-right">
                        <span className="text-sm font-semibold text-dark-900">${product.price}</span>
                        {product.comparePrice > product.price && (
                          <span className="block text-xs text-dark-400 line-through">${product.comparePrice}</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className={`text-sm font-medium ${product.stock === 0 ? 'text-red-500' : product.stock < 10 ? 'text-amber-500' : 'text-green-600'}`}>
                          {product.stock}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => toggleStatus({ variables: { id: product._id } })}
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${product.isActive ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-600 hover:bg-red-200'}`}
                        >
                          {product.isActive ? <><CheckIcon className="w-3 h-3" /> Active</> : <><XMarkIcon className="w-3 h-3" /> Inactive</>}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        {product.isFeatured ? (
                          <span className="text-amber-500 text-sm font-bold">⭐</span>
                        ) : (
                          <span className="text-dark-200 text-sm">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => { setEditProduct(product); setShowModal(true); }}
                            className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                          >
                            <PencilIcon className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(product)}
                            className="p-1.5 text-dark-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <TrashIcon className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))
              }
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div className="px-4 py-3 border-t border-dark-100 flex items-center justify-between">
            <p className="text-xs text-dark-400">Page {page} of {pages} · {total} results</p>
            <div className="flex gap-2">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1 text-sm btn-secondary disabled:opacity-40"
              >
                ← Prev
              </button>
              <button
                onClick={() => setPage(p => Math.min(pages, p + 1))}
                disabled={page === pages}
                className="px-3 py-1 text-sm btn-secondary disabled:opacity-40"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Product Form Modal */}
      <AnimatePresence>
        {showModal && (
          <ProductModal
            product={editProduct}
            categories={categories}
            onClose={() => setShowModal(false)}
            onSuccess={() => { setShowModal(false); refetch(); }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirm Modal */}
      <AnimatePresence>
        {deleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setDeleteConfirm(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-xl p-6 max-w-sm w-full shadow-2xl"
            >
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrashIcon className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold text-dark-900 text-center mb-2">Delete Product?</h3>
              <p className="text-sm text-dark-500 text-center mb-6">
                Are you sure you want to delete <strong>"{deleteConfirm.name}"</strong>? This action cannot be undone.
              </p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 btn-secondary">Cancel</button>
                <button
                  onClick={() => deleteProduct({ variables: { id: deleteConfirm._id } })}
                  className="flex-1 btn-danger"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ProductModal({ product, categories, onClose, onSuccess }) {
  const isEdit = !!product;
  const { register, handleSubmit, formState: { errors }, watch } = useForm({
    defaultValues: product
      ? {
          name: product.name, description: product.description,
          shortDescription: product.shortDescription, price: product.price,
          comparePrice: product.comparePrice, stock: product.stock,
          sku: product.sku, categoryId: product.category?._id,
          images: product.images?.join(', ') || '',
          tags: product.tags?.join(', ') || '',
          isFeatured: product.isFeatured, isDeals: product.isDeals,
          freeShipping: product.freeShipping,
        }
      : { isFeatured: false, isDeals: false, freeShipping: false, stock: 0 },
  });

  const [createProduct, { loading: creating }] = useMutation(CREATE_PRODUCT, {
    onCompleted: () => { toast.success('Product created!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });

  const [updateProduct, { loading: updating }] = useMutation(UPDATE_PRODUCT, {
    onCompleted: () => { toast.success('Product updated!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });

  const loading = creating || updating;

  const onSubmit = (data) => {
    const imagesArr = data.images.split(',').map((s) => s.trim()).filter(Boolean);
    const tagsArr = data.tags?.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean) || [];

    const input = {
      name: data.name, description: data.description,
      shortDescription: data.shortDescription, price: parseFloat(data.price),
      comparePrice: data.comparePrice ? parseFloat(data.comparePrice) : null,
      stock: parseInt(data.stock), sku: data.sku, categoryId: data.categoryId,
      images: imagesArr.length ? imagesArr : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600'],
      tags: tagsArr, isFeatured: !!data.isFeatured, isDeals: !!data.isDeals,
      freeShipping: !!data.freeShipping,
    };

    if (isEdit) {
      updateProduct({ variables: { id: product._id, input } });
    } else {
      createProduct({ variables: { input } });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-t-2xl sm:rounded-2xl w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
      >
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-dark-100 flex items-center justify-between z-10">
          <h2 className="text-lg font-semibold text-dark-900">{isEdit ? 'Edit Product' : 'Add New Product'}</h2>
          <button onClick={onClose} className="text-dark-400 hover:text-dark-700"><XMarkIcon className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Product Name *</label>
            <input {...register('name', { required: 'Required' })} className="input-field" placeholder="Enter product name" />
            {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name.message}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Price ($) *</label>
              <input {...register('price', { required: 'Required', min: 0 })} type="number" step="0.01" className="input-field" placeholder="0.00" />
              {errors.price && <p className="text-xs text-red-500 mt-1">{errors.price.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Compare Price ($)</label>
              <input {...register('comparePrice')} type="number" step="0.01" className="input-field" placeholder="0.00 (optional)" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Stock *</label>
              <input {...register('stock', { required: 'Required', min: 0 })} type="number" className="input-field" placeholder="0" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">SKU</label>
              <input {...register('sku')} className="input-field" placeholder="Product SKU" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Category *</label>
            <select {...register('categoryId', { required: 'Required' })} className="input-field">
              <option value="">Select category</option>
              {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
            {errors.categoryId && <p className="text-xs text-red-500 mt-1">{errors.categoryId.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Short Description</label>
            <input {...register('shortDescription')} className="input-field" placeholder="Brief product description" />
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Description *</label>
            <textarea {...register('description', { required: 'Required' })} rows={4} className="input-field resize-none" placeholder="Detailed description..." />
            {errors.description && <p className="text-xs text-red-500 mt-1">{errors.description.message}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Image URLs (comma separated)</label>
            <textarea {...register('images')} rows={2} className="input-field resize-none text-xs" placeholder="https://..., https://..." />
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Tags (comma separated)</label>
            <input {...register('tags')} className="input-field" placeholder="electronics, mobile, apple" />
          </div>

          <div className="flex flex-wrap gap-4">
            {[
              { name: 'isFeatured', label: '⭐ Featured Product' },
              { name: 'isDeals', label: '🔥 Deals Product' },
              { name: 'freeShipping', label: '🚚 Free Shipping' },
            ].map((toggle) => (
              <label key={toggle.name} className="flex items-center gap-2 cursor-pointer">
                <input {...register(toggle.name)} type="checkbox" className="w-4 h-4 text-primary-600 rounded" />
                <span className="text-sm text-dark-700">{toggle.label}</span>
              </label>
            ))}
          </div>

          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 btn-primary flex items-center justify-center gap-2">
              {loading && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {isEdit ? 'Update Product' : 'Create Product'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
