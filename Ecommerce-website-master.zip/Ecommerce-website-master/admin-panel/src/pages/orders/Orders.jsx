import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { MagnifyingGlassIcon, EyeIcon, XMarkIcon, ChevronDownIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_ORDERS, GET_DELIVERY_BOYS } from '../../graphql/queries.js';
import { UPDATE_ORDER_STATUS, ASSIGN_DELIVERY_BOY } from '../../graphql/mutations.js';
import clsx from 'clsx';
import useVerticalStore from '../../store/verticalStore.js';
import useAuthStore from '../../store/authStore.js';

const STATUS_TABS = ['all', 'placed', 'accepted', 'processing', 'ready_for_pickup', 'picked_up', 'out_for_delivery', 'delivered', 'completed', 'cancelled', 'refunded'];
const STATUS_COLORS = {
  placed: 'badge-warning', accepted: 'badge-info', processing: 'badge-info',
  ready_for_pickup: 'badge-info', picked_up: 'badge-info', out_for_delivery: 'badge-info',
  delivered: 'badge-success', completed: 'badge-success', cancelled: 'badge-danger', refunded: 'badge-danger',
};
const NEXT_STATUSES = {
  placed: ['accepted', 'cancelled'],
  accepted: ['processing', 'cancelled'],
  processing: ['ready_for_pickup', 'cancelled'],
  ready_for_pickup: ['picked_up', 'cancelled'],
  picked_up: ['out_for_delivery', 'cancelled'],
  out_for_delivery: ['delivered'],
  delivered: ['completed', 'refunded'],
};

const getOrderDisplayTotal = (order) => {
  if (typeof order?.total === 'number' && order.total > 0) return order.total;
  const sub = Number(order?.subtotal || 0);
  const disc = Number(order?.discount || 0);
  const ship = Number(order?.shippingCost || 0);
  const tax = Number(order?.tax || 0);
  const calc = Math.max(0, sub - disc + ship + tax);
  return Math.round(calc * 100) / 100;
};

export default function Orders() {
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_ORDERS, {
    variables: {
      status: statusFilter === 'all' ? undefined : statusFilter,
      search: search || undefined,
      vertical: activeVertical === 'all' ? undefined : activeVertical,
      pagination: { page, limit: 20 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: deliveryData } = useQuery(GET_DELIVERY_BOYS);
  const deliveryBoys = deliveryData?.getAllUsers || [];

  const [updateStatus, { loading: updating }] = useMutation(UPDATE_ORDER_STATUS, {
    onCompleted: (res) => {
      toast.success('Order status updated!');
      refetch();
      if (res?.updateOrderStatus && selectedOrder) {
        setSelectedOrder((prev) =>
          prev
            ? {
                ...prev,
                status: res.updateOrderStatus.status,
                trackingUpdates: res.updateOrderStatus.trackingUpdates || prev.trackingUpdates,
              }
            : null
        );
      }
    },
    onError: (e) => toast.error(e.message),
  });

  const [assignDelivery] = useMutation(ASSIGN_DELIVERY_BOY, {
    onCompleted: () => { toast.success('Delivery boy assigned!'); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const orders = (data?.getAllOrders?.orders || []).filter(Boolean);
  const total = data?.getAllOrders?.total || 0;
  const pages = data?.getAllOrders?.pages || 1;

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Orders</h2>
          <p className="text-sm text-dark-500">{total} orders total</p>
        </div>
        <div className="relative w-full sm:w-64">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
          <input
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search orders..."
            className="input-field pl-9"
          />
        </div>
      </div>

      {/* Status Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {STATUS_TABS.map((s) => (
          <button
            key={s}
            onClick={() => { setStatusFilter(s); setPage(1); }}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-200 flex-shrink-0',
              statusFilter === s
                ? 'bg-primary-600 text-white shadow-sm'
                : 'bg-white text-dark-500 border border-dark-200 hover:border-primary-300 hover:text-primary-600'
            )}
          >
            {s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}
          </button>
        ))}
      </div>

      {/* Orders Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Order</th>
                <th className="px-4 py-3 text-left">Vertical</th>
                <th className="px-4 py-3 text-left">Customer</th>
                <th className="px-4 py-3 text-left">Items</th>
                <th className="px-4 py-3 text-right">Total</th>
                <th className="px-4 py-3 text-center">Payment</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-left">Date</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(8)].map((_, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-dark-100 rounded animate-pulse" /></td>
                      ))}
                    </tr>
                  ))
                : orders.map((order) => (
                    <motion.tr
                      key={order._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/50 transition-colors cursor-pointer"
                      onClick={() => setSelectedOrder(order)}
                    >
                      <td className="px-4 py-3">
                        <span className="text-sm font-semibold text-primary-600">#{order?.orderNumber || '—'}</span>
                      </td>
<td className="px-4 py-3">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md uppercase ${
                          order.vertical === 'food'
                            ? 'bg-orange-100 text-orange-800'
                            : order.vertical === 'grocery'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.vertical === 'services'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {order.vertical === 'food' ? '🍔 Food' : order.vertical === 'grocery' ? '🥦 Grocery' : order.vertical === 'services' ? '🛠️ Service' : '🛍️ Retail'}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <img src={order.customer?.avatar} alt="" className="w-7 h-7 rounded-full" />
                          <div>
                            <p className="text-xs font-medium text-dark-800">{order.customer?.name}</p>
                            <p className="text-xs text-dark-400">{order.customer?.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-500">{order.items?.length} item(s)</td>
                      <td className="px-4 py-3 text-right text-sm font-semibold text-dark-900 font-mono">₹{getOrderDisplayTotal(order).toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={clsx(
                          'text-xs px-2 py-0.5 rounded-full font-medium',
                          order.paymentMethod === 'stripe' ? 'bg-purple-100 text-purple-700' : 'bg-amber-100 text-amber-700'
                        )}>
                          {order.paymentMethod === 'stripe' ? '💳 Card' : '💵 COD'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={STATUS_COLORS[order.status] || 'badge-gray'}>
                          {order.status?.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-400">
                        {order.createdAt ? format(new Date(order.createdAt), 'MMM d, yyyy') : '—'}
                      </td>
                      <td className="px-4 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                        >
                          <EyeIcon className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  ))
              }
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div className="px-4 py-3 border-t border-dark-100 flex items-center justify-between">
            <p className="text-xs text-dark-400">Page {page} of {pages}</p>
            <div className="flex gap-2">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 text-sm btn-secondary disabled:opacity-40">← Prev</button>
              <button onClick={() => setPage(p => Math.min(pages, p + 1))} disabled={page === pages} className="px-3 py-1 text-sm btn-secondary disabled:opacity-40">Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <OrderDetailModal
            order={selectedOrder}
            deliveryBoys={deliveryBoys}
            onClose={() => setSelectedOrder(null)}
            onUpdateStatus={({ status, message, location }) =>
              updateStatus({ variables: { orderId: selectedOrder._id, status, message, location } })
            }
            onAssignDelivery={(deliveryBoyId) =>
              assignDelivery({ variables: { orderId: selectedOrder._id, deliveryBoyId } })
            }
            updating={updating}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function OrderDetailModal({ order, deliveryBoys, onClose, onUpdateStatus, onAssignDelivery, updating }) {
  const user = useAuthStore((s) => s.user);
  const isSuperAdmin = user?.role === 'superadmin';
  const [newStatus, setNewStatus] = useState('');
  const [statusMessage, setStatusMessage] = useState('');
  const [selectedDelivery, setSelectedDelivery] = useState(order.deliveryBoy?._id || '');

  const rawNext = NEXT_STATUSES[order.status] || [];
  const nextStatuses = rawNext.filter((s) => s !== 'completed' || isSuperAdmin);

  useEffect(() => {
    const raw = NEXT_STATUSES[order?.status] || [];
    const filtered = raw.filter((s) => s !== 'completed' || isSuperAdmin);
    setNewStatus(filtered[0] || '');
    setStatusMessage('');
  }, [order?.status, isSuperAdmin]);

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
      >
        <div className="sticky top-0 bg-white px-6 py-4 border-b border-dark-100 flex items-center justify-between z-10">
          <div>
            <h2 className="text-lg font-semibold text-dark-900">Order #{order?.orderNumber || '—'}</h2>
            <p className="text-xs text-dark-400">{order.createdAt ? format(new Date(order.createdAt), 'MMMM d, yyyy · h:mm a') : ''}</p>
          </div>
          <button onClick={onClose}><XMarkIcon className="w-5 h-5 text-dark-400" /></button>
        </div>

        <div className="p-6 space-y-6">
          {/* Status + Payment + Delivery Option */}
          <div className="flex flex-wrap gap-4">
            <div className="card px-4 py-3 flex-1 min-w-[140px]">
              <p className="text-xs text-dark-400 mb-1">Order Status</p>
              <span className={clsx('text-sm font-semibold capitalize', STATUS_COLORS[order.status]?.replace('badge-', 'text-'))}>
                {order.status?.replace(/_/g, ' ')}
              </span>
            </div>
            <div className="card px-4 py-3 flex-1 min-w-[140px]">
              <p className="text-xs text-dark-400 mb-1">Payment</p>
              <p className="text-sm font-semibold text-dark-800 capitalize">
                {order.paymentMethod} · <span className={order.paymentStatus === 'paid' ? 'text-green-600' : 'text-amber-600'}>{order.paymentStatus}</span>
              </p>
            </div>
            <div className="card px-4 py-3 flex-1 min-w-[160px]">
              <p className="text-xs text-dark-400 mb-1">Delivery Speed / Option</p>
              <p className="text-sm font-semibold text-dark-800">
                {order.deliveryOption?.name || 'Standard Delivery'}
                {order.deliveryOption?.estimatedDays ? ` (${order.deliveryOption.estimatedDays})` : ''}
              </p>
            </div>
          </div>

          {/* Customer */}
          <div>
            <h3 className="text-sm font-semibold text-dark-700 mb-3">Customer</h3>
            <div className="flex items-center gap-3">
              <img src={order.customer?.avatar} alt="" className="w-10 h-10 rounded-full" />
              <div>
                <p className="text-sm font-medium text-dark-800">{order.customer?.name}</p>
                <p className="text-xs text-dark-500">{order.customer?.email} · {order.customer?.phone}</p>
              </div>
            </div>
          </div>

          {/* Items */}
          <div>
            <h3 className="text-sm font-semibold text-dark-700 mb-3">Items ({order.items?.length})</h3>
            <div className="space-y-2">
              {order.items?.map((item, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-dark-50 rounded-lg">
                  <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-dark-800 truncate">{item.name}</p>
                    {item.variantLabel && <p className="text-xs text-dark-400">{item.variantLabel}</p>}
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-dark-900 font-mono">₹{(item.price * item.quantity).toLocaleString('en-IN')}</p>
                    <p className="text-xs text-dark-400">x{item.quantity} @ ₹{Number(item.price).toLocaleString('en-IN')}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Totals */}
          <div className="card p-4 space-y-2">
            {[
              { label: 'Subtotal', value: order.subtotal },
              ...(order.discount > 0 ? [{ label: 'Discount', value: -order.discount, green: true }] : []),
              { label: 'Delivery / Shipping', value: order.shippingCost || 0 },
              { label: 'GST (18%)', value: order.tax || 0 },
            ].map((row) => (
              <div key={row.label} className="flex justify-between text-sm text-dark-600 font-mono">
                <span>{row.label}</span>
                <span className={row.green ? 'text-green-600' : ''}>{row.green && '-'}₹{Math.abs(row.value)?.toLocaleString('en-IN')}</span>
              </div>
            ))}
            <div className="flex justify-between text-base font-bold text-dark-900 pt-2 border-t border-dark-100 font-mono">
              <span>Total</span>
              <span className="text-primary-600">₹{getOrderDisplayTotal(order).toLocaleString('en-IN')}</span>
            </div>
          </div>

          {/* Shipping Address */}
          <div>
            <h3 className="text-sm font-semibold text-dark-700 mb-2">Shipping Address</h3>
            <div className="p-3 bg-dark-50 rounded-lg text-sm text-dark-600 space-y-0.5">
              <p className="font-medium text-dark-800">{order.shippingAddress?.fullName}</p>
              <p>{order.shippingAddress?.addressLine1}{order.shippingAddress?.addressLine2 ? `, ${order.shippingAddress.addressLine2}` : ''}</p>
              <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.postalCode}</p>
              <p>{order.shippingAddress?.country} · 📞 {order.shippingAddress?.phone}</p>
            </div>
          </div>

          {/* Tracking Timeline */}
          {order.trackingUpdates?.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-dark-700 mb-3">Tracking History</h3>
              <div className="space-y-3">
                {[...order.trackingUpdates].reverse().map((update, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className={`w-3 h-3 rounded-full mt-0.5 flex-shrink-0 ${i === 0 ? 'bg-primary-500' : 'bg-dark-200'}`} />
                      {i < order.trackingUpdates.length - 1 && <div className="w-0.5 flex-1 bg-dark-100 mt-1" />}
                    </div>
                    <div className="pb-3">
                      <p className="text-sm font-medium text-dark-800 capitalize">{update.status?.replace(/_/g, ' ')}</p>
                      <p className="text-xs text-dark-500">{update.message}</p>
                      <p className="text-xs text-dark-400 mt-0.5">
                        {update.timestamp ? format(new Date(update.timestamp), 'MMM d, h:mm a') : ''}
                        {update.location && ` · 📍 ${update.location}`}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Update Status */}
          {nextStatuses.length > 0 && (
            <div className="card p-4 space-y-3">
              <h3 className="text-sm font-semibold text-dark-700">Update Order Status</h3>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                className="input-field"
              >
                <option value="">Select new status</option>
                {nextStatuses.map((s) => (
                  <option key={s} value={s}>{s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase())}</option>
                ))}
              </select>
              <input
                value={statusMessage}
                onChange={(e) => setStatusMessage(e.target.value)}
                className="input-field"
                placeholder="Custom message (optional)"
              />
              <button
                onClick={() => { if (newStatus) onUpdateStatus({ status: newStatus, message: statusMessage }); }}
                disabled={!newStatus || updating}
                className="w-full btn-primary disabled:opacity-50"
              >
                {updating ? 'Updating...' : 'Update Status'}
              </button>
            </div>
          )}

          {/* Assign Delivery Boy */}
          {['ready_for_pickup', 'picked_up', 'out_for_delivery'].includes(order.status) && deliveryBoys.length > 0 && (
            <div className="card p-4 space-y-3">
              <h3 className="text-sm font-semibold text-dark-700">Assign Delivery Agent</h3>
              <select
                value={selectedDelivery}
                onChange={(e) => setSelectedDelivery(e.target.value)}
                className="input-field"
              >
                <option value="">Select delivery agent</option>
                {deliveryBoys.map((d) => (
                  <option key={d._id} value={d._id}>{d.name} · {d.phone}</option>
                ))}
              </select>
              <button
                onClick={() => { if (selectedDelivery) onAssignDelivery(selectedDelivery); }}
                disabled={!selectedDelivery}
                className="w-full btn-secondary disabled:opacity-50"
              >
                Assign Agent
              </button>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
