import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { XMarkIcon, ChevronDownIcon, EyeIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_ORDERS } from '../../graphql/queries.js';
import { UPDATE_RETURN_STATUS } from '../../graphql/mutations.js';
import clsx from 'clsx';
import useVerticalStore from '../../store/verticalStore.js';

const RETURN_STATUSES = ['requested', 'approved', 'rejected', 'refunded'];

export default function Returns() {
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [page, setPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_ORDERS, {
    variables: {
      vertical: activeVertical === 'all' ? undefined : activeVertical,
      pagination: { limit: 200 }, // fetching more since we filter client-side
    },
    fetchPolicy: 'cache-and-network',
  });

  const [updateReturnStatus, { loading: updating }] = useMutation(UPDATE_RETURN_STATUS, {
    onCompleted: () => { toast.success('Return status updated!'); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const allOrders = (data?.getAllOrders?.orders || []).filter(Boolean);
  
  // Filter only those with a return status that is not 'none' or null/undefined
  const returns = allOrders.filter(o => o.returnStatus && o.returnStatus !== 'none');

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Return Requests</h2>
          <p className="text-sm text-dark-500">{returns.length} return requests</p>
        </div>
      </div>

      {/* Returns Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Order</th>
                <th className="px-4 py-3 text-left">Customer</th>
                <th className="px-4 py-3 text-left">Return Reason</th>
                <th className="px-4 py-3 text-right">Amount</th>
                <th className="px-4 py-3 text-center">Return Status</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(5)].map((_, i) => (
                    <tr key={i}>
                      {[...Array(6)].map((_, j) => (
                        <td key={j} className="px-4 py-3"><div className="h-4 bg-dark-100 rounded animate-pulse" /></td>
                      ))}
                    </tr>
                  ))
                : returns.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="px-4 py-8 text-center text-dark-500">No return requests found.</td>
                    </tr>
                  )
                : returns.map((order) => (
                    <motion.tr
                      key={order._id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="hover:bg-dark-50/50 transition-colors"
                    >
                      <td className="px-4 py-3">
                        <button onClick={() => setSelectedOrder(order)} className="text-sm font-semibold text-primary-600 hover:underline">
                          #{order?.orderNumber || '—'}
                        </button>
                      </td>
                      <td className="px-4 py-3">
                        {order.customer ? (
                          <Link to={`/users/${order.customer._id}`} className="flex items-center gap-2 hover:bg-dark-50/50 p-1 rounded-lg transition-colors">
                            <img src={order.customer.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(order.customer.name || 'C')}`} alt="" className="w-7 h-7 rounded-full" />
                            <div>
                              <p className="text-xs font-medium text-dark-800">{order.customer.name}</p>
                              <p className="text-xs text-dark-400">{order.customer.email}</p>
                            </div>
                          </Link>
                        ) : (
                          <span className="text-xs text-dark-500">Unknown</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-700 max-w-xs truncate">
                        {order.returnReason || 'No reason provided'}
                      </td>
                      <td className="px-4 py-3 text-right text-sm font-semibold text-dark-900 font-mono">₹{order.total?.toLocaleString('en-IN')}</td>
                      <td className="px-4 py-3 text-center">
                        <select
                          value={order.returnStatus}
                          onChange={(e) => updateReturnStatus({ variables: { orderId: order._id, status: e.target.value } })}
                          disabled={updating}
                          className="input-field py-1 text-xs sm:w-32 inline-block capitalize"
                        >
                          <option value="requested">Requested</option>
                          <option value="approved">Approved</option>
                          <option value="rejected">Rejected</option>
                          <option value="refunded">Refunded</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                          title="View Details"
                        >
                          <EyeIcon className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                  ))
              }
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal (Simple viewer for the return) */}
      <AnimatePresence>
        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedOrder(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden"
            >
              <div className="bg-dark-50 px-6 py-4 border-b border-dark-100 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-dark-900">Return Request</h2>
                  <p className="text-xs text-dark-500">Order #{selectedOrder?.orderNumber || '—'}</p>
                </div>
                <button onClick={() => setSelectedOrder(null)}><XMarkIcon className="w-5 h-5 text-dark-400 hover:text-dark-900" /></button>
              </div>
              
              <div className="p-6 space-y-4">
                <div>
                  <h3 className="text-sm font-semibold text-dark-700 mb-1">Customer</h3>
                  <p className="text-sm text-dark-900">{selectedOrder.customer?.name} ({selectedOrder.customer?.email})</p>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-dark-700 mb-1">Return Reason</h3>
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-100">
                    <p className="text-sm text-amber-900">{selectedOrder.returnReason || 'No reason provided by the customer.'}</p>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-dark-700 mb-1">Current Status</h3>
                  <p className="text-sm capitalize font-medium text-dark-900">{selectedOrder.returnStatus}</p>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-dark-700 mb-1">Items</h3>
                  <ul className="space-y-2">
                    {selectedOrder.items?.map((item, idx) => (
                      <li key={idx} className="text-sm flex justify-between border-b border-dark-50 pb-1">
                        <span>{item.quantity}x {item.name}</span>
                        <span className="font-mono">₹{item.price * item.quantity}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="pt-2 flex justify-end gap-3">
                  <button onClick={() => setSelectedOrder(null)} className="btn-secondary">Close</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
