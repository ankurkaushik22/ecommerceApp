import { useState } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { GET_ANALYTICS, GET_DASHBOARD_STATS } from '../../graphql/queries.js';
import clsx from 'clsx';

const PERIOD_OPTIONS = [
  { label: 'Last 7 days', value: '7d' },
  { label: 'Last 30 days', value: '30d' },
  { label: 'Last 90 days', value: '90d' },
];

const PIE_COLORS = ['#6366f1', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 shadow-xl">
        <p className="text-dark-400 text-xs mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }} className="text-sm font-semibold">{p.name}: {typeof p.value === 'number' ? p.value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p.value}</p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  const [period, setPeriod] = useState('30d');

  const { data: analyticsData, loading } = useQuery(GET_ANALYTICS, { variables: { period } });
  const { data: dashboardData } = useQuery(GET_DASHBOARD_STATS);

  const analytics = analyticsData?.getAnalytics;
  const ordersByStatus = analytics?.ordersByStatus || [];
  const revenueByCategory = analytics?.revenueByCategory || [];
  const monthlyRevenue = analytics?.monthlyRevenue || [];

  const pieData = ordersByStatus.map((item, i) => ({
    name: item._id?.replace(/_/g, ' ') || 'unknown',
    value: item.count,
    color: PIE_COLORS[i % PIE_COLORS.length],
  }));

  const revChartData = revenueByCategory.map((item) => ({
    name: item._id || 'Other',
    revenue: Math.round(item.revenue),
  }));

  const dailyData = monthlyRevenue.map((item) => ({
    date: item._id,
    revenue: Math.round(item.revenue),
    orders: item.orders,
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Analytics</h2>
          <p className="text-sm text-dark-500">Store performance insights</p>
        </div>
        <div className="flex gap-2">
          {PERIOD_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setPeriod(opt.value)}
              className={clsx(
                'px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
                period === opt.value
                  ? 'bg-primary-600 text-white'
                  : 'bg-white text-dark-500 border border-dark-200 hover:border-primary-300'
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Revenue Over Time */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
        <h3 className="text-base font-semibold text-dark-900 mb-4">Revenue & Orders Over Time</h3>
        {loading ? (
          <div className="h-72 bg-dark-50 rounded-lg animate-pulse" />
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={dailyData}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Area type="monotone" dataKey="revenue" name="Revenue ($)" stroke="#6366f1" strokeWidth={2} fill="url(#revGrad)" />
              <Area type="monotone" dataKey="orders" name="Orders" stroke="#f59e0b" strokeWidth={2} fill="none" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Orders by Status Pie */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Orders by Status</h3>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={3} dataKey="value">
                  {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip formatter={(value, name) => [value, name]} />
                <Legend iconType="circle" iconSize={8} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </motion.div>

        {/* Revenue by Category */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Revenue by Category</h3>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={revChartData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} width={80} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="revenue" name="Revenue ($)" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </motion.div>
      </div>

      {/* Top Products Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="card">
        <div className="px-6 py-4 border-b border-dark-100">
          <h3 className="text-base font-semibold text-dark-900">Top Products by Sales</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium">
                <th className="px-6 py-3 text-left">#</th>
                <th className="px-6 py-3 text-left">Product</th>
                <th className="px-6 py-3 text-right">Price</th>
                <th className="px-6 py-3 text-right">Sales</th>
                <th className="px-6 py-3 text-right">Rating</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {(dashboardData?.getDashboardStats?.topProducts || []).map((product, i) => (
                <tr key={product._id} className="hover:bg-dark-50/50">
                  <td className="px-6 py-3 text-sm font-bold text-dark-400">#{i + 1}</td>
                  <td className="px-6 py-3">
                    <div className="flex items-center gap-3">
                      <img src={product.images?.[0]} alt={product.name} className="w-9 h-9 object-cover rounded-lg" />
                      <span className="text-sm font-medium text-dark-800 line-clamp-1">{product.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-3 text-right text-sm font-semibold text-dark-900">${product.price}</td>
                  <td className="px-6 py-3 text-right text-sm text-dark-600">{product.salesCount} sold</td>
                  <td className="px-6 py-3 text-right text-sm text-amber-500">⭐ {product.rating?.average?.toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
