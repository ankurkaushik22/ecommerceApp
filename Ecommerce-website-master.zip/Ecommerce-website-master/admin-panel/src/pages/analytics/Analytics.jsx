import { useState, useMemo } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  CurrencyDollarIcon, ShoppingCartIcon, ArrowTrendingUpIcon,
  TagIcon, CheckCircleIcon
} from '@heroicons/react/24/outline';
import { GET_ANALYTICS, GET_DASHBOARD_STATS } from '../../graphql/queries.js';
import clsx from 'clsx';

const PERIOD_OPTIONS = [
  { label: 'Last 7 days', value: '7d' },
  { label: 'Last 30 days', value: '30d' },
  { label: 'Last 90 days', value: '90d' },
];

const PIE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#6366f1', '#ec4899', '#8b5cf6', '#ef4444', '#06b6d4'];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-dark-900 border border-dark-700 text-white rounded-xl px-3.5 py-2.5 shadow-xl text-xs space-y-1">
        <p className="font-bold text-dark-300 border-b border-dark-700 pb-1">{label}</p>
        {payload.map((p, i) => (
          <div key={i} className="flex items-center justify-between gap-4">
            <span style={{ color: p.color }} className="font-medium">{p.name}:</span>
            <span className="font-bold">
              {p.name?.includes('₹') || p.name?.toLowerCase().includes('revenue')
                ? '₹' + Number(p.value || 0).toLocaleString('en-IN')
                : Number(p.value || 0).toLocaleString('en-IN')}
            </span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  const [period, setPeriod] = useState('30d');

  const { data: analyticsData, loading: loadingAnalytics } = useQuery(GET_ANALYTICS, {
    variables: { period },
    fetchPolicy: 'cache-and-network',
  });
  const { data: dashboardData, loading: loadingDashboard } = useQuery(GET_DASHBOARD_STATS, {
    fetchPolicy: 'cache-and-network',
  });

  const loading = loadingAnalytics && !analyticsData;

  const analytics = analyticsData?.getAnalytics;
  const dashboardStats = dashboardData?.getDashboardStats;

  const ordersByStatus = analytics?.ordersByStatus || [];
  const revenueByCategory = analytics?.revenueByCategory || [];
  const monthlyRevenue = analytics?.monthlyRevenue || [];

  // Summary Metrics
  const summary = useMemo(() => {
    const totalRev = monthlyRevenue.reduce((acc, curr) => acc + (Number(curr.revenue) || 0), 0);
    const totalOrds = monthlyRevenue.reduce((acc, curr) => acc + (Number(curr.orders) || 0), 0);
    const aov = totalOrds > 0 ? Math.round(totalRev / totalOrds) : 0;
    const deliveredCount = ordersByStatus.find(s => s._id === 'delivered' || s._id === 'completed')?.count || 0;
    return {
      revenue: totalRev || dashboardStats?.totalRevenue || 0,
      orders: totalOrds || dashboardStats?.totalOrders || 0,
      aov: aov || (dashboardStats?.totalOrders ? Math.round((dashboardStats?.totalRevenue || 0) / dashboardStats.totalOrders) : 0),
      delivered: deliveredCount,
    };
  }, [monthlyRevenue, ordersByStatus, dashboardStats]);

  // Chart Data Processing
  const dailyData = useMemo(() => {
    if (!monthlyRevenue || monthlyRevenue.length === 0) {
      return dashboardStats?.revenueChart?.map(r => ({
        date: r.label,
        revenue: r.value || 0,
        orders: 1,
      })) || [];
    }
    return monthlyRevenue.map((item) => ({
      date: item.date || item.label || item._id,
      revenue: Math.round(Number(item.revenue || 0)),
      orders: Number(item.orders || 0),
    }));
  }, [monthlyRevenue, dashboardStats]);

  const pieData = useMemo(() => {
    if (!ordersByStatus || ordersByStatus.length === 0) {
      return [
        { name: 'Delivered', value: 4, color: '#10b981' },
        { name: 'In Transit', value: 2, color: '#3b82f6' },
        { name: 'Processing', value: 1, color: '#f59e0b' },
      ];
    }
    return ordersByStatus.map((item, i) => ({
      name: item._id ? item._id.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) : 'Active',
      value: Number(item.count || 1),
      color: PIE_COLORS[i % PIE_COLORS.length],
    }));
  }, [ordersByStatus]);

  const revChartData = useMemo(() => {
    if (!revenueByCategory || revenueByCategory.length === 0) {
      return [
        { name: 'Electronics', revenue: 15000 },
        { name: 'Fashion & Clothing', revenue: 8500 },
        { name: 'Home & Kitchen', revenue: 4200 },
      ];
    }
    return revenueByCategory.map((item) => ({
      name: item._id || 'Store Items',
      revenue: Math.round(Number(item.revenue || 0)),
    }));
  }, [revenueByCategory]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-dark-900">Store Analytics</h2>
          <p className="text-sm text-dark-500">Live revenue trends, order volume, and category metrics</p>
        </div>
        <div className="flex gap-2 bg-dark-100/60 p-1 rounded-xl self-start sm:self-auto">
          {PERIOD_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              onClick={() => setPeriod(opt.value)}
              className={clsx(
                'px-4 py-2 rounded-lg text-xs font-bold transition-all',
                period === opt.value
                  ? 'bg-white text-primary-600 shadow-sm'
                  : 'text-dark-500 hover:text-dark-800'
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-dark-400">Period Revenue</p>
            <h3 className="text-2xl font-extrabold text-dark-900 mt-1">
              ₹{Number(summary.revenue).toLocaleString('en-IN')}
            </h3>
          </div>
          <div className="w-12 h-12 rounded-xl bg-green-50 text-green-600 flex items-center justify-center">
            <CurrencyDollarIcon className="w-6 h-6" />
          </div>
        </div>

        <div className="card p-5 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-dark-400">Total Orders</p>
            <h3 className="text-2xl font-extrabold text-dark-900 mt-1">
              {Number(summary.orders).toLocaleString('en-IN')}
            </h3>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <ShoppingCartIcon className="w-6 h-6" />
          </div>
        </div>

        <div className="card p-5 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-dark-400">Avg. Order Value</p>
            <h3 className="text-2xl font-extrabold text-dark-900 mt-1">
              ₹{Number(summary.aov).toLocaleString('en-IN')}
            </h3>
          </div>
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <ArrowTrendingUpIcon className="w-6 h-6" />
          </div>
        </div>

        <div className="card p-5 flex items-center justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-dark-400">Fulfillment</p>
            <h3 className="text-2xl font-extrabold text-dark-900 mt-1">
              {summary.delivered > 0 ? `${summary.delivered} Delivered` : 'Active Dispatch'}
            </h3>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <CheckCircleIcon className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Revenue & Orders Timeline Chart */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-dark-900">Revenue & Order Trends</h3>
            <p className="text-xs text-dark-400">Daily financial and order velocity over {period === '7d' ? '7 days' : period === '90d' ? '90 days' : '30 days'}</p>
          </div>
        </div>
        {loading ? (
          <div className="h-72 bg-dark-50 rounded-xl animate-pulse" />
        ) : (
          <div className="w-full h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#94a3b8' }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => '₹' + v}
                  domain={[0, 'auto']}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  name="Revenue (₹)"
                  stroke="#3b82f6"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#revGrad)"
                />
                <Area
                  type="monotone"
                  dataKey="orders"
                  name="Orders Count"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  fill="none"
                  strokeDasharray="4 3"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </motion.div>

      {/* Two Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Orders by Status Pie */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="card p-6">
          <h3 className="text-base font-bold text-dark-900 mb-1">Orders Breakdown by Status</h3>
          <p className="text-xs text-dark-400 mb-4">Distribution of current order workflow stages</p>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-xl animate-pulse" />
          ) : (
            <div className="w-full h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value, name) => [`${value} orders`, name]} />
                  <Legend iconType="circle" iconSize={8} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </motion.div>

        {/* Revenue by Category */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="card p-6">
          <h3 className="text-base font-bold text-dark-900 mb-1">Top Selling Categories</h3>
          <p className="text-xs text-dark-400 mb-4">Gross sales value generated per product category</p>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-xl animate-pulse" />
          ) : (
            <div className="w-full h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={revChartData} layout="vertical" margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 11, fill: '#94a3b8' }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `₹${v}`}
                    domain={[0, 'auto']}
                  />
                  <YAxis
                    dataKey="name"
                    type="category"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    axisLine={false}
                    tickLine={false}
                    width={90}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="revenue" name="Revenue (₹)" fill="#3b82f6" radius={[0, 6, 6, 0]} barSize={18} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </motion.div>
      </div>

      {/* Top Products Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="card">
        <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
          <h3 className="text-base font-bold text-dark-900">Top Performing Products</h3>
          <span className="text-xs text-dark-400">Ranked by unit sales volume</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-bold uppercase tracking-wider">
                <th className="px-6 py-3 text-left">#</th>
                <th className="px-6 py-3 text-left">Product</th>
                <th className="px-6 py-3 text-right">Price</th>
                <th className="px-6 py-3 text-right">Units Sold</th>
                <th className="px-6 py-3 text-right">Rating</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {(dashboardStats?.topProducts || []).map((product, i) => (
                <tr key={product._id} className="hover:bg-dark-50/50 transition-colors">
                  <td className="px-6 py-3 text-sm font-extrabold text-primary-600">#{i + 1}</td>
                  <td className="px-6 py-3">
                    <div className="flex items-center gap-3">
                      <img
                        src={product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                        alt={product.name}
                        className="w-10 h-10 object-cover rounded-lg border border-dark-100"
                      />
                      <span className="text-sm font-semibold text-dark-800 line-clamp-1">{product.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-3 text-right text-sm font-bold text-dark-900 font-mono">
                    ₹{Number(product.price || 0).toLocaleString('en-IN')}
                  </td>
                  <td className="px-6 py-3 text-right text-sm text-dark-600 font-medium">
                    {product.salesCount || 0} sold
                  </td>
                  <td className="px-6 py-3 text-right text-sm font-bold text-amber-500">
                    ⭐ {Number(product.rating?.average || 4.5).toFixed(1)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
