import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon, ChevronRightIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_CATEGORIES } from '../../graphql/queries.js';
import { CREATE_CATEGORY, UPDATE_CATEGORY, DELETE_CATEGORY } from '../../graphql/mutations.js';

export default function Categories() {
  const [showModal, setShowModal] = useState(false);
  const [editCategory, setEditCategory] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [parentFilter, setParentFilter] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_CATEGORIES);

  const [deleteCategory] = useMutation(DELETE_CATEGORY, {
    onCompleted: () => { toast.success('Category deleted'); setDeleteConfirm(null); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const allCategories = data?.getAllCategories || [];
  const rootCategories = allCategories.filter((c) => !c.parent);
  const displayCategories = parentFilter
    ? allCategories.filter((c) => c.parent?._id === parentFilter)
    : rootCategories;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Categories</h2>
          <p className="text-sm text-dark-500">{allCategories.length} categories total</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
          onClick={() => { setEditCategory(null); setShowModal(true); }}
          className="flex items-center gap-2 btn-primary"
        >
          <PlusIcon className="w-4 h-4" /> Add Category
        </motion.button>
      </div>

      {/* Breadcrumb Filter */}
      {parentFilter && (
        <div className="flex items-center gap-2 text-sm">
          <button onClick={() => setParentFilter(null)} className="text-primary-600 hover:underline">All Categories</button>
          <ChevronRightIcon className="w-4 h-4 text-dark-300" />
          <span className="text-dark-600">{allCategories.find((c) => c._id === parentFilter)?.name}</span>
        </div>
      )}

      {/* Categories Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {loading
          ? [...Array(8)].map((_, i) => (
              <div key={i} className="card p-4 animate-pulse">
                <div className="w-full h-32 bg-dark-100 rounded-lg mb-3" />
                <div className="h-4 bg-dark-100 rounded w-2/3 mb-2" />
                <div className="h-3 bg-dark-100 rounded w-1/2" />
              </div>
            ))
          : displayCategories.map((cat) => (
              <motion.div
                key={cat._id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="card overflow-hidden group hover:shadow-md transition-shadow"
              >
                <div className="relative h-36 overflow-hidden bg-gradient-to-br from-dark-100 to-dark-200">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  <div className="absolute bottom-2 left-3 text-2xl">{cat.icon}</div>
                  <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${cat.isActive ? 'bg-green-400' : 'bg-red-400'}`} />
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="text-sm font-semibold text-dark-800">{cat.name}</h3>
                      {cat.parent && (
                        <p className="text-xs text-dark-400 mt-0.5">Under: {cat.parent.name}</p>
                      )}
                      {cat.children?.length > 0 && (
                        <button
                          onClick={() => setParentFilter(cat._id)}
                          className="text-xs text-primary-600 hover:underline mt-1 block"
                        >
                          {cat.children.length} subcategories →
                        </button>
                      )}
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <button
                        onClick={() => { setEditCategory(cat); setShowModal(true); }}
                        className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                      >
                        <PencilIcon className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(cat)}
                        className="p-1.5 text-dark-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <TrashIcon className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
        }
      </div>

      {/* Category Form Modal */}
      <AnimatePresence>
        {showModal && (
          <CategoryModal
            category={editCategory}
            categories={allCategories}
            onClose={() => setShowModal(false)}
            onSuccess={() => { setShowModal(false); refetch(); }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirm */}
      <AnimatePresence>
        {deleteConfirm && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
              className="bg-white rounded-xl p-6 max-w-sm w-full"
            >
              <h3 className="text-lg font-semibold text-dark-900 mb-2">Delete "{deleteConfirm.name}"?</h3>
              <p className="text-sm text-dark-500 mb-6">All subcategories will be moved to root level.</p>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 btn-secondary">Cancel</button>
                <button onClick={() => deleteCategory({ variables: { id: deleteConfirm._id } })} className="flex-1 btn-danger">Delete</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CategoryModal({ category, categories, onClose, onSuccess }) {
  const isEdit = !!category;
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: category
      ? { name: category.name, description: category.description, image: category.image, icon: category.icon, parentId: category.parent?._id || '', sortOrder: category.sortOrder, isActive: category.isActive }
      : { icon: '🛍️', sortOrder: 0, isActive: true },
  });

  const [createCategory, { loading: creating }] = useMutation(CREATE_CATEGORY, {
    onCompleted: () => { toast.success('Category created!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });
  const [updateCategory, { loading: updating }] = useMutation(UPDATE_CATEGORY, {
    onCompleted: () => { toast.success('Category updated!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });

  const loading = creating || updating;
  const rootCategories = categories.filter((c) => !c.parent && c._id !== category?._id);

  const onSubmit = (data) => {
    const input = { ...data, sortOrder: parseInt(data.sortOrder) || 0, parentId: data.parentId || null };
    if (isEdit) updateCategory({ variables: { id: category._id, input } });
    else createCategory({ variables: { input } });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-xl w-full max-w-md shadow-2xl overflow-hidden"
      >
        <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold">{isEdit ? 'Edit Category' : 'Add Category'}</h2>
          <button onClick={onClose}><XMarkIcon className="w-5 h-5 text-dark-400" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Name *</label>
              <input {...register('name', { required: 'Required' })} className="input-field" />
              {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Icon (emoji)</label>
              <input {...register('icon')} className="input-field text-2xl" placeholder="🛍️" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Parent Category</label>
            <select {...register('parentId')} className="input-field">
              <option value="">None (Root)</option>
              {rootCategories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Image URL</label>
            <input {...register('image')} className="input-field" placeholder="https://..." />
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Description</label>
            <textarea {...register('description')} rows={2} className="input-field resize-none" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Sort Order</label>
              <input {...register('sortOrder')} type="number" className="input-field" />
            </div>
            <div className="flex items-end pb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input {...register('isActive')} type="checkbox" className="w-4 h-4 text-primary-600 rounded" />
                <span className="text-sm text-dark-700">Active</span>
              </label>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 btn-primary">
              {loading ? 'Saving...' : isEdit ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
