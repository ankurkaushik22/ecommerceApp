import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion, AnimatePresence } from 'framer-motion';
import { EyeIcon, EyeSlashIcon, BuildingStorefrontIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { LOGIN, SEND_LOGIN_OTP, LOGIN_WITH_OTP } from '../../graphql/mutations.js';
import useAuthStore from '../../store/authStore.js';

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [loginMethod, setLoginMethod] = useState('password'); // 'password' or 'otp'
  const [otpSent, setOtpSent] = useState(false);
  const [otpEmail, setOtpEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');

  const navigate = useNavigate();
  const { login } = useAuthStore();

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');
      const refreshToken = params.get('refreshToken') || '';
      const userParam = params.get('user');
      const isVerificationPending = params.get('verificationPending') === 'true';

      if (token && userParam) {
        const userObj = JSON.parse(decodeURIComponent(userParam));
        login(userObj, token, refreshToken);
        if (isVerificationPending) {
          toast.success('Business account created! Account verification is in progress.', { duration: 6000 });
        } else {
          toast.success(`Welcome back, ${userObj.name}! 👋`);
        }
        navigate('/dashboard', { replace: true });
      }
    } catch (e) {
      console.error('Direct login error:', e);
    }
  }, [login, navigate]);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    defaultValues: { email: '', password: '' }
  });

  const handleLoginSuccess = (user, token, refreshToken) => {
    // Allow all staff/administrative/vendor/delivery/custom roles (only exclude customers)
    if (user.role === 'customer' || user.isActive === false) {
      setErrorMessage('Access denied. This account does not have staff or administrative permissions.');
      toast.error('Access denied. Staff & admin accounts only.');
      return;
    }

    login(user, token, refreshToken);
    toast.success(`Welcome back, ${user.name}! 👋`);
    
    // Redirect to appropriate landing page
    if (user.role === 'delivery') {
      navigate('/orders');
    } else {
      navigate('/dashboard');
    }
  };

  const [loginMutation, { loading }] = useMutation(LOGIN, {
    onCompleted: (data) => {
      const { token, refreshToken, user } = data.login;
      handleLoginSuccess(user, token, refreshToken);
    },
    onError: (err) => {
      const msg =
        err.message?.includes('credentials') ||
        err.message?.includes('password') ||
        err.message?.includes('found') ||
        err.message?.includes('User')
          ? 'Invalid username or password. Please try again.'
          : err.message || 'Invalid username or password';
      setErrorMessage(msg);
      toast.error(msg);
    },
  });

  const [sendOtpMutation, { loading: sendingOtp }] = useMutation(SEND_LOGIN_OTP, {
    onCompleted: (data) => {
      toast.success(data.sendLoginOTP.message || 'OTP sent successfully');
      setOtpSent(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to send OTP');
      toast.error(err.message || 'Failed to send OTP');
    }
  });

  const [loginOtpMutation, { loading: loggingInOtp }] = useMutation(LOGIN_WITH_OTP, {
    onCompleted: (data) => {
      const { token, refreshToken, user } = data.loginWithOTP;
      handleLoginSuccess(user, token, refreshToken);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Invalid OTP');
      toast.error(err.message || 'Invalid OTP');
    }
  });

  const onSubmit = (data, e) => {
    e?.preventDefault?.();
    setErrorMessage('');
    loginMutation({ variables: { input: data } });
  };

  const handleSendOtp = (e) => {
    e.preventDefault();
    if (!otpEmail) {
      setErrorMessage('Please enter your email');
      return;
    }
    setErrorMessage('');
    sendOtpMutation({ variables: { email: otpEmail } });
  };

  const handleLoginOtp = (e) => {
    e.preventDefault();
    if (!otpCode) {
      setErrorMessage('Please enter the OTP');
      return;
    }
    setErrorMessage('');
    loginOtpMutation({ variables: { email: otpEmail, otp: otpCode } });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-900 via-dark-800 to-primary-900 flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-primary-700/10 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md relative"
      >
        {/* Card */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100">
          {/* Logo */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.1 }}
            className="flex flex-col items-center mb-6"
          >
            <div className="w-16 h-16 bg-gradient-to-br from-primary-500 to-primary-700 rounded-2xl flex items-center justify-center mb-3 shadow-lg shadow-primary-500/30">
              <BuildingStorefrontIcon className="w-9 h-9 text-white" />
            </div>
            <h1 className="text-2xl font-extrabold text-dark-900">Suaaka Portal</h1>
            <p className="text-dark-500 text-xs mt-1">Management & Staff Access Console</p>
          </motion.div>

          {/* Security badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2 mb-5"
          >
            <ShieldCheckIcon className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span className="text-[11px] text-emerald-800 font-semibold">
              Authorized Portal — Super Admin, Admin, Vendor & Delivery
            </span>
          </motion.div>

          {/* Error Message Banner */}
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 mb-4 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <span className="text-rose-500 font-bold">⚠️</span>
              <span>{errorMessage}</span>
            </motion.div>
          )}

          {/* Method Toggle */}
          <div className="flex bg-gray-100 p-1 rounded-xl mb-6">
            <button
              onClick={() => setLoginMethod('password')}
              className={`flex-1 text-xs font-bold py-2 rounded-lg transition-all ${
                loginMethod === 'password' ? 'bg-white shadow-sm text-dark-900' : 'text-dark-500 hover:text-dark-700'
              }`}
            >
              Password
            </button>
            <button
              onClick={() => setLoginMethod('otp')}
              className={`flex-1 text-xs font-bold py-2 rounded-lg transition-all ${
                loginMethod === 'otp' ? 'bg-white shadow-sm text-dark-900' : 'text-dark-500 hover:text-dark-700'
              }`}
            >
              OTP
            </button>
          </div>

          {/* Form */}
          {loginMethod === 'password' ? (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
                <label className="block text-xs font-bold text-dark-700 mb-1">Email Address</label>
                <input
                  {...register('email', {
                    required: 'Email is required',
                    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Enter a valid email' },
                  })}
                  type="email"
                  placeholder="admin@shopzone.com"
                  className="input-field text-xs"
                  autoComplete="email"
                />
                {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email.message}</p>}
              </motion.div>

              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.4 }}>
                <label className="block text-xs font-bold text-dark-700 mb-1">Password</label>
                <div className="relative">
                  <input
                    {...register('password', { required: 'Password is required' })}
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="input-field text-xs pr-10"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-dark-400 hover:text-dark-600"
                  >
                    {showPassword ? <EyeSlashIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-xs text-red-500">{errors.password.message}</p>}
              </motion.div>

              <motion.button
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
                whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-primary-500/30 hover:from-primary-700 hover:to-primary-800 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Authenticating...
                  </>
                ) : (
                  'Sign In to Portal'
                )}
              </motion.button>
            </form>
          ) : (
            <form onSubmit={otpSent ? handleLoginOtp : handleSendOtp} className="space-y-4">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 }}>
                <label className="block text-xs font-bold text-dark-700 mb-1">Email Address</label>
                <input
                  type="email"
                  value={otpEmail}
                  onChange={(e) => setOtpEmail(e.target.value)}
                  placeholder="admin@shopzone.com"
                  className="input-field text-xs"
                  required
                  disabled={otpSent}
                />
              </motion.div>

              {otpSent && (
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                  <label className="block text-xs font-bold text-dark-700 mb-1">OTP Code</label>
                  <input
                    type="text"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="Enter 6-digit OTP"
                    className="input-field text-xs tracking-widest"
                    required
                  />
                </motion.div>
              )}

              <motion.button
                initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}
                whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}
                type="submit"
                disabled={sendingOtp || loggingInOtp}
                className="w-full py-3 px-4 bg-gradient-to-r from-primary-600 to-primary-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-primary-500/30 hover:from-primary-700 hover:to-primary-800 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {sendingOtp || loggingInOtp ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing...
                  </>
                ) : otpSent ? (
                  'Login with OTP'
                ) : (
                  'Send OTP'
                )}
              </motion.button>

              {otpSent && (
                <button
                  type="button"
                  onClick={() => { setOtpSent(false); setOtpCode(''); }}
                  className="w-full text-xs text-primary-600 hover:text-primary-700 font-semibold mt-2"
                >
                  Change Email or Resend OTP
                </button>
              )}
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
