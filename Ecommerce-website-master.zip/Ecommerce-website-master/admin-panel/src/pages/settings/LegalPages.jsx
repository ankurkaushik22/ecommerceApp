import { useState } from 'react';
import { gql, useQuery, useMutation } from '@apollo/client';
import { toast } from 'react-hot-toast';

const GET_LEGAL_PAGES = gql`
  query GetLegalPages {
    getLegalPages {
      _id
      slug
      title
      content
      version
      updatedAt
      updatedBy {
        name
      }
    }
  }
`;

const UPDATE_LEGAL_PAGE = gql`
  mutation UpdateLegalPage($slug: String!, $title: String!, $content: String!) {
    updateLegalPage(slug: $slug, title: $title, content: $content) {
      _id
      slug
      title
      content
      version
      updatedAt
    }
  }
`;

export default function LegalPages() {
  const { data, loading, error, refetch } = useQuery(GET_LEGAL_PAGES);
  const [updateLegalPage] = useMutation(UPDATE_LEGAL_PAGE);

  const [editingSlug, setEditingSlug] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');

  if (loading) return <div className="p-6">Loading...</div>;
  if (error) return <div className="p-6 text-red-500">Error loading legal pages.</div>;

  const pages = data?.getLegalPages || [];

  // If pages are not found, we can mock them or let backend return empty. Assuming backend has them.
  // We'll filter the list for terms-and-conditions and privacy-policy.
  const displayPages = [
    pages.find(p => p.slug === 'terms-and-conditions') || { slug: 'terms-and-conditions', title: 'Terms & Conditions', content: '' },
    pages.find(p => p.slug === 'privacy-policy') || { slug: 'privacy-policy', title: 'Privacy Policy', content: '' }
  ];

  const handleEdit = (page) => {
    setEditingSlug(page.slug);
    setEditTitle(page.title);
    setEditContent(page.content);
  };

  const handleSave = async (slug) => {
    try {
      await updateLegalPage({
        variables: {
          slug,
          title: editTitle,
          content: editContent,
        },
      });
      toast.success('Legal page updated successfully');
      setEditingSlug(null);
      refetch();
    } catch (err) {
      toast.error('Failed to update legal page');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-dark-900">Legal Pages</h1>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {displayPages.map((page) => (
          <div key={page.slug} className="card p-6 bg-white border border-gray-100 rounded-3xl shadow-sm">
            {editingSlug === page.slug ? (
              <div className="space-y-4">
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="input-field w-full font-bold text-lg"
                  placeholder="Page Title"
                />
                <textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  rows={20}
                  className="input-field w-full font-mono text-sm"
                  placeholder="HTML Content..."
                />
                <div className="flex justify-end gap-3">
                  <button
                    onClick={() => setEditingSlug(null)}
                    className="btn-secondary px-4 py-2 text-sm"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleSave(page.slug)}
                    className="btn-primary px-4 py-2 text-sm"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">{page.title}</h3>
                  <div className="text-xs text-dark-500 mt-1 flex gap-4">
                    <span>Version: {page.version || 1}</span>
                    {page.updatedAt && (
                      <span>Last Updated: {new Date(page.updatedAt).toLocaleDateString()}</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleEdit(page)}
                  className="btn-secondary px-4 py-2 text-sm"
                >
                  Edit
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
