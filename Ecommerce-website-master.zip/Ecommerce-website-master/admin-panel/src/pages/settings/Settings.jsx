import { useState, useEffect } from 'react';
import { useSearchParams, useLocation } from 'react-router-dom';
import { useQuery, useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { UPDATE_PROFILE, CHANGE_PASSWORD, UPDATE_STORE_SETTINGS, UPDATE_VENDOR_BANK_DETAILS } from '../../graphql/mutations.js';
import { GET_STORE_SETTINGS, GET_VENDOR_BANK_DETAILS } from '../../graphql/queries.js';
import useAuthStore from '../../store/authStore.js';
import clsx from 'clsx';
import ImageUpload from '../../components/common/ImageUpload';

const TABS = ['Profile', 'Security', 'Bank Details', 'Payment', 'Notifications', 'Branding', 'Super Categories'];

export default function Settings() {
  const [searchParams, setSearchParams] = useSearchParams();
  const location = useLocation();
  const { user, updateUser } = useAuthStore();
  const [disabledVerticals, setDisabledVerticals] = useState([]);

  const isAdminOrSuperAdmin = user?.role === 'superadmin' || user?.role === 'admin';
  const visibleTabs = isAdminOrSuperAdmin
    ? ['Profile', 'Security', 'Bank Details', 'Payment', 'Notifications', 'Branding', 'Super Categories']
    : ['Profile', 'Security', 'Bank Details'];

  const initialTab = searchParams.get('tab') || location.state?.tab || 'Profile';
  const [activeTab, setActiveTab] = useState(visibleTabs.includes(initialTab) ? initialTab : 'Profile');

  useEffect(() => {
    const currentTab = searchParams.get('tab') || location.state?.tab;
    if (currentTab && visibleTabs.includes(currentTab)) {
      setActiveTab(currentTab);
    }
  }, [searchParams, location.state]);

  useEffect(() => {
    if (!visibleTabs.includes(activeTab)) {
      setActiveTab('Profile');
    }
  }, [user?.role, activeTab]);

  const { register: regProfile, handleSubmit: handleProfile, setValue, watch: watchProfile, formState: { errors: profileErrors } } = useForm({
    defaultValues: { name: user?.name, phone: user?.phone, avatar: user?.avatar },
  });
  const { register: regPass, handleSubmit: handlePass, reset: resetPass } = useForm();

  const [updateProfile, { loading: updatingProfile }] = useMutation(UPDATE_PROFILE, {
    onCompleted: (d) => { updateUser(d.updateProfile); toast.success('Profile updated!'); },
    onError: (e) => toast.error(e.message),
  });
  const [changePassword, { loading: changingPass }] = useMutation(CHANGE_PASSWORD, {
    onCompleted: () => { toast.success('Password changed!'); resetPass(); },
    onError: (e) => toast.error(e.message),
  });

  const onProfileSubmit = (data) => updateProfile({ variables: data });
  const onPassSubmit = (data) => {
    if (data.newPassword !== data.confirmPassword) { toast.error("Passwords don't match"); return; }
    changePassword({ variables: { currentPassword: data.currentPassword, newPassword: data.newPassword } });
  };

  const { data: storeSettingsData, refetch: refetchStoreSettings } = useQuery(GET_STORE_SETTINGS);
  const { register: regBrand, handleSubmit: handleBrand, setValue: setBrandValue, watch: watchBrand, reset: resetBrand } = useForm();
  
  useEffect(() => {
    if (storeSettingsData?.getStoreSettings) {
      resetBrand({
        storeName: storeSettingsData.getStoreSettings.storeName || '',
        logoUrl: storeSettingsData.getStoreSettings.logoUrl || '',
        faviconUrl: storeSettingsData.getStoreSettings.faviconUrl || '',
        appIconUrl: storeSettingsData.getStoreSettings.appIconUrl || '',
        serviceBookingMode: storeSettingsData.getStoreSettings.serviceBookingMode || 'call_now',
        serviceContactPhone: storeSettingsData.getStoreSettings.serviceContactPhone || '+91 98765 43210',
      });
      setDisabledVerticals(storeSettingsData.getStoreSettings.disabledVerticals || []);
    }
  }, [storeSettingsData, resetBrand]);

  const [updateStoreSettings, { loading: updatingBranding }] = useMutation(UPDATE_STORE_SETTINGS, {
    onCompleted: () => {
      toast.success('Settings updated!');
      refetchStoreSettings();
    },
    onError: (e) => toast.error(e.message),
  });

  const onBrandSubmit = (data) => {
    updateStoreSettings({ variables: { ...data, disabledVerticals } });
  };

  const { data: bankData, refetch: refetchBank } = useQuery(GET_VENDOR_BANK_DETAILS, {
    fetchPolicy: 'cache-and-network',
  });

  const [bankName, setBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [upiId, setUpiId] = useState('');

  useEffect(() => {
    const details = bankData?.getVendorBankDetails || user?.bankDetails;
    if (details) {
      setBankName(details.bankName || '');
      setAccountHolderName(details.accountHolderName || '');
      setAccountNumber(details.accountNumber || '');
      setIfscCode(details.ifscCode || '');
      setUpiId(details.upiId || '');
    }
  }, [bankData, user?.bankDetails]);

  const [updateBankMutation, { loading: savingBank }] = useMutation(UPDATE_VENDOR_BANK_DETAILS, {
    onCompleted: (d) => {
      toast.success('Bank & UPI details saved successfully!');
      if (user) {
        updateUser({
          ...user,
          bankDetails: d.updateVendorBankDetails,
        });
      }
      refetchBank();
    },
    onError: (e) => toast.error(e.message),
  });

  const handleBankSubmit = (e) => {
    e.preventDefault();
    updateBankMutation({
      variables: {
        input: {
          bankName: bankName.trim(),
          accountHolderName: accountHolderName.trim(),
          accountNumber: accountNumber.trim(),
          ifscCode: ifscCode.trim().toUpperCase(),
          upiId: upiId.trim().toLowerCase(),
        },
      },
    });
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold text-dark-900">Settings</h2>
        <p className="text-sm text-dark-500">Manage your account and preferences</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-dark-200 flex gap-0">
        {visibleTabs.map((tab) => (
          <button
            key={tab}
            onClick={() => {
              setActiveTab(tab);
              setSearchParams({ tab });
            }}
            className={clsx(
              'px-4 py-2.5 text-sm font-medium border-b-2 transition-colors cursor-pointer',
              activeTab === tab
                ? 'border-primary-600 text-primary-600'
                : 'border-transparent text-dark-400 hover:text-dark-700'
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Profile Tab */}
      {activeTab === 'Profile' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-6">Profile Information</h3>
          <form onSubmit={handleProfile(onProfileSubmit, (errors) => {
            if (errors.phone) toast.error(errors.phone.message);
          })} className="space-y-4">
            {/* Avatar */}
            <div className="flex items-center gap-4 mb-6">
              <img src={user?.avatar} alt={user?.name} className="w-16 h-16 rounded-full border-4 border-dark-100" />
              <div>
                <p className="text-sm font-semibold text-dark-800">{user?.name}</p>
                <p className="text-xs text-dark-400 capitalize">{user?.role} · {user?.email}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Full Name</label>
              <input {...regProfile('name')} className="input-field" />
            </div>
            <div>
              <label className={clsx('block text-sm font-medium mb-1', profileErrors.phone ? 'text-red-600' : 'text-dark-700')}>Phone</label>
              <input 
                {...regProfile('phone', { required: 'Please fill mobile number first' })} 
                className={clsx('input-field transition-colors', profileErrors.phone && 'border-red-500 bg-red-50 focus:border-red-500 focus:ring-red-200')} 
                placeholder="+1-555-0100" 
              />
            </div>
            <div>
              <ImageUpload
                label="Avatar Image"
                value={watchProfile('avatar') || ''}
                onChange={(url) => {
                  setValue('avatar', url, { shouldDirty: true });
                }}
              />
            </div>
            <div className="pt-2">
              <button type="submit" disabled={updatingProfile} className="btn-primary">
                {updatingProfile ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Bank Details Tab */}
      {activeTab === 'Bank Details' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <div className="flex items-center justify-between mb-4 border-b border-dark-100 pb-3">
            <div>
              <h3 className="text-base font-bold text-dark-900">Bank Account & UPI Details</h3>
              <p className="text-xs text-dark-500">Provide your payout bank account and UPI details for manual earnings transfer</p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              🏦 Payout Account
            </span>
          </div>

          <form onSubmit={handleBankSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-dark-700 mb-1">Bank Name</label>
                <input
                  type="text"
                  placeholder="e.g. State Bank of India / HDFC"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="input-field text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-dark-700 mb-1">Account Holder Name</label>
                <input
                  type="text"
                  placeholder="e.g. John Doe / Store Name"
                  value={accountHolderName}
                  onChange={(e) => setAccountHolderName(e.target.value)}
                  className="input-field text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-dark-700 mb-1">Account Number</label>
                <input
                  type="text"
                  placeholder="e.g. 12345678901234"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  className="input-field text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-dark-700 mb-1">IFSC Code</label>
                <input
                  type="text"
                  placeholder="e.g. SBIN0001234"
                  value={ifscCode}
                  onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                  className="input-field text-xs font-mono uppercase"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-dark-700 mb-1">UPI ID (VPA)</label>
              <input
                type="text"
                placeholder="e.g. name@upi or mobile@paytm"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value.toLowerCase())}
                className="input-field text-xs font-mono"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={savingBank}
                className="btn-primary text-xs font-bold cursor-pointer"
              >
                {savingBank ? 'Saving Details...' : 'Save Bank & UPI Details'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Security Tab */}
      {activeTab === 'Security' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-6">Change Password</h3>
          <form onSubmit={handlePass(onPassSubmit)} className="space-y-4 max-w-sm">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Current Password</label>
              <input {...regPass('currentPassword', { required: true })} type="password" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">New Password</label>
              <input {...regPass('newPassword', { required: true, minLength: 6 })} type="password" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Confirm New Password</label>
              <input {...regPass('confirmPassword', { required: true })} type="password" className="input-field" />
            </div>
            <button type="submit" disabled={changingPass} className="btn-primary">
              {changingPass ? 'Changing...' : 'Change Password'}
            </button>
          </form>
        </motion.div>
      )}

      {/* Payment Tab */}
      {activeTab === 'Payment' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Payment Configuration</h3>
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm font-medium text-amber-800 mb-1">⚠️ Stripe Integration</p>
              <p className="text-xs text-amber-700">Add your Stripe keys to the backend <code className="bg-amber-100 px-1 rounded">.env</code> file to enable live payments.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Stripe Mode</label>
              <select className="input-field w-48">
                <option value="test">Test Mode</option>
                <option value="live">Live Mode</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Supported Methods</label>
              <div className="flex gap-3 flex-wrap">
                {['💳 Stripe Card', '💵 Cash on Delivery'].map((m) => (
                  <span key={m} className="badge-success px-3 py-1 text-sm">{m}</span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'Notifications' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Notification Preferences</h3>
          <div className="space-y-4">
            {[
              { label: 'New Order Notifications', desc: 'Get notified when a new order is placed' },
              { label: 'Low Stock Alerts', desc: 'Alert when product stock falls below 10' },
              { label: 'Review Notifications', desc: 'Get notified for new product reviews' },
              { label: 'Payment Alerts', desc: 'Notifications for payment events' },
            ].map((item) => (
              <div key={item.label} className="flex items-start justify-between p-3 rounded-lg hover:bg-dark-50 transition-colors">
                <div>
                  <p className="text-sm font-medium text-dark-800">{item.label}</p>
                  <p className="text-xs text-dark-400">{item.desc}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer ml-4">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-10 h-5 bg-dark-200 rounded-full peer peer-checked:bg-primary-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-5" />
                </label>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Branding Tab */}
      {activeTab === 'Branding' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-6">Store Branding</h3>
          <form onSubmit={handleBrand(onBrandSubmit)} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Store Name</label>
              <input {...regBrand('storeName', { required: 'Store Name is required' })} className="input-field" placeholder="My Store" />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <ImageUpload
                  label="Store Logo"
                  value={watchBrand('logoUrl') || ''}
                  onChange={(url) => setBrandValue('logoUrl', url, { shouldDirty: true })}
                />
              </div>
              
              <div>
                <ImageUpload
                  label="Favicon (Website Icon)"
                  value={watchBrand('faviconUrl') || ''}
                  onChange={(url) => setBrandValue('faviconUrl', url, { shouldDirty: true })}
                />
              </div>
              
              <div>
                <ImageUpload
                  label="App Icon (Mobile)"
                  value={watchBrand('appIconUrl') || ''}
                  onChange={(url) => setBrandValue('appIconUrl', url, { shouldDirty: true })}
                />
              </div>
            </div>

            <div className="border-t border-dark-200 pt-6 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-dark-900 mb-1">Services Action Mode</h4>
                <p className="text-xs text-dark-500">Choose whether customers call directly or book online for Services.</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-700 mb-2">Booking Mode</label>
                <div className="flex gap-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="call_now"
                      {...regBrand('serviceBookingMode')}
                      className="text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-sm font-medium text-dark-800">Call Now (Direct Call)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="book_now"
                      {...regBrand('serviceBookingMode')}
                      className="text-primary-600 focus:ring-primary-500"
                    />
                    <span className="text-sm font-medium text-dark-800">Book Now (Cart Booking)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-700 mb-1">Service Contact Phone Number</label>
                <input
                  {...regBrand('serviceContactPhone')}
                  className="input-field max-w-md"
                  placeholder="+91 98765 43210"
                />
                <p className="text-xs text-dark-400 mt-1">Number dialed when customer clicks "Call Now".</p>
              </div>
            </div>
            
            <div className="pt-2">
              <button type="submit" disabled={updatingBranding} className="btn-primary">
                {updatingBranding ? 'Saving...' : 'Save Settings'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Super Categories Tab */}
      {activeTab === 'Super Categories' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-dark-900">Super Categories (Verticals) Management</h3>
            <p className="text-xs text-dark-500 mt-1">
              Enable or disable entire super categories (Shopping, Food Delivery, Grocery, Services) across the store, website, and mobile app.
            </p>
          </div>

          <div className="space-y-4 divide-y divide-dark-100">
            {[
              { id: 'shopping', label: 'Shopping (Retail)', icon: '🛍️', desc: 'Apparel, Electronics, Books, Beauty, Home & General Retail' },
              { id: 'food', label: 'Food Delivery', icon: '🍔', desc: 'Restaurants, Fast Food, Cafes, Biryani & Food Items' },
              { id: 'grocery', label: 'Grocery (Fresh)', icon: '🥦', desc: 'Fresh Fruits, Vegetables, Dairy, Meat & Everyday Staples' },
              { id: 'services', label: 'Services', icon: '🛠️', desc: 'Home Maintenance, Appliance Repair, Cleaning, Salon & Spa' },
            ].map((v) => {
              const isDisabled = disabledVerticals.includes(v.id);
              return (
                <div key={v.id} className="pt-4 first:pt-0 flex items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl p-2 rounded-xl bg-dark-50 border border-dark-100">{v.icon}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-dark-900">{v.label}</h4>
                        <span className={clsx(
                          'text-[10px] font-bold px-2 py-0.5 rounded-md uppercase',
                          isDisabled ? 'bg-rose-100 text-rose-700 border border-rose-200' : 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                        )}>
                          {isDisabled ? 'Disabled (Inactive)' : 'Active (Enabled)'}
                        </span>
                      </div>
                      <p className="text-xs text-dark-500 mt-0.5">{v.desc}</p>
                    </div>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
                    <input
                      type="checkbox"
                      checked={!isDisabled}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setDisabledVerticals((prev) => prev.filter((id) => id !== v.id));
                        } else {
                          setDisabledVerticals((prev) => [...prev, v.id]);
                        }
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500" />
                  </label>
                </div>
              );
            })}
          </div>

          <div className="pt-4 border-t border-dark-100">
            <button
              type="button"
              disabled={updatingBranding}
              onClick={() => {
                updateStoreSettings({ variables: { disabledVerticals } });
              }}
              className="btn-primary"
            >
              {updatingBranding ? 'Saving Settings...' : 'Save Super Category Settings'}
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
