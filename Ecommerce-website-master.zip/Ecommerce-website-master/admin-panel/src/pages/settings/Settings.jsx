import { useState } from 'react';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import { UPDATE_PROFILE, CHANGE_PASSWORD } from '../../graphql/mutations.js';
import useAuthStore from '../../store/authStore.js';
import clsx from 'clsx';

const TABS = ['Profile', 'Security', 'Payment', 'Notifications'];

export default function Settings() {
  const [activeTab, setActiveTab] = useState('Profile');
  const { user, updateUser } = useAuthStore();

  const { register: regProfile, handleSubmit: handleProfile } = useForm({
    defaultValues: { name: user?.name, phone: user?.phone, avatar: user?.avatar },
  });
  const { register: regPass, handleSubmit: handlePass, reset: resetPass } = useForm();

  const [updateProfile, { loading: updatingProfile }] = useMutation(UPDATE_PROFILE, {
    onCompleted: (d) => { updateUser(d.updateProfile); toast.success('Profile updated!'); },
    onError: (e) => toast.error(e.message),
  });
  const [changePassword, { loading: changingPass }] = useMutation(CHANGE_PASSWORD, {
    onCompleted: () => { toast.success('Password changed!'); resetPass(); },
    onError: (e) => toast.error(e.message),
  });

  const onProfileSubmit = (data) => updateProfile({ variables: data });
  const onPassSubmit = (data) => {
    if (data.newPassword !== data.confirmPassword) { toast.error("Passwords don't match"); return; }
    changePassword({ variables: { currentPassword: data.currentPassword, newPassword: data.newPassword } });
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold text-dark-900">Settings</h2>
        <p className="text-sm text-dark-500">Manage your account and preferences</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-dark-200 flex gap-0">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={clsx(
              'px-4 py-2.5 text-sm font-medium border-b-2 transition-colors',
              activeTab === tab
                ? 'border-primary-600 text-primary-600'
                : 'border-transparent text-dark-400 hover:text-dark-700'
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Profile Tab */}
      {activeTab === 'Profile' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-6">Profile Information</h3>
          <form onSubmit={handleProfile(onProfileSubmit)} className="space-y-4">
            {/* Avatar */}
            <div className="flex items-center gap-4 mb-6">
              <img src={user?.avatar} alt={user?.name} className="w-16 h-16 rounded-full border-4 border-dark-100" />
              <div>
                <p className="text-sm font-semibold text-dark-800">{user?.name}</p>
                <p className="text-xs text-dark-400 capitalize">{user?.role} · {user?.email}</p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Full Name</label>
              <input {...regProfile('name')} className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Phone</label>
              <input {...regProfile('phone')} className="input-field" placeholder="+1-555-0100" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Avatar URL</label>
              <input {...regProfile('avatar')} className="input-field" placeholder="https://..." />
            </div>
            <div className="pt-2">
              <button type="submit" disabled={updatingProfile} className="btn-primary">
                {updatingProfile ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Security Tab */}
      {activeTab === 'Security' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-6">Change Password</h3>
          <form onSubmit={handlePass(onPassSubmit)} className="space-y-4 max-w-sm">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Current Password</label>
              <input {...regPass('currentPassword', { required: true })} type="password" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">New Password</label>
              <input {...regPass('newPassword', { required: true, minLength: 6 })} type="password" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Confirm New Password</label>
              <input {...regPass('confirmPassword', { required: true })} type="password" className="input-field" />
            </div>
            <button type="submit" disabled={changingPass} className="btn-primary">
              {changingPass ? 'Changing...' : 'Change Password'}
            </button>
          </form>
        </motion.div>
      )}

      {/* Payment Tab */}
      {activeTab === 'Payment' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Payment Configuration</h3>
          <div className="space-y-4">
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm font-medium text-amber-800 mb-1">⚠️ Stripe Integration</p>
              <p className="text-xs text-amber-700">Add your Stripe keys to the backend <code className="bg-amber-100 px-1 rounded">.env</code> file to enable live payments.</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Stripe Mode</label>
              <select className="input-field w-48">
                <option value="test">Test Mode</option>
                <option value="live">Live Mode</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Supported Methods</label>
              <div className="flex gap-3 flex-wrap">
                {['💳 Stripe Card', '💵 Cash on Delivery'].map((m) => (
                  <span key={m} className="badge-success px-3 py-1 text-sm">{m}</span>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Notifications Tab */}
      {activeTab === 'Notifications' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Notification Preferences</h3>
          <div className="space-y-4">
            {[
              { label: 'New Order Notifications', desc: 'Get notified when a new order is placed' },
              { label: 'Low Stock Alerts', desc: 'Alert when product stock falls below 10' },
              { label: 'Review Notifications', desc: 'Get notified for new product reviews' },
              { label: 'Payment Alerts', desc: 'Notifications for payment events' },
            ].map((item) => (
              <div key={item.label} className="flex items-start justify-between p-3 rounded-lg hover:bg-dark-50 transition-colors">
                <div>
                  <p className="text-sm font-medium text-dark-800">{item.label}</p>
                  <p className="text-xs text-dark-400">{item.desc}</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer ml-4">
                  <input type="checkbox" defaultChecked className="sr-only peer" />
                  <div className="w-10 h-5 bg-dark-200 rounded-full peer peer-checked:bg-primary-600 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-5" />
                </label>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}
