import React, { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { GET_BANNERS } from '../../graphql/queries.js';
import { CREATE_BANNER, UPDATE_BANNER, DELETE_BANNER } from '../../graphql/mutations.js';
import toast from 'react-hot-toast';
import clsx from 'clsx';
import ImageUpload from '../../components/common/ImageUpload';
import ConfirmModal from '../../components/common/ConfirmModal';

export default function Banners() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const { data, loading, error, refetch } = useQuery(GET_BANNERS, {
    variables: { platform: 'both' }, // Just passing a default or leaving it to get all
    fetchPolicy: 'network-only'
  });

  const [createBanner] = useMutation(CREATE_BANNER, {
    onCompleted: () => {
      toast.success('Banner created successfully');
      setFormOpen(false);
      refetch();
    },
    onError: (err) => toast.error(err.message)
  });

  const [updateBanner] = useMutation(UPDATE_BANNER, {
    onCompleted: () => {
      toast.success('Banner updated successfully');
      setFormOpen(false);
      refetch();
    },
    onError: (err) => toast.error(err.message)
  });

  const [deleteBanner] = useMutation(DELETE_BANNER, {
    onCompleted: () => {
      toast.success('Banner deleted successfully');
      refetch();
    },
    onError: (err) => toast.error(err.message)
  });

  const [isFormOpen, setFormOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState(null);

  const initialFormState = {
    title: '',
    subtitle: '',
    tag: '',
    image: '',
    link: '',
    discount: '',
    platform: 'both',
    bgGradient: '',
    bgHex: '',
    buttonColor: '',
    accentColor: '',
    isActive: true,
    order: 0
  };

  const [formData, setFormData] = useState(initialFormState);

  const handleOpenForm = (banner = null) => {
    if (banner) {
      setEditingBanner(banner);
      setFormData({
        title: banner.title || '',
        subtitle: banner.subtitle || '',
        tag: banner.tag || '',
        image: banner.image || '',
        link: banner.link || '',
        discount: banner.discount || '',
        platform: banner.platform || 'both',
        bgGradient: banner.bgGradient || '',
        bgHex: banner.bgHex || '',
        buttonColor: banner.buttonColor || '',
        accentColor: banner.accentColor || '',
        isActive: banner.isActive,
        order: banner.order || 0
      });
    } else {
      setEditingBanner(null);
      setFormData(initialFormState);
    }
    setFormOpen(true);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : type === 'number' ? Number(value) : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const input = { ...formData };
    
    if (editingBanner) {
      updateBanner({ variables: { id: editingBanner._id, input } });
    } else {
      createBanner({ variables: { input } });
    }
  };

  const handleDelete = (id) => {
    setDeleteConfirm(id);
  };

  if (loading) return <div className="py-4 text-sm text-dark-500">Loading banners...</div>;
  if (error) return <div className="py-4 text-sm text-rose-500">Error loading banners: {error.message}</div>;

  const banners = data?.getBanners || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Dynamic Banners</h1>
          <p className="text-dark-500 text-sm mt-1">Manage promotional banners for website and mobile app</p>
        </div>
        <button
          onClick={() => handleOpenForm()}
          className="btn-primary flex items-center gap-2 px-4 py-2"
        >
          <PlusIcon className="w-5 h-5" />
          Add Banner
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {banners.map((banner) => (
          <div key={banner._id} className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
            <div className="aspect-video bg-gray-100 relative overflow-hidden group">
              {banner.image ? (
                <img src={banner.image} alt={banner.title} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">No Image</div>
              )}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button
                  onClick={() => handleOpenForm(banner)}
                  className="p-2 bg-white rounded-full text-blue-600 hover:bg-blue-50"
                >
                  <PencilIcon className="w-5 h-5" />
                </button>
                <button
                  onClick={() => handleDelete(banner._id)}
                  className="p-2 bg-white rounded-full text-red-600 hover:bg-red-50"
                >
                  <TrashIcon className="w-5 h-5" />
                </button>
              </div>
              <div className="absolute top-2 left-2 flex flex-col gap-1">
                <span className={clsx(
                  "px-2 py-1 text-[10px] font-bold uppercase rounded-md",
                  banner.isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                )}>
                  {banner.isActive ? 'Active' : 'Inactive'}
                </span>
                <span className="px-2 py-1 text-[10px] font-bold uppercase bg-blue-100 text-blue-800 rounded-md">
                  {banner.platform}
                </span>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-lg text-gray-900 truncate">{banner.title || 'Untitled Banner'}</h3>
              <p className="text-sm text-gray-500 truncate">{banner.subtitle || 'No subtitle'}</p>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="text-gray-500">Order: {banner.order}</span>
                {banner.discount && (
                  <span className="font-bold text-blue-600">{banner.discount}</span>
                )}
              </div>
            </div>
          </div>
        ))}
        {banners.length === 0 && (
          <div className="col-span-full py-12 text-center text-gray-500 bg-white border border-dashed border-gray-300 rounded-xl">
            No banners found. Create one to get started.
          </div>
        )}
      </div>

      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-3xl my-8">
            <div className="flex justify-between items-center p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-900">
                {editingBanner ? 'Edit Banner' : 'Create Banner'}
              </h2>
              <button
                onClick={() => setFormOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <XMarkIcon className="w-6 h-6" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Subtitle</label>
                  <input
                    type="text"
                    name="subtitle"
                    value={formData.subtitle}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tag (e.g., NEW, HOT)</label>
                  <input
                    type="text"
                    name="tag"
                    value={formData.tag}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Discount Text (e.g., 50% OFF)</label>
                  <input
                    type="text"
                    name="discount"
                    value={formData.discount}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div className="md:col-span-2">
                  <ImageUpload
                    label="Banner Image"
                    value={formData.image}
                    onChange={(url) => setFormData({ ...formData, image: url })}
                  />
                  <p className="mt-2 text-xs text-gray-500">
                    * Recommended size: <strong>1200 x 300 pixels</strong> (4:1 aspect ratio) for best display on the customer website.
                  </p>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Target Link</label>
                  <input
                    type="text"
                    name="link"
                    value={formData.link}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Platform</label>
                  <select
                    name="platform"
                    value={formData.platform}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="both">Both (Web & Mobile)</option>
                    <option value="website">Website Only</option>
                    <option value="mobile">Mobile App Only</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Display Order</label>
                  <input
                    type="number"
                    name="order"
                    value={formData.order}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Background Gradient CSS</label>
                  <input
                    type="text"
                    name="bgGradient"
                    value={formData.bgGradient}
                    onChange={handleChange}
                    placeholder="e.g. from-blue-50 to-white"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Background Hex (Fallback/Mobile)</label>
                  <input
                    type="text"
                    name="bgHex"
                    value={formData.bgHex}
                    onChange={handleChange}
                    placeholder="e.g. #f3f4f6"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Button Color</label>
                  <input
                    type="text"
                    name="buttonColor"
                    value={formData.buttonColor}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Accent Color</label>
                  <input
                    type="text"
                    name="accentColor"
                    value={formData.accentColor}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div className="md:col-span-2 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    name="isActive"
                    checked={formData.isActive}
                    onChange={handleChange}
                    className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                  />
                  <label htmlFor="isActive" className="text-sm font-medium text-gray-700">
                    Active (visible to customers)
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-6 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setFormOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700"
                >
                  {editingBanner ? 'Save Changes' : 'Create Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Banner?"
        message="Are you sure you want to delete this banner? This action cannot be undone."
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteBanner({ variables: { id: deleteConfirm } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
