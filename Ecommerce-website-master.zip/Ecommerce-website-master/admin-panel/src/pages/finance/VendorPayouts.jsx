import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BanknotesIcon,
  CurrencyRupeeIcon,
  BuildingStorefrontIcon,
  ArrowUpRightIcon,
  CheckCircleIcon,
  XCircleIcon,
  ClockIcon,
  CreditCardIcon,
  XMarkIcon,
  CheckIcon,
  FunnelIcon,
  MagnifyingGlassIcon,
  InformationCircleIcon,
  QrCodeIcon,
  EyeIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import useAuthStore from '../../store/authStore';
import {
  GET_VENDOR_PAYOUT_SUMMARY,
  GET_ADMIN_PAYOUT_SUMMARY,
  GET_PAYOUT_REQUESTS,
  GET_VENDOR_BANK_DETAILS,
} from '../../graphql/queries';
import {
  REQUEST_VENDOR_PAYOUT,
  UPDATE_PAYOUT_REQUEST_STATUS,
  UPDATE_VENDOR_BANK_DETAILS,
  ADMIN_RELEASE_VENDOR_PAYOUT,
} from '../../graphql/mutations';

export default function VendorPayouts() {
  const { user } = useAuthStore();
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';

  const [statusFilter, setStatusFilter] = useState('pending');
  const [activeVendorFilter, setActiveVendorFilter] = useState('pending'); // 'pending' | 'eligible' | 'paid' | ''
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [processModalOpen, setProcessModalOpen] = useState(false);
  const [adminNotes, setAdminNotes] = useState('');

  // Admin Direct Release Payout state
  const [directReleaseModalOpen, setDirectReleaseModalOpen] = useState(false);
  const [directReleaseItem, setDirectReleaseItem] = useState(null);
  const [directReleaseAmount, setDirectReleaseAmount] = useState('');
  const [directReleaseNotes, setDirectReleaseNotes] = useState('');

  // Vendor Payout Request state
  const [requestModalOpen, setRequestModalOpen] = useState(false);

  // Vendor Bank Details Form state
  const [bankModalOpen, setBankModalOpen] = useState(false);
  const [accountHolderName, setAccountHolderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [bankName, setBankName] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [upiId, setUpiId] = useState('');

  // Queries
  const { data: summaryData, refetch: refetchSummary } = useQuery(GET_VENDOR_PAYOUT_SUMMARY, {
    fetchPolicy: 'cache-and-network',
  });

  const { data: adminSummaryData, refetch: refetchAdminSummary } = useQuery(GET_ADMIN_PAYOUT_SUMMARY, {
    skip: !isAdmin,
    fetchPolicy: 'cache-and-network',
  });

  const { data: requestsData, loading: loadingRequests, refetch: refetchRequests } = useQuery(GET_PAYOUT_REQUESTS, {
    variables: { status: statusFilter || undefined },
    fetchPolicy: 'cache-and-network',
  });

  const refetchAll = () => {
    refetchSummary();
    refetchRequests();
    if (isAdmin) refetchAdminSummary();
  };

  // Mutations
  const [requestPayout, { loading: requesting }] = useMutation(REQUEST_VENDOR_PAYOUT, {
    onCompleted: () => {
      toast.success('Payout request submitted successfully!');
      setRequestModalOpen(false);
      refetchAll();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateStatus, { loading: processing }] = useMutation(UPDATE_PAYOUT_REQUEST_STATUS, {
    onCompleted: () => {
      toast.success('Payout request status updated!');
      setProcessModalOpen(false);
      setSelectedRequest(null);
      setAdminNotes('');
      refetchAll();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateBankDetails, { loading: savingBank }] = useMutation(UPDATE_VENDOR_BANK_DETAILS, {
    onCompleted: () => {
      toast.success('Bank & UPI details saved successfully!');
      setBankModalOpen(false);
      refetchAll();
    },
    onError: (e) => toast.error(e.message),
  });

  const [adminReleasePayout, { loading: releasingPayout }] = useMutation(ADMIN_RELEASE_VENDOR_PAYOUT, {
    onCompleted: (res) => {
      const amt = Number(res?.adminReleaseVendorPayout?.amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 });
      toast.success(`Eligible payout of ₹${amt} successfully released and marked as paid!`);
      setDirectReleaseModalOpen(false);
      setDirectReleaseItem(null);
      setDirectReleaseNotes('');
      refetchAll();
    },
    onError: (e) => toast.error(e.message),
  });

  const openDirectReleaseModal = (item) => {
    setDirectReleaseItem(item);
    setDirectReleaseAmount(item.eligibleBalance || 0);
    setDirectReleaseNotes('');
    setDirectReleaseModalOpen(true);
  };

  const handleDirectReleaseSubmit = (e) => {
    e.preventDefault();
    if (!directReleaseItem?.vendor?._id) return;
    const numericAmount = Number(directReleaseAmount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      toast.error('Please enter a valid payout amount greater than ₹0');
      return;
    }
    if (numericAmount > (directReleaseItem.eligibleBalance || 0)) {
      toast.error(`Amount ₹${numericAmount} exceeds vendor eligible balance ₹${directReleaseItem.eligibleBalance}`);
      return;
    }
    adminReleasePayout({
      variables: {
        vendorId: directReleaseItem.vendor._id,
        amount: numericAmount,
        adminNotes: directReleaseNotes.trim() || 'Direct payout released by Admin',
      },
    });
  };

  const summary = summaryData?.getVendorPayoutSummary || {
    totalSales: 0,
    totalCommission: 0,
    totalEarnings: 0,
    eligibleBalance: 0,
    pendingPayout: 0,
    totalPaidOut: 0,
    returnPendingBalance: 0,
    bankDetails: null,
  };

  const adminSummary = adminSummaryData?.getAdminPayoutSummary || {
    totalEligiblePayoutsPending: 0,
    totalPendingRequestsAmount: 0,
    totalPaidOut: 0,
    vendorPayoutsList: [],
  };

  const filteredVendorBalances = useMemo(() => {
    const list = adminSummary.vendorPayoutsList || [];
    if (activeVendorFilter === 'pending') {
      return list.filter((item) => (item.pendingPayout || 0) > 0);
    }
    if (activeVendorFilter === 'eligible') {
      return list.filter((item) => (item.eligibleBalance || 0) > 0);
    }
    if (activeVendorFilter === 'paid') {
      return list.filter((item) => (item.totalPaidOut || 0) > 0);
    }
    if (activeVendorFilter === 'all') {
      return list;
    }
    return list.filter((item) => (item.pendingPayout || 0) > 0);
  }, [adminSummary.vendorPayoutsList, activeVendorFilter]);

  const payoutRequests = requestsData?.getPayoutRequests || [];

  const openBankModal = () => {
    const bd = summary.bankDetails || {};
    setAccountHolderName(bd.accountHolderName || '');
    setAccountNumber(bd.accountNumber || '');
    setBankName(bd.bankName || '');
    setIfscCode(bd.ifscCode || '');
    setUpiId(bd.upiId || '');
    setBankModalOpen(true);
  };

  const handleSaveBank = (e) => {
    e.preventDefault();
    updateBankDetails({
      variables: {
        input: {
          accountHolderName,
          accountNumber,
          bankName,
          ifscCode,
          upiId,
        },
      },
    });
  };

  const handleRequestSubmit = (e) => {
    e.preventDefault();
    if (summary.eligibleBalance <= 0) {
      toast.error('No eligible balance available for payout request');
      return;
    }
    if (!summary.bankDetails?.accountNumber && !summary.bankDetails?.upiId) {
      toast.error('Please add your Bank Account or UPI ID before requesting a payout');
      openBankModal();
      return;
    }
    requestPayout({ variables: { amount: summary.eligibleBalance } });
  };

  const handleProcessStatus = (newStatus) => {
    if (!selectedRequest) return;
    updateStatus({
      variables: {
        id: selectedRequest._id,
        status: newStatus,
        adminNotes: adminNotes.trim(),
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">
            {isAdmin ? 'Vendor Payout Management' : 'My Earnings & Payouts'}
          </h1>
          <p className="text-sm text-dark-500 mt-1">
            {isAdmin
              ? 'Process vendor payout requests, view bank/UPI details, and record manual transfers'
              : 'Track product sales, earnings, return-window clearance, and request payouts'}
          </p>
        </div>
        {!isAdmin && (
          <div className="flex items-center gap-2">
            <button
              onClick={openBankModal}
              className="btn-secondary text-xs font-semibold flex items-center gap-1.5"
            >
              <CreditCardIcon className="w-4 h-4 text-primary-600" />
              {summary.bankDetails?.accountNumber || summary.bankDetails?.upiId
                ? 'Edit Bank / UPI Info'
                : 'Add Bank / UPI Info'}
            </button>
            <button
              onClick={() => setRequestModalOpen(true)}
              disabled={summary.eligibleBalance <= 0}
              className="btn-primary text-xs font-bold flex items-center gap-1.5 disabled:opacity-50"
            >
              <ArrowUpRightIcon className="w-4 h-4" /> Request Payout
            </button>
          </div>
        )}
      </div>

      {/* KPI Cards */}
      {isAdmin ? (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => {
              setActiveVendorFilter('pending');
              setStatusFilter('pending');
              const el = document.getElementById('vendor-balances-summary-table');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`card p-5 rounded-2xl cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98] ${
              activeVendorFilter === 'pending'
                ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-md scale-[1.01]'
                : 'bg-white border border-gray-100 text-dark-900 hover:border-orange-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeVendorFilter === 'pending' ? 'opacity-90 text-white' : 'text-dark-500'}`}>
                Total Pending Requests
              </span>
              <div className={`p-2.5 rounded-xl ${activeVendorFilter === 'pending' ? 'bg-white/10 text-white' : 'bg-orange-50 text-orange-600'}`}>
                <ClockIcon className="w-5 h-5" />
              </div>
            </div>
            <div className={`mt-3 text-2xl font-black ${activeVendorFilter === 'pending' ? 'text-white' : 'text-dark-900'}`}>
              ₹{Number(adminSummary.totalPendingRequestsAmount).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <p className={`text-xs mt-1 flex items-center justify-between ${activeVendorFilter === 'pending' ? 'opacity-90 text-white' : 'text-dark-400'}`}>
              <span>Awaiting manual transfer approval</span>
              <ArrowUpRightIcon className="w-4 h-4 ml-1 opacity-80" />
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            onClick={() => {
              setActiveVendorFilter('eligible');
              setStatusFilter('');
              const el = document.getElementById('vendor-balances-summary-table');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`card p-5 rounded-2xl cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98] ${
              activeVendorFilter === 'eligible'
                ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-md scale-[1.01]'
                : 'bg-white border border-gray-100 text-dark-900 hover:border-orange-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeVendorFilter === 'eligible' ? 'opacity-90 text-white' : 'text-dark-500'}`}>
                Total Eligible Payouts Pending
              </span>
              <div className={`p-2.5 rounded-xl ${activeVendorFilter === 'eligible' ? 'bg-white/10 text-white' : 'bg-blue-50 text-blue-600'}`}>
                <CurrencyRupeeIcon className="w-5 h-5" />
              </div>
            </div>
            <div className={`mt-3 text-2xl font-black ${activeVendorFilter === 'eligible' ? 'text-white' : 'text-dark-900'}`}>
              ₹{Number(adminSummary.totalEligiblePayoutsPending).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <p className={`text-xs mt-1 flex items-center justify-between ${activeVendorFilter === 'eligible' ? 'opacity-90 text-white' : 'text-dark-400'}`}>
              <span>Total available balance across all vendors</span>
              <ArrowUpRightIcon className="w-4 h-4 opacity-80" />
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            onClick={() => {
              setActiveVendorFilter('paid');
              setStatusFilter('paid');
              const el = document.getElementById('payout-requests-table');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`card p-5 rounded-2xl cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98] ${
              activeVendorFilter === 'paid'
                ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-md scale-[1.01]'
                : 'bg-white border border-gray-100 text-dark-900 hover:border-orange-300 shadow-2xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeVendorFilter === 'paid' ? 'opacity-90 text-white' : 'text-dark-500'}`}>
                Total Paid Out to Vendors
              </span>
              <div className={`p-2.5 rounded-xl ${activeVendorFilter === 'paid' ? 'bg-white/10 text-white' : 'bg-emerald-50 text-emerald-600'}`}>
                <CheckCircleIcon className="w-5 h-5" />
              </div>
            </div>
            <div className={`mt-3 text-2xl font-black ${activeVendorFilter === 'paid' ? 'text-white' : 'text-emerald-600'}`}>
              ₹{Number(adminSummary.totalPaidOut).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <p className={`text-xs mt-1 flex items-center justify-between ${activeVendorFilter === 'paid' ? 'opacity-90 text-white' : 'text-dark-400'}`}>
              <span>Cumulative settled vendor payouts</span>
              <ArrowUpRightIcon className="w-4 h-4 opacity-80" />
            </p>
          </motion.div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => setRequestModalOpen(true)}
            className="card p-5 bg-gradient-to-br from-primary-600 to-indigo-700 text-white rounded-2xl shadow-sm cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98]"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider opacity-80">Eligible Payout Balance</span>
              <div className="p-2.5 bg-white/10 rounded-xl">
                <CurrencyRupeeIcon className="w-5 h-5 text-white" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-black">₹{Number(summary.eligibleBalance).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <p className="text-xs opacity-80 mt-1 flex items-center justify-between">
              <span>Ready to request / transfer</span>
              <ArrowUpRightIcon className="w-4 h-4 opacity-80" />
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            onClick={() => {
              setStatusFilter('pending');
              const el = document.getElementById('payout-requests-table');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`card p-5 bg-white border border-gray-100 rounded-2xl shadow-2xs cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98] ${
              statusFilter === 'pending' ? 'ring-2 ring-amber-500 border-amber-500' : ''
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-dark-500">Pending Requests</span>
              <div className="p-2.5 bg-amber-50 rounded-xl">
                <ClockIcon className="w-5 h-5 text-amber-600" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-bold text-dark-900">₹{Number(summary.pendingPayout).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <p className="text-xs text-dark-400 mt-1 flex items-center justify-between">
              <span>Awaiting admin transfer approval</span>
              <ArrowUpRightIcon className="w-4 h-4 text-amber-600 opacity-80" />
            </p>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="card p-5 bg-white border border-gray-100 rounded-2xl shadow-2xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-dark-500">7-Day Return Pending</span>
              <div className="p-2.5 bg-blue-50 rounded-xl">
                <InformationCircleIcon className="w-5 h-5 text-blue-600" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-bold text-dark-900">₹{Number(summary.returnPendingBalance).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <p className="text-xs text-dark-400 mt-1">Shopping items in return window</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            onClick={() => {
              setStatusFilter('paid');
              const el = document.getElementById('payout-requests-table');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className={`card p-5 bg-white border border-gray-100 rounded-2xl shadow-2xs cursor-pointer hover:scale-[1.02] transition-all active:scale-[0.98] ${
              statusFilter === 'paid' ? 'ring-2 ring-emerald-500 border-emerald-500' : ''
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-dark-500">Total Settled / Paid Out</span>
              <div className="p-2.5 bg-emerald-50 rounded-xl">
                <CheckCircleIcon className="w-5 h-5 text-emerald-600" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-bold text-emerald-600">₹{Number(summary.totalPaidOut).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <p className="text-xs text-dark-400 mt-1 flex items-center justify-between">
              <span>Transferred to vendor account</span>
              <ArrowUpRightIcon className="w-4 h-4 text-emerald-600 opacity-80" />
            </p>
          </motion.div>
        </div>
      )}

      {/* Admin Vendor Balances & Eligible Payouts Table */}
      {isAdmin && adminSummary.vendorPayoutsList?.length > 0 && (
        <div id="vendor-balances-summary-table" className="card overflow-hidden bg-white border border-gray-100 shadow-sm rounded-2xl space-y-4">
          <div className="p-4 border-b border-gray-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-dark-900 text-sm">Vendor Balances & Eligible Payouts Summary</h3>
              <p className="text-xs text-dark-500">
                {activeVendorFilter === 'pending'
                  ? 'Showing vendors with pending payout requests (> ₹0)'
                  : activeVendorFilter === 'eligible'
                  ? 'Showing vendors with available eligible balance (> ₹0)'
                  : activeVendorFilter === 'paid'
                  ? 'Showing vendors with settled/paid payouts (> ₹0)'
                  : 'List of all active vendors and their current pending & eligible balances'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {activeVendorFilter && (
                <button
                  onClick={() => {
                    setActiveVendorFilter('');
                    setStatusFilter('');
                  }}
                  className="text-xs font-semibold px-2.5 py-1 bg-gray-100 text-dark-600 hover:bg-gray-200 rounded-full transition-colors"
                >
                  Show All Vendors
                </button>
              )}
              <span className="text-xs font-semibold px-2.5 py-0.5 bg-indigo-50 text-indigo-700 rounded-full">
                {filteredVendorBalances.length} Vendors
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-gray-50 border-b border-gray-100 text-dark-500 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3.5 px-4">Vendor</th>
                  <th className="py-3.5 px-4 text-right">Eligible Balance</th>
                  <th className="py-3.5 px-4 text-right">Pending Request</th>
                  <th className="py-3.5 px-4 text-right">Return Window Pending</th>
                  <th className="py-3.5 px-4 text-right">Total Paid Out</th>
                  <th className="py-3.5 px-4">Bank / UPI Info</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-dark-800 font-medium">
                {filteredVendorBalances.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-dark-400 text-xs">
                      No vendors match the "{activeVendorFilter}" filter.{' '}
                      <button
                        onClick={() => {
                          setActiveVendorFilter('');
                          setStatusFilter('');
                        }}
                        className="text-primary-600 font-bold underline hover:text-primary-800"
                      >
                        Reset Filter
                      </button>
                    </td>
                  </tr>
                ) : (
                  filteredVendorBalances.map((item) => (
                    <tr key={item.vendor?._id} className="hover:bg-gray-50/80 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              item.vendor?.avatar ||
                              `https://ui-avatars.com/api/?name=${encodeURIComponent(item.vendor?.name || 'V')}`
                            }
                            alt={item.vendor?.name}
                            className="w-8 h-8 rounded-full object-cover border border-gray-200"
                          />
                          <div>
                            <p className="font-bold text-dark-900">{item.vendor?.name || 'Vendor'}</p>
                            <p className="text-[11px] text-dark-400">{item.vendor?.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-600">
                        ₹{Number(item.eligibleBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-amber-600">
                        ₹{Number(item.pendingPayout || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-dark-600">
                        ₹{Number(item.returnPendingBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-dark-900">
                        ₹{Number(item.totalPaidOut || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4">
                        {item.bankDetails?.accountNumber ? (
                          <div className="text-[11px] text-dark-700">
                            <strong>{item.bankDetails.bankName}</strong> ({item.bankDetails.accountNumber.slice(-4)})
                          </div>
                        ) : item.bankDetails?.upiId ? (
                          <div className="text-[11px] text-emerald-700 font-mono">
                            UPI: {item.bankDetails.upiId}
                          </div>
                        ) : (
                          <span className="text-dark-400 text-xs">—</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Vendor Bank Details Quick Banner (if vendor) */}
      {!isAdmin && (
        <div className="card p-5 bg-slate-50 border border-slate-200/80 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
              <CreditCardIcon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-dark-900">Configured Payment Methods</h4>
              <p className="text-xs text-dark-500 mt-0.5">
                {summary.bankDetails?.accountNumber
                  ? `Bank: ${summary.bankDetails.bankName || 'Saved'} (A/C: ••••${summary.bankDetails.accountNumber.slice(-4)})`
                  : 'No bank account added yet'}{' '}
                · {summary.bankDetails?.upiId ? `UPI: ${summary.bankDetails.upiId}` : 'No UPI ID saved'}
              </p>
            </div>
          </div>
          <button onClick={openBankModal} className="btn-secondary text-xs font-semibold">
            {summary.bankDetails ? 'Update Details' : 'Add Bank & UPI Details'}
          </button>
        </div>
      )}

      {/* Payout Requests List Table */}
      <div id="payout-requests-table" className="card overflow-hidden bg-white border border-gray-100 shadow-sm rounded-2xl space-y-4">
        {/* Table Filters */}
        <div className="p-4 border-b border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-dark-900 text-sm">Payout Requests & History</h3>
            <span className="text-xs font-semibold px-2 py-0.5 bg-gray-100 text-dark-600 rounded-full">
              {payoutRequests.length}
            </span>
          </div>

          {isAdmin && (
            <div className="flex items-center gap-2">
              <FunnelIcon className="w-4 h-4 text-dark-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="input-field text-xs py-1.5 w-40"
              >
                <option value="">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="paid">Paid (Settled)</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 border-b border-gray-100 text-dark-500 font-bold uppercase tracking-wider">
              <tr>
                {isAdmin && <th className="py-3.5 px-4">Vendor / Merchant</th>}
                <th className="py-3.5 px-4 text-right">Requested Amount (₹)</th>
                <th className="py-3.5 px-4">Bank / UPI Info</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4">Date Requested</th>
                <th className="py-3.5 px-4">Transfer Ref / Notes</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-dark-800 font-medium">
              {loadingRequests ? (
                <tr>
                  <td colSpan={isAdmin ? 7 : 6} className="py-12 text-center">
                    <div className="w-6 h-6 border-2 border-primary-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  </td>
                </tr>
              ) : payoutRequests.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 7 : 6} className="py-12 text-center text-gray-400 font-normal">
                    No payout requests found.
                  </td>
                </tr>
              ) : (
                payoutRequests.map((req) => (
                  <tr key={req._id} className="hover:bg-gray-50/80 transition-colors">
                    {isAdmin && (
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              req.vendor?.avatar ||
                              `https://ui-avatars.com/api/?name=${encodeURIComponent(req.vendor?.name || 'V')}`
                            }
                            alt={req.vendor?.name}
                            className="w-8 h-8 rounded-full object-cover border border-gray-200"
                          />
                          <div>
                            <p className="font-bold text-dark-900">{req.vendor?.name || 'Vendor'}</p>
                            <p className="text-[11px] text-dark-400">{req.vendor?.email}</p>
                          </div>
                        </div>
                      </td>
                    )}
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-dark-900 text-sm">
                      ₹{Number(req.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="text-xs">
                        {req.bankDetails?.accountNumber ? (
                          <div className="flex items-center gap-1 font-semibold text-dark-800">
                            <CreditCardIcon className="w-3.5 h-3.5 text-indigo-600" />
                            {req.bankDetails.bankName} (A/C: {req.bankDetails.accountNumber})
                          </div>
                        ) : null}
                        {req.bankDetails?.upiId ? (
                          <div className="flex items-center gap-1 text-emerald-700 font-semibold mt-0.5">
                            <QrCodeIcon className="w-3.5 h-3.5 text-emerald-600" />
                            UPI: {req.bankDetails.upiId}
                          </div>
                        ) : !req.bankDetails?.accountNumber ? (
                          <span className="text-rose-500 font-medium">No Bank/UPI Details</span>
                        ) : null}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          req.status === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : req.status === 'approved'
                            ? 'bg-blue-100 text-blue-800'
                            : req.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-dark-500 font-mono text-[11px]">
                      {new Date(req.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="py-3.5 px-4 text-dark-600">
                      {req.adminNotes ? (
                        <span className="font-mono text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                          {req.adminNotes}
                        </span>
                      ) : (
                        <span className="text-dark-300 text-xs">—</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {isAdmin ? (
                        req.status === 'paid' ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                              <CheckCircleIcon className="w-3.5 h-3.5 text-emerald-600" />
                              Paid
                            </span>
                            <button
                              onClick={() => {
                                setSelectedRequest(req);
                                setAdminNotes(req.adminNotes || '');
                                setProcessModalOpen(true);
                              }}
                              className="p-1 text-dark-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                              title="View Payout Details"
                            >
                              <EyeIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ) : req.status === 'rejected' ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-full">
                              <XCircleIcon className="w-3.5 h-3.5 text-rose-600" />
                              Rejected
                            </span>
                            <button
                              onClick={() => {
                                setSelectedRequest(req);
                                setAdminNotes(req.adminNotes || '');
                                setProcessModalOpen(true);
                              }}
                              className="p-1 text-dark-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                              title="View Rejection Details"
                            >
                              <EyeIcon className="w-4 h-4" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setSelectedRequest(req);
                              setAdminNotes(req.adminNotes || '');
                              setProcessModalOpen(true);
                            }}
                            className="btn-secondary text-[11px] font-bold py-1 px-2.5 bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 shadow-sm transition-all"
                          >
                            Process Payout
                          </button>
                        )
                      ) : (
                        <button
                          onClick={() => {
                            setSelectedRequest(req);
                            setAdminNotes(req.adminNotes || '');
                            setProcessModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1 text-[11px] font-medium text-dark-500 hover:text-indigo-600 hover:bg-gray-100 px-2 py-1 rounded transition-colors"
                          title="View Details"
                        >
                          <EyeIcon className="w-3.5 h-3.5" />
                          View
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin Process Payout Modal */}
      <AnimatePresence>
        {processModalOpen && selectedRequest && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">
                    {selectedRequest.status === 'paid'
                      ? 'Payout Details (Settled)'
                      : selectedRequest.status === 'rejected'
                      ? 'Payout Request (Rejected)'
                      : 'Process Vendor Payout'}
                  </h3>
                  <p className="text-xs text-dark-500">
                    Vendor: <strong className="text-dark-800">{selectedRequest.vendor?.name}</strong> ({selectedRequest.vendor?.email})
                  </p>
                </div>
                <button onClick={() => setProcessModalOpen(false)} className="text-dark-400 hover:text-dark-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              {/* Status Banner for settled or rejected requests */}
              {selectedRequest.status === 'paid' && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2.5 text-emerald-800 text-xs font-semibold">
                  <CheckCircleIcon className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  <div>
                    <p className="font-bold">Payout Completed & Transferred</p>
                    <p className="text-[11px] text-emerald-700 font-normal">This payout has already been processed and marked as paid.</p>
                  </div>
                </div>
              )}
              {selectedRequest.status === 'rejected' && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-rose-800 text-xs font-semibold">
                  <XCircleIcon className="w-5 h-5 text-rose-600 flex-shrink-0" />
                  <div>
                    <p className="font-bold">Payout Request Rejected</p>
                    <p className="text-[11px] text-rose-700 font-normal">This payout request was rejected and not transferred.</p>
                  </div>
                </div>
              )}

              {/* Amount Badge */}
              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-800">
                  {selectedRequest.status === 'paid' ? 'Transferred Amount' : 'Requested Amount'}
                </span>
                <span className="text-2xl font-black text-indigo-900 font-mono">
                  ₹{Number(selectedRequest.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
              </div>

              {/* Vendor Bank & UPI Details Display Box */}
              <div className="p-4 bg-gray-50 border border-gray-200 rounded-2xl space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-dark-700 flex items-center gap-1.5">
                  <CreditCardIcon className="w-4 h-4 text-indigo-600" />
                  Vendor Transfer Info {selectedRequest.status !== 'paid' ? '(For Manual Transfer)' : ''}
                </h4>
                {selectedRequest.bankDetails?.accountNumber ? (
                  <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                    <div>
                      <span className="text-dark-400 block">Bank Name:</span>
                      <strong className="text-dark-800">{selectedRequest.bankDetails.bankName || 'N/A'}</strong>
                    </div>
                    <div>
                      <span className="text-dark-400 block">Account Holder:</span>
                      <strong className="text-dark-800">{selectedRequest.bankDetails.accountHolderName || 'N/A'}</strong>
                    </div>
                    <div>
                      <span className="text-dark-400 block">Account Number:</span>
                      <strong className="text-dark-900 font-mono text-sm">{selectedRequest.bankDetails.accountNumber}</strong>
                    </div>
                    <div>
                      <span className="text-dark-400 block">IFSC Code:</span>
                      <strong className="text-dark-900 font-mono text-sm">{selectedRequest.bankDetails.ifscCode}</strong>
                    </div>
                  </div>
                ) : null}
                {selectedRequest.bankDetails?.upiId && (
                  <div className="pt-2 border-t border-gray-200 text-xs">
                    <span className="text-dark-400 block">UPI ID:</span>
                    <strong className="text-emerald-700 font-mono text-sm">{selectedRequest.bankDetails.upiId}</strong>
                  </div>
                )}
                {!selectedRequest.bankDetails?.accountNumber && !selectedRequest.bankDetails?.upiId && (
                  <p className="text-xs text-rose-500 font-medium">Vendor has not saved bank or UPI details yet.</p>
                )}
              </div>

              {/* Transfer Ref / Admin Notes */}
              <div>
                <label className="block text-xs font-bold text-dark-700 mb-1">
                  Manual Transfer Reference / UTR Number / Admin Note
                </label>
                {selectedRequest.status === 'paid' || selectedRequest.status === 'rejected' ? (
                  <div className="p-3 bg-gray-50 border border-gray-200 rounded-xl text-xs font-mono text-dark-800 break-all">
                    {selectedRequest.adminNotes || 'No notes provided.'}
                  </div>
                ) : (
                  <input
                    type="text"
                    placeholder="e.g. UTR: 325491823901 or Bank NEFT Ref"
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    className="input-field text-xs font-mono"
                  />
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                {selectedRequest.status === 'paid' || selectedRequest.status === 'rejected' || !isAdmin ? (
                  <button
                    type="button"
                    onClick={() => setProcessModalOpen(false)}
                    className="flex-1 btn-secondary text-xs font-bold py-2.5"
                  >
                    Close
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => handleProcessStatus('rejected')}
                      disabled={processing}
                      className="flex-1 btn-danger text-xs font-bold py-2.5"
                    >
                      Reject Request
                    </button>
                    <button
                      type="button"
                      onClick={() => handleProcessStatus('paid')}
                      disabled={processing}
                      className="flex-1 btn-primary bg-emerald-600 hover:bg-emerald-700 text-xs font-bold py-2.5"
                    >
                      {processing ? 'Saving...' : 'Mark as Paid (Transferred)'}
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Vendor Request Payout Modal */}
      <AnimatePresence>
        {requestModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">Request Vendor Payout</h3>
                  <p className="text-xs text-dark-500">Submit a withdrawal request for eligible earnings</p>
                </div>
                <button onClick={() => setRequestModalOpen(false)} className="text-dark-400 hover:text-dark-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleRequestSubmit} className="space-y-4">
                <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">Eligible Balance to Request</span>
                  <span className="text-2xl font-black text-emerald-900 font-mono block mt-1">
                    ₹{Number(summary.eligibleBalance).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                  <p className="text-[11px] text-emerald-700 mt-2 font-medium">
                    Clicking submit will request your full eligible balance for payout.
                  </p>
                </div>

                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setRequestModalOpen(false)} className="flex-1 btn-secondary text-xs font-bold">
                    Cancel
                  </button>
                  <button type="submit" disabled={requesting} className="flex-1 btn-primary text-xs font-bold">
                    {requesting ? 'Submitting...' : 'Confirm Request'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Vendor Bank & UPI Configuration Modal */}
      <AnimatePresence>
        {bankModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">Bank Account & UPI Details</h3>
                  <p className="text-xs text-dark-500">Admins use these details to manually transfer your earnings</p>
                </div>
                <button onClick={() => setBankModalOpen(false)} className="text-dark-400 hover:text-dark-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveBank} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-dark-700 mb-1">Account Holder Name *</label>
                  <input
                    type="text"
                    placeholder="Full name as per bank account"
                    value={accountHolderName}
                    onChange={(e) => setAccountHolderName(e.target.value)}
                    className="input-field text-xs"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-dark-700 mb-1">Bank Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. HDFC Bank / ICICI Bank"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      className="input-field text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-dark-700 mb-1">IFSC Code *</label>
                    <input
                      type="text"
                      placeholder="e.g. HDFC0001234"
                      value={ifscCode}
                      onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                      className="input-field text-xs uppercase font-mono"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-dark-700 mb-1">Account Number *</label>
                  <input
                    type="text"
                    placeholder="Enter bank account number"
                    value={accountNumber}
                    onChange={(e) => setAccountNumber(e.target.value)}
                    className="input-field text-xs font-mono"
                    required
                  />
                </div>

                <div className="pt-2 border-t border-gray-100">
                  <label className="block text-xs font-bold text-dark-700 mb-1">UPI ID (Optional)</label>
                  <input
                    type="text"
                    placeholder="e.g. merchant@upi or 9876543210@paytm"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value.toLowerCase())}
                    className="input-field text-xs font-mono"
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setBankModalOpen(false)} className="flex-1 btn-secondary text-xs font-bold">
                    Cancel
                  </button>
                  <button type="submit" disabled={savingBank} className="flex-1 btn-primary text-xs font-bold">
                    {savingBank ? 'Saving...' : 'Save Bank Details'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Direct Payout Release Modal */}
      <AnimatePresence>
        {directReleaseModalOpen && directReleaseItem && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">Release Vendor Payout</h3>
                  <p className="text-xs text-dark-500">Disburse eligible earnings directly to vendor without a request</p>
                </div>
                <button onClick={() => setDirectReleaseModalOpen(false)} className="text-dark-400 hover:text-dark-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl flex items-center gap-3">
                <img
                  src={directReleaseItem.vendor?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(directReleaseItem.vendor?.name || 'V')}`}
                  alt=""
                  className="w-10 h-10 rounded-full object-cover border border-gray-200"
                />
                <div>
                  <h4 className="text-sm font-bold text-dark-900">{directReleaseItem.vendor?.name}</h4>
                  <p className="text-xs text-dark-400">{directReleaseItem.vendor?.email}</p>
                </div>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-2xl">
                <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider block">Available Eligible Balance</span>
                <span className="text-2xl font-black text-emerald-900 font-mono block mt-1">
                  ₹{Number(directReleaseItem.eligibleBalance || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </span>
                {directReleaseItem.bankDetails?.accountNumber ? (
                  <p className="text-[11px] text-emerald-800 mt-2 font-medium">
                    Bank: <strong>{directReleaseItem.bankDetails.bankName}</strong> (A/C: ••••{directReleaseItem.bankDetails.accountNumber.slice(-4)})
                  </p>
                ) : directReleaseItem.bankDetails?.upiId ? (
                  <p className="text-[11px] text-emerald-800 mt-2 font-medium font-mono">
                    UPI: {directReleaseItem.bankDetails.upiId}
                  </p>
                ) : (
                  <p className="text-[11px] text-amber-700 mt-2 font-medium">
                    ⚠️ Vendor has not configured bank or UPI info yet.
                  </p>
                )}
              </div>

              <form onSubmit={handleDirectReleaseSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-dark-700 mb-1">Amount to Release (₹) *</label>
                  <input
                    type="number"
                    step="0.01"
                    max={directReleaseItem.eligibleBalance}
                    placeholder="Enter amount to transfer"
                    value={directReleaseAmount}
                    onChange={(e) => setDirectReleaseAmount(e.target.value)}
                    className="input-field text-xs font-mono font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-dark-700 mb-1">Transfer Ref / UTR / Admin Note *</label>
                  <input
                    type="text"
                    placeholder="e.g. Bank transfer UTR: 1234567890"
                    value={directReleaseNotes}
                    onChange={(e) => setDirectReleaseNotes(e.target.value)}
                    className="input-field text-xs"
                    required
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setDirectReleaseModalOpen(false)} className="flex-1 btn-secondary text-xs font-bold">
                    Cancel
                  </button>
                  <button type="submit" disabled={releasingPayout} className="flex-1 btn-primary text-xs font-bold bg-emerald-600 hover:bg-emerald-700">
                    {releasingPayout ? 'Releasing...' : 'Release & Mark Paid'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
