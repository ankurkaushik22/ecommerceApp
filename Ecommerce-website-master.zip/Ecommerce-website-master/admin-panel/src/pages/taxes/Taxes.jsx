import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  BanknotesIcon,
  PlusIcon,
  PencilSquareIcon,
  TrashIcon,
  CheckBadgeIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_TAX_SETTINGS } from '../../graphql/queries.js';
import {
  CREATE_TAX_SETTING,
  UPDATE_TAX_SETTING,
  DELETE_TAX_SETTING,
} from '../../graphql/mutations.js';
import ConfirmModal from '../../components/common/ConfirmModal';

export default function Taxes() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [name, setName] = useState('');
  const [rate, setRate] = useState(18);
  const [cgst, setCgst] = useState(9);
  const [sgst, setSgst] = useState(9);
  const [igst, setIgst] = useState(18);
  const [hsnCode, setHsnCode] = useState('9983');
  const [description, setDescription] = useState('');
  const [isDefault, setIsDefault] = useState(false);
  const [isActive, setIsActive] = useState(true);

  const { data, loading, refetch } = useQuery(GET_TAX_SETTINGS);

  const [createMutation, { loading: creating }] = useMutation(CREATE_TAX_SETTING, {
    onCompleted: () => {
      toast.success('Tax rule created!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateMutation, { loading: updating }] = useMutation(UPDATE_TAX_SETTING, {
    onCompleted: () => {
      toast.success('Tax rule updated!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteMutation] = useMutation(DELETE_TAX_SETTING, {
    onCompleted: () => {
      toast.success('Tax rule deleted');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const taxSettings = data?.getTaxSettings || [];

  const handleOpenNew = () => {
    setEditingId(null);
    setName('');
    setRate(18);
    setCgst(9);
    setSgst(9);
    setIgst(18);
    setHsnCode('9983');
    setDescription('');
    setIsDefault(false);
    setIsActive(true);
    setModalOpen(true);
  };

  const handleOpenEdit = (tax) => {
    setEditingId(tax._id);
    setName(tax.name);
    setRate(tax.rate);
    setCgst(tax.cgst || tax.rate / 2);
    setSgst(tax.sgst || tax.rate / 2);
    setIgst(tax.igst || tax.rate);
    setHsnCode(tax.hsnCode || '9983');
    setDescription(tax.description || '');
    setIsDefault(tax.isDefault);
    setIsActive(tax.isActive);
    setModalOpen(true);
  };

  const handleRateChange = (newRate) => {
    const val = parseFloat(newRate) || 0;
    setRate(val);
    setCgst(val / 2);
    setSgst(val / 2);
    setIgst(val);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error('Tax rule name is required');
      return;
    }

    const input = {
      name: name.trim(),
      rate: parseFloat(rate) || 0,
      cgst: parseFloat(cgst) || 0,
      sgst: parseFloat(sgst) || 0,
      igst: parseFloat(igst) || 0,
      hsnCode: hsnCode.trim(),
      description: description.trim(),
      isDefault,
      isActive,
    };

    if (editingId) {
      updateMutation({ variables: { id: editingId, input } });
    } else {
      createMutation({ variables: { input } });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Tax & GST Management</h1>
          <p className="text-sm text-dark-500 mt-1">
            Configure Indian GST rates, CGST / SGST / IGST tax splits, HSN codes, and invoice rules
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="btn-primary flex items-center gap-2 text-sm shadow-md"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add Tax Rule</span>
        </button>
      </div>

      {/* Tax Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="card p-6 h-52 animate-pulse bg-gray-100 rounded-2xl" />
          ))
        ) : (
          taxSettings.map((tax) => (
            <motion.div
              key={tax._id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-6 space-y-4 hover:shadow-lg transition-all border border-gray-100 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
                      <BanknotesIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-dark-900">{tax.name}</h3>
                      <p className="text-xs text-primary-600 font-mono font-semibold">HSN: {tax.hsnCode || '9983'}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        tax.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {tax.isActive ? 'Active' : 'Disabled'}
                    </span>
                    {tax.isDefault && (
                      <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs text-dark-500 min-h-[32px]">
                  {tax.description || 'Standard GST rate applied to general commercial orders.'}
                </p>

                {/* GST Split Box */}
                <div className="p-3 bg-gray-50 rounded-xl space-y-1 text-xs">
                  <div className="flex justify-between font-bold text-dark-900">
                    <span>Total GST Rate:</span>
                    <span className="text-sm text-primary-600 font-extrabold">{tax.rate}%</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1 text-[11px] text-gray-600 border-t border-gray-200">
                    <div>CGST: <strong className="text-dark-800">{tax.cgst || tax.rate / 2}%</strong></div>
                    <div>SGST: <strong className="text-dark-800">{tax.sgst || tax.rate / 2}%</strong></div>
                    <div>IGST: <strong className="text-dark-800">{tax.igst || tax.rate}%</strong></div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                <button
                  onClick={() => handleOpenEdit(tax)}
                  className="text-xs font-bold text-primary-600 hover:text-primary-700 flex items-center gap-1"
                >
                  <PencilSquareIcon className="w-4 h-4" /> Edit Rule
                </button>

                <button
                  onClick={() => setDeleteConfirm(tax)}
                  className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg transition-colors"
                >
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-lg font-bold text-dark-900">
                {editingId ? 'Edit Tax Rule' : 'Create Tax Rule'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 text-gray-400 hover:text-gray-700">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Rule Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Standard GST (18%)"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Total Rate (%) *</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    placeholder="18"
                    value={rate}
                    onChange={(e) => handleRateChange(e.target.value)}
                    className="input-field text-xs font-bold"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">HSN / SAC Code</label>
                  <input
                    type="text"
                    placeholder="9983"
                    value={hsnCode}
                    onChange={(e) => setHsnCode(e.target.value)}
                    className="input-field text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 p-3 bg-gray-50 rounded-xl border border-gray-100">
                <div>
                  <label className="text-[10px] font-bold text-dark-600 block mb-1">CGST (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={cgst}
                    onChange={(e) => setCgst(parseFloat(e.target.value) || 0)}
                    className="input-field text-xs text-center p-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-dark-600 block mb-1">SGST (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={sgst}
                    onChange={(e) => setSgst(parseFloat(e.target.value) || 0)}
                    className="input-field text-xs text-center p-1"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-dark-600 block mb-1">IGST (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={igst}
                    onChange={(e) => setIgst(parseFloat(e.target.value) || 0)}
                    className="input-field text-xs text-center p-1"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Description</label>
                <input
                  type="text"
                  placeholder="e.g. Standard tax rate applied on regular retail goods"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field text-xs"
                />
              </div>

              <div className="space-y-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-dark-800">
                  <input
                    type="checkbox"
                    checked={isDefault}
                    onChange={(e) => setIsDefault(e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span>Set as Default Tax Rule</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-dark-800">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span>Active Rule</span>
                </label>
              </div>

              <div className="flex gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || updating}
                  className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold"
                >
                  {creating || updating ? 'Saving...' : 'Save Tax Rule'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Tax Rule?"
        message={`Are you sure you want to delete tax rule "${deleteConfirm?.name}"?`}
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteMutation({ variables: { id: deleteConfirm._id } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
