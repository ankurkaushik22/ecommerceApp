import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_USERS } from '../../graphql/queries.js';
import { UPDATE_USER_STATUS, UPDATE_USER_ROLE } from '../../graphql/mutations.js';
import clsx from 'clsx';

const ROLE_COLORS = { admin: 'bg-red-100 text-red-700', vendor: 'bg-purple-100 text-purple-700', delivery: 'bg-blue-100 text-blue-700', customer: 'bg-green-100 text-green-700' };

export default function Users() {
  const [roleFilter, setRoleFilter] = useState('');
  const [page, setPage] = useState(1);

  const { data, loading, refetch } = useQuery(GET_ALL_USERS, {
    variables: { role: roleFilter || undefined, pagination: { page, limit: 20 } },
    fetchPolicy: 'cache-and-network',
  });

  const [updateStatus] = useMutation(UPDATE_USER_STATUS, {
    onCompleted: () => { toast.success('User status updated'); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const [updateRole] = useMutation(UPDATE_USER_ROLE, {
    onCompleted: () => { toast.success('Role updated'); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const users = data?.getAllUsers || [];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Users</h2>
          <p className="text-sm text-dark-500">{users.length} users shown</p>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 flex gap-3">
        <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} className="input-field w-48">
          <option value="">All Roles</option>
          <option value="customer">Customers</option>
          <option value="vendor">Vendors</option>
          <option value="delivery">Delivery</option>
          <option value="admin">Admins</option>
        </select>
      </div>

      {/* Users Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs text-dark-500 font-medium uppercase tracking-wider">
                <th className="px-4 py-3 text-left">User</th>
                <th className="px-4 py-3 text-left">Role</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Verified</th>
                <th className="px-4 py-3 text-left">Joined</th>
                <th className="px-4 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-50">
              {loading
                ? [...Array(8)].map((_, i) => (
                    <tr key={i}>{[...Array(6)].map((_, j) => <td key={j} className="px-4 py-3"><div className="h-4 bg-dark-100 rounded animate-pulse" /></td>)}</tr>
                  ))
                : users.map((user) => (
                    <motion.tr key={user._id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="hover:bg-dark-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img src={user.avatar} alt={user.name} className="w-9 h-9 rounded-full border-2 border-dark-100" />
                          <div>
                            <p className="text-sm font-medium text-dark-800">{user.name}</p>
                            <p className="text-xs text-dark-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <select
                          defaultValue={user.role}
                          onChange={(e) => updateRole({ variables: { userId: user._id, role: e.target.value } })}
                          className={clsx('text-xs font-medium px-2 py-1 rounded-full border-0 cursor-pointer', ROLE_COLORS[user.role])}
                        >
                          <option value="customer">Customer</option>
                          <option value="vendor">Vendor</option>
                          <option value="delivery">Delivery</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          onClick={() => updateStatus({ variables: { userId: user._id, isActive: !user.isActive } })}
                          className={clsx('text-xs px-2.5 py-1 rounded-full font-medium transition-colors', user.isActive ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-red-100 text-red-600 hover:bg-red-200')}
                        >
                          {user.isActive ? 'Active' : 'Banned'}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={user.isVerified ? 'text-green-500' : 'text-dark-200'}>
                          {user.isVerified ? '✓ Verified' : '—'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-dark-400">
                        {user.createdAt ? format(new Date(user.createdAt), 'MMM d, yyyy') : '—'}
                      </td>
                      <td className="px-4 py-3 text-center text-xs text-dark-400">
                        <span title={user.phone}>{user.phone || '—'}</span>
                      </td>
                    </motion.tr>
                  ))
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
