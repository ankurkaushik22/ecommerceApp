import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import {
  UserPlusIcon,
  MagnifyingGlassIcon,
  PencilSquareIcon,
  TrashIcon,
  CheckBadgeIcon,
  XMarkIcon,
  ShieldCheckIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import useAuthStore from '../../store/authStore.js';
import { GET_ALL_USERS, GET_ROLES } from '../../graphql/queries.js';
import {
  CREATE_USER,
  UPDATE_USER,
  DELETE_USER,
  UPDATE_USER_STATUS,
} from '../../graphql/mutations.js';
import ConfirmModal from '../../components/common/ConfirmModal';

const ROLE_BADGES = {
  superadmin: 'bg-amber-100 text-amber-900 border-amber-300 font-extrabold',
  admin: 'bg-rose-100 text-rose-800 border-rose-200',
  vendor: 'bg-purple-100 text-purple-800 border-purple-200',
  delivery: 'bg-blue-100 text-blue-800 border-blue-200',
  manager: 'bg-teal-100 text-teal-800 border-teal-200',
  customer: 'bg-emerald-100 text-emerald-800 border-emerald-200',
};

export default function Users() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const currentUser = useAuthStore((s) => s.user);
  const isSuperAdmin = currentUser?.role === 'superadmin';

  const [roleFilter, setRoleFilter] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);

  // Form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('vendor');
  const [phone, setPhone] = useState('');
  const [isActive, setIsActive] = useState(true);

  const { data, loading, refetch } = useQuery(GET_ALL_USERS, {
    variables: { role: roleFilter || undefined, pagination: { limit: 100 } },
    fetchPolicy: 'network-only',
  });

  const { data: rolesData } = useQuery(GET_ROLES, {
    fetchPolicy: 'cache-and-network',
  });

  const [createUserMutation, { loading: creating }] = useMutation(CREATE_USER, {
    onCompleted: () => {
      toast.success('User account created successfully!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateUserMutation, { loading: updating }] = useMutation(UPDATE_USER, {
    onCompleted: () => {
      toast.success('User updated successfully!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteUserMutation] = useMutation(DELETE_USER, {
    onCompleted: () => {
      toast.success('User deleted');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateStatusMutation] = useMutation(UPDATE_USER_STATUS, {
    onCompleted: () => {
      toast.success('User status updated');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const users = data?.getAllUsers || [];

  // Available staff roles for creation (excluding customer and excluding superadmin if non-superadmin)
  const assignableRoles = useMemo(() => {
    const defaultRoles = [
      { roleName: 'vendor', displayName: 'Vendor / Seller' },
      { roleName: 'delivery', displayName: 'Delivery Agent' },
      { roleName: 'admin', displayName: 'Administrator' },
    ];

    if (isSuperAdmin) {
      defaultRoles.unshift({ roleName: 'superadmin', displayName: 'Super Administrator' });
    }

    const fetched = (rolesData?.getRoles || []).filter((r) => {
      if (r.roleName === 'customer') return false;
      if (r.roleName === 'superadmin' && !isSuperAdmin) return false;
      return true;
    });

    const map = new Map();
    [...defaultRoles, ...fetched].forEach((r) => map.set(r.roleName, r));
    return Array.from(map.values());
  }, [rolesData, isSuperAdmin]);

  // Filter list: hide superadmin accounts from regular admins
  const visibleUsers = useMemo(() => {
    return users.filter((u) => {
      if (!isSuperAdmin && u.role === 'superadmin') return false;
      return true;
    });
  }, [users, isSuperAdmin]);

  const filteredUsers = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return visibleUsers.filter((u) => {
      return u.name?.toLowerCase().includes(term) || u.email?.toLowerCase().includes(term);
    });
  }, [visibleUsers, searchTerm]);

  const handleOpenCreate = () => {
    setEditingUser(null);
    setName('');
    setEmail('');
    setPassword('');
    setRole('vendor');
    setPhone('');
    setIsActive(true);
    setModalOpen(true);
  };

  const handleOpenEdit = (u) => {
    setEditingUser(u);
    setName(u.name);
    setEmail(u.email);
    setPassword('');
    setRole(u.role);
    setPhone(u.phone || '');
    setIsActive(u.isActive);
    setModalOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      toast.error('Name and Email are required');
      return;
    }

    if (editingUser) {
      const input = {
        name: name.trim(),
        email: email.trim(),
        role,
        phone: phone.trim(),
        isActive,
      };
      if (password.trim()) input.password = password.trim();

      updateUserMutation({
        variables: {
          id: editingUser._id,
          input,
        },
      });
    } else {
      if (!password.trim() || password.length < 6) {
        toast.error('Password must be at least 6 characters');
        return;
      }
      createUserMutation({
        variables: {
          input: {
            name: name.trim(),
            email: email.trim(),
            password: password.trim(),
            role,
            phone: phone.trim(),
          },
        },
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">User Management</h1>
          <p className="text-sm text-dark-500 mt-1">
            Create and manage staff accounts, vendor portals, and delivery executives with role-based access
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="btn-primary flex items-center gap-2 text-sm shadow-md"
        >
          <UserPlusIcon className="w-5 h-5" />
          <span>Add Staff / User</span>
        </button>
      </div>

      {/* Filter & Search */}
      <div className="card p-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white border border-gray-100">
        <div className="relative w-full sm:w-80">
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 text-xs"
          />
          <MagnifyingGlassIcon className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="input-field text-xs w-full sm:w-48"
          >
            <option value="">All Roles (5)</option>
            {isSuperAdmin && <option value="superadmin">Super Administrators</option>}
            <option value="admin">Administrators</option>
            <option value="vendor">Vendors (Sellers)</option>
            <option value="delivery">Delivery Agents</option>
            <option value="customer">Customers</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="card overflow-hidden bg-white border border-gray-100 shadow-sm rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 border-b border-gray-100 text-dark-500 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4">User</th>
                <th className="py-3.5 px-4">Role</th>
                <th className="py-3.5 px-4">Phone</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4">Joined</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-dark-800 font-medium">
              {loading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} className="animate-pulse">
                    <td colSpan={6} className="py-4 px-4 bg-gray-50/50" />
                  </tr>
                ))
              ) : filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-400">
                    No users matching criteria.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const isUserSuperAdmin = u.role === 'superadmin';
                  return (
                    <tr key={u._id} className="hover:bg-gray-50/80 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(u.name)}`}
                            alt=""
                            className="w-9 h-9 rounded-full border border-gray-200 object-cover"
                          />
                          <div>
                            <p className="font-bold text-dark-900">{u.name}</p>
                            <p className="text-[11px] text-gray-400">{u.email}</p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                            ROLE_BADGES[u.role] || 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-gray-500 font-mono">
                        {u.phone || '—'}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <button
                          disabled={isUserSuperAdmin && !isSuperAdmin}
                          onClick={() =>
                            updateStatusMutation({
                              variables: { userId: u._id, isActive: !u.isActive },
                            })
                          }
                          className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full transition-all disabled:opacity-50 ${
                            u.isActive
                              ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                              : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                          }`}
                        >
                          {u.isActive ? 'Active' : 'Suspended'}
                        </button>
                      </td>

                      <td className="py-3.5 px-4 text-gray-400">
                        {u.createdAt ? format(new Date(u.createdAt), 'dd MMM yyyy') : '—'}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        {/* Only allow editing/deleting if permitted */}
                        {(!isUserSuperAdmin || isSuperAdmin) && (
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => handleOpenEdit(u)}
                              className="p-1.5 text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                              title="Edit User"
                            >
                              <PencilSquareIcon className="w-4 h-4" />
                            </button>

                            {currentUser?._id !== u._id && (
                              <button
                                onClick={() => setDeleteConfirm(u)}
                                className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                                title="Delete User"
                              >
                                <TrashIcon className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit User Modal */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h3 className="text-lg font-bold text-dark-900">
                  {editingUser ? `Edit User: ${editingUser.name}` : 'Create New Staff / User'}
                </h3>
                <p className="text-xs text-dark-500">
                  {editingUser ? 'Update profile and role permissions' : 'Create an account for staff, vendor, or delivery agent'}
                </p>
              </div>
              <button onClick={() => setModalOpen(false)} className="p-1 text-gray-400 hover:text-gray-700">
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Full Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Suresh Kumar"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field text-xs"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Email Address *</label>
                <input
                  type="email"
                  placeholder="user@shopzone.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-field text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Role / Module Access *</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    className="input-field text-xs font-semibold"
                    required
                  >
                    {assignableRoles.map((r) => (
                      <option key={r.roleName} value={r.roleName}>
                        {r.displayName || r.roleName}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Phone Number</label>
                  <input
                    type="text"
                    placeholder="+91 98765 43210"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="input-field text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">
                  {editingUser ? 'New Password (leave blank to keep current)' : 'Password *'}
                </label>
                <input
                  type="password"
                  placeholder={editingUser ? '••••••••' : 'Min 6 characters'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field text-xs"
                  required={!editingUser}
                />
              </div>

              {editingUser && (
                <div className="pt-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-dark-800">
                    <input
                      type="checkbox"
                      checked={isActive}
                      onChange={(e) => setIsActive(e.target.checked)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span>Account Active (Allowed to Login to Portal)</span>
                  </label>
                </div>
              )}

              <div className="flex gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || updating}
                  className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold"
                >
                  {creating || updating ? 'Saving...' : editingUser ? 'Update User' : 'Create User'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete User Account?"
        message={`Are you sure you want to delete user account for "${deleteConfirm?.name}" (${deleteConfirm?.email})? This action cannot be undone.`}
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteUserMutation({ variables: { id: deleteConfirm._id } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
