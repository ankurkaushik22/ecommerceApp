import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import {
  MagnifyingGlassIcon,
  CheckBadgeIcon,
  XMarkIcon,
  PlusIcon,
  BuildingStorefrontIcon,
  CheckIcon,
  CreditCardIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_VENDORS } from '../../graphql/queries.js';
import { UPDATE_USER_STATUS, UPDATE_USER, CREATE_USER } from '../../graphql/mutations.js';

export default function Vendors() {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewBankVendor, setViewBankVendor] = useState(null);

  // Form state for creating vendor
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [vendorCategory, setVendorCategory] = useState('');
  const [selectedVerticals, setSelectedVerticals] = useState(['shopping']);

  const { data, loading, refetch } = useQuery(GET_VENDORS, {
    fetchPolicy: 'network-only',
  });

  const [updateStatusMutation] = useMutation(UPDATE_USER_STATUS, {
    onCompleted: () => {
      toast.success('Vendor status updated');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateUserMutation] = useMutation(UPDATE_USER, {
    onCompleted: () => {
      toast.success('Vendor updated!');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [createUserMutation, { loading: creating }] = useMutation(CREATE_USER, {
    onCompleted: () => {
      toast.success('Vendor account created successfully!');
      setShowAddModal(false);
      setName('');
      setEmail('');
      setPassword('');
      setPhone('');
      setVendorCategory('');
      setSelectedVerticals(['shopping']);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const vendors = data?.getVendors || [];

  const filteredVendors = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return vendors.filter((u) => {
      return u.name?.toLowerCase().includes(term) || u.email?.toLowerCase().includes(term);
    });
  }, [vendors, searchTerm]);

  const handleCreateVendor = (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      toast.error('Please complete all required fields.');
      return;
    }
    createUserMutation({
      variables: {
        input: {
          name: name.trim(),
          email: email.trim().toLowerCase(),
          password,
          role: 'vendor',
          phone: phone.trim(),
          vendorCategory: vendorCategory.trim() || 'General Store',
          vendorVerticals: selectedVerticals,
          vendorVertical: selectedVerticals[0] || 'shopping',
        },
      },
    });
  };

  const toggleModalVertical = (vId) => {
    if (selectedVerticals.includes(vId)) {
      if (selectedVerticals.length === 1) return; // keep at least 1
      setSelectedVerticals(selectedVerticals.filter((v) => v !== vId));
    } else {
      setSelectedVerticals([...selectedVerticals, vId]);
    }
  };

  const totalVendors = vendors.length;
  const activeVendors = vendors.filter((v) => v.isActive).length;

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Vendors & Merchant Management</h2>
          <p className="text-sm text-dark-500">Manage seller accounts & assigned verticals</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 btn-primary self-start sm:self-auto cursor-pointer"
        >
          <PlusIcon className="w-4 h-4" /> Add Vendor Account
        </motion.button>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-primary-50 text-primary-600 flex items-center justify-center">
            <BuildingStorefrontIcon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-dark-500 font-medium">Total Registered Vendors</p>
            <h3 className="text-xl font-bold text-dark-900 mt-0.5">{totalVendors}</h3>
          </div>
        </div>

        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <CheckIcon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-dark-500 font-medium">Active Vendors</p>
            <h3 className="text-xl font-bold text-dark-900 mt-0.5">{activeVendors}</h3>
          </div>
        </div>

        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center">
            <XMarkIcon className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs text-dark-500 font-medium">Inactive Vendors</p>
            <h3 className="text-xl font-bold text-dark-900 mt-0.5">{totalVendors - activeVendors}</h3>
          </div>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="card p-4">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-md">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-400" />
            <input
              type="text"
              placeholder="Search vendors by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field pl-9"
            />
          </div>
        </div>
      </div>

      {/* Vendors Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-dark-50 text-xs font-medium text-dark-500 uppercase tracking-wider">
                <th className="px-6 py-3 text-left">Vendor Store</th>
                <th className="px-6 py-3 text-left">Email</th>
                <th className="px-6 py-3 text-left">Assigned Verticals</th>
                <th className="px-6 py-3 text-left">Joined</th>
                <th className="px-6 py-3 text-center">Verification</th>
                <th className="px-6 py-3 text-center">Status</th>
                <th className="px-6 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-100">
              {loading ? (
                <tr>
                  <td colSpan="7" className="px-6 py-8 text-center text-dark-400">Loading vendors...</td>
                </tr>
              ) : filteredVendors.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-6 py-8 text-center text-dark-400">No vendors found.</td>
                </tr>
              ) : (
                filteredVendors.map((vendor) => (
                  <motion.tr
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={vendor._id}
                    className="hover:bg-dark-50/50"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-3">
                        <img
                          src={vendor.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(vendor.name)}`}
                          alt={vendor.name}
                          className="w-8 h-8 rounded-full border border-dark-200"
                        />
                        <div>
                          <span className="text-sm font-bold text-dark-900 block">{vendor.name}</span>
                          <span className="text-[11px] text-dark-400 block">{vendor.vendorCategory || 'General Store'}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-600">
                      {vendor.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 flex-wrap max-w-xs">
                        {[
                          { id: 'shopping', label: 'Shopping', icon: '🛍️' },
                          { id: 'food', label: 'Food', icon: '🍔' },
                          { id: 'grocery', label: 'Grocery', icon: '🥦' },
                          { id: 'services', label: 'Services', icon: '🛠️' },
                        ].map((v) => {
                          const currentVerticals = vendor.vendorVerticals?.length
                            ? vendor.vendorVerticals
                            : [vendor.vendorVertical || 'shopping'];
                          const isAssigned = currentVerticals.includes(v.id);

                          return (
                            <button
                              key={v.id}
                              type="button"
                              onClick={() => {
                                let newVerticals;
                                if (isAssigned) {
                                  newVerticals = currentVerticals.filter((item) => item !== v.id);
                                  if (newVerticals.length === 0) newVerticals = [v.id];
                                } else {
                                  newVerticals = [...currentVerticals, v.id];
                                }
                                updateUserMutation({
                                  variables: {
                                    id: vendor._id,
                                    input: { vendorVerticals: newVerticals, vendorVertical: newVerticals[0] },
                                  },
                                });
                              }}
                              className={`text-[11px] font-bold px-2 py-1 rounded-lg border transition-all flex items-center gap-1 cursor-pointer ${
                                isAssigned
                                  ? 'bg-primary-50 text-primary-700 border-primary-300 shadow-2xs'
                                  : 'bg-gray-50 text-gray-400 border-gray-200 hover:bg-gray-100 hover:text-gray-600'
                              }`}
                              title={isAssigned ? `Remove ${v.label}` : `Assign ${v.label}`}
                            >
                              <span>{v.icon}</span>
                              <span>{v.label}</span>
                              {isAssigned && <span className="text-[10px] text-primary-600 font-extrabold">✓</span>}
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-dark-500 font-semibold">
                      {vendor.createdAt ? format(new Date(isNaN(Number(vendor.createdAt)) ? vendor.createdAt : parseInt(vendor.createdAt)), 'MMM d, yyyy') : 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      {vendor.isVerified ? (
                        <div className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-md text-xs font-semibold">
                          <CheckBadgeIcon className="w-4 h-4 text-emerald-600" />
                          <span>Verified</span>
                          <button
                            onClick={() =>
                              updateUserMutation({
                                variables: { id: vendor._id, input: { isVerified: false } }
                              })
                            }
                            className="ml-1 text-[10px] text-dark-400 hover:text-red-600 hover:underline font-normal"
                            title="Revoke Verification"
                          >
                            (Revoke)
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() =>
                            updateUserMutation({
                              variables: { id: vendor._id, input: { isVerified: true } }
                            })
                          }
                          className="inline-flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-xs transition-all cursor-pointer"
                        >
                          <CheckBadgeIcon className="w-4 h-4" />
                          <span>Verify Vendor</span>
                        </button>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          vendor.isActive
                            ? 'bg-green-100 text-green-700'
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {vendor.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => setViewBankVendor(vendor)}
                          className="text-xs font-medium px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                          title="View Vendor Bank & UPI Details"
                        >
                          <CreditCardIcon className="w-4 h-4 text-gray-500" />
                          <span>Bank Details</span>
                        </button>
                        <button
                          onClick={() => updateStatusMutation({ variables: { userId: vendor._id, isActive: !vendor.isActive } })}
                          className={`text-xs font-medium px-3 py-1.5 rounded-lg border cursor-pointer ${vendor.isActive ? 'border-red-200 text-red-600 hover:bg-red-50' : 'border-green-200 text-green-600 hover:bg-green-50'}`}
                        >
                          {vendor.isActive ? 'Disable' : 'Enable'}
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Vendor Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">Create Vendor Account</h3>
                  <p className="text-xs text-dark-500">Add a new seller account with assigned business verticals</p>
                </div>
                <button onClick={() => setShowAddModal(false)} className="p-1 text-gray-400 hover:text-gray-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateVendor} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Vendor / Store Name *</label>
                  <input
                    type="text"
                    placeholder="e.g. Asian Paints Hardware"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="input-field text-xs"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-dark-700 block mb-1">Email Address *</label>
                    <input
                      type="email"
                      placeholder="vendor@store.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="input-field text-xs"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-dark-700 block mb-1">Account Password *</label>
                    <input
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="input-field text-xs"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-dark-700 block mb-1">Phone Number</label>
                    <input
                      type="text"
                      placeholder="+91 9876543210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="input-field text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-dark-700 block mb-1">Business Category</label>
                    <input
                      type="text"
                      placeholder="e.g. Hardware & Paints"
                      value={vendorCategory}
                      onChange={(e) => setVendorCategory(e.target.value)}
                      className="input-field text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Assigned Business Verticals *</label>
                  <div className="grid grid-cols-2 gap-2 p-3 bg-gray-50 rounded-2xl border border-gray-100">
                    {[
                      { id: 'shopping', label: '🛍️ Shopping (Retail)' },
                      { id: 'food', label: '🍔 Food Delivery' },
                      { id: 'grocery', label: '🥦 Grocery (Fresh)' },
                      { id: 'services', label: '🛠️ Services' },
                    ].map((v) => {
                      const isSelected = selectedVerticals.includes(v.id);
                      return (
                        <button
                          key={v.id}
                          type="button"
                          onClick={() => toggleModalVertical(v.id)}
                          className={`p-2.5 rounded-xl border text-xs font-bold text-left transition-all flex items-center justify-between ${
                            isSelected
                              ? 'bg-white border-primary-500 text-primary-900 shadow-2xs'
                              : 'bg-white/60 border-gray-200 text-gray-500 hover:bg-white'
                          }`}
                        >
                          <span>{v.label}</span>
                          {isSelected && <span className="text-primary-600 font-extrabold">✓</span>}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex gap-3 pt-3 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold cursor-pointer"
                  >
                    {creating ? 'Creating...' : 'Create Vendor'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* View Bank & Payment Info Modal */}
      <AnimatePresence>
        {viewBankVendor && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <div>
                  <h3 className="text-lg font-bold text-dark-900">Vendor Profile & Bank Details</h3>
                  <p className="text-xs text-dark-500">{viewBankVendor.name} ({viewBankVendor.vendorCategory || 'General Store'})</p>
                </div>
                <button onClick={() => setViewBankVendor(null)} className="p-1 text-gray-400 hover:text-gray-700">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4 text-xs">
                <div className="bg-gray-50 p-3.5 rounded-2xl border border-gray-100 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Vendor Email:</span>
                    <span className="font-semibold text-gray-900">{viewBankVendor.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Phone Number:</span>
                    <span className="font-semibold text-gray-900">{viewBankVendor.phone || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Category:</span>
                    <span className="font-semibold text-gray-900">{viewBankVendor.vendorCategory || 'General'}</span>
                  </div>
                </div>

                <h4 className="font-bold text-dark-900 text-sm pt-1">Bank Account & UPI Details</h4>
                
                {viewBankVendor.bankDetails && (viewBankVendor.bankDetails.accountNumber || viewBankVendor.bankDetails.upiId) ? (
                  <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 space-y-2.5">
                    <div className="flex justify-between items-center">
                      <span className="text-emerald-800 font-medium">Bank Name:</span>
                      <span className="font-bold text-emerald-950">{viewBankVendor.bankDetails.bankName || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-emerald-800 font-medium">Account Holder:</span>
                      <span className="font-bold text-emerald-950">{viewBankVendor.bankDetails.accountHolderName || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-emerald-800 font-medium">Account Number:</span>
                      <span className="font-mono font-bold text-emerald-950">{viewBankVendor.bankDetails.accountNumber || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-emerald-800 font-medium">IFSC Code:</span>
                      <span className="font-mono font-bold text-emerald-950">{viewBankVendor.bankDetails.ifscCode || 'N/A'}</span>
                    </div>
                    <div className="border-t border-emerald-200/60 pt-2 flex justify-between items-center">
                      <span className="text-emerald-800 font-medium">UPI ID:</span>
                      <span className="font-mono font-bold text-emerald-950">{viewBankVendor.bankDetails.upiId || 'N/A'}</span>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 text-center">
                    <p className="font-semibold mb-1">No Bank Details Saved</p>
                    <p className="text-[11px] text-amber-700">This vendor has not filled in their bank account or UPI details yet in their profile.</p>
                  </div>
                )}
              </div>

              <div className="pt-2 border-t border-gray-100 flex justify-end">
                <button
                  type="button"
                  onClick={() => setViewBankVendor(null)}
                  className="w-full py-2.5 rounded-xl btn-primary text-xs font-bold cursor-pointer"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

