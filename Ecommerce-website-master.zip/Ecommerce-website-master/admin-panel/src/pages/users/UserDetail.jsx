import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import { ArrowLeftIcon, EnvelopeIcon, PhoneIcon } from '@heroicons/react/24/outline';

const GET_USER_DETAIL = gql`
  query GetUserDetail($id: ID!, $email: String) {
    getUserById(id: $id) {
      _id name email role avatar phone createdAt
      addresses { fullName phone addressLine1 city state postalCode country isDefault }
    }
    getAllOrders(search: $email) {
      orders {
        _id orderNumber status paymentStatus total createdAt customer { _id email }
        items { name quantity price }
      }
    }
  }
`;

export default function UserDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const { data, loading, error } = useQuery(GET_USER_DETAIL, {
    variables: { id, email: id },
    fetchPolicy: 'network-only'
  });

  if (loading) return <div className="p-8 flex justify-center text-gray-500">Loading...</div>;
  if (error || !data?.getUserById) return <div className="p-8 text-center text-red-500">User not found</div>;

  const user = data.getUserById;
  const orders = (data.getAllOrders?.orders || []).filter(Boolean).filter(o => o.customer?._id === id || o.customer?.email === user.email);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ArrowLeftIcon className="w-5 h-5 text-gray-600" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">User Details</h1>
          <p className="text-sm text-gray-500">View customer profile and order history</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-6 col-span-1 border border-gray-200 shadow-sm rounded-xl bg-white h-fit">
          <div className="flex flex-col items-center text-center">
            {user.avatar ? (
              <img src={user.avatar} alt={user.name} className="w-24 h-24 rounded-full object-cover mb-4 ring-4 ring-brand-50" />
            ) : (
              <div className="w-24 h-24 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center text-3xl font-bold mb-4 ring-4 ring-brand-50">
                {user.name.charAt(0).toUpperCase()}
              </div>
            )}
            <h2 className="text-xl font-bold text-gray-900">{user.name}</h2>
            <span className="px-3 py-1 bg-brand-50 text-brand-700 text-xs font-semibold rounded-full mt-2 capitalize">
              {user.role}
            </span>
          </div>

          <div className="mt-6 space-y-4">
            <div className="flex items-center gap-3 text-sm text-gray-600">
              <EnvelopeIcon className="w-5 h-5 text-gray-400" />
              <a href={`mailto:${user.email}`} className="hover:text-brand-600">{user.email}</a>
            </div>
            {user.phone && (
              <div className="flex items-center gap-3 text-sm text-gray-600">
                <PhoneIcon className="w-5 h-5 text-gray-400" />
                <span>{user.phone}</span>
              </div>
            )}
          </div>
        </div>

        <div className="col-span-1 lg:col-span-2 space-y-4">
          <div className="card p-6 border border-gray-200 shadow-sm rounded-xl bg-white">
            <h3 className="font-bold text-gray-900 mb-4 text-lg">Order History</h3>
            
            {orders.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No orders found for this user.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-500 uppercase bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 rounded-l-lg">Order ID</th>
                      <th className="px-4 py-3">Date</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Total</th>
                      <th className="px-4 py-3 rounded-r-lg">Items</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(order => (
                      <tr key={order._id} className="border-b border-gray-100 last:border-0 hover:bg-gray-50/50">
                        <td className="px-4 py-3 font-medium text-brand-600">
                          <button onClick={() => navigate('/orders')} className="hover:underline">
                            {order?.orderNumber || '—'}
                          </button>
                        </td>
                        <td className="px-4 py-3 text-gray-600">
                          {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : '—'}
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-1 rounded-md text-[11px] font-medium uppercase tracking-wider bg-gray-100 text-gray-700">
                            {order.status?.replace(/_/g, ' ') || '—'}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-medium">₹{order.total?.toFixed(2) || '0.00'}</td>
                        <td className="px-4 py-3 text-gray-500">
                          {order.items?.length || 0} item(s)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
