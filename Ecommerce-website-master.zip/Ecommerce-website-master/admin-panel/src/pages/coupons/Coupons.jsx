import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';
import { PlusIcon, PencilIcon, TrashIcon, XMarkIcon, ClipboardDocumentIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ALL_COUPONS } from '../../graphql/queries.js';
import { CREATE_COUPON, UPDATE_COUPON, DELETE_COUPON } from '../../graphql/mutations.js';
import clsx from 'clsx';
import ConfirmModal from '../../components/common/ConfirmModal';

export default function Coupons() {
  const [showModal, setShowModal] = useState(false);
  const [editCoupon, setEditCoupon] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const { data, loading, refetch } = useQuery(GET_ALL_COUPONS);
  const [deleteCoupon] = useMutation(DELETE_COUPON, {
    onCompleted: () => { toast.success('Coupon deleted'); setDeleteConfirm(null); refetch(); },
    onError: (e) => toast.error(e.message),
  });

  const coupons = data?.getAllCoupons || [];

  const copyCode = (code) => {
    navigator.clipboard.writeText(code);
    toast.success(`Copied: ${code}`);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-dark-900">Coupons</h2>
          <p className="text-sm text-dark-500">{coupons.length} coupons total</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
          onClick={() => { setEditCoupon(null); setShowModal(true); }}
          className="flex items-center gap-2 btn-primary"
        >
          <PlusIcon className="w-4 h-4" /> Create Coupon
        </motion.button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading
          ? [...Array(6)].map((_, i) => <div key={i} className="card p-5 h-40 animate-pulse bg-dark-100" />)
          : coupons.map((coupon) => (
              <motion.div
                key={coupon._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={clsx('card p-5 relative overflow-hidden border-2', coupon.isActive ? 'border-transparent' : 'border-dark-200 opacity-60')}
              >
                {/* Decorative dashes */}
                <div className="absolute left-0 top-1/2 -translate-y-1/2 flex flex-col gap-1.5">
                  {[...Array(4)].map((_, i) => <div key={i} className="w-2 h-1 bg-dark-100 rounded-r-full" />)}
                </div>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 flex flex-col gap-1.5">
                  {[...Array(4)].map((_, i) => <div key={i} className="w-2 h-1 bg-dark-100 rounded-l-full" />)}
                </div>

                <div className="pl-2 pr-2">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <button
                        onClick={() => copyCode(coupon.code)}
                        className="flex items-center gap-1.5 text-lg font-bold text-primary-600 font-mono tracking-wider hover:text-primary-700"
                      >
                        {coupon.code} <ClipboardDocumentIcon className="w-4 h-4" />
                      </button>
                      <p className="text-xs text-dark-400 mt-0.5">{coupon.description}</p>
                    </div>
                    <span className={clsx(
                      'text-2xl font-bold',
                      coupon.type === 'percentage' ? 'text-green-600' : 'text-amber-600'
                    )}>
                      {coupon.type === 'percentage' ? `${coupon.value}%` : `₹${coupon.value}`}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-dark-500 mb-3">
                    <span>Min: ₹{coupon.minOrderAmount || 0}</span>
                    <span>Used: {coupon.usedCount}/{coupon.usageLimit || '∞'}</span>
                    {coupon.expiresAt && (
                      <span className="col-span-2 text-amber-600">
                        Expires: {format(new Date(coupon.expiresAt), 'MMM d, yyyy')}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <span className={clsx('text-xs px-2 py-0.5 rounded-full font-medium', coupon.isActive ? 'badge-success' : 'badge-gray')}>
                      {coupon.isActive ? 'Active' : 'Inactive'}
                    </span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => { setEditCoupon(coupon); setShowModal(true); }}
                        className="p-1.5 text-dark-400 hover:text-primary-600 hover:bg-primary-50 rounded-lg"
                      >
                        <PencilIcon className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm(coupon)}
                        className="p-1.5 text-dark-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <TrashIcon className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
        }
      </div>

      {/* Coupon Modal */}
      <AnimatePresence>
        {showModal && (
          <CouponModal
            coupon={editCoupon}
            onClose={() => setShowModal(false)}
            onSuccess={() => { setShowModal(false); refetch(); }}
          />
        )}
      </AnimatePresence>

      {/* Delete Confirm */}
      <ConfirmModal
        isOpen={!!deleteConfirm}
        title={`Delete Coupon "${deleteConfirm?.code}"?`}
        message="Are you sure you want to delete this coupon? This action cannot be undone."
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteCoupon({ variables: { id: deleteConfirm._id } });
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}

function CouponModal({ coupon, onClose, onSuccess }) {
  const isEdit = !!coupon;
  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: coupon
      ? { ...coupon, startsAt: coupon.startsAt ? coupon.startsAt.slice(0, 10) : '', expiresAt: coupon.expiresAt ? coupon.expiresAt.slice(0, 10) : '' }
      : { type: 'percentage', value: 10, minOrderAmount: 0, isActive: true },
  });

  const [createCoupon, { loading: creating }] = useMutation(CREATE_COUPON, {
    onCompleted: () => { toast.success('Coupon created!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });
  const [updateCoupon, { loading: updating }] = useMutation(UPDATE_COUPON, {
    onCompleted: () => { toast.success('Coupon updated!'); onSuccess(); },
    onError: (e) => toast.error(e.message),
  });

  const loading = creating || updating;
  const type = watch('type');

  const onSubmit = (data) => {
    const input = {
      ...data,
      code: data.code.toUpperCase(),
      value: parseFloat(data.value),
      minOrderAmount: parseFloat(data.minOrderAmount) || 0,
      maxDiscountAmount: data.maxDiscountAmount ? parseFloat(data.maxDiscountAmount) : null,
      usageLimit: data.usageLimit ? parseInt(data.usageLimit) : null,
      startsAt: data.startsAt || null,
      expiresAt: data.expiresAt || null,
      isActive: !!data.isActive,
    };
    if (isEdit) updateCoupon({ variables: { id: coupon._id, input } });
    else createCoupon({ variables: { input } });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto shadow-2xl"
      >
        <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold">{isEdit ? 'Edit Coupon' : 'Create Coupon'}</h2>
          <button onClick={onClose}><XMarkIcon className="w-5 h-5 text-dark-400" /></button>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Coupon Code *</label>
            <input {...register('code', { required: 'Required' })} className="input-field uppercase font-mono tracking-widest" placeholder="SAVE20" />
            {errors.code && <p className="text-xs text-red-500 mt-1">{errors.code.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Type *</label>
              <select {...register('type')} className="input-field">
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed Discount (₹)</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Value *</label>
              <input {...register('value', { required: 'Required', min: 0 })} type="number" step="0.01" className="input-field" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Description</label>
            <input {...register('description')} className="input-field" placeholder="e.g. 20% off your first order" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Min Order (₹)</label>
              <input {...register('minOrderAmount')} type="number" step="0.01" className="input-field" />
            </div>
            {type === 'percentage' && (
              <div>
                <label className="block text-sm font-medium text-dark-700 mb-1">Max Discount (₹)</label>
                <input {...register('maxDiscountAmount')} type="number" step="0.01" className="input-field" placeholder="Optional" />
              </div>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-700 mb-1">Usage Limit</label>
            <input {...register('usageLimit')} type="number" className="input-field" placeholder="Leave blank for unlimited" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Starts At</label>
              <input {...register('startsAt')} type="date" className="input-field" />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-700 mb-1">Expires At</label>
              <input {...register('expiresAt')} type="date" className="input-field" />
            </div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input {...register('isActive')} type="checkbox" className="w-4 h-4 text-primary-600 rounded" />
            <span className="text-sm text-dark-700">Active</span>
          </label>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 btn-secondary">Cancel</button>
            <button type="submit" disabled={loading} className="flex-1 btn-primary">
              {loading ? 'Saving...' : isEdit ? 'Update' : 'Create'}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}
