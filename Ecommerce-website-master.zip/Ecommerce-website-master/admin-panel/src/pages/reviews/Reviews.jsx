import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  StarIcon,
  ChatBubbleLeftRightIcon,
  TrashIcon,
  CheckBadgeIcon,
  FunnelIcon,
  XMarkIcon,
} from '@heroicons/react/24/outline';
import { StarIcon as StarSolid } from '@heroicons/react/24/solid';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import { GET_ALL_REVIEWS } from '../../graphql/queries.js';
import { REPLY_TO_REVIEW, DELETE_REVIEW } from '../../graphql/mutations.js';
import useVerticalStore, { getCategoryVertical } from '../../store/verticalStore.js';
import ConfirmModal from '../../components/common/ConfirmModal';

export default function Reviews() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [targetFilter, setTargetFilter] = useState('all'); // 'all' | 'product' | 'seller' | 'delivery'
  const [replyingReview, setReplyingReview] = useState(null);
  const [replyText, setReplyText] = useState('');

  const { data, loading, refetch } = useQuery(GET_ALL_REVIEWS, {
    variables: {
      targetType: targetFilter === 'all' ? undefined : targetFilter,
      pagination: { limit: 100 },
    },
    fetchPolicy: 'network-only',
  });

  const [replyMutation, { loading: replying }] = useMutation(REPLY_TO_REVIEW, {
    onCompleted: () => {
      toast.success('Reply submitted successfully!');
      setReplyingReview(null);
      setReplyText('');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteMutation] = useMutation(DELETE_REVIEW, {
    onCompleted: () => {
      toast.success('Review deleted');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const rawReviews = data?.getAllReviews || [];
  const reviews = rawReviews.filter((rev) => {
    if (activeVertical === 'all') return true;
    const prodVertical = rev.product?.category ? getCategoryVertical(rev.product.category) : null;
    const orderVertical = rev.order?.vertical || null;
    const vendorVertical = rev.vendor?.vendorVertical || null;
    const revVertical = prodVertical || orderVertical || vendorVertical || 'shopping';
    return revVertical === activeVertical;
  });

  const handleOpenReply = (rev) => {
    setReplyingReview(rev);
    setReplyText(rev.reply?.comment || '');
  };

  const handleSendReply = (e) => {
    e.preventDefault();
    if (!replyText.trim()) {
      toast.error('Please enter a reply message');
      return;
    }
    replyMutation({
      variables: {
        reviewId: replyingReview._id,
        comment: replyText.trim(),
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Reviews & Customer Ratings</h1>
          <p className="text-sm text-dark-500 mt-1">
            Monitor ratings and respond to customer reviews for Products, Sellers/Vendors, and Delivery Executives
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex rounded-2xl bg-gray-100 p-1 gap-1">
          {[
            { key: 'all', label: 'All Reviews' },
            { key: 'product', label: '🛍️ Products' },
            { key: 'seller', label: '🏬 Sellers' },
            { key: 'delivery', label: '🚚 Delivery' },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setTargetFilter(tab.key)}
              className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-all ${
                targetFilter === tab.key
                  ? 'bg-white text-primary-600 shadow-sm'
                  : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Reviews List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {loading ? (
          [...Array(4)].map((_, i) => (
            <div key={i} className="card p-6 h-48 animate-pulse bg-gray-100 rounded-2xl" />
          ))
        ) : reviews.length === 0 ? (
          <div className="col-span-full py-16 text-center card bg-white border border-gray-100 rounded-3xl space-y-2">
            <p className="text-4xl">⭐</p>
            <h3 className="text-lg font-bold text-dark-900">No Reviews Found</h3>
            <p className="text-xs text-dark-500">No customer reviews under this category yet.</p>
          </div>
        ) : (
          reviews.map((rev) => (
            <motion.div
              key={rev._id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-5 space-y-4 hover:shadow-md transition-all border border-gray-100 bg-white rounded-2xl flex flex-col justify-between"
            >
              <div className="space-y-3">
                {/* Review Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={rev.user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(rev.user?.name || 'Customer')}`}
                      alt=""
                      className="w-9 h-9 rounded-full border border-gray-200"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-dark-900">{rev.user?.name || 'Customer'}</span>
                        {rev.verified && (
                          <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-0.5 bg-emerald-50 px-1.5 py-0.2 rounded-md">
                            <CheckBadgeIcon className="w-3 h-3" /> Verified
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-gray-400">
                        {rev.createdAt ? format(new Date(rev.createdAt), 'dd MMM yyyy') : 'Recently'}
                      </p>
                    </div>
                  </div>

                  {/* Target Type Badge & Stars */}
                  <div className="text-right flex flex-col items-end gap-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full">
                      {rev.targetType}
                    </span>
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <StarSolid
                          key={i}
                          className={`w-3.5 h-3.5 ${i < rev.rating ? 'text-amber-400' : 'text-gray-200'}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Target Information */}
                <div className="p-2.5 bg-gray-50 rounded-xl text-xs flex items-center justify-between text-dark-700">
                  <span className="font-semibold">
                    {rev.targetType === 'product' && `Product: ${rev.product?.name || 'General Product'}`}
                    {rev.targetType === 'seller' && `Seller: ${rev.vendor?.name || 'Store Merchant'}`}
                    {rev.targetType === 'delivery' && `Delivery Agent: ${rev.deliveryAgent?.name || 'Courier Agent'}`}
                  </span>
                  {rev.order?.orderNumber && (
                    <span className="text-gray-400 text-[11px]">Order #{rev.order.orderNumber}</span>
                  )}
                </div>

                {/* Review Text */}
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-dark-900">{rev.title}</h4>
                  <p className="text-xs text-dark-600 leading-relaxed">{rev.comment}</p>
                </div>

                {/* Response / Reply if exists */}
                {rev.reply && (
                  <div className="p-3 bg-primary-50/70 border border-primary-100 rounded-xl space-y-1 text-xs">
                    <p className="font-bold text-primary-900 flex items-center gap-1.5">
                      <ChatBubbleLeftRightIcon className="w-3.5 h-3.5 text-primary-600" />
                      <span>Response from {rev.reply.repliedBy?.name || 'Store'}:</span>
                    </p>
                    <p className="text-dark-700">{rev.reply.comment}</p>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
                <button
                  onClick={() => handleOpenReply(rev)}
                  className="font-bold text-primary-600 hover:text-primary-700 flex items-center gap-1.5"
                >
                  <ChatBubbleLeftRightIcon className="w-4 h-4" />
                  <span>{rev.reply ? 'Edit Reply' : 'Reply to Customer'}</span>
                </button>

                <button
                  onClick={() => setDeleteConfirm(rev._id)}
                  className="text-gray-400 hover:text-red-600 p-1"
                >
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Reply Modal */}
      {replyingReview && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-4"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <div>
                <h3 className="text-lg font-bold text-dark-900">Reply to Review</h3>
                <p className="text-xs text-dark-500">By {replyingReview.user?.name || 'Customer'}</p>
              </div>
              <button onClick={() => setReplyingReview(null)} className="p-1 text-gray-400 hover:text-gray-700">
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-gray-50 rounded-2xl text-xs space-y-1">
              <p className="font-bold text-dark-900">{replyingReview.title}</p>
              <p className="text-dark-600">"{replyingReview.comment}"</p>
            </div>

            <form onSubmit={handleSendReply} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Official Response *</label>
                <textarea
                  placeholder="Thank the customer or address their concern..."
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  rows={4}
                  required
                  className="input-field text-xs resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setReplyingReview(null)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={replying}
                  className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold"
                >
                  {replying ? 'Sending...' : 'Post Reply'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Review?"
        message="Are you sure you want to delete this customer review? This action cannot be undone."
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteMutation({ variables: { reviewId: deleteConfirm } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
