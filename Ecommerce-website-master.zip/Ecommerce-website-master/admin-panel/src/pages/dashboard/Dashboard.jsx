import { useState } from 'react';
import { useQuery } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  CurrencyDollarIcon, ShoppingCartIcon, CubeIcon,
  UsersIcon, ClockIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon,
  XMarkIcon, ArrowTopRightOnSquareIcon, MapPinIcon, PhoneIcon, EnvelopeIcon, UserCircleIcon,
  ExclamationTriangleIcon, BanknotesIcon, ArrowUpRightIcon, CreditCardIcon
} from '@heroicons/react/24/outline';
import { GET_DASHBOARD_STATS, GET_VENDOR_PAYOUT_SUMMARY, GET_ADMIN_PAYOUT_SUMMARY } from '../../graphql/queries.js';
import useAuthStore from '../../store/authStore.js';
import useVerticalStore from '../../store/verticalStore.js';
import clsx from 'clsx';

const statusColors = {
  placed: 'badge-warning', accepted: 'badge-info', processing: 'badge-info',
  ready_for_pickup: 'badge-info', picked_up: 'badge-info', out_for_delivery: 'badge-info',
  pending: 'badge-warning', confirmed: 'badge-info', preparing: 'badge-info',
  dispatched: 'badge-info', delivered: 'badge-success', completed: 'badge-success',
  cancelled: 'badge-danger', refunded: 'badge-danger',
};

const StatCard = ({ title, value, icon: Icon, color, change, prefix = '', suffix = '', loading }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="card p-6"
  >
    {loading ? (
      <div className="animate-pulse space-y-3">
        <div className="h-4 bg-dark-100 rounded w-2/3" />
        <div className="h-8 bg-dark-100 rounded w-1/2" />
        <div className="h-3 bg-dark-100 rounded w-1/3" />
      </div>
    ) : (
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-dark-500 font-medium">{title}</p>
          <p className="text-2xl font-bold text-dark-900 mt-1">
            {prefix}{typeof value === 'number' ? value.toLocaleString(undefined, { maximumFractionDigits: 0 }) : value}{suffix}
          </p>
          {change !== undefined && (
            <div className={clsx('flex items-center gap-1 mt-1 text-xs font-medium', change >= 0 ? 'text-green-600' : 'text-red-500')}>
              {change >= 0 ? <ArrowTrendingUpIcon className="w-3.5 h-3.5" /> : <ArrowTrendingDownIcon className="w-3.5 h-3.5" />}
              {Math.abs(change)}% vs yesterday
            </div>
          )}
        </div>
        <div className={clsx('p-3 rounded-xl', color)}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    )}
  </motion.div>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-dark-900 text-white text-xs rounded-lg px-3 py-2 shadow-lg">
        <p className="font-medium">{label}</p>
        <p className="text-primary-300 font-bold mt-0.5">
          {payload[0].name}: {typeof payload[0].value === 'number' ? payload[0].value.toLocaleString('en-IN') : payload[0].value}
        </p>
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const navigate = useNavigate();
  const user = useAuthStore((s) => s.user);
  const isAdmin = user?.role === 'admin' || user?.role === 'superadmin';
  const activeVertical = useVerticalStore((s) => s.activeVertical);
  const [selectedOrder, setSelectedOrder] = useState(null);

  const { data, loading, error } = useQuery(GET_DASHBOARD_STATS, {
    variables: {
      vertical: activeVertical === 'all' ? undefined : activeVertical,
    },
    pollInterval: 30000,
    fetchPolicy: 'cache-and-network',
  });

  const { data: payoutData } = useQuery(GET_VENDOR_PAYOUT_SUMMARY, {
    skip: user?.role !== 'vendor',
    fetchPolicy: 'cache-and-network',
  });

  const { data: adminPayoutData } = useQuery(GET_ADMIN_PAYOUT_SUMMARY, {
    skip: !isAdmin,
    fetchPolicy: 'cache-and-network',
  });

  const stats = data?.getDashboardStats;
  const payoutSummary = payoutData?.getVendorPayoutSummary;
  const adminPayoutSummary = adminPayoutData?.getAdminPayoutSummary;

  const hasBankDetails = Boolean(
    user?.bankDetails?.accountNumber ||
    user?.bankDetails?.upiId ||
    payoutSummary?.bankDetails?.accountNumber ||
    payoutSummary?.bankDetails?.upiId
  );

  const statCards = user?.role === 'vendor' ? [
    {
      title: 'Total Sales / Revenue',
      value: stats?.totalRevenue || 0,
      prefix: '₹',
      icon: CurrencyDollarIcon,
      color: 'bg-green-50 text-green-600',
    },
    {
      title: 'Total Payout (Paid Out)',
      value: payoutSummary?.totalPaidOut || 0,
      prefix: '₹',
      icon: BanknotesIcon,
      color: 'bg-emerald-50 text-emerald-600',
    },
    {
      title: 'Available Payout Balance',
      value: payoutSummary?.eligibleBalance || 0,
      prefix: '₹',
      icon: CurrencyDollarIcon,
      color: 'bg-indigo-50 text-indigo-600',
    },
    {
      title: 'Total Orders',
      value: stats?.totalOrders || 0,
      icon: ShoppingCartIcon,
      color: 'bg-blue-50 text-blue-600',
    },
  ] : [
    {
      title: 'Total Revenue',
      value: stats?.totalRevenue || 0,
      prefix: '₹',
      icon: CurrencyDollarIcon,
      color: 'bg-green-50 text-green-600',
      change: 8.2,
    },
    {
      title: 'Total Orders',
      value: stats?.totalOrders || 0,
      icon: ShoppingCartIcon,
      color: 'bg-blue-50 text-blue-600',
      change: 4.5,
    },
    {
      title: 'Total Products',
      value: stats?.totalProducts || 0,
      icon: CubeIcon,
      color: 'bg-purple-50 text-purple-600',
    },
    {
      title: 'Total Customers',
      value: stats?.totalUsers || 0,
      icon: UsersIcon,
      color: 'bg-orange-50 text-orange-600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="badge-warning text-xs font-semibold uppercase tracking-wider">
            {user?.role === 'superadmin' ? 'Super Administrator' : user?.role === 'vendor' ? 'Vendor Portal' : 'Admin'}
          </span>
          <h1 className="text-2xl font-bold text-dark-900 mt-1">
            Welcome back, {user?.name || 'Admin'} 👋
          </h1>
        </div>
        {user?.role === 'vendor' && (
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/finance/payouts')}
              className="btn-primary text-xs font-bold flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <ArrowUpRightIcon className="w-4 h-4" />
              <span>Request Payout</span>
            </button>
          </div>
        )}
      </div>

      {/* Missing Bank Details Warning Banner for Vendors */}
      {user?.role === 'vendor' && !hasBankDetails && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-rose-50 border border-rose-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-600 flex items-center justify-center flex-shrink-0">
              <CreditCardIcon className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-rose-900 flex items-center gap-2">
                <span>Action Required: Add Bank Account or UPI Details</span>
                <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-rose-200 text-rose-800 rounded-full">
                  Missing Info
                </span>
              </h4>
              <p className="text-xs text-rose-700 mt-0.5">
                You haven't added your Bank Account or UPI details yet. Please add them so admin can transfer your payout earnings.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-shrink-0">
            <button
              onClick={() => navigate('/settings?tab=Bank Details')}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <CreditCardIcon className="w-4 h-4" />
              <span>Add Bank & UPI Details</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* Pending New Orders Banner for Vendors */}
      {user?.role === 'vendor' && (stats?.pendingOrders || 0) > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 flex items-center justify-center flex-shrink-0">
              <ShoppingCartIcon className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-blue-900 flex items-center gap-2">
                <span>New Orders Received (Action Required)</span>
                <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-blue-200 text-blue-800 rounded-full">
                  {stats.pendingOrders} Pending
                </span>
              </h4>
              <p className="text-xs text-blue-700 mt-0.5">
                You have {stats.pendingOrders} order{(stats.pendingOrders === 1) ? '' : 's'} waiting for preparation and dispatch.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-shrink-0">
            <button
              onClick={() => navigate('/orders')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <ShoppingCartIcon className="w-4 h-4" />
              <span>Process Orders</span>
              <span className="bg-white/20 text-white px-1.5 py-0.5 rounded-full text-[10px] ml-1">
                {stats.pendingOrders}
              </span>
            </button>
          </div>
        </motion.div>
      )}

      {/* Pending Verification Banner for Admin / SuperAdmin */}
      {user?.role !== 'vendor' && ((stats?.pendingVendorCount || 0) > 0 || (stats?.pendingProductCount || 0) > 0) && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center flex-shrink-0">
              <ExclamationTriangleIcon className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-900">Pending Approval Requests</h4>
              <p className="text-xs text-amber-700 mt-0.5">
                You have {stats?.pendingVendorCount || 0} vendor{(stats?.pendingVendorCount || 0) === 1 ? '' : 's'} waiting for account verification and {stats?.pendingProductCount || 0} product{(stats?.pendingProductCount || 0) === 1 ? '' : 's'} pending store approval.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
            {(stats?.pendingVendorCount || 0) > 0 && (
              <button
                onClick={() => navigate('/vendors')}
                className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <span>Verify Vendors</span>
                <span className="bg-white/20 text-white px-1.5 py-0.5 rounded-full text-[10px]">
                  {stats.pendingVendorCount}
                </span>
              </button>
            )}
            {(stats?.pendingProductCount || 0) > 0 && (
              <button
                onClick={() => navigate('/products')}
                className="px-3.5 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 border border-amber-300 cursor-pointer"
              >
                <span>Review Products</span>
                <span className="bg-amber-800 text-white px-1.5 py-0.5 rounded-full text-[10px]">
                  {stats.pendingProductCount}
                </span>
              </button>
            )}
          </div>
        </motion.div>
      )}

      {/* Pending Vendor Payout Requests Banner for Admin */}
      {isAdmin && (adminPayoutSummary?.totalPendingRequestsAmount || 0) > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xs"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-600 flex items-center justify-center flex-shrink-0">
              <BanknotesIcon className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-indigo-900 flex items-center gap-2">
                <span>Pending Vendor Payout Requests</span>
                <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase bg-indigo-200 text-indigo-800 rounded-full">
                  Action Required
                </span>
              </h4>
              <p className="text-xs text-indigo-700 mt-0.5">
                Vendors have requested <strong>₹{Number(adminPayoutSummary.totalPendingRequestsAmount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong> in pending payouts. Total eligible vendor balance pending transfer: ₹{Number(adminPayoutSummary.totalEligiblePayoutsPending).toLocaleString('en-IN', { minimumFractionDigits: 2 })}.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-shrink-0">
            <button
              onClick={() => navigate('/finance/payouts')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <BanknotesIcon className="w-4 h-4" />
              <span>Review & Process Payouts</span>
            </button>
          </div>
        </motion.div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {statCards.map((card, i) => (
          <StatCard key={i} {...card} loading={loading} />
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-dark-900">Revenue (Last 7 Days)</h3>
          </div>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={stats?.revenueChart || []}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => '₹' + v} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="value" name="Revenue" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#revenueGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </motion.div>

        {/* Orders Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-semibold text-dark-900">Orders (Last 7 Days)</h3>
          </div>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={stats?.ordersChart || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Orders" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </motion.div>
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="card xl:col-span-2">
          <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-dark-900">Recent Orders</h3>
              <p className="text-xs text-dark-400">Click any order number to view full item details</p>
            </div>
            <button
              onClick={() => navigate('/orders')}
              className="text-sm text-primary-600 hover:text-primary-700 font-semibold flex items-center gap-1"
            >
              View all →
            </button>
          </div>
          <div className="overflow-x-auto">
            {loading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-4 animate-pulse">
                    <div className="w-8 h-8 bg-dark-100 rounded-full" />
                    <div className="flex-1 space-y-1">
                      <div className="h-3 bg-dark-100 rounded w-3/4" />
                      <div className="h-3 bg-dark-100 rounded w-1/2" />
                    </div>
                    <div className="h-6 w-20 bg-dark-100 rounded" />
                  </div>
                ))}
              </div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="text-xs text-dark-400 font-medium border-b border-dark-50">
                    <th className="px-6 py-3 text-left">Order</th>
                    <th className="px-6 py-3 text-left">Customer</th>
                    <th className="px-6 py-3 text-left">Total</th>
                    <th className="px-6 py-3 text-left">Status</th>
                    <th className="px-6 py-3 text-left">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-dark-50">
                  {(stats?.recentOrders || []).filter(Boolean).map((order) => (
                    <tr
                      key={order._id}
                      onClick={() => setSelectedOrder(order)}
                      className="hover:bg-primary-50/40 transition-colors cursor-pointer group"
                    >
                      <td className="px-6 py-3.5 text-sm font-bold text-primary-600 group-hover:underline flex items-center gap-1.5">
                        <span>#{order?.orderNumber || '—'}</span>
                        <ArrowTopRightOnSquareIcon className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </td>
                      <td className="px-6 py-3.5">
                        <div className="flex items-center gap-2">
                          {order.customer?.avatar ? (
                            <img src={order.customer.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                          ) : (
                            <div className="w-7 h-7 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center text-xs font-bold">
                              {order.customer?.name?.[0]?.toUpperCase() || 'C'}
                            </div>
                          )}
                          <span className="text-sm text-dark-700 font-medium">{order.customer?.name || 'Customer'}</span>
                        </div>
                      </td>
                      <td className="px-6 py-3.5 text-sm font-semibold text-dark-900">
                        ₹{Number(order.total || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="px-6 py-3.5">
                        <span className={statusColors[order.status] || 'badge-gray'}>
                          {order.status?.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-3.5 text-xs text-dark-400">
                        {order.createdAt ? format(new Date(order.createdAt), 'MMM d, h:mm a') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </motion.div>

        {/* Top Products */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="card">
          <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
            <h3 className="text-base font-semibold text-dark-900">Top Products</h3>
            <button
              onClick={() => navigate('/products')}
              className="text-xs text-primary-600 hover:text-primary-700 font-semibold"
            >
              All Products →
            </button>
          </div>
          <div className="p-4 space-y-2.5">
            {loading
              ? [...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-3 animate-pulse">
                    <div className="w-10 h-10 bg-dark-100 rounded-lg" />
                    <div className="flex-1 space-y-1">
                      <div className="h-3 bg-dark-100 rounded w-3/4" />
                      <div className="h-3 bg-dark-100 rounded w-1/2" />
                    </div>
                  </div>
                ))
              : (stats?.topProducts || []).map((product, i) => (
                  <div
                    key={product._id}
                    onClick={() => navigate(`/products?search=${encodeURIComponent(product.name)}`)}
                    className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-primary-50/50 hover:border-primary-200 border border-transparent transition-all cursor-pointer group"
                  >
                    <div className="relative flex-shrink-0">
                      <img
                        src={product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=120'}
                        alt={product.name}
                        className="w-11 h-11 object-cover rounded-lg border border-dark-100 group-hover:scale-105 transition-transform"
                      />
                      <span className="absolute -top-1 -left-1 w-4 h-4 bg-primary-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                        {i + 1}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-dark-800 truncate group-hover:text-primary-600 transition-colors">
                        {product.name}
                      </p>
                      <p className="text-[11px] text-dark-400">
                        {product.salesCount || 0} sold · ⭐ {Number(product.rating?.average || 4.5).toFixed(1)}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-dark-900">
                      ₹{Number(product.price || 0).toLocaleString('en-IN')}
                    </span>
                  </div>
                ))
            }
          </div>
        </motion.div>
      </div>

      {/* Order Item Details Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            >
              {/* Modal Header */}
              <div className="p-5 border-b border-dark-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm font-bold text-primary-600 bg-primary-50 px-2.5 py-1 rounded-lg">
                    #{selectedOrder?.orderNumber || '—'}
                  </span>
                  <div>
                    <h2 className="text-base font-bold text-dark-900">Order Item Details</h2>
                    <span className="text-xs text-dark-400">
                      Placed on {selectedOrder.createdAt ? format(new Date(selectedOrder.createdAt), 'dd MMMM yyyy, hh:mm a') : 'Recent'}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="p-1.5 text-dark-400 hover:text-dark-700 rounded-lg hover:bg-dark-100 transition-colors"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Customer & Shipping Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-dark-50/70 p-4 rounded-xl border border-dark-100">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-dark-400 block">Customer</span>
                    <p className="text-sm font-bold text-dark-900">{selectedOrder.customer?.name || 'Customer'}</p>
                    <p className="text-xs text-dark-500">{selectedOrder.customer?.email || '—'}</p>
                    {selectedOrder.customer?.phone && (
                      <p className="text-xs text-dark-500">{selectedOrder.customer.phone}</p>
                    )}
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-dark-400 block">Delivery Address</span>
                    <p className="text-xs text-dark-700">
                      {selectedOrder.shippingAddress?.fullName && <strong>{selectedOrder.shippingAddress.fullName}<br /></strong>}
                      {selectedOrder.shippingAddress?.addressLine1 || 'Delivery Address'}
                      {selectedOrder.shippingAddress?.city ? `, ${selectedOrder.shippingAddress.city}` : ''}
                      {selectedOrder.shippingAddress?.postalCode ? ` - ${selectedOrder.shippingAddress.postalCode}` : ''}
                    </p>
                  </div>
                </div>

                {/* Items List */}
                <div>
                  <h4 className="text-xs font-bold text-dark-500 uppercase tracking-wider mb-3">
                    Purchased Items ({(selectedOrder.items || []).length})
                  </h4>
                  <div className="border border-dark-100 rounded-xl divide-y divide-dark-100 overflow-hidden">
                    {(selectedOrder.items || []).map((item, idx) => (
                      <div key={idx} className="p-4 flex items-center justify-between gap-4 hover:bg-dark-50/50">
                        <div className="flex items-center gap-3.5 min-w-0">
                          <img
                            src={item.image || item.product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                            alt={item.name}
                            className="w-12 h-12 object-cover rounded-lg border border-dark-100 flex-shrink-0"
                          />
                          <div className="min-w-0">
                            <h5 className="text-sm font-bold text-dark-900 truncate">{item.name}</h5>
                            <p className="text-xs text-dark-500 mt-0.5">
                              Qty: <strong className="text-dark-800">{item.quantity}</strong> × ₹{Number(item.price || 0).toLocaleString('en-IN')}
                            </p>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span className="text-sm font-extrabold text-dark-900">
                            ₹{(Number(item.price || 0) * Number(item.quantity || 1)).toLocaleString('en-IN')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Price Breakdown */}
                <div className="bg-dark-50/50 p-4 rounded-xl border border-dark-100 space-y-2 text-xs">
                  <div className="flex justify-between text-dark-600">
                    <span>Payment Method</span>
                    <span className="font-bold text-dark-800 uppercase">{selectedOrder.paymentMethod || 'COD'}</span>
                  </div>
                  <div className="flex justify-between text-dark-600">
                    <span>Order Status</span>
                    <span className={clsx('font-bold', statusColors[selectedOrder.status] || 'badge-gray')}>
                      {selectedOrder.status?.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <div className="border-t border-dark-200 pt-2 flex justify-between text-sm font-extrabold text-dark-900">
                    <span>Total Amount</span>
                    <span className="text-primary-600">₹{Number(selectedOrder.total || 0).toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => {
                      const id = selectedOrder._id;
                      setSelectedOrder(null);
                      navigate(`/orders?search=${selectedOrder?.orderNumber || ''}`);
                    }}
                    className="btn-primary flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-1.5"
                  >
                    <span>Manage in Orders Page</span>
                    <ArrowTopRightOnSquareIcon className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setSelectedOrder(null)}
                    className="btn-secondary py-2.5 px-5 text-xs font-bold"
                  >
                    Close
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
