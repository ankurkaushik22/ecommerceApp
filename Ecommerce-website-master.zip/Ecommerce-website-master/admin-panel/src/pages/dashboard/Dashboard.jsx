import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  CurrencyDollarIcon, ShoppingCartIcon, CubeIcon,
  UsersIcon, ClockIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon
} from '@heroicons/react/24/outline';
import { GET_DASHBOARD_STATS } from '../../graphql/queries.js';
import clsx from 'clsx';

const statusColors = {
  pending: 'badge-warning', confirmed: 'badge-info', preparing: 'badge-info',
  dispatched: 'badge-info', out_for_delivery: 'badge-info',
  delivered: 'badge-success', cancelled: 'badge-danger', refunded: 'badge-danger',
};

const StatCard = ({ title, value, icon: Icon, color, change, prefix = '', suffix = '', loading }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="card p-6"
  >
    {loading ? (
      <div className="animate-pulse space-y-3">
        <div className="h-4 bg-dark-100 rounded w-2/3" />
        <div className="h-8 bg-dark-100 rounded w-1/2" />
        <div className="h-3 bg-dark-100 rounded w-1/3" />
      </div>
    ) : (
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-dark-500 font-medium">{title}</p>
          <p className="text-2xl font-bold text-dark-900 mt-1">
            {prefix}{typeof value === 'number' ? value.toLocaleString(undefined, { maximumFractionDigits: 0 }) : value}{suffix}
          </p>
          {change !== undefined && (
            <div className={clsx('flex items-center gap-1 mt-1 text-xs font-medium', change >= 0 ? 'text-green-600' : 'text-red-500')}>
              {change >= 0 ? <ArrowTrendingUpIcon className="w-3.5 h-3.5" /> : <ArrowTrendingDownIcon className="w-3.5 h-3.5" />}
              {Math.abs(change)}% vs yesterday
            </div>
          )}
        </div>
        <div className={clsx('p-3 rounded-xl', color)}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    )}
  </motion.div>
);

const CustomTooltip = ({ active, payload, label, prefix = '' }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-dark-900 border border-dark-700 rounded-lg px-3 py-2 shadow-xl">
        <p className="text-dark-400 text-xs mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }} className="text-sm font-semibold">
            {prefix}{typeof p.value === 'number' ? p.value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const { data, loading } = useQuery(GET_DASHBOARD_STATS, {
    pollInterval: 30000, // Refresh every 30s
  });

  const stats = data?.getDashboardStats;

  const statCards = [
    { title: 'Total Revenue', value: stats?.totalRevenue, icon: CurrencyDollarIcon, color: 'bg-green-100 text-green-600', prefix: '$' },
    { title: "Today's Revenue", value: stats?.todayRevenue, icon: ArrowTrendingUpIcon, color: 'bg-primary-100 text-primary-600', prefix: '$' },
    { title: 'Total Orders', value: stats?.totalOrders, icon: ShoppingCartIcon, color: 'bg-blue-100 text-blue-600' },
    { title: 'Total Products', value: stats?.totalProducts, icon: CubeIcon, color: 'bg-purple-100 text-purple-600' },
    { title: 'Total Customers', value: stats?.totalUsers, icon: UsersIcon, color: 'bg-amber-100 text-amber-600' },
    { title: 'Pending Orders', value: stats?.pendingOrders, icon: ClockIcon, color: 'bg-red-100 text-red-600' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {statCards.map((card, i) => (
          <motion.div key={card.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <StatCard {...card} loading={loading} />
          </motion.div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Revenue (Last 7 Days)</h3>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={stats?.revenueChart || []}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                <Tooltip content={<CustomTooltip prefix="$" />} />
                <Area type="monotone" dataKey="value" name="Revenue" stroke="#6366f1" strokeWidth={2.5} fill="url(#colorRevenue)" dot={{ fill: '#6366f1', r: 4 }} activeDot={{ r: 6 }} />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </motion.div>

        {/* Orders Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="card p-6">
          <h3 className="text-base font-semibold text-dark-900 mb-4">Orders (Last 7 Days)</h3>
          {loading ? (
            <div className="h-64 bg-dark-50 rounded-lg animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={stats?.ordersChart || []}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="value" name="Orders" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </motion.div>
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="card xl:col-span-2">
          <div className="px-6 py-4 border-b border-dark-100 flex items-center justify-between">
            <h3 className="text-base font-semibold text-dark-900">Recent Orders</h3>
            <a href="/orders" className="text-sm text-primary-600 hover:text-primary-700 font-medium">View all →</a>
          </div>
          <div className="overflow-x-auto">
            {loading ? (
              <div className="p-6 space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-4 animate-pulse">
                    <div className="w-8 h-8 bg-dark-100 rounded-full" />
                    <div className="flex-1 space-y-1">
                      <div className="h-3 bg-dark-100 rounded w-3/4" />
                      <div className="h-3 bg-dark-100 rounded w-1/2" />
                    </div>
                    <div className="h-6 w-20 bg-dark-100 rounded" />
                  </div>
                ))}
              </div>
            ) : (
              <table className="w-full">
                <thead>
                  <tr className="text-xs text-dark-400 font-medium border-b border-dark-50">
                    <th className="px-6 py-3 text-left">Order</th>
                    <th className="px-6 py-3 text-left">Customer</th>
                    <th className="px-6 py-3 text-left">Total</th>
                    <th className="px-6 py-3 text-left">Status</th>
                    <th className="px-6 py-3 text-left">Date</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-dark-50">
                  {(stats?.recentOrders || []).map((order) => (
                    <tr key={order._id} className="hover:bg-dark-50/50 transition-colors">
                      <td className="px-6 py-3.5 text-sm font-medium text-primary-600">#{order.orderNumber}</td>
                      <td className="px-6 py-3.5">
                        <div className="flex items-center gap-2">
                          <img src={order.customer?.avatar} alt="" className="w-7 h-7 rounded-full" />
                          <span className="text-sm text-dark-700">{order.customer?.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-3.5 text-sm font-semibold text-dark-900">${order.total?.toFixed(2)}</td>
                      <td className="px-6 py-3.5">
                        <span className={statusColors[order.status] || 'badge-gray'}>
                          {order.status?.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-3.5 text-xs text-dark-400">
                        {order.createdAt ? format(new Date(order.createdAt), 'MMM d, h:mm a') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </motion.div>

        {/* Top Products */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="card">
          <div className="px-6 py-4 border-b border-dark-100">
            <h3 className="text-base font-semibold text-dark-900">Top Products</h3>
          </div>
          <div className="p-4 space-y-3">
            {loading
              ? [...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center gap-3 animate-pulse">
                    <div className="w-10 h-10 bg-dark-100 rounded-lg" />
                    <div className="flex-1 space-y-1">
                      <div className="h-3 bg-dark-100 rounded w-3/4" />
                      <div className="h-3 bg-dark-100 rounded w-1/2" />
                    </div>
                  </div>
                ))
              : (stats?.topProducts || []).map((product, i) => (
                  <div key={product._id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-dark-50 transition-colors">
                    <div className="relative flex-shrink-0">
                      <img src={product.images?.[0]} alt={product.name} className="w-10 h-10 object-cover rounded-lg" />
                      <span className="absolute -top-1 -left-1 w-4 h-4 bg-primary-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                        {i + 1}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-dark-700 truncate">{product.name}</p>
                      <p className="text-xs text-dark-400">{product.salesCount} sold · ⭐ {product.rating?.average}</p>
                    </div>
                    <span className="text-xs font-semibold text-dark-900">${product.price}</span>
                  </div>
                ))
            }
          </div>
        </motion.div>
      </div>
    </div>
  );
}
