import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  TruckIcon,
  PlusIcon,
  PencilSquareIcon,
  TrashIcon,
  CheckBadgeIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_DELIVERY_OPTIONS } from '../../graphql/queries.js';
import {
  CREATE_DELIVERY_OPTION,
  UPDATE_DELIVERY_OPTION,
  DELETE_DELIVERY_OPTION,
} from '../../graphql/mutations.js';
import ConfirmModal from '../../components/common/ConfirmModal';

export default function DeliveryOptions() {
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [estimatedDays, setEstimatedDays] = useState('3-5 Business Days');
  const [price, setPrice] = useState(49);
  const [minOrderForFree, setMinOrderForFree] = useState(499);
  const [isDefault, setIsDefault] = useState(false);
  const [isActive, setIsActive] = useState(true);

  const { data, loading, refetch } = useQuery(GET_DELIVERY_OPTIONS);

  const [createMutation, { loading: creating }] = useMutation(CREATE_DELIVERY_OPTION, {
    onCompleted: () => {
      toast.success('Delivery option created!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [updateMutation, { loading: updating }] = useMutation(UPDATE_DELIVERY_OPTION, {
    onCompleted: () => {
      toast.success('Delivery option updated!');
      setModalOpen(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteMutation] = useMutation(DELETE_DELIVERY_OPTION, {
    onCompleted: () => {
      toast.success('Delivery option deleted');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const deliveryOptions = data?.getDeliveryOptions || [];

  const handleOpenNew = () => {
    setEditingId(null);
    setName('');
    setDescription('');
    setEstimatedDays('2-4 Business Days');
    setPrice(49);
    setMinOrderForFree(499);
    setIsDefault(false);
    setIsActive(true);
    setModalOpen(true);
  };

  const handleOpenEdit = (opt) => {
    setEditingId(opt._id);
    setName(opt.name);
    setDescription(opt.description || '');
    setEstimatedDays(opt.estimatedDays);
    setPrice(opt.price);
    setMinOrderForFree(opt.minOrderForFree || 0);
    setIsDefault(opt.isDefault);
    setIsActive(opt.isActive);
    setModalOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error('Delivery option name is required');
      return;
    }

    const input = {
      name: name.trim(),
      description: description.trim(),
      estimatedDays: estimatedDays.trim(),
      price: parseFloat(price) || 0,
      minOrderForFree: parseFloat(minOrderForFree) || 0,
      isDefault,
      isActive,
    };

    if (editingId) {
      updateMutation({ variables: { id: editingId, input } });
    } else {
      createMutation({ variables: { input } });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-dark-900">Delivery & Shipping Methods</h1>
          <p className="text-sm text-dark-500 mt-1">
            Configure delivery speeds, pricing in INR (₹), and free delivery thresholds for customer checkout
          </p>
        </div>

        <button
          onClick={handleOpenNew}
          className="btn-primary flex items-center gap-2 text-sm shadow-md"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add Delivery Method</span>
        </button>
      </div>

      {/* Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="card p-6 h-48 animate-pulse bg-gray-100 rounded-2xl" />
          ))
        ) : (
          deliveryOptions.map((opt) => (
            <motion.div
              key={opt._id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="card p-6 space-y-4 hover:shadow-lg transition-all border border-gray-100 flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-primary-50 text-primary-600 flex items-center justify-center">
                      <TruckIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-dark-900">{opt.name}</h3>
                      <p className="text-xs text-primary-600 font-medium">⏱️ {opt.estimatedDays}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        opt.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-gray-100 text-gray-500'
                      }`}
                    >
                      {opt.isActive ? 'Active' : 'Disabled'}
                    </span>
                    {opt.isDefault && (
                      <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs text-dark-500 min-h-[32px]">
                  {opt.description || 'Standard courier delivery to all serviceable pincodes.'}
                </p>

                <div className="p-3 bg-gray-50 rounded-xl space-y-1 text-xs">
                  <div className="flex justify-between text-dark-800 font-semibold">
                    <span>Shipping Fee:</span>
                    <span className="text-sm font-bold text-dark-900">₹{opt.price}</span>
                  </div>
                  {opt.minOrderForFree > 0 && (
                    <div className="flex justify-between text-emerald-700 font-medium text-[11px]">
                      <span>Free Shipping Above:</span>
                      <span>₹{opt.minOrderForFree}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                <button
                  onClick={() => handleOpenEdit(opt)}
                  className="text-xs font-bold text-primary-600 hover:text-primary-700 flex items-center gap-1"
                >
                  <PencilSquareIcon className="w-4 h-4" /> Edit Option
                </button>

                <button
                  onClick={() => setDeleteConfirm(opt)}
                  className="p-1.5 text-gray-400 hover:text-red-600 rounded-lg transition-colors"
                >
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5"
          >
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-lg font-bold text-dark-900">
                {editingId ? 'Edit Delivery Method' : 'Add New Delivery Method'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 text-gray-400 hover:text-gray-700">
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Method Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Express 24-Hour Delivery"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field text-xs"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Estimated Days / Speed *</label>
                <input
                  type="text"
                  placeholder="e.g. 1-2 Business Days"
                  value={estimatedDays}
                  onChange={(e) => setEstimatedDays(e.target.value)}
                  className="input-field text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Standard Price (₹) *</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="49"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="input-field text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-dark-700 block mb-1">Free Over (₹)</label>
                  <input
                    type="number"
                    min="0"
                    placeholder="499"
                    value={minOrderForFree}
                    onChange={(e) => setMinOrderForFree(e.target.value)}
                    className="input-field text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-dark-700 block mb-1">Description / Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Priority dispatch with express courier tracking"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field text-xs"
                />
              </div>

              <div className="space-y-2 pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-dark-800">
                  <input
                    type="checkbox"
                    checked={isDefault}
                    onChange={(e) => setIsDefault(e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span>Set as Default Checkout Delivery Method</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-dark-800">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                  />
                  <span>Active (Available for customer selection)</span>
                </label>
              </div>

              <div className="flex gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating || updating}
                  className="flex-1 py-2.5 rounded-xl btn-primary text-xs font-bold"
                >
                  {creating || updating ? 'Saving...' : 'Save Delivery Method'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      <ConfirmModal
        isOpen={!!deleteConfirm}
        title="Delete Delivery Option?"
        message={`Are you sure you want to delete delivery option "${deleteConfirm?.name}"?`}
        confirmText="Delete"
        onConfirm={() => {
          if (deleteConfirm) {
            deleteMutation({ variables: { id: deleteConfirm._id } });
            setDeleteConfirm(null);
          }
        }}
        onCancel={() => setDeleteConfirm(null)}
      />
    </div>
  );
}
