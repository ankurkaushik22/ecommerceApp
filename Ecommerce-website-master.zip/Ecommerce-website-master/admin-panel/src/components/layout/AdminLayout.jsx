import { useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  HomeIcon, ShoppingBagIcon, TagIcon, ClipboardDocumentListIcon,
  UsersIcon, TicketIcon, ChartBarIcon, Cog6ToothIcon,
  Bars3Icon, XMarkIcon, ArrowRightOnRectangleIcon,
  BellIcon, ChevronDownIcon, BuildingStorefrontIcon
} from '@heroicons/react/24/outline';
import useAuthStore from '../../store/authStore.js';
import clsx from 'clsx';

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: HomeIcon },
  { path: '/products', label: 'Products', icon: ShoppingBagIcon },
  { path: '/categories', label: 'Categories', icon: TagIcon },
  { path: '/orders', label: 'Orders', icon: ClipboardDocumentListIcon },
  { path: '/users', label: 'Users', icon: UsersIcon },
  { path: '/coupons', label: 'Coupons', icon: TicketIcon },
  { path: '/analytics', label: 'Analytics', icon: ChartBarIcon },
  { path: '/settings', label: 'Settings', icon: Cog6ToothIcon },
];

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-dark-800">
        <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center flex-shrink-0">
          <BuildingStorefrontIcon className="w-5 h-5 text-white" />
        </div>
        {sidebarOpen && (
          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-white font-bold text-lg">
            ShopZone
          </motion.span>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <motion.button
              key={item.path}
              onClick={() => { navigate(item.path); setMobileSidebarOpen(false); }}
              whileHover={{ x: 2 }}
              whileTap={{ scale: 0.98 }}
              className={clsx(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 text-sm font-medium',
                isActive
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-900/30'
                  : 'text-dark-400 hover:bg-dark-800 hover:text-white'
              )}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && (
                <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                  {item.label}
                </motion.span>
              )}
              {isActive && sidebarOpen && (
                <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />
              )}
            </motion.button>
          );
        })}
      </nav>

      {/* User section at bottom */}
      <div className="px-3 py-4 border-t border-dark-800">
        {user && (
          <div className={clsx('flex items-center gap-3', !sidebarOpen && 'justify-center')}>
            <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full flex-shrink-0 border-2 border-dark-700" />
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">{user.name}</p>
                <p className="text-dark-400 text-xs truncate capitalize">{user.role}</p>
              </div>
            )}
            {sidebarOpen && (
              <button onClick={handleLogout} className="text-dark-400 hover:text-red-400 transition-colors p-1">
                <ArrowRightOnRectangleIcon className="w-5 h-5" />
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-dark-50">
      {/* Desktop Sidebar */}
      <motion.aside
        animate={{ width: sidebarOpen ? 240 : 72 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="hidden lg:flex flex-col bg-dark-900 flex-shrink-0 relative z-20"
      >
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-16 w-6 h-6 bg-dark-700 border border-dark-600 rounded-full flex items-center justify-center text-dark-300 hover:text-white transition-colors z-30"
        >
          <ChevronDownIcon className={clsx('w-3.5 h-3.5 transition-transform duration-300', sidebarOpen ? 'rotate-90' : '-rotate-90')} />
        </button>
        <SidebarContent />
      </motion.aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setMobileSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 z-30 lg:hidden"
            />
            <motion.aside
              initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-64 bg-dark-900 z-40 lg:hidden"
            >
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="absolute top-4 right-4 text-dark-400 hover:text-white"
              >
                <XMarkIcon className="w-6 h-6" />
              </button>
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="bg-white border-b border-dark-100 px-4 lg:px-6 h-16 flex items-center justify-between flex-shrink-0 z-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden text-dark-500 hover:text-dark-700"
            >
              <Bars3Icon className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-lg font-semibold text-dark-900 capitalize">
                {navItems.find((n) => n.path === location.pathname)?.label || 'Admin Panel'}
              </h1>
              <p className="text-xs text-dark-400 hidden sm:block">
                Welcome back, {user?.name?.split(' ')[0]}!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Notifications */}
            <button className="relative text-dark-400 hover:text-dark-700 p-2 rounded-lg hover:bg-dark-50 transition-colors">
              <BellIcon className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2 text-dark-700 hover:text-dark-900 transition-colors"
              >
                <img src={user?.avatar} alt={user?.name} className="w-8 h-8 rounded-full border-2 border-dark-100" />
                <span className="hidden sm:block text-sm font-medium">{user?.name?.split(' ')[0]}</span>
                <ChevronDownIcon className={clsx('w-4 h-4 transition-transform', userMenuOpen && 'rotate-180')} />
              </button>

              <AnimatePresence>
                {userMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
                    className="absolute right-0 top-12 w-48 bg-white rounded-xl shadow-xl border border-dark-100 py-1 z-50"
                  >
                    <div className="px-4 py-3 border-b border-dark-100">
                      <p className="text-sm font-medium text-dark-900">{user?.name}</p>
                      <p className="text-xs text-dark-400">{user?.email}</p>
                    </div>
                    <button onClick={() => { navigate('/settings'); setUserMenuOpen(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-dark-700 hover:bg-dark-50 transition-colors">
                      Settings
                    </button>
                    <button onClick={() => { handleLogout(); setUserMenuOpen(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors">
                      Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
