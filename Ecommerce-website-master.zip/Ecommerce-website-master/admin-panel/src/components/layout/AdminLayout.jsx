import { useState, useMemo, useEffect, useRef } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  HomeIcon, ShoppingBagIcon, TagIcon, ClipboardDocumentListIcon,
  UsersIcon, TicketIcon, Cog6ToothIcon,
  Bars3Icon, XMarkIcon, ArrowRightOnRectangleIcon,
  BellIcon, ChevronDownIcon, BuildingStorefrontIcon,
  ShieldCheckIcon, TruckIcon, BanknotesIcon, DocumentTextIcon, CurrencyRupeeIcon,
  StarIcon, LockClosedIcon, ArrowUturnLeftIcon, PhotoIcon, SparklesIcon,
  ChatBubbleLeftRightIcon
} from '@heroicons/react/24/outline';
import useAuthStore from '../../store/authStore.js';
import useVerticalStore, { VERTICAL_OPTIONS } from '../../store/verticalStore.js';
import NotificationBell from '../common/NotificationBell.jsx';
import { GET_ROLES, GET_STORE_SETTINGS, GET_ME, GET_DASHBOARD_STATS } from '../../graphql/queries.js';
import clsx from 'clsx';

const NAV_GROUPS = [
  {
    title: null,
    items: [
      { id: 'dashboard', path: '/dashboard', label: 'Dashboard', icon: HomeIcon },
    ],
  },
  {
    title: 'PRODUCT MANAGEMENT',
    items: [
      { id: 'products', path: '/products', label: 'Products', icon: ShoppingBagIcon },
      { id: 'categories', path: '/categories', label: 'Categories', icon: TagIcon },
      { id: 'reviews', path: '/reviews', label: 'Reviews & Ratings', icon: StarIcon },
    ],
  },
  {
    title: 'ORDER MANAGEMENT',
    items: [
      { id: 'orders', path: '/orders', label: 'Orders', icon: ClipboardDocumentListIcon },
      { id: 'returns', path: '/returns', label: 'Return Requests', icon: ArrowUturnLeftIcon },
      { id: 'delivery', path: '/delivery', label: 'Delivery Methods', icon: TruckIcon },
    ],
  },
  {
    title: 'CUSTOMER SUPPORT',
    items: [
      { id: 'support', path: '/support', label: 'Support Tickets', icon: ChatBubbleLeftRightIcon },
    ],
  },
  {
    title: 'CONTENT MANAGEMENT',
    items: [
      { id: 'banners', path: '/settings/banners', label: 'Banners', icon: PhotoIcon },
      { id: 'legal', path: '/settings/legal', label: 'Legal Pages', icon: DocumentTextIcon },
    ],
  },
  {
    title: 'VENDOR MANAGEMENT',
    items: [
      { id: 'vendors', path: '/vendors', label: 'Vendors', icon: BuildingStorefrontIcon },
    ],
  },
  {
    title: 'USER MANAGEMENT',
    items: [
      { id: 'users', path: '/users', label: 'Users', icon: UsersIcon },
      { id: 'roles', path: '/roles', label: 'Roles & Permissions', icon: ShieldCheckIcon },
    ],
  },
  {
    title: 'MARKETING',
    items: [
      { id: 'coupons', path: '/coupons', label: 'Coupons', icon: TicketIcon },
      { id: 'promotions', path: '/promotions', label: 'Promotions', icon: SparklesIcon },
    ],
  },
  {
    title: 'FINANCE & TAX',
    items: [
      { id: 'taxes', path: '/taxes', label: 'Tax & GST', icon: BanknotesIcon },
      { id: 'invoices', path: '/invoices', label: 'GST Invoices', icon: DocumentTextIcon },
      { id: 'commissions', path: '/finance/commissions', label: 'Commissions', icon: BanknotesIcon },
      { id: 'payouts', path: '/finance/payouts', label: 'Vendor Payouts', icon: CurrencyRupeeIcon },
    ],
  },
  {
    title: 'SETTINGS',
    items: [
      { id: 'settings', path: '/settings', label: 'Settings', icon: Cog6ToothIcon },
    ],
  },
];

const ALL_NAV_ITEMS = NAV_GROUPS.flatMap((g) => g.items);

function SidebarContent({
  sidebarOpen,
  storeSettings,
  user,
  getRoleDisplayName,
  permittedModuleIds,
  location,
  navigate,
  setMobileSidebarOpen,
  onLogoutClick,
  dashboardStats,
}) {
  const getBadgeCount = (itemId) => {
    if (itemId === 'orders') return dashboardStats?.pendingOrders || 0;
    if (itemId === 'products') return dashboardStats?.pendingProductCount || 0;
    if (itemId === 'vendors' && user?.role !== 'vendor') return dashboardStats?.pendingVendorCount || 0;
    return 0;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-dark-800">
        <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
          {storeSettings?.logoUrl ? (
            <img src={storeSettings.logoUrl} alt="Store Logo" className="w-full h-full object-cover" />
          ) : (
            <BuildingStorefrontIcon className="w-5 h-5 text-white" />
          )}
        </div>
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col min-w-0">
            <span className="text-white font-bold text-lg leading-tight truncate">
              {storeSettings?.storeName || 'Suaaka'}
            </span>
            <span className={clsx(
              'text-[10px] uppercase font-bold tracking-wider truncate',
              user?.role === 'superadmin' ? 'text-amber-400 font-extrabold' : 'text-primary-400'
            )}>
              {getRoleDisplayName()}
            </span>
          </motion.div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-3 space-y-3 overflow-y-auto custom-scrollbar">
        {NAV_GROUPS.map((group, groupIdx) => {
          const visibleItems = group.items.filter((item) => permittedModuleIds.includes(item.id));
          if (visibleItems.length === 0) return null;

          return (
            <div key={group.title || `group-${groupIdx}`} className="space-y-1">
              {group.title && sidebarOpen && (
                <div className="px-3 pt-2 pb-0.5">
                  <p className="text-[10px] font-extrabold tracking-wider text-dark-400 uppercase select-none opacity-80">
                    {group.title}
                  </p>
                </div>
              )}
              {group.title && !sidebarOpen && (
                <div className="my-1.5 border-t border-dark-800" />
              )}
              {visibleItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                const badgeCount = getBadgeCount(item.id);
                return (
                  <motion.button
                    key={item.path}
                    onClick={() => { navigate(item.path); setMobileSidebarOpen(false); }}
                    whileHover={{ x: 2 }}
                    whileTap={{ scale: 0.98 }}
                    title={!sidebarOpen ? `${item.label}${badgeCount > 0 ? ` (${badgeCount})` : ''}` : undefined}
                    className={clsx(
                      'w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 text-sm font-medium relative',
                      isActive
                        ? 'bg-primary-600 text-white shadow-md shadow-primary-900/30'
                        : 'text-dark-400 hover:bg-dark-800 hover:text-white'
                    )}
                  >
                    <div className="relative flex-shrink-0">
                      <Icon className="w-5 h-5" />
                      {!sidebarOpen && badgeCount > 0 && (
                        <span className="absolute -top-1.5 -right-2 px-1 py-0.2 text-[9px] font-extrabold rounded-full bg-amber-500 text-white min-w-[14px] h-3.5 flex items-center justify-center border border-dark-900 leading-none">
                          {badgeCount}
                        </span>
                      )}
                    </div>
                    {sidebarOpen && (
                      <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="truncate">
                        {item.label}
                      </motion.span>
                    )}
                    {sidebarOpen && badgeCount > 0 && (
                      <span className={clsx(
                        'ml-auto px-2 py-0.5 text-[11px] font-extrabold rounded-full flex-shrink-0 transition-colors',
                        isActive ? 'bg-white text-primary-700 shadow-xs' : 'bg-amber-500 text-white'
                      )}>
                        {badgeCount}
                      </span>
                    )}
                    {isActive && sidebarOpen && badgeCount === 0 && (
                      <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-white flex-shrink-0" />
                    )}
                  </motion.button>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* User section at bottom */}
      <div className="px-3 py-4 border-t border-dark-800">
        {user && (
          <div className={clsx('flex items-center gap-3', !sidebarOpen && 'justify-center')}>
            <img
              src={user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}`}
              alt={user.name}
              className="w-8 h-8 rounded-full flex-shrink-0 border-2 border-dark-700 object-cover"
            />
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium truncate">{user.name}</p>
                <p className="text-dark-400 text-xs truncate capitalize">{getRoleDisplayName()}</p>
              </div>
            )}
            <button
              onClick={onLogoutClick}
              className="text-dark-400 hover:text-red-400 transition-colors p-1"
              title="Sign Out"
            >
              <ArrowRightOnRectangleIcon className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const mainRef = useRef(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout, updateUser } = useAuthStore();
  const { activeVertical, setActiveVertical } = useVerticalStore();

  useQuery(GET_ME, {
    skip: !user,
    fetchPolicy: 'network-only',
    onCompleted: (data) => {
      if (data?.me) {
        updateUser(data.me);
      }
    },
  });

  const { data: rolesData } = useQuery(GET_ROLES, {
    skip: !user || user.role === 'customer',
    fetchPolicy: 'cache-and-network',
  });

  const { data: storeSettingsData } = useQuery(GET_STORE_SETTINGS, {
    fetchPolicy: 'cache-first',
  });
  const storeSettings = storeSettingsData?.getStoreSettings;

  const { data: statsData } = useQuery(GET_DASHBOARD_STATS, {
    skip: !user || user.role === 'customer',
    pollInterval: 10000,
    fetchPolicy: 'cache-and-network',
  });
  const dashboardStats = statsData?.getDashboardStats;

  useEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTop = 0;
    }
  }, [location.pathname, activeVertical]);

  useEffect(() => {
    if (storeSettings?.faviconUrl) {
      let link = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = storeSettings.faviconUrl;
    }
    if (storeSettings?.storeName) {
      document.title = `${storeSettings.storeName} Admin Panel`;
    }
    if (activeVertical !== 'all' && storeSettings?.disabledVerticals?.includes(activeVertical)) {
      setActiveVertical('all');
    }
  }, [storeSettings?.faviconUrl, storeSettings?.storeName, storeSettings?.disabledVerticals, activeVertical, setActiveVertical]);

  const isVendor = user?.role === 'vendor';
  const assignedVerticals = useMemo(() => {
    if (!isVendor) return [];
    if (user?.vendorVerticals && user.vendorVerticals.length > 0) {
      return user.vendorVerticals;
    }
    if (user?.vendorVertical) {
      return [user.vendorVertical];
    }
    return ['shopping'];
  }, [isVendor, user]);

  useEffect(() => {
    if (isVendor && assignedVerticals.length > 0) {
      if (!assignedVerticals.includes(activeVertical)) {
        setActiveVertical(assignedVerticals[0]);
      }
    }
  }, [isVendor, assignedVerticals, activeVertical, setActiveVertical]);

const DEFAULT_ROLE_MODULES = {
  superadmin: ALL_NAV_ITEMS.map((n) => n.id),
  admin: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'returns', 'delivery', 'support', 'banners', 'legal', 'vendors', 'users', 'roles', 'coupons', 'promotions', 'taxes', 'invoices', 'commissions', 'payouts', 'settings'],
  vendor: ['dashboard', 'products', 'orders', 'payouts', 'settings'],
  delivery: ['dashboard', 'orders'],
  manager: ['dashboard', 'products', 'categories', 'add_categories', 'orders', 'coupons', 'reviews', 'invoices'],
};

  // Calculate accessible modules for the logged in user
  const permittedModuleIds = useMemo(() => {
    if (!user) return [];
    if (user.role === 'superadmin') {
      return ALL_NAV_ITEMS.map((n) => n.id);
    }

    // Lookup role definition from DB (RolePermission)
    const roleDoc = rolesData?.getRoles?.find((r) => r.roleName === user.role);
    const defaultModules = DEFAULT_ROLE_MODULES[user.role] || ['dashboard'];
    let baseModules = (roleDoc && Array.isArray(roleDoc.modules) && roleDoc.modules.length > 0)
      ? roleDoc.modules
      : defaultModules;

    if (user.role === 'admin') {
      baseModules = Array.from(new Set([...baseModules, 'commissions', 'payouts']));
    }
    if (user.role === 'vendor') {
      baseModules = Array.from(new Set([...baseModules, 'payouts']));
    }

    const userPermissions = user.permissions || [];
    return Array.from(new Set([...baseModules, ...userPermissions]));
  }, [user, rolesData]);

  const navItems = useMemo(() => {
    return ALL_NAV_ITEMS.filter((item) => permittedModuleIds.includes(item.id));
  }, [permittedModuleIds]);

  // Check if current route is authorized
  const currentNav = ALL_NAV_ITEMS.find((n) => location.pathname === n.path || location.pathname.startsWith(n.path + '/'));
  const isCurrentRouteAuthorized = currentNav ? permittedModuleIds.includes(currentNav.id) : true;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getRoleDisplayName = () => {
    if (!user || !user.role) return 'Staff';
    if (user.role === 'superadmin') return 'Super Administrator';
    if (user.role === 'admin') return 'Administrator';
    if (user.role === 'vendor') return 'Seller / Merchant';
    if (user.role === 'delivery') return 'Delivery Executive';
    return user.role.charAt(0).toUpperCase() + user.role.slice(1);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-dark-50">
      {/* Desktop Sidebar */}
      <motion.aside
        animate={{ width: sidebarOpen ? 240 : 72 }}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
        className="hidden lg:flex flex-col bg-dark-900 flex-shrink-0 relative z-20"
      >
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-16 w-6 h-6 bg-dark-700 border border-dark-600 rounded-full flex items-center justify-center text-dark-300 hover:text-white transition-colors z-30"
        >
          <ChevronDownIcon className={clsx('w-3.5 h-3.5 transition-transform duration-300', sidebarOpen ? 'rotate-90' : '-rotate-90')} />
        </button>
        <SidebarContent
          sidebarOpen={sidebarOpen}
          storeSettings={storeSettings}
          user={user}
          getRoleDisplayName={getRoleDisplayName}
          permittedModuleIds={permittedModuleIds}
          location={location}
          navigate={navigate}
          setMobileSidebarOpen={setMobileSidebarOpen}
          onLogoutClick={() => setShowLogoutModal(true)}
          dashboardStats={dashboardStats}
        />
      </motion.aside>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setMobileSidebarOpen(false)}
              className="fixed inset-0 bg-black/60 z-30 lg:hidden"
            />
            <motion.aside
              initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-64 bg-dark-900 z-40 lg:hidden"
            >
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="absolute top-4 right-4 text-dark-400 hover:text-white"
              >
                <XMarkIcon className="w-6 h-6" />
              </button>
              <SidebarContent
                sidebarOpen={true}
                storeSettings={storeSettings}
                user={user}
                getRoleDisplayName={getRoleDisplayName}
                permittedModuleIds={permittedModuleIds}
                location={location}
                navigate={navigate}
                setMobileSidebarOpen={setMobileSidebarOpen}
                onLogoutClick={() => {
                  setMobileSidebarOpen(false);
                  setShowLogoutModal(true);
                }}
                dashboardStats={dashboardStats}
              />
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="lg:hidden p-2 text-dark-500 hover:text-dark-900 rounded-lg hover:bg-gray-100"
            >
              <Bars3Icon className="w-6 h-6" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className={clsx(
                  'text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md border',
                  user?.role === 'superadmin'
                    ? 'bg-amber-50 text-amber-800 border-amber-300'
                    : 'bg-primary-50 text-primary-700 border-primary-200'
                )}>
                  {getRoleDisplayName()}
                </span>
              </div>
              <h2 className="text-sm font-bold text-dark-800 mt-0.5">
                Welcome back, {user?.name || 'User'} 👋
              </h2>
            </div>
          </div>

          {/* Universal Vertical Switcher Bar */}
          {(() => {
            const HIDE_VERTICAL_PATHS = ['/vendors', '/users', '/roles', '/taxes', '/settings', '/finance'];
            const showVerticalSwitcher = !HIDE_VERTICAL_PATHS.some((path) => location.pathname === path || location.pathname.startsWith(path + '/'));
            if (!showVerticalSwitcher) return null;

            return isVendor ? (
              assignedVerticals.length === 1 ? (
                <div className="hidden md:flex items-center gap-1.5 px-3.5 py-1.5 bg-primary-50 border border-primary-200 text-primary-800 rounded-xl text-xs font-extrabold shadow-2xs">
                  <span>{VERTICAL_OPTIONS.find((v) => v.id === assignedVerticals[0])?.icon || '🛍️'}</span>
                  <span>Assigned Vertical: {VERTICAL_OPTIONS.find((v) => v.id === assignedVerticals[0])?.label || assignedVerticals[0]}</span>
                </div>
              ) : (
                <div className="hidden md:flex items-center bg-gray-100/90 p-1 rounded-2xl border border-gray-200 shadow-xs">
                  {VERTICAL_OPTIONS.filter((v) => assignedVerticals.includes(v.id)).map((v) => {
                    const isActive = activeVertical === v.id;
                    return (
                      <button
                        key={v.id}
                        onClick={() => setActiveVertical(v.id)}
                        className={clsx(
                          'flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all relative',
                          isActive
                            ? 'bg-white text-dark-900 shadow-xs border border-gray-200/80'
                            : 'text-dark-500 hover:text-dark-800 hover:bg-white/60'
                        )}
                        title={v.label}
                      >
                        <span>{v.icon}</span>
                        <span>{v.label}</span>
                      </button>
                    );
                  })}
                </div>
              )
            ) : (
              <div className="hidden md:flex items-center bg-gray-100/90 p-1 rounded-2xl border border-gray-200 shadow-xs">
                {VERTICAL_OPTIONS.filter(
                  (v) => v.id === 'all' || !storeSettings?.disabledVerticals?.includes(v.id)
                ).map((v) => {
                  const isActive = activeVertical === v.id;
                  return (
                    <button
                      key={v.id}
                      onClick={() => setActiveVertical(v.id)}
                      className={clsx(
                        'flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl transition-all relative',
                        isActive
                          ? 'bg-white text-dark-900 shadow-xs border border-gray-200/80'
                          : 'text-dark-500 hover:text-dark-800 hover:bg-white/60'
                      )}
                      title={v.label}
                    >
                      <span>{v.icon}</span>
                      <span>{v.label}</span>
                    </button>
                  );
                })}
              </div>
            );
          })()}

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 hidden sm:inline-block">
              INR (₹)
            </span>
            <NotificationBell />
          </div>
        </header>

        {/* Page Content */}
        <main ref={mainRef} className="flex-1 overflow-y-auto p-6">
          {!isCurrentRouteAuthorized ? (
            <div className="min-h-[50vh] flex items-center justify-center">
              <div className="card p-8 max-w-md text-center space-y-4 bg-white border border-gray-100 rounded-3xl shadow-sm">
                <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
                  <LockClosedIcon className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-dark-900">Module Access Restricted</h3>
                <p className="text-xs text-dark-500 leading-relaxed">
                  Your current account role (<strong>{getRoleDisplayName()}</strong>) is not authorized to access this module.
                </p>
                <button
                  onClick={() => navigate(navItems[0]?.path || '/dashboard')}
                  className="btn-primary text-xs font-bold px-4 py-2"
                >
                  Return to Accessible Dashboard
                </button>
              </div>
            </div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>

      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {showLogoutModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowLogoutModal(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="relative bg-white rounded-2xl shadow-xl border border-gray-100 max-w-sm w-full p-6 text-center z-10 overflow-hidden"
            >
              <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <ArrowRightOnRectangleIcon className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-dark-900">Sign Out Confirmation</h3>
              <p className="text-xs text-dark-500 mt-1 mb-5 leading-relaxed">
                Are you sure you want to sign out of your account? You will need to log back in to access the management portal.
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowLogoutModal(false)}
                  className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-xs font-bold text-dark-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setShowLogoutModal(false);
                    handleLogout();
                  }}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-xs transition-colors"
                >
                  Sign Out
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
