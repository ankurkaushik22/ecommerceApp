import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, gql, useSubscription } from '@apollo/client';
import { BellIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';
import useAuthStore from '../../store/authStore.js';

const GET_NOTIFICATIONS = gql`
  query GetNotifications {
    getNotifications {
      _id title message isRead createdAt type data
    }
  }
`;

const MARK_READ = gql`
  mutation MarkNotificationRead($id: ID!) {
    markNotificationRead(id: $id) { _id isRead }
  }
`;

const MARK_ALL_READ = gql`
  mutation MarkAllNotificationsRead {
    markAllNotificationsRead
  }
`;

// Only subscribe if we know the user ID
const NOTIFICATION_SUB = gql`
  subscription OnNotification($userId: ID!) {
    notificationReceived(userId: $userId) {
      _id title message isRead createdAt type data
    }
  }
`;

export default function NotificationBell() {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const { user } = useAuthStore();

  const { data, refetch, updateQuery } = useQuery(GET_NOTIFICATIONS, {
    fetchPolicy: 'network-only',
    pollInterval: 10000,
    skip: !user
  });

  const { data: subData } = useSubscription(NOTIFICATION_SUB, {
    variables: { userId: user?._id },
    skip: !user?._id
  });

  useEffect(() => {
    if (subData?.notificationReceived) {
      updateQuery((prev) => {
        if (!prev) return prev;
        const newNotif = subData.notificationReceived;
        if (prev.getNotifications.some(n => n._id === newNotif._id)) return prev;
        return {
          ...prev,
          getNotifications: [newNotif, ...prev.getNotifications]
        };
      });
    }
  }, [subData, updateQuery]);

  const [markRead] = useMutation(MARK_READ);
  const [markAllRead] = useMutation(MARK_ALL_READ, {
    onCompleted: () => refetch()
  });

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const notifications = data?.getNotifications || [];
  const unreadCount = notifications.filter(n => !n.isRead).length;

  const handleNotificationClick = async (notif) => {
    if (!notif.isRead) {
      await markRead({ variables: { id: notif._id } });
      refetch();
    }
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-dark-400 hover:text-dark-900 rounded-xl hover:bg-gray-100 transition-colors"
      >
        <BellIcon className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white" />
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-white border border-gray-200 rounded-2xl shadow-xl z-50 overflow-hidden flex flex-col max-h-[28rem]">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
            <h3 className="font-bold text-gray-900">Notifications</h3>
            {unreadCount > 0 && (
              <button 
                onClick={() => markAllRead()}
                className="text-xs text-brand-600 hover:text-brand-700 font-medium"
              >
                Mark all read
              </button>
            )}
          </div>
          
          <div className="overflow-y-auto flex-1 p-2 space-y-1">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500 text-sm">
                No notifications yet.
              </div>
            ) : (
              notifications.map((notif) => (
                <div 
                  key={notif._id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`p-3 rounded-xl cursor-pointer transition-colors ${notif.isRead ? 'hover:bg-gray-50 opacity-75' : 'bg-brand-50/50 hover:bg-brand-50'}`}
                >
                  <div className="flex justify-between items-start mb-1">
                    <span className={`text-sm font-semibold ${notif.isRead ? 'text-gray-800' : 'text-brand-900'}`}>{notif.title}</span>
                    <span className="text-[10px] text-gray-500 whitespace-nowrap ml-2">
                      {new Date(notif.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <p className={`text-xs ${notif.isRead ? 'text-gray-500' : 'text-gray-700'}`}>{notif.message}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
