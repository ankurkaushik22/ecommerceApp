import React, { useState } from 'react';
import { ArrowUpTrayIcon, XMarkIcon, ArrowPathIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import ConfirmModal from './ConfirmModal';

export default function MultiImageUpload({ value = [], onChange, label = 'Images' }) {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const [deleteIndex, setDeleteIndex] = useState(null);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setLoading(true);
    setProgress(0);
    setError(null);

    const toastId = toast.loading(`Uploading ${files.length} image(s)...`);

    const formData = new FormData();
    files.forEach(file => {
      formData.append('images', file);
    });

    const token = localStorage.getItem('adminToken');
    const apiUrl = import.meta.env.VITE_API_URL 
      ? import.meta.env.VITE_API_URL.replace('/graphql', '') 
      : 'https://ecommerce-api-yak7.onrender.com';

    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${apiUrl}/api/upload/multiple`);
    if (token) {
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);
    }

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        const percent = Math.round((event.loaded / event.total) * 100);
        setProgress(percent);
        toast.loading(`Uploading ${files.length} image(s) (${percent}%)...`, { id: toastId });
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const data = JSON.parse(xhr.responseText);
          if (data.urls && data.urls.length > 0) {
            onChange([...value, ...data.urls]);
            toast.success(`${data.urls.length} image(s) uploaded!`, { id: toastId });
          } else {
            throw new Error('No URLs returned from server');
          }
        } catch (err) {
          setError(err.message || 'Invalid server response');
          toast.error(err.message || 'Upload failed', { id: toastId });
        }
      } else {
        let errMsg = 'Upload failed';
        try {
          const errData = JSON.parse(xhr.responseText);
          if (errData.error) errMsg = errData.error;
        } catch(e) {}
        setError(errMsg);
        toast.error(errMsg, { id: toastId });
      }
      setLoading(false);
      setProgress(0);
    };

    xhr.onerror = () => {
      setError('Network error during upload');
      toast.error('Network error during upload', { id: toastId });
      setLoading(false);
      setProgress(0);
    };

    xhr.send(formData);
  };

  const removeImage = (indexToRemove) => {
    setDeleteIndex(indexToRemove);
  };

  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      
      {value.length > 0 && (
        <div className="flex flex-wrap gap-4 mb-4">
          {value.map((url, index) => (
            <div key={index} className="relative inline-block border border-gray-200 rounded-lg overflow-hidden bg-gray-50">
              <img src={url} alt={`Uploaded ${index + 1}`} className="h-24 w-24 object-contain bg-white" />
              <button
                type="button"
                onClick={() => removeImage(index)}
                className="absolute top-1 right-1 p-1 bg-white/90 text-red-600 rounded-full shadow-sm hover:bg-red-50 transition-colors"
                title="Remove image"
              >
                <XMarkIcon className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors relative">
        <div className="space-y-2 text-center w-full max-w-xs">
          {loading ? (
            <div className="space-y-2">
              <ArrowPathIcon className="mx-auto h-10 w-10 text-blue-600 animate-spin" />
              <p className="text-xs font-bold text-blue-600">Uploading... {progress}%</p>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-150" 
                  style={{ width: `${progress}%` }} 
                />
              </div>
            </div>
          ) : (
            <>
              <ArrowUpTrayIcon className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600 justify-center">
                <label className="relative cursor-pointer bg-transparent rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none">
                  <span>Upload files</span>
                  <input 
                    type="file" 
                    className="sr-only" 
                    accept="image/*" 
                    multiple
                    onChange={handleFileChange} 
                    disabled={loading}
                  />
                </label>
              </div>
              <p className="text-xs text-gray-500">PNG, JPG, GIF up to 5MB</p>
            </>
          )}
        </div>
      </div>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}

      <ConfirmModal
        isOpen={deleteIndex !== null}
        title="Remove Image?"
        message="Are you sure you want to remove this image?"
        confirmText="Remove"
        onConfirm={() => {
          if (deleteIndex !== null) {
            const newImages = value.filter((_, index) => index !== deleteIndex);
            onChange(newImages);
            setDeleteIndex(null);
          }
        }}
        onCancel={() => setDeleteIndex(null)}
      />
    </div>
  );
}
