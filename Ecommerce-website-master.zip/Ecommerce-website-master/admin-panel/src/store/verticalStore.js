import { create } from 'zustand';

export const VERTICAL_OPTIONS = [
  { id: 'all', label: 'All Verticals', icon: '🌐', color: 'slate' },
  { id: 'shopping', label: 'Shopping (Retail)', icon: '🛍️', color: 'purple' },
  { id: 'food', label: 'Food Delivery', icon: '🍔', color: 'orange' },
  { id: 'grocery', label: 'Grocery (Fresh)', icon: '🥦', color: 'emerald' },
  { id: 'services', label: 'Services', icon: '🛠️', color: 'blue' },
];

export const useVerticalStore = create((set) => ({
  activeVertical: typeof window !== 'undefined' ? localStorage.getItem('adminActiveVertical') || 'all' : 'all',
  setActiveVertical: (vertical) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('adminActiveVertical', vertical);
    }
    set({ activeVertical: vertical });
  },
}));

const GROCERY_KEYWORDS = ['grocery', 'vegetables', 'fruits', 'dairy', 'bakery', 'meat', 'breakfast', 'poultry', 'breads'];
const FOOD_KEYWORDS = ['food', 'dining', 'biryani', 'burger', 'momos', 'chinese', 'north-indian', 'pizza', 'pasta', 'dessert', 'restaurant', 'cafe'];
const SERVICE_KEYWORDS = ['service', 'repair', 'cleaning', 'electrician', 'plumber', 'painting', 'woodwork', 'salon', 'spa'];

export function getCategoryVertical(category) {
  if (!category) return 'shopping';
  if (category.vertical) return category.vertical;

  const slug = (category.slug || '').toLowerCase();
  const name = (category.name || '').toLowerCase();
  const parentSlug = (category.parent?.slug || '').toLowerCase();
  const parentName = (category.parent?.name || '').toLowerCase();

  const text = `${slug} ${name} ${parentSlug} ${parentName}`;

  if (GROCERY_KEYWORDS.some((k) => text.includes(k))) return 'grocery';
  if (FOOD_KEYWORDS.some((k) => text.includes(k))) return 'food';
  if (SERVICE_KEYWORDS.some((k) => text.includes(k))) return 'services';

  return 'shopping';
}

export default useVerticalStore;
