import { gql } from '@apollo/client';

export const LOGIN = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user { _id name email role avatar permissions vendorCategory vendorVertical vendorVerticals }
    }
  }
`;

export const GET_ME = gql`
  query Me {
    me {
      _id name email role avatar phone permissions vendorCategory vendorVertical vendorVerticals isActive createdAt
      bankDetails {
        accountHolderName
        accountNumber
        bankName
        ifscCode
        upiId
      }
    }
  }
`;

export const GET_VENDOR_BANK_DETAILS = gql`
  query GetVendorBankDetails($vendorId: ID) {
    getVendorBankDetails(vendorId: $vendorId) {
      accountHolderName
      accountNumber
      bankName
      ifscCode
      upiId
    }
  }
`;

export const GET_DASHBOARD_STATS = gql`
  query GetDashboardStats($vertical: String) {
    getDashboardStats(vertical: $vertical) {
      totalRevenue todayRevenue totalOrders todayOrders
      totalProducts totalUsers totalVendors pendingOrders
      pendingVendorCount pendingProductCount
      recentOrders {
        _id orderNumber total subtotal tax shippingCost discount status paymentMethod paymentStatus createdAt
        customer { _id name email phone avatar }
        shippingAddress { fullName phone addressLine1 addressLine2 city state postalCode }
        items { name quantity price image product { _id name slug images } }
      }
      topProducts { _id name slug images price salesCount stock category { name } rating { average count } }
      revenueChart { label value }
      ordersChart { label value }
    }
  }
`;

export const GET_ALL_PRODUCTS = gql`
  query GetAllProducts($filter: ProductFilterInput, $sort: ProductSortInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, sort: $sort, pagination: $pagination) {
      products {
        _id name slug description shortDescription price comparePrice discount images stock sku
        tags vertical isVeg restaurantName preparationTime unitMeasure serviceDuration specifications { key value } highlights
        variants { name options { label price stock sku thumbnail thumbnails } }
        isActive isFeatured isDeals freeShipping disableCOD salesCount createdAt
        approvalStatus commissionType commissionValue
        vendor { _id name email vendorCategory }
        category { _id name slug vertical parent { _id name slug vertical } }
        subcategory { _id name slug vertical }
        rating { average count }
      }
      total page pages hasNext
    }
  }
`;

export const GET_PRODUCT = gql`
  query GetProduct($id: ID!) {
    getProductById(id: $id) {
      _id name slug description shortDescription price comparePrice
      images stock sku isActive isFeatured isDeals freeShipping disableCOD shippingCost
      tags vertical isVeg restaurantName preparationTime unitMeasure serviceDuration specifications { key value } highlights
      variants { name options { label price stock sku thumbnail thumbnails } }
      approvalStatus commissionType commissionValue
      category { _id name slug vertical parent { _id name slug vertical } }
      subcategory { _id name slug vertical }
      vendor { _id name email vendorCategory }
      rating { average count }
    }
  }
`;

export const GET_ALL_CATEGORIES = gql`
  query GetAllCategories {
    getAllCategories {
      _id name slug icon image description isActive sortOrder vertical
      parent { _id name slug vertical }
      children { _id name slug vertical }
      productCount
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories($parentId: ID) {
    getCategories(parentId: $parentId) {
      _id name slug icon image isActive sortOrder
      children { _id name }
    }
  }
`;

export const GET_ALL_ORDERS = gql`
  query GetAllOrders($status: String, $search: String, $vertical: String, $pagination: PaginationInput) {
    getAllOrders(status: $status, search: $search, vertical: $vertical, pagination: $pagination) {
      orders {
        _id orderNumber status vertical returnStatus returnReason paymentMethod paymentStatus
        subtotal discount shippingCost tax total createdAt
        deliveryOption { name estimatedDays price }
        customer { _id name email avatar phone }
        deliveryBoy { _id name phone }
        items { name image price quantity variantLabel }
        shippingAddress { fullName phone addressLine1 city state postalCode country }
        trackingUpdates { status message timestamp location }
      }
      total page pages
    }
  }
`;

export const GET_ALL_USERS = gql`
  query GetAllUsers($role: String, $pagination: PaginationInput) {
    getAllUsers(role: $role, pagination: $pagination) {
      _id name email role avatar phone isActive isVerified vendorCategory vendorVertical vendorVerticals commissionRate createdAt
    }
  }
`;

export const GET_ALL_COUPONS = gql`
  query GetAllCoupons {
    getAllCoupons {
      _id code type value description minOrderAmount maxDiscountAmount
      usageLimit usedCount isActive startsAt expiresAt createdAt
    }
  }
`;

export const GET_ANALYTICS = gql`
  query GetAnalytics($period: String) {
    getAnalytics(period: $period)
  }
`;

export const GET_VENDORS = gql`
  query GetVendors {
    getVendors {
      _id name email avatar phone isActive isVerified vendorCategory vendorVertical vendorVerticals commissionRate createdAt
      bankDetails {
        accountHolderName
        accountNumber
        bankName
        ifscCode
        upiId
      }
    }
  }
`;

export const GET_DELIVERY_BOYS = gql`
  query GetDeliveryBoys {
    getDeliveryAgents {
      _id name email phone avatar isActive
    }
  }
`;

export const GET_ROLES = gql`
  query GetRoles {
    getRoles {
      _id roleName displayName description modules isSystem createdAt
    }
  }
`;

export const GET_DELIVERY_OPTIONS = gql`
  query GetDeliveryOptions($activeOnly: Boolean) {
    getDeliveryOptions(activeOnly: $activeOnly) {
      _id name description estimatedDays price minOrderForFree isDefault isActive sortOrder createdAt
    }
  }
`;

export const GET_TAX_SETTINGS = gql`
  query GetTaxSettings($activeOnly: Boolean) {
    getTaxSettings(activeOnly: $activeOnly) {
      _id name rate cgst sgst igst hsnCode isDefault isActive description createdAt
    }
  }
`;

export const GET_ALL_REVIEWS = gql`
  query GetAllReviews($targetType: String, $pagination: PaginationInput) {
    getAllReviews(targetType: $targetType, pagination: $pagination) {
      _id targetType rating title comment images verified createdAt
      user { _id name email avatar }
      product { _id name images slug category { _id name slug vertical parent { _id name slug } } }
      vendor { _id name email vendorVertical }
      deliveryAgent { _id name email }
      order { _id orderNumber vertical }
      reply { comment repliedAt repliedBy { _id name role avatar } }
    }
  }
`;

export const GET_ORDER_INVOICE = gql`
  query GetOrderInvoice($orderId: ID!) {
    getOrderInvoice(orderId: $orderId) {
      invoiceNumber
      invoiceDate
      order {
        _id orderNumber createdAt paymentMethod paymentStatus subtotal discount shippingCost tax total
        shippingAddress { fullName phone addressLine1 addressLine2 city state postalCode country }
        customer { name email phone }
        items { name price quantity variantLabel total }
        taxDetails { rate taxAmount cgst sgst igst hsnCode }
        deliveryOption { name estimatedDays price }
      }
      companyDetails
    }
  }
`;

export const GET_ASSIGNED_DELIVERIES = gql`
  query GetAssignedDeliveries($status: String, $pagination: PaginationInput) {
    getAssignedDeliveries(status: $status, pagination: $pagination) {
      orders {
        _id orderNumber status paymentMethod paymentStatus
        subtotal discount shippingCost tax total createdAt
        customer { _id name email avatar phone }
        items { name image price quantity variantLabel }
        shippingAddress { fullName phone addressLine1 city state postalCode country }
        trackingUpdates { status message timestamp location }
      }
      total page pages
    }
  }
`;

export const GET_BANNERS = gql`
  query GetBanners($platform: String) {
    getBanners(platform: $platform) {
      _id title subtitle tag image link discount platform bgGradient bgHex buttonColor accentColor isActive order createdAt
    }
  }
`;

export const GET_STORE_SETTINGS = gql`
  query GetStoreSettings {
    getStoreSettings {
      _id
      storeName
      logoUrl
      faviconUrl
      appIconUrl
      disabledVerticals
      serviceBookingMode
      serviceContactPhone
    }
  }
`;

export const GET_VENDOR_PAYOUT_SUMMARY = gql`
  query GetVendorPayoutSummary($vendorId: ID) {
    getVendorPayoutSummary(vendorId: $vendorId) {
      totalSales
      totalCommission
      totalEarnings
      eligibleBalance
      pendingPayout
      totalPaidOut
      returnPendingBalance
      bankDetails {
        accountHolderName
        accountNumber
        bankName
        ifscCode
        upiId
      }
    }
  }
`;

export const GET_ADMIN_PAYOUT_SUMMARY = gql`
  query GetAdminPayoutSummary {
    getAdminPayoutSummary {
      totalEligiblePayoutsPending
      totalPendingRequestsAmount
      totalPaidOut
      vendorPayoutsList {
        vendor {
          _id
          name
          email
          phone
          avatar
          vendorCategory
          bankDetails {
            accountHolderName
            accountNumber
            bankName
            ifscCode
            upiId
          }
        }
        eligibleBalance
        pendingPayout
        totalEarnings
        totalPaidOut
        returnPendingBalance
      }
    }
  }
`;

export const GET_PAYOUT_REQUESTS = gql`
  query GetPayoutRequests($status: String, $vendorId: ID) {
    getPayoutRequests(status: $status, vendorId: $vendorId) {
      _id
      amount
      status
      adminNotes
      processedAt
      createdAt
      vendor {
        _id
        name
        email
        phone
        avatar
        vendorCategory
        bankDetails {
          accountHolderName
          accountNumber
          bankName
          ifscCode
          upiId
        }
      }
      bankDetails {
        accountHolderName
        accountNumber
        bankName
        ifscCode
        upiId
      }
      processedBy {
        _id
        name
        email
      }
    }
  }
`;
