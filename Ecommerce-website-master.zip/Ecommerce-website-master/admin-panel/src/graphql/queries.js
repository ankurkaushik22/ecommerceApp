import { gql } from '@apollo/client';

export const LOGIN = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token
      refreshToken
      user { _id name email role avatar }
    }
  }
`;

export const GET_ME = gql`
  query Me {
    me { _id name email role avatar phone isActive createdAt }
  }
`;

export const GET_DASHBOARD_STATS = gql`
  query GetDashboardStats {
    getDashboardStats {
      totalRevenue todayRevenue totalOrders todayOrders
      totalProducts totalUsers totalVendors pendingOrders
      recentOrders {
        _id orderNumber total status paymentMethod createdAt
        customer { name email avatar }
        items { name quantity price }
      }
      topProducts { _id name images price salesCount rating { average count } }
      revenueChart { label value }
      ordersChart { label value }
    }
  }
`;

export const GET_ALL_PRODUCTS = gql`
  query GetAllProducts($filter: ProductFilterInput, $sort: ProductSortInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, sort: $sort, pagination: $pagination) {
      products {
        _id name slug price comparePrice discount images stock
        isActive isFeatured isDeals freeShipping salesCount createdAt
        category { _id name }
        rating { average count }
        vendor { name }
      }
      total page pages hasNext
    }
  }
`;

export const GET_PRODUCT = gql`
  query GetProduct($id: ID!) {
    getProductById(id: $id) {
      _id name slug description shortDescription price comparePrice
      images stock sku isActive isFeatured isDeals freeShipping shippingCost
      tags specifications { key value }
      category { _id name } subcategory { _id name }
      vendor { _id name }
      rating { average count }
    }
  }
`;

export const GET_ALL_CATEGORIES = gql`
  query GetAllCategories {
    getAllCategories {
      _id name slug icon image description isActive sortOrder
      parent { _id name }
      children { _id name }
      productCount
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories($parentId: ID) {
    getCategories(parentId: $parentId) {
      _id name slug icon image isActive sortOrder
      children { _id name }
    }
  }
`;

export const GET_ALL_ORDERS = gql`
  query GetAllOrders($status: String, $pagination: PaginationInput) {
    getAllOrders(status: $status, pagination: $pagination) {
      orders {
        _id orderNumber status paymentMethod paymentStatus
        subtotal discount shippingCost tax total createdAt
        customer { _id name email avatar phone }
        deliveryBoy { _id name phone }
        items { name image price quantity variantLabel }
        shippingAddress { fullName phone addressLine1 city state postalCode country }
        trackingUpdates { status message timestamp location }
      }
      total page pages
    }
  }
`;

export const GET_ALL_USERS = gql`
  query GetAllUsers($role: String, $pagination: PaginationInput) {
    getAllUsers(role: $role, pagination: $pagination) {
      _id name email role avatar phone isActive isVerified createdAt
    }
  }
`;

export const GET_ALL_COUPONS = gql`
  query GetAllCoupons {
    getAllCoupons {
      _id code type value description minOrderAmount maxDiscountAmount
      usageLimit usedCount isActive startsAt expiresAt createdAt
    }
  }
`;

export const GET_ANALYTICS = gql`
  query GetAnalytics($period: String) {
    getAnalytics(period: $period)
  }
`;

export const GET_VENDORS = gql`
  query GetVendors {
    getVendors { _id name email avatar isActive isVerified createdAt }
  }
`;

export const GET_DELIVERY_BOYS = gql`
  query GetDeliveryBoys {
    getAllUsers(role: "delivery") {
      _id name email phone avatar isActive
    }
  }
`;
