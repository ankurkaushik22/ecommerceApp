export function getItemVertical(item) {
  if (!item) return 'shopping';
  const prod = item.product || item;

  // 1. Check explicit vertical property if set to food, grocery, services, or shopping
  const vert = item.vertical || prod.vertical || prod.category?.vertical;
  if (vert && ['food', 'grocery', 'services', 'shopping'].includes(vert)) {
    return vert;
  }

  // 2. Check product schema metadata attributes & addons/instructions
  if ((Array.isArray(item.addons) && item.addons.length > 0) || (Array.isArray(prod.addons) && prod.addons.length > 0)) {
    return 'food';
  }
  if (item.instructions || prod.instructions) {
    return 'food';
  }
  if (prod.restaurantName || (Array.isArray(prod.cuisine) && prod.cuisine.length > 0)) {
    return 'food';
  }
  if (prod.unitMeasure || (Array.isArray(prod.nutritionalHighlights) && prod.nutritionalHighlights.length > 0)) {
    return 'grocery';
  }
  if (prod.serviceDuration || (Array.isArray(prod.includedFeatures) && prod.includedFeatures.length > 0)) {
    return 'services';
  }

  // 3. Fallback name and category string matching
  const name = (item.name || prod.name || '').toLowerCase();
  const cat = (item.category?.name || prod.category?.name || item.category?.slug || prod.category?.slug || '').toLowerCase();

  if (
    cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') ||
    cat.includes('meat') || cat.includes('poultry') || cat.includes('bakery') || cat.includes('seafood') ||
    name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('bread') ||
    name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') ||
    name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') ||
    name.includes('apple') || name.includes('avocado') || name.includes('avocados') || name.includes('spinach') || name.includes('carrot') ||
    name.includes('strawberry') || name.includes('strawberries') || name.includes('chicken') || name.includes('mutton') || name.includes('meat') ||
    name.includes('egg') || name.includes('eggs') || name.includes('fish') || name.includes('prawn') ||
    name.includes('tomato') || name.includes('tomatoes') || name.includes('curry cut') || name.includes('boneless')
  ) {
    return 'grocery';
  }

  if (
    cat.includes('food') || cat.includes('restaurant') || cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') || cat.includes('pasta') ||
    name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('pasta') || name.includes('margherita') ||
    name.includes('tikka') || name.includes('momo') || name.includes('shake') || name.includes('wrap') || name.includes('roll') ||
    name.includes('thali') || name.includes('paneer tikka') || name.includes('kathi wrap') || name.includes('kathi') ||
    name.includes('dosa') || name.includes('chhole') || name.includes('paneer') || name.includes('chowmein')
  ) {
    return 'food';
  }

  if (cat.includes('service') || name.includes('plumbing') || name.includes('cleaning') || name.includes('repair')) {
    return 'services';
  }

  return 'shopping';
}

export function isFoodItem(item) {
  return getItemVertical(item) === 'food';
}

export function isGroceryItem(item) {
  return getItemVertical(item) === 'grocery';
}

export function isServiceItem(item) {
  return getItemVertical(item) === 'services';
}

export function isShoppingItem(item) {
  return getItemVertical(item) === 'shopping';
}

export function filterItemsByVertical(items, pathname) {
  if (!items || items.length === 0) return [];

  if (pathname?.startsWith('/food')) {
    const foodItems = items.filter(isFoodItem);
    if (foodItems.length > 0) return foodItems;
  }
  if (pathname?.startsWith('/grocery')) {
    const groceryItems = items.filter(isGroceryItem);
    if (groceryItems.length > 0) return groceryItems;
  }
  if (pathname?.startsWith('/services')) {
    const serviceItems = items.filter(isServiceItem);
    if (serviceItems.length > 0) return serviceItems;
  }
  if (pathname?.startsWith('/shopping')) {
    const shopItems = items.filter(isShoppingItem);
    if (shopItems.length > 0) return shopItems;
  }

  // Return all items for general pages (checkout, cart, home, header, cart drawer)
  return items;
}

export function isProductStockCompulsory(product) {
  if (!product) return false;
  if (product.isUnlimitedStock === true) return false;
  if (product.isStockCompulsory === false) return false;
  const vert = getItemVertical(product) || product.vertical;
  const isFoodOrService =
    vert === 'food' ||
    vert === 'services' ||
    Boolean(product.restaurantName) ||
    product.isVeg !== undefined ||
    (Array.isArray(product.cuisine) && product.cuisine.length > 0) ||
    (Array.isArray(product.addons) && product.addons.length > 0) ||
    Boolean(product.serviceDuration);

  if (isFoodOrService) {
    if (product.isStockCompulsory === true && product.isUnlimitedStock === false && typeof product.stock === 'number' && product.stock > 0) {
      return true;
    }
    return false;
  }
  if (product.isUnlimitedStock === false || product.isStockCompulsory === true) {
    return true;
  }
  return true;
}

export function getItemAvailableStock(item) {
  if (!item) return 999999;
  const p = item.product || item;
  if (!isProductStockCompulsory(p)) return 999999;
  if (typeof item.availableStock === 'number') return item.availableStock;

  const vIndex = item.variantIndex !== undefined ? item.variantIndex : (p.variantIndex ?? -1);
  if (vIndex >= 0 && Array.isArray(p.variants) && p.variants.length > 0) {
    let flatIdx = 0;
    for (const vg of p.variants) {
      for (const opt of vg.options || []) {
        if (flatIdx === vIndex) {
          if (opt.stock !== null && opt.stock !== undefined && typeof opt.stock === 'number') {
            return Number(opt.stock);
          }
          return 999999;
        }
        flatIdx++;
      }
    }
  }

  if (p.stock !== null && p.stock !== undefined && typeof p.stock === 'number') {
    return Number(p.stock);
  }

  return 999999;
}
