'use client';
import { gql, useQuery } from '@apollo/client';

const GET_LEGAL_PAGE = gql`
  query GetLegalPage($slug: String!) {
    getLegalPage(slug: $slug) {
      _id
      title
      content
      updatedAt
    }
  }
`;

export default function TermsPage() {
  const { data, loading, error } = useQuery(GET_LEGAL_PAGE, {
    variables: { slug: 'terms-and-conditions' },
  });

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-brand-500"></div>
      </div>
    );
  }

  if (error || !data?.getLegalPage) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <p className="text-red-500">Failed to load Terms & Conditions.</p>
      </div>
    );
  }

  const page = data.getLegalPage;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 md:p-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{page.title}</h1>
        {page.updatedAt && (
          <p className="text-sm text-gray-500 mb-8">
            Last updated: {new Date(page.updatedAt).toLocaleDateString()}
          </p>
        )}
        <div
          className="prose max-w-none prose-brand text-gray-700 whitespace-pre-wrap"
          dangerouslySetInnerHTML={{ __html: page.content }}
        />
      </div>
    </div>
  );
}
