'use client';
import { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import { format } from 'date-fns';
import {
  ChatBubbleLeftRightIcon,
  CheckCircleIcon,
  PaperAirplaneIcon,
  QuestionMarkCircleIcon,
  EnvelopeIcon,
  PhoneIcon,
  ClockIcon,
} from '@heroicons/react/24/outline';
import { useAuthStore } from '@/store/authStore';
import Link from 'next/link';

const CREATE_SUPPORT_TICKET = gql`
  mutation CreateSupportTicket($input: CreateSupportTicketInput!) {
    createSupportTicket(input: $input) {
      _id
      ticketNumber
      subject
      message
      category
      status
      createdAt
    }
  }
`;

const GET_MY_SUPPORT_TICKETS = gql`
  query GetMySupportTickets {
    getMySupportTickets {
      _id
      ticketNumber
      subject
      message
      category
      status
      priority
      adminReply
      createdAt
      repliedAt
    }
  }
`;

const CATEGORIES = [
  { id: 'orders', label: 'Orders & Delivery' },
  { id: 'payment', label: 'Payment & Refund' },
  { id: 'product', label: 'Product Inquiry' },
  { id: 'account', label: 'Account & Login' },
  { id: 'general', label: 'General Query / Feedback' },
];

const STATUS_COLORS = {
  open: 'bg-amber-50 text-amber-700 border-amber-200',
  in_progress: 'bg-blue-50 text-blue-700 border-blue-200',
  resolved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  closed: 'bg-gray-50 text-gray-700 border-gray-200',
};

export default function SupportPage() {
  const { user, isAuthenticated } = useAuthStore();
  const [activeTab, setActiveTab] = useState('new'); // 'new' or 'history'
  const [category, setCategory] = useState('orders');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submittedTicket, setSubmittedTicket] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  const { data, loading: loadingTickets, refetch } = useQuery(GET_MY_SUPPORT_TICKETS, {
    skip: !isAuthenticated,
    fetchPolicy: 'network-only',
  });

  const [createTicket, { loading: submitting }] = useMutation(CREATE_SUPPORT_TICKET, {
    onCompleted: (res) => {
      setSubmittedTicket(res.createSupportTicket);
      setSubject('');
      setMessage('');
      setErrorMsg('');
      if (refetch) refetch();
    },
    onError: (err) => {
      setErrorMsg(err.message || 'Failed to submit support request. Please try again.');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim()) {
      setErrorMsg('Please enter both subject and message details.');
      return;
    }

    createTicket({
      variables: {
        input: {
          subject: subject.trim(),
          message: message.trim(),
          category,
          name: user?.name || 'Website Customer',
          email: user?.email || 'customer@example.com',
          phone: user?.phone,
        },
      },
    });
  };

  const tickets = data?.getMySupportTickets || [];

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 bg-brand-50 text-brand-700 px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider">
          <ChatBubbleLeftRightIcon className="w-4 h-4" /> 24/7 Customer Helpdesk
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 tracking-tight">
          How can we help you today?
        </h1>
        <p className="text-sm text-gray-500 max-w-lg mx-auto">
          Submit your question, order issue, or feedback directly to our support team and track your requests.
        </p>
      </div>

      {/* Navigation Tabs */}
      {isAuthenticated && (
        <div className="flex justify-center">
          <div className="bg-gray-100 p-1 rounded-2xl inline-flex gap-1">
            <button
              onClick={() => {
                setActiveTab('new');
                setSubmittedTicket(null);
              }}
              className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'new'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              Submit New Ticket
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-6 py-2.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'history'
                  ? 'bg-white text-gray-900 shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              My Tickets ({tickets.length})
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      {activeTab === 'history' && isAuthenticated ? (
        /* Support Tickets History */
        <div className="space-y-4">
          {loadingTickets ? (
            <div className="p-12 text-center text-gray-400">Loading your tickets...</div>
          ) : tickets.length === 0 ? (
            <div className="bg-white rounded-3xl border border-gray-100 p-12 text-center space-y-3">
              <QuestionMarkCircleIcon className="w-12 h-12 text-gray-300 mx-auto" />
              <h3 className="text-base font-bold text-gray-900">No Support Tickets Yet</h3>
              <p className="text-xs text-gray-500 max-w-sm mx-auto">
                You have not submitted any inquiries. Click &apos;Submit New Ticket&apos; if you need assistance.
              </p>
              <button
                onClick={() => setActiveTab('new')}
                className="btn-brand inline-block text-xs font-bold px-4 py-2 mt-2"
              >
                Submit a Query
              </button>
            </div>
          ) : (
            tickets.map((t) => (
              <div
                key={t._id}
                className="bg-white rounded-2xl border border-gray-100 p-5 sm:p-6 space-y-3 shadow-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-brand-600 bg-brand-50 px-2.5 py-1 rounded-lg">
                      #{t.ticketNumber}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full border capitalize font-bold ${
                        STATUS_COLORS[t.status] || 'bg-gray-50'
                      }`}
                    >
                      {t.status.replace('_', ' ')}
                    </span>
                  </div>
                  <span className="text-xs text-gray-400">
                    {t.createdAt ? format(new Date(t.createdAt), 'dd MMM yyyy, hh:mm a') : ''}
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-gray-900">{t.subject}</h3>
                  <p className="text-sm text-gray-600 mt-1 whitespace-pre-line">{t.message}</p>
                </div>

                {t.adminReply && (
                  <div className="bg-blue-50/70 border border-blue-100 rounded-xl p-4 mt-3 space-y-1">
                    <div className="flex items-center justify-between text-xs font-bold text-blue-900">
                      <span>Admin Reply</span>
                      {t.repliedAt && (
                        <span className="text-blue-500 font-normal">
                          {format(new Date(t.repliedAt), 'dd MMM yyyy, hh:mm a')}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-blue-800 whitespace-pre-line">{t.adminReply}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      ) : submittedTicket ? (
        /* Success Screen */
        <div className="bg-white rounded-3xl border border-gray-100 p-8 sm:p-12 text-center space-y-4 shadow-sm max-w-lg mx-auto">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto text-2xl">
            <CheckCircleIcon className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Message Sent to Admin!</h2>
          <p className="text-xs sm:text-sm text-gray-500 leading-relaxed">
            Your support request has been registered. Our admin team will review your message and reply back shortly.
          </p>

          <div className="bg-gray-50 border border-gray-200 rounded-2xl p-4 inline-block">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-wider block">
              Ticket Reference ID
            </span>
            <span className="text-lg font-black text-brand-600 font-mono mt-1 block">
              #{submittedTicket.ticketNumber}
            </span>
          </div>

          <div className="pt-2">
            <button
              onClick={() => setSubmittedTicket(null)}
              className="btn-brand text-xs font-bold px-6 py-3"
            >
              Submit Another Message
            </button>
          </div>
        </div>
      ) : (
        /* New Support Form */
        <div className="bg-white rounded-3xl border border-gray-100 p-6 sm:p-10 shadow-sm space-y-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            {errorMsg && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl">
                {errorMsg}
              </div>
            )}

            {/* Category */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Issue Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 font-medium focus:outline-none focus:ring-2 focus:ring-brand-500"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Subject */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Subject
              </label>
              <input
                type="text"
                placeholder="e.g. Need assistance with order delivery or refund"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                Message Details
              </label>
              <textarea
                rows={5}
                placeholder="Please describe your question, issue, or order reference in detail..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
            </div>

            {/* Logged in sender note */}
            {user?.email ? (
              <div className="bg-brand-50/60 border border-brand-100 rounded-xl p-3.5 flex items-center gap-2.5 text-xs text-brand-800">
                <EnvelopeIcon className="w-4 h-4 text-brand-600 flex-shrink-0" />
                <span>
                  Admin reply will be linked to your account: <strong>{user.email}</strong>
                </span>
              </div>
            ) : (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 text-xs text-amber-800">
                Tip: <Link href="/login?redirect=/support" className="font-bold underline">Sign In</Link> to track your support ticket history and receive real-time admin replies.
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full btn-brand py-3 rounded-xl text-sm font-extrabold flex items-center justify-center gap-2 shadow-sm disabled:opacity-60"
            >
              {submitting ? (
                'Submitting Message...'
              ) : (
                <>
                  <PaperAirplaneIcon className="w-4 h-4" /> Send Message to Admin
                </>
              )}
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
