'use client';
import { useMemo } from 'react';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import {
  SparklesIcon, FireIcon, TruckIcon, ShieldCheckIcon,
  ArrowPathIcon, CreditCardIcon, ArrowRightIcon
} from '@heroicons/react/24/outline';
import HeroBanner from '@/components/shop/HeroBanner';
import ProductCard from '@/components/shop/ProductCard';
import { GET_PRODUCTS, GET_CATEGORIES, GET_STORE_SETTINGS } from '@/graphql/queries';

const FEATURES = [
  { icon: TruckIcon, title: 'Free Express Delivery', desc: 'On orders over ₹499' },
  { icon: ShieldCheckIcon, title: 'Secure Payment', desc: '100% protected by UPI & Stripe' },
  { icon: ArrowPathIcon, title: '30-Day Easy Returns', desc: 'Hassle-free guarantee' },
  { icon: CreditCardIcon, title: 'Cash on Delivery', desc: 'Pay at your doorstep' },
];

const FALLBACK_SHOPPING_CATEGORIES = [
  { _id: 'c-elec', name: 'Electronics', slug: 'electronics', icon: '💻', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400' },
  { _id: 'c-cloth', name: 'Clothing', slug: 'clothing', icon: '👔', image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=400' },
  { _id: 'c-home', name: 'Home & Kitchen', slug: 'home-and-kitchen', icon: '🍳', image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=400' },
  { _id: 'c-beauty', name: 'Beauty & Health', slug: 'beauty-and-health', icon: '✨', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400' },
  { _id: 'c-sports', name: 'Sports & Outdoors', slug: 'sports-and-outdoors', icon: '⚽', image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400' },
  { _id: 'c-jewel', name: 'Jewelry', slug: 'jewelry', icon: '💎', image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400' },
  { _id: 'c-books', name: 'Books', slug: 'books', icon: '📚', image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400' },
  { _id: 'c-auto', name: 'Automotive', slug: 'automotive', icon: '🚗', image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400' },
];

const FALLBACK_SHOPPING_PRODUCTS = [
  {
    _id: 'fb-sp-1',
    name: 'iPhone 15 Pro Max 256GB Titanium',
    slug: 'iphone-15-pro-max-256gb',
    price: 119999,
    comparePrice: 134900,
    discount: 11,
    images: ['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800'],
    category: { _id: 'c-elec', name: 'Electronics', slug: 'electronics' },
    rating: { average: 4.8, count: 1250 },
    freeShipping: true,
    stock: 25,
  },
  {
    _id: 'fb-sp-2',
    name: 'MacBook Pro 14" M3 Pro Chip',
    slug: 'macbook-pro-14-m3-pro',
    price: 199990,
    comparePrice: 219900,
    discount: 9,
    images: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800'],
    category: { _id: 'c-elec', name: 'Electronics', slug: 'electronics' },
    rating: { average: 4.9, count: 840 },
    freeShipping: true,
    stock: 15,
  },
  {
    _id: 'fb-sp-3',
    name: 'Sony WH-1000XM5 Wireless Headphones',
    slug: 'sony-wh-1000xm5-headphones',
    price: 29990,
    comparePrice: 34990,
    discount: 14,
    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800'],
    category: { _id: 'c-elec', name: 'Electronics', slug: 'electronics' },
    rating: { average: 4.7, count: 2100 },
    freeShipping: true,
    stock: 40,
  },
  {
    _id: 'fb-sp-4',
    name: 'Samsung 55" 4K Ultra HD Smart QLED TV',
    slug: 'samsung-55-4k-qled-smart-tv',
    price: 64990,
    comparePrice: 89900,
    discount: 28,
    images: ['https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800'],
    category: { _id: 'c-elec', name: 'Electronics', slug: 'electronics' },
    rating: { average: 4.6, count: 680 },
    freeShipping: true,
    stock: 18,
  },
  {
    _id: 'fb-sp-5',
    name: "Men's Italian Wool Slim Fit 2-Piece Suit",
    slug: 'mens-premium-slim-fit-suit',
    price: 12999,
    comparePrice: 18999,
    discount: 32,
    images: ['https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800'],
    category: { _id: 'c-cloth', name: 'Clothing', slug: 'clothing' },
    rating: { average: 4.6, count: 420 },
    freeShipping: true,
    stock: 30,
  },
  {
    _id: 'fb-sp-6',
    name: "Women's Chiffon Floral Print Maxi Dress",
    slug: 'womens-floral-maxi-dress',
    price: 3499,
    comparePrice: 4999,
    discount: 30,
    images: ['https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=800'],
    category: { _id: 'c-cloth', name: 'Clothing', slug: 'clothing' },
    rating: { average: 4.5, count: 530 },
    freeShipping: true,
    stock: 50,
  },
  {
    _id: 'fb-sp-7',
    name: 'Nespresso Vertuo Next Coffee Machine',
    slug: 'nespresso-vertuo-next-coffee-machine',
    price: 16999,
    comparePrice: 21999,
    discount: 23,
    images: ['https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=800'],
    category: { _id: 'c-home', name: 'Home & Kitchen', slug: 'home-and-kitchen' },
    rating: { average: 4.7, count: 890 },
    freeShipping: true,
    stock: 22,
  },
  {
    _id: 'fb-sp-8',
    name: 'Ergonomic Mesh High Back Office Chair',
    slug: 'ergonomic-office-chair-lumbar-support',
    price: 14999,
    comparePrice: 22999,
    discount: 35,
    images: ['https://images.unsplash.com/photo-1580481077197-28d58c89c8a9?w=800'],
    category: { _id: 'c-home', name: 'Home & Kitchen', slug: 'home-and-kitchen' },
    rating: { average: 4.8, count: 1100 },
    freeShipping: true,
    stock: 35,
  },
];

export default function ShopMallPage() {
  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];

  const { data: catData, loading: loadingCats } = useQuery(GET_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });

  const { data: prodData, loading: loadingProducts } = useQuery(GET_PRODUCTS, {
    variables: {
      pagination: { limit: 80 },
    },
    fetchPolicy: 'cache-and-network',
  });

  // Whitelist of shopping category slugs
  const SHOPPING_SLUGS = useMemo(() => new Set([
    'electronics', 'clothing', 'home-and-kitchen', 'beauty-and-health',
    'sports-and-outdoors', 'books', 'automotive', 'jewelry',
  ]), []);

  // Non-shopping slugs to exclude
  const NON_SHOPPING_SLUGS = useMemo(() => new Set([
    'food-and-dining', 'food-delivery', 'services', 'home-services', 'grocery',
    'fresh-fruits', 'fresh-vegetables', 'dairy-breakfast', 'bakery-breads', 'meat',
    'biryani-rice', 'north-indian', 'pizzas-pasta', 'burgers-fast-food',
    'chinese-momos', 'desserts-shakes', 'rolls-wraps',
    'ac-appliance-repair', 'deep-home-cleaning', 'womens-salon-spa',
    'electrician-plumber', 'painting-woodwork',
  ]), []);

  const categories = useMemo(() => {
    const raw = catData?.getCategories || [];
    const filtered = raw.filter((c) => {
      const slug = (c.slug || '').toLowerCase();
      return SHOPPING_SLUGS.has(slug);
    });
    return filtered.length > 0 ? filtered : FALLBACK_SHOPPING_CATEGORIES;
  }, [catData, SHOPPING_SLUGS]);

  const { dealsProducts, featuredProducts } = useMemo(() => {
    const raw = prodData?.getProducts?.products || [];
    const shoppingOnly = raw.filter((p) => {
      const catSlug = (p?.category?.slug || '').toLowerCase();
      if (NON_SHOPPING_SLUGS.has(catSlug)) return false;
      return SHOPPING_SLUGS.has(catSlug);
    });

    const products = shoppingOnly.length > 0 ? shoppingOnly : FALLBACK_SHOPPING_PRODUCTS;

    const deals = products
      .filter((p) => p.isDeals || (p.comparePrice && p.comparePrice > p.price))
      .slice(0, 4);

    const featured = products
      .filter((p) => p.isFeatured || (p.rating?.average && p.rating.average >= 4.5))
      .slice(0, 8);

    return {
      dealsProducts: deals.length >= 2 ? deals : products.slice(0, 4),
      featuredProducts: featured.length >= 4 ? featured : products.slice(0, 8),
    };
  }, [prodData, NON_SHOPPING_SLUGS, SHOPPING_SLUGS]);

  if (disabledVerticals.includes('shopping')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <p className="text-6xl">🛍️</p>
        <h1 className="text-2xl font-bold text-gray-900">Shopping Mall Currently Unavailable</h1>
        <Link href="/" className="btn-brand inline-block text-sm px-6 py-2.5 rounded-xl font-bold">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-12">
      {/* Hero Banner */}
      <HeroBanner />

      {/* Trust Badges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {FEATURES.map((item, i) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3.5 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm"
            >
              <div className="p-3 rounded-xl bg-brand-50 text-brand-600 flex-shrink-0">
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-gray-900 leading-tight">{item.title}</h4>
                <p className="text-[11px] text-gray-500 mt-0.5">{item.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Featured Categories Carousel / Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 flex items-center gap-2">
              <span>Shop by Category</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-500">Explore top shopping categories curated for you</p>
          </div>
          <Link
            href="/categories"
            className="text-sm font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            All Categories <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
          {loadingCats && !catData
            ? [...Array(8)].map((_, i) => (
                <div key={i} className="card p-4 flex flex-col items-center animate-pulse gap-3">
                  <div className="w-16 h-16 rounded-full bg-gray-100" />
                  <div className="h-3 w-16 bg-gray-100 rounded" />
                </div>
              ))
            : categories.slice(0, 8).map((cat) => (
                <Link
                  key={cat._id}
                  href={`/category/${cat.slug}`}
                  className="card p-4 flex flex-col items-center justify-center text-center group hover:border-brand-300 hover:shadow-md transition-all rounded-2xl"
                >
                  <div className="w-16 h-16 rounded-2xl bg-brand-50 flex items-center justify-center overflow-hidden group-hover:scale-110 transition-transform mb-2">
                    {cat.image || (cat.icon && cat.icon.startsWith('http')) ? (
                      <img
                        src={cat.image || cat.icon}
                        alt={cat.name}
                        className="w-full h-full object-cover rounded-2xl"
                      />
                    ) : (
                      <span className="text-3xl">{cat.icon || '🛍️'}</span>
                    )}
                  </div>
                  <span className="text-xs sm:text-sm font-bold text-gray-800 group-hover:text-brand-600 transition-colors">
                    {cat.name}
                  </span>
                </Link>
              ))}
        </div>
      </section>

      {/* Flash Deals / Today's Specials */}
      <section className="space-y-4 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-500/10 via-brand-500/5 to-rose-500/10 border border-amber-200/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500 text-white rounded-xl shadow-sm">
              <FireIcon className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Today&apos;s Flash Deals</h2>
              <p className="text-xs sm:text-sm text-gray-600">Special discounts updated daily</p>
            </div>
          </div>
          <Link
            href="/deals"
            className="self-start sm:self-auto text-sm font-bold text-amber-600 hover:text-amber-700 flex items-center gap-1 bg-white px-4 py-2 rounded-xl border border-amber-200 shadow-2xs hover:shadow-sm transition-all"
          >
            View All Deals <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {loadingProducts && !prodData
            ? [...Array(4)].map((_, i) => (
                <div key={i} className="card p-4 h-72 animate-pulse bg-gray-100 rounded-2xl" />
              ))
            : dealsProducts.map((prod) => (
                <ProductCard key={prod._id} product={prod} />
              ))}
        </div>
      </section>

      {/* Featured Products Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-brand-50 text-brand-600 rounded-xl">
              <SparklesIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Featured Collections</h2>
              <p className="text-xs sm:text-sm text-gray-500">Handpicked items with great ratings</p>
            </div>
          </div>
          <Link
            href="/products"
            className="text-sm font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            See More <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {loadingProducts && !prodData
            ? [...Array(8)].map((_, i) => (
                <div key={i} className="card p-4 h-72 animate-pulse bg-gray-100 rounded-2xl" />
              ))
            : featuredProducts.map((prod) => (
                <ProductCard key={prod._id} product={prod} />
              ))}
        </div>
      </section>
    </div>
  );
}
