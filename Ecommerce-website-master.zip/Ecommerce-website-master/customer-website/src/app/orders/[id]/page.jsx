'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useSubscription, gql } from '@apollo/client';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import {
  CheckCircleIcon, ClockIcon, TruckIcon,
  XCircleIcon, MapPinIcon, PhoneIcon, UserIcon,
  ArrowLeftIcon, DocumentTextIcon, StarIcon,
  SparklesIcon, PrinterIcon, XMarkIcon,
  ShareIcon, EnvelopeIcon,
} from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_ORDER } from '@/graphql/queries';
import { CANCEL_ORDER, ADD_REVIEW, REQUEST_RETURN } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

const ORDER_SUBSCRIPTION = gql`
  subscription OnOrderStatusUpdated($orderId: ID!) {
    orderStatusUpdated(orderId: $orderId) {
      _id status paymentStatus trackingUpdates { status message timestamp location }
    }
  }
`;

const STEPS = [
  { key: 'placed', label: 'Order Placed', desc: 'We have received your order' },
  { key: 'accepted', label: 'Order Accepted', desc: 'Seller accepted the order' },
  { key: 'processing', label: 'Processing', desc: 'Item is being packed & prepared' },
  { key: 'ready_for_pickup', label: 'Ready for Pickup', desc: 'Package ready for courier' },
  { key: 'picked_up', label: 'Picked Up', desc: 'Courier agent picked up the package' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Courier agent is on the way' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered to your address' },
];

export default function OrderTrackingPage() {
  const params = useParams();
  const router = useRouter();
  const orderId = params?.id ? decodeURIComponent(params.id) : '';

  const [cancelReason, setCancelReason] = useState('');
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [returnReason, setReturnReason] = useState('');
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  // Review modal states
  const [reviewTab, setReviewTab] = useState('product'); // 'product' | 'seller' | 'delivery'
  const [selectedProductId, setSelectedProductId] = useState('');
  const [rating, setRating] = useState(5);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');

  const { data, loading, error, refetch } = useQuery(GET_ORDER, {
    variables: { id: orderId },
    skip: !orderId,
    fetchPolicy: 'cache-and-network',
  });

  // Listen to live subscription updates
  const { data: subData } = useSubscription(ORDER_SUBSCRIPTION, {
    variables: { orderId },
    skip: !orderId,
  });

  const order = data?.getOrder;

  useEffect(() => {
    if (subData?.orderStatusUpdated) {
      if (order && subData.orderStatusUpdated.status !== order.status) {
        toast.success(`Order status updated to: ${subData.orderStatusUpdated.status.replace(/_/g, ' ')}`);
      }
      refetch();
    }
  }, [subData, order?.status, refetch]);

  const [cancelOrderMutation, { loading: cancelling }] = useMutation(CANCEL_ORDER, {
    onCompleted: () => {
      toast.success('Order cancelled');
      setShowCancelModal(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [requestReturnMutation, { loading: requestingReturn }] = useMutation(REQUEST_RETURN, {
    onCompleted: () => {
      toast.success('Return request submitted successfully');
      setShowReturnModal(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [addReviewMutation, { loading: submittingReview }] = useMutation(ADD_REVIEW, {
    onCompleted: () => {
      toast.success('Thank you! Your review has been submitted.');
      setShowReviewModal(false);
      setTitle('');
      setComment('');
      setRating(5);
    },
    onError: (e) => toast.error(e.message || 'Failed to submit review'),
  });

  

  useEffect(() => {
    if (order?.items?.[0]?.product?._id) {
      setSelectedProductId(order.items[0].product._id);
    }
  }, [order]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
        <div className="h-48 bg-gray-100 rounded-3xl animate-pulse" />
        <div className="h-64 bg-gray-100 rounded-3xl animate-pulse" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-4xl">📦</p>
        <h2 className="text-2xl font-bold text-gray-900">
          {error ? 'Unable to Load Order' : 'Order Not Found'}
        </h2>
        <p className="text-xs text-gray-500 max-w-sm mx-auto">
          {error?.message || `We couldn't locate any order with reference "${orderId}". Please check the order number or link.`}
        </p>
        <div className="flex items-center justify-center gap-3 pt-2">
          {error && (
            <button onClick={() => refetch()} className="btn-brand text-xs font-bold px-4 py-2">
              Try Again
            </button>
          )}
          <button onClick={() => router.push('/orders')} className="btn-outline text-xs font-bold px-4 py-2">
            Back to Orders
          </button>
        </div>
      </div>
    );
  }

  const currentStepIndex = STEPS.findIndex((s) => s.key === order.status);
  const isCancelled = order.status === 'cancelled';
  const isDelivered = order.status === 'delivered';

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (!comment.trim()) {
      toast.error('Please write a comment');
      return;
    }

    const input = {
      targetType: reviewTab,
      orderId: order._id,
      rating,
      title: title.trim() || `${reviewTab === 'product' ? 'Product' : reviewTab === 'seller' ? 'Seller' : 'Delivery'} Feedback`,
      comment: comment.trim(),
    };

    if (reviewTab === 'product') {
      input.productId = selectedProductId || order.items[0]?.product?._id;
    } else if (reviewTab === 'seller') {
      input.vendorId = order.vendor?._id || order.items[0]?.vendor || undefined;
    } else if (reviewTab === 'delivery') {
      input.deliveryAgentId = order.deliveryAgent?._id || order.deliveryBoy?._id || undefined;
    }

    addReviewMutation({ variables: { input } });
  };

  const handleShareInvoice = async () => {
    const invoiceSummary = `🧾 *Suaaka Tax Invoice*\nOrder No: #${order.orderNumber}\nInvoice No: ${order.invoiceNumber || `INV-${order.orderNumber}`}\nGrand Total: ₹${order.total?.toLocaleString('en-IN')}\nBilled To: ${order.shippingAddress?.fullName || 'Customer'}\nItems: ${(order.items || []).map((i) => `${i.name} (Qty: ${i.quantity})`).join(', ')}\n\nView Order: ${typeof window !== 'undefined' ? window.location.href : ''}`;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `Tax Invoice #${order.orderNumber} - Suaaka`,
          text: invoiceSummary,
          url: window.location.href,
        });
        toast.success('Invoice shared successfully!');
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
      }
    }

    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(invoiceSummary);
      toast.success('Invoice details copied to clipboard!');
    }
  };

  const handleEmailInvoice = () => {
    const subject = encodeURIComponent(`Tax Invoice for Order #${order.orderNumber} - Suaaka`);
    const body = encodeURIComponent(
      `Hello ${order.shippingAddress?.fullName || 'Customer'},\n\nHere is your Tax Invoice summary for Order #${order.orderNumber}:\n\nInvoice Number: ${order.invoiceNumber || `INV-${order.orderNumber}`}\nTotal Amount Paid: INR ${order.total}\nPayment Method: ${order.paymentMethod?.toUpperCase()}\nDelivery Address: ${order.shippingAddress?.addressLine1}, ${order.shippingAddress?.city} - ${order.shippingAddress?.postalCode}\n\nItems:\n${(order.items || []).map((i) => `- ${i.name} x ${i.quantity} (INR ${i.price})`).join('\n')}\n\nYou can track and view full details here:\n${typeof window !== 'undefined' ? window.location.href : ''}\n\nThank you for shopping with Suaaka!`
    );
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
  };

  const handleWhatsAppInvoice = () => {
    const invoiceSummary = `🧾 *Suaaka Tax Invoice*\nOrder No: #${order.orderNumber}\nInvoice No: ${order.invoiceNumber || `INV-${order.orderNumber}`}\nGrand Total: ₹${order.total?.toLocaleString('en-IN')}\nBilled To: ${order.shippingAddress?.fullName || 'Customer'}\n\nItems:\n${(order.items || []).map((i) => `• ${i.name} (Qty: ${i.quantity})`).join('\n')}\n\nTrack Invoice: ${typeof window !== 'undefined' ? window.location.href : ''}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(invoiceSummary)}`, '_blank');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <button
            onClick={() => router.push('/orders')}
            className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-brand-600 mb-2 font-medium"
          >
            <ArrowLeftIcon className="w-3.5 h-3.5" /> Back to My Orders
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-extrabold text-gray-900">
              Order #{order.orderNumber}
            </h1>
            <span
              className={`px-3 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                order.status === 'delivered'
                  ? 'bg-emerald-100 text-emerald-800'
                  : order.status === 'cancelled'
                  ? 'bg-rose-100 text-rose-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              {order.status.replace(/_/g, ' ')}
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Placed on {order.createdAt ? format(new Date(order.createdAt), 'PPP p') : 'Recently'} • Invoice #{order.invoiceNumber || `INV-${order.orderNumber}`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Tax Invoice Button */}
          <button
            onClick={() => setShowInvoiceModal(true)}
            className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <DocumentTextIcon className="w-4 h-4 text-gray-600" />
            <span>Tax Invoice</span>
          </button>

          {/* Rate & Review Button */}
          {isDelivered && (
            <button
              onClick={() => setShowReviewModal(true)}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all"
            >
              <StarIcon className="w-4 h-4" />
              <span>Rate & Review</span>
            </button>
          )}

          {/* Cancel Order Button */}
          {['placed', 'accepted', 'processing'].includes(order.status) && (
            <button
              onClick={() => setShowCancelModal(true)}
              className="px-4 py-2 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-bold transition-colors"
            >
              Cancel Order
            </button>
          )}

          {/* Request Return Button */}
          {order.status === 'delivered' && (!order.returnStatus || order.returnStatus === 'none') && (
            <button
              onClick={() => setShowReturnModal(true)}
              className="px-4 py-2 bg-orange-100 text-orange-700 hover:bg-orange-200 rounded-xl text-xs font-bold transition-colors"
            >
              Request Return
            </button>
          )}

          {/* Return Status Badge */}
          {order.returnStatus && order.returnStatus !== 'none' && (
            <div className="px-4 py-2 bg-gray-100 text-gray-700 rounded-xl text-xs font-bold capitalize border border-gray-200">
              Return: {order.returnStatus}
            </div>
          )}
        </div>
      </div>

      {/* Tracking Stepper */}
      {!isCancelled && (
        <div className="card p-6 sm:p-8 space-y-6">
          <h2 className="text-base font-bold text-gray-900">Order Journey & Tracking</h2>

          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {STEPS.map((step, idx) => {
              const isCompleted = idx <= currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              return (
                <div key={step.key} className="flex flex-col items-center text-center space-y-2 relative">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-brand-500 text-white shadow-lg shadow-brand-500/30'
                        : 'bg-gray-100 text-gray-400'
                    } ${isCurrent ? 'ring-4 ring-brand-100 scale-105' : ''}`}
                  >
                    {isCompleted ? <CheckCircleIcon className="w-6 h-6" /> : <ClockIcon className="w-5 h-5" />}
                  </div>
                  <span className={`text-xs font-bold ${isCompleted ? 'text-gray-900' : 'text-gray-400'}`}>
                    {step.label}
                  </span>
                  <span className="text-[10px] text-gray-400 leading-tight hidden sm:block">
                    {step.desc}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Live Delivery Partner Tracking Map Card */}
      {['picked_up', 'out_for_delivery'].includes(order.status) && (
        <div className="card overflow-hidden border border-emerald-200 shadow-md">
          {/* Header */}
          <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <span className="text-xs font-black tracking-wider uppercase">Live Delivery Partner Tracking</span>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-800/50">
              {order.status === 'out_for_delivery' ? 'Arriving in ~15 mins' : 'In Transit from Hub'}
            </span>
          </div>

          {/* Interactive Visual Map Canvas */}
          <div className="h-52 bg-slate-100 relative overflow-hidden flex items-center justify-center border-b border-gray-200">
            {/* Roads Layout */}
            <div className="absolute top-16 left-0 right-0 h-4 bg-slate-300"></div>
            <div className="absolute top-36 left-0 right-0 h-5 bg-slate-300"></div>
            <div className="absolute top-0 bottom-0 left-1/4 w-4 bg-slate-300"></div>
            <div className="absolute top-0 bottom-0 right-1/3 w-5 bg-slate-300"></div>

            {/* Connecting Route Line */}
            <div className="absolute top-12 bottom-16 left-28 right-36 border-2 border-dashed border-emerald-500 rounded-xl pointer-events-none opacity-80"></div>

            {/* Agent Live Marker */}
            <div className="absolute bottom-8 left-20 flex flex-col items-center animate-bounce">
              <div className="w-10 h-10 rounded-full bg-emerald-600 border-2 border-white shadow-lg flex items-center justify-center text-white">
                <TruckIcon className="w-5 h-5" />
              </div>
              <span className="mt-1 bg-white text-[10px] font-bold text-slate-800 px-2 py-0.5 rounded shadow border border-gray-200">
                {order.deliveryAgent?.name || 'Delivery Partner'}
              </span>
            </div>

            {/* Destination Pin */}
            <div className="absolute top-8 right-28 flex flex-col items-center">
              <div className="w-9 h-9 rounded-full bg-brand-500 border-2 border-white shadow-lg flex items-center justify-center text-white">
                <MapPinIcon className="w-5 h-5" />
              </div>
              <span className="mt-1 bg-slate-900 text-[10px] font-bold text-white px-2 py-0.5 rounded shadow">
                Your Address
              </span>
            </div>

            {/* Floating Live Telemetry Badge */}
            <div className="absolute bottom-3 right-4 bg-white/95 backdrop-blur-sm border border-gray-200 px-3 py-1.5 rounded-xl shadow text-xs flex items-center gap-3">
              <div>
                <p className="text-[10px] text-gray-500 font-bold uppercase">Estimated ETA</p>
                <p className="font-extrabold text-emerald-600">~15 mins</p>
              </div>
              <div className="w-px h-6 bg-gray-200"></div>
              <div>
                <p className="text-[10px] text-gray-500 font-bold uppercase">GPS Speed</p>
                <p className="font-extrabold text-slate-800">{order.liveLocation?.speed || 24} km/h</p>
              </div>
            </div>
          </div>

          {/* Footer Call Partner */}
          <div className="p-4 bg-white flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                {(order.deliveryAgent?.name || order.deliveryBoy?.name)?.[0] || 'D'}
              </div>
              <div>
                <p className="text-sm font-bold text-gray-900">
                  {order.deliveryAgent?.name || order.deliveryBoy?.name || 'ShopZone Logistics Executive'}
                </p>
                <p className="text-xs text-gray-500">
                  {order.liveLocation
                    ? `Live GPS updated ${format(new Date(order.liveLocation.updatedAt || new Date()), 'p')}`
                    : 'Dispatched and on route'}
                </p>
              </div>
            </div>

            {(order.deliveryAgent?.phone || order.deliveryBoy?.phone) && (
              <a
                href={`tel:${(order.deliveryAgent?.phone || order.deliveryBoy?.phone || '').replace(/[^0-9+]/g, '')}`}
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition"
              >
                <PhoneIcon className="w-4 h-4" />
                <span>Call Delivery Partner</span>
              </a>
            )}
          </div>
        </div>
      )}

      {/* Grid: Delivery Agent & Shipping Address */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Delivery Partner */}
        <div className="card p-6 space-y-3">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <TruckIcon className="w-4 h-4 text-brand-500" />
            <span>Delivery Information</span>
          </h3>
          <div className="p-3 bg-brand-50/50 rounded-xl border border-brand-100/70 text-xs space-y-1">
            <p className="font-bold text-brand-900">Speed: {order.deliveryOption?.name || 'Standard Delivery'}</p>
            <p className="text-gray-600">Estimated transit: {order.deliveryOption?.estimatedDays || '3-5 Business Days'}</p>
          </div>
          {(order.deliveryAgent || order.deliveryBoy) ? (
            <div className="flex items-center gap-3 pt-2">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm">
                {(order.deliveryAgent?.name || order.deliveryBoy?.name)?.[0] || 'D'}
              </div>
              <div className="text-xs">
                <p className="font-bold text-gray-900">{order.deliveryAgent?.name || order.deliveryBoy?.name}</p>
                <p className="text-gray-500 flex items-center gap-1 mt-0.5">
                  <PhoneIcon className="w-3.5 h-3.5 text-gray-400" /> {order.deliveryAgent?.phone || order.deliveryBoy?.phone || '+91 98765 00000'}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-gray-500">
              A courier executive will be assigned once the package leaves the local hub.
            </p>
          )}
        </div>

        {/* Shipping Address */}
        <div className="card p-6 space-y-2">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <MapPinIcon className="w-4 h-4 text-brand-500" />
            <span>Shipping Destination</span>
          </h3>
          <div className="text-xs text-gray-600 space-y-0.5 pt-1">
            <p className="font-bold text-gray-900 text-sm">{order.shippingAddress?.fullName}</p>
            <p>{order.shippingAddress?.addressLine1} {order.shippingAddress?.addressLine2}</p>
            <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}</p>
            <p className="text-gray-400 pt-1">📞 {order.shippingAddress?.phone}</p>
          </div>
        </div>
      </div>

      {/* Items & Payment Breakdown */}
      <div className="card p-6 space-y-5">
        <h3 className="font-bold text-gray-900 text-base">Items in this Package</h3>
        <div className="divide-y divide-gray-100">
          {order.items?.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={item.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                  alt=""
                  className="w-14 h-14 object-cover rounded-xl border border-gray-100"
                />
                <div>
                  <h4 className="font-bold text-sm text-gray-900">{item.name}</h4>
                  {item.variantLabel && (
                    <span className="text-xs text-gray-500">{item.variantLabel}</span>
                  )}
                  <p className="text-xs text-gray-400 mt-0.5">
                    Qty: {item.quantity} × ₹{Number(item.price).toLocaleString('en-IN')}
                  </p>
                </div>
              </div>
              <span className="font-extrabold text-sm text-gray-900">
                ₹{(item.price * item.quantity).toLocaleString('en-IN')}
              </span>
            </div>
          ))}
        </div>

        {/* Pricing Totals */}
        <div className="border-t border-gray-100 pt-4 space-y-2 text-xs text-gray-600">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>₹{order.subtotal?.toLocaleString('en-IN')}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Discount</span>
              <span>-₹{order.discount?.toLocaleString('en-IN')}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Shipping ({order.deliveryOption?.name || 'Standard'})</span>
            <span>{(order.shippingCost === 0 || !order.shippingCost) ? <span className="text-emerald-600 font-semibold">FREE</span> : `₹${order.shippingCost}`}</span>
          </div>
          {order.tax > 0 && (
            <div className="flex justify-between">
              <span>GST ({order.taxDetails?.rate || 18}%)</span>
              <span>₹{order.tax?.toLocaleString('en-IN')}</span>
            </div>
          )}
          <div className="border-t border-gray-100 pt-2 flex justify-between text-base font-extrabold text-gray-900">
            <span>Total Paid ({order.paymentMethod?.toUpperCase()})</span>
            <span className="text-brand-600 font-bold">₹{order.total?.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* Tax Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <div>
                <h3 className="text-xl font-extrabold text-gray-900">TAX INVOICE</h3>
                <p className="text-xs text-gray-500">Invoice No: {order.invoiceNumber || `INV-${order.orderNumber}`}</p>
              </div>
              <div className="flex items-center gap-2 flex-wrap justify-end">
                <button
                  onClick={handleShareInvoice}
                  className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title="Share Invoice"
                >
                  <ShareIcon className="w-4 h-4" /> Share
                </button>
                <button
                  onClick={handleEmailInvoice}
                  className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title="Email Invoice"
                >
                  <EnvelopeIcon className="w-4 h-4" /> Email
                </button>
                <button
                  onClick={handleWhatsAppInvoice}
                  className="px-3 py-1.5 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                  title="Share on WhatsApp"
                >
                  <span className="text-sm">💬</span> WhatsApp
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-brand-500 hover:bg-brand-600 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <PrinterIcon className="w-4 h-4" /> Print / PDF
                </button>
                <button
                  onClick={() => setShowInvoiceModal(false)}
                  className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700"
                >
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Seller & Customer Details */}
            <div className="grid grid-cols-2 gap-4 text-xs text-gray-600 p-4 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-bold text-gray-900 text-sm">Suaaka E-Commerce Pvt Ltd</p>
                <p>Plot 42, Tech City, Meerut, UP - 250001</p>
                <p className="font-semibold text-gray-800 mt-1">GSTIN: 09AAACH7409R1ZZ</p>
                <p>HSN Code: 9983</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900 text-sm">Billed To: {order.shippingAddress?.fullName}</p>
                <p>{order.shippingAddress?.addressLine1}</p>
                <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.postalCode}</p>
                <p>Phone: {order.shippingAddress?.phone}</p>
                <p className="font-semibold text-gray-800 mt-1">Date: {order.createdAt ? format(new Date(order.createdAt), 'dd MMM yyyy') : 'N/A'}</p>
              </div>
            </div>

            {/* Table */}
            <table className="w-full text-xs">
              <thead className="border-b border-gray-200 text-gray-500 font-semibold">
                <tr>
                  <th className="text-left py-2">Item Description</th>
                  <th className="text-center py-2">Qty</th>
                  <th className="text-right py-2">Price</th>
                  <th className="text-right py-2">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {order.items?.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-2.5 font-medium">{item.name}</td>
                    <td className="py-2.5 text-center">{item.quantity}</td>
                    <td className="py-2.5 text-right">₹{Number(item.price).toLocaleString('en-IN')}</td>
                    <td className="py-2.5 text-right font-bold">₹{(item.price * item.quantity).toLocaleString('en-IN')}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* GST Summary */}
            <div className="border-t border-gray-200 pt-3 space-y-1.5 text-xs text-gray-600">
              <div className="flex justify-between">
                <span>Taxable Amount</span>
                <span>₹{(order.subtotal - (order.discount || 0)).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>CGST (9%)</span>
                <span>₹{(order.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>SGST (9%)</span>
                <span>₹{(order.tax / 2).toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping Charges</span>
                <span>{order.shippingCost === 0 ? 'FREE' : `₹${order.shippingCost}`}</span>
              </div>
              <div className="border-t border-gray-200 pt-2 flex justify-between text-base font-extrabold text-gray-900">
                <span>Grand Total (INR)</span>
                <span>₹{order.total?.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <p className="text-[10px] text-gray-400 text-center">
              This is a computer-generated tax invoice and does not require a physical signature.
            </p>
          </div>
        </div>
      )}

      {/* Multi-Target Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-lg font-bold text-gray-900">Rate & Review</h3>
              <button onClick={() => setShowReviewModal(false)} className="p-1 text-gray-400 hover:text-gray-700">
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Review Target Selector Tabs */}
            <div className="flex rounded-2xl bg-gray-100 p-1 gap-1">
              {[
                { key: 'product', label: '🛍️ Product' },
                { key: 'seller', label: '🏬 Seller' },
                { key: 'delivery', label: '🚚 Delivery Agent' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setReviewTab(tab.key)}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                    reviewTab === tab.key
                      ? 'bg-white text-brand-600 shadow-sm'
                      : 'text-gray-500 hover:text-gray-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              {/* Product selector if multiple items */}
              {reviewTab === 'product' && order.items?.length > 1 && (
                <div>
                  <label className="text-xs font-bold text-gray-700 block mb-1">Select Product to Review</label>
                  <select
                    value={selectedProductId}
                    onChange={(e) => setSelectedProductId(e.target.value)}
                    className="input-field text-xs"
                  >
                    {order.items.map((it) => (
                      <option key={it.product?._id || it.name} value={it.product?._id}>
                        {it.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Star Rating */}
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Rating</label>
                <div className="flex gap-1.5 text-amber-400">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button
                      type="button"
                      key={s}
                      onClick={() => setRating(s)}
                      className="p-1 focus:outline-none hover:scale-110 transition-transform"
                    >
                      <StarIcon className={`w-7 h-7 ${s <= rating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Review Title</label>
                <input
                  type="text"
                  placeholder="e.g. Excellent service & fast delivery"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="input-field text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Your Detailed Feedback</label>
                <textarea
                  placeholder={`Share your experience with this ${reviewTab}...`}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={3}
                  required
                  className="input-field text-xs resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submittingReview}
                  className="flex-1 py-2.5 rounded-xl btn-brand text-xs font-bold"
                >
                  {submittingReview ? 'Submitting...' : 'Submit Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancel Order Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Cancel Order #{order.orderNumber}?</h3>
            <p className="text-xs text-gray-500">
              Are you sure you want to cancel this order? This action cannot be reversed.
            </p>
            <textarea
              placeholder="Reason for cancellation (required)..."
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              rows={3}
              className="input-field text-xs resize-none"
            />
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowCancelModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Keep Order
              </button>
              <button
                onClick={() => {
                  if (!cancelReason.trim()) { toast.error('Please specify a cancellation reason'); return; }
                  cancelOrderMutation({ variables: { orderId: order._id, reason: cancelReason } });
                }}
                disabled={!cancelReason.trim() || cancelling}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 disabled:opacity-50"
              >
                {cancelling ? 'Cancelling...' : 'Yes, Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Request Return Modal */}
      {showReturnModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Request Return for #{order.orderNumber}</h3>
            <p className="text-xs text-gray-500">
              Please provide a reason for returning this order. Our team will review your request.
            </p>
            <textarea
              placeholder="Reason for return (required)..."
              value={returnReason}
              onChange={(e) => setReturnReason(e.target.value)}
              rows={3}
              className="input-field text-xs resize-none"
            />
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowReturnModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Close
              </button>
              <button
                onClick={() => {
                  requestReturnMutation({ variables: { orderId: order._id, reason: returnReason } });
                }}
                disabled={!returnReason.trim() || requestingReturn}
                className="flex-1 py-2.5 rounded-xl bg-orange-600 text-white text-xs font-bold hover:bg-orange-700 disabled:opacity-50"
              >
                {requestingReturn ? 'Submitting...' : 'Submit Request'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
