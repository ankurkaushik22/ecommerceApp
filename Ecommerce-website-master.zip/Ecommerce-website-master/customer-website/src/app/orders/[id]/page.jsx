'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation, useSubscription, gql } from '@apollo/client';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import {
  CheckCircleIcon, ClockIcon, TruckIcon,
  XCircleIcon, MapPinIcon, PhoneIcon, UserIcon,
  ArrowLeftIcon
} from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_ORDER } from '@/graphql/queries';
import { CANCEL_ORDER } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

const ORDER_SUBSCRIPTION = gql`
  subscription OnOrderStatusUpdated($orderId: ID!) {
    orderStatusUpdated(orderId: $orderId) {
      _id status paymentStatus trackingUpdates { status message timestamp location }
    }
  }
`;

const STEPS = [
  { key: 'pending', label: 'Order Placed', desc: 'We have received your order' },
  { key: 'confirmed', label: 'Order Confirmed', desc: 'Seller accepted the order' },
  { key: 'preparing', label: 'Preparing', desc: 'Item is being packed & prepared' },
  { key: 'dispatched', label: 'Dispatched', desc: 'Package left the fulfillment hub' },
  { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Courier agent is on the way' },
  { key: 'delivered', label: 'Delivered', desc: 'Delivered to your address' },
];

export default function OrderTrackingPage() {
  const params = useParams();
  const router = useRouter();
  const orderId = params?.id;

  const [cancelReason, setCancelReason] = useState('');
  const [showCancelModal, setShowCancelModal] = useState(false);

  const { data, loading, refetch } = useQuery(GET_ORDER, {
    variables: { id: orderId },
    skip: !orderId,
    fetchPolicy: 'cache-and-network',
  });

  // Listen to live subscription updates
  const { data: subData } = useSubscription(ORDER_SUBSCRIPTION, {
    variables: { orderId },
    skip: !orderId,
  });

  useEffect(() => {
    if (subData?.orderStatusUpdated) {
      toast.success(`Order status updated to: ${subData.orderStatusUpdated.status.replace(/_/g, ' ')}`);
      refetch();
    }
  }, [subData, refetch]);

  const [cancelOrderMutation, { loading: cancelling }] = useMutation(CANCEL_ORDER, {
    onCompleted: () => {
      toast.success('Order cancelled');
      setShowCancelModal(false);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const order = data?.getOrder;

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 space-y-6">
        <div className="h-48 bg-gray-100 rounded-3xl animate-pulse" />
        <div className="h-64 bg-gray-100 rounded-3xl animate-pulse" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-4xl">🔎</p>
        <h2 className="text-2xl font-bold text-gray-900">Order Not Found</h2>
        <button onClick={() => router.push('/orders')} className="btn-brand text-xs font-bold px-4 py-2">
          Back to Orders
        </button>
      </div>
    );
  }

  const currentStepIndex = STEPS.findIndex((s) => s.key === order.status);
  const isCancelled = order.status === 'cancelled';

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <button
            onClick={() => router.push('/orders')}
            className="flex items-center gap-1 text-xs text-gray-500 hover:text-brand-600 mb-2 font-semibold"
          >
            <ArrowLeftIcon className="w-3.5 h-3.5" /> Back to My Orders
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
              Order #{order.orderNumber}
            </h1>
            <span className="flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 bg-brand-50 text-brand-600 rounded-full border border-brand-200/60 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-brand-500" /> Live Tracking
            </span>
          </div>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Placed on {order.createdAt ? format(new Date(order.createdAt), 'MMMM d, yyyy · h:mm a') : '—'}
          </p>
        </div>

        {['pending', 'confirmed'].includes(order.status) && (
          <button
            onClick={() => setShowCancelModal(true)}
            className="px-4 py-2 border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-bold rounded-xl transition-colors self-start sm:self-auto"
          >
            Cancel Order
          </button>
        )}
      </div>

      {/* Stepper Status Timeline */}
      <div className="card p-6 sm:p-8 space-y-6">
        <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
          <TruckIcon className="w-6 h-6 text-brand-500" />
          <span>Delivery Progress</span>
        </h2>

        {isCancelled ? (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center gap-3 text-rose-800 text-sm">
            <XCircleIcon className="w-6 h-6 flex-shrink-0" />
            <div>
              <p className="font-bold">This order has been cancelled.</p>
              <p className="text-xs text-rose-600 mt-0.5">If you were charged, a refund will be processed back to your original payment method.</p>
            </div>
          </div>
        ) : (
          <div className="relative">
            {/* Desktop Horizontal Stepper */}
            <div className="hidden md:grid grid-cols-6 gap-2 text-center relative z-10">
              {STEPS.map((step, idx) => {
                const isPassed = currentStepIndex >= idx;
                const isCurrent = currentStepIndex === idx;

                return (
                  <div key={step.key} className="flex flex-col items-center space-y-2">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all shadow-md ${
                        isPassed
                          ? 'bg-brand-500 text-white shadow-brand-500/25'
                          : 'bg-gray-100 text-gray-400'
                      } ${isCurrent ? 'ring-4 ring-brand-100 scale-110' : ''}`}
                    >
                      {isPassed ? <CheckCircleIcon className="w-6 h-6" /> : idx + 1}
                    </div>
                    <span className={`text-xs font-bold ${isPassed ? 'text-gray-900' : 'text-gray-400'}`}>
                      {step.label}
                    </span>
                    <span className="text-[10px] text-gray-400 max-w-[100px] leading-tight">
                      {step.desc}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Mobile Vertical Stepper */}
            <div className="md:hidden space-y-6">
              {STEPS.map((step, idx) => {
                const isPassed = currentStepIndex >= idx;
                const isCurrent = currentStepIndex === idx;

                return (
                  <div key={step.key} className="flex items-start gap-4">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0 ${
                        isPassed ? 'bg-brand-500 text-white' : 'bg-gray-100 text-gray-400'
                      }`}
                    >
                      {isPassed ? <CheckCircleIcon className="w-5 h-5" /> : idx + 1}
                    </div>
                    <div>
                      <h4 className={`text-sm font-bold ${isPassed ? 'text-gray-900' : 'text-gray-400'}`}>
                        {step.label}
                      </h4>
                      <p className="text-xs text-gray-500 mt-0.5">{step.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Tracking Updates History */}
      {order.trackingUpdates?.length > 0 && (
        <div className="card p-6 space-y-4">
          <h3 className="font-bold text-gray-900 text-base">Live Activity Feed</h3>
          <div className="space-y-4">
            {[...order.trackingUpdates].reverse().map((update, idx) => (
              <div key={idx} className="flex items-start gap-3 text-xs">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-500 mt-1 flex-shrink-0 ring-4 ring-brand-100" />
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold uppercase tracking-wider text-gray-800">
                      {update.status?.replace(/_/g, ' ')}
                    </span>
                    <span className="text-gray-400">
                      {update.timestamp ? format(new Date(update.timestamp), 'MMM d, h:mm a') : ''}
                    </span>
                  </div>
                  <p className="text-gray-600 mt-0.5">{update.message}</p>
                  {update.location && (
                    <p className="text-brand-600 font-medium mt-0.5 flex items-center gap-1">
                      <MapPinIcon className="w-3.5 h-3.5" /> {update.location}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Grid: Delivery Agent & Shipping Address */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Delivery Partner */}
        <div className="card p-6 space-y-3">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <UserIcon className="w-4 h-4 text-brand-500" />
            <span>Delivery Agent</span>
          </h3>
          {order.deliveryBoy ? (
            <div className="flex items-center gap-4 p-3 bg-gray-50 rounded-xl">
              <div className="w-12 h-12 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-base">
                {order.deliveryBoy.name?.charAt(0)}
              </div>
              <div className="text-xs">
                <p className="font-bold text-gray-900 text-sm">{order.deliveryBoy.name}</p>
                <p className="text-gray-500 flex items-center gap-1 mt-0.5">
                  <PhoneIcon className="w-3.5 h-3.5 text-gray-400" /> {order.deliveryBoy.phone || 'Available via App'}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-xs text-gray-500">
              A delivery executive will be assigned once the package leaves the distribution center.
            </p>
          )}
        </div>

        {/* Shipping Address */}
        <div className="card p-6 space-y-2">
          <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
            <MapPinIcon className="w-4 h-4 text-brand-500" />
            <span>Shipping Destination</span>
          </h3>
          <div className="text-xs text-gray-600 space-y-0.5 pt-1">
            <p className="font-bold text-gray-900 text-sm">{order.shippingAddress?.fullName}</p>
            <p>{order.shippingAddress?.addressLine1} {order.shippingAddress?.addressLine2}</p>
            <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} {order.shippingAddress?.postalCode}</p>
            <p className="text-gray-400 pt-1">📞 {order.shippingAddress?.phone}</p>
          </div>
        </div>
      </div>

      {/* Items & Payment Breakdown */}
      <div className="card p-6 space-y-5">
        <h3 className="font-bold text-gray-900 text-base">Items in this Package</h3>
        <div className="divide-y divide-gray-100">
          {order.items?.map((item, idx) => (
            <div key={idx} className="py-3 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={item.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                  alt=""
                  className="w-14 h-14 object-cover rounded-xl border border-gray-100"
                />
                <div>
                  <h4 className="font-bold text-sm text-gray-900">{item.name}</h4>
                  {item.variantLabel && (
                    <span className="text-xs text-gray-500">{item.variantLabel}</span>
                  )}
                  <p className="text-xs text-gray-400 mt-0.5">
                    Qty: {item.quantity} × ${item.price?.toFixed(2)}
                  </p>
                </div>
              </div>
              <span className="font-extrabold text-sm text-gray-900">
                ${(item.price * item.quantity).toFixed(2)}
              </span>
            </div>
          ))}
        </div>

        {/* Pricing Totals */}
        <div className="border-t border-gray-100 pt-4 space-y-2 text-xs text-gray-600">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>${order.subtotal?.toFixed(2)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Discount</span>
              <span>-${order.discount?.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between">
            <span>Shipping</span>
            <span>{(order.shippingCost === 0 || !order.shippingCost) ? <span className="text-emerald-600 font-semibold">FREE</span> : `$${order.shippingCost.toFixed(2)}`}</span>
          </div>
          {order.tax > 0 && (
            <div className="flex justify-between">
              <span>Estimated Tax (8%)</span>
              <span>${order.tax.toFixed(2)}</span>
            </div>
          )}
          <div className="border-t border-gray-100 pt-2 flex justify-between text-base font-extrabold text-gray-900">
            <span>Total Paid ({order.paymentMethod?.toUpperCase()})</span>
            <span>${order.total?.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Cancel Order Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full space-y-4">
            <h3 className="text-lg font-bold text-gray-900">Cancel Order #{order.orderNumber}?</h3>
            <p className="text-xs text-gray-500">
              Are you sure you want to cancel this order? This action cannot be reversed.
            </p>
            <textarea
              placeholder="Reason for cancellation (required)..."
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              rows={3}
              className="input-field text-xs resize-none"
            />
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowCancelModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-xs font-semibold text-gray-700 hover:bg-gray-50"
              >
                Keep Order
              </button>
              <button
                onClick={() => {
                  if (!cancelReason.trim()) { toast.error('Please specify a cancellation reason'); return; }
                  cancelOrderMutation({ variables: { orderId: order._id, reason: cancelReason } });
                }}
                disabled={cancelling}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold disabled:opacity-50"
              >
                {cancelling ? 'Cancelling...' : 'Confirm Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
