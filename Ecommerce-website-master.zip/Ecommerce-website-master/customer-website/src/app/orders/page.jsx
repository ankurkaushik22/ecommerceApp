'use client';
import { useState, useMemo } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useQuery } from '@apollo/client';
import { format } from 'date-fns';
import {
  MagnifyingGlassIcon,
  AdjustmentsHorizontalIcon,
  XMarkIcon,
  ShoppingBagIcon,
  TruckIcon,
  ArrowRightIcon,
} from '@heroicons/react/24/outline';
import { GET_ORDERS } from '@/graphql/queries';
import { useAuthStore } from '@/store/authStore';

const STATUS_BADGES = {
  placed: 'bg-amber-100 text-amber-800',
  accepted: 'bg-blue-100 text-blue-800',
  pending: 'bg-amber-100 text-amber-800',
  confirmed: 'bg-blue-100 text-blue-800',
  processing: 'bg-indigo-100 text-indigo-800',
  ready_for_pickup: 'bg-purple-100 text-purple-800',
  picked_up: 'bg-purple-100 text-purple-800',
  dispatched: 'bg-purple-100 text-purple-800',
  out_for_delivery: 'bg-brand-100 text-brand-800',
  delivered: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-rose-100 text-rose-800',
  refunded: 'bg-rose-100 text-rose-800',
};

const TIME_FILTERS = [
  { key: 'all', label: 'All Time' },
  { key: '30_days', label: 'Last 30 days' },
  { key: '3_months', label: 'Past 3 months' },
  { key: '2026', label: '2026' },
  { key: '2025', label: '2025' },
  { key: '2024', label: '2024' },
];

const STATUS_FILTERS = [
  { key: 'all', label: 'All Orders' },
  { key: 'open', label: 'Open / In Transit' },
  { key: 'delivered', label: 'Delivered' },
  { key: 'cancelled', label: 'Cancelled / Returned' },
];

export default function OrdersPage() {
  const { isAuthenticated } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilterModal, setShowFilterModal] = useState(false);
  
  // Applied filters
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedTime, setSelectedTime] = useState('all');

  // Staged modal filters
  const [tempStatus, setTempStatus] = useState('all');
  const [tempTime, setTempTime] = useState('all');

  const { data, loading } = useQuery(GET_ORDERS, {
    variables: {
      pagination: { page: 1, limit: 50 },
    },
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const rawOrders = data?.getOrders?.orders || [];

  const filteredOrders = useMemo(() => {
    return rawOrders.filter((order) => {
      // 1. Status Filter
      if (selectedStatus === 'open') {
        const openStatuses = ['placed', 'accepted', 'pending', 'confirmed', 'processing', 'ready_for_pickup', 'picked_up', 'dispatched', 'out_for_delivery'];
        if (!openStatuses.includes(order.status)) return false;
      } else if (selectedStatus === 'delivered') {
        if (order.status !== 'delivered') return false;
      } else if (selectedStatus === 'cancelled') {
        if (!['cancelled', 'refunded'].includes(order.status)) return false;
      }

      // 2. Time Filter
      if (order.createdAt && selectedTime !== 'all') {
        const orderDate = new Date(order.createdAt);
        const now = new Date();
        if (selectedTime === '30_days') {
          const diffDays = (now - orderDate) / (1000 * 60 * 60 * 24);
          if (diffDays > 30 || diffDays < 0) return false;
        } else if (selectedTime === '3_months') {
          const diffDays = (now - orderDate) / (1000 * 60 * 60 * 24);
          if (diffDays > 90 || diffDays < 0) return false;
        } else if (/^\d{4}$/.test(selectedTime)) {
          if (orderDate.getFullYear() !== parseInt(selectedTime, 10)) return false;
        }
      }

      // 3. Search Query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const orderNo = (order.orderNumber || '').toLowerCase();
        const status = (order.status || '').toLowerCase();
        const hasItemMatch = (order.items || []).some((it) =>
          (it.name || '').toLowerCase().includes(q)
        );
        if (!orderNo.includes(q) && !status.includes(q) && !hasItemMatch) {
          return false;
        }
      }

      return true;
    });
  }, [rawOrders, selectedStatus, selectedTime, searchQuery]);

  const openModal = () => {
    setTempStatus(selectedStatus);
    setTempTime(selectedTime);
    setShowFilterModal(true);
  };

  const applyModalFilters = () => {
    setSelectedStatus(tempStatus);
    setSelectedTime(tempTime);
    setShowFilterModal(false);
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Sign in to View Your Orders</h2>
        <p className="text-gray-500">Track current shipments and view previous order history.</p>
        <Link href="/login?redirect=/orders" className="btn-brand inline-block text-sm">
          Sign In
        </Link>
      </div>
    );
  }

  const isFilterActive = selectedStatus !== 'all' || selectedTime !== 'all';

  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="border-b border-gray-200 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Orders</h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-1">
            Track status and view details of all your purchases
          </p>
        </div>
      </div>

      {/* Amazon-Style Search & Filter Bar */}
      <div className="flex items-center gap-3">
        {/* Search Input Box */}
        <div className="relative flex-1">
          <MagnifyingGlassIcon className="w-5 h-5 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search all orders"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 bg-white border border-gray-300 rounded-xl text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-500 shadow-2xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              <XMarkIcon className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Button */}
        <button
          onClick={openModal}
          className={"flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-bold transition-all shadow-2xs " + (
            isFilterActive
              ? "bg-brand-50 border-brand-500 text-brand-700 ring-2 ring-brand-500/20"
              : "bg-white border-gray-300 text-gray-700 hover:bg-gray-50"
          )}
        >
          <AdjustmentsHorizontalIcon className="w-4 h-4" />
          <span>Filter</span>
          <span className="text-gray-400">&gt;</span>
        </button>
      </div>

      {/* Active Filter Chips */}
      {isFilterActive && (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {selectedStatus !== 'all' && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-50 border border-brand-200 text-brand-700 rounded-lg text-xs font-semibold">
              Status: {STATUS_FILTERS.find((f) => f.key === selectedStatus)?.label}
              <button onClick={() => setSelectedStatus('all')}>
                <XMarkIcon className="w-3.5 h-3.5" />
              </button>
            </span>
          )}
          {selectedTime !== 'all' && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-50 border border-brand-200 text-brand-700 rounded-lg text-xs font-semibold">
              Time: {TIME_FILTERS.find((f) => f.key === selectedTime)?.label}
              <button onClick={() => setSelectedTime('all')}>
                <XMarkIcon className="w-3.5 h-3.5" />
              </button>
            </span>
          )}
          <button
            onClick={() => {
              setSelectedStatus('all');
              setSelectedTime('all');
            }}
            className="text-xs text-rose-600 font-bold hover:underline ml-1"
          >
            Clear All
          </button>
        </div>
      )}

      {/* Orders List */}
      <div className="space-y-4">
        {loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="card h-48 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 space-y-4 shadow-sm">
            <ShoppingBagIcon className="w-16 h-16 text-gray-300 mx-auto" />
            <h3 className="text-lg font-bold text-gray-900">
              {searchQuery || isFilterActive ? 'No matching orders found' : 'No orders found'}
            </h3>
            <p className="text-sm text-gray-500 max-w-sm mx-auto">
              {searchQuery || isFilterActive
                ? 'Try selecting a different year, status or resetting filters.'
                : 'Browse products to make your first purchase!'}
            </p>
            {searchQuery || isFilterActive ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedStatus('all');
                  setSelectedTime('all');
                }}
                className="btn-brand inline-block text-xs font-bold px-5 py-2.5"
              >
                Reset Filters
              </button>
            ) : (
              <Link href="/shop" className="btn-brand inline-block text-xs font-bold px-5 py-2.5">
                Browse Products
              </Link>
            )}
          </div>
        ) : (
          filteredOrders.map((order) => (
            <div
              key={order._id}
              className="card overflow-hidden bg-white border border-gray-100 hover:border-gray-200 transition-all rounded-2xl shadow-sm"
            >
              {/* Card Header */}
              <div className="bg-gray-50/70 p-4 sm:p-5 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-6">
                  <div>
                    <span className="text-gray-400 block font-medium">ORDER PLACED</span>
                    <span className="font-bold text-gray-800">
                      {order.createdAt ? format(new Date(order.createdAt), 'dd MMMM yyyy') : 'Recent'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block font-medium">TOTAL</span>
                    <span className="font-bold text-gray-800">
                      ₹{Number(order.total || 0).toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="hidden sm:block">
                    <span className="text-gray-400 block font-medium">SHIP TO</span>
                    <span className="font-bold text-gray-800 truncate max-w-[150px] block">
                      {order.shippingAddress?.fullName || 'Customer'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-mono text-gray-500 font-semibold">#{order.orderNumber}</span>
                  <span
                    className={"px-2.5 py-1 rounded-full font-bold uppercase tracking-wider text-[10px] " + (
                      STATUS_BADGES[order.status] || 'bg-gray-100 text-gray-800'
                    )}
                  >
                    {order.status?.replace(/_/g, ' ')}
                  </span>
                </div>
              </div>

              {/* Items List */}
              <div className="p-4 sm:p-5 divide-y divide-gray-100">
                {order.items?.map((item, idx) => (
                  <div key={idx} className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="relative w-16 h-16 rounded-xl overflow-hidden bg-gray-50 border border-gray-100 flex-shrink-0">
                        <img
                          src={item.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-gray-900 line-clamp-1">{item.name}</h4>
                        <p className="text-xs text-gray-500 mt-0.5">
                          Qty: {item.quantity} • ₹{Number(item.price || 0).toLocaleString('en-IN')} each
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Card Footer */}
              <div className="bg-gray-50/40 p-3 sm:p-4 border-t border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-brand-600 font-bold">
                  <TruckIcon className="w-4 h-4" />
                  <span>Tracking updates active</span>
                </div>
                <Link
                  href={"/orders/" + order._id}
                  className="btn-outline text-xs font-bold px-4 py-2 flex items-center gap-1 hover:bg-brand-50 hover:text-brand-600"
                >
                  View Order Details <ArrowRightIcon className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Filter Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3">
              <h3 className="text-lg font-bold text-gray-900">Filter Orders</h3>
              <button
                onClick={() => setShowFilterModal(false)}
                className="p-1 text-gray-400 hover:text-gray-700 rounded-lg"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-5">
              {/* Order Status */}
              <div>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2.5">
                  Order Status
                </h4>
                <div className="flex flex-wrap gap-2">
                  {STATUS_FILTERS.map((f) => (
                    <button
                      key={f.key}
                      onClick={() => setTempStatus(f.key)}
                      className={"px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all " + (
                        tempStatus === f.key
                          ? 'bg-brand-500 text-white shadow-sm'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      )}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Period */}
              <div>
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2.5">
                  Time Period
                </h4>
                <div className="flex flex-wrap gap-2">
                  {TIME_FILTERS.map((f) => (
                    <button
                      key={f.key}
                      onClick={() => setTempTime(f.key)}
                      className={"px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all " + (
                        tempTime === f.key
                          ? 'bg-brand-500 text-white shadow-sm'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      )}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-3 border-t border-gray-100">
              <button
                onClick={() => {
                  setTempStatus('all');
                  setTempTime('all');
                }}
                className="flex-1 py-2.5 border border-gray-300 text-gray-700 rounded-xl text-xs font-bold hover:bg-gray-50"
              >
                Reset
              </button>
              <button
                onClick={applyModalFilters}
                className="flex-1 py-2.5 bg-brand-500 hover:bg-brand-600 text-white rounded-xl text-xs font-bold shadow-sm"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
