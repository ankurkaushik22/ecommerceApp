'use client';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useQuery } from '@apollo/client';
import { format } from 'date-fns';
import { TruckIcon, ArrowRightIcon, ShoppingBagIcon } from '@heroicons/react/24/outline';
import { GET_ORDERS } from '@/graphql/queries';
import { useAuthStore } from '@/store/authStore';

const STATUS_TABS = ['all', 'pending', 'confirmed', 'dispatched', 'out_for_delivery', 'delivered', 'cancelled'];

const STATUS_BADGES = {
  pending: 'bg-amber-100 text-amber-800',
  confirmed: 'bg-blue-100 text-blue-800',
  preparing: 'bg-indigo-100 text-indigo-800',
  dispatched: 'bg-purple-100 text-purple-800',
  out_for_delivery: 'bg-brand-100 text-brand-800',
  delivered: 'bg-emerald-100 text-emerald-800',
  cancelled: 'bg-rose-100 text-rose-800',
};

export default function OrdersPage() {
  const { isAuthenticated } = useAuthStore();
  const [statusFilter, setStatusFilter] = useState('all');

  const { data, loading } = useQuery(GET_ORDERS, {
    variables: {
      status: statusFilter === 'all' ? undefined : statusFilter,
      pagination: { page: 1, limit: 20 },
    },
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Sign in to View Your Orders</h2>
        <p className="text-gray-500">Track current shipments and view previous order history.</p>
        <Link href="/login?redirect=/orders" className="btn-brand inline-block text-sm">
          Sign In
        </Link>
      </div>
    );
  }

  const orders = data?.getOrders?.orders || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="border-b border-gray-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Orders</h1>
        <p className="text-sm text-gray-500 mt-1">Track status and view details of all your purchases</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {STATUS_TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setStatusFilter(tab)}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
              statusFilter === tab
                ? 'bg-brand-500 text-white shadow-md shadow-brand-500/20'
                : 'bg-white text-gray-600 border border-gray-200 hover:border-brand-300'
            }`}
          >
            {tab.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Orders List */}
      <div className="space-y-4">
        {loading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="card h-48 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 space-y-4">
            <ShoppingBagIcon className="w-16 h-16 text-gray-300 mx-auto" />
            <h3 className="text-lg font-bold text-gray-900">No orders found</h3>
            <p className="text-sm text-gray-500">You have no orders in this status category.</p>
            <Link href="/products" className="btn-brand inline-block text-xs font-bold px-5 py-2.5">
              Browse Products
            </Link>
          </div>
        ) : (
          orders.map((order) => (
            <div
              key={order._id}
              className="card overflow-hidden bg-white border border-gray-100 hover:border-gray-200 transition-all rounded-2xl shadow-sm"
            >
              {/* Card Header */}
              <div className="bg-gray-50/70 p-4 sm:p-5 border-b border-gray-100 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-6">
                  <div>
                    <span className="text-gray-400 block">Order Placed</span>
                    <span className="font-bold text-gray-800">
                      {order.createdAt ? format(new Date(order.createdAt), 'MMMM d, yyyy') : '—'}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Total Amount</span>
                    <span className="font-bold text-gray-900">${order.total?.toFixed(2)}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Ship To</span>
                    <span className="font-bold text-gray-800">{order.shippingAddress?.fullName}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider ${STATUS_BADGES[order.status] || 'bg-gray-100 text-gray-800'}`}>
                    {order.status?.replace(/_/g, ' ')}
                  </span>
                  <Link
                    href={`/orders/${order._id}`}
                    className="flex items-center gap-1 font-bold text-brand-600 hover:text-brand-700"
                  >
                    <span>View Details</span>
                    <ArrowRightIcon className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>

              {/* Items in this order */}
              <div className="p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3 flex-wrap">
                  {order.items?.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 bg-gray-50 p-2 rounded-xl border border-gray-100">
                      <img
                        src={item.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=100'}
                        alt=""
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                      <div className="text-xs">
                        <p className="font-bold text-gray-900 line-clamp-1 max-w-[150px]">{item.name}</p>
                        <p className="text-gray-500">Qty: {item.quantity} × ${item.price?.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  <Link
                    href={`/orders/${order._id}`}
                    className="btn-brand text-xs font-bold py-2.5 px-4 flex items-center justify-center gap-1.5 w-full sm:w-auto shadow-sm"
                  >
                    <TruckIcon className="w-4 h-4" />
                    <span>Track Order</span>
                  </Link>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
