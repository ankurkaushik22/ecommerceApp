'use client';
import { useParams } from 'next/navigation';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import ProductCard from '@/components/shop/ProductCard';
import { GET_PRODUCTS, GET_ALL_CATEGORIES } from '@/graphql/queries';

export default function CategoryPage() {
  const params = useParams();
  const slug = params?.slug;

  const { data: allCatData } = useQuery(GET_ALL_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });
  const categories = allCatData?.getAllCategories || [];
  const currentCategory = categories.find(
    (c) => c.slug?.toLowerCase() === slug?.toLowerCase() || c._id === slug
  );

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { categoryId: currentCategory?._id },
      pagination: { page: 1, limit: 30 },
    },
    skip: !currentCategory?._id,
    fetchPolicy: 'cache-and-network',
  });

  const products = data?.getProducts?.products || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Category Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-gray-100 shadow-sm flex flex-col sm:flex-row items-center gap-6">
        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-brand-50 flex items-center justify-center text-4xl flex-shrink-0">
          {currentCategory?.icon || '🛍️'}
        </div>
        <div className="text-center sm:text-left space-y-1">
          <span className="text-xs uppercase font-bold tracking-wider text-brand-600">Category</span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">
            {currentCategory?.name || slug?.replace(/-/g, ' ')}
          </h1>
          <p className="text-sm text-gray-500 max-w-xl">
            {currentCategory?.description || `Explore our high quality selection in ${currentCategory?.name || 'this category'}.`}
          </p>
        </div>
      </div>

      {/* Subcategories if any */}
      {currentCategory?.children?.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-2">
          {currentCategory.children.map((sub) => (
            <Link
              key={sub._id}
              href={`/category/${sub.slug}`}
              className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 hover:border-brand-500 hover:text-brand-600 transition-colors whitespace-nowrap"
            >
              {sub.name}
            </Link>
          ))}
        </div>
      )}

      {/* Product List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-gray-900">Products in this Category</h2>
          <span className="text-xs text-gray-500">{products.length} found</span>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
            <p className="text-gray-500">No products found in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
