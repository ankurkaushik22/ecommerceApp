'use client';
import { useState, useMemo } from 'react';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MagnifyingGlassIcon,
  ShieldCheckIcon,
  StarIcon,
  ClockIcon,
  CalendarDaysIcon,
  CheckCircleIcon,
  WrenchScrewdriverIcon,
  XMarkIcon,
  ArrowRightIcon,
  PhoneIcon,
} from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';
import { GET_PRODUCTS, GET_STORE_SETTINGS } from '@/graphql/queries';
import { useCartStore } from '@/store/cartStore';
import toast from 'react-hot-toast';

const SERVICE_CATEGORIES = [
  { id: 'all', name: 'All Services', icon: '✨' },
  { id: 'ac', name: 'AC & Appliance Repair', icon: '❄️' },
  { id: 'cleaning', name: 'Full Home Cleaning', icon: '🧹' },
  { id: 'salon', name: "Women's Salon & Spa", icon: '💆‍♀️' },
  { id: 'electrician', name: 'Electrician & Plumber', icon: '⚡' },
  { id: 'painting', name: 'Painting & Woodwork', icon: '🎨' },
];

const TIME_SLOTS = [
  '09:00 AM - 11:00 AM',
  '11:00 AM - 01:00 PM',
  '02:00 PM - 04:00 PM',
  '04:00 PM - 06:00 PM',
  '06:00 PM - 08:00 PM',
];

const FALLBACK_SERVICES = [
  {
    _id: 'web-s-1',
    name: 'AC Power Foam Jet Deep Service',
    slug: 'ac-power-foam-jet-deep-service',
    price: 499,
    comparePrice: 799,
    serviceDuration: '45 mins',
    warranty: '30 Days Service Warranty',
    includedFeatures: [
      'High pressure water jet spray',
      'Foam wash on indoor cooling coils',
      'Outdoor unit dust and debris wash',
      'Gas leak & cooling check',
    ],
    images: ['https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800'],
    rating: { average: 4.8, count: 3200 },
    description: 'High-pressure water jet and chemical foam cleaning of cooling coil, blower, drain tray, and condenser.',
  },
  {
    _id: 'web-s-2',
    name: 'Complete Full Home Deep Cleaning',
    slug: 'complete-full-home-deep-cleaning',
    price: 1999,
    comparePrice: 2999,
    serviceDuration: '4 hours',
    warranty: '100% Quality Guarantee',
    includedFeatures: [
      'Kitchen chimney & countertop degreasing',
      'Bathroom tiles descaling & sanitization',
      'Floor buffing with single-disc machine',
      'Balcony & window grill wiping',
    ],
    images: ['https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=800'],
    rating: { average: 4.9, count: 2150 },
    description: 'Intensive mechanized cleaning including scrubbers, steam sterilization of kitchen tiles and bathroom de-scaling.',
  },
  {
    _id: 'web-s-3',
    name: 'O3+ Diamond Glow Facial & Waxing Package',
    slug: 'o3-diamond-glow-facial-waxing-package',
    price: 999,
    comparePrice: 1599,
    serviceDuration: '90 mins',
    warranty: '100% Sealed Single-Use Kits',
    includedFeatures: [
      'O3+ Diamond Brightening Facial',
      'Rica Waxing for Arms & Underarms',
      'Face Cleanup & Dead Skin Removal',
      'Relaxing 15-min Acupressure Massage',
    ],
    images: ['https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800'],
    rating: { average: 4.8, count: 4100 },
    description: 'Luxury salon service at home by verified female estheticians using single-use sealed kits.',
  },
  {
    _id: 'web-s-4',
    name: 'On-Demand Verified Electrician Inspection',
    slug: 'on-demand-verified-electrician-inspection',
    price: 199,
    comparePrice: 299,
    serviceDuration: '60 mins',
    warranty: '30 Days Post-Service Warranty',
    includedFeatures: [
      'Fault diagnosis & circuit testing',
      'Repair of up to 2 switchboards or sockets',
      'Earthing & voltage stability check',
      'Procurement assistance for ISI parts',
    ],
    images: ['https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=800'],
    rating: { average: 4.7, count: 1250 },
    description: 'Doorstep electrical diagnosis for short circuits, tripping MCBs, wiring faults, and switchboard repairs.',
  },
  {
    _id: 'web-s-5',
    name: 'Washing Machine Complete Repair & Servicing',
    slug: 'washing-machine-complete-repair-servicing',
    price: 349,
    comparePrice: 599,
    serviceDuration: '45 mins',
    warranty: '90 Days Spare Parts Warranty',
    includedFeatures: [
      'Motor & transmission belt inspection',
      'Drain pump & inlet valve descaling',
      'Shock absorber & balance ring check',
      'PCB electronic control board testing',
    ],
    images: ['https://images.unsplash.com/photo-1582735689369-4fe89db7114c?w=800'],
    rating: { average: 4.6, count: 880 },
    description: 'Comprehensive diagnostic check and repair for top-load and front-load washing machines.',
  },
];

export default function ServicesPage() {
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  // Booking Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [activeService, setActiveService] = useState(null);
  const [selectedDate, setSelectedDate] = useState('Today');
  const [selectedSlot, setSelectedSlot] = useState(TIME_SLOTS[0]);
  const [serviceAddress, setServiceAddress] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [bookingDetails, setBookingDetails] = useState(null);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;
  const bookingMode = storeSettings?.serviceBookingMode || 'call_now';
  const servicePhone = storeSettings?.serviceContactPhone || '+91 98765 43210';

  const handleServiceAction = (service) => {
    if (bookingMode === 'call_now') {
      const cleanPhone = servicePhone.replace(/[^\d+]/g, '');
      window.location.href = `tel:${cleanPhone}`;
    } else {
      openBookingModal(service);
    }
  };

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'services',
        search: search.trim() || undefined,
      },
      pagination: { page: 1, limit: 30 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products;
  const services = (rawProducts && rawProducts.length > 0) ? rawProducts : FALLBACK_SERVICES;

  const filteredServices = useMemo(() => {
    return services.filter((s) => {
      if (selectedCat !== 'all') {
        const q = selectedCat.toLowerCase();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesDesc = s.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) return false;
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = s.name.toLowerCase().includes(q);
        const matchesDesc = s.description?.toLowerCase().includes(q);
        if (!matchesName && !matchesDesc) return false;
      }
      return true;
    });
  }, [services, selectedCat, search]);

  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];
  if (disabledVerticals.includes('services')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <p className="text-6xl">🛠️</p>
        <h1 className="text-2xl font-bold text-gray-900">Home Services Currently Unavailable</h1>
        <Link href="/" className="btn-brand inline-block text-sm px-6 py-2.5 rounded-xl font-bold">
          Return to Home
        </Link>
      </div>
    );
  }

  const openBookingModal = (service) => {
    setActiveService(service);
    setSelectedDate('Today');
    setSelectedSlot(TIME_SLOTS[0]);
    setBookingSuccess(false);
    setBookingDetails(null);
    setModalOpen(true);
  };

  const handleConfirmBooking = () => {
    if (!activeService) return;

    const formattedDate = selectedDate === 'Today'
      ? new Date().toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' })
      : selectedDate === 'Tomorrow'
      ? new Date(Date.now() + 86400000).toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' })
      : new Date(Date.now() + 172800000).toLocaleDateString('en-IN', { weekday: 'short', month: 'short', day: 'numeric' });

    const bookingId = `SRV-${Math.floor(100000 + Math.random() * 900000)}`;

    setBookingDetails({
      id: bookingId,
      serviceName: activeService.name,
      price: activeService.price,
      date: `${selectedDate} (${formattedDate})`,
      timeSlot: selectedSlot,
      address: serviceAddress.trim() || 'Home Address (Default)',
      phone: contactPhone.trim() || 'Registered Mobile Number',
    });

    setBookingSuccess(true);
    toast.success(`🎉 Appointment booked for ${selectedDate} (${selectedSlot})!`);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20">
      {/* Services Hero Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white">
        <div className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-4 text-center md:text-left max-w-2xl">
              <div className="inline-flex items-center gap-2 bg-blue-600/30 border border-blue-400/30 px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider text-blue-300">
                <ShieldCheckIcon className="w-4 h-4 text-blue-400" />
                <span>SUAAKA VERIFIED • CERTIFIED EXPERTS</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-tight">
                Home Services at Your Doorstep
              </h1>
              <p className="text-slate-300 text-sm sm:text-base font-medium">
                AC repair, full home deep cleaning, salon for women, electricians & plumbers. Transparent pricing and 30-day warranty.
              </p>

              {/* 3 Value Pillars */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center">
                  <StarIconSolid className="w-5 h-5 text-amber-400 mx-auto" />
                  <p className="text-xs font-black text-white mt-1">4.8+ Rated</p>
                  <p className="text-[10px] text-slate-300">Certified Pros</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center">
                  <ShieldCheckIcon className="w-5 h-5 text-emerald-400 mx-auto" />
                  <p className="text-xs font-black text-white mt-1">30-Day</p>
                  <p className="text-[10px] text-slate-300">Service Warranty</p>
                </div>
                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center">
                  <span className="text-xl">💳</span>
                  <p className="text-xs font-black text-white mt-1">Fixed Upfront</p>
                  <p className="text-[10px] text-slate-300">No Hidden Fees</p>
                </div>
              </div>
            </div>

            {/* Right Hero Feature Card */}
            <div className="bg-white text-slate-900 rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-gray-100">
              <span className="text-xs font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                TRENDING NOW
              </span>
              <h3 className="text-xl font-extrabold mt-3">AC Power Foam Jet Clean</h3>
              <p className="text-xs text-slate-500 mt-1">2X deeper cooling & 30% power savings</p>
              <div className="flex items-baseline gap-2 mt-4">
                <span className="text-2xl font-black text-slate-900">₹499</span>
                <span className="text-sm text-slate-400 line-through">₹799</span>
                <span className="text-xs font-extrabold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">38% OFF</span>
              </div>
              <button
                onClick={() => handleServiceAction(services[0])}
                className={`w-full mt-5 text-white font-extrabold text-sm py-3 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-2 ${
                  bookingMode === 'call_now'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {bookingMode === 'call_now' ? (
                  <>
                    <PhoneIcon className="w-4 h-4" />
                    <span>Call Us Now</span>
                  </>
                ) : (
                  <>
                    <span>Book Slot Now</span>
                    <ArrowRightIcon className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Filter & Search Bar */}
      <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-xs">
        <div className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row items-center gap-4 justify-between">
          {/* Search Box */}
          <div className="relative w-full md:w-96">
            <MagnifyingGlassIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search for AC service, deep cleaning, salon..."
              className="w-full pl-10 pr-4 py-2 text-sm bg-gray-100/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all font-medium text-slate-800"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <XMarkIcon className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
            {SERVICE_CATEGORIES.map((cat) => {
              const isSelected = selectedCat === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCat(cat.id)}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex-shrink-0 ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white border border-gray-200 text-slate-600 hover:bg-gray-50'
                  }`}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Services List Container */}
      <div className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 mt-8 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black text-slate-900">
              Trending Service Packages ({filteredServices.length})
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Select any package to choose your preferred appointment date and time slot
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service) => (
            <div
              key={service._id}
              className="bg-white rounded-3xl p-5 border border-gray-200/90 hover:border-blue-300 hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      {service.rating?.average && (
                        <span className="flex items-center gap-1 text-[11px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                          <StarIconSolid className="w-3 h-3 text-emerald-600" />
                          <span>{service.rating.average.toFixed(1)}</span>
                          <span className="text-emerald-500 font-normal">({service.rating.count || 500}+)</span>
                        </span>
                      )}
                      {service.serviceDuration && (
                        <span className="flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          <ClockIcon className="w-3 h-3" />
                          <span>{service.serviceDuration}</span>
                        </span>
                      )}
                    </div>

                    <h3 className="text-lg font-extrabold text-slate-900 leading-snug pt-1">
                      {service.name}
                    </h3>
                  </div>

                  <img
                    src={service.images?.[0] || 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400'}
                    alt={service.name}
                    className="w-20 h-20 object-cover rounded-2xl bg-gray-100 flex-shrink-0"
                  />
                </div>

                {service.description && (
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed mt-2">
                    {service.description}
                  </p>
                )}

                {/* Included Features Checklist */}
                {service.includedFeatures && service.includedFeatures.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-gray-100 space-y-1.5">
                    <p className="text-[11px] font-extrabold text-slate-700 uppercase tracking-wider">What is included:</p>
                    {service.includedFeatures.map((feat, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-600 font-medium">
                        <CheckCircleIcon className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                        <span className="truncate">{feat}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Pricing & Booking Button */}
              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between">
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-black text-slate-900">₹{service.price}</span>
                    {service.comparePrice > service.price && (
                      <span className="text-xs text-slate-400 line-through">₹{service.comparePrice}</span>
                    )}
                  </div>
                  {service.warranty && (
                    <span className="text-[11px] font-bold text-blue-600 block">
                      🛡️ {service.warranty}
                    </span>
                  )}
                </div>

                <button
                  onClick={() => handleServiceAction(service)}
                  className={`text-white font-extrabold text-xs px-5 py-2.5 rounded-xl shadow-md hover:shadow-lg transition-all active:scale-95 flex items-center gap-1.5 ${
                    bookingMode === 'call_now'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {bookingMode === 'call_now' ? (
                    <>
                      <PhoneIcon className="w-4 h-4" />
                      <span>Call Now</span>
                    </>
                  ) : (
                    <>
                      <CalendarDaysIcon className="w-4 h-4" />
                      <span>Book Slot</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Appointment Slot Modal */}
      <AnimatePresence>
        {modalOpen && activeService && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100"
            >
            <div className="p-6 border-b border-gray-100 flex items-start justify-between">
              <div>
                <span className="text-xs font-black text-blue-600 uppercase tracking-wider">
                  {bookingSuccess ? 'BOOKING STATUS' : 'BOOK APPOINTMENT'}
                </span>
                <h3 className="text-xl font-extrabold text-slate-900 mt-1">
                  {activeService.name}
                </h3>
                <p className="text-xs text-slate-500 font-medium">Duration: {activeService.serviceDuration || '45 mins'}</p>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1.5 text-gray-400 hover:text-gray-700 rounded-xl hover:bg-gray-100 transition-colors"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            {bookingSuccess && bookingDetails ? (
              <div className="p-6 text-center space-y-5">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircleIcon className="w-10 h-10" />
                </div>

                <div>
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                    APPOINTMENT CONFIRMED
                  </span>
                  <h3 className="text-2xl font-black text-slate-900 mt-2">
                    Service Booked Successfully!
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 font-medium">
                    Booking Reference: <span className="font-mono font-bold text-slate-900">#{bookingDetails.id}</span>
                  </p>
                </div>

                {/* Booking Summary Box */}
                <div className="bg-slate-50 rounded-2xl p-4 text-left border border-gray-200/80 space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Service:</span>
                    <span className="font-bold text-slate-900 text-right max-w-[220px] truncate">{bookingDetails.serviceName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Scheduled Date:</span>
                    <span className="font-bold text-slate-900">{bookingDetails.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Arrival Slot:</span>
                    <span className="font-bold text-slate-900">{bookingDetails.timeSlot}</span>
                  </div>
                  <div className="flex justify-between border-t border-gray-200/60 pt-2">
                    <span className="text-slate-500 font-medium">Amount to Pay:</span>
                    <span className="font-black text-sm text-slate-900">₹{bookingDetails.price}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Payment Mode:</span>
                    <span className="font-bold text-emerald-600">Pay after service (Cash / UPI)</span>
                  </div>
                </div>

                {/* Technician Note */}
                <div className="bg-blue-50 rounded-xl p-3.5 text-left border border-blue-100 flex items-start gap-2.5">
                  <ShieldCheckIcon className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-950 leading-relaxed font-medium">
                    Our verified service expert has been assigned. You will receive an arrival call 30 minutes before your chosen time slot.
                  </p>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => setModalOpen(false)}
                    className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs py-3 rounded-xl transition-all shadow-md cursor-pointer"
                  >
                    Done
                  </button>
                  <Link
                    href="/orders"
                    onClick={() => setModalOpen(false)}
                    className="flex-1 bg-white hover:bg-slate-50 border border-gray-300 text-slate-700 font-extrabold text-xs py-3 rounded-xl transition-all text-center"
                  >
                    View My Bookings
                  </Link>
                </div>
              </div>
            ) : (
              <>
                <div className="p-6 space-y-5 max-h-[65vh] overflow-y-auto">
                  {/* Step 1: Date */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2.5">
                      1. Select Service Date
                    </label>
                    <div className="grid grid-cols-3 gap-3">
                      {['Today', 'Tomorrow', 'Day After'].map((d) => {
                        const isSelected = selectedDate === d;
                        return (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setSelectedDate(d)}
                            className={`py-3 rounded-2xl border text-xs font-extrabold transition-all flex flex-col items-center justify-center gap-1 ${
                              isSelected
                                ? 'bg-blue-50 border-blue-600 text-blue-700 ring-2 ring-blue-500/20 shadow-xs'
                                : 'bg-slate-50 border-gray-200 text-slate-600 hover:border-gray-300'
                            }`}
                          >
                            <CalendarDaysIcon className="w-4 h-4" />
                            <span>{d}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 2: Time Slots */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2.5">
                      2. Select Arrival Time Slot
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {TIME_SLOTS.map((slot) => {
                        const isSelected = selectedSlot === slot;
                        return (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => setSelectedSlot(slot)}
                            className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all text-left flex items-center justify-between ${
                              isSelected
                                ? 'bg-blue-50 border-blue-600 text-blue-700 shadow-xs'
                                : 'bg-slate-50 border-gray-200 text-slate-600 hover:bg-gray-100'
                            }`}
                          >
                            <span>{slot}</span>
                            {isSelected && <CheckCircleIcon className="w-4 h-4 text-blue-600" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Step 3: Address & Contact */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-slate-700 mb-2">
                      3. Service Address & Phone
                    </label>
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={serviceAddress}
                        onChange={(e) => setServiceAddress(e.target.value)}
                        placeholder="House / Flat No, Street, Landmark"
                        className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all font-medium text-slate-800"
                      />
                      <input
                        type="tel"
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        placeholder="Contact Mobile Number (e.g. 9876543210)"
                        className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all font-medium text-slate-800"
                      />
                    </div>
                  </div>

                  {/* Assurance Note */}
                  <div className="bg-blue-50/70 rounded-2xl p-3.5 border border-blue-100 text-xs text-blue-900 space-y-1">
                    <p className="font-bold flex items-center gap-1.5">
                      <ShieldCheckIcon className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      <span>Verified Professional Assigned</span>
                    </p>
                    <p className="text-blue-700 pl-5 text-[11px]">
                      Pay after service is completed to your satisfaction. Includes 30-Day Service Warranty.
                    </p>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="p-5 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-slate-400 font-medium block">Total Payable</span>
                    <p className="text-xl font-black text-slate-900">₹{activeService.price}</p>
                    <span className="text-[10px] text-emerald-600 font-bold block">Pay after service</span>
                  </div>
                  <button
                    onClick={handleConfirmBooking}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-sm px-6 py-3 rounded-2xl shadow-lg hover:shadow-xl transition-all flex items-center gap-2 cursor-pointer"
                  >
                    <span>Book Appointment</span>
                    <ArrowRightIcon className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
