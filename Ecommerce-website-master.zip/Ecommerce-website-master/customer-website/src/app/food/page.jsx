'use client';
import { useState, useMemo, useRef } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import Link from 'next/link';
import Image from 'next/image';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MagnifyingGlassIcon,
  SparklesIcon,
  FireIcon,
  ClockIcon,
  StarIcon,
  ShoppingBagIcon,
  CheckIcon,
  PlusIcon,
  MinusIcon,
  XMarkIcon,
  MapPinIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { GET_PRODUCTS, GET_STORE_SETTINGS, GET_CART, GET_CATEGORIES, GET_ORDERS } from '@/graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM, REMOVE_FROM_CART } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import HeroBanner from '@/components/shop/HeroBanner';
import { filterItemsByVertical } from '@/utils/cartHelpers';
const isCookingInstructionDisabled = (dish) => {
  if (!dish) return false;
  if (dish.allowCookingInstructions === false || dish.hideCookingInstructions === true) return true;

  const name = (dish.name || '').toLowerCase();
  const cat = typeof dish.category === 'string' ? dish.category.toLowerCase() : (dish.category?.name || '').toLowerCase();
  const subcat = typeof dish.subcategory === 'string' ? dish.subcategory.toLowerCase() : (dish.subcategory?.name || '').toLowerCase();
  const cuisineStr = Array.isArray(dish.cuisine) ? dish.cuisine.join(' ').toLowerCase() : (dish.cuisine || '').toLowerCase();
  const tagsStr = Array.isArray(dish.tags) ? dish.tags.join(' ').toLowerCase() : '';

  const keywords = [
    'sweet', 'petha', 'mithai', 'dessert', 'halwa', 'ladoo', 'laddu', 'barfi', 'burfi',
    'gulab jamun', 'rasgulla', 'kaju katli', 'jalebi', 'ice cream', 'beverage', 'drink',
    'shake', 'cold drink', 'soda', 'bakery', 'cake', 'pastry'
  ];

  return keywords.some(kw => name.includes(kw) || cat.includes(kw) || subcat.includes(kw) || cuisineStr.includes(kw) || tagsStr.includes(kw));
};

const CUISINES = [
  {
    id: 'all',
    name: 'All Cuisines',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
  },
  {
    id: 'biryani',
    name: 'Biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=300',
  },
  {
    id: 'north-indian',
    name: 'North Indian',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=300',
  },
  {
    id: 'pizza',
    name: 'Pizzas',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300',
  },
  {
    id: 'burger',
    name: 'Burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300',
  },
  {
    id: 'chinese',
    name: 'Momos & Chinese',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=300',
  },
  {
    id: 'dessert',
    name: 'Desserts & Shakes',
    image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=300',
  },
  {
    id: 'rolls',
    name: 'Rolls & Wraps',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=300',
  },
];

const FEATURED_RESTAURANTS = [
  {
    id: 'r1',
    name: 'Behrouz Royal Biryani',
    cuisines: 'Biryani, Mughlai, Kebabs',
    cuisineTags: ['biryani', 'mughlai', 'kebabs', 'north indian', 'hyderabadi'],
    rating: 4.6,
    time: '25-30 mins',
    prepMinutes: 28,
    price: '₹350 for two',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r2',
    name: "La Pino'z Pizza",
    cuisines: 'Pizzas, Garlic Bread, Pastas',
    cuisineTags: ['pizza', 'pizzas', 'italian', 'pasta', 'fast food', 'garlic bread'],
    rating: 4.4,
    time: '20-25 mins',
    prepMinutes: 22,
    price: '₹300 for two',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r3',
    name: 'The Burger Club',
    cuisines: 'Burgers, American, Shakes',
    cuisineTags: ['burger', 'burgers', 'american', 'shakes', 'fast food'],
    rating: 4.5,
    time: '15-20 mins',
    prepMinutes: 18,
    price: '₹250 for two',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r4',
    name: 'Punjab Grill Express',
    cuisines: 'North Indian, Dal Makhani, Paneer Tikka',
    cuisineTags: ['north indian', 'curry', 'punjabi', 'paneer', 'thali', 'indian', 'dal makhani'],
    rating: 4.7,
    time: '20-25 mins',
    prepMinutes: 20,
    price: '₹320 for two',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=600',
    isVeg: true,
    hasDeals: true,
  },
  {
    id: 'r5',
    name: 'Wow! Momo Magic',
    cuisines: 'Momos, Chinese, Tibetan, Snacks',
    cuisineTags: ['chinese', 'momos', 'momo', 'tibetan', 'asian', 'noodles', 'dimsum'],
    rating: 4.5,
    time: '15-20 mins',
    prepMinutes: 15,
    price: '₹200 for two',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=600',
    isVeg: false,
    hasDeals: true,
  },
  {
    id: 'r6',
    name: 'Rolls Mania Express',
    cuisines: 'Kathi Rolls, Wraps, Fast Food',
    cuisineTags: ['rolls & wraps', 'rolls', 'wraps', 'kathi', 'rolls mania', 'fast food'],
    rating: 4.6,
    time: '15-20 mins',
    prepMinutes: 15,
    price: '₹180 for two',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600',
    isVeg: false,
    hasDeals: true,
  },
];

const FALLBACK_DISHES = [
  {
    _id: 'web-f-1',
    name: 'Hyderabadi Chicken Dum Biryani',
    slug: 'hyderabadi-chicken-dum-biryani',
    restaurantName: 'Behrouz Royal Biryani',
    cuisine: ['Biryani', 'Hyderabadi', 'Mughlai'],
    price: 349,
    comparePrice: 429,
    isVeg: false,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800'],
    rating: { average: 4.6, count: 1420 },
    description: 'Authentic dum cooked long grain basmati rice layered with aromatic spices and tender bone-in chicken.',
    addons: [
      { name: 'Extra Salan & Raita', price: 30, icon: '🥣' },
      { name: 'Extra Boiled Egg', price: 20, icon: '🥚' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-1b',
    name: 'Royal Awadhi Veg Dum Biryani',
    slug: 'royal-awadhi-veg-dum-biryani',
    restaurantName: 'Behrouz Royal Biryani',
    cuisine: ['Biryani', 'Mughlai', 'Veg'],
    price: 279,
    comparePrice: 349,
    isVeg: true,
    preparationTime: 20,
    images: ['https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=800'],
    rating: { average: 4.5, count: 860 },
    description: 'Fragrant saffron basmati rice layered with garden fresh vegetables, paneer cubes and golden fried onions.',
    addons: [
      { name: 'Extra Salan & Raita', price: 30, icon: '🥣' },
      { name: 'Extra Paneer Cubes', price: 40, icon: '🧀' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-2',
    name: 'Paneer Tikka Butter Masala',
    slug: 'paneer-tikka-butter-masala',
    restaurantName: 'Punjab Grill Express',
    cuisine: ['North Indian', 'Curry', 'Punjabi'],
    price: 289,
    comparePrice: 349,
    isVeg: true,
    preparationTime: 20,
    images: ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800'],
    rating: { average: 4.5, count: 890 },
    description: 'Tandoori cottage cheese cubes simmered in a rich tomato, cashew nut and butter gravy.',
    addons: [
      { name: 'Extra Butter Naan', price: 40, icon: '🫓' },
      { name: 'Jeera Rice Cup', price: 60, icon: '🍚' },
      { name: 'Extra Amul Butter', price: 20, icon: '🧈' },
    ],
  },
  {
    _id: 'web-f-2b',
    name: 'Slow Cooked Dal Makhani with 2 Naan',
    slug: 'slow-cooked-dal-makhani-with-naan',
    restaurantName: 'Punjab Grill Express',
    cuisine: ['North Indian', 'Punjabi', 'Thali'],
    price: 249,
    comparePrice: 299,
    isVeg: true,
    preparationTime: 20,
    images: ['https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800'],
    rating: { average: 4.7, count: 1250 },
    description: 'Overnight simmered black lentils finished with fresh cream and white butter, served with crisp butter naan.',
    addons: [
      { name: 'Extra Butter Naan', price: 40, icon: '🫓' },
      { name: 'Extra White Butter', price: 25, icon: '🧈' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-3',
    name: 'Farmhouse Loaded Italian Pizza',
    slug: 'farmhouse-loaded-italian-pizza',
    restaurantName: "La Pino'z Pizza",
    cuisine: ['Pizza', 'Italian', 'Continental'],
    price: 379,
    comparePrice: 499,
    isVeg: true,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800'],
    rating: { average: 4.4, count: 750 },
    description: 'Crisp hand-stretched crust topped with marinara, mozzarella, bell peppers, sweet corn and black olives.',
    addons: [
      { name: 'Extra Mozzarella Cheese', price: 45, icon: '🧀' },
      { name: 'Garlic Dip', price: 25, icon: '🧄' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-3b',
    name: 'Fiery BBQ Chicken & Jalapeno Pizza',
    slug: 'fiery-bbq-chicken-jalapeno-pizza',
    restaurantName: "La Pino'z Pizza",
    cuisine: ['Pizza', 'Italian', 'Fast Food'],
    price: 429,
    comparePrice: 549,
    isVeg: false,
    preparationTime: 25,
    images: ['https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800'],
    rating: { average: 4.6, count: 910 },
    description: 'Smoky BBQ glazed chicken chunks, spicy jalapenos, red onions and mozzarella cheese.',
    addons: [
      { name: 'Extra Mozzarella Cheese', price: 45, icon: '🧀' },
      { name: 'Extra BBQ Chicken Chunks', price: 60, icon: '🍗' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-4',
    name: 'Crispy Double Patty Chicken Burger',
    slug: 'crispy-double-patty-chicken-burger',
    restaurantName: 'The Burger Club',
    cuisine: ['Burger', 'American', 'Fast Food'],
    price: 219,
    comparePrice: 279,
    isVeg: false,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800'],
    rating: { average: 4.5, count: 1100 },
    description: 'Two golden fried chicken fillets with smoky chipotle mayo, crunchy lettuce on toasted brioche bun.',
    addons: [
      { name: 'Cheddar Cheese Slice', price: 30, icon: '🧀' },
      { name: 'Crispy Peri Peri Fries', price: 59, icon: '🍟' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-4b',
    name: 'Crunchy Veggie Supreme Cheesy Burger',
    slug: 'crunchy-veggie-supreme-cheesy-burger',
    restaurantName: 'The Burger Club',
    cuisine: ['Burger', 'Fast Food', 'Snacks'],
    price: 159,
    comparePrice: 199,
    isVeg: true,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1550547660-d9450f859349?w=800'],
    rating: { average: 4.4, count: 680 },
    description: 'Herbed potato-corn patty layered with cheddar cheese slice, fresh tomato and thousand island dressing.',
    addons: [
      { name: 'Cheddar Cheese Slice', price: 30, icon: '🧀' },
      { name: 'Crispy Salted Fries', price: 49, icon: '🍟' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-5',
    name: 'Steamed Himalayan Veg Darjeeling Momos',
    slug: 'steamed-himalayan-veg-darjeeling-momos',
    restaurantName: 'Wow! Momo Magic',
    cuisine: ['Chinese', 'Momos', 'Tibetan'],
    price: 139,
    comparePrice: 179,
    isVeg: true,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=800'],
    rating: { average: 4.3, count: 620 },
    description: 'Thin wrapper dumplings packed with minced vegetables, served with fiery red chili dipping chutney.',
    addons: [
      { name: 'Extra Schezwan Chutney', price: 20, icon: '🌶️' },
      { name: 'Mayonnaise Dip', price: 20, icon: '🥣' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-5b',
    name: 'Crispy Pan-Fried Chicken Momos (6 Pcs)',
    slug: 'crispy-pan-fried-chicken-momos',
    restaurantName: 'Wow! Momo Magic',
    cuisine: ['Chinese', 'Momos', 'Snacks'],
    price: 179,
    comparePrice: 219,
    isVeg: false,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800'],
    rating: { average: 4.6, count: 830 },
    description: 'Crispy golden pan-fried dumplings filled with spiced minced chicken, tossed in hot garlic sauce.',
    addons: [
      { name: 'Extra Schezwan Chutney', price: 20, icon: '🌶️' },
      { name: 'Mayonnaise Dip', price: 20, icon: '🥣' },
      { name: 'Cold Drink 250ml', price: 45, icon: '🥤' },
    ],
  },
  {
    _id: 'web-f-6',
    name: 'Belgian Dark Chocolate Thick Shake',
    slug: 'belgian-dark-chocolate-thick-shake',
    restaurantName: 'Keventers Thick Shakes',
    cuisine: ['Desserts', 'Shakes', 'Beverages'],
    price: 199,
    comparePrice: 249,
    isVeg: true,
    preparationTime: 10,
    images: ['https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=800'],
    rating: { average: 4.7, count: 530 },
    description: 'Rich and creamy thick shake blended with imported Belgian cocoa and dark chocolate fudge.',
    addons: [
      { name: 'Extra Vanilla Scoop', price: 40, icon: '🍨' },
      { name: 'Extra Roasted Nuts', price: 30, icon: '🥜' },
    ],
  },
  {
    _id: 'web-f-6b',
    name: 'Warm Gulab Jamun with Kesar Rabri',
    slug: 'warm-gulab-jamun-with-kesar-rabri',
    restaurantName: 'Mithai Mahal',
    cuisine: ['Desserts', 'Sweets', 'North Indian'],
    price: 149,
    comparePrice: 189,
    isVeg: true,
    preparationTime: 10,
    images: ['https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=800'],
    rating: { average: 4.8, count: 640 },
    description: 'Soft khoya dumplings soaked in rose-cardamom syrup, served over thick saffron malai rabri.',
  },
  {
    _id: 'web-f-7',
    name: 'Kolkata Double Egg Chicken Kathi Roll',
    slug: 'kolkata-double-egg-chicken-kathi-roll',
    restaurantName: 'Rolls Mania Express',
    cuisine: ['Rolls & Wraps', 'Fast Food', 'Street Food'],
    price: 169,
    comparePrice: 219,
    isVeg: false,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800'],
    rating: { average: 4.6, count: 970 },
    description: 'Flaky lachha paratha layered with double egg, spiced grilled chicken tikka cubes, crunchy onions and tangy chutney.',
  },
  {
    _id: 'web-f-8',
    name: 'Smoky Paneer Tikka Kathi Wrap',
    slug: 'smoky-paneer-tikka-kathi-wrap',
    restaurantName: 'Rolls Mania Express',
    cuisine: ['Rolls & Wraps', 'North Indian', 'Snacks'],
    price: 149,
    comparePrice: 189,
    isVeg: true,
    preparationTime: 15,
    images: ['https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800'],
    rating: { average: 4.5, count: 740 },
    description: 'Grilled tandoori paneer slices rolled in a toasted wheat paratha with mint-coriander mayonnaise.',
  },
];



export default function FoodPage() {
  const [search, setSearch] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState('all');
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [isVegOnly, setIsVegOnly] = useState(false);
  const [activeTab, setActiveTab] = useState('all'); // all, rating, fast, offers
  const dishesRef = useRef(null);

  const [customizingDish, setCustomizingDish] = useState(null);
  const [selectedVariantOption, setSelectedVariantOption] = useState(null);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [itemInstructions, setItemInstructions] = useState('');
  const [hideInstructionsLocal, setHideInstructionsLocal] = useState(false);

  const { isAuthenticated } = useAuthStore();
  const {
    items: localCartItems,
    addItem: addItemLocal,
    updateQuantity: updateQuantityLocal,
    removeItem: removeItemLocal,
    openCart,
  } = useCartStore();

  const { data: categoriesData, loading: categoriesLoading } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'food' },
    fetchPolicy: 'cache-and-network',
  });

  const dynamicCategories = categoriesData?.getCategories || [];

  const dynamicCuisines = useMemo(() => {
    const allTab = {
      id: 'all',
      name: 'All Cuisines',
      image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300',
    };

    // Don't fall back to static CUISINES while loading — return empty to show skeleton
    if (!dynamicCategories || dynamicCategories.length === 0) {
      return [];
    }

    const fetchedTabs = dynamicCategories.map((cat) => {
      const fallbackMatch = CUISINES.find(
        (c) => c.name.toLowerCase() === cat.name.toLowerCase() || c.id === cat.slug
      );
      const fallbackImage = cat.image
        || fallbackMatch?.image
        || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300';

      return {
        id: cat.slug || cat._id,
        _id: cat._id,
        slug: cat.slug,
        name: cat.name,
        children: cat.children || [],
        image: fallbackImage,
      };
    });

    return [allTab, ...fetchedTabs];
  }, [dynamicCategories]);

  const { data: ordersData } = useQuery(GET_ORDERS, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const pastOrderedNames = useMemo(() => {
    const ordersList = ordersData?.getOrders?.orders || ordersData?.getOrders || [];
    if (!Array.isArray(ordersList)) return new Set();
    const names = new Set();
    ordersList.forEach((order) => {
      (order.items || []).forEach((item) => {
        if (item.name) names.add(item.name.toLowerCase().trim());
        if (item.product?.name) names.add(item.product.name.toLowerCase().trim());
      });
    });
    return names;
  }, [ordersData]);

  const { data: cartData, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [addToCartMutation] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      refetchCart();
    },
    onError: (err) => console.error('addToCart error:', err),
  });

  const [updateCartItemMutation] = useMutation(UPDATE_CART_ITEM, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('updateCartItem error:', err),
  });

  const [removeFromCartMutation] = useMutation(REMOVE_FROM_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('removeFromCart error:', err),
  });

  const serverCartItems = cartData?.getCart?.items || [];
  const currentCartItems = isAuthenticated && serverCartItems.length > 0
    ? serverCartItems
    : (localCartItems.length > 0 ? localCartItems : serverCartItems);

  const foodCartItems = filterItemsByVertical(currentCartItems || [], 'food');
  const totalFoodItems = foodCartItems.reduce((sum, i) => sum + (i.quantity || 1), 0);
  const totalFoodAmount = foodCartItems.reduce((sum, i) => sum + (Number(i.price || i.product?.price || 0) * Number(i.quantity || 1)), 0);

  const getCartItem = (dishId) => {
    return currentCartItems.find(
      (item) => (item.product?._id || item.product?.id || item.product || item.productId || item._id) === dishId
    );
  };

  const getItemQuantity = (dishId) => {
    const item = getCartItem(dishId);
    return item ? item.quantity : 0;
  };

  const handleOpenCustomization = (dish) => {
    setCustomizingDish(dish);
    setSelectedAddons([]);
    setItemInstructions('');
  };

  const handleAddCustomized = () => {
    if (!customizingDish) return;
    const dish = customizingDish;
    const currentBasePrice = selectedVariantOption ? selectedVariantOption.price : dish.price;
    const addonTotal = selectedAddons.reduce((sum, a) => sum + a.price, 0);
    const finalPrice = currentBasePrice + addonTotal;
    const variantLabel = selectedVariantOption ? (selectedVariantOption.label || selectedVariantOption.name) : undefined;

    // Immediately close modal and reset customization state
    setCustomizingDish(null);
    setSelectedAddons([]);
    setItemInstructions('');
    setSelectedVariantOption(null);
    setHideInstructionsLocal(false);

    try {
      const isMongoId = /^[0-9a-fA-F]{24}$/.test(dish._id);
      if (isAuthenticated && isMongoId) {
        addToCartMutation({
          variables: {
            input: {
              productId: dish._id,
              quantity: 1,
              variantIndex: selectedVariantOption?.variantIndex ?? -1,
              variantLabel: variantLabel,
              addons: selectedAddons.map((a) => ({ name: a.name, price: a.price, icon: a.icon || '' })),
              instructions: itemInstructions,
              customPrice: finalPrice,
            },
          },
        }).catch((err) => console.error('addToCart error:', err));
      } else {
        const customizedProduct = {
          ...dish,
          price: finalPrice,
          variantLabel: variantLabel,
          addons: selectedAddons,
          instructions: itemInstructions,
          vertical: 'food',
        };
        addItemLocal(customizedProduct, 1);
      }

      toast.success(`Added ${dish.name} to cart!`);
      openCart();
    } catch (err) {
      console.error('handleAddCustomized error:', err);
      toast.error('Could not add item to cart');
    }
  };

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: {
        vertical: 'food',
        search: search.trim() || undefined,
        isVeg: isVegOnly ? true : undefined,
      },
      pagination: { page: 1, limit: 30 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products;
  const dishes = (rawProducts && rawProducts.length > 0) ? rawProducts : FALLBACK_DISHES;

  const filteredDishes = useMemo(() => {
    const activeCuisineObj = dynamicCuisines.find(
      (c) => c.id === selectedCuisine || c.slug === selectedCuisine || c._id === selectedCuisine || c.name === selectedCuisine
    );

    return dishes.filter((item) => {
      if (isVegOnly && !item.isVeg) return false;

      if (selectedCuisine !== 'all') {
        const catId = item.category?._id?.toString();
        const catSlug = item.category?.slug?.toLowerCase();
        const catName = item.category?.name?.toLowerCase();

        const subcatId = item.subcategory?._id?.toString();
        const subcatSlug = item.subcategory?.slug?.toLowerCase();
        const subcatName = item.subcategory?.name?.toLowerCase();

        const parentCatId = (item.category?.parent?._id || item.category?.parent)?.toString();
        const parentCatSlug = item.category?.parent?.slug?.toLowerCase();
        const parentCatName = item.category?.parent?.name?.toLowerCase();

        const activeId = activeCuisineObj?._id?.toString();
        const activeSlug = activeCuisineObj?.slug?.toLowerCase() || activeCuisineObj?.id?.toLowerCase();
        const activeName = activeCuisineObj?.name?.toLowerCase();

        let matchesCuisine = false;

        // Check direct category / subcategory / parent IDs, Slugs, and Names
        if (activeId && (catId === activeId || subcatId === activeId || parentCatId === activeId)) {
          matchesCuisine = true;
        } else if (activeSlug && (catSlug === activeSlug || subcatSlug === activeSlug || parentCatSlug === activeSlug)) {
          matchesCuisine = true;
        } else if (activeName && (catName === activeName || subcatName === activeName || parentCatName === activeName)) {
          matchesCuisine = true;
        }

        // Check if item category is one of the children subcategories of the selected category tab
        if (!matchesCuisine && activeCuisineObj?.children && activeCuisineObj.children.length > 0) {
          const childIds = activeCuisineObj.children.map((ch) => ch._id?.toString());
          const childSlugs = activeCuisineObj.children.map((ch) => ch.slug?.toLowerCase());
          const childNames = activeCuisineObj.children.map((ch) => ch.name?.toLowerCase());

          if ((catId && childIds.includes(catId)) || (subcatId && childIds.includes(subcatId))) {
            matchesCuisine = true;
          } else if ((catSlug && childSlugs.includes(catSlug)) || (subcatSlug && childSlugs.includes(subcatSlug))) {
            matchesCuisine = true;
          } else if ((catName && childNames.includes(catName)) || (subcatName && childNames.includes(subcatName))) {
            matchesCuisine = true;
          }
        }

        // Fallback matching logic on dish name, description, restaurant, and cuisine array
        if (!matchesCuisine) {
          const dishCuisines = (item.cuisine || []).map((c) => c.toLowerCase().replace(/[-_&]/g, ' '));
          const dishName = (item.name || '').toLowerCase();
          const dishDesc = (item.description || '').toLowerCase();
          const dishRest = (item.restaurantName || '').toLowerCase();

          const normCuisine = (activeName || selectedCuisine).replace(/[-_&]/g, ' ').toLowerCase();

          if (normCuisine.includes('biryani')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('biryani') || c.includes('mughlai') || c.includes('hyderabadi')) ||
              dishName.includes('biryani') ||
              dishDesc.includes('biryani');
          } else if (normCuisine.includes('north indian') || normCuisine.includes('indian')) {
            matchesCuisine =
              dishCuisines.some(
                (c) =>
                  c.includes('north indian') ||
                  c.includes('curry') ||
                  c.includes('punjabi') ||
                  c.includes('thali') ||
                  c.includes('tandoor')
              ) ||
              dishName.includes('paneer') ||
              dishName.includes('makhani') ||
              dishName.includes('naan') ||
              dishName.includes('tikka') ||
              dishDesc.includes('paneer') ||
              dishDesc.includes('makhani');
          } else if (normCuisine.includes('pizza')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('pizza') || c.includes('italian')) ||
              dishName.includes('pizza') ||
              dishDesc.includes('pizza');
          } else if (normCuisine.includes('burg')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('burger') || c.includes('american')) ||
              dishName.includes('burger') ||
              dishDesc.includes('burger');
          } else if (normCuisine.includes('chinese') || normCuisine.includes('momo')) {
            matchesCuisine =
              dishCuisines.some(
                (c) =>
                  c.includes('chinese') ||
                  c.includes('momo') ||
                  c.includes('tibetan') ||
                  c.includes('asian') ||
                  c.includes('noodle')
              ) ||
              dishName.includes('momo') ||
              dishName.includes('dimsum') ||
              dishName.includes('noodle') ||
              dishName.includes('manchurian') ||
              dishDesc.includes('momo') ||
              dishDesc.includes('dumpling');
          } else if (normCuisine.includes('dessert') || normCuisine.includes('shake')) {
            matchesCuisine =
              dishCuisines.some(
                (c) =>
                  c.includes('dessert') ||
                  c.includes('sweet') ||
                  c.includes('shake') ||
                  c.includes('beverage') ||
                  c.includes('ice cream')
              ) ||
              dishName.includes('shake') ||
              dishName.includes('chocolate') ||
              dishName.includes('jamun') ||
              dishName.includes('rabri') ||
              dishName.includes('kulfi') ||
              dishName.includes('cake') ||
              dishDesc.includes('shake') ||
              dishDesc.includes('chocolate') ||
              dishDesc.includes('sweet');
          } else if (normCuisine.includes('roll') || normCuisine.includes('wrap')) {
            matchesCuisine =
              dishCuisines.some((c) => c.includes('roll') || c.includes('wrap') || c.includes('kathi')) ||
              dishName.includes('roll') ||
              dishName.includes('wrap') ||
              dishName.includes('kathi') ||
              dishDesc.includes('roll') ||
              dishDesc.includes('wrap');
          } else {
            matchesCuisine =
              dishCuisines.some((c) => c.includes(normCuisine) || normCuisine.includes(c)) ||
              dishName.includes(normCuisine) ||
              dishRest.includes(normCuisine) ||
              (catName && catName.includes(normCuisine)) ||
              (subcatName && subcatName.includes(normCuisine));
          }
        }

        if (!matchesCuisine) return false;
      }

      if (activeTab === 'rating' && (item.rating?.average || 0) < 4.4) return false;
      if (activeTab === 'fast' && (item.preparationTime || 30) > 25) return false;
      if (activeTab === 'offers' && !item.comparePrice && !item.discount && !item.isDeals) return false;
      if (activeTab === 'past' && !pastOrderedNames.has((item.name || '').toLowerCase().trim())) return false;

      if (selectedRestaurant) {
        const normRest = selectedRestaurant.toLowerCase();
        const itemRest = (item.restaurantName || '').toLowerCase();
        if (!itemRest.includes(normRest) && !normRest.includes(itemRest)) {
          return false;
        }
      }

      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = item.name.toLowerCase().includes(q);
        const matchesRest = item.restaurantName?.toLowerCase().includes(q);
        const matchesCuisine = item.cuisine?.some((c) => c.toLowerCase().includes(q));
        if (!matchesName && !matchesRest && !matchesCuisine) return false;
      }

      return true;
    });
  }, [dishes, isVegOnly, selectedCuisine, selectedRestaurant, activeTab, search, pastOrderedNames]);

  const filteredRestaurants = useMemo(() => {
    return FEATURED_RESTAURANTS.filter((rest) => {
      // 1. Pure Veg Filter
      if (isVegOnly) {
        const hasVegDishInMenu = dishes.some(
          (d) => (d.restaurantName || '').toLowerCase().includes(rest.name.toLowerCase()) && d.isVeg
        );
        if (!rest.isVeg && !hasVegDishInMenu) return false;
      }

      // 2. Active Tab Filters (rating, fast, offers)
      if (activeTab === 'rating' && rest.rating < 4.4) return false;
      if (activeTab === 'fast' && rest.prepMinutes > 20) return false;
      if (activeTab === 'offers' && !rest.hasDeals) return false;

      // 3. Selected Cuisine Filter
      if (selectedCuisine && selectedCuisine !== 'all') {
        const activeCuisineObj = dynamicCuisines.find(
          (c) => c.id === selectedCuisine || c.slug === selectedCuisine || c._id === selectedCuisine || c.name === selectedCuisine
        );
        const activeName = (activeCuisineObj?.name || selectedCuisine).toLowerCase().replace(/[-_&]/g, ' ').trim();
        const restName = rest.name.toLowerCase();
        const restCuisines = rest.cuisines.toLowerCase();
        const matchesCuisineTag = rest.cuisineTags.some((tag) => tag.includes(activeName) || activeName.includes(tag));
        const matchesDishCuisine = dishes.some(
          (d) => (d.restaurantName || '').toLowerCase().includes(rest.name.toLowerCase()) &&
            ((d.category?.name || '').toLowerCase().includes(activeName) ||
             (d.cuisine || []).some((c) => c.toLowerCase().includes(activeName)))
        );
        if (!matchesCuisineTag && !restName.includes(activeName) && !restCuisines.includes(activeName) && !matchesDishCuisine) {
          return false;
        }
      }

      // 4. Search Query Filter
      if (search.trim()) {
        const q = search.toLowerCase().trim();
        const matchesRestName = rest.name.toLowerCase().includes(q);
        const matchesCuisinesStr = rest.cuisines.toLowerCase().includes(q);
        const matchesCuisineTag = rest.cuisineTags.some((tag) => tag.includes(q) || q.includes(tag));
        const matchesDish = dishes.some(
          (d) => (d.restaurantName || '').toLowerCase().includes(rest.name.toLowerCase()) &&
            ((d.name || '').toLowerCase().includes(q) ||
             (d.description || '').toLowerCase().includes(q) ||
             (d.cuisine || []).some((c) => c.toLowerCase().includes(q)))
        );
        if (!matchesRestName && !matchesCuisinesStr && !matchesCuisineTag && !matchesDish) {
          return false;
        }
      }

      return true;
    });
  }, [isVegOnly, activeTab, selectedCuisine, search, dishes, dynamicCuisines]);

  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];
  if (disabledVerticals.includes('food')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <p className="text-6xl">🍔</p>
        <h1 className="text-2xl font-bold text-gray-900">Food Delivery Currently Unavailable</h1>
        <Link href="/" className="btn-brand inline-block text-sm px-6 py-2.5 rounded-xl font-bold">
          Return to Home
        </Link>
      </div>
    );
  }

  const handleSelectRestaurant = (restName) => {
    if (selectedRestaurant === restName) {
      setSelectedRestaurant(null);
    } else {
      setSelectedRestaurant(restName);
      toast.success(`Viewing menu for ${restName}`);
      setTimeout(() => {
        dishesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  };

  const handleUpdateQty = (dish, newQty, e) => {
    if (e) {
      e.stopPropagation();
    }
    const cartItem = getCartItem(dish._id);
    const isMongoId = /^[0-9a-fA-F]{24}$/.test(dish._id);
    const isServerItem = Boolean(
      cartItem?._id && !String(cartItem._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(cartItem._id)
    );

    if (newQty <= 0) {
      if (isAuthenticated && isServerItem) {
        removeFromCartMutation({ variables: { itemId: cartItem._id } });
      }
      if (cartItem?._id) removeItemLocal(cartItem._id);
      else removeItemLocal(dish._id);
    } else {
      if (isAuthenticated && isMongoId) {
        if (isServerItem) {
          updateCartItemMutation({ variables: { itemId: cartItem._id, quantity: newQty } });
        } else {
          addToCartMutation({
            variables: { input: { productId: dish._id, quantity: newQty, variantIndex: -1 } },
          });
        }
      }
      if (cartItem?._id) updateQuantityLocal(cartItem._id, newQty);
      else updateQuantityLocal(dish._id, newQty);
    }
  };

  const handleAdd = (dish) => {
    addItem({
      _id: dish._id,
      name: dish.name,
      price: dish.price,
      images: dish.images,
      stock: dish.stock || 50,
      vertical: 'food',
    });
    toast.success(`Added ${dish.name} to cart!`);
  };

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20">
      {/* Filter & Search Bar Container */}
      <div className="sticky top-16 md:top-[104px] z-40 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm transition-all">
        <div className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row items-center gap-4 justify-between">
          {/* Search Input */}
          <div className="relative w-full md:w-96">
            <MagnifyingGlassIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search dishes, restaurants or cuisines..."
              className="w-full pl-10 pr-4 py-2 text-sm bg-gray-100/90 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all font-medium text-slate-800"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <XMarkIcon className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Controls: Veg Only Toggle & Filter Pills */}
          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 w-full md:w-auto py-1 px-1">
            {/* Pure Veg Switch */}
            <button
              onClick={() => setIsVegOnly(!isVegOnly)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl border text-xs font-black transition-all flex-shrink-0 ${
                isVegOnly
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs'
                  : 'bg-white border-gray-300 text-gray-600 hover:border-gray-400'
              }`}
            >
              <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center border ${isVegOnly ? 'border-emerald-600' : 'border-gray-400'}`}>
                <span className={`w-2 h-2 rounded-full ${isVegOnly ? 'bg-emerald-600' : 'bg-gray-400'}`} />
              </span>
              <span>Pure Veg Only</span>
            </button>

            {/* Quick Filter Tabs */}
            {[
              { id: 'all', label: 'All Items' },
              { id: 'offers', label: '🏷️ Offers' },
              { id: 'past', label: '📜 Past Orders' },
              { id: 'fast', label: '⚡ Under 25 mins' },
              { id: 'rating', label: '⭐ Rating 4.4+' },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex-shrink-0 cursor-pointer ${
                    isActive
                      ? 'bg-orange-600 text-white shadow-xs'
                      : 'bg-white border border-gray-200 text-slate-600 hover:bg-gray-50'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 mt-6 space-y-8">
        {/* Promotional Hero Banners */}
        <HeroBanner vertical="food" />

        {/* Featured Restaurants Shelf */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 flex items-center gap-2">
                <span>Top Rated Restaurants Near You</span>
                {filteredRestaurants.length > 0 && (
                  <span className="text-xs font-bold text-slate-600 bg-slate-100 border border-slate-200 px-2.5 py-0.5 rounded-full">
                    {filteredRestaurants.length}
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                {search.trim() ? `Filtered restaurants matching "${search}"` : 'Click any restaurant to explore its exclusive menu'}
              </p>
            </div>
            {selectedRestaurant && (
              <button
                onClick={() => setSelectedRestaurant(null)}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 bg-orange-50 hover:bg-orange-100 px-3 py-1.5 rounded-xl border border-orange-200 transition-all cursor-pointer flex items-center gap-1"
              >
                <span>Clear Selection</span>
                <span>✕</span>
              </button>
            )}
          </div>

          {filteredRestaurants.length === 0 ? (
            <div className="bg-white border border-gray-200 rounded-2xl p-6 text-center text-slate-500 text-sm font-medium shadow-xs">
              No restaurants match "{search || 'selected filters'}". Try searching another dish or cuisine!
            </div>
          ) : (
            <div className="-mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 flex items-center gap-5 overflow-x-auto py-2.5 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              {filteredRestaurants.map((rest) => {
                const isSelected = selectedRestaurant === rest.name;
                return (
                  <div
                    key={rest.id}
                    onClick={() => handleSelectRestaurant(rest.name)}
                    className={`w-[290px] sm:w-[320px] md:w-[340px] flex-shrink-0 rounded-3xl overflow-hidden transition-all duration-300 group cursor-pointer ${
                      isSelected
                        ? 'bg-orange-50/40 border-2 border-orange-500 shadow-xl ring-4 ring-orange-500/20 scale-[1.01]'
                        : 'bg-white border border-gray-200 hover:border-orange-300 hover:shadow-xl'
                    }`}
                  >
                    <div className="relative h-44 w-full overflow-hidden bg-gray-100">
                      <img
                        src={rest.image}
                        alt={rest.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute top-3 right-3 bg-slate-900/80 backdrop-blur-xs text-white text-xs font-bold px-2.5 py-1 rounded-xl flex items-center gap-1">
                        <ClockIcon className="w-3.5 h-3.5" />
                        <span>{rest.time}</span>
                      </div>
                      {isSelected && (
                        <div className="absolute top-3 left-3 bg-orange-600 text-white text-[11px] font-black px-3 py-1 rounded-xl shadow-lg flex items-center gap-1.5 animate-pulse">
                          <CheckIcon className="w-3.5 h-3.5 stroke-[3]" />
                          <span>MENU ACTIVE</span>
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between">
                        <h3 className={`text-base font-extrabold transition-colors truncate ${
                          isSelected ? 'text-orange-600' : 'text-slate-900 group-hover:text-orange-600'
                        }`}>
                          {rest.name}
                        </h3>
                        <div className="flex items-center gap-1 bg-emerald-600 text-white text-xs font-black px-2 py-0.5 rounded-lg flex-shrink-0">
                          <span>{rest.rating}</span>
                          <StarIconSolid className="w-3 h-3" />
                        </div>
                      </div>
                      <p className="text-xs text-slate-500 font-medium mt-1 truncate">{rest.cuisines}</p>
                      <div className="flex items-center justify-between mt-2 pt-1 border-t border-gray-100">
                        <p className="text-xs text-slate-400 font-medium">{rest.price}</p>
                        <span className={`text-xs font-bold ${isSelected ? 'text-orange-600' : 'text-slate-400 group-hover:text-orange-500'}`}>
                          {isSelected ? 'Viewing Menu ↑' : 'View Menu →'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Cuisines Carousel - Eat What Makes You Happy */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-xl font-black text-slate-900">Eat What Makes You Happy</h2>
          </div>
          <div className="-mx-4 sm:-mx-6 lg:-mx-8 px-4 sm:px-6 lg:px-8 flex items-center gap-4 sm:gap-6 overflow-x-auto py-3.5 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
            {categoriesLoading && dynamicCuisines.length === 0
              ? /* Skeleton placeholders while loading */
                Array.from({ length: 7 }).map((_, i) => (
                  <div key={`skel-${i}`} className="flex flex-col items-center flex-shrink-0 p-1 animate-pulse">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gray-200" />
                    <div className="mt-2 w-16 h-3 rounded bg-gray-200" />
                  </div>
                ))
              : dynamicCuisines.map((item) => {
                  const isSelected = selectedCuisine === item.id || selectedCuisine === item.name;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setSelectedCuisine((prev) => (prev === item.id || prev === item.name ? 'all' : item.id))}
                      className="flex flex-col items-center group flex-shrink-0 cursor-pointer p-1"
                    >
                      <div className={`relative w-20 h-20 sm:w-24 sm:h-24 rounded-full p-1 transition-all duration-200 ${
                        isSelected
                          ? 'border-4 border-orange-500 shadow-md bg-white scale-105'
                          : 'border-2 border-gray-200 group-hover:border-orange-300 bg-white'
                      }`}>
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover rounded-full"
                          onError={(e) => {
                            e.currentTarget.src = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300';
                          }}
                        />
                        {isSelected && (
                          <div className="absolute -bottom-0.5 right-0.5 bg-orange-500 text-white rounded-full p-0.5 border-2 border-white shadow-xs">
                            <CheckIcon className="w-3.5 h-3.5 stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <span className={`mt-2 text-xs font-bold text-center w-24 sm:w-28 line-clamp-2 leading-tight transition-colors ${
                        isSelected ? 'text-orange-600 font-extrabold' : 'text-slate-700 group-hover:text-slate-900'
                      }`}>
                        {item.name}
                      </span>
                      {isSelected && (
                        <div className="h-1 w-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-full mt-1.5 shadow-xs" />
                      )}
                    </button>
                  );
                })
            }
          </div>
        </div>

        {/* Dishes Grid */}
        <div ref={dishesRef} className="scroll-mt-24">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <h2 className="text-xl font-black text-slate-900">
                  {selectedRestaurant
                    ? `🏪 ${selectedRestaurant} Menu (${filteredDishes.length})`
                    : selectedCuisine === 'all'
                    ? `Popular Dishes (${filteredDishes.length})`
                    : `${CUISINES.find((c) => c.id === selectedCuisine)?.name || 'Cuisine'} (${filteredDishes.length})`}
                </h2>
                {selectedRestaurant && (
                  <button
                    onClick={() => setSelectedRestaurant(null)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-orange-700 bg-orange-100/80 hover:bg-orange-200 px-3 py-1 rounded-full border border-orange-200 transition-all cursor-pointer"
                  >
                    <span>All Restaurants</span>
                    <span className="text-orange-600 font-black">✕</span>
                  </button>
                )}
                {selectedCuisine !== 'all' && (
                  <button
                    onClick={() => setSelectedCuisine('all')}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-1 rounded-full border border-slate-200 transition-all cursor-pointer"
                  >
                    <span>All Cuisines</span>
                    <span className="text-slate-600 font-black">✕</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {selectedRestaurant
                  ? `All items from ${selectedRestaurant} • Prepared fresh to order`
                  : 'Curated delicious meals ready to prepare and deliver'}
              </p>
            </div>
          </div>

          {filteredDishes.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-gray-200 space-y-3">
              <span className="text-4xl">🍽️</span>
              <h3 className="text-lg font-bold text-gray-900">No dishes found</h3>
              <p className="text-xs text-gray-500 max-w-sm mx-auto">We couldn't find any dishes matching your active filters. Try clearing your filters.</p>
              <button
                onClick={() => { setSelectedCuisine('all'); setIsVegOnly(false); setActiveTab('all'); setSearch(''); }}
                className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition-all cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {filteredDishes.map((dish) => {
              const qty = getItemQuantity(dish._id);
              return (
                <div
                  key={dish._id}
                  onClick={() => handleOpenCustomization(dish)}
                  className="bg-white rounded-3xl p-4 border border-gray-200/90 hover:border-orange-400 hover:shadow-xl transition-all duration-300 flex flex-col justify-between cursor-pointer group"
                >
                  <div className="flex gap-4">
                    <div className="flex-1 space-y-1">
                      {/* Veg / Non-Veg Indicator */}
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 border-2 rounded-xs flex items-center justify-center ${
                          dish.isVeg ? 'border-emerald-600' : 'border-rose-600'
                        }`}>
                          <span className={`w-2 h-2 rounded-full ${dish.isVeg ? 'bg-emerald-600' : 'bg-rose-600'}`} />
                        </div>
                        {dish.rating?.average && (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md">
                            <StarIconSolid className="w-3 h-3" /> {dish.rating.average.toFixed(1)}
                          </span>
                        )}
                        {dish.preparationTime && (
                          <span className="text-[11px] font-semibold text-slate-400">
                            ⏱️ {dish.preparationTime}m
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-extrabold text-slate-900 leading-snug group-hover:text-orange-600 transition-colors">
                        {dish.name}
                      </h3>
                      {dish.restaurantName && (
                        <p className="text-xs font-bold text-orange-600">by {dish.restaurantName}</p>
                      )}

                      <div className="flex items-baseline gap-2 pt-1">
                        <span className="text-lg font-black text-slate-900">₹{dish.price}</span>
                        {dish.comparePrice > dish.price && (
                          <span className="text-xs text-slate-400 line-through">₹{dish.comparePrice}</span>
                        )}
                      </div>

                      {dish.description && (
                        <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed pt-1 font-normal">
                          {dish.description.replace(/<[^>]*>/g, '').replace(/&nbsp;/gi, ' ').trim()}
                        </p>
                      )}
                    </div>

                    {/* Image & Add Button */}
                    <div className="relative w-28 h-28 flex-shrink-0">
                      <img
                        src={dish.images?.[0] || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300'}
                        alt={dish.name}
                        className="w-full h-full object-cover rounded-2xl bg-gray-100 group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2" onClick={(e) => e.stopPropagation()}>
                        {qty === 0 ? (
                          <button
                            onClick={() => handleOpenCustomization(dish)}
                            className="bg-white hover:bg-orange-50 border-2 border-orange-500 text-orange-600 font-black text-xs px-5 py-1.5 rounded-xl shadow-md transition-all active:scale-95 cursor-pointer"
                          >
                            ADD +
                          </button>
                        ) : (
                          <div className="flex items-center bg-orange-600 text-white rounded-xl shadow-md px-2 py-1 gap-2">
                            <button
                              onClick={(e) => handleUpdateQty(dish, qty - 1, e)}
                              className="p-0.5 hover:bg-orange-700 rounded-md transition-colors cursor-pointer"
                            >
                              <MinusIcon className="w-3.5 h-3.5" />
                            </button>
                            <span className="text-xs font-black min-w-[14px] text-center">{qty}</span>
                            <button
                              onClick={(e) => handleUpdateQty(dish, qty + 1, e)}
                              className="p-0.5 hover:bg-orange-700 rounded-md transition-colors cursor-pointer"
                            >
                              <PlusIcon className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Customizable Footer Link matching Mobile */}
                  <div className="pt-2.5 flex items-center justify-between border-t border-gray-100 mt-3">
                    <span className="text-[11px] font-extrabold text-orange-600 group-hover:underline flex items-center gap-1">
                      <span>Customizable • Tap for details</span>
                    </span>
                    <span className="text-[11px] font-bold text-slate-400 group-hover:text-orange-500 transition-colors">
                      View Details →
                    </span>
                  </div>
                </div>
              );
            })}
            </div>
          )}
        </div>
      </div>

      {/* Dish Customization & Details Modal */}
      <AnimatePresence>
        {customizingDish && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
            onClick={() => setCustomizingDish(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-gray-100 flex flex-col max-h-[90vh]"
            >
              {/* Modal Hero Image Header */}
              <div className="relative h-56 w-full bg-gray-100 flex-shrink-0">
                <img
                  src={customizingDish.images?.[0] || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600'}
                  alt={customizingDish.name}
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => setCustomizingDish(null)}
                  className="absolute top-3 right-3 bg-white/90 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-sm transition-all cursor-pointer"
                >
                  <XMarkIcon className="w-5 h-5 stroke-[2.5]" />
                </button>
                <div className="absolute bottom-3 left-3 flex items-center gap-2">
                  <div className={`px-2.5 py-1 rounded-full text-xs font-black text-white shadow-md flex items-center gap-1 ${
                    customizingDish.isVeg ? 'bg-emerald-600' : 'bg-rose-600'
                  }`}>
                    <span>{customizingDish.isVeg ? '🟢 VEG' : '🔴 NON-VEG'}</span>
                  </div>
                  {customizingDish.rating?.average && (
                    <div className="bg-amber-500 text-white text-xs font-black px-2.5 py-1 rounded-full shadow-md flex items-center gap-1">
                      <StarIconSolid className="w-3.5 h-3.5" />
                      <span>{customizingDish.rating.average.toFixed(1)}</span>
                    </div>
                  )}
                  {customizingDish.preparationTime && (
                    <div className="bg-slate-900/80 backdrop-blur-xs text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-md">
                      ⏱️ {customizingDish.preparationTime} mins
                    </div>
                  )}
                </div>
              </div>

              {/* Scrollable Details & Options */}
              <div className="p-6 overflow-y-auto space-y-5 flex-1">
                <div>
                  <h2 className="text-xl font-black text-slate-900">{customizingDish.name}</h2>
                  {customizingDish.restaurantName && (
                    <p className="text-xs font-bold text-orange-600 mt-0.5">by {customizingDish.restaurantName}</p>
                  )}
                  {customizingDish.description && (
                    <div
                      className="text-xs text-slate-600 font-normal mt-2 leading-relaxed bg-slate-50 p-3 rounded-2xl border border-slate-100 prose prose-xs max-w-none"
                      dangerouslySetInnerHTML={{ __html: customizingDish.description }}
                    />
                  )}
                </div>

                {/* Food Variants Section */}
                {Boolean(customizingDish.variants && customizingDish.variants.length > 0) && (
                  <div>
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider mb-2.5">
                      {customizingDish.variants[0]?.name || 'Select Variant / Portion'}
                    </h4>
                    <div className="space-y-2">
                      {customizingDish.variants.map((vGroup, vIdx) => (
                        <div key={vIdx} className="space-y-2">
                          {(vGroup.options || []).map((opt, optIdx) => {
                            const isSelected =
                              (selectedVariantOption?.label || selectedVariantOption?.name) === (opt.label || opt.name) ||
                              (!selectedVariantOption && optIdx === 0);
                            return (
                              <div
                                key={optIdx}
                                onClick={() => setSelectedVariantOption(opt)}
                                className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                                  isSelected
                                    ? 'bg-orange-50/60 border-orange-400 shadow-xs'
                                    : 'bg-white border-gray-200 hover:border-gray-300'
                                }`}
                              >
                                <div className="flex items-center gap-2.5">
                                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-orange-500 bg-orange-500' : 'border-gray-300'}`}>
                                    {isSelected && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                                  </div>
                                  <span className={`text-xs ${isSelected ? 'font-black text-orange-600' : 'font-bold text-slate-800'}`}>
                                    {opt.label || opt.name}
                                  </span>
                                </div>
                                <span className="text-xs font-extrabold text-slate-600">₹{opt.price}</span>
                              </div>
                            );
                          })}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Add-ons Section */}
                {customizingDish.addons && customizingDish.addons.length > 0 && (
                <div>
                  <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider mb-2.5">
                    Select Add-ons / Toppings
                  </h4>
                  <div className="space-y-2">
                    {customizingDish.addons.map((addon, idx) => {
                      const isSelected = selectedAddons.some((a) => a.name === addon.name);
                      return (
                        <div
                          key={idx}
                          onClick={() => {
                            if (isSelected) {
                              setSelectedAddons(selectedAddons.filter((a) => a.name !== addon.name));
                            } else {
                              setSelectedAddons([...selectedAddons, addon]);
                            }
                          }}
                          className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-orange-50/60 border-orange-400 shadow-xs'
                              : 'bg-white border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="text-xl">{addon.icon || '🍽️'}</span>
                            <span className="text-xs font-bold text-slate-800">{addon.name}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-xs font-extrabold text-slate-600">+₹{addon.price}</span>
                            <div className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                              isSelected ? 'bg-orange-500 border-orange-500 text-white' : 'border-gray-300 bg-white'
                            }`}>
                              {isSelected && <CheckIcon className="w-3.5 h-3.5 stroke-[3]" />}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                )}

                {/* Instructions Section */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-xs font-black uppercase text-slate-400 tracking-wider">
                      Instructions
                    </h4>
                  </div>
                  <textarea
                    value={itemInstructions}
                    onChange={(e) => setItemInstructions(e.target.value)}
                    placeholder="e.g. Less oil, extra sauce, make it crispy..."
                    className="w-full text-xs bg-slate-50 border border-gray-200 rounded-2xl p-3 focus:outline-none focus:ring-2 focus:ring-orange-500 text-slate-800 font-medium resize-none h-20"
                  />
                  {/* Quick Chips */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['Less spicy', 'Extra sauce', 'Make it crispy', 'No onion/garlic'].map((chip) => (
                      <button
                        key={chip}
                        type="button"
                        onClick={() => {
                          if (!itemInstructions.includes(chip)) {
                            setItemInstructions((prev) => (prev ? `${prev}, ${chip}` : chip));
                          }
                        }}
                        className="text-[11px] font-bold bg-white border border-gray-200 hover:border-orange-300 text-slate-700 hover:text-orange-600 px-2.5 py-1 rounded-xl transition-all cursor-pointer"
                      >
                        + {chip}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Action Footer */}
              <div className="p-4 bg-slate-50 border-t border-gray-200 flex items-center justify-between gap-4">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total Amount</span>
                  <span className="text-xl font-black text-slate-900">
                    ₹{(selectedVariantOption ? selectedVariantOption.price : customizingDish.price) + selectedAddons.reduce((sum, a) => sum + a.price, 0)}
                  </span>
                </div>
                <button
                  onClick={handleAddCustomized}
                  className="bg-orange-500 hover:bg-orange-600 text-white flex-1 py-3 px-6 rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg shadow-orange-500/25 active:scale-95 transition-all cursor-pointer text-center"
                >
                  ADD ITEM TO CART • ₹{(selectedVariantOption ? selectedVariantOption.price : customizingDish.price) + selectedAddons.reduce((sum, a) => sum + a.price, 0)}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {totalFoodItems > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4">
          <div className="bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-2xl p-4 shadow-2xl flex items-center justify-between border border-orange-400/30">
            <div>
              <p className="text-[11px] font-black uppercase tracking-wider text-orange-100">
                {totalFoodItems} {totalFoodItems === 1 ? 'Item' : 'Items'} Added
              </p>
              <p className="text-lg font-black text-white">₹{totalFoodAmount.toLocaleString('en-IN')}</p>
            </div>
            <Link
              href="/cart"
              className="bg-white text-orange-600 hover:bg-orange-50 font-black text-xs uppercase tracking-wider px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-md active:scale-95"
            >
              <span>View Cart</span>
              <ArrowRightIcon className="w-4 h-4" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
