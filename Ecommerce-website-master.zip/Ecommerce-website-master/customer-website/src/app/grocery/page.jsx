'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useQuery, useMutation } from '@apollo/client';
import {
  MagnifyingGlassIcon,
  MapPinIcon,
  TagIcon,
  SparklesIcon,
  PlusIcon,
  MinusIcon,
  CheckIcon,
  HeartIcon,
} from '@heroicons/react/24/solid';
import { HeartIcon as HeartOutline } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_PRODUCTS, GET_CART, GET_STORE_SETTINGS } from '@/graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM, REMOVE_FROM_CART } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';

const GROCERY_CATEGORIES = [
  { id: 'fruits', name: 'Fruits', icon: '🍎', querySlug: 'fruits' },
  { id: 'veggies', name: 'Veggies', icon: '🥬', querySlug: 'vegetables' },
  { id: 'meat', name: 'Meat', icon: '🥩', querySlug: 'meat' },
  { id: 'bakery', name: 'Bakery', icon: '🥐', querySlug: 'bakery' },
];



const FALLBACK_ITEMS = [
  {
    _id: '6a98798bc87f422f2bb5fd22',
    name: 'Organic Yellow Bananas (Robusta)',
    slug: 'organic-yellow-bananas-robusta',
    unitMeasure: '500g (3-4 pcs)',
    price: 49,
    comparePrice: 65,
    badge: null,
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500'],
    category: { slug: 'fresh-fruits', name: 'Fresh Fruits' },
    rating: { average: 4.8, count: 210 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd25',
    name: 'Crisp Red Fuji Apples',
    slug: 'crisp-red-fuji-apples',
    unitMeasure: '1kg (Approx 4-5 pcs)',
    price: 149,
    comparePrice: 199,
    badge: 'SALE',
    images: ['https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=500'],
    category: { slug: 'fresh-fruits', name: 'Fresh Fruits' },
    rating: { average: 4.9, count: 180 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd28',
    name: 'Ready-to-eat Hass Avocados',
    slug: 'ready-to-eat-hass-avocados',
    unitMeasure: '2 pcs',
    price: 199,
    comparePrice: 249,
    badge: 'ORGANIC',
    images: ['https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=500'],
    category: { slug: 'fresh-fruits', name: 'Fresh Fruits' },
    rating: { average: 4.9, count: 128 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd2b',
    name: 'Hydroponic Fresh Baby Spinach',
    slug: 'hydroponic-fresh-baby-spinach-palak',
    unitMeasure: '250g Pack',
    price: 39,
    comparePrice: 55,
    badge: null,
    images: ['https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=500'],
    category: { slug: 'fresh-vegetables', name: 'Fresh Vegetables' },
    rating: { average: 4.7, count: 140 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd2e',
    name: 'Fresh Crunchy Orange Carrots',
    slug: 'fresh-crunchy-orange-carrots',
    unitMeasure: '500g',
    price: 45,
    comparePrice: 60,
    badge: 'ORGANIC',
    images: ['https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=500'],
    category: { slug: 'fresh-vegetables', name: 'Fresh Vegetables' },
    rating: { average: 4.8, count: 88 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd31',
    name: 'Sweet Farm Fresh Strawberries',
    slug: 'sweet-farm-fresh-strawberries',
    unitMeasure: '200g Punnet',
    price: 119,
    comparePrice: 159,
    badge: 'SALE',
    images: ['https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=500'],
    category: { slug: 'fresh-fruits', name: 'Fresh Fruits' },
    rating: { average: 4.9, count: 165 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd34',
    name: 'Farm Fresh Pure Whole Cow Milk',
    slug: 'farm-fresh-pure-whole-cow-milk',
    unitMeasure: '1 Litre Pouch',
    price: 68,
    comparePrice: 75,
    badge: null,
    images: ['https://images.unsplash.com/photo-1563636619-e9143da7973b?w=500'],
    category: { slug: 'dairy-breakfast', name: 'Dairy & Breakfast' },
    rating: { average: 4.9, count: 320 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd37',
    name: 'Artisan Sourdough Country Loaf',
    slug: 'artisan-sourdough-country-loaf',
    unitMeasure: '400g Loaf',
    price: 99,
    comparePrice: 130,
    badge: 'FRESH',
    images: ['https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=500'],
    category: { slug: 'bakery-breads', name: 'Bakery & Breads' },
    rating: { average: 4.8, count: 75 },
  },
  {
    _id: '6a987d124d090c15299b7dc1',
    name: 'Tender Fresh Chicken Breast (Boneless)',
    slug: 'tender-fresh-chicken-breast-boneless',
    unitMeasure: '500g Pack',
    price: 189,
    comparePrice: 220,
    badge: 'FRESH',
    images: ['https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=500'],
    category: { slug: 'meat', name: 'Fresh Meat & Poultry' },
    rating: { average: 4.9, count: 190 },
  },
];

export default function GroceryPage() {
  const { isAuthenticated } = useAuthStore();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeFilter, setActiveFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [favorites, setFavorites] = useState({});

  // Local guest cart
  const { 
    items: localCartItems, 
    addItem: addItemLocal, 
    updateQuantity: updateQuantityLocal, 
    removeItem: removeItemLocal 
  } = useCartStore();

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vertical: 'grocery' },
      pagination: { page: 1, limit: 30 },
    },
    fetchPolicy: 'cache-and-network',
  });

  // Server cart data
  const { data: cartData, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [addToCartMutation] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      toast.success('Added to cart!');
      refetchCart();
    },
    onError: (err) => {
      console.error('addToCart error:', err);
    },
  });

  const [updateCartItemMutation] = useMutation(UPDATE_CART_ITEM, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('updateCartItem error:', err),
  });

  const [removeFromCartMutation] = useMutation(REMOVE_FROM_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('removeFromCart error:', err),
  });

  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];
  if (disabledVerticals.includes('grocery')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <p className="text-6xl">🥦</p>
        <h1 className="text-2xl font-bold text-gray-900">Grocery Store Currently Unavailable</h1>
        <Link href="/" className="btn-brand inline-block text-sm px-6 py-2.5 rounded-xl font-bold">
          Return to Home
        </Link>
      </div>
    );
  }

  const serverCartItems = cartData?.getCart?.items || [];
  const currentCartItems = isAuthenticated && serverCartItems.length > 0 
    ? serverCartItems 
    : (localCartItems.length > 0 ? localCartItems : serverCartItems);

  // Helper to find existing cart item for a product
  const getCartItem = (product) => {
    return currentCartItems.find(
      (item) => (item.product?._id || item.product?.id || item.product) === product._id
    );
  };

  const fetched = data?.getProducts?.products;
  const products = (fetched && fetched.length > 0) ? fetched : FALLBACK_ITEMS;

  const filteredProducts = products.filter((p) => {
    // 1. Search filter
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchName = p.name?.toLowerCase().includes(q);
      const matchDesc = p.description?.toLowerCase().includes(q);
      const matchCat = p.category?.name?.toLowerCase().includes(q);
      if (!matchName && !matchDesc && !matchCat) return false;
    }

    // 2. Category Tab Filter
    if (selectedCategory !== 'all') {
      const catSlug = (p.category?.slug || '').toLowerCase();
      const catName = (p.category?.name || '').toLowerCase();
      const prodName = (p.name || '').toLowerCase();

      // Explicit check for Vegetables
      const isKnownVeggie =
        catSlug.includes('veg') ||
        catName.includes('veg') ||
        prodName.includes('carrot') ||
        prodName.includes('spinach') ||
        prodName.includes('palak') ||
        prodName.includes('tomato') ||
        prodName.includes('potato') ||
        prodName.includes('onion') ||
        prodName.includes('cucumber') ||
        prodName.includes('broccoli') ||
        prodName.includes('vegetable');

      if (selectedCategory === 'fruits') {
        // Carrots and other veggies must never appear in fruits!
        if (isKnownVeggie) return false;

        const isFruit =
          catSlug.includes('fruit') ||
          catName.includes('fruit') ||
          prodName.includes('banana') ||
          prodName.includes('apple') ||
          prodName.includes('avocado') ||
          prodName.includes('strawberr') ||
          prodName.includes('mango') ||
          prodName.includes('papaya') ||
          prodName.includes('grape') ||
          prodName.includes('guava') ||
          prodName.includes('watermelon') ||
          prodName.includes('melon') ||
          prodName.includes('kiwi') ||
          (prodName.includes('orange') && !prodName.includes('carrot')) ||
          prodName.includes('fruit');
        if (!isFruit) return false;
      } else if (selectedCategory === 'veggies') {
        if (!isKnownVeggie) return false;
      } else if (selectedCategory === 'meat') {
        const isMeat =
          catSlug.includes('meat') ||
          catName.includes('meat') ||
          catSlug.includes('poultry') ||
          prodName.includes('chicken') ||
          prodName.includes('mutton') ||
          prodName.includes('meat') ||
          prodName.includes('egg') ||
          prodName.includes('fish');
        if (!isMeat) return false;
      } else if (selectedCategory === 'bakery') {
        const isBakery =
          catSlug.includes('bakery') ||
          catName.includes('bakery') ||
          catSlug.includes('bread') ||
          prodName.includes('bread') ||
          prodName.includes('loaf') ||
          prodName.includes('sourdough') ||
          prodName.includes('croissant') ||
          prodName.includes('toast') ||
          prodName.includes('bun') ||
          prodName.includes('bakery');
        if (!isBakery) return false;
      }
    }

    // 3. Sub filter (All, Organic, Fresh, Deals)
    if (activeFilter === 'organic') {
      return (
        p.name?.toLowerCase().includes('organic') ||
        p.description?.toLowerCase().includes('organic') ||
        p.badge === 'ORGANIC' ||
        p.tags?.includes('organic')
      );
    }
    if (activeFilter === 'fresh') {
      return (
        p.name?.toLowerCase().includes('fresh') ||
        p.description?.toLowerCase().includes('fresh') ||
        p.badge === 'FRESH'
      );
    }
    if (activeFilter === 'deals') {
      return Boolean(p.comparePrice && p.comparePrice > p.price);
    }
    return true;
  });

  const toggleFav = (id) => {
    setFavorites((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAddToCart = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const isMongoId = /^[0-9a-fA-F]{24}$/.test(product._id);
    if (isAuthenticated && isMongoId) {
      addToCartMutation({
        variables: {
          input: { productId: product._id, quantity: 1, variantIndex: -1 },
        },
      });
    } else {
      addItemLocal(product, 1);
      toast.success('Added to cart!');
    }
  };

  const handleIncrement = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const cartItem = getCartItem(product);
    if (!cartItem) {
      handleAddToCart(product, e);
      return;
    }

    const nextQty = (cartItem.quantity || 1) + 1;
    const isServerItem = Boolean(cartItem._id && !String(cartItem._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(cartItem._id));

    if (isAuthenticated && isServerItem) {
      updateCartItemMutation({ variables: { itemId: cartItem._id, quantity: nextQty } });
    } else {
      updateQuantityLocal(cartItem._id, nextQty);
    }
  };

  const handleDecrement = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const cartItem = getCartItem(product);
    if (!cartItem) return;

    const currentQty = cartItem.quantity || 1;
    const isServerItem = Boolean(cartItem._id && !String(cartItem._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(cartItem._id));

    if (currentQty <= 1) {
      if (isAuthenticated && isServerItem) {
        removeFromCartMutation({ variables: { itemId: cartItem._id } });
      } else {
        removeItemLocal(cartItem._id);
      }
    } else {
      const nextQty = currentQty - 1;
      if (isAuthenticated && isServerItem) {
        updateCartItemMutation({ variables: { itemId: cartItem._id, quantity: nextQty } });
      } else {
        updateQuantityLocal(cartItem._id, nextQty);
      }
    }
  };

  return (
    <div className="w-full max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Location & Fresh Header Strip */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div className="flex items-center gap-2 text-sm text-gray-600">
          <MapPinIcon className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <span>Deliver to:</span>
          <span className="font-extrabold text-gray-900">123 Maple St (250001)</span>
        </div>

        {/* Grocery Search Bar */}
        <div className="relative w-full sm:w-80">
          <MagnifyingGlassIcon className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search fresh groceries..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-emerald-500 focus:bg-white transition-all"
          />
        </div>
      </div>

      {/* Quick Category Tabs (Interactive with active selection) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {GROCERY_CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory((prev) => (prev === cat.id ? 'all' : cat.id))}
              className={`flex items-center gap-3 p-4 rounded-2xl transition-all cursor-pointer group text-left ${
                isSelected
                  ? 'bg-emerald-50 border-2 border-emerald-500 shadow-md ring-2 ring-emerald-500/20'
                  : 'bg-[#E0F2FE] hover:bg-[#BAE6FD] border border-[#BFDBFE] hover:shadow-xs'
              }`}
            >
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center text-2xl transition-transform ${
                  isSelected
                    ? 'bg-emerald-500 text-white shadow-sm scale-105'
                    : 'bg-white shadow-xs group-hover:scale-105'
                }`}
              >
                {cat.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h4
                    className={`font-bold text-sm truncate transition-colors ${
                      isSelected ? 'text-emerald-900' : 'text-gray-900 group-hover:text-emerald-700'
                    }`}
                  >
                    {cat.name}
                  </h4>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0 animate-pulse" />
                  )}
                </div>
                <p className={`text-[11px] font-medium ${isSelected ? 'text-emerald-700' : 'text-gray-500'}`}>
                  {isSelected ? 'Selected' : '100% Fresh'}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Hero Banner: WEEKLY DEALS (Matching Reference 1) */}
      <div className="relative rounded-3xl overflow-hidden shadow-md min-h-[220px] sm:min-h-[260px] flex items-center">
        <img
          src="https://images.unsplash.com/photo-1540420773420-3366772f4999?w=1200"
          alt="Fresh Greens"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-900/50 to-transparent" />
        <div className="relative z-10 p-8 sm:p-12 max-w-xl text-white space-y-3">
          <span className="text-xs font-black tracking-wider text-emerald-400 uppercase">
            WEEKLY DEALS
          </span>
          <h2 className="text-2xl sm:text-4xl font-black leading-tight">
            Fresh Greens,<br />Lower Prices
          </h2>
          <button
            onClick={() => setActiveFilter('deals')}
            className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm px-6 py-2.5 rounded-xl shadow-md transition-all hover:scale-105 cursor-pointer"
          >
            Shop Deals
          </button>
        </div>
      </div>

      {/* Filter Tabs Section (Matching Reference 2) */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h3 className="text-2xl font-black text-gray-900">
                {selectedCategory === 'fruits'
                  ? 'Fresh Fruits'
                  : selectedCategory === 'veggies'
                  ? 'Farm-Fresh Vegetables'
                  : selectedCategory === 'meat'
                  ? 'Fresh Meat & Poultry'
                  : selectedCategory === 'bakery'
                  ? 'Bakery & Fresh Breads'
                  : 'Fruits & Vegetables'}
              </h3>
              {selectedCategory !== 'all' && (
                <button
                  onClick={() => setSelectedCategory('all')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100/70 hover:bg-emerald-200 px-3 py-1 rounded-full border border-emerald-200 transition-all cursor-pointer"
                >
                  <span>All Groceries</span>
                  <span className="text-emerald-500">✕</span>
                </button>
              )}
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              {selectedCategory === 'fruits'
                ? 'Naturally ripened, sweet & crisp organic fruits'
                : selectedCategory === 'veggies'
                ? 'Crisp farm-fresh vegetables delivered in hours'
                : selectedCategory === 'meat'
                ? 'Hygienic, antibiotic-free fresh cuts'
                : selectedCategory === 'bakery'
                ? 'Slow-fermented artisan loaves and morning bakes'
                : 'Handpicked farm-fresh items delivered within hours'}
            </p>
          </div>


        </div>

        {/* 4-Column Product Grid (Matching Reference 2) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredProducts.map((prod) => {
            const isFav = favorites[prod._id];
            const badgeText = prod.badge || (prod.comparePrice > prod.price ? 'SALE' : null);
            const isSale = badgeText === 'SALE';
            const cartItem = getCartItem(prod);
            const quantity = cartItem?.quantity || 0;

            return (
              <Link
                key={prod._id}
                href={`/products/${prod.slug || prod._id}`}
                className="group relative bg-white border border-gray-100 rounded-3xl p-4 flex flex-col justify-between hover:shadow-lg transition-all duration-200"
              >
                {/* Badge Tag (SALE in orange, ORGANIC in green) */}
                {badgeText && (
                  <span
                    className={`absolute top-3 left-3 z-10 text-[9px] font-black tracking-wider px-2 py-0.5 rounded-lg text-white ${
                      isSale ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                  >
                    {badgeText}
                  </span>
                )}

                {/* Heart Wishlist */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleFav(prod._id);
                  }}
                  className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/90 shadow-xs flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors"
                >
                  {isFav ? (
                    <HeartIcon className="w-4 h-4 text-red-500" />
                  ) : (
                    <HeartOutline className="w-4 h-4 text-gray-400" />
                  )}
                </button>

                {/* Product Image */}
                <div className="w-full h-44 rounded-2xl bg-gray-50/50 flex items-center justify-center p-2 mb-3 overflow-hidden">
                  <img
                    src={prod.images?.[0] || 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400'}
                    alt={prod.name}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                  />
                </div>

                {/* Unit info above title */}
                <span className="text-[11px] font-semibold text-gray-500 block">
                  {prod.unitMeasure || '500g'}
                </span>

                {/* Title */}
                <h4 className="font-extrabold text-sm text-gray-900 group-hover:text-emerald-600 transition-colors line-clamp-2 mt-1 min-h-[38px]">
                  {prod.name}
                </h4>

                {/* Price and Add/Counter Button */}
                <div className="flex items-center justify-between pt-3 mt-auto border-t border-gray-50">
                  <div>
                    {prod.comparePrice && prod.comparePrice > prod.price && (
                      <span className="text-xs text-gray-400 line-through block font-medium">
                        ₹{Number(prod.comparePrice).toFixed(2)}
                      </span>
                    )}
                    <span className="text-base font-black text-gray-900">
                      ₹{Number(prod.price).toFixed(2)}
                    </span>
                  </div>

                  {quantity > 0 ? (
                    <div 
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
                      className="flex items-center bg-gray-50 border border-emerald-300 rounded-full px-1.5 py-1 shadow-xs"
                    >
                      <button
                        type="button"
                        onClick={(e) => handleDecrement(prod, e)}
                        className="w-7 h-7 rounded-full bg-white hover:bg-red-50 text-gray-700 hover:text-red-600 border border-gray-200 flex items-center justify-center transition-all active:scale-90"
                        title="Decrease quantity"
                      >
                        <MinusIcon className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                      <span className="w-7 text-center font-black text-sm text-gray-900 select-none">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => handleIncrement(prod, e)}
                        className="w-7 h-7 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center transition-all active:scale-90 shadow-xs"
                        title="Increase quantity"
                      >
                        <PlusIcon className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={(e) => handleAddToCart(prod, e)}
                      className="w-9 h-9 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-xs transition-transform active:scale-95"
                      title="Add to cart"
                    >
                      <PlusIcon className="w-4 h-4 stroke-[3]" />
                    </button>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
