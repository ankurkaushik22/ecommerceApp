'use client';
import { useState, useMemo } from 'react';
import Link from 'next/link';
import { useQuery, useMutation } from '@apollo/client';
import {
  MagnifyingGlassIcon,
  MapPinIcon,
  PlusIcon,
  MinusIcon,
  HeartIcon,
  ArrowUpIcon,
} from '@heroicons/react/24/solid';
import { HeartIcon as HeartOutline, ArrowRightIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_PRODUCTS, GET_CART, GET_STORE_SETTINGS, GET_CATEGORIES } from '@/graphql/queries';
import { ADD_TO_CART, UPDATE_CART_ITEM, REMOVE_FROM_CART } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import HeroBanner from '@/components/shop/HeroBanner';
import { filterItemsByVertical } from '@/utils/cartHelpers';



const ALL_GROCERY_FALLBACKS = [
  {
    _id: 'g-fizzy-1',
    name: 'Diet Coke Diets & Lights',
    slug: 'diet-coke-diets-lights',
    unitMeasure: '330 ml',
    optionsCount: 2,
    price: 50,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.8, count: 210 },
  },
  {
    _id: 'g-fizzy-2',
    name: 'Thums Up Soft Drink',
    slug: 'thums-up-soft-drink-750ml',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 39,
    comparePrice: 40,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.9, count: 340 },
  },
  {
    _id: 'g-fizzy-3',
    name: 'Thums Up Soft Drink',
    slug: 'thums-up-soft-drink-1ltr',
    unitMeasure: '1 ltr',
    optionsCount: null,
    price: 50,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.8, count: 180 },
  },
  {
    _id: 'g-fizzy-4',
    name: 'Sprite Lemon-Lime Soft Drink',
    slug: 'sprite-lemon-lime-soft-drink',
    unitMeasure: '750 ml',
    optionsCount: null,
    price: 36,
    comparePrice: 40,
    discountTag: '10% OFF on MRP',
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.7, count: 195 },
  },
  {
    _id: 'g-fizzy-5',
    name: "Limca Lemon 'N' Lime",
    slug: 'limca-lemon-n-lime',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 40,
    comparePrice: null,
    discountTag: null,
    isVeg: true,
    tagBadge: null,
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.6, count: 140 },
  },
  {
    _id: 'g-fizzy-6',
    name: 'Coca-Cola Soft Drink',
    slug: 'coca-cola-soft-drink',
    unitMeasure: '750 ml',
    optionsCount: 3,
    price: 38,
    comparePrice: 40,
    discountTag: '5% OFF on MRP',
    isVeg: true,
    tagBadge: 'Chilled',
    deliveryMins: '14 mins',
    images: ['https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400'],
    category: { slug: 'drinks', name: 'Drinks & Juices' },
    rating: { average: 4.9, count: 510 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd22',
    name: 'Organic Yellow Bananas (Robusta)',
    slug: 'organic-yellow-bananas-robusta',
    unitMeasure: '500g (3-4 pcs)',
    optionsCount: null,
    price: 49,
    comparePrice: 65,
    discountTag: '24% OFF',
    isVeg: true,
    tagBadge: 'ORGANIC',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=500'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.8, count: 210 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd25',
    name: 'Crisp Red Fuji Apples',
    slug: 'crisp-red-fuji-apples',
    unitMeasure: '1kg (Approx 4-5 pcs)',
    optionsCount: null,
    price: 149,
    comparePrice: 199,
    discountTag: '25% OFF',
    isVeg: true,
    tagBadge: 'SALE',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=500'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.9, count: 180 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd28',
    name: 'Ready-to-eat Hass Avocados',
    slug: 'ready-to-eat-hass-avocados',
    unitMeasure: '2 pcs pack',
    optionsCount: null,
    price: 199,
    comparePrice: 249,
    discountTag: '20% OFF',
    isVeg: true,
    tagBadge: 'ORGANIC',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=500'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.9, count: 128 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd2b',
    name: 'Hydroponic Fresh Baby Spinach',
    slug: 'hydroponic-fresh-baby-spinach-palak',
    unitMeasure: '250g Pack',
    optionsCount: null,
    price: 39,
    comparePrice: 55,
    discountTag: '29% OFF',
    isVeg: true,
    tagBadge: 'FRESH',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=500'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.7, count: 140 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd2e',
    name: 'Fresh Crunchy Orange Carrots',
    slug: 'fresh-crunchy-orange-carrots',
    unitMeasure: '500g',
    optionsCount: null,
    price: 45,
    comparePrice: 60,
    discountTag: '25% OFF',
    isVeg: true,
    tagBadge: 'ORGANIC',
    deliveryMins: '12 mins',
    images: ['https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=500'],
    category: { slug: 'vegetables', name: 'Vegetables & Fruits' },
    rating: { average: 4.8, count: 88 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd34',
    name: 'Farm Fresh Pure Whole Cow Milk',
    slug: 'farm-fresh-pure-whole-cow-milk',
    unitMeasure: '1 Litre Pouch',
    optionsCount: null,
    price: 68,
    comparePrice: 75,
    discountTag: '9% OFF',
    isVeg: true,
    tagBadge: 'FRESH',
    deliveryMins: '10 mins',
    images: ['https://images.unsplash.com/photo-1563636619-e9143da7973b?w=500'],
    category: { slug: 'dairy', name: 'Dairy, Bread & Eggs' },
    rating: { average: 4.9, count: 320 },
  },
  {
    _id: '6a98798bc87f422f2bb5fd37',
    name: 'Artisan Sourdough Country Loaf',
    slug: 'artisan-sourdough-country-loaf',
    unitMeasure: '400g Loaf',
    optionsCount: null,
    price: 99,
    comparePrice: 130,
    discountTag: '23% OFF',
    isVeg: true,
    tagBadge: 'FRESH',
    deliveryMins: '15 mins',
    images: ['https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?w=500'],
    category: { slug: 'bakery', name: 'Bakery & Biscuits' },
    rating: { average: 4.8, count: 75 },
  },
  {
    _id: '6a987d124d090c15299b7dc1',
    name: 'Tender Fresh Chicken Breast (Boneless)',
    slug: 'tender-fresh-chicken-breast-boneless',
    unitMeasure: '500g Pack',
    optionsCount: null,
    price: 189,
    comparePrice: 220,
    discountTag: '14% OFF',
    isVeg: false,
    tagBadge: 'FRESH',
    deliveryMins: '20 mins',
    images: ['https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=500'],
    category: { slug: 'meat', name: 'Chicken, Meat & Fish' },
    rating: { average: 4.9, count: 190 },
  },
];

export default function GroceryPage() {
  const { isAuthenticated } = useAuthStore();
  const [selectedTopTab, setSelectedTopTab] = useState('all');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState('all');
  const [activeFilter, setActiveFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [favorites, setFavorites] = useState({});

  // Local guest cart
  const {
    items: localCartItems,
    addItem: addItemLocal,
    updateQuantity: updateQuantityLocal,
    removeItem: removeItemLocal,
  } = useCartStore();

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);

  const { data: categoriesData } = useQuery(GET_CATEGORIES, {
    variables: { vertical: 'grocery' },
    fetchPolicy: 'cache-and-network',
  });

  const dbCategories = categoriesData?.getCategories || [];

  const topTabs = useMemo(() => {
    const defaultAll = { id: 'all', name: 'All' };
    if (!dbCategories || dbCategories.length === 0) return [defaultAll];
    return [
      defaultAll,
      ...dbCategories.map((cat) => ({
        id: cat.slug || cat._id,
        name: cat.name,
        slug: cat.slug || cat._id,
      })),
    ];
  }, [dbCategories]);

  const categorySections = useMemo(() => {
    if (!dbCategories || dbCategories.length === 0) return [];

    const hasParentChild = dbCategories.some((c) => c.children && c.children.length > 0);

    if (hasParentChild) {
      return dbCategories.map((parent) => ({
        id: parent._id,
        title: parent.name,
        items: (parent.children && parent.children.length > 0) ? parent.children : [parent],
      }));
    }

    return [
      {
        id: 'grocery-categories',
        title: 'Explore Categories',
        items: dbCategories,
      },
    ];
  }, [dbCategories]);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: { vertical: 'grocery' },
      pagination: { page: 1, limit: 50 },
    },
    fetchPolicy: 'cache-and-network',
  });

  // Server cart data
  const { data: cartData, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [addToCartMutation] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      toast.success('Added to cart!');
      refetchCart();
    },
    onError: (err) => {
      console.error('addToCart error:', err);
    },
  });

  const [updateCartItemMutation] = useMutation(UPDATE_CART_ITEM, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('updateCartItem error:', err),
  });

  const [removeFromCartMutation] = useMutation(REMOVE_FROM_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => refetchCart(),
    onError: (err) => console.error('removeFromCart error:', err),
  });

  const disabledVerticals = settingsData?.getStoreSettings?.disabledVerticals || [];
  if (disabledVerticals.includes('grocery')) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-24 text-center space-y-4">
        <p className="text-6xl">🥦</p>
        <h1 className="text-2xl font-bold text-gray-900">Grocery Store Currently Unavailable</h1>
        <Link href="/" className="btn-brand inline-block text-sm px-6 py-2.5 rounded-xl font-bold">
          Return to Home
        </Link>
      </div>
    );
  }

  const serverCartItems = cartData?.getCart?.items || [];
  const currentCartItems =
    isAuthenticated && serverCartItems.length > 0
      ? serverCartItems
      : localCartItems.length > 0
      ? localCartItems
      : serverCartItems;

  const groceryCartItems = filterItemsByVertical(currentCartItems || [], 'grocery');
  const totalGroceryItems = groceryCartItems.reduce((sum, i) => sum + (i.quantity || 1), 0);
  const totalGroceryAmount = groceryCartItems.reduce((sum, i) => sum + (Number(i.price || i.product?.price || 0) * Number(i.quantity || 1)), 0);

  const getCartItem = (product) => {
    return currentCartItems.find(
      (item) => (item.product?._id || item.product?.id || item.product) === product._id
    );
  };

  const fetched = data?.getProducts?.products;
  const allProducts = useMemo(() => {
    if (!fetched || fetched.length === 0) return ALL_GROCERY_FALLBACKS;
    const fetchedIds = new Set(fetched.map((p) => p._id));
    const uniqueFallbacks = ALL_GROCERY_FALLBACKS.filter((f) => !fetchedIds.has(f._id));
    return [...fetched, ...uniqueFallbacks];
  }, [fetched]);

  const filteredProducts = useMemo(() => {
    return allProducts.filter((p) => {
      // 1. Search filter
      if (search.trim()) {
        const q = search.toLowerCase();
        const matchName = p.name?.toLowerCase().includes(q);
        const matchDesc = p.description?.toLowerCase().includes(q);
        const matchCat = p.category?.name?.toLowerCase().includes(q);
        if (!matchName && !matchDesc && !matchCat) return false;
      }

      // 2. Top Tab Filter
      if (selectedTopTab !== 'all') {
        const cName = (p.category?.name || '').toLowerCase();
        const cSlug = (p.category?.slug || p.category?._id || '').toLowerCase();
        const target = selectedTopTab.toLowerCase();
        const matches = cName.includes(target) || cSlug.includes(target) || (p.name || '').toLowerCase().includes(target);
        if (!matches) return false;
      }

      // 3. Category Tile Filter
      if (selectedCategorySlug !== 'all') {
        const catSlug = (p.category?.slug || '').toLowerCase();
        const catName = (p.category?.name || '').toLowerCase();
        const prodName = (p.name || '').toLowerCase();
        const target = selectedCategorySlug.toLowerCase();

        const matchCat = catSlug.includes(target) || catName.includes(target) || prodName.includes(target);
        if (!matchCat) return false;
      }

      // 4. Sub Filter (Organic, Fresh, Deals)
      if (activeFilter === 'organic') {
        return (
          p.name?.toLowerCase().includes('organic') ||
          p.description?.toLowerCase().includes('organic') ||
          p.badge === 'ORGANIC' ||
          p.tagBadge === 'Organic'
        );
      }
      if (activeFilter === 'fresh') {
        return (
          p.name?.toLowerCase().includes('fresh') ||
          p.description?.toLowerCase().includes('fresh') ||
          p.badge === 'FRESH' ||
          p.tagBadge === 'Fresh'
        );
      }
      if (activeFilter === 'deals') {
        return Boolean((p.comparePrice && p.comparePrice > p.price) || p.discountTag);
      }

      return true;
    });
  }, [allProducts, search, selectedTopTab, selectedCategorySlug, activeFilter]);

  const toggleFav = (id) => {
    setFavorites((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAddToCart = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const isMongoId = /^[0-9a-fA-F]{24}$/.test(product._id);
    if (isAuthenticated && isMongoId) {
      addToCartMutation({
        variables: {
          input: { productId: product._id, quantity: 1, variantIndex: -1 },
        },
      });
    } else {
      addItemLocal(product, 1);
      toast.success('Added to cart!');
    }
  };

  const handleIncrement = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const cartItem = getCartItem(product);
    if (!cartItem) {
      handleAddToCart(product, e);
      return;
    }

    const nextQty = (cartItem.quantity || 1) + 1;
    const isServerItem = Boolean(
      cartItem._id &&
        !String(cartItem._id).startsWith('local-') &&
        /^[0-9a-fA-F]{24}$/.test(cartItem._id)
    );

    if (isAuthenticated && isServerItem) {
      updateCartItemMutation({ variables: { itemId: cartItem._id, quantity: nextQty } });
    } else {
      updateQuantityLocal(cartItem._id, nextQty);
    }
  };

  const handleDecrement = (product, e) => {
    e.preventDefault();
    e.stopPropagation();
    const cartItem = getCartItem(product);
    if (!cartItem) return;

    const currentQty = cartItem.quantity || 1;
    const isServerItem = Boolean(
      cartItem._id &&
        !String(cartItem._id).startsWith('local-') &&
        /^[0-9a-fA-F]{24}$/.test(cartItem._id)
    );

    if (currentQty <= 1) {
      if (isAuthenticated && isServerItem) {
        removeFromCartMutation({ variables: { itemId: cartItem._id } });
      } else {
        removeItemLocal(cartItem._id);
      }
    } else {
      const nextQty = currentQty - 1;
      if (isAuthenticated && isServerItem) {
        updateCartItemMutation({ variables: { itemId: cartItem._id, quantity: nextQty } });
      } else {
        updateQuantityLocal(cartItem._id, nextQty);
      }
    }
  };

  return (
    <div className="w-full max-w-[1500px] mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-6">
      {/* 1. Header Location & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div className="flex items-center gap-2 text-sm text-gray-700">
          <MapPinIcon className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <span className="text-gray-500 font-medium">Deliver to:</span>
          <span className="font-extrabold text-gray-900">Home - 123 Maple St (250001)</span>
        </div>

        {/* Search input with Blinkit-style placeholder */}
        <div className="relative flex-1 sm:max-w-md">
          <MagnifyingGlassIcon className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search for atta, dal, coke and more..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-sm bg-gray-50 border border-gray-200 rounded-full focus:outline-none focus:border-emerald-500 focus:bg-white transition-all shadow-xs"
          />
        </div>
      </div>

      {/* 2. Top Category Horizontal Navigation Strip */}
      <div className="flex items-center space-x-2 border-b border-gray-200 overflow-x-auto pb-1 no-scrollbar">
        {topTabs.map((tab) => {
          const isActive = selectedTopTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setSelectedTopTab(tab.id);
                setSelectedCategorySlug('all');
              }}
              className={`relative px-4 py-2.5 text-sm font-bold whitespace-nowrap transition-colors flex items-center gap-2 cursor-pointer ${
                isActive ? 'text-emerald-700' : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <span>{tab.name}</span>
              {tab.badge && (
                <span className="bg-amber-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full uppercase">
                  {tab.badge}
                </span>
              )}
              {isActive && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600 rounded-t-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* 3. Hero Banner Carousel */}
      <HeroBanner vertical="grocery" />

      {/* Dynamic Category Grid Sections from Admin DB */}
      {categorySections.map((sec) => (
        <div key={sec.id} className="space-y-3 pt-2">
          <h3 className="text-xl font-black text-gray-900 tracking-tight">{sec.title}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
            {sec.items.map((cat) => {
              const catSlug = cat.slug || cat._id;
              const isSelected = selectedCategorySlug === catSlug;
              return (
                <button
                  key={cat._id || cat.id}
                  onClick={() =>
                    setSelectedCategorySlug((prev) => (prev === catSlug ? 'all' : catSlug))
                  }
                  className={`group flex flex-col items-center justify-center p-3 sm:p-4 rounded-3xl transition-all cursor-pointer border text-center ${
                    isSelected
                      ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20 shadow-md scale-[1.02]'
                      : 'bg-white border-gray-100/80 hover:border-emerald-200 hover:shadow-xl hover:-translate-y-0.5 shadow-xs'
                  }`}
                >
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-gray-50 mb-2.5 flex items-center justify-center p-0.5 shadow-2xs">
                    <img
                      src={cat.image || cat.icon || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=300'}
                      alt={cat.name}
                      className="w-full h-full object-cover rounded-xl group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <span className={`text-xs font-black line-clamp-2 leading-tight ${isSelected ? 'text-emerald-900' : 'text-gray-900 group-hover:text-emerald-700'}`}>
                    {cat.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {/* 7. Product List Section */}
      <div className="space-y-4 pt-4 border-t border-gray-100">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h3 className="text-2xl font-black text-gray-900">
              {selectedCategorySlug !== 'all'
                ? `Items in ${dbCategories.find((c) => (c.slug || c._id) === selectedCategorySlug)?.name || selectedCategorySlug}`
                : selectedTopTab !== 'all'
                ? `${topTabs.find((t) => t.id === selectedTopTab)?.name || selectedTopTab} Items`
                : 'All Grocery Items'}
            </h3>
            {(selectedCategorySlug !== 'all' || selectedTopTab !== 'all') && (
              <button
                onClick={() => {
                  setSelectedCategorySlug('all');
                  setSelectedTopTab('all');
                }}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100/80 hover:bg-emerald-200 px-3 py-1 rounded-full border border-emerald-200 transition-all cursor-pointer"
              >
                <span>Reset Filters</span>
                <span className="text-emerald-600">✕</span>
              </button>
            )}
          </div>

          {/* Sub Filters (All, Organic, Fresh, Deals) */}
          <div className="flex items-center space-x-2 bg-gray-100 p-1 rounded-xl">
            {['all', 'organic', 'fresh', 'deals'].map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`px-3 py-1.5 text-xs font-extrabold rounded-lg capitalize transition-all cursor-pointer ${
                  activeFilter === f
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid (4 Columns) */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-gray-50 rounded-3xl border border-gray-100 space-y-3">
            <p className="text-4xl">🛒</p>
            <h4 className="text-lg font-bold text-gray-800">No items found matching your filters</h4>
            <button
              onClick={() => {
                setSearch('');
                setSelectedCategorySlug('all');
                setSelectedTopTab('all');
                setActiveFilter('all');
              }}
              className="text-xs font-bold text-emerald-600 hover:underline"
            >
              Clear all filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {filteredProducts.map((prod) => {
              const isFav = favorites[prod._id];
              const cartItem = getCartItem(prod);
              const quantity = cartItem?.quantity || 0;

              return (
                <Link
                  key={prod._id}
                  href={`/products/${prod.slug || prod._id}`}
                  className="group relative bg-white border border-gray-100 rounded-3xl p-4 flex flex-col justify-between hover:shadow-xl hover:border-emerald-100 transition-all duration-200"
                >
                  {/* Top Badges Header */}
                  <div className="flex items-center justify-between gap-1 mb-2 z-10">
                    <div className="flex items-center gap-1.5">
                      {/* Veg indicator badge */}
                      <span
                        className="w-4 h-4 border border-emerald-600 flex items-center justify-center p-0.5 rounded-[3px] bg-white shadow-2xs"
                        title={prod.isVeg !== false ? 'Pure Veg' : 'Non-Veg'}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${
                            prod.isVeg !== false ? 'bg-emerald-600' : 'bg-red-600'
                          }`}
                        />
                      </span>

                      {/* Delivery Mins */}
                      <span className="text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200/80 px-1.5 py-0.5 rounded-md flex items-center gap-1">
                        <span>⏱️</span>
                        <span>{prod.deliveryMins || '14 mins'}</span>
                      </span>
                    </div>

                    {/* Wishlist Heart */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleFav(prod._id);
                      }}
                      className="w-7 h-7 rounded-full bg-white/90 shadow-xs border border-gray-100 flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors"
                    >
                      {isFav ? (
                        <HeartIcon className="w-4 h-4 text-red-500" />
                      ) : (
                        <HeartOutline className="w-4 h-4 text-gray-400" />
                      )}
                    </button>
                  </div>

                  {/* Product Image */}
                  <div className="w-full h-36 rounded-2xl bg-gray-50/50 flex items-center justify-center p-2 mb-2 overflow-hidden relative">
                    <img
                      src={
                        prod.images?.[0] ||
                        'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400'
                      }
                      alt={prod.name}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Discount or Tag Badge */}
                    {(prod.discountTag || prod.tagBadge || prod.badge) && (
                      <span className="absolute bottom-2 left-2 text-[9px] font-black bg-emerald-600 text-white px-2 py-0.5 rounded-md shadow-xs uppercase tracking-wider">
                        {prod.discountTag || prod.tagBadge || prod.badge}
                      </span>
                    )}
                  </div>

                  {/* Options count or unit measure */}
                  <div className="flex items-center justify-between text-[11px] font-semibold text-gray-500 mb-1">
                    <span>{prod.unitMeasure || '500g'}</span>
                    {prod.optionsCount && (
                      <span className="text-[10px] bg-gray-100 text-gray-700 px-1.5 py-0.5 rounded-md font-bold">
                        {prod.optionsCount} options
                      </span>
                    )}
                  </div>

                  {/* Product Title */}
                  <h4 className="font-extrabold text-sm text-gray-900 group-hover:text-emerald-700 transition-colors line-clamp-2 min-h-[38px] leading-snug">
                    {prod.name}
                  </h4>

                  {/* Price & Add to Cart Counter */}
                  <div className="flex items-center justify-between pt-3 mt-auto border-t border-gray-100">
                    <div>
                      {prod.comparePrice && prod.comparePrice > prod.price && (
                        <span className="text-xs text-gray-400 line-through block font-medium">
                          ₹{Number(prod.comparePrice).toFixed(0)}
                        </span>
                      )}
                      <span className="text-base font-black text-gray-900">
                        ₹{Number(prod.price).toFixed(0)}
                      </span>
                    </div>

                    {quantity > 0 ? (
                      <div
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                        }}
                        className="flex items-center bg-emerald-50 border border-emerald-500 rounded-full px-1 py-0.5 shadow-xs"
                      >
                        <button
                          type="button"
                          onClick={(e) => handleDecrement(prod, e)}
                          className="w-6 h-6 rounded-full bg-white text-emerald-800 hover:bg-emerald-100 border border-emerald-300 flex items-center justify-center transition-all active:scale-90"
                          title="Decrease quantity"
                        >
                          <MinusIcon className="w-3 h-3 stroke-[3]" />
                        </button>
                        <span className="w-6 text-center font-black text-xs text-emerald-900 select-none">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => handleIncrement(prod, e)}
                          className="w-6 h-6 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center transition-all active:scale-90 shadow-xs"
                          title="Increase quantity"
                        >
                          <PlusIcon className="w-3 h-3 stroke-[3]" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => handleAddToCart(prod, e)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-600 border border-emerald-500 text-emerald-700 hover:text-white font-extrabold text-xs flex items-center gap-1 shadow-xs transition-all active:scale-95 cursor-pointer"
                      >
                        <span>ADD</span>
                        <PlusIcon className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>

      {totalGroceryItems > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-2xl p-4 shadow-2xl flex items-center justify-between border border-emerald-400/30">
            <div>
              <p className="text-[11px] font-black uppercase tracking-wider text-emerald-100">
                {totalGroceryItems} {totalGroceryItems === 1 ? 'Item' : 'Items'} Added
              </p>
              <p className="text-lg font-black text-white">₹{totalGroceryAmount.toLocaleString('en-IN')}</p>
            </div>
            <Link
              href="/cart"
              className="bg-white text-emerald-700 hover:bg-emerald-50 font-black text-xs uppercase tracking-wider px-5 py-2.5 rounded-xl flex items-center gap-2 transition-all shadow-md active:scale-95"
            >
              <span>View Cart</span>
              <ArrowRightIcon className="w-4 h-4" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
