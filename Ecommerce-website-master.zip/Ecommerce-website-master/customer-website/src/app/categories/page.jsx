'use client';
import { useState, useMemo } from 'react';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import Image from 'next/image';
import {
  MagnifyingGlassIcon,
  ShoppingBagIcon,
  SparklesIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';
import { GET_ALL_CATEGORIES } from '@/graphql/queries';

const FALLBACK_CATEGORIES = [
  // Shopping
  {
    _id: 'c-elec',
    name: 'Electronics',
    slug: 'electronics',
    vertical: 'shopping',
    icon: '💻',
    image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400',
    description: 'Smartphones, laptops, headphones, smart TVs & premium gadgets',
  },
  {
    _id: 'c-cloth',
    name: 'Clothing & Fashion',
    slug: 'clothing',
    vertical: 'shopping',
    icon: '👔',
    image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=400',
    description: 'Suits, dresses, jackets, denim, footwear & daily essentials',
  },
  {
    _id: 'c-home',
    name: 'Home & Kitchen',
    slug: 'home-and-kitchen',
    vertical: 'shopping',
    icon: '🍳',
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=400',
    description: 'Cookware, air fryers, coffee makers, blenders & home decor',
  },
  {
    _id: 'c-beauty',
    name: 'Beauty & Health',
    slug: 'beauty-and-health',
    vertical: 'shopping',
    icon: '✨',
    image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400',
    description: 'Skincare serums, perfumes, hair care & wellness products',
  },
  {
    _id: 'c-sports',
    name: 'Sports & Outdoors',
    slug: 'sports-and-outdoors',
    vertical: 'shopping',
    icon: '⚽',
    image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400',
    description: 'Gym equipment, running shoes, yoga mats & outdoor sports gear',
  },
  {
    _id: 'c-jewel',
    name: 'Jewelry & Watches',
    slug: 'jewelry',
    vertical: 'shopping',
    icon: '💎',
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400',
    description: 'Diamond rings, gold chains, luxury watches & sparkling earrings',
  },
  {
    _id: 'c-books',
    name: 'Books & Stationery',
    slug: 'books',
    vertical: 'shopping',
    icon: '📚',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
    description: 'Bestsellers, self-help, business, fiction & educational books',
  },
  {
    _id: 'c-auto',
    name: 'Automotive Accessories',
    slug: 'automotive',
    vertical: 'shopping',
    icon: '🚗',
    image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=400',
    description: 'Dash cams, tire inflators, car vacuum cleaners & car care kits',
  },

  // Grocery
  {
    _id: 'g-fruits',
    name: 'Fresh Fruits',
    slug: 'fresh-fruits',
    vertical: 'grocery',
    icon: '🍎',
    image: 'https://images.unsplash.com/photo-1619566636858-adf3ef46400b?w=400',
    description: 'Organic apples, bananas, avocados, berries & seasonal fruits',
  },
  {
    _id: 'g-veggies',
    name: 'Fresh Vegetables',
    slug: 'fresh-vegetables',
    vertical: 'grocery',
    icon: '🥦',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400',
    description: 'Farm-fresh hydroponic spinach, carrots, tomatoes & daily greens',
  },
  {
    _id: 'g-dairy',
    name: 'Dairy & Breakfast',
    slug: 'dairy-breakfast',
    vertical: 'grocery',
    icon: '🥛',
    image: 'https://images.unsplash.com/photo-1528732263440-4dd1a18a4cc2?w=400',
    description: 'Pure whole milk, farm brown eggs, paneer, butter & yogurt',
  },
  {
    _id: 'g-bakery',
    name: 'Bakery & Breads',
    slug: 'bakery-breads',
    vertical: 'grocery',
    icon: '🍞',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400',
    description: 'Artisan sourdough, multigrain loaves, buns & breakfast toasts',
  },
  {
    _id: 'g-meat',
    name: 'Fresh Meat & Poultry',
    slug: 'meat',
    vertical: 'grocery',
    icon: '🍗',
    image: 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400',
    description: 'Tender chicken breast, mutton curry cut & fresh meat cuts',
  },

  // Food
  {
    _id: 'f-biryani',
    name: 'Biryani & Rice Bowls',
    slug: 'biryani-rice',
    vertical: 'food',
    icon: '🍛',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400',
    description: 'Hyderabadi chicken dum biryani, Awadhi veg biryani & kebabs',
  },
  {
    _id: 'f-pizza',
    name: 'Pizzas & Pastas',
    slug: 'pizzas-pasta',
    vertical: 'food',
    icon: '🍕',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400',
    description: 'Gourmet wood-fired pizzas, garlic bread & creamy pastas',
  },
  {
    _id: 'f-burgers',
    name: 'Burgers & Fast Food',
    slug: 'burgers-fast-food',
    vertical: 'food',
    icon: '🍔',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400',
    description: 'Double patty chicken smash burgers, cheesy fries & wraps',
  },
  {
    _id: 'f-chinese',
    name: 'Chinese & Momos',
    slug: 'chinese-momos',
    vertical: 'food',
    icon: '🥟',
    image: 'https://images.unsplash.com/photo-1541696432-82c6da8ce7bf?w=400',
    description: 'Steamed Himalayan momos, fried dimsums & spicy Hakka noodles',
  },

  // Services
  {
    _id: 's-ac',
    name: 'AC & Appliance Repair',
    slug: 'ac-appliance-repair',
    vertical: 'services',
    icon: '❄️',
    image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400',
    description: 'Jet foam deep service, cooling diagnostics & appliance repair',
  },
  {
    _id: 's-clean',
    name: 'Deep Home Cleaning',
    slug: 'deep-home-cleaning',
    vertical: 'services',
    icon: '🧹',
    image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400',
    description: 'Full house sanitization, kitchen degreasing & sofa cleaning',
  },
  {
    _id: 's-elec',
    name: 'Electrician & Plumber',
    slug: 'electrician-plumber',
    vertical: 'services',
    icon: '🔧',
    image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=400',
    description: 'Wiring repair, socket replacements, pipe leakage fixes & taps',
  },
];

const VERTICAL_TABS = [
  { id: 'all', label: 'All Categories', icon: '🌟' },
  { id: 'shopping', label: '🛍️ Shopping', icon: '🛍️' },
  { id: 'grocery', label: '🥦 Grocery', icon: '🥦' },
  { id: 'food', label: '🍔 Food Delivery', icon: '🍔' },
  { id: 'services', label: '🛠️ Home Services', icon: '🛠️' },
];

const GROCERY_SLUGS = new Set([
  'fresh-fruits', 'fresh-vegetables', 'dairy-breakfast', 'bakery-breads', 'meat',
  'organic-staples', 'beverages', 'snacks-packaged-foods'
]);

const FOOD_SLUGS = new Set([
  'biryani-rice', 'north-indian', 'pizzas-pasta', 'burgers-fast-food',
  'chinese-momos', 'desserts-shakes', 'food-delivery', 'food-and-dining'
]);

const SERVICE_SLUGS = new Set([
  'ac-appliance-repair', 'deep-home-cleaning', 'womens-salon-spa',
  'electrician-plumber', 'painting-woodwork', 'services', 'home-services'
]);

export function getCategoryVertical(cat) {
  if (cat.vertical) return cat.vertical;
  const slug = (cat.slug || '').toLowerCase();
  if (GROCERY_SLUGS.has(slug)) return 'grocery';
  if (FOOD_SLUGS.has(slug)) return 'food';
  if (SERVICE_SLUGS.has(slug)) return 'services';
  return 'shopping';
}

export default function AllCategoriesPage() {
  const [activeTab, setActiveTab] = useState('all');
  const [search, setSearch] = useState('');

  const { data: catData, loading } = useQuery(GET_ALL_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });

  const categories = useMemo(() => {
    const raw = catData?.getAllCategories || [];
    const source = raw.length > 0 ? raw : FALLBACK_CATEGORIES;

    return source.filter((cat) => {
      const vert = getCategoryVertical(cat);
      if (activeTab !== 'all' && vert !== activeTab) return false;

      if (search.trim()) {
        const q = search.toLowerCase();
        const matchesName = (cat.name || '').toLowerCase().includes(q);
        const matchesDesc = (cat.description || '').toLowerCase().includes(q);
        const matchesSlug = (cat.slug || '').toLowerCase().includes(q);
        if (!matchesName && !matchesDesc && !matchesSlug) return false;
      }

      return true;
    });
  }, [catData, activeTab, search]);

  const getCategoryHref = (cat) => {
    const vert = getCategoryVertical(cat);
    if (vert === 'grocery') return '/grocery';
    if (vert === 'food') return '/food';
    if (vert === 'services') return '/services';
    return `/category/${cat.slug}`;
  };

  const getVerticalBadge = (vertical) => {
    switch (vertical) {
      case 'grocery':
        return { label: 'GROCERY', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'food':
        return { label: 'FOOD', bg: 'bg-orange-50 text-orange-700 border-orange-200' };
      case 'services':
        return { label: 'SERVICE', bg: 'bg-blue-50 text-blue-700 border-blue-200' };
      default:
        return { label: 'SHOPPING', bg: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
    }
  };

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-brand-900 to-slate-900 text-white rounded-3xl p-6 sm:p-10 shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider text-brand-200">
            <SparklesIcon className="w-4 h-4 text-brand-300" />
            <span>Curated Directory</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black tracking-tight">
            Explore All Categories
          </h1>
          <p className="text-slate-300 text-sm sm:text-base font-medium">
            Browse through hundreds of high quality products, fresh groceries, local dining delicacies, and doorstep home services.
          </p>
        </div>

        {/* Search Bar */}
        <div className="mt-6 max-w-md relative z-10">
          <div className="relative">
            <MagnifyingGlassIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by category name or keyword..."
              className="w-full pl-11 pr-4 py-2.5 text-sm bg-white/95 backdrop-blur-md text-gray-900 rounded-xl outline-none focus:ring-2 focus:ring-brand-400 font-medium shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {VERTICAL_TABS.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-brand-600 text-white shadow-md shadow-brand-500/20'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Categories Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg sm:text-xl font-bold text-gray-900">
            {activeTab === 'all' ? 'All Curated Categories' : `${activeTab.toUpperCase()} Categories`}
            <span className="text-sm font-normal text-gray-500 ml-2">({categories.length})</span>
          </h2>
        </div>

        {categories.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-gray-200 space-y-3">
            <span className="text-4xl">🔍</span>
            <h3 className="text-lg font-bold text-gray-900">No categories found</h3>
            <p className="text-xs text-gray-500 max-w-sm mx-auto">
              We could not find any category matching "{search}". Try searching for another keyword.
            </p>
            <button
              onClick={() => { setSearch(''); setActiveTab('all'); }}
              className="bg-brand-500 text-white font-bold text-xs px-4 py-2 rounded-xl hover:bg-brand-600 transition-colors cursor-pointer"
            >
              Clear Search
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
            {categories.map((cat) => {
              const vert = getCategoryVertical(cat);
              const badge = getVerticalBadge(vert);
              const href = getCategoryHref(cat);

              return (
                <Link
                  key={cat._id || cat.slug}
                  href={href}
                  className="bg-white rounded-3xl p-5 border border-gray-200/90 hover:border-brand-400 hover:shadow-xl transition-all duration-300 group flex flex-col justify-between"
                >
                  <div className="space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="w-16 h-16 rounded-2xl bg-brand-50 overflow-hidden flex items-center justify-center p-1 group-hover:scale-105 transition-transform duration-300">
                        {cat.image || (cat.icon && cat.icon.startsWith('http')) ? (
                          <img
                            src={cat.image || cat.icon}
                            alt={cat.name}
                            className="w-full h-full object-cover rounded-xl"
                          />
                        ) : (
                          <span className="text-3xl">{cat.icon || '🛍️'}</span>
                        )}
                      </div>
                      <span className={`text-[10px] font-black tracking-wider uppercase px-2.5 py-1 rounded-full border ${badge.bg}`}>
                        {badge.label}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-extrabold text-gray-900 group-hover:text-brand-600 transition-colors">
                        {cat.name}
                      </h3>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                        {cat.description || `Explore our top curated range in ${cat.name}.`}
                      </p>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-gray-100 flex items-center justify-between text-xs font-bold text-brand-600 group-hover:text-brand-700">
                    <span>Explore Category</span>
                    <ArrowRightIcon className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
