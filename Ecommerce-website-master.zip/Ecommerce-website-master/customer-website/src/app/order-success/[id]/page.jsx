'use client';
import { useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { CheckCircleIcon, TruckIcon, ArrowRightIcon } from '@heroicons/react/24/solid';
import { GET_ORDER, GET_CART } from '@/graphql/queries';
import { useCartStore } from '@/store/cartStore';

export default function OrderSuccessPage() {
  const params = useParams();
  const router = useRouter();
  const orderId = params?.id;
  const clearCart = useCartStore((s) => s.clearCart);

  const { data, loading } = useQuery(GET_ORDER, {
    variables: { id: orderId },
    skip: !orderId,
  });

  const { refetch: refetchCart } = useQuery(GET_CART, {
    fetchPolicy: 'network-only',
  });

  useEffect(() => {
    clearCart();
    refetchCart?.();
  }, [clearCart, refetchCart]);

  const order = data?.getOrder;

  return (
    <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-8">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', damping: 15 }}
        className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20"
      >
        <CheckCircleIcon className="w-12 h-12" />
      </motion.div>

      <div className="space-y-2">
        <h1 className="text-3xl font-extrabold text-gray-900">Thank You for Your Order!</h1>
        <p className="text-gray-500 text-sm max-w-md mx-auto leading-relaxed">
          Your order has been placed and is currently being processed by our team.
        </p>
      </div>

      {order && (
        <div className="card p-6 text-left space-y-4 bg-white border border-gray-100 shadow-md">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-gray-100 pb-3">
            <div>
              <span className="text-xs text-gray-400">Order Number</span>
              <p className="font-extrabold text-brand-600">#{order.orderNumber}</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-gray-400">Estimated Delivery</span>
              <p className="text-xs font-bold text-gray-900">
                {order.estimatedDelivery ? new Date(order.estimatedDelivery).toLocaleDateString() : '3 - 5 business days'}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500">Items Ordered:</h4>
            {order.items?.map((item, idx) => (
              <div key={idx} className="flex justify-between items-center text-xs text-gray-700 py-1">
                <span>{item.quantity}x {item.name}</span>
                <span className="font-semibold">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-100 pt-3 flex justify-between text-sm font-extrabold text-gray-900">
            <span>Total Paid</span>
            <span>${order.total?.toFixed(2)} ({order.paymentMethod?.toUpperCase()})</span>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
        {orderId && (
          <Link
            href={`/orders/${orderId}`}
            className="btn-brand px-6 py-3.5 text-sm font-bold flex items-center justify-center gap-2 w-full sm:w-auto shadow-md"
          >
            <TruckIcon className="w-5 h-5" />
            <span>Track Order Status</span>
          </Link>
        )}
        <Link
          href="/products"
          className="btn-outline px-6 py-3.5 text-sm font-bold flex items-center justify-center gap-2 w-full sm:w-auto"
        >
          <span>Continue Shopping</span>
          <ArrowRightIcon className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
