import { Inter } from 'next/font/google';
import './globals.css';
import { ApolloWrapper } from '@/lib/apolloClient';
import { Toaster } from 'react-hot-toast';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import AuthRestorer from '@/components/ui/AuthRestorer';

const inter = Inter({ subsets: ['latin'], display: 'swap' });

export const metadata = {
  title: { default: 'ShopZone - Everything You Need, Delivered Fast', template: '%s | ShopZone' },
  description: 'Shop millions of products with fast delivery, secure payments, and easy returns.',
  keywords: ['ecommerce', 'online shopping', 'deals', 'free shipping'],
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={inter.className}>
      <head>
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body className="min-h-screen flex flex-col bg-gray-50">
        <ApolloWrapper>
          <AuthRestorer />
          <Header />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 3500,
              style: { borderRadius: '12px', fontSize: '14px', fontWeight: '500' },
              success: { style: { background: '#f0fdf4', color: '#166534', border: '1px solid #bbf7d0' } },
              error: { style: { background: '#fef2f2', color: '#991b1b', border: '1px solid #fecaca' } },
            }}
          />
        </ApolloWrapper>
      </body>
    </html>
  );
}
