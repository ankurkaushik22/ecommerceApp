import { Inter } from 'next/font/google';
import './globals.css';
import { ApolloWrapper } from '@/lib/apolloClient';
import { Toaster } from 'react-hot-toast';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import AuthRestorer from '@/components/ui/AuthRestorer';

const inter = Inter({ subsets: ['latin'], display: 'swap' });

export async function generateMetadata() {
  let titleStr = 'Suaaka';
  let iconUrl = '/favicon.ico';
  let appIconUrl = '/favicon.ico';

  try {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'https://ecommerce-api-yak7.onrender.com/graphql';
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: '{ getStoreSettings { storeName faviconUrl appIconUrl } }' }),
      next: { revalidate: 60 } // cache for 1 minute
    });
    const json = await res.json();
    const settings = json?.data?.getStoreSettings;
    
    if (settings) {
      if (settings.storeName) titleStr = settings.storeName;
      if (settings.faviconUrl) iconUrl = settings.faviconUrl;
      if (settings.appIconUrl) appIconUrl = settings.appIconUrl;
    }
  } catch (err) {
    console.error('Failed to fetch store settings for metadata:', err);
  }

  return {
    title: { default: `${titleStr} - Everything You Need, Delivered Fast`, template: `%s | ${titleStr}` },
    description: `Shop millions of products on ${titleStr} with fast delivery, secure payments, and easy returns.`,
    keywords: [titleStr.toLowerCase(), 'ecommerce', 'online shopping', 'deals', 'free shipping'],
    icons: {
      icon: iconUrl,
      apple: appIconUrl,
    }
  };
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={inter.className}>
      <body className="min-h-screen flex flex-col bg-gray-50 overflow-x-hidden w-full max-w-full">
        <ApolloWrapper>
          <AuthRestorer />
          <Header />
          <main className="flex-1 w-full max-w-full overflow-x-hidden">
            {children}
          </main>
          <Footer />
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 3500,
              style: { borderRadius: '12px', fontSize: '14px', fontWeight: '500' },
              success: { style: { background: '#f0fdf4', color: '#166534', border: '1px solid #bbf7d0' } },
              error: { style: { background: '#fef2f2', color: '#991b1b', border: '1px solid #fecaca' } },
            }}
          />
        </ApolloWrapper>
      </body>
    </html>
  );
}
