'use client';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { useQuery } from '@apollo/client';
import ProductCard from '@/components/shop/ProductCard';
import { SEARCH_PRODUCTS } from '@/graphql/queries';

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
          <div className="h-8 w-48 bg-gray-200 animate-pulse rounded-lg" />
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        </div>
      }
    >
      <SearchContent />
    </Suspense>
  );
}

function SearchContent() {
  const searchParams = useSearchParams();
  const query = searchParams.get('q') || '';

  const { data, loading } = useQuery(SEARCH_PRODUCTS, {
    variables: { query, pagination: { page: 1, limit: 20 } },
    skip: !query,
  });

  const products = data?.searchProducts?.products || [];
  const total = data?.searchProducts?.total || 0;

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-gray-900">
          Search Results for <span className="text-brand-600">"{query}"</span>
        </h1>
        <p className="text-sm text-gray-500 mt-1">Found {total} items</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 space-y-3">
          <p className="text-4xl">🔍</p>
          <h3 className="text-lg font-bold text-gray-900">No matching products</h3>
          <p className="text-sm text-gray-500 max-w-sm mx-auto">
            Try checking for typos or use broader search terms like "phone", "headphones", or "shoes".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product._id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
