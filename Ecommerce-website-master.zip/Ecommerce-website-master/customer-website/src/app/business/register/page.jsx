'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, LockClosedIcon, EnvelopeIcon, UserIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { REGISTER } from '@/graphql/mutations';
import { useQuery } from '@apollo/client';
import { GET_STORE_SETTINGS } from '@/graphql/queries';

export default function BusinessRegisterPage() {
  const router = useRouter();

  const { register, handleSubmit, formState: { errors } } = useForm();

  const [registerMutation, { loading }] = useMutation(REGISTER, {
    onCompleted: (data) => {
      toast.success('Business account created! Redirecting to Vendor Panel...');
      const { token, refreshToken, user } = data.register;

      const adminBase =
        typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
          ? 'http://localhost:5173'
          : 'https://ecommerce-admin-alpha-brown.vercel.app';

      const redirectUrl = `${adminBase}/login?token=${encodeURIComponent(token)}&refreshToken=${encodeURIComponent(refreshToken || '')}&user=${encodeURIComponent(JSON.stringify(user))}&verificationPending=true`;

      setTimeout(() => {
        window.location.href = redirectUrl;
      }, 300);
    },
    onError: (err) => {
      toast.error(err.message || 'Registration failed');
    },
  });

  const onSubmit = (formData) => {
    registerMutation({
      variables: {
        input: {
          name: formData.companyName,
          email: formData.email,
          password: formData.password,
          role: 'vendor',
          vendorVertical: formData.vendorVertical || 'shopping',
          vendorCategory: formData.vendorCategory || 'General Seller',
          acceptedTerms: true,
        },
      },
    });
  };

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;
  const disabledVerticals = storeSettings?.disabledVerticals || [];

  const CATEGORY_OPTIONS = [
    { id: 'shopping', name: '🛍️ Shopping (Retail / Products)' },
    { id: 'food', name: '🍔 Food Delivery (Restaurant / Food Items)' },
    { id: 'grocery', name: '🥦 Grocery (Fresh Staples & Dairy)' },
    { id: 'services', name: '🛠️ Services (Home Repairs, Cleaning & Beauty)' },
  ].filter((c) => !disabledVerticals.includes(c.id));

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            {storeSettings?.logoUrl ? (
              <img src={storeSettings.logoUrl} alt={storeSettings?.storeName ? `${storeSettings.storeName} Business` : 'Suaaka Business'} className="h-10 md:h-12 w-auto object-contain max-w-[200px]" />
            ) : (
              <>
                <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
                  <BuildingStorefrontIcon className="w-5 h-5" />
                </div>
                <span>Suaaka Business</span>
              </>
            )}
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">Create a free business account</h2>
          <p className="text-xs text-gray-500">Join thousands of sellers on {storeSettings?.storeName || 'Suaaka'}</p>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-200 shadow-sm rounded-xl">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-sm font-bold text-gray-800 block mb-1">Company Name</label>
              <div className="relative">
                <input
                  type="text"
                  {...register('companyName', { required: 'Company name is required' })}
                  placeholder="Acme Corp"
                  className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm"
                />
                <UserIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.companyName && <p className="text-xs text-red-500 mt-1">{errors.companyName.message}</p>}
            </div>

            <div>
              <label className="text-sm font-bold text-gray-800 block mb-1">Business Category / Vertical *</label>
              <select
                {...register('vendorVertical', { required: 'Please select a business category' })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm font-semibold bg-white"
              >
                {CATEGORY_OPTIONS.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-sm font-bold text-gray-800 block mb-1">Business Email</label>
              <div className="relative">
                <input
                  type="email"
                  {...register('email', { required: 'Email is required' })}
                  placeholder="contact@acme.com"
                  className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm"
                />
                <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="text-sm font-bold text-gray-800 block mb-1">Password</label>
              <div className="relative">
                <input
                  type="password"
                  {...register('password', { required: 'Password is required', minLength: 6 })}
                  placeholder="At least 6 characters"
                  className="w-full px-3 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.password && <p className="text-xs text-red-500 mt-1">Minimum 6 characters required</p>}
            </div>

            <p className="text-[11px] text-gray-600 pb-2">
              By continuing, you agree to {storeSettings?.storeName || 'Suaaka'}&apos;s <Link href="/terms" className="text-blue-600 hover:underline">Conditions of Use</Link> and <Link href="/privacy" className="text-blue-600 hover:underline">Privacy Notice</Link>.
            </p>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-brand-500 hover:bg-brand-600 text-white rounded-lg py-2.5 font-bold text-sm shadow-sm transition-colors"
            >
              {loading ? 'Creating...' : 'Create Business Account'}
            </button>
          </form>

          <div className="text-center text-sm text-gray-600 pt-4 border-t border-gray-200">
            Already have an account?{' '}
            <Link href="/login" className="font-bold text-blue-600 hover:underline">
              Sign In
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
