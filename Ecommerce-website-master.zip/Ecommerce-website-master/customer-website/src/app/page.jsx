'use client';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import {
  SparklesIcon, FireIcon, TruckIcon, ShieldCheckIcon,
  ArrowPathIcon, CreditCardIcon, ArrowRightIcon
} from '@heroicons/react/24/outline';
import HeroBanner from '@/components/shop/HeroBanner';
import ProductCard from '@/components/shop/ProductCard';
import { GET_FEATURED_PRODUCTS, GET_DEALS_PRODUCTS, GET_CATEGORIES } from '@/graphql/queries';

const FEATURES = [
  { icon: TruckIcon, title: 'Free Worldwide Shipping', desc: 'On orders over $50' },
  { icon: ShieldCheckIcon, title: 'Secure Payment', desc: '100% protected by Stripe' },
  { icon: ArrowPathIcon, title: '30-Day Easy Returns', desc: 'Hassle-free guarantee' },
  { icon: CreditCardIcon, title: 'Cash on Delivery', desc: 'Pay at your doorstep' },
];

export default function HomePage() {
  const { data: featuredData, loading: loadingFeatured } = useQuery(GET_FEATURED_PRODUCTS, {
    variables: { limit: 8 },
    fetchPolicy: 'cache-and-network',
  });
  const { data: dealsData, loading: loadingDeals } = useQuery(GET_DEALS_PRODUCTS, {
    variables: { limit: 4 },
    fetchPolicy: 'cache-and-network',
  });
  const { data: catData, loading: loadingCats } = useQuery(GET_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });

  const featuredProducts = featuredData?.getFeaturedProducts || [];
  const dealsProducts = dealsData?.getDealsProducts || [];
  const categories = catData?.getCategories || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-12">
      {/* Hero Banner */}
      <HeroBanner />

      {/* Trust Badges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {FEATURES.map((item, i) => {
          const Icon = item.icon;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-center gap-3.5 p-4 rounded-2xl bg-white border border-gray-100 shadow-sm"
            >
              <div className="p-3 rounded-xl bg-brand-50 text-brand-600 flex-shrink-0">
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-gray-900 leading-tight">{item.title}</h4>
                <p className="text-[11px] text-gray-500 mt-0.5">{item.desc}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Featured Categories Carousel / Grid */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 flex items-center gap-2">
              <span>Shop by Category</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-500">Explore top selections curated for you</p>
          </div>
          <Link
            href="/category/electronics"
            className="text-sm font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            All Categories <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 sm:gap-4">
          {loadingCats
            ? [...Array(6)].map((_, i) => (
                <div key={i} className="card p-4 flex flex-col items-center animate-pulse gap-3">
                  <div className="w-16 h-16 rounded-full bg-gray-100" />
                  <div className="h-3 w-16 bg-gray-100 rounded" />
                </div>
              ))
            : categories.slice(0, 6).map((cat) => (
                <Link
                  key={cat._id}
                  href={`/category/${cat.slug}`}
                  className="card p-4 flex flex-col items-center justify-center text-center group hover:border-brand-300 hover:shadow-md transition-all rounded-2xl"
                >
                  <div className="w-16 h-16 rounded-2xl bg-brand-50 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform mb-2">
                    {cat.icon || '🛍️'}
                  </div>
                  <span className="text-xs sm:text-sm font-bold text-gray-800 group-hover:text-brand-600 transition-colors">
                    {cat.name}
                  </span>
                  <span className="text-[10px] text-gray-400 mt-0.5">
                    {cat.children?.length || 0} Subcategories
                  </span>
                </Link>
              ))}
        </div>
      </section>

      {/* Flash Deals / Today's Specials */}
      <section className="space-y-4 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-amber-500/10 via-brand-500/5 to-rose-500/10 border border-amber-200/50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-rose-500 text-white rounded-xl shadow-md shadow-rose-500/30">
              <FireIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-gray-900">Today's Flash Deals</h2>
              <p className="text-xs sm:text-sm text-gray-600">Limited time offers with crazy discounts</p>
            </div>
          </div>
          <Link
            href="/deals"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-brand-500 hover:bg-brand-600 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all self-start sm:self-auto"
          >
            View All Deals <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 pt-2">
          {loadingDeals
            ? [...Array(4)].map((_, i) => (
                <div key={i} className="card h-72 animate-pulse bg-white/70" />
              ))
            : dealsProducts.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 flex items-center gap-2">
              <SparklesIcon className="w-6 h-6 text-brand-500" />
              <span>Trending & Featured Products</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-500">Top rated picks by customers</p>
          </div>
          <Link
            href="/products"
            className="text-sm font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
          >
            Explore All <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {loadingFeatured
            ? [...Array(8)].map((_, i) => (
                <div key={i} className="card h-80 animate-pulse bg-gray-100" />
              ))
            : featuredProducts.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
        </div>
      </section>

      {/* Promo Banner Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 to-navy-900 p-8 text-white flex flex-col justify-between min-h-[220px]">
          <div className="space-y-2 z-10 max-w-sm">
            <span className="text-xs uppercase font-bold tracking-widest text-indigo-400">Audio Experience</span>
            <h3 className="text-2xl font-extrabold">Next Level Sound & Pure Bass</h3>
            <p className="text-xs text-indigo-200">Noise cancellation headphones and wireless earbuds</p>
          </div>
          <div className="z-10 pt-4">
            <Link href="/category/electronics" className="btn-brand text-xs font-bold px-4 py-2">
              Shop Audio →
            </Link>
          </div>
        </div>

        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-600 to-brand-700 p-8 text-white flex flex-col justify-between min-h-[220px]">
          <div className="space-y-2 z-10 max-w-sm">
            <span className="text-xs uppercase font-bold tracking-widest text-amber-200">Special Promo</span>
            <h3 className="text-2xl font-extrabold">Save Up to 50% With Coupons</h3>
            <p className="text-xs text-amber-100">Use coupon code <span className="font-mono font-bold bg-white/20 px-1.5 py-0.5 rounded">FLASH50</span> at checkout</p>
          </div>
          <div className="z-10 pt-4">
            <Link href="/deals" className="bg-white text-brand-700 hover:bg-gray-100 px-4 py-2 rounded-xl text-xs font-bold transition-colors inline-block">
              Claim Deals →
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
