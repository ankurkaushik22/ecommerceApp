'use client';
import Link from 'next/link';
import { ArrowRightIcon } from '@heroicons/react/24/outline';

export default function HomePage() {
  return (
    <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Super-App Gateway Hero Section */}
      <section className="bg-gradient-to-b from-slate-50/80 via-white to-slate-50/80 border border-gray-200/90 rounded-3xl p-6 sm:p-12 shadow-sm space-y-8 sm:space-y-10">
        {/* Headline */}
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            <span className="text-orange-500">Every</span>
            <span className="text-teal-600">thing</span> you need,
            <br />
            <span className="text-slate-900">in one app.</span>
          </h1>
          <div className="flex items-center justify-center gap-3 pt-1 text-sm sm:text-base font-bold">
            <span className="text-purple-600">Shop</span>
            <span className="text-gray-300">•</span>
            <span className="text-orange-500">Eat</span>
            <span className="text-gray-300">•</span>
            <span className="text-emerald-600">Grocery</span>
            <span className="text-gray-300">•</span>
            <span className="text-blue-600">Services</span>
          </div>
        </div>

        {/* 4 Gateway Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* 1. Shopping */}
          <Link
            href="/shop"
            className="group relative bg-[#FAF5FF] hover:bg-[#F3E8FF] border-2 border-[#E9D5FF] rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:-translate-y-1 min-h-[260px]"
          >
            <div className="w-full h-36 rounded-2xl overflow-hidden bg-white shadow-xs mb-4">
              <img
                src="https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=500"
                alt="Shopping"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-[#6D28D9]">Shopping</h3>
              <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed pr-8">
                Shop from top brands across categories
              </p>
            </div>
            <div className="absolute bottom-5 right-5 w-8 h-8 rounded-full bg-[#7C3AED] text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
              <ArrowRightIcon className="w-4 h-4" />
            </div>
          </Link>

          {/* 2. Food Delivery */}
          <Link
            href="/food"
            className="group relative bg-[#FFF7ED] hover:bg-[#FFEDD5] border-2 border-[#FED7AA] rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:-translate-y-1 min-h-[260px]"
          >
            <div className="w-full h-36 rounded-2xl overflow-hidden bg-white shadow-xs mb-4">
              <img
                src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500"
                alt="Food Delivery"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-[#EA580C]">Food Delivery</h3>
              <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed pr-8">
                Order from your favourite restaurants
              </p>
            </div>
            <div className="absolute bottom-5 right-5 w-8 h-8 rounded-full bg-[#EA580C] text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
              <ArrowRightIcon className="w-4 h-4" />
            </div>
          </Link>

          {/* 3. Grocery */}
          <Link
            href="/grocery"
            className="group relative bg-[#F0FDF4] hover:bg-[#DCFCE7] border-2 border-[#BBF7D0] rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:-translate-y-1 min-h-[260px]"
          >
            <div className="w-full h-36 rounded-2xl overflow-hidden bg-white shadow-xs mb-4">
              <img
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=500"
                alt="Grocery"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-[#16A34A]">Grocery</h3>
              <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed pr-8">
                Fresh groceries delivered to your door
              </p>
            </div>
            <div className="absolute bottom-5 right-5 w-8 h-8 rounded-full bg-[#16A34A] text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
              <ArrowRightIcon className="w-4 h-4" />
            </div>
          </Link>

          {/* 4. Services */}
          <Link
            href="/services"
            className="group relative bg-[#EFF6FF] hover:bg-[#DBEAFE] border-2 border-[#BFDBFE] rounded-3xl p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-lg hover:-translate-y-1 min-h-[260px]"
          >
            <div className="w-full h-36 rounded-2xl overflow-hidden bg-white shadow-xs mb-4">
              <img
                src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=500"
                alt="Services"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-[#2563EB]">Services</h3>
              <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed pr-8">
                Trusted services at your doorstep
              </p>
            </div>
            <div className="absolute bottom-5 right-5 w-8 h-8 rounded-full bg-[#2563EB] text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
              <ArrowRightIcon className="w-4 h-4" />
            </div>
          </Link>
        </div>

        {/* Exclusive Offers Banner */}
        <Link
          href="/deals"
          className="flex flex-col sm:flex-row items-center justify-between bg-gradient-to-r from-[#FAF5FF] via-white to-[#FAF5FF] border-2 border-[#E9D5FF] rounded-2xl p-5 sm:p-6 shadow-xs hover:shadow-md transition-all gap-4"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-[#F3E8FF] text-[#7C3AED] flex items-center justify-center flex-shrink-0 text-2xl font-bold">
              🏷️
            </div>
            <div>
              <span className="text-[10px] font-black tracking-wider uppercase text-[#7C3AED] bg-[#F3E8FF] px-2.5 py-0.5 rounded-full">
                EXCLUSIVE OFFERS
              </span>
              <h4 className="text-lg font-bold text-slate-900 mt-1">Best deals just for you!</h4>
              <p className="text-xs text-slate-500">Explore amazing offers across all categories.</p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-white border border-[#E9D5FF] text-[#7C3AED] px-5 py-2.5 rounded-full font-bold text-xs shadow-xs hover:bg-[#FAF5FF] transition-colors">
            View Offers <ArrowRightIcon className="w-3.5 h-3.5" />
          </div>
        </Link>
      </section>
    </div>
  );
}
