'use client';
import { useMemo } from 'react';
import { useQuery } from '@apollo/client';
import { FireIcon, SparklesIcon } from '@heroicons/react/24/solid';
import ProductCard from '@/components/shop/ProductCard';
import { GET_DEALS_PRODUCTS } from '@/graphql/queries';

const SHOPPING_SLUGS = new Set([
  'electronics', 'clothing', 'home-and-kitchen', 'beauty-and-health',
  'sports-and-outdoors', 'books', 'automotive', 'jewelry',
]);

export default function DealsPage() {
  const { data, loading } = useQuery(GET_DEALS_PRODUCTS, {
    variables: { limit: 50 },
    fetchPolicy: 'cache-and-network',
  });

  const rawDeals = data?.getDealsProducts || [];

  const deals = useMemo(() => {
    return rawDeals.filter((p) => {
      const catSlug = (p.category?.slug || '').toLowerCase();
      if (!catSlug) return true;
      return SHOPPING_SLUGS.has(catSlug);
    });
  }, [rawDeals]);

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-600 via-amber-600 to-brand-600 p-8 sm:p-12 text-white shadow-xl">
        <div className="max-w-xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold uppercase tracking-wider">
            <FireIcon className="w-4 h-4 text-amber-300" />
            <span>Limited Time Offers</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">Today's Best Deals & Offers</h1>
          <p className="text-sm text-rose-100 leading-relaxed">
            Grab incredible bargains across electronics, clothing, home essentials, and more before the timer runs out!
          </p>
        </div>
      </div>

      {/* Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <SparklesIcon className="w-5 h-5 text-brand-500" />
            <span>Exclusive Discounts</span>
          </h2>
          <span className="text-xs text-gray-500 font-medium">{deals.length} items available</span>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : deals.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-gray-100">
            <p className="text-gray-500">No active deals right now. Check back soon!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {deals.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
