'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import {
  CreditCardIcon, BanknotesIcon, ShieldCheckIcon,
  MapPinIcon, CheckCircleIcon, ArrowLeftIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_CART, GET_ME } from '@/graphql/queries';
import { PLACE_ORDER } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';

export default function CheckoutPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const { items: localItems, subtotal: localSubtotal, clearCart: clearLocalCart } = useCartStore();

  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' | 'stripe'
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(0);
  const [useNewAddress, setUseNewAddress] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      fullName: user?.name || '',
      phone: user?.phone || '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      postalCode: '',
      country: 'United States',
    },
  });

  const { data: cartData, loading: loadingCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'network-only',
  });

  const { data: userData } = useQuery(GET_ME, {
    skip: !isAuthenticated,
  });

  const [placeOrderMutation, { loading: placingOrder }] = useMutation(PLACE_ORDER, {
    refetchQueries: [{ query: GET_CART }],
    update(cache) {
      cache.writeQuery({
        query: GET_CART,
        data: {
          getCart: {
            __typename: 'Cart',
            _id: cartData?.getCart?._id || 'temp',
            user: user?._id || '',
            items: [],
            subtotal: 0,
            itemCount: 0,
            couponCode: null,
            couponDiscount: 0,
            discount: 0,
            updatedAt: new Date().toISOString(),
          },
        },
      });
    },
    onCompleted: (res) => {
      const order = res.placeOrder;
      toast.success('Order placed successfully!');
      clearLocalCart();
      router.push(`/order-success/${order._id}`);
    },
    onError: (e) => toast.error(e.message),
  });

  const savedAddresses = userData?.me?.addresses || user?.addresses || [];
  const cart = isAuthenticated ? cartData?.getCart : null;
  const items = isAuthenticated ? cart?.items || [] : localItems;
  const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
  const discount = isAuthenticated ? cart?.couponDiscount || 0 : 0;
  const shipping = subtotal > 50 || items.length === 0 ? 0 : 9.99;
  const tax = Math.round((Math.max(0, subtotal - discount) * 0.08) * 100) / 100;
  const total = Math.max(0, subtotal - discount + shipping + tax);

  const onCheckoutSubmit = (formData) => {
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }

    if (!isAuthenticated) {
      toast.error('Please login to place your order');
      router.push('/login?redirect=/checkout');
      return;
    }

    let shippingAddress = null;
    if (!useNewAddress && savedAddresses.length > 0) {
      const saved = savedAddresses[selectedAddressIndex];
      shippingAddress = {
        fullName: saved.fullName,
        phone: saved.phone,
        addressLine1: saved.addressLine1,
        addressLine2: saved.addressLine2 || '',
        city: saved.city,
        state: saved.state,
        postalCode: saved.postalCode,
        country: saved.country || 'United States',
      };
    } else {
      shippingAddress = {
        fullName: formData.fullName,
        phone: formData.phone,
        addressLine1: formData.addressLine1,
        addressLine2: formData.addressLine2 || '',
        city: formData.city,
        state: formData.state,
        postalCode: formData.postalCode,
        country: formData.country || 'United States',
      };
    }

    placeOrderMutation({
      variables: {
        input: {
          paymentMethod,
          shippingAddressId: !useNewAddress && savedAddresses.length > 0 ? savedAddresses[selectedAddressIndex]._id : undefined,
          notes: 'Customer placed order via web',
        },
        address: useNewAddress || savedAddresses.length === 0 ? shippingAddress : undefined,
      },
    });
  };

  if (items.length === 0 && !loadingCart) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Your Cart is Empty</h2>
        <p className="text-gray-500">Add items to your cart before proceeding to checkout.</p>
        <button onClick={() => router.push('/products')} className="btn-brand text-sm">
          Browse Products
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Checkout Header */}
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Secure Checkout</h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-0.5">Complete your shipping & payment details</p>
        </div>
        <button
          onClick={() => router.push('/cart')}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-brand-600 hover:underline"
        >
          <ArrowLeftIcon className="w-4 h-4" /> Back to Cart
        </button>
      </div>

      <form onSubmit={handleSubmit(onCheckoutSubmit)} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Address & Payment (8 cols) */}
        <div className="lg:col-span-8 space-y-8">
          {/* Step 1: Shipping Address */}
          <div className="card p-6 space-y-5">
            <div className="flex items-center gap-2.5 border-b border-gray-100 pb-3">
              <div className="w-7 h-7 bg-brand-500 text-white rounded-full flex items-center justify-center font-bold text-xs">
                1
              </div>
              <h2 className="text-lg font-bold text-gray-900">Shipping Address</h2>
            </div>

            {/* Saved Addresses List */}
            {savedAddresses.length > 0 && !useNewAddress && (
              <div className="space-y-3">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Select Saved Address:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {savedAddresses.map((addr, idx) => (
                    <div
                      key={addr._id || idx}
                      onClick={() => setSelectedAddressIndex(idx)}
                      className={`p-4 rounded-xl border cursor-pointer transition-all ${
                        selectedAddressIndex === idx
                          ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold uppercase text-brand-700 bg-brand-100 px-2 py-0.5 rounded">
                          {addr.label || 'Home'}
                        </span>
                        {selectedAddressIndex === idx && (
                          <CheckCircleIcon className="w-5 h-5 text-brand-600" />
                        )}
                      </div>
                      <p className="font-bold text-sm text-gray-900">{addr.fullName}</p>
                      <p className="text-xs text-gray-600 mt-1">{addr.addressLine1} {addr.addressLine2}</p>
                      <p className="text-xs text-gray-600">{addr.city}, {addr.state} {addr.postalCode}</p>
                      <p className="text-xs text-gray-400 mt-1">📞 {addr.phone}</p>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setUseNewAddress(true)}
                  className="text-xs font-bold text-brand-600 hover:underline pt-2 inline-block"
                >
                  + Ship to a new address
                </button>
              </div>
            )}

            {/* New Address Form */}
            {(useNewAddress || savedAddresses.length === 0) && (
              <div className="space-y-4">
                {savedAddresses.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setUseNewAddress(false)}
                    className="text-xs text-brand-600 font-semibold hover:underline mb-2 block"
                  >
                    ← Use saved address
                  </button>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Full Name *</label>
                    <input
                      {...register('fullName', { required: 'Name is required' })}
                      className="input-field text-sm"
                      placeholder="John Doe"
                    />
                    {errors.fullName && <p className="text-xs text-red-500 mt-1">{errors.fullName.message}</p>}
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Phone Number *</label>
                    <input
                      {...register('phone', { required: 'Phone is required' })}
                      className="input-field text-sm"
                      placeholder="+1 (555) 000-0000"
                    />
                    {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Street Address *</label>
                  <input
                    {...register('addressLine1', { required: 'Address is required' })}
                    className="input-field text-sm"
                    placeholder="123 Main Street, Apt 4B"
                  />
                  {errors.addressLine1 && <p className="text-xs text-red-500 mt-1">{errors.addressLine1.message}</p>}
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">City *</label>
                    <input
                      {...register('city', { required: 'City is required' })}
                      className="input-field text-sm"
                      placeholder="New York"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">State *</label>
                    <input
                      {...register('state', { required: 'State is required' })}
                      className="input-field text-sm"
                      placeholder="NY"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Postal Code *</label>
                    <input
                      {...register('postalCode', { required: 'ZIP is required' })}
                      className="input-field text-sm"
                      placeholder="10001"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Step 2: Payment Method */}
          <div className="card p-6 space-y-5">
            <div className="flex items-center gap-2.5 border-b border-gray-100 pb-3">
              <div className="w-7 h-7 bg-brand-500 text-white rounded-full flex items-center justify-center font-bold text-xs">
                2
              </div>
              <h2 className="text-lg font-bold text-gray-900">Payment Method</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Cash on Delivery */}
              <div
                onClick={() => setPaymentMethod('cod')}
                className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-start gap-4 ${
                  paymentMethod === 'cod'
                    ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="p-3 bg-amber-100 text-amber-800 rounded-xl">
                  <BanknotesIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Cash on Delivery (COD)</h3>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                    Pay securely with cash when your package arrives at your doorstep.
                  </p>
                </div>
              </div>

              {/* Stripe Online Card */}
              <div
                onClick={() => setPaymentMethod('stripe')}
                className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-start gap-4 ${
                  paymentMethod === 'stripe'
                    ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="p-3 bg-purple-100 text-purple-800 rounded-xl">
                  <CreditCardIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Credit / Debit Card (Stripe)</h3>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                    Fast & secure card checkout powered by Stripe integration.
                  </p>
                </div>
              </div>
            </div>

            {paymentMethod === 'stripe' && (
              <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 text-xs text-gray-600 space-y-2">
                <p className="font-semibold text-gray-800">💳 Card Payment Information</p>
                <p>Card payment intent will be authorized immediately upon placing the order.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Order Summary Review (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="card p-6 space-y-5 sticky top-20">
            <h3 className="font-bold text-gray-900 text-lg">Order Items ({items.length})</h3>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={item._id} className="flex items-center gap-3">
                  <img
                    src={item.product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=150'}
                    alt=""
                    className="w-12 h-12 object-cover rounded-lg border border-gray-100 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-gray-900 truncate">{item.product?.name || item.name}</p>
                    <p className="text-[11px] text-gray-500">Qty: {item.quantity} × ${item.price?.toFixed(2)}</p>
                  </div>
                  <span className="text-xs font-bold text-gray-900">
                    ${(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-gray-100 pt-4 space-y-2 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Shipping</span>
                <span>{shipping === 0 ? <span className="text-emerald-600 font-semibold">FREE</span> : `$${shipping.toFixed(2)}`}</span>
              </div>
              {tax > 0 && (
                <div className="flex justify-between text-gray-600">
                  <span>Estimated Tax (8%)</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
              )}
              <div className="border-t border-gray-100 pt-2 flex justify-between text-lg font-extrabold text-gray-900">
                <span>Total</span>
                <span className="text-brand-600">${total.toFixed(2)}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={placingOrder}
              className="w-full btn-brand py-4 font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-brand-500/25"
            >
              <ShieldCheckIcon className="w-5 h-5" />
              <span>{placingOrder ? 'Processing Order...' : `Place Order • $${total.toFixed(2)}`}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
