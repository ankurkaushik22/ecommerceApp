'use client';
import { useState, useMemo, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import {
  ShieldCheckIcon,
  TruckIcon,
  CreditCardIcon,
  BanknotesIcon,
  MapPinIcon,
  CheckCircleIcon,
  ArrowLeftIcon,
  SparklesIcon,
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import { GET_CART, GET_ME, GET_DELIVERY_OPTIONS, GET_TAX_SETTINGS } from '@/graphql/queries';
import { PLACE_ORDER, SYNC_CART } from '@/graphql/mutations';
import { getItemVertical, isFoodItem, isGroceryItem, isServiceItem, isShoppingItem } from '@/utils/cartHelpers';

export default function CheckoutPage() {
  const router = useRouter();
  const { user, isAuthenticated } = useAuthStore();
  const { items: localItems, clearCart: clearLocalCart } = useCartStore();

  const [paymentMethod, setPaymentMethod] = useState('cod'); // 'cod' | 'stripe'
  const [selectedAddressIndex, setSelectedAddressIndex] = useState(0);
  const [useNewAddress, setUseNewAddress] = useState(false);
  const [saveAsDefault, setSaveAsDefault] = useState(true);
  const [selectedDeliveryOptionId, setSelectedDeliveryOptionId] = useState('');
  const [selectedSlot, setSelectedSlot] = useState('Today: 3PM - 5PM');
  const [selectedVertical, setSelectedVertical] = useState(undefined);
  const syncAttempted = useRef(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const slot = params.get('slot');
      if (slot) setSelectedSlot(slot);
      const vert = params.get('vertical');
      if (vert) setSelectedVertical(vert);
    }
  }, []);

  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      fullName: user?.name || '',
      phone: user?.phone || '',
      addressLine1: '',
      addressLine2: '',
      city: 'Meerut',
      state: 'Uttar Pradesh',
      postalCode: '250001',
      country: 'India',
    },
  });

  const { data: cartData, loading: loadingCart, refetch: refetchCart } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'network-only',
  });

  const [syncCartMutation] = useMutation(SYNC_CART, {
    onCompleted: () => {
      clearLocalCart();
      refetchCart();
    },
    onError: (e) => console.error('Cart sync error:', e),
  });

  useEffect(() => {
    if (isAuthenticated && localItems && localItems.length > 0 && !syncAttempted.current) {
      syncAttempted.current = true;
      const itemsToSync = localItems
        .filter((item) => item.product && (item.product._id || item.product))
        .map((item) => ({
          productId: item.product._id || item.product,
          variantIndex: item.variantIndex ?? -1,
          quantity: item.quantity || 1,
        }));

      if (itemsToSync.length > 0) {
        syncCartMutation({ variables: { items: itemsToSync } });
      }
    }
  }, [isAuthenticated, localItems, syncCartMutation]);

  const { data: userData } = useQuery(GET_ME, {
    skip: !isAuthenticated,
  });

  const { data: deliveryOptionsData } = useQuery(GET_DELIVERY_OPTIONS, {
    variables: { activeOnly: true },
    fetchPolicy: 'cache-and-network',
  });

  const { data: taxSettingsData } = useQuery(GET_TAX_SETTINGS, {
    variables: { activeOnly: true },
    fetchPolicy: 'cache-and-network',
  });

  const [placeOrderMutation, { loading: placingOrder }] = useMutation(PLACE_ORDER, {
    refetchQueries: [{ query: GET_CART }],
    update(cache) {
      cache.writeQuery({
        query: GET_CART,
        data: {
          getCart: {
            __typename: 'Cart',
            _id: cartData?.getCart?._id || 'temp',
            user: user?._id || '',
            items: [],
            subtotal: 0,
            itemCount: 0,
            couponCode: null,
            couponDiscount: 0,
            discount: 0,
            updatedAt: new Date().toISOString(),
          },
        },
      });
    },
    onCompleted: (res) => {
      const order = res.placeOrder;
      toast.success('Order placed successfully! 🎉');
      clearLocalCart();
      router.push(`/order-success/${order._id}`);
    },
    onError: (e) => toast.error(e.message),
  });

  const deliveryOptions = deliveryOptionsData?.getDeliveryOptions || [
    { _id: 'std', name: 'Standard Delivery', estimatedDays: '3-5 Business Days', price: 49, minOrderForFree: 499 },
    { _id: 'exp', name: 'Express Delivery (24-48 Hours)', estimatedDays: '1-2 Business Days', price: 99, minOrderForFree: 1499 },
  ];

  const currentDeliveryOption = useMemo(() => {
    if (selectedDeliveryOptionId) {
      return deliveryOptions.find((d) => d._id === selectedDeliveryOptionId) || deliveryOptions[0];
    }
    return deliveryOptions.find((d) => d.isDefault) || deliveryOptions[0];
  }, [deliveryOptions, selectedDeliveryOptionId]);

  const activeTax = taxSettingsData?.getTaxSettings?.find((t) => t.isDefault) ||
    taxSettingsData?.getTaxSettings?.[0] || { rate: 18, name: 'Standard GST (18%)' };

  const savedAddresses = userData?.me?.addresses || user?.addresses || [];
  const cart = isAuthenticated ? cartData?.getCart : null;
  const rawItems = isAuthenticated ? cart?.items || [] : localItems;

  const effectiveVertical = useMemo(() => {
    if (selectedVertical && selectedVertical !== 'all') return selectedVertical;
    if (rawItems.length > 0) return getItemVertical(rawItems[0]);
    return 'shopping';
  }, [selectedVertical, rawItems]);

  const items = useMemo(() => {
    if (effectiveVertical === 'food') return rawItems.filter(isFoodItem);
    if (effectiveVertical === 'grocery') return rawItems.filter(isGroceryItem);
    if (effectiveVertical === 'services') return rawItems.filter(isServiceItem);
    return rawItems.filter(isShoppingItem);
  }, [rawItems, effectiveVertical]);

  const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
  const discount = isAuthenticated ? cart?.couponDiscount || 0 : 0;
  const taxableAmount = Math.max(0, subtotal - discount);

  const isFreeDelivery = currentDeliveryOption?.minOrderForFree > 0 && subtotal >= currentDeliveryOption?.minOrderForFree;
  const shipping = items.length === 0 ? 0 : (isFreeDelivery ? 0 : (currentDeliveryOption?.price || 49));
  const taxRate = activeTax?.rate || 18;
  const tax = Math.round((taxableAmount * (taxRate / 100)) * 100) / 100;
  const total = Math.round((taxableAmount + shipping + tax) * 100) / 100;

  const hasDisableCOD = useMemo(() => items.some(item => item.product?.disableCOD), [items]);

  useEffect(() => {
    if (hasDisableCOD && paymentMethod === 'cod') {
      setPaymentMethod('stripe');
    }
  }, [hasDisableCOD, paymentMethod]);

  const onCheckoutSubmit = (formData) => {
    if (items.length === 0) {
      toast.error('Your cart is empty');
      return;
    }

    if (!isAuthenticated) {
      toast.error('Please login to place your order');
      router.push('/login?redirect=/checkout');
      return;
    }

    let shippingAddress = null;
    if (!useNewAddress && savedAddresses.length > 0) {
      const saved = savedAddresses[selectedAddressIndex];
      shippingAddress = {
        fullName: saved.fullName,
        phone: saved.phone,
        addressLine1: saved.addressLine1,
        addressLine2: saved.addressLine2 || '',
        city: saved.city,
        state: saved.state,
        postalCode: saved.postalCode,
        country: saved.country || 'India',
      };
    } else {
      shippingAddress = {
        fullName: formData.fullName,
        phone: formData.phone,
        addressLine1: formData.addressLine1,
        addressLine2: formData.addressLine2 || '',
        city: formData.city,
        state: formData.state,
        postalCode: formData.postalCode,
        country: formData.country || 'India',
      };
    }

    const slotNote = selectedSlot ? `[Slot: ${selectedSlot}]` : '';
    const finalNotes = [slotNote, 'Customer placed order via web'].filter(Boolean).join(' ');

    placeOrderMutation({
      variables: {
        input: {
          paymentMethod,
          deliveryOptionId: currentDeliveryOption?._id,
          shippingAddressId: !useNewAddress && savedAddresses.length > 0 ? savedAddresses[selectedAddressIndex]._id : undefined,
          notes: finalNotes,
          vertical: effectiveVertical,
          saveAsDefault,
        },
        address: useNewAddress || savedAddresses.length === 0 ? shippingAddress : undefined,
      },
    });
  };

  if (items.length === 0 && !loadingCart) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Your Cart is Empty</h2>
        <p className="text-gray-500">Add items to your cart before proceeding to checkout.</p>
        <button onClick={() => router.push('/products')} className="btn-brand text-sm">
          Browse Products
        </button>
      </div>
    );
  }

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Checkout Header */}
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Secure Checkout</h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-0.5">Complete your delivery & payment details</p>
        </div>
        <button
          onClick={() => router.push('/cart')}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-brand-600 hover:underline"
        >
          <ArrowLeftIcon className="w-4 h-4" /> Back to Cart
        </button>
      </div>

      <form onSubmit={handleSubmit(onCheckoutSubmit)} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Steps (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Step 1: Delivery Address */}
          <div className="card p-6 space-y-5">
            <div className="flex items-center gap-2.5 border-b border-gray-100 pb-3">
              <div className="w-7 h-7 bg-brand-500 text-white rounded-full flex items-center justify-center font-bold text-xs">
                1
              </div>
              <h2 className="text-lg font-bold text-gray-900">Delivery Address</h2>
            </div>

            {/* Saved Addresses */}
            {savedAddresses.length > 0 && !useNewAddress ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {savedAddresses.map((addr, idx) => (
                    <div
                      key={addr._id || idx}
                      onClick={() => setSelectedAddressIndex(idx)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                        selectedAddressIndex === idx
                          ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-brand-700 uppercase">{addr.label || 'Address'}</span>
                        {selectedAddressIndex === idx && (
                          <CheckCircleIcon className="w-5 h-5 text-brand-600" />
                        )}
                      </div>
                      <p className="font-bold text-sm text-gray-900 mt-1">{addr.fullName}</p>
                      <p className="text-xs text-gray-600 mt-0.5">{addr.addressLine1}</p>
                      {addr.addressLine2 && <p className="text-xs text-gray-500">{addr.addressLine2}</p>}
                      <p className="text-xs text-gray-600">
                        {addr.city}, {addr.state} - {addr.postalCode}
                      </p>
                      <p className="text-xs font-semibold text-gray-700 mt-1">📞 {addr.phone}</p>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => setUseNewAddress(true)}
                  className="text-xs font-bold text-brand-600 hover:underline"
                >
                  + Deliver to a different address
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {savedAddresses.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setUseNewAddress(false)}
                    className="text-xs font-bold text-brand-600 hover:underline mb-2 block"
                  >
                    ← Select from saved addresses
                  </button>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Full Name *</label>
                    <input
                      {...register('fullName', { required: 'Full name is required' })}
                      className="input-field text-sm"
                      placeholder="e.g. John Sharma"
                    />
                    {errors.fullName && <p className="text-xs text-red-500 mt-1">{errors.fullName.message}</p>}
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Phone Number *</label>
                    <input
                      {...register('phone', { required: 'Phone is required' })}
                      className="input-field text-sm"
                      placeholder="+91 98765 43210"
                    />
                    {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone.message}</p>}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Address Line 1 (Street / House No) *</label>
                  <input
                    {...register('addressLine1', { required: 'Street address is required' })}
                    className="input-field text-sm"
                    placeholder="123 Main Street, Sector 4"
                  />
                  {errors.addressLine1 && <p className="text-xs text-red-500 mt-1">{errors.addressLine1.message}</p>}
                </div>

                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Address Line 2 (Apartment, Landmark)</label>
                  <input
                    {...register('addressLine2')}
                    className="input-field text-sm"
                    placeholder="Apt 4B, Near Metro Pillar 120"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">City *</label>
                    <input
                      {...register('city', { required: 'City is required' })}
                      className="input-field text-sm"
                      placeholder="Meerut"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">State *</label>
                    <input
                      {...register('state', { required: 'State is required' })}
                      className="input-field text-sm"
                      placeholder="Uttar Pradesh"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-gray-700 block mb-1">Pincode *</label>
                    <input
                      {...register('postalCode', { required: 'Pincode is required' })}
                      className="input-field text-sm"
                      placeholder="250001"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Save Address as Default Option */}
            <div className="pt-3 border-t border-gray-100 flex items-center gap-2.5">
              <input
                type="checkbox"
                id="saveAsDefault"
                checked={saveAsDefault}
                onChange={(e) => setSaveAsDefault(e.target.checked)}
                className="w-4 h-4 text-brand-600 border-gray-300 rounded focus:ring-brand-500 cursor-pointer"
              />
              <label htmlFor="saveAsDefault" className="text-xs font-bold text-gray-700 cursor-pointer select-none flex items-center gap-1.5">
                <span>Save this address as default delivery address</span>
              </label>
            </div>
          </div>

          {/* Step 2: Shipping & Delivery Method (Shopping Only) */}
          {effectiveVertical === 'shopping' && (
            <div className="card p-6 space-y-4">
              <div className="flex items-center gap-2.5 border-b border-gray-100 pb-3">
                <div className="w-7 h-7 bg-brand-500 text-white rounded-full flex items-center justify-center font-bold text-xs">
                  2
                </div>
                <h2 className="text-lg font-bold text-gray-900">Shipping & Delivery Speed</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {deliveryOptions.map((opt) => {
                  const isSelected = (currentDeliveryOption?._id === opt._id);
                  const isFree = opt.minOrderForFree > 0 && subtotal >= opt.minOrderForFree;
                  return (
                    <div
                      key={opt._id}
                      onClick={() => setSelectedDeliveryOptionId(opt._id)}
                      className={`p-4 rounded-2xl border cursor-pointer transition-all flex items-start justify-between ${
                        isSelected
                          ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <TruckIcon className="w-4 h-4 text-brand-600" />
                          <h4 className="text-sm font-bold text-gray-900">{opt.name}</h4>
                        </div>
                        <p className="text-xs text-gray-500">{opt.estimatedDays}</p>
                        {opt.minOrderForFree > 0 && (
                          <p className="text-[10px] text-emerald-600 font-semibold">
                            Free on orders over ₹{opt.minOrderForFree}
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-extrabold text-gray-900">
                          {isFree ? <span className="text-emerald-600">FREE</span> : `₹${opt.price}`}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Payment Method */}
          <div className="card p-6 space-y-5">
            <div className="flex items-center gap-2.5 border-b border-gray-100 pb-3">
              <div className="w-7 h-7 bg-brand-500 text-white rounded-full flex items-center justify-center font-bold text-xs">
                {effectiveVertical === 'shopping' ? 3 : 2}
              </div>
              <h2 className="text-lg font-bold text-gray-900">Payment Method</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Cash on Delivery */}
              <div
                onClick={() => {
                  if (!hasDisableCOD) setPaymentMethod('cod');
                }}
                className={`p-5 rounded-2xl border transition-all flex items-start gap-4 ${
                  hasDisableCOD ? 'opacity-50 cursor-not-allowed bg-gray-50' : 'cursor-pointer hover:border-gray-300'
                } ${
                  paymentMethod === 'cod' && !hasDisableCOD
                    ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                    : 'border-gray-200'
                }`}
              >
                <div className="p-3 bg-amber-100 text-amber-800 rounded-xl">
                  <BanknotesIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Cash on Delivery (COD)</h3>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                    Pay with cash or UPI QR code when your package arrives.
                  </p>
                  {hasDisableCOD && (
                    <p className="text-xs text-red-500 mt-1 font-semibold">One or more items require prepaid payment</p>
                  )}
                </div>
              </div>

              {/* Online Card / Stripe */}
              <div
                onClick={() => setPaymentMethod('stripe')}
                className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-start gap-4 ${
                  paymentMethod === 'stripe'
                    ? 'border-brand-500 bg-brand-50/40 ring-2 ring-brand-500/20'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="p-3 bg-purple-100 text-purple-800 rounded-xl">
                  <CreditCardIcon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Card / NetBanking (Stripe)</h3>
                  <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                    Fast & secure online card checkout powered by Stripe.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Order Summary Review (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="card p-6 space-y-5 sticky top-20">
            <h3 className="font-bold text-gray-900 text-lg">Order Items ({items.length})</h3>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {items.map((item) => (
                <div key={item._id} className="flex items-center gap-3">
                  <img
                    src={item.image || item.product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=150'}
                    alt=""
                    className="w-12 h-12 object-cover rounded-lg border border-gray-100 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-gray-900 truncate">{item.product?.name || item.name}</p>
                    {item.variantLabel && (
                      <p className="text-[10px] text-brand-700 font-medium bg-brand-50 inline-block px-1 rounded">{item.variantLabel}</p>
                    )}
                    <p className="text-[11px] text-gray-500">Qty: {item.quantity} × ₹{Number(item.price).toLocaleString('en-IN')}</p>
                  </div>
                  <span className="text-xs font-bold text-gray-900">
                    ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>

            <div className="border-t border-gray-100 pt-4 space-y-2 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Discount</span>
                  <span>-₹{discount.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Delivery ({currentDeliveryOption?.name || 'Standard'})</span>
                <span>{shipping === 0 ? <span className="text-emerald-600 font-semibold">FREE</span> : `₹${shipping}`}</span>
              </div>
              {tax > 0 && (
                <div className="flex justify-between text-gray-600">
                  <span>{activeTax?.name || 'GST (18%)'}</span>
                  <span>₹{tax.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="border-t border-gray-100 pt-2 flex justify-between text-lg font-extrabold text-gray-900">
                <span>Total Amount</span>
                <span className="text-brand-600">₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              type="submit"
              disabled={placingOrder}
              className="w-full btn-brand py-4 font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-brand-500/25"
            >
              <ShieldCheckIcon className="w-5 h-5" />
              <span>{placingOrder ? 'Processing Order...' : `Place Order • ₹${total.toLocaleString('en-IN')}`}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
