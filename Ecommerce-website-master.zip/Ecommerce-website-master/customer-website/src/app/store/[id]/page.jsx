'use client';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  BuildingStorefrontIcon,
  ShieldCheckIcon,
  StarIcon,
  ArrowLeftIcon,
  ShoppingBagIcon,
  EnvelopeIcon,
  CheckBadgeIcon,
} from '@heroicons/react/24/solid';
import ProductCard from '@/components/shop/ProductCard';
import { GET_PRODUCTS } from '@/graphql/queries';

export default function SellerStorePage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const sellerId = params?.id ? decodeURIComponent(params.id) : '';
  const sellerNameParam = searchParams?.get('name') || '';
  const categoryParam = searchParams?.get('category') || '';

  const isOfficialStore = sellerId === 'official-brand-store' || sellerId === 'official' || !sellerId;

  const { data, loading, error } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: isOfficialStore
        ? { ...(categoryParam ? { category: categoryParam } : { all: true }) }
        : { vendorId: sellerId },
      pagination: { page: 1, limit: 60 },
    },
    skip: !sellerId,
    fetchPolicy: 'cache-and-network',
  });

  const rawProducts = data?.getProducts?.products || [];
  const products = isOfficialStore && categoryParam && rawProducts.length > 0
    ? rawProducts.filter((p) => p.category?.slug === categoryParam || p.category?._id === categoryParam)
    : rawProducts;

  const vendorInfo = products[0]?.vendor;
  const storeName = vendorInfo?.name || sellerNameParam || 'Official Brand Store';

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back button */}
      <button
        onClick={() => router.back()}
        className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-900 transition-colors"
      >
        <ArrowLeftIcon className="w-4 h-4" /> Back to Products
      </button>

      {/* Seller Header Profile Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-10 shadow-lg">
        <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Seller Logo */}
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white p-1 shadow-md overflow-hidden flex-shrink-0 border-2 border-white/20">
            {vendorInfo?.avatar ? (
              <img
                src={vendorInfo.avatar}
                alt={vendorInfo?.name || 'Seller Logo'}
                className="w-full h-full object-cover rounded-xl"
              />
            ) : (
              <div className="w-full h-full bg-indigo-50 text-indigo-600 flex items-center justify-center text-4xl rounded-xl">
                🏪
              </div>
            )}
          </div>

          {/* Seller Details */}
          <div className="flex-1 text-center sm:text-left space-y-2">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                {storeName}
              </h1>
              <span className="inline-flex items-center gap-1 bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2.5 py-0.5 rounded-full text-xs font-bold">
                <CheckBadgeIcon className="w-4 h-4 text-blue-400" /> Verified Seller
              </span>
            </div>

            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl">
              Welcome to {storeName}&apos;s official storefront on Suaaka. Browse 100% authentic items backed by fast delivery and easy returns.
            </p>

            {/* Quick Stats Strip */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 sm:gap-6 pt-3 text-xs sm:text-sm">
              <div className="flex items-center gap-1.5 text-amber-300">
                <StarIcon className="w-4 h-4 text-amber-400" />
                <span className="font-bold">4.8 / 5.0</span>
                <span className="text-slate-400 text-xs">(Store Rating)</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-300">
                <ShoppingBagIcon className="w-4 h-4 text-indigo-400" />
                <span className="font-bold">{products.length} Products Available</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-300">
                <ShieldCheckIcon className="w-4 h-4 text-emerald-400" />
                <span>100% Buyer Protection</span>
              </div>
            </div>
          </div>
        </div>

        {/* Ambient decorative glow */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Store Products Feed */}
      <div className="space-y-6">
        <div className="flex items-center justify-between border-b border-gray-200 pb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
              All Products from {storeName}
            </h2>
            <p className="text-xs text-gray-500">
              Showing {products.length} catalog items
            </p>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card p-4 h-80 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-gray-100 p-8 space-y-3">
            <span className="text-4xl">📦</span>
            <h3 className="text-lg font-bold text-gray-900">No Products Listed Yet</h3>
            <p className="text-xs text-gray-500 max-w-sm mx-auto">
              This seller currently has no active products in stock. Please check back soon!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {products.map((prod) => (
              <ProductCard key={prod._id} product={prod} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
