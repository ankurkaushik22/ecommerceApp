'use client';
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import { TrashIcon, PlusIcon, MinusIcon, ArrowRightIcon, TagIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_CART, VALIDATE_COUPON } from '@/graphql/queries';
import { UPDATE_CART_ITEM, REMOVE_FROM_CART, CLEAR_CART, APPLY_COUPON, REMOVE_COUPON } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';

export default function CartPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const {
    items: localItems,
    updateQuantity: updateLocalQty,
    removeItem: removeLocalItem,
    clearCart: clearLocalCart,
    subtotal: localSubtotal,
  } = useCartStore();

  const [couponCode, setCouponCode] = useState('');
  const [localCoupon, setLocalCoupon] = useState(null);

  const { data, loading, refetch } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [removeFromCart] = useMutation(REMOVE_FROM_CART, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [clearCartMutation] = useMutation(CLEAR_CART, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [applyCouponMutation, { loading: applyingCoupon }] = useMutation(APPLY_COUPON, {
    onCompleted: () => {
      toast.success('Coupon applied!');
      setCouponCode('');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [removeCouponMutation] = useMutation(REMOVE_COUPON, {
    onCompleted: () => {
      toast.success('Coupon removed');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const cart = isAuthenticated ? data?.getCart : null;
  const items = isAuthenticated ? cart?.items || [] : localItems;
  const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
  const discount = isAuthenticated
    ? cart?.couponDiscount || 0
    : localCoupon
    ? localCoupon.discount
    : 0;
  const appliedCouponCode = isAuthenticated ? cart?.couponCode : localCoupon?.code;

  const shipping = subtotal > 50 || items.length === 0 ? 0 : 9.99;
  const total = Math.max(0, subtotal - discount + shipping);

  const handleApplyCoupon = (e) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    if (isAuthenticated) {
      applyCouponMutation({ variables: { code: couponCode.trim().toUpperCase() } });
    } else {
      // Mock client-side coupon check for guest
      const code = couponCode.trim().toUpperCase();
      if (code === 'SAVE10') {
        const disc = subtotal * 0.1;
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon SAVE10 applied!');
      } else if (code === 'SAVE20') {
        const disc = subtotal * 0.2;
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon SAVE20 applied!');
      } else if (code === 'FLASH50') {
        const disc = subtotal * 0.5;
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon FLASH50 applied!');
      } else {
        toast.error('Invalid coupon code. Try SAVE10 or FLASH50');
      }
      setCouponCode('');
    }
  };

  const handleRemoveCoupon = () => {
    if (isAuthenticated) {
      removeCouponMutation();
    } else {
      setLocalCoupon(null);
      toast.success('Coupon removed');
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="h-96 bg-gray-100 rounded-3xl animate-pulse" />
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mx-auto text-4xl">
          🛒
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Cart is Empty</h1>
        <p className="text-gray-500 max-w-sm mx-auto text-sm leading-relaxed">
          Looks like you haven't added anything to your cart yet. Explore thousands of great products today!
        </p>
        <Link href="/products" className="btn-brand inline-flex items-center gap-2 text-sm px-6 py-3">
          Start Shopping <ArrowRightIcon className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Shopping Cart</h1>
        <button
          onClick={() => {
            if (isAuthenticated) clearCartMutation();
            else clearLocalCart();
          }}
          className="text-xs text-red-600 hover:underline font-semibold"
        >
          Clear Cart
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Items List (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {items.map((item) => {
            const product = item.product;
            const imgSrc = product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300';

            return (
              <div
                key={item._id}
                className="p-4 sm:p-5 rounded-2xl bg-white border border-gray-100 shadow-sm flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between"
              >
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-50 flex-shrink-0">
                    <img
                      src={imgSrc}
                      alt=""
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300';
                      }}
                    />
                  </div>
                  <div className="min-w-0">
                    <Link
                      href={`/products/${product?.slug || '#'}`}
                      className="font-bold text-gray-900 text-sm sm:text-base hover:text-brand-600 transition-colors line-clamp-1"
                    >
                      {product?.name || item.name}
                    </Link>
                    <p className="text-xs text-gray-400 mt-0.5">
                      Price: <span className="font-semibold text-gray-800">${item.price?.toFixed(2)}</span>
                    </p>
                    {product?.freeShipping && (
                      <span className="inline-block mt-1 text-[10px] bg-emerald-50 text-emerald-700 font-semibold px-2 py-0.5 rounded-full">
                        Free Shipping
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-3 sm:pt-0 border-t sm:border-t-0 border-gray-100">
                  {/* Quantity */}
                  <div className="flex items-center border border-gray-200 rounded-xl bg-white shadow-sm p-1">
                    <button
                      onClick={() => {
                        if (isAuthenticated) {
                          if (item.quantity > 1) {
                            updateCartItem({ variables: { itemId: item._id, quantity: item.quantity - 1 } });
                          } else {
                            removeFromCart({ variables: { itemId: item._id } });
                          }
                        } else {
                          updateLocalQty(item._id, item.quantity - 1);
                        }
                      }}
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
                    >
                      <MinusIcon className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm font-bold text-gray-900">{item.quantity}</span>
                    <button
                      onClick={() => {
                        if (isAuthenticated) {
                          updateCartItem({ variables: { itemId: item._id, quantity: item.quantity + 1 } });
                        } else {
                          updateLocalQty(item._id, item.quantity + 1);
                        }
                      }}
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
                    >
                      <PlusIcon className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Total item price */}
                  <div className="text-right min-w-[70px]">
                    <span className="text-base font-extrabold text-gray-900">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => {
                      if (isAuthenticated) removeFromCart({ variables: { itemId: item._id } });
                      else removeLocalItem(item._id);
                    }}
                    className="p-2 text-gray-400 hover:text-red-600 rounded-lg transition-colors"
                  >
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}

          <Link href="/products" className="inline-block text-xs font-semibold text-brand-600 hover:underline pt-2">
            ← Continue Shopping
          </Link>
        </div>

        {/* Order Summary Card (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Coupon Box */}
          <div className="card p-5 space-y-3">
            <h3 className="font-bold text-sm text-gray-900 flex items-center gap-1.5">
              <TagIcon className="w-4 h-4 text-brand-500" />
              <span>Apply Promo Code</span>
            </h3>

            {appliedCouponCode ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-bold text-emerald-800 text-xs">{appliedCouponCode}</span>
                  <p className="text-[11px] text-emerald-600">-${discount.toFixed(2)} discount applied</p>
                </div>
                <button
                  onClick={handleRemoveCoupon}
                  className="text-xs text-red-600 font-bold hover:underline"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. FLASH50"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="input-field text-xs uppercase"
                />
                <button
                  type="submit"
                  disabled={applyingCoupon || !couponCode}
                  className="btn-brand text-xs px-4 flex-shrink-0"
                >
                  Apply
                </button>
              </form>
            )}
          </div>

          {/* Price Breakdown */}
          <div className="card p-6 space-y-4">
            <h3 className="font-bold text-gray-900 text-lg">Order Summary</h3>

            <div className="space-y-2.5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Coupon Discount</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between text-gray-600">
                <span>Estimated Shipping</span>
                <span>{shipping === 0 ? <span className="text-emerald-600 font-semibold">FREE</span> : `$${shipping.toFixed(2)}`}</span>
              </div>

              {subtotal > 0 && (
                <div className="flex justify-between text-gray-600">
                  <span>Estimated Tax (8%)</span>
                  <span>${(Math.round(Math.max(0, subtotal - discount) * 0.08 * 100) / 100).toFixed(2)}</span>
                </div>
              )}

              <div className="border-t border-gray-100 pt-3 flex justify-between text-base font-extrabold text-gray-900">
                <span>Estimated Total</span>
                <span>${(Math.max(0, subtotal - discount + shipping + (Math.round(Math.max(0, subtotal - discount) * 0.08 * 100) / 100))).toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => router.push('/checkout')}
              className="w-full btn-brand py-3.5 flex items-center justify-center gap-2 shadow-lg shadow-brand-500/25 text-sm font-bold"
            >
              <span>Proceed to Checkout</span>
              <ArrowRightIcon className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-xs text-gray-400 pt-1">
              <span>🔒 256-Bit SSL Encrypted Checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
