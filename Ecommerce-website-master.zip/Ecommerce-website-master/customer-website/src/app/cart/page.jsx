'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import { TrashIcon, PlusIcon, MinusIcon, ArrowRightIcon, TagIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_CART, VALIDATE_COUPON } from '@/graphql/queries';
import { UPDATE_CART_ITEM, REMOVE_FROM_CART, CLEAR_CART, APPLY_COUPON, REMOVE_COUPON, SYNC_CART } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import { isFoodItem, isGroceryItem, isServiceItem, isShoppingItem } from '@/utils/cartHelpers';

export default function CartPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const {
    items: localItems,
    updateQuantity: updateLocalQty,
    removeItem: removeLocalItem,
    clearCart: clearLocalCart,
    subtotal: localSubtotal,
  } = useCartStore();

  const [couponCode, setCouponCode] = useState('');
  const [localCoupon, setLocalCoupon] = useState(null);
  const [selectedSlot, setSelectedSlot] = useState('Today: 3PM - 5PM');
  const syncAttempted = useRef(false);

  const { data, loading, refetch } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [syncCartMutation] = useMutation(SYNC_CART, {
    onCompleted: () => {
      clearLocalCart();
      refetch();
    },
    onError: (e) => console.error('Cart sync error:', e),
  });

  useEffect(() => {
    if (isAuthenticated && localItems && localItems.length > 0 && !syncAttempted.current) {
      syncAttempted.current = true;
      const itemsToSync = localItems
        .filter((item) => item.product && (item.product._id || item.product))
        .map((item) => ({
          productId: item.product._id || item.product,
          variantIndex: item.variantIndex ?? -1,
          quantity: item.quantity || 1,
        }));

      if (itemsToSync.length > 0) {
        syncCartMutation({ variables: { items: itemsToSync } });
      }
    }
  }, [isAuthenticated, localItems, syncCartMutation]);

  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [removeFromCart] = useMutation(REMOVE_FROM_CART, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [clearCartMutation] = useMutation(CLEAR_CART, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const [applyCouponMutation, { loading: applyingCoupon }] = useMutation(APPLY_COUPON, {
    onCompleted: () => {
      toast.success('Coupon applied!');
      setCouponCode('');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [removeCouponMutation] = useMutation(REMOVE_COUPON, {
    onCompleted: () => {
      toast.success('Coupon removed');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [activeTab, setActiveTab] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('vertical') || 'all';
    }
    return 'all';
  });

  const cart = isAuthenticated ? data?.getCart : null;
  const serverItems = cart?.items || [];
  const rawItems = (isAuthenticated && serverItems.length > 0)
    ? serverItems
    : (localItems.length > 0 ? localItems : serverItems);

  const foodItems = rawItems.filter(isFoodItem);
  const groceryItems = rawItems.filter(isGroceryItem);
  const serviceItems = rawItems.filter(isServiceItem);
  const shoppingItems = rawItems.filter(isShoppingItem);

  let items = rawItems;
  if (activeTab === 'food') items = foodItems;
  else if (activeTab === 'grocery') items = groceryItems;
  else if (activeTab === 'services') items = serviceItems;
  else if (activeTab === 'shopping') items = shoppingItems;

  const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
  const discount = isAuthenticated
    ? cart?.couponDiscount || 0
    : localCoupon
    ? localCoupon.discount
    : 0;
  const appliedCouponCode = isAuthenticated ? cart?.couponCode : localCoupon?.code;

  const shipping = subtotal >= 499 || items.length === 0 ? 0 : 49;
  const estimatedTax = Math.round(Math.max(0, subtotal - discount) * 0.18 * 100) / 100;
  const total = Math.max(0, subtotal - discount + shipping + estimatedTax);

  const handleApplyCoupon = (e) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    if (isAuthenticated) {
      applyCouponMutation({ variables: { code: couponCode.trim().toUpperCase() } });
    } else {
      const code = couponCode.trim().toUpperCase();
      if (code === 'SAVE10') {
        const disc = Math.round(subtotal * 0.1);
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon SAVE10 applied!');
      } else if (code === 'SAVE20') {
        const disc = Math.round(subtotal * 0.2);
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon SAVE20 applied!');
      } else if (code === 'FLASH50') {
        const disc = Math.round(subtotal * 0.5);
        setLocalCoupon({ code, discount: disc });
        toast.success('Coupon FLASH50 applied!');
      } else {
        toast.error('Invalid coupon code. Try SAVE10 or FLASH50');
      }
      setCouponCode('');
    }
  };

  const handleRemoveCoupon = () => {
    if (isAuthenticated) {
      removeCouponMutation();
    } else {
      setLocalCoupon(null);
      toast.success('Coupon removed');
    }
  };

  if (loading) {
    return (
      <div className="w-full mx-auto px-4 py-12">
        <div className="h-96 bg-gray-100 rounded-3xl animate-pulse" />
      </div>
    );
  }

  if (rawItems.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mx-auto text-4xl">
          🛒
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Cart is Empty</h1>
        <p className="text-gray-500 max-w-sm mx-auto text-sm leading-relaxed">
          Looks like you haven't added anything to your cart yet. Explore thousands of great products today!
        </p>
        <Link href="/products" className="btn-brand inline-flex items-center gap-2 text-sm px-6 py-3">
          Start Shopping <ArrowRightIcon className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  const hasMultipleCategories =
    [foodItems.length > 0, groceryItems.length > 0, serviceItems.length > 0, shoppingItems.length > 0].filter(Boolean).length > 1;

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 pb-4 gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Cart</h1>
          {hasMultipleCategories && (
            <p className="text-xs text-slate-500 font-medium mt-1">
              Your cart has items from different categories. Filter by category tab below.
            </p>
          )}
        </div>

        <button
          onClick={() => {
            if (isAuthenticated) clearCartMutation();
            else clearLocalCart();
          }}
          className="text-xs text-red-600 hover:underline font-semibold self-start sm:self-auto"
        >
          Clear Cart
        </button>
      </div>

      {hasMultipleCategories && (
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white shadow-md'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Items ({rawItems.length})
          </button>
          {foodItems.length > 0 && (
            <button
              onClick={() => setActiveTab('food')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'food'
                  ? 'bg-orange-600 text-white shadow-md'
                  : 'bg-orange-50 text-orange-700 hover:bg-orange-100'
              }`}
            >
              🍔 Food ({foodItems.length})
            </button>
          )}
          {shoppingItems.length > 0 && (
            <button
              onClick={() => setActiveTab('shopping')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'shopping'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
              }`}
            >
              🛍️ Shopping ({shoppingItems.length})
            </button>
          )}
          {groceryItems.length > 0 && (
            <button
              onClick={() => setActiveTab('grocery')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'grocery'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
              }`}
            >
              🥦 Grocery ({groceryItems.length})
            </button>
          )}
          {serviceItems.length > 0 && (
            <button
              onClick={() => setActiveTab('services')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'services'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-purple-50 text-purple-700 hover:bg-purple-100'
              }`}
            >
              🛠️ Services ({serviceItems.length})
            </button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Items List (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          {items.map((item) => {
            const product = item.product;
            const imgSrc = item.image || product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300';

            return (
              <div
                key={item._id}
                className="p-4 sm:p-5 rounded-2xl bg-white border border-gray-100 shadow-sm flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between"
              >
                <div className="flex items-center gap-4 flex-1 min-w-0">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-50 flex-shrink-0">
                    <img
                      src={imgSrc}
                      alt=""
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300';
                      }}
                    />
                  </div>
                  <div className="min-w-0">
                    <Link
                      href={`/products/${product?.slug || '#'}`}
                      className="font-bold text-gray-900 text-sm sm:text-base hover:text-brand-600 transition-colors line-clamp-1"
                    >
                      {product?.name || item.name}
                    </Link>
                    {item.variantLabel && (
                      <p className="text-xs text-brand-700 font-medium bg-brand-50 inline-block px-2 py-0.5 rounded-full mt-0.5">
                        {item.variantLabel}
                      </p>
                    )}
                    <p className="text-xs text-gray-500 mt-0.5 font-medium">
                      Price: <span className="font-bold text-gray-900">${item.price?.toFixed(2)}</span>
                      {product?.unitMeasure && (
                        <span className="text-gray-400 font-normal"> / {product.unitMeasure}</span>
                      )}
                    </p>
                    {product?.freeShipping && (
                      <span className="inline-block mt-1 text-[10px] bg-emerald-50 text-emerald-700 font-semibold px-2 py-0.5 rounded-full">
                        Free Shipping
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-3 sm:pt-0 border-t sm:border-t-0 border-gray-100">
                  {/* Quantity */}
                  <div className="flex items-center border border-gray-200 rounded-xl bg-white shadow-sm p-1">
                    <button
                      onClick={() => {
                        const isServerItem = Boolean(item._id && !String(item._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(item._id));
                        if (isAuthenticated && isServerItem) {
                          if (item.quantity > 1) {
                            updateCartItem({ variables: { itemId: item._id, quantity: item.quantity - 1 } });
                          } else {
                            removeFromCart({ variables: { itemId: item._id } });
                          }
                        } else {
                          updateLocalQty(item._id, item.quantity - 1);
                        }
                      }}
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
                    >
                      <MinusIcon className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm font-bold text-gray-900">{item.quantity}</span>
                    <button
                      onClick={() => {
                        const isServerItem = Boolean(item._id && !String(item._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(item._id));
                        if (isAuthenticated && isServerItem) {
                          updateCartItem({ variables: { itemId: item._id, quantity: item.quantity + 1 } });
                        } else {
                          updateLocalQty(item._id, item.quantity + 1);
                        }
                      }}
                      className="p-1.5 text-gray-500 hover:text-gray-700 rounded-lg hover:bg-gray-100"
                    >
                      <PlusIcon className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Total item price */}
                  <div className="text-right min-w-[80px]">
                    <span className="text-base font-extrabold text-gray-900">
                      ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => {
                      const isServerItem = Boolean(item._id && !String(item._id).startsWith('local-') && /^[0-9a-fA-F]{24}$/.test(item._id));
                      if (isAuthenticated && isServerItem) removeFromCart({ variables: { itemId: item._id } });
                      else removeLocalItem(item._id);
                    }}
                    className="p-2 text-gray-400 hover:text-red-600 rounded-lg transition-colors"
                  >
                    <TrashIcon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}

          <Link href="/products" className="inline-block text-xs font-semibold text-brand-600 hover:underline pt-2">
            ← Continue Shopping
          </Link>
        </div>

        {/* Order Summary Card (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Coupon Box */}
          <div className="card p-5 space-y-3">
            <h3 className="font-bold text-sm text-gray-900 flex items-center gap-1.5">
              <TagIcon className="w-4 h-4 text-brand-500" />
              <span>Apply Promo Code</span>
            </h3>

            {appliedCouponCode ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-bold text-emerald-800 text-xs">{appliedCouponCode}</span>
                  <p className="text-[11px] text-emerald-600">-₹{discount.toLocaleString('en-IN')} discount applied</p>
                </div>
                <button
                  onClick={handleRemoveCoupon}
                  className="text-xs text-red-600 font-bold hover:underline"
                >
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyCoupon} className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. FLASH50"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="input-field text-xs uppercase"
                />
                <button
                  type="submit"
                  disabled={applyingCoupon || !couponCode}
                  className="btn-brand text-xs px-4 flex-shrink-0"
                >
                  Apply
                </button>
              </form>
            )}
          </div>

          {/* Delivery Time Slot Selector (Matching Reference 4) */}
          <div className="card p-5 space-y-3">
            <h3 className="font-bold text-sm text-gray-900 flex items-center justify-between">
              <span>Delivery Time</span>
              <span className="text-xs text-emerald-600 font-bold">{selectedSlot}</span>
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'today-3-5', day: 'Today', time: '3PM - 5PM' },
                { id: 'tomorrow-9-11', day: 'Tomorrow', time: '9AM - 11AM' },
                { id: 'tomorrow-5-7', day: 'Tomorrow', time: '5PM - 7PM' },
              ].map((slot) => {
                const isSelected = selectedSlot === `${slot.day}: ${slot.time}`;
                return (
                  <button
                    key={slot.id}
                    type="button"
                    onClick={() => setSelectedSlot(`${slot.day}: ${slot.time}`)}
                    className={`p-2.5 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20'
                        : 'border-gray-200 hover:border-gray-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center justify-center gap-1">
                      <span className={`text-xs font-extrabold ${isSelected ? 'text-emerald-700' : 'text-gray-800'}`}>
                        {slot.day}
                      </span>
                      {isSelected && <span className="text-emerald-600 text-xs font-bold">✔</span>}
                    </div>
                    <span className={`text-[10px] font-semibold block mt-0.5 ${isSelected ? 'text-emerald-600' : 'text-gray-500'}`}>
                      {slot.time}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Price Breakdown */}
          <div className="card p-6 space-y-4">
            <h3 className="font-bold text-gray-900 text-lg">Order Summary</h3>

            <div className="space-y-2.5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>₹{subtotal.toLocaleString('en-IN')}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Coupon Discount</span>
                  <span>-₹{discount.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="flex justify-between text-gray-600">
                <span>Estimated Delivery</span>
                <span>{shipping === 0 ? <span className="text-emerald-600 font-semibold">FREE</span> : `₹${shipping}`}</span>
              </div>

              {subtotal > 0 && (
                <div className="flex justify-between text-gray-600">
                  <span>Estimated GST (18%)</span>
                  <span>₹{estimatedTax.toLocaleString('en-IN')}</span>
                </div>
              )}

              <div className="border-t border-gray-100 pt-3 flex justify-between text-base font-extrabold text-gray-900">
                <span>Total Amount</span>
                <span>₹{total.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <button
              onClick={() => {
                const checkoutVertical = activeTab !== 'all' ? activeTab : (items.length > 0 ? getItemVertical(items[0]) : 'shopping');
                router.push(`/checkout?slot=${encodeURIComponent(selectedSlot)}&vertical=${checkoutVertical}`);
              }}
              className="w-full py-3.5 px-4 rounded-xl text-white font-extrabold bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 transition-all active:scale-98 text-sm"
            >
              <span>Proceed to Checkout</span>
              <ArrowRightIcon className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-center gap-2 text-xs text-gray-400 pt-1">
              <span>🔒 256-Bit SSL Encrypted Checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
