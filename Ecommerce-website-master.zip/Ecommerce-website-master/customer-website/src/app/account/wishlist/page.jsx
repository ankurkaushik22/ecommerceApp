'use client';
import { useQuery } from '@apollo/client';
import Link from 'next/link';
import { HeartIcon, ShoppingCartIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import ProductCard from '@/components/shop/ProductCard';
import { GET_ME } from '@/graphql/queries';
import { useAuthStore } from '@/store/authStore';

export default function WishlistPage() {
  const { isAuthenticated } = useAuthStore();
  const { data, loading } = useQuery(GET_ME, { skip: !isAuthenticated });

  if (!isAuthenticated) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-gray-900">Sign In to View Your Wishlist</h2>
        <p className="text-gray-500">Save items you love to review and purchase later.</p>
        <Link href="/login?redirect=/account/wishlist" className="btn-brand inline-block text-sm">
          Sign In
        </Link>
      </div>
    );
  }

  const wishlist = data?.me?.wishlist || [];

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Wishlist</h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-0.5">{wishlist.length} saved products</p>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
          ))}
        </div>
      ) : wishlist.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-gray-100 space-y-4">
          <HeartIcon className="w-16 h-16 text-gray-300 mx-auto" />
          <h3 className="text-lg font-bold text-gray-900">Your wishlist is empty</h3>
          <p className="text-xs sm:text-sm text-gray-500 max-w-sm mx-auto">
            Explore our collections and click the heart icon on any product to save it here.
          </p>
          <Link href="/products" className="btn-brand inline-flex items-center gap-1.5 text-xs font-bold px-5 py-2.5">
            <span>Explore Products</span>
            <ArrowRightIcon className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {wishlist.map((item) => (
            <ProductCard key={item._id} product={item} />
          ))}
        </div>
      )}
    </div>
  );
}
