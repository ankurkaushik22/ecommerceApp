'use client';
import { useQuery, useMutation } from '@apollo/client';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';
import { BellIcon, CheckIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_NOTIFICATIONS, GET_UNREAD_COUNT } from '@/graphql/queries';
import { MARK_NOTIFICATION_READ, MARK_ALL_READ } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

export default function NotificationsPage() {
  const { isAuthenticated } = useAuthStore();
  const router = useRouter();

  const { data, loading, refetch } = useQuery(GET_NOTIFICATIONS, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const [markRead] = useMutation(MARK_NOTIFICATION_READ, {
    refetchQueries: [{ query: GET_UNREAD_COUNT }, { query: GET_NOTIFICATIONS }],
    onCompleted: () => refetch(),
  });

  const [markAllRead, { loading: markingAll }] = useMutation(MARK_ALL_READ, {
    refetchQueries: [{ query: GET_UNREAD_COUNT }, { query: GET_NOTIFICATIONS }],
    update(cache) {
      cache.writeQuery({
        query: GET_UNREAD_COUNT,
        data: { getUnreadNotificationCount: 0 },
      });
    },
    onCompleted: () => {
      toast.success('All notifications marked as read');
      refetch();
    },
  });

  const notifications = data?.getNotifications || [];

  const handleNotificationClick = async (notif) => {
    // Mark as read if unread
    if (!notif.isRead) {
      markRead({ variables: { id: notif._id } });
    }

    // Navigate based on notification type
    if (notif.type === 'order' && notif.data?.orderId) {
      router.push(`/orders/${notif.data.orderId}`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-gray-900">Notifications</h1>
          <p className="text-xs text-gray-500 mt-0.5">Stay updated on your shipments and offers</p>
        </div>
        {notifications.some((n) => !n.isRead) && (
          <button
            onClick={() => markAllRead()}
            disabled={markingAll}
            className="text-xs font-bold text-brand-600 hover:underline"
          >
            Mark all as read
          </button>
        )}
      </div>

      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-3xl border border-gray-100 space-y-2">
            <BellIcon className="w-12 h-12 text-gray-300 mx-auto" />
            <h3 className="text-sm font-bold text-gray-900">No notifications yet</h3>
            <p className="text-xs text-gray-400">We'll alert you here when your order updates or deals happen.</p>
          </div>
        ) : (
          notifications.map((notif) => (
            <div
              key={notif._id}
              onClick={() => handleNotificationClick(notif)}
              className={`card p-4 flex items-start gap-4 cursor-pointer transition-all rounded-2xl hover:shadow-md ${
                !notif.isRead ? 'bg-brand-50/40 border-brand-200' : 'bg-white border-gray-100'
              }`}
            >
              <div className={`p-2.5 rounded-xl ${!notif.isRead ? 'bg-brand-500 text-white' : 'bg-gray-100 text-gray-500'}`}>
                <BellIcon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-gray-900">{notif.title}</h4>
                  <span className="text-[11px] text-gray-400">
                    {notif.createdAt ? format(new Date(notif.createdAt), 'MMM d, h:mm a') : ''}
                  </span>
                </div>
                <p className="text-xs text-gray-600 mt-1 leading-relaxed">{notif.message}</p>
                {notif.type === 'order' && notif.data?.orderId && (
                  <span className="inline-block mt-1.5 text-[11px] font-semibold text-brand-600">
                    View Order Details →
                  </span>
                )}
              </div>
              {!notif.isRead && (
                <span className="w-2.5 h-2.5 bg-brand-500 rounded-full flex-shrink-0 mt-2" />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
