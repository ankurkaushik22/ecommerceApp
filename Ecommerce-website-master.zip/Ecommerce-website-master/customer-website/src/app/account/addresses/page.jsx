'use client';
import { useState } from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { PlusIcon, TrashIcon, MapPinIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ME } from '@/graphql/queries';
import { ADD_ADDRESS, DELETE_ADDRESS } from '@/graphql/mutations';

export default function AddressesPage() {
  const [showAddForm, setShowAddForm] = useState(false);

  const { data, loading, refetch } = useQuery(GET_ME);
  const addresses = data?.me?.addresses || [];

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      label: 'Home',
      fullName: '',
      phone: '',
      addressLine1: '',
      addressLine2: '',
      city: '',
      state: '',
      postalCode: '',
      country: 'United States',
      isDefault: false,
    },
  });

  const [addAddressMutation, { loading: adding }] = useMutation(ADD_ADDRESS, {
    onCompleted: () => {
      toast.success('Address added successfully!');
      setShowAddForm(false);
      reset();
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [deleteAddressMutation] = useMutation(DELETE_ADDRESS, {
    onCompleted: () => {
      toast.success('Address removed');
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const onAddSubmit = (formData) => {
    addAddressMutation({ variables: { input: formData } });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="flex items-center justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Your Saved Addresses</h1>
          <p className="text-xs sm:text-sm text-gray-500 mt-0.5">Manage delivery addresses for faster checkouts</p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="btn-brand text-xs font-bold px-4 py-2.5 flex items-center gap-1.5 shadow-sm"
        >
          <PlusIcon className="w-4 h-4" />
          <span>Add Address</span>
        </button>
      </div>

      {/* Add Address Form Modal / Inline Box */}
      {showAddForm && (
        <div className="card p-6 border-brand-200 bg-brand-50/20 space-y-4">
          <h3 className="font-bold text-gray-900 text-base">Add New Address</h3>
          <form onSubmit={handleSubmit(onAddSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">Address Label</label>
                <select {...register('label')} className="input-field text-xs">
                  <option value="Home">Home</option>
                  <option value="Work">Work / Office</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">Full Name *</label>
                <input {...register('fullName', { required: true })} className="input-field text-xs" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">Phone Number *</label>
                <input {...register('phone', { required: true })} className="input-field text-xs" />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Street Address *</label>
              <input {...register('addressLine1', { required: true })} className="input-field text-xs" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">Apt / Suite (Optional)</label>
                <input {...register('addressLine2')} className="input-field text-xs" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">City *</label>
                <input {...register('city', { required: true })} className="input-field text-xs" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">State *</label>
                <input {...register('state', { required: true })} className="input-field text-xs" />
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-700 block mb-1">Postal Code *</label>
                <input {...register('postalCode', { required: true })} className="input-field text-xs" />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <label className="flex items-center gap-2 text-xs text-gray-700 font-semibold cursor-pointer">
                <input type="checkbox" {...register('isDefault')} className="w-4 h-4 text-brand-600 rounded" />
                <span>Make this my default delivery address</span>
              </label>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={adding}
                  className="btn-brand text-xs font-bold px-5 py-2"
                >
                  {adding ? 'Saving...' : 'Save Address'}
                </button>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Addresses Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        {addresses.length === 0 ? (
          <div className="col-span-full text-center py-16 bg-white rounded-3xl border border-gray-100 space-y-3">
            <MapPinIcon className="w-12 h-12 text-gray-300 mx-auto" />
            <h3 className="text-base font-bold text-gray-900">No saved addresses</h3>
            <p className="text-xs text-gray-500">Add an address to speed up your checkout process.</p>
          </div>
        ) : (
          addresses.map((addr) => (
            <div
              key={addr._id}
              className="card p-5 space-y-3 relative group hover:shadow-md transition-all rounded-2xl flex flex-col justify-between"
            >
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] uppercase font-extrabold tracking-wider bg-brand-50 text-brand-700 px-2 py-0.5 rounded">
                    {addr.label}
                  </span>
                  {addr.isDefault && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                      Default
                    </span>
                  )}
                </div>
                <h4 className="font-bold text-sm text-gray-900">{addr.fullName}</h4>
                <p className="text-xs text-gray-600 leading-relaxed">
                  {addr.addressLine1} {addr.addressLine2 && `, ${addr.addressLine2}`}
                </p>
                <p className="text-xs text-gray-600">
                  {addr.city}, {addr.state} {addr.postalCode}
                </p>
                <p className="text-xs text-gray-400 pt-1">📞 {addr.phone}</p>
              </div>

              <div className="border-t border-gray-100 pt-3 flex justify-end">
                <button
                  onClick={() => deleteAddressMutation({ variables: { addressId: addr._id } })}
                  className="text-xs text-gray-400 hover:text-red-600 flex items-center gap-1 font-semibold transition-colors"
                >
                  <TrashIcon className="w-4 h-4" /> Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
