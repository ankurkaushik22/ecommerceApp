'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useQuery, useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import {
  UserCircleIcon, ShoppingBagIcon, HeartIcon,
  MapPinIcon, BellIcon, KeyIcon, ArrowRightIcon
} from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_ME } from '@/graphql/queries';
import { UPDATE_PROFILE, CHANGE_PASSWORD } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

export default function AccountPage() {
  const { user: authUser, updateUser } = useAuthStore();
  const [activeSection, setActiveSection] = useState('profile'); // profile | password

  const { data, loading, refetch } = useQuery(GET_ME, { fetchPolicy: 'network-only' });
  const user = data?.me || authUser;

  const { register: regProfile, handleSubmit: handleProfileSubmit, formState: { errors: profileErrors } } = useForm({
    values: {
      name: user?.name || '',
      phone: user?.phone || '',
      avatar: user?.avatar || '',
    },
  });

  const { register: regPass, handleSubmit: handlePassSubmit, reset: resetPass } = useForm();

  const [updateProfileMutation, { loading: savingProfile }] = useMutation(UPDATE_PROFILE, {
    onCompleted: (res) => {
      toast.success('Profile updated!');
      updateUser(res.updateProfile);
      refetch();
    },
    onError: (e) => toast.error(e.message),
  });

  const [changePasswordMutation, { loading: changingPass }] = useMutation(CHANGE_PASSWORD, {
    onCompleted: () => {
      toast.success('Password changed successfully!');
      resetPass();
    },
    onError: (e) => toast.error(e.message),
  });

  const onProfileSave = (formData) => {
    updateProfileMutation({ variables: formData });
  };

  const onPasswordSave = (formData) => {
    if (formData.newPassword !== formData.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    changePasswordMutation({
      variables: {
        currentPassword: formData.currentPassword,
        newPassword: formData.newPassword,
      },
    });
  };

  const SHORTCUTS = [
    { title: 'Your Orders', desc: 'Track, return, or buy again', href: '/orders', icon: ShoppingBagIcon },
    { title: 'Your Wishlist', desc: 'View saved items', href: '/account/wishlist', icon: HeartIcon },
    { title: 'Your Addresses', desc: 'Edit delivery locations', href: '/account/addresses', icon: MapPinIcon },
    { title: 'Notifications', desc: 'Order & promo alerts', href: '/account/notifications', icon: BellIcon },
  ];

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Account Header */}
      <div className="flex items-center gap-4 border-b border-gray-200 pb-6">
        <img
          src={user?.avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user?.name || 'User')}
          alt=""
          className="w-16 h-16 rounded-full border-2 border-brand-500 shadow-md"
        />
        <div>
          <h1 className="text-2xl font-extrabold text-gray-900">{user?.name}</h1>
          <p className="text-xs text-gray-500">{user?.email} • {user?.phone || 'No phone set'}</p>
        </div>
      </div>

      {/* Fast Shortcuts Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {SHORTCUTS.map((sc, i) => {
          const Icon = sc.icon;
          return (
            <Link
              key={i}
              href={sc.href}
              className="card p-5 hover:border-brand-300 hover:shadow-md transition-all flex items-center justify-between group rounded-2xl"
            >
              <div className="flex items-center gap-3.5">
                <div className="p-3 bg-brand-50 text-brand-600 rounded-xl group-hover:bg-brand-500 group-hover:text-white transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-gray-900">{sc.title}</h3>
                  <p className="text-xs text-gray-400 mt-0.5">{sc.desc}</p>
                </div>
              </div>
              <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-brand-600 transition-colors" />
            </Link>
          );
        })}
      </div>

      {/* Profile & Security Settings */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-4 space-y-2">
          <button
            onClick={() => setActiveSection('profile')}
            className={`w-full text-left p-4 rounded-xl text-sm font-bold flex items-center gap-3 transition-colors ${
              activeSection === 'profile'
                ? 'bg-brand-50 text-brand-700 border border-brand-200'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <UserCircleIcon className="w-5 h-5" />
            <span>Profile Details</span>
          </button>
          <button
            onClick={() => setActiveSection('password')}
            className={`w-full text-left p-4 rounded-xl text-sm font-bold flex items-center gap-3 transition-colors ${
              activeSection === 'password'
                ? 'bg-brand-50 text-brand-700 border border-brand-200'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <KeyIcon className="w-5 h-5" />
            <span>Change Password</span>
          </button>
        </div>

        <div className="md:col-span-8">
          {activeSection === 'profile' && (
            <div className="card p-6 sm:p-8 space-y-6">
              <h2 className="text-lg font-bold text-gray-900">Edit Personal Information</h2>
              <form onSubmit={handleProfileSubmit(onProfileSave, (errors) => {
                if (errors.phone) toast.error(errors.phone.message);
                if (errors.name) toast.error(errors.name.message);
              })} className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Full Name</label>
                  <input {...regProfile('name', { required: true })} className="input-field text-sm" />
                </div>
                <div>
                  <label className={`text-xs font-semibold block mb-1 ${profileErrors.phone ? 'text-red-600' : 'text-gray-700'}`}>Phone Number</label>
                  <input 
                    {...regProfile('phone', { required: 'Please fill mobile number first' })} 
                    placeholder="+1 (555) 000-0000" 
                    className={`input-field text-sm transition-colors ${profileErrors.phone ? 'border-red-500 bg-red-50 focus:border-red-500 focus:ring-red-200' : ''}`} 
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Avatar Image</label>
                  <div className="flex items-center gap-4">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={async (e) => {
                        const file = e.target.files[0];
                        if (!file) return;
                        const formData = new FormData();
                        formData.append('image', file);
                        const toastId = toast.loading('Uploading image...');
                        try {
                          const token = localStorage.getItem('shopToken');
                          const res = await fetch('https://ecommerce-api-yak7.onrender.com/api/upload', {
                            method: 'POST',
                            headers: { authorization: `Bearer ${token}` },
                            body: formData
                          });
                          const data = await res.json();
                          if (data.success) {
                            regProfile('avatar').onChange({ target: { value: data.url, name: 'avatar' }});
                            toast.success('Image uploaded successfully', { id: toastId });
                          } else {
                            throw new Error('Upload failed');
                          }
                        } catch (err) {
                          toast.error('Failed to upload image', { id: toastId });
                        }
                      }}
                      className="text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-bold file:bg-brand-50 file:text-brand-700 hover:file:bg-brand-100"
                    />
                    <input type="hidden" {...regProfile('avatar')} />
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={savingProfile}
                  className="btn-brand text-xs font-bold px-6 py-2.5"
                >
                  {savingProfile ? 'Saving...' : 'Save Profile Changes'}
                </button>
              </form>
            </div>
          )}

          {activeSection === 'password' && (
            <div className="card p-6 sm:p-8 space-y-6">
              <h2 className="text-lg font-bold text-gray-900">Update Password</h2>
              <form onSubmit={handlePassSubmit(onPasswordSave)} className="space-y-4 max-w-md">
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Current Password</label>
                  <input
                    type="password"
                    {...regPass('currentPassword', { required: true })}
                    className="input-field text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">New Password</label>
                  <input
                    type="password"
                    {...regPass('newPassword', { required: true, minLength: 6 })}
                    className="input-field text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-700 block mb-1">Confirm New Password</label>
                  <input
                    type="password"
                    {...regPass('confirmPassword', { required: true })}
                    className="input-field text-sm"
                  />
                </div>
                <button
                  type="submit"
                  disabled={changingPass}
                  className="btn-brand text-xs font-bold px-6 py-2.5"
                >
                  {changingPass ? 'Updating...' : 'Update Password'}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
