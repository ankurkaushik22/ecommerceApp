'use client';
import { useState, useMemo } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  AdjustmentsHorizontalIcon, FunnelIcon, XMarkIcon,
  ChevronDownIcon, StarIcon
} from '@heroicons/react/24/outline';
import ProductCard from '@/components/shop/ProductCard';
import { GET_PRODUCTS, GET_CATEGORIES } from '@/graphql/queries';

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortBy, setSortBy] = useState('createdAt');
  const [sortOrder, setSortOrder] = useState('desc');
  const [page, setPage] = useState(1);
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const filterInput = useMemo(() => {
    const filter = {};
    if (selectedCategory) filter.categoryId = selectedCategory;
    if (minPrice !== '') filter.minPrice = parseFloat(minPrice);
    if (maxPrice !== '') filter.maxPrice = parseFloat(maxPrice);
    if (minRating > 0) filter.rating = minRating;
    if (inStockOnly) filter.inStock = true;
    return filter;
  }, [selectedCategory, minPrice, maxPrice, minRating, inStockOnly]);

  const sortInput = useMemo(() => ({
    field: sortBy,
    order: sortOrder,
  }), [sortBy, sortOrder]);

  const { data, loading } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: filterInput,
      sort: sortInput,
      pagination: { page, limit: 12 },
    },
    fetchPolicy: 'cache-and-network',
  });

  const { data: catData } = useQuery(GET_CATEGORIES);
  const categories = catData?.getCategories || [];
  const products = data?.getProducts?.products || [];
  const total = data?.getProducts?.total || 0;
  const totalPages = data?.getProducts?.pages || 1;

  const handleSortChange = (e) => {
    const val = e.target.value;
    if (val === 'price_asc') { setSortBy('price'); setSortOrder('asc'); }
    else if (val === 'price_desc') { setSortBy('price'); setSortOrder('desc'); }
    else if (val === 'rating_desc') { setSortBy('rating'); setSortOrder('desc'); }
    else { setSortBy('createdAt'); setSortOrder('desc'); }
    setPage(1);
  };

  const clearFilters = () => {
    setSelectedCategory('');
    setMinPrice('');
    setMaxPrice('');
    setMinRating(0);
    setInStockOnly(false);
    setPage(1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">All Products</h1>
          <p className="text-sm text-gray-500 mt-1">Showing {products.length} of {total} products</p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowMobileFilters(!showMobileFilters)}
            className="lg:hidden flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 shadow-sm"
          >
            <FunnelIcon className="w-4 h-4 text-brand-600" />
            <span>Filters</span>
          </button>

          <div className="relative">
            <select
              onChange={handleSortChange}
              className="appearance-none bg-white border border-gray-200 rounded-xl px-4 py-2 pr-8 text-sm font-medium text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating_desc">Highest Rated</option>
            </select>
            <ChevronDownIcon className="w-4 h-4 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <aside className={`lg:block ${showMobileFilters ? 'block' : 'hidden'} space-y-6 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm h-fit sticky top-20`}>
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <AdjustmentsHorizontalIcon className="w-5 h-5 text-brand-500" />
              <span>Filters</span>
            </h3>
            <button
              onClick={clearFilters}
              className="text-xs text-brand-600 font-semibold hover:underline"
            >
              Reset All
            </button>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Categories</h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              <button
                onClick={() => { setSelectedCategory(''); setPage(1); }}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${
                  selectedCategory === '' ? 'bg-brand-50 text-brand-600 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                All Categories
              </button>
              {categories.map((cat) => (
                <button
                  key={cat._id}
                  onClick={() => { setSelectedCategory(cat._id); setPage(1); }}
                  className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors flex items-center justify-between ${
                    selectedCategory === cat._id ? 'bg-brand-50 text-brand-600 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className="text-xs text-gray-400">{cat.icon}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Price Range ($)</h4>
            <div className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Min"
                value={minPrice}
                onChange={(e) => { setMinPrice(e.target.value); setPage(1); }}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-brand-500 focus:outline-none"
              />
              <span className="text-gray-400">-</span>
              <input
                type="number"
                placeholder="Max"
                value={maxPrice}
                onChange={(e) => { setMaxPrice(e.target.value); setPage(1); }}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-brand-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Rating */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Minimum Rating</h4>
            <div className="space-y-1">
              {[4, 3, 2, 1].map((stars) => (
                <button
                  key={stars}
                  onClick={() => { setMinRating(minRating === stars ? 0 : stars); setPage(1); }}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                    minRating === stars ? 'bg-amber-50 text-amber-900 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <StarIcon
                        key={i}
                        className={`w-4 h-4 ${i < stars ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                      />
                    ))}
                  </div>
                  <span className="text-xs">& Up</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stock Filter */}
          <div className="pt-2 border-t border-gray-100">
            <label className="flex items-center gap-2.5 cursor-pointer text-sm text-gray-700 font-medium">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => { setInStockOnly(e.target.checked); setPage(1); }}
                className="w-4 h-4 text-brand-600 rounded border-gray-300 focus:ring-brand-500"
              />
              <span>In Stock Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid */}
        <main className="lg:col-span-3 space-y-8">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-gray-100 p-8 space-y-4">
              <p className="text-4xl">🔍</p>
              <h3 className="text-lg font-bold text-gray-900">No products found</h3>
              <p className="text-sm text-gray-500 max-w-sm mx-auto">
                We couldn't find any products matching your selected filters. Try broadening your criteria.
              </p>
              <button onClick={clearFilters} className="btn-brand text-sm">
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 pt-4">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-4 py-2 border border-gray-200 rounded-xl text-sm font-medium bg-white text-gray-700 disabled:opacity-40 hover:bg-gray-50"
              >
                Previous
              </button>
              <span className="text-sm text-gray-600 font-medium px-2">
                Page {page} of {totalPages}
              </span>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-4 py-2 border border-gray-200 rounded-xl text-sm font-medium bg-white text-gray-700 disabled:opacity-40 hover:bg-gray-50"
              >
                Next
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
