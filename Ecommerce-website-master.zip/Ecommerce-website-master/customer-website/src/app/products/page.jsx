'use client';
import { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useQuery } from '@apollo/client';
import { motion } from 'framer-motion';
import {
  AdjustmentsHorizontalIcon, FunnelIcon, XMarkIcon,
  ChevronDownIcon, StarIcon, ArrowPathIcon
} from '@heroicons/react/24/outline';
import ProductCard from '@/components/shop/ProductCard';
import { GET_PRODUCTS, GET_ALL_CATEGORIES } from '@/graphql/queries';

// Shopping category slugs whitelist
const SHOPPING_SLUGS = new Set([
  'electronics', 'clothing', 'home-and-kitchen', 'beauty-and-health',
  'sports-and-outdoors', 'books', 'automotive', 'jewelry',
]);

const PAGE_SIZE = 16;

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [inStockOnly, setInStockOnly] = useState(false);
  const [sortValue, setSortValue] = useState('newest');
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Infinite scroll states
  const [allProductsList, setAllProductsList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasNextPage, setHasNextPage] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  // Intersection observer sentinel ref
  const observerTarget = useRef(null);

  const { sortBy, sortOrder } = useMemo(() => {
    if (sortValue === 'price_asc') return { sortBy: 'price', sortOrder: 'asc' };
    if (sortValue === 'price_desc') return { sortBy: 'price', sortOrder: 'desc' };
    if (sortValue === 'rating_desc') return { sortBy: 'rating', sortOrder: 'desc' };
    return { sortBy: 'createdAt', sortOrder: 'desc' };
  }, [sortValue]);

  const filterInput = useMemo(() => {
    const filter = {};
    if (selectedCategory) filter.categoryId = selectedCategory;
    if (minPrice !== '') filter.minPrice = parseFloat(minPrice);
    if (maxPrice !== '') filter.maxPrice = parseFloat(maxPrice);
    if (minRating > 0) filter.minRating = minRating;
    if (inStockOnly) filter.inStock = true;
    return filter;
  }, [selectedCategory, minPrice, maxPrice, minRating, inStockOnly]);

  const sortInput = useMemo(() => ({
    field: sortBy,
    order: sortOrder,
  }), [sortBy, sortOrder]);

  // Initial page load & refetch when filters change
  const { data, loading, fetchMore } = useQuery(GET_PRODUCTS, {
    variables: {
      filter: filterInput,
      sort: sortInput,
      pagination: { page: 1, limit: PAGE_SIZE },
    },
    fetchPolicy: 'network-only',
    notifyOnNetworkStatusChange: true,
  });

  const { data: catData } = useQuery(GET_ALL_CATEGORIES, {
    fetchPolicy: 'cache-and-network',
  });

  // Shopping categories whitelist for sidebar
  const categories = useMemo(() => {
    const raw = catData?.getAllCategories || [];
    return raw.filter((c) => SHOPPING_SLUGS.has((c.slug || '').toLowerCase()));
  }, [catData]);

  // Sync initial query results to list when filter/sort changes
  useEffect(() => {
    if (data?.getProducts) {
      const fetched = data.getProducts.products || [];
      const hasNext = data.getProducts.hasNext !== undefined 
        ? data.getProducts.hasNext 
        : data.getProducts.page < data.getProducts.pages;

      setAllProductsList(fetched);
      setCurrentPage(1);
      setHasNextPage(hasNext);
    }
  }, [data]);

  // Filter products by shopping slugs
  const products = useMemo(() => {
    return allProductsList.filter((p) => {
      if (selectedCategory) return true; // Explicitly selected
      const catSlug = (p.category?.slug || '').toLowerCase();
      if (catSlug) return SHOPPING_SLUGS.has(catSlug);
      return true;
    });
  }, [allProductsList, selectedCategory]);

  const totalCount = data?.getProducts?.total || products.length;

  // Function to load next page on scroll
  const loadMore = useCallback(async () => {
    if (loading || isLoadingMore || !hasNextPage) return;

    setIsLoadingMore(true);
    const nextPage = currentPage + 1;

    try {
      const res = await fetchMore({
        variables: {
          filter: filterInput,
          sort: sortInput,
          pagination: { page: nextPage, limit: PAGE_SIZE },
        },
      });

      const newProducts = res.data?.getProducts?.products || [];
      const hasMore = res.data?.getProducts?.hasNext !== undefined
        ? res.data?.getProducts?.hasNext
        : (res.data?.getProducts?.page < res.data?.getProducts?.pages);

      if (newProducts.length > 0) {
        setAllProductsList((prev) => {
          const existingIds = new Set(prev.map((p) => p._id));
          const uniqueNew = newProducts.filter((p) => !existingIds.has(p._id));
          return [...prev, ...uniqueNew];
        });
        setCurrentPage(nextPage);
      }
      setHasNextPage(hasMore);
    } catch (err) {
      console.error('Error loading more products:', err);
    } finally {
      setIsLoadingMore(false);
    }
  }, [loading, isLoadingMore, hasNextPage, currentPage, fetchMore, filterInput, sortInput]);

  // IntersectionObserver to trigger loadMore when user reaches bottom
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !loading && !isLoadingMore) {
          loadMore();
        }
      },
      { threshold: 0.1, rootMargin: '200px' }
    );

    const currentTarget = observerTarget.current;
    if (currentTarget) {
      observer.observe(currentTarget);
    }

    return () => {
      if (currentTarget) {
        observer.unobserve(currentTarget);
      }
    };
  }, [loadMore, hasNextPage, loading, isLoadingMore]);

  const handleSortChange = (e) => {
    setSortValue(e.target.value);
  };

  const clearFilters = () => {
    setSelectedCategory('');
    setMinPrice('');
    setMaxPrice('');
    setMinRating(0);
    setInStockOnly(false);
    setSortValue('newest');
  };

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">All Products</h1>
          <p className="text-sm text-gray-500 mt-1">
            {loading && allProductsList.length === 0 ? 'Loading...' : `Showing ${products.length} of ${totalCount} products`}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowMobileFilters(!showMobileFilters)}
            className="lg:hidden flex items-center gap-1.5 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 shadow-sm"
          >
            <FunnelIcon className="w-4 h-4 text-brand-600" />
            <span>Filters</span>
          </button>

          <div className="relative">
            <select
              value={sortValue}
              onChange={handleSortChange}
              className="appearance-none bg-white border border-gray-200 rounded-xl px-4 py-2 pr-8 text-sm font-medium text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating_desc">Highest Rated</option>
            </select>
            <ChevronDownIcon className="w-4 h-4 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Main Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <aside className={`lg:block ${showMobileFilters ? 'block' : 'hidden'} space-y-6 bg-white p-5 rounded-2xl border border-gray-100 shadow-sm h-fit sticky top-20`}>
          <div className="flex items-center justify-between border-b border-gray-100 pb-3">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
              <AdjustmentsHorizontalIcon className="w-5 h-5 text-brand-500" />
              <span>Filters</span>
            </h3>
            <button
              onClick={clearFilters}
              className="text-xs text-brand-600 font-semibold hover:underline"
            >
              Reset All
            </button>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Categories</h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              <button
                onClick={() => setSelectedCategory('')}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${
                  selectedCategory === '' ? 'bg-brand-50 text-brand-600 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                All Categories
              </button>
              {categories.map((cat) => (
                <button
                  key={cat._id}
                  onClick={() => setSelectedCategory(cat._id)}
                  className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors flex items-center justify-between ${
                    selectedCategory === cat._id ? 'bg-brand-50 text-brand-600 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <span>{cat.name}</span>
                  {!cat.icon?.startsWith('http') && (
                    <span className="text-xs text-gray-400">{cat.icon}</span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Price Range (₹)</h4>
            <div className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Min"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-brand-500 focus:outline-none"
              />
              <span className="text-gray-400">-</span>
              <input
                type="number"
                placeholder="Max"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
                className="w-full px-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-brand-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Rating */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3">Minimum Rating</h4>
            <div className="space-y-1">
              {[4, 3, 2, 1].map((stars) => (
                <button
                  key={stars}
                  onClick={() => setMinRating(minRating === stars ? 0 : stars)}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                    minRating === stars ? 'bg-amber-50 text-amber-900 font-semibold' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <StarIcon
                        key={i}
                        className={`w-4 h-4 ${i < stars ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                      />
                    ))}
                  </div>
                  <span className="text-xs">& Up</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stock Filter */}
          <div className="pt-2 border-t border-gray-100">
            <label className="flex items-center gap-2.5 cursor-pointer text-sm text-gray-700 font-medium">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-4 h-4 text-brand-600 rounded border-gray-300 focus:ring-brand-500"
              />
              <span>In Stock Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid */}
        <main className="lg:col-span-3 space-y-8">
          {loading && allProductsList.length === 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card h-80 animate-pulse bg-gray-100 rounded-2xl" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-2xl border border-gray-100 p-8 space-y-4">
              <p className="text-4xl">🔍</p>
              <h3 className="text-lg font-bold text-gray-900">No products found</h3>
              <p className="text-sm text-gray-500 max-w-sm mx-auto">
                We couldn't find any products matching your selected filters. Try broadening your criteria.
              </p>
              <button onClick={clearFilters} className="btn-brand text-sm">
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard key={product._id} product={product} />
              ))}
            </div>
          )}

          {/* Infinite Scroll Sentinel & Loading Indicator */}
          <div ref={observerTarget} className="py-6 flex flex-col items-center justify-center">
            {isLoadingMore && (
              <div className="flex items-center gap-2 text-sm text-gray-500 font-medium py-4">
                <ArrowPathIcon className="w-5 h-5 animate-spin text-brand-600" />
                <span>Loading more products...</span>
              </div>
            )}
            {!hasNextPage && products.length > 0 && (
              <p className="text-xs text-gray-400 font-medium pt-2 pb-6">
                You've reached the end of the products list
              </p>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
