'use client';
import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  StarIcon, HeartIcon, ShieldCheckIcon, TruckIcon,
  ArrowPathIcon, PlusIcon, MinusIcon, CheckBadgeIcon,
  ShoppingCartIcon, BoltIcon, ShareIcon
} from '@heroicons/react/24/solid';
import { HeartIcon as HeartOutline } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_PRODUCT, GET_RELATED_PRODUCTS, GET_PRODUCT_REVIEWS, GET_ME, GET_CART } from '@/graphql/queries';
import { ADD_TO_CART, TOGGLE_WISHLIST, ADD_REVIEW } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import ProductCard from '@/components/shop/ProductCard';

export default function ProductDetailPage() {
  const params = useParams();
  const router = useRouter();
  const slug = params?.slug;

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description'); // description | specs | reviews

  // Review Form state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');

  const { user, isAuthenticated } = useAuthStore();
  const addItemLocal = useCartStore((s) => s.addItem);

  const { data, loading, error } = useQuery(GET_PRODUCT, {
    variables: { slug },
    skip: !slug,
  });

  const product = data?.getProduct;

  const { data: relatedData } = useQuery(GET_RELATED_PRODUCTS, {
    variables: { productId: product?._id, limit: 4 },
    skip: !product?._id,
  });

  const { data: reviewsData, refetch: refetchReviews } = useQuery(GET_PRODUCT_REVIEWS, {
    variables: { productId: product?._id, pagination: { page: 1, limit: 10 } },
    skip: !product?._id,
  });

  const [addToCartMutation, { loading: addingCart }] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      toast.success('Added to cart!');
    },
    onError: (e) => toast.error(e.message),
  });

  const [toggleWishlist] = useMutation(TOGGLE_WISHLIST, {
    refetchQueries: [{ query: GET_ME }],
    onError: (e) => toast.error(e.message),
  });

  const [addReviewMutation, { loading: submittingReview }] = useMutation(ADD_REVIEW, {
    onCompleted: () => {
      toast.success('Review submitted successfully!');
      setReviewTitle('');
      setReviewComment('');
      refetchReviews();
    },
    onError: (e) => toast.error(e.message),
  });

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="h-[450px] bg-gray-100 rounded-3xl animate-pulse" />
          <div className="space-y-4">
            <div className="h-8 bg-gray-100 rounded w-3/4 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-1/3 animate-pulse" />
            <div className="h-10 bg-gray-100 rounded w-1/4 animate-pulse" />
            <div className="h-32 bg-gray-100 rounded animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-4xl">📦</p>
        <h2 className="text-2xl font-bold text-gray-900">Product Not Found</h2>
        <p className="text-gray-500">The product you are looking for might have been removed or renamed.</p>
        <Link href="/products" className="btn-brand inline-block text-sm">
          Browse Products
        </Link>
      </div>
    );
  }

  const isWishlisted = user?.wishlist?.some((w) => w._id === product._id);
  const reviews = reviewsData?.getProductReviews || [];
  const relatedProducts = relatedData?.getRelatedProducts || [];

  const handleAddToCart = (directCheckout = false) => {
    if (isAuthenticated) {
      addToCartMutation({
        variables: {
          input: {
            productId: product._id,
            quantity,
            variantIndex: product.variants?.length > 0 ? selectedVariant : -1,
          },
        },
      }).then(() => {
        if (directCheckout) router.push('/checkout');
      });
    } else {
      addItemLocal(product, quantity, product.variants?.length > 0 ? selectedVariant : -1);
      toast.success('Added to cart!');
      if (directCheckout) router.push('/checkout');
    }
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      toast.error('Please login to leave a review');
      return;
    }
    addReviewMutation({
      variables: {
        input: {
          productId: product._id,
          rating: reviewRating,
          title: reviewTitle,
          comment: reviewComment,
        },
      },
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs sm:text-sm text-gray-500">
        <Link href="/" className="hover:text-brand-600">Home</Link>
        <span>/</span>
        {product.category && (
          <>
            <Link href={`/category/${product.category.slug}`} className="hover:text-brand-600">
              {product.category.name}
            </Link>
            <span>/</span>
          </>
        )}
        <span className="text-gray-900 font-medium truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Product Info Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Gallery (5 cols) */}
        <div className="lg:col-span-6 space-y-4">
          <div className="relative pt-[90%] w-full rounded-3xl overflow-hidden bg-white border border-gray-100 shadow-sm">
            <img
              src={product.images?.[selectedImage] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'}
              alt={product.name}
              className="absolute inset-0 w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80';
              }}
            />
          </div>

          {/* Thumbnails */}
          {product.images?.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(i)}
                  className={`relative w-20 h-20 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all ${
                    selectedImage === i ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <img
                    src={img}
                    alt=""
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&auto=format&fit=crop&q=80';
                    }}
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Product Details (7 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            {product.category && (
              <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-2.5 py-1 rounded-full">
                {product.category.name}
              </span>
            )}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-2.5 leading-tight">
              {product.name}
            </h1>

            {/* Rating & Stock */}
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.round(product.rating?.average || 0)
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-gray-200 fill-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-bold text-gray-800">
                  {product.rating?.average ? product.rating.average.toFixed(1) : 'New'}
                </span>
                <span className="text-xs text-gray-400">({product.reviewsCount || 0} reviews)</span>
              </div>

              <div className="h-4 w-px bg-gray-200" />

              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                product.stock > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
              }`}>
                {product.stock > 0 ? `In Stock (${product.stock} left)` : 'Out of Stock'}
              </span>
            </div>
          </div>

          {/* Pricing */}
          <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-gray-900">${product.price?.toFixed(2)}</span>
            {product.comparePrice && product.comparePrice > product.price && (
              <>
                <span className="text-lg text-gray-400 line-through">${product.comparePrice?.toFixed(2)}</span>
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  -{product.discount || Math.round((1 - product.price / product.comparePrice) * 100)}% OFF
                </span>
              </>
            )}
          </div>

          <p className="text-sm text-gray-600 leading-relaxed">
            {product.shortDescription || product.description?.substring(0, 180) + '...'}
          </p>

          {/* Variants */}
          {product.variants?.length > 0 && (
            <div className="space-y-3">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-700 block">
                Select Option:
              </label>
              <div className="flex flex-wrap gap-2.5">
                {product.variants[0]?.options?.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedVariant(i)}
                    className={`px-4 py-2 rounded-xl text-sm font-semibold border transition-all ${
                      selectedVariant === i
                        ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700'
                    }`}
                  >
                    {opt.label} {opt.price && `(+$${opt.price})`}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity & Action Buttons */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-4">
              {/* Quantity */}
              <div className="flex items-center border border-gray-200 rounded-xl bg-white p-1 shadow-sm">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <MinusIcon className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-bold text-gray-900 text-sm">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => Math.min(product.stock || 10, q + 1))}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <PlusIcon className="w-4 h-4" />
                </button>
              </div>

              {/* Wishlist Button */}
              <button
                onClick={() => {
                  if (!isAuthenticated) { toast.error('Please login first'); return; }
                  toggleWishlist({ variables: { productId: product._id } });
                }}
                className="p-3 border border-gray-200 rounded-xl text-gray-400 hover:text-red-500 hover:border-red-200 bg-white shadow-sm transition-colors"
                title="Wishlist"
              >
                {isWishlisted ? <HeartIcon className="w-5 h-5 text-red-500" /> : <HeartOutline className="w-5 h-5" />}
              </button>
            </div>

            {/* Cart / Buy Now */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button
                onClick={() => handleAddToCart(false)}
                disabled={addingCart || product.stock <= 0}
                className="btn-outline flex items-center justify-center gap-2 py-3.5"
              >
                <ShoppingCartIcon className="w-5 h-5" />
                <span>Add to Cart</span>
              </button>

              <button
                onClick={() => handleAddToCart(true)}
                disabled={product.stock <= 0}
                className="btn-brand flex items-center justify-center gap-2 py-3.5 shadow-lg shadow-brand-500/25"
              >
                <BoltIcon className="w-5 h-5" />
                <span>Buy Now</span>
              </button>
            </div>
          </div>

          {/* Delivery & Assurance */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-gray-100 text-xs text-gray-600">
            <div className="flex items-center gap-2">
              <TruckIcon className="w-5 h-5 text-brand-600 flex-shrink-0" />
              <span>{product.freeShipping ? 'Free Standard Shipping' : 'Fast Delivery Guaranteed'}</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheckIcon className="w-5 h-5 text-brand-600 flex-shrink-0" />
              <span>Authentic Guarantee</span>
            </div>
            <div className="flex items-center gap-2">
              <ArrowPathIcon className="w-5 h-5 text-brand-600 flex-shrink-0" />
              <span>30-Day Easy Returns</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Description, Specs, Reviews */}
      <div className="space-y-6 pt-6">
        <div className="border-b border-gray-200 flex gap-8">
          {['description', 'specifications', 'reviews'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-4 text-sm font-bold uppercase tracking-wider border-b-2 transition-all ${
                activeTab === tab
                  ? 'border-brand-500 text-brand-600'
                  : 'border-transparent text-gray-400 hover:text-gray-700'
              }`}
            >
              {tab === 'reviews' ? `Reviews (${product.reviewsCount || 0})` : tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="py-2">
          {activeTab === 'description' && (
            <div className="prose max-w-none text-gray-700 leading-relaxed space-y-4">
              <p>{product.description}</p>
            </div>
          )}

          {activeTab === 'specifications' && (
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {product.specifications?.map((spec, i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-5 py-3 font-semibold text-gray-700 w-1/3">{spec.key}</td>
                      <td className="px-5 py-3 text-gray-600">{spec.value}</td>
                    </tr>
                  ))}
                  {(!product.specifications || product.specifications.length === 0) && (
                    <tr>
                      <td className="px-5 py-4 text-gray-400 italic">No specifications listed.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Rating Summary (4 cols) */}
              <div className="lg:col-span-4 space-y-4 bg-gray-50 p-6 rounded-2xl border border-gray-100 h-fit">
                <h3 className="font-bold text-gray-900 text-lg">Customer Ratings</h3>
                <div className="flex items-center gap-3">
                  <span className="text-4xl font-extrabold text-gray-900">
                    {product.rating?.average ? product.rating.average.toFixed(1) : '0.0'}
                  </span>
                  <div>
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <StarIcon
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.round(product.rating?.average || 0) ? 'text-amber-400 fill-amber-400' : 'text-gray-200'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500">{product.reviewsCount || 0} total ratings</span>
                  </div>
                </div>

                {/* Rating Distribution */}
                <div className="space-y-2 pt-2">
                  {product.rating?.distribution?.map((dist) => (
                    <div key={dist.star} className="flex items-center gap-2 text-xs text-gray-600">
                      <span className="w-10">{dist.star} stars</span>
                      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-400 rounded-full"
                          style={{ width: `${dist.percentage}%` }}
                        />
                      </div>
                      <span className="w-8 text-right font-medium">{dist.percentage}%</span>
                    </div>
                  ))}
                </div>

                {/* Add Review Form */}
                <div className="pt-4 border-t border-gray-200">
                  <h4 className="font-bold text-sm text-gray-900 mb-2">Write a Review</h4>
                  <form onSubmit={handleReviewSubmit} className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">Rating</label>
                      <div className="flex gap-1 text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <button
                            type="button"
                            key={s}
                            onClick={() => setReviewRating(s)}
                            className="p-0.5 focus:outline-none"
                          >
                            <StarIcon className={`w-5 h-5 ${s <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="text"
                      placeholder="Headline (e.g. Great quality!)"
                      value={reviewTitle}
                      onChange={(e) => setReviewTitle(e.target.value)}
                      required
                      className="input-field text-xs py-2"
                    />
                    <textarea
                      placeholder="Write your review here..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      required
                      rows={3}
                      className="input-field text-xs py-2 resize-none"
                    />
                    <button
                      type="submit"
                      disabled={submittingReview}
                      className="w-full btn-brand text-xs font-bold py-2"
                    >
                      {submittingReview ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </form>
                </div>
              </div>

              {/* Review list (8 cols) */}
              <div className="lg:col-span-8 space-y-4">
                {reviews.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                    <p className="text-gray-500">No reviews yet for this product. Be the first to review!</p>
                  </div>
                ) : (
                  reviews.map((rev) => (
                    <div key={rev._id} className="p-5 rounded-2xl bg-white border border-gray-100 shadow-sm space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={rev.user?.avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(rev.user?.name || 'User')}
                            alt=""
                            className="w-8 h-8 rounded-full border border-gray-200"
                          />
                          <div>
                            <p className="text-xs font-bold text-gray-900">{rev.user?.name}</p>
                            {rev.verified && (
                              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-0.5">
                                <CheckBadgeIcon className="w-3.5 h-3.5" /> Verified Purchase
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex text-amber-400">
                          {[...Array(5)].map((_, i) => (
                            <StarIcon
                              key={i}
                              className={`w-3.5 h-3.5 ${i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                      <h4 className="text-sm font-bold text-gray-900">{rev.title}</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">{rev.comment}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Customers also bought</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5">
            {relatedProducts.map((rel) => (
              <ProductCard key={rel._id} product={rel} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
