'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useQuery, useMutation } from '@apollo/client';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  StarIcon, HeartIcon, ShieldCheckIcon, TruckIcon,
  ArrowPathIcon, PlusIcon, MinusIcon, CheckBadgeIcon,
  ShoppingCartIcon, BoltIcon, ShareIcon
} from '@heroicons/react/24/solid';
import { HeartIcon as HeartOutline, ArrowLeftIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { GET_PRODUCT, GET_RELATED_PRODUCTS, GET_PRODUCT_REVIEWS, GET_ME, GET_CART } from '@/graphql/queries';
import { ADD_TO_CART, TOGGLE_WISHLIST, ADD_REVIEW } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import ProductCard from '@/components/shop/ProductCard';

export default function ProductDetailPage() {
  const params = useParams();
  const router = useRouter();
  const slug = params?.slug;

  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSizeIdx, setSelectedSizeIdx] = useState(0);
  const [selectedColorIdx, setSelectedColorIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description'); // description | specs | reviews

  // Reset main image selection to index 0 whenever selected size or color variant changes
  useEffect(() => {
    setSelectedImage(0);
  }, [selectedSizeIdx, selectedColorIdx]);

  // Review Form state
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');

  const { user, isAuthenticated } = useAuthStore();
  const addItemLocal = useCartStore((s) => s.addItem);

  const { data, loading, error } = useQuery(GET_PRODUCT, {
    variables: { slug },
    skip: !slug,
  });

  const product = data?.getProduct;

  const { data: relatedData } = useQuery(GET_RELATED_PRODUCTS, {
    variables: { productId: product?._id, limit: 4 },
    skip: !product?._id,
  });

  const relatedProducts = relatedData?.getRelatedProducts || [];

  const { data: reviewsData, refetch: refetchReviews } = useQuery(GET_PRODUCT_REVIEWS, {
    variables: { productId: product?._id, pagination: { page: 1, limit: 10 } },
    skip: !product?._id,
  });

  const reviews = reviewsData?.getProductReviews || product?.reviews || [];

  const [addToCartMutation, { loading: addingCart }] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      toast.success('Added to cart!');
    },
    onError: (e) => toast.error(e.message),
  });

  const [toggleWishlist] = useMutation(TOGGLE_WISHLIST, {
    refetchQueries: [{ query: GET_ME }],
    onError: (e) => toast.error(e.message),
  });

  const [addReviewMutation, { loading: submittingReview }] = useMutation(ADD_REVIEW, {
    onCompleted: () => {
      toast.success('Review submitted successfully!');
      setReviewTitle('');
      setReviewComment('');
      refetchReviews();
    },
    onError: (e) => toast.error(e.message),
  });

  if (loading) {
    return (
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="h-[450px] bg-gray-100 rounded-3xl animate-pulse" />
          <div className="space-y-4">
            <div className="h-8 bg-gray-100 rounded w-3/4 animate-pulse" />
            <div className="h-4 bg-gray-100 rounded w-1/3 animate-pulse" />
            <div className="h-10 bg-gray-100 rounded w-1/4 animate-pulse" />
            <div className="h-32 bg-gray-100 rounded animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="w-full mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-4xl">📦</p>
        <h2 className="text-2xl font-bold text-gray-900">Product Not Found</h2>
        <p className="text-gray-500">The product you are looking for might have been removed or renamed.</p>
        <Link href="/products" className="btn-brand inline-block text-sm">
          Browse Products
        </Link>
      </div>
    );
  }

  const isWishlisted = user?.wishlist?.some((w) => w._id === product._id);
  const activeVariantOption = product?.variants?.[selectedSizeIdx]?.options?.[selectedColorIdx];
  const displayPrice = activeVariantOption?.price || product?.price;

  const handleAddToCart = (directCheckout = false) => {
    if (!isAuthenticated) {
      router.push(`/login?redirect=/products/${slug}`);
      return;
    }

    let flatVariantIdx = -1;
    if (product.variants?.length > 0) {
      flatVariantIdx = 0;
      for (let i = 0; i < selectedSizeIdx && i < product.variants.length; i++) {
        flatVariantIdx += product.variants[i]?.options?.length || 0;
      }
      flatVariantIdx += selectedColorIdx;
    }

    addToCartMutation({
      variables: {
        input: {
          productId: product._id,
          quantity,
          variantIndex: flatVariantIdx,
        },
      },
    }).then(() => {
      if (directCheckout) router.push('/checkout');
    });
  };

  const handleReviewSubmit = (e) => {
    e.preventDefault();
    if (!isAuthenticated) {
      router.push(`/login?redirect=/products/${slug}`);
      return;
    }
    addReviewMutation({
      variables: {
        input: {
          productId: product._id,
          rating: reviewRating,
          title: reviewTitle,
          comment: reviewComment,
        },
      },
    });
  };

  return (
    <div className="w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Top Bar: Breadcrumb + Back Button */}
      <div className="flex items-center justify-between gap-4 text-xs sm:text-sm text-gray-500">
        <nav className="flex items-center gap-2 overflow-hidden">
          <Link href="/" className="hover:text-brand-600">Home</Link>
          <span>/</span>
          {product.category && (
            <>
              <Link href={`/category/${product.category.slug}`} className="hover:text-brand-600">
                {product.category.name}
              </Link>
              <span>/</span>
            </>
          )}
          <span className="text-gray-900 font-medium truncate max-w-xs">{product.name}</span>
        </nav>
        <button
          onClick={() => router.back()}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-200 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50 hover:text-brand-600 transition-colors shadow-2xs flex-shrink-0 cursor-pointer"
        >
          <ArrowLeftIcon className="w-4 h-4" />
          <span>Back</span>
        </button>
      </div>

      {/* Main Product Info Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Left: Gallery (6 cols) */}
        {(() => {
          const rawThumbs = activeVariantOption?.thumbnails?.length
            ? activeVariantOption.thumbnails
            : (activeVariantOption?.thumbnail ? [activeVariantOption.thumbnail] : []);
          const variantThumbs = rawThumbs.filter(Boolean);

          const baseImages = product.images?.length
            ? product.images
            : ['https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'];

          // If active variant option has its own thumbnail(s), show ONLY the variant's thumbnails so default/other variant images (like Black) don't bleed into this variant's gallery!
          const galleryImages = variantThumbs.length > 0 ? variantThumbs : baseImages;
          const currentImg = galleryImages[selectedImage] || galleryImages[0];

          return (
            <div className="lg:col-span-6 flex flex-col-reverse sm:flex-row gap-4 items-start">
              {/* Vertical Thumbnails on Left (Starts at top) */}
              {galleryImages.length > 1 && (
                <div className="flex sm:flex-col gap-2.5 overflow-x-auto sm:overflow-y-auto sm:max-h-[520px] flex-shrink-0 w-full sm:w-auto pb-2 sm:pb-0">
                  {galleryImages.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setSelectedImage(i)}
                      className={`relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 flex-shrink-0 transition-all ${
                        selectedImage === i ? 'border-brand-500 ring-2 ring-brand-500/20' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <img
                        src={img}
                        alt=""
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&auto=format&fit=crop&q=80';
                        }}
                      />
                    </button>
                  ))}
                </div>
              )}

              {/* Main Product Image */}
              <div className="relative flex-1 w-full min-w-0 pt-[100%] sm:pt-[95%] rounded-3xl overflow-hidden bg-white border border-gray-100 shadow-sm">
                <img
                  src={currentImg}
                  alt={product.name}
                  className="absolute inset-0 w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80';
                  }}
                />
              </div>
            </div>
          );
        })()}

        {/* Right: Product Details (7 cols) */}
        <div className="lg:col-span-6 space-y-6">
          {/* Seller / Brand Store Row (Amazon Style) */}
          <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl">
            <Link
              href={
                product.vendor?._id
                  ? `/store/${product.vendor._id}?name=${encodeURIComponent(product.vendor.name || '')}`
                  : product.vendor?.name
                  ? `/store/${encodeURIComponent(product.vendor.name)}?name=${encodeURIComponent(product.vendor.name)}`
                  : `/store/official-brand-store?name=${encodeURIComponent(product.category?.name ? product.category.name + ' Official Store' : 'Official Brand Store')}${product.category?.slug ? `&category=${encodeURIComponent(product.category.slug)}` : ''}`
              }
              className="flex items-center gap-3 group"
            >
              <div className="w-11 h-11 rounded-xl bg-white border border-slate-200 overflow-hidden flex items-center justify-center shadow-xs flex-shrink-0">
                {product.vendor?.avatar ? (
                  <img
                    src={product.vendor.avatar}
                    alt={product.vendor?.name || 'Seller Logo'}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                ) : (
                  <span className="text-xl">🏬</span>
                )}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-sm font-extrabold text-slate-900 group-hover:text-brand-600 transition-colors">
                    {product.vendor?.name || 'Official Brand Store'}
                  </h4>
                  <span className="text-[10px] bg-blue-100 text-blue-700 font-bold px-1.5 py-0.5 rounded-full">
                    Verified
                  </span>
                </div>
                <span className="text-xs font-bold text-sky-600 group-hover:underline flex items-center gap-0.5 mt-0.5">
                  Visit the store &rarr;
                </span>
              </div>
            </Link>

            <div className="text-right">
              <div className="flex items-center gap-1 justify-end">
                <span className="text-xs font-bold text-slate-900">
                  {Number(product.rating?.average || 4.5).toFixed(1)}
                </span>
                <div className="flex text-amber-400 text-xs">
                  {'★'.repeat(Math.round(product.rating?.average || 4))}
                </div>
              </div>
              <span className="text-[11px] text-slate-400">
                ({product.rating?.count || product.reviewsCount || 14} ratings)
              </span>
            </div>
          </div>

          <div>
            {product.category && (
              <span className="text-xs font-bold uppercase tracking-wider text-brand-600 bg-brand-50 px-2.5 py-1 rounded-full">
                {product.category.name}
              </span>
            )}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mt-2.5 leading-tight">
              {product.name}
            </h1>

            {/* Rating & Stock */}
            <div className="flex items-center gap-4 mt-3">
              <div className="flex items-center gap-1.5">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.round(product.rating?.average || 0)
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-gray-200 fill-gray-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-bold text-gray-800">
                  {product.rating?.average ? product.rating.average.toFixed(1) : 'New'}
                </span>
                <span className="text-xs text-gray-400">({product.reviewsCount || 0} reviews)</span>
              </div>

              <div className="h-4 w-px bg-gray-200" />

              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                product.stock > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
              }`}>
                {product.stock > 0 ? `In Stock (${product.stock} left)` : 'Out of Stock'}
              </span>
            </div>
          </div>

          {/* Pricing */}
          <div className="p-4 rounded-2xl bg-gray-50 border border-gray-100 flex items-baseline gap-3">
            <span className="text-3xl font-extrabold text-gray-900">₹{displayPrice?.toLocaleString('en-IN')}</span>
            {product.unitMeasure && (
              <span className="text-sm font-semibold text-gray-500">{product.unitMeasure.startsWith('for') ? product.unitMeasure : `/ ${product.unitMeasure}`}</span>
            )}
            {product.comparePrice && product.comparePrice > displayPrice && (
              <>
                <span className="text-lg text-gray-400 line-through">₹{product.comparePrice?.toLocaleString('en-IN')}</span>
                <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                  -{product.discount || Math.round((1 - displayPrice / product.comparePrice) * 100)}% OFF
                </span>
              </>
            )}
          </div>

          <p className="text-sm text-gray-600 leading-relaxed">
            {product.shortDescription || product.description?.substring(0, 180) + '...'}
          </p>

          {/* Nutritional Highlights */}
          {product.nutritionalHighlights && product.nutritionalHighlights.length > 0 && (
            <div className="space-y-2 pt-1">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-gray-500">Nutritional Highlights</h4>
              <div className="flex flex-wrap gap-2">
                {product.nutritionalHighlights.map((tag, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200/80"
                  >
                    <span>{idx % 2 === 0 ? '💚' : '🌾'}</span>
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Size & Color Multi-Dimensional Variants */}
          {product.variants?.length > 0 && (
            <div className="space-y-4 pt-2 border-t border-gray-100">
              {/* If multiple sizes/groups exist */}
              {product.variants.length > 1 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-700">
                      1. Select Size / Age:
                    </label>
                    <span className="text-xs font-bold text-brand-600">
                      {product.variants[selectedSizeIdx]?.name}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((variantGroup, sIdx) => {
                      const isSelected = selectedSizeIdx === sIdx;
                      return (
                        <button
                          key={sIdx}
                          onClick={() => {
                            setSelectedSizeIdx(sIdx);
                            setSelectedColorIdx(0);
                            setSelectedImage(0);
                          }}
                          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all ${
                            isSelected
                              ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-sm ring-1 ring-brand-500'
                              : 'border-gray-200 hover:border-gray-300 text-gray-700 bg-white'
                          }`}
                        >
                          {variantGroup.name}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {/* Color Options under selected Size */}
              {product.variants[selectedSizeIdx]?.options?.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-700">
                      {product.variants.length > 1 ? '2. Select Color:' : 'Select Option / Color:'}
                    </label>
                    <span className="text-xs font-bold text-slate-800">
                      {product.variants[selectedSizeIdx]?.options[selectedColorIdx]?.label}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    {product.variants[selectedSizeIdx].options.map((opt, cIdx) => {
                      const isSelected = selectedColorIdx === cIdx;
                      return (
                        <button
                          key={cIdx}
                          onClick={() => {
                            setSelectedColorIdx(cIdx);
                            setSelectedImage(0);
                          }}
                          className={`px-4 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-2 ${
                            isSelected
                              ? 'border-brand-500 bg-brand-50 text-brand-700 shadow-sm ring-1 ring-brand-500'
                              : 'border-gray-200 hover:border-gray-300 text-gray-700 bg-white'
                          }`}
                        >
                          {opt.thumbnail ? (
                            <img src={opt.thumbnail} alt={opt.label} className="w-5 h-5 rounded-full object-cover border border-white shadow-2xs" />
                          ) : (
                            <span className="w-3 h-3 rounded-full bg-slate-800 border border-white shadow-2xs" />
                          )}
                          <span>{opt.label}</span>
                          {opt.price > 0 && opt.price !== product.price && (
                            <span className="text-[10px] font-mono text-gray-500">(₹{opt.price})</span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quantity & Action Buttons */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center gap-4">
              {/* Quantity */}
              <div className="flex items-center border border-gray-200 rounded-xl bg-white p-1 shadow-sm">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <MinusIcon className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-bold text-gray-900 text-sm">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => Math.min(product.stock || 10, q + 1))}
                  className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                >
                  <PlusIcon className="w-4 h-4" />
                </button>
              </div>

              {/* Wishlist Button */}
              <button
                onClick={() => {
                  if (!isAuthenticated) {
                    router.push(`/login?redirect=/products/${slug}`);
                    return;
                  }
                  toggleWishlist({ variables: { productId: product._id } });
                }}
                className="p-3 border border-gray-200 rounded-xl text-gray-400 hover:text-red-500 hover:border-red-200 bg-white shadow-sm transition-colors"
                title="Wishlist"
              >
                {isWishlisted ? <HeartIcon className="w-5 h-5 text-red-500" /> : <HeartOutline className="w-5 h-5" />}
              </button>
            </div>

            {/* Cart / Buy Now */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button
                onClick={() => handleAddToCart(false)}
                disabled={addingCart || product.stock <= 0}
                className="btn-outline flex items-center justify-center gap-2 py-3.5"
              >
                <ShoppingCartIcon className="w-5 h-5" />
                <span>Add to Cart</span>
              </button>

              <button
                onClick={() => handleAddToCart(true)}
                disabled={product.stock <= 0}
                className="btn-brand flex items-center justify-center gap-2 py-3.5 shadow-lg shadow-brand-500/25"
              >
                <BoltIcon className="w-5 h-5" />
                <span>Buy Now</span>
              </button>
            </div>
          </div>

          {/* Delivery & Assurance / Highlights */}
          {(() => {
            const displayHighlights = product.highlights?.length > 0
              ? product.highlights
              : [
                  product.freeShipping ? 'Free Standard Shipping' : 'Fast Delivery Guaranteed',
                  'Authentic Guarantee',
                  '30-Day Easy Returns',
                ];
            const getHighlightIcon = (text = '') => {
              const lower = text.toLowerCase();
              if (lower.includes('deliver') || lower.includes('ship') || lower.includes('fast')) return TruckIcon;
              if (lower.includes('return') || lower.includes('replace') || lower.includes('exchange')) return ArrowPathIcon;
              if (lower.includes('guarantee') || lower.includes('authentic') || lower.includes('warranty') || lower.includes('secure')) return ShieldCheckIcon;
              return CheckBadgeIcon;
            };
            return (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-gray-100 text-xs text-gray-600">
                {displayHighlights.map((item, idx) => {
                  const IconComp = getHighlightIcon(item);
                  return (
                    <div key={idx} className="flex items-center gap-2">
                      <IconComp className="w-5 h-5 text-brand-600 flex-shrink-0" />
                      <span>{item}</span>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      </div>

      {/* Tabs: Description, Specs, Reviews */}
      <div className="space-y-6 pt-6">
        <div className="border-b border-gray-200 flex gap-8">
          {['description', 'specifications', 'reviews'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-4 text-sm font-bold uppercase tracking-wider border-b-2 transition-all ${
                activeTab === tab
                  ? 'border-brand-500 text-brand-600'
                  : 'border-transparent text-gray-400 hover:text-gray-700'
              }`}
            >
              {tab === 'reviews' ? `Reviews (${product.reviewsCount || 0})` : tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="py-2">
          {activeTab === 'description' && (
            <div className="prose max-w-none text-gray-800 leading-relaxed text-sm space-y-4">
              {product.description?.includes('<') ? (
                <div dangerouslySetInnerHTML={{ __html: product.description }} />
              ) : (
                <p className="whitespace-pre-line">{product.description}</p>
              )}
            </div>
          )}

          {activeTab === 'specifications' && (
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <tbody>
                  {product.specifications?.map((spec, i) => (
                    <tr key={i} className={i % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                      <td className="px-5 py-3 font-semibold text-gray-700 w-1/3">{spec.key}</td>
                      <td className="px-5 py-3 text-gray-600">{spec.value}</td>
                    </tr>
                  ))}
                  {(!product.specifications || product.specifications.length === 0) && (
                    <tr>
                      <td className="px-5 py-4 text-gray-400 italic">No specifications listed.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Rating Summary (4 cols) */}
              <div className="lg:col-span-4 space-y-4 bg-gray-50 p-6 rounded-2xl border border-gray-100 h-fit">
                <h3 className="font-bold text-gray-900 text-lg">Customer Ratings</h3>
                <div className="flex items-center gap-3">
                  <span className="text-4xl font-extrabold text-gray-900">
                    {product.rating?.average ? product.rating.average.toFixed(1) : '0.0'}
                  </span>
                  <div>
                    <div className="flex text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <StarIcon
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.round(product.rating?.average || 0) ? 'text-amber-400 fill-amber-400' : 'text-gray-200'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500">{product.reviewsCount || 0} total ratings</span>
                  </div>
                </div>

                {/* Rating Distribution */}
                <div className="space-y-2 pt-2">
                  {product.rating?.distribution?.map((dist) => (
                    <div key={dist.star} className="flex items-center gap-2 text-xs text-gray-600">
                      <span className="w-10">{dist.star} stars</span>
                      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-400 rounded-full"
                          style={{ width: `${dist.percentage}%` }}
                        />
                      </div>
                      <span className="w-8 text-right font-medium">{dist.percentage}%</span>
                    </div>
                  ))}
                </div>

                {/* Add Review Form */}
                <div className="pt-4 border-t border-gray-200">
                  <h4 className="font-bold text-sm text-gray-900 mb-2">Write a Review</h4>
                  <form onSubmit={handleReviewSubmit} className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 block mb-1">Rating</label>
                      <div className="flex gap-1 text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <button
                            type="button"
                            key={s}
                            onClick={() => setReviewRating(s)}
                            className="p-0.5 focus:outline-none"
                          >
                            <StarIcon className={`w-5 h-5 ${s <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="text"
                      placeholder="Headline (e.g. Great quality!)"
                      value={reviewTitle}
                      onChange={(e) => setReviewTitle(e.target.value)}
                      required
                      className="input-field text-xs py-2"
                    />
                    <textarea
                      placeholder="Write your review here..."
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      required
                      rows={3}
                      className="input-field text-xs py-2 resize-none"
                    />
                    <button
                      type="submit"
                      disabled={submittingReview}
                      className="w-full btn-brand text-xs font-bold py-2"
                    >
                      {submittingReview ? 'Submitting...' : 'Submit Review'}
                    </button>
                  </form>
                </div>
              </div>

              {/* Review list (8 cols) */}
              <div className="lg:col-span-8 space-y-4">
                {reviews.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-2xl border border-gray-100">
                    <p className="text-gray-500">No reviews yet for this product. Be the first to review!</p>
                  </div>
                ) : (
                  reviews.map((rev) => (
                    <div key={rev._id} className="p-5 rounded-2xl bg-white border border-gray-100 shadow-sm space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <img
                            src={rev.user?.avatar || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(rev.user?.name || 'User')}
                            alt=""
                            className="w-8 h-8 rounded-full border border-gray-200"
                          />
                          <div>
                            <p className="text-xs font-bold text-gray-900">{rev.user?.name}</p>
                            {rev.verified && (
                              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-0.5">
                                <CheckBadgeIcon className="w-3.5 h-3.5" /> Verified Purchase
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex text-amber-400">
                          {[...Array(5)].map((_, i) => (
                            <StarIcon
                              key={i}
                              className={`w-3.5 h-3.5 ${i < rev.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                      <h4 className="text-sm font-bold text-gray-900">{rev.title}</h4>
                      <p className="text-xs text-gray-600 leading-relaxed">{rev.comment}</p>

                      {/* Seller / Store Reply */}
                      {rev.reply && (
                        <div className="mt-3 p-3 bg-brand-50/70 border border-brand-200/80 rounded-xl space-y-1 text-xs">
                          <p className="font-bold text-brand-900 flex items-center gap-1.5">
                            <span>💬 Response from {rev.reply.repliedBy?.name || 'Seller'}</span>
                            <span className="text-[10px] text-brand-500 font-normal">
                              ({new Date(rev.reply.repliedAt).toLocaleDateString()})
                            </span>
                          </p>
                          <p className="text-gray-700 leading-relaxed">{rev.reply.comment}</p>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="space-y-4 pt-6 border-t border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Customers also bought</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-5">
            {relatedProducts.map((rel) => (
              <ProductCard key={rel._id} product={rel} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
