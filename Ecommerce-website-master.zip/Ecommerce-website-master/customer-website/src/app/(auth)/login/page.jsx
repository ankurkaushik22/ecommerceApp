'use client';
import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, LockClosedIcon, EnvelopeIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { LOGIN } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500" />
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectUrl = searchParams.get('redirect') || '/';
  const [errorMessage, setErrorMessage] = useState('');

  const loginStore = useAuthStore((s) => s.login);

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    defaultValues: { email: '', password: '' },
  });

  const [loginMutation, { loading }] = useMutation(LOGIN, {
    onCompleted: (data) => {
      const { user, token, refreshToken } = data.login;
      loginStore(user, token, refreshToken);
      toast.success(`Welcome back, ${user.name}!`);
      router.push(redirectUrl);
    },
    onError: (err) => {
      const msg =
        err.message?.includes('credentials') ||
        err.message?.includes('password') ||
        err.message?.includes('found') ||
        err.message?.includes('User')
          ? 'Invalid username or password. Please try again.'
          : err.message || 'Invalid username or password';
      setErrorMessage(msg);
      toast.error(msg);
    },
  });

  const onSubmit = (formData, e) => {
    e?.preventDefault?.();
    setErrorMessage('');
    loginMutation({
      variables: {
        input: {
          email: formData.email,
          password: formData.password,
        },
      },
    });
  };

  const fillDemo = (email, pass) => {
    setErrorMessage('');
    setValue('email', email);
    setValue('password', pass);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
              <BuildingStorefrontIcon className="w-5 h-5" />
            </div>
            <span>ShopZone</span>
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">Sign in to your account</h2>
          <p className="text-xs text-gray-500">Access your orders, wishlist, and recommendations</p>
        </div>

        {/* Demo Accounts Pill */}
        <div className="bg-brand-50/70 border border-brand-200/70 rounded-2xl p-3.5 text-xs text-brand-900 space-y-2">
          <p className="font-bold flex items-center gap-1.5">
            <span>⚡ Quick Demo Credentials</span>
          </p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => fillDemo('john@example.com', 'John@123')}
              className="bg-white hover:bg-brand-100 px-2.5 py-1 rounded-lg border border-brand-200 font-medium transition-colors"
            >
              👤 Customer (john@example.com)
            </button>
            <button
              type="button"
              onClick={() => fillDemo('admin@shopzone.com', 'Admin@123')}
              className="bg-white hover:bg-brand-100 px-2.5 py-1 rounded-lg border border-brand-200 font-medium transition-colors"
            >
              👑 Admin (admin@shopzone.com)
            </button>
          </div>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-100 shadow-xl rounded-3xl">
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <span className="text-red-500 font-bold">⚠️</span>
              <span>{errorMessage}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Email Address</label>
              <div className="relative">
                <input
                  type="email"
                  {...register('email', { required: 'Email is required' })}
                  placeholder="name@example.com"
                  className="input-field pl-10 text-sm"
                />
                <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Password</label>
              <div className="relative">
                <input
                  type="password"
                  {...register('password', { required: 'Password is required' })}
                  placeholder="••••••••"
                  className="input-field pl-10 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password.message}</p>}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-brand py-3 font-bold text-sm shadow-md shadow-brand-500/25"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="text-center text-xs text-gray-500 pt-2 border-t border-gray-100">
            Don't have an account?{' '}
            <Link href="/register" className="font-bold text-brand-600 hover:underline">
              Create an account
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
