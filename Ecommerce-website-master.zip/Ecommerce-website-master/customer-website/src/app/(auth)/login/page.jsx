'use client';
import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useMutation, useLazyQuery, useQuery } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, LockClosedIcon, EnvelopeIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { LOGIN, REGISTER, SYNC_CART, SEND_LOGIN_OTP, LOGIN_WITH_OTP } from '@/graphql/mutations';
import { CHECK_USER_EXISTS, GET_STORE_SETTINGS } from '@/graphql/queries';
import { useAuthStore } from '@/store/authStore';

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500" />
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectUrl = searchParams.get('redirect') || '/';
  const [errorMessage, setErrorMessage] = useState('');
  
  const [loginMethod, setLoginMethod] = useState('password'); // 'password' or 'otp'
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  
  const [step, setStep] = useState(1);
  const [identifier, setIdentifier] = useState('');
  const [userExists, setUserExists] = useState(false);

  const { login } = useAuthStore();
  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;

  const { register, handleSubmit, setValue, formState: { errors } } = useForm({
    defaultValues: { email: '', password: '' },
  });

  const [syncCartMutation] = useMutation(SYNC_CART);
  
  const [checkUserExists, { loading: checkingUser }] = useLazyQuery(CHECK_USER_EXISTS, {
    fetchPolicy: 'network-only',
    onCompleted: (data) => {
      setUserExists(data.checkUserExists);
      setStep(2);
    },
    onError: () => {
      // If error (e.g. not implemented), assume user doesn't exist for now or handle appropriately
      setUserExists(false);
      setStep(2);
    }
  });

  const onAuthSuccess = async (user, token, refreshToken, isNewUser = false) => {
    login(user, token, refreshToken);
    toast.success(isNewUser ? `Welcome, ${user.name}!` : `Welcome back, ${user.name}!`);

    // Sync guest cart if any
    try {
      const raw = typeof window !== 'undefined' ? localStorage.getItem('shopGuestCart') : null;
      const guestItems = raw ? JSON.parse(raw) : [];
      if (guestItems && guestItems.length > 0) {
        const itemsToSync = guestItems
          .filter((item) => item.product && (item.product._id || item.product))
          .map((item) => ({
            productId: item.product._id || item.product,
            variantIndex: item.variantIndex ?? -1,
            quantity: item.quantity || 1,
          }));
        if (itemsToSync.length > 0) {
          await syncCartMutation({ variables: { items: itemsToSync } });
          localStorage.removeItem('shopGuestCart');
        }
      }
    } catch (err) {
      console.error('Guest cart sync error:', err);
    }

    router.push(redirectUrl);
  };

  const [loginMutation, { loading: loggingIn }] = useMutation(LOGIN, {
    onCompleted: async (data) => {
      const { user, token, refreshToken } = data.login;
      await onAuthSuccess(user, token, refreshToken, false);
    },
    onError: (err) => {
      const msg = err.message || 'Invalid username or password';
      setErrorMessage(msg);
      toast.error(msg);
    },
  });

  const [registerMutation, { loading: registering }] = useMutation(REGISTER, {
    onCompleted: async (data) => {
      const { user, token, refreshToken } = data.register;
      await onAuthSuccess(user, token, refreshToken, true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Registration failed');
      toast.error(err.message || 'Registration failed');
    },
  });

  const [sendOtpMutation, { loading: sendingOtp }] = useMutation(SEND_LOGIN_OTP, {
    onCompleted: (data) => {
      toast.success(data.sendLoginOTP.message || 'OTP sent successfully');
      setOtpSent(true);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to send OTP');
      toast.error(err.message || 'Failed to send OTP');
    }
  });

  const [loginOtpMutation, { loading: loggingInOtp }] = useMutation(LOGIN_WITH_OTP, {
    onCompleted: async (data) => {
      const { token, refreshToken, user } = data.loginWithOTP;
      await onAuthSuccess(user, token, refreshToken, false);
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Invalid OTP');
      toast.error(err.message || 'Invalid OTP');
    }
  });

  const onStep1Submit = (e) => {
    e.preventDefault();
    if (!identifier) return;
    setErrorMessage('');
    checkUserExists({ variables: { identifier } });
  };

  const handleSendOtp = (e) => {
    e.preventDefault();
    if (!identifier) {
      setErrorMessage('Please enter your email or mobile');
      return;
    }
    setErrorMessage('');
    sendOtpMutation({ variables: { email: identifier } });
  };

  const handleLoginOtp = (e) => {
    e.preventDefault();
    if (!otpCode) {
      setErrorMessage('Please enter the OTP');
      return;
    }
    setErrorMessage('');
    loginOtpMutation({ variables: { email: identifier, otp: otpCode } });
  };

  const onStep2Submit = (formData) => {
    setErrorMessage('');
    if (userExists) {
      loginMutation({
        variables: {
          input: {
            email: identifier,
            password: formData.password,
          },
        },
      });
    } else {
      registerMutation({
        variables: {
          input: {
            email: identifier,
            password: formData.password,
            role: 'customer',
            acceptedTerms: true,
          },
        },
      });
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            {storeSettings?.logoUrl ? (
              <img src={storeSettings.logoUrl} alt={storeSettings?.storeName || 'Suaaka'} className="h-10 md:h-12 w-auto object-contain max-w-[200px]" />
            ) : (
              <>
                <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
                  <BuildingStorefrontIcon className="w-5 h-5" />
                </div>
                <span>{storeSettings?.storeName || 'Suaaka'}</span>
              </>
            )}
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">{step === 1 ? 'Sign in or create account' : (userExists ? 'Sign in' : 'Create account')}</h2>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-200 shadow-sm rounded-xl">
          <div className="flex bg-gray-100 p-1 rounded-xl mb-2">
            <button
              onClick={() => setLoginMethod('password')}
              className={`flex-1 text-sm font-bold py-2 rounded-lg transition-all ${
                loginMethod === 'password' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Password
            </button>
            <button
              onClick={() => setLoginMethod('otp')}
              className={`flex-1 text-sm font-bold py-2 rounded-lg transition-all ${
                loginMethod === 'otp' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              OTP
            </button>
          </div>

          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <span className="text-red-500 font-bold">⚠️</span>
              <span>{errorMessage}</span>
            </motion.div>
          )}

          {loginMethod === 'password' ? (
            step === 1 ? (
              <form onSubmit={onStep1Submit} className="space-y-4">
                <div>
                  <label className="text-sm font-bold text-gray-800 block mb-1">Enter mobile number or email</label>
                  <input
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    required
                    autoFocus
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm"
                  />
                </div>

                <button
                  type="submit"
                  disabled={checkingUser}
                  className="w-full bg-brand-500 hover:bg-brand-600 text-white rounded-lg py-2.5 font-bold text-sm shadow-sm transition-colors"
                >
                  {checkingUser ? 'Continuing...' : 'Continue'}
                </button>

                <p className="text-[11px] text-gray-600 pb-2">
                  By continuing, you agree to {storeSettings?.storeName || 'Suaaka'}&apos;s <Link href="/terms" className="text-blue-600 hover:underline">Conditions of Use</Link> and <Link href="/privacy" className="text-blue-600 hover:underline">Privacy Notice</Link>.
                </p>

                <div className="pt-4 mt-4 border-t border-gray-200">
                  <p className="text-xs font-bold text-gray-800 mb-2">Buying for work?</p>
                  <Link href="/business/register" className="text-sm text-blue-600 hover:underline">
                    Create a free business account
                  </Link>
                </div>
              </form>
            ) : (
              <form onSubmit={handleSubmit(onStep2Submit)} className="space-y-4">
                <div className="text-sm text-gray-800 flex items-center gap-2 mb-4">
                  <span>{identifier}</span>
                  <button type="button" onClick={() => setStep(1)} className="text-blue-600 hover:underline text-xs font-bold">Change</button>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-sm font-bold text-gray-800 block">Password</label>
                    {userExists && (
                      <Link
                        href="/forgot-password"
                        className="text-[11px] text-blue-600 hover:underline"
                      >
                        Forgot Password?
                      </Link>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="password"
                      {...register('password', { required: 'Password is required' })}
                      autoFocus
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm pl-10"
                    />
                    <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  </div>
                  {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password.message}</p>}
                </div>

                <button
                  type="submit"
                  disabled={loggingIn || registering}
                  className="w-full bg-brand-500 hover:bg-brand-600 text-white rounded-lg py-2.5 font-bold text-sm shadow-sm transition-colors"
                >
                  {loggingIn || registering ? 'Processing...' : (userExists ? 'Sign In' : 'Create Account')}
                </button>
              </form>
            )
          ) : (
            <form onSubmit={otpSent ? handleLoginOtp : handleSendOtp} className="space-y-4">
              <div>
                <label className="text-sm font-bold text-gray-800 block mb-1">Email Address</label>
                <input
                  type="email"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  required
                  disabled={otpSent}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm"
                />
              </div>

              {otpSent && (
                <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
                  <label className="text-sm font-bold text-gray-800 block mb-1">OTP Code</label>
                  <input
                    type="text"
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    required
                    placeholder="Enter 6-digit OTP"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-brand-500 focus:border-brand-500 text-sm tracking-widest"
                  />
                </motion.div>
              )}

              <button
                type="submit"
                disabled={sendingOtp || loggingInOtp}
                className="w-full bg-brand-500 hover:bg-brand-600 text-white rounded-lg py-2.5 font-bold text-sm shadow-sm transition-colors"
              >
                {sendingOtp || loggingInOtp ? 'Processing...' : (otpSent ? 'Login' : 'Send OTP')}
              </button>

              {otpSent && (
                <button
                  type="button"
                  onClick={() => { setOtpSent(false); setOtpCode(''); }}
                  className="w-full text-xs text-brand-600 hover:text-brand-700 font-semibold mt-2"
                >
                  Change Email or Resend OTP
                </button>
              )}
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
