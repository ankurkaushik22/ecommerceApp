'use client';
import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, KeyIcon, EnvelopeIcon, ArrowLeftIcon, CheckCircleIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { FORGOT_PASSWORD, VERIFY_RESET_OTP } from '@/graphql/mutations';

export default function ForgotPasswordPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500" />
        </div>
      }
    >
      <ForgotPasswordContent />
    </Suspense>
  );
}

function ForgotPasswordContent() {
  const router = useRouter();
  const [step, setStep] = useState('email'); // 'email' | 'otp' | 'success'
  const [submittedEmail, setSubmittedEmail] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const { register: regEmail, handleSubmit: handleEmailSubmit, formState: { errors: emailErrors } } = useForm({
    defaultValues: { email: '' },
  });

  const { register: regOtp, handleSubmit: handleOtpSubmit, formState: { errors: otpErrors } } = useForm({
    defaultValues: { otp: '' },
  });

  const [forgotPasswordMutation, { loading: sendingEmail }] = useMutation(FORGOT_PASSWORD, {
    onCompleted: (data) => {
      const res = data.forgotPassword;
      if (res.success) {
        if (res.resetToken) {
          setResetToken(res.resetToken);
        }
        setStep('otp');
        toast.success('Password reset instructions generated!');
      } else {
        setErrorMessage(res.message || 'Unable to process reset request');
      }
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to send reset email');
      toast.error(err.message || 'Failed to send reset email');
    },
  });

  const [verifyOtpMutation, { loading: verifyingOtp }] = useMutation(VERIFY_RESET_OTP, {
    onCompleted: (data) => {
      const res = data.verifyResetOTP;
      if (res.success && res.resetToken) {
        toast.success('OTP verified! Now choose a new password.');
        router.push(`/reset-password?token=${res.resetToken}&email=${encodeURIComponent(submittedEmail)}`);
      } else {
        setErrorMessage('Verification failed. Please try again.');
      }
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Invalid or expired OTP');
      toast.error(err.message || 'Invalid OTP');
    },
  });

  const onEmailSubmit = (formData, e) => {
    e?.preventDefault?.();
    setErrorMessage('');
    setSubmittedEmail(formData.email);
    forgotPasswordMutation({ variables: { email: formData.email } });
  };

  const onOtpSubmit = (formData, e) => {
    e?.preventDefault?.();
    setErrorMessage('');
    verifyOtpMutation({
      variables: {
        email: submittedEmail,
        otp: formData.otp.trim(),
      },
    });
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
              <BuildingStorefrontIcon className="w-5 h-5" />
            </div>
            <span>Suaaka</span>
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">
            {step === 'email' ? 'Forgot Password?' : 'Enter Verification Code'}
          </h2>
          <p className="text-xs text-gray-500 max-w-sm mx-auto">
            {step === 'email'
              ? "Don't worry! Enter your registered email address and we'll help you reset your password."
              : `We sent a 6-digit verification code to ${submittedEmail}`}
          </p>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-100 shadow-xl rounded-3xl">
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <span className="text-red-500 font-bold">⚠️</span>
              <span>{errorMessage}</span>
            </motion.div>
          )}

          {step === 'email' ? (
            <form onSubmit={handleEmailSubmit(onEmailSubmit)} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">Registered Email Address</label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="you@example.com"
                    {...regEmail('email', {
                      required: 'Email is required',
                      pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email format' },
                    })}
                    className="input-field pl-10 text-sm"
                  />
                  <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
                {emailErrors.email && (
                  <p className="text-red-500 text-xs mt-1">{emailErrors.email.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={sendingEmail}
                className="btn-brand w-full py-3 text-sm font-bold shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2"
              >
                {sendingEmail ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <KeyIcon className="w-4 h-4" />
                    <span>Send Reset Instructions</span>
                  </>
                )}
              </button>
            </form>
          ) : (
            <form onSubmit={handleOtpSubmit(onOtpSubmit)} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 block mb-1">6-Digit Verification Code (OTP)</label>
                <input
                  type="text"
                  maxLength={6}
                  placeholder="e.g. 123456"
                  {...regOtp('otp', {
                    required: 'Please enter the 6-digit OTP',
                    minLength: { value: 6, message: 'OTP must be 6 digits' },
                  })}
                  className="input-field text-center text-lg tracking-widest font-mono font-bold"
                />
                {otpErrors.otp && (
                  <p className="text-red-500 text-xs mt-1">{otpErrors.otp.message}</p>
                )}
              </div>

              {resetToken && (
                <div className="p-3 bg-brand-50 border border-brand-200 rounded-xl text-center">
                  <p className="text-[11px] text-brand-800 font-semibold mb-2">Or continue directly with secure token:</p>
                  <Link
                    href={`/reset-password?token=${resetToken}&email=${encodeURIComponent(submittedEmail)}`}
                    className="text-xs font-bold text-brand-600 hover:text-brand-700 underline"
                  >
                    Click here to Set New Password Directly &rarr;
                  </Link>
                </div>
              )}

              <button
                type="submit"
                disabled={verifyingOtp}
                className="btn-brand w-full py-3 text-sm font-bold shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2"
              >
                {verifyingOtp ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <CheckCircleIcon className="w-4 h-4" />
                    <span>Verify Code & Proceed</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep('email')}
                className="w-full text-center text-xs text-gray-500 hover:text-gray-700 pt-2 block font-medium"
              >
                Try different email
              </button>
            </form>
          )}

          <div className="pt-4 border-t border-gray-100 text-center">
            <Link
              href="/login"
              className="inline-flex items-center gap-1.5 text-xs font-bold text-brand-600 hover:text-brand-700"
            >
              <ArrowLeftIcon className="w-3.5 h-3.5" />
              <span>Back to Sign In</span>
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
