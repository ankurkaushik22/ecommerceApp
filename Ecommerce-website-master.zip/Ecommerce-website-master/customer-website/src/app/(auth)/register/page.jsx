'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, UserIcon, EnvelopeIcon, LockClosedIcon, PhoneIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { REGISTER } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

export default function RegisterPage() {
  const router = useRouter();
  const loginStore = useAuthStore((s) => s.login);

  const { register, handleSubmit, formState: { errors } } = useForm();

  const [registerMutation, { loading }] = useMutation(REGISTER, {
    onCompleted: (data) => {
      const { user, token, refreshToken } = data.register;
      loginStore(user, token, refreshToken);
      toast.success(`Welcome to ShopZone, ${user.name}!`);
      router.push('/');
    },
    onError: (err) => {
      toast.error(err.message || 'Registration failed');
    },
  });

  const onSubmit = (formData) => {
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    registerMutation({
      variables: {
        input: {
          name: formData.name,
          email: formData.email,
          password: formData.password,
          phone: formData.phone || '',
          role: 'customer',
        },
      },
    });
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
              <BuildingStorefrontIcon className="w-5 h-5" />
            </div>
            <span>ShopZone</span>
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">Create an account</h2>
          <p className="text-xs text-gray-500">Join ShopZone to shop from millions of products</p>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-100 shadow-xl rounded-3xl">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Full Name *</label>
              <div className="relative">
                <input
                  type="text"
                  {...register('name', { required: 'Name is required' })}
                  placeholder="John Doe"
                  className="input-field pl-10 text-sm"
                />
                <UserIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name.message}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Email Address *</label>
              <div className="relative">
                <input
                  type="email"
                  {...register('email', { required: 'Email is required' })}
                  placeholder="name@example.com"
                  className="input-field pl-10 text-sm"
                />
                <EnvelopeIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Phone Number (Optional)</label>
              <div className="relative">
                <input
                  type="tel"
                  {...register('phone')}
                  placeholder="+1 (555) 000-0000"
                  className="input-field pl-10 text-sm"
                />
                <PhoneIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Password *</label>
              <div className="relative">
                <input
                  type="password"
                  {...register('password', { required: 'Password is required', minLength: 6 })}
                  placeholder="At least 6 characters"
                  className="input-field pl-10 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.password && <p className="text-xs text-red-500 mt-1">Minimum 6 characters required</p>}
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Confirm Password *</label>
              <div className="relative">
                <input
                  type="password"
                  {...register('confirmPassword', { required: 'Confirm password is required' })}
                  placeholder="••••••••"
                  className="input-field pl-10 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-brand py-3 font-bold text-sm shadow-md shadow-brand-500/25"
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </button>
          </form>

          <div className="text-center text-xs text-gray-500 pt-2 border-t border-gray-100">
            Already have an account?{' '}
            <Link href="/login" className="font-bold text-brand-600 hover:underline">
              Sign In
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
