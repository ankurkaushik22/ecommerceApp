'use client';
import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useMutation } from '@apollo/client';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { BuildingStorefrontIcon, LockClosedIcon, CheckBadgeIcon } from '@heroicons/react/24/outline';
import toast from 'react-hot-toast';
import { RESET_PASSWORD } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';

export default function ResetPasswordPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-[80vh] flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-500" />
        </div>
      }
    >
      <ResetPasswordContent />
    </Suspense>
  );
}

function ResetPasswordContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token') || '';
  const email = searchParams.get('email') || '';

  const [errorMessage, setErrorMessage] = useState('');
  const loginStore = useAuthStore((s) => s.login);

  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: { password: '', confirmPassword: '' },
  });

  const password = watch('password', '');

  const [resetPasswordMutation, { loading }] = useMutation(RESET_PASSWORD, {
    onCompleted: (data) => {
      const { token: authToken, refreshToken, user } = data.resetPassword;
      loginStore(user, authToken, refreshToken);
      toast.success('Password updated successfully! Welcome back.');
      router.push('/');
    },
    onError: (err) => {
      setErrorMessage(err.message || 'Failed to reset password. The link or token may have expired.');
      toast.error(err.message || 'Password reset failed');
    },
  });

  const onSubmit = (formData, e) => {
    e?.preventDefault?.();
    setErrorMessage('');
    if (!token) {
      setErrorMessage('Missing password reset token. Please request a new link.');
      return;
    }
    resetPasswordMutation({
      variables: {
        token,
        newPassword: formData.password,
      },
    });
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-6"
      >
        <div className="text-center space-y-2">
          <Link href="/" className="inline-flex items-center gap-2 text-brand-600 font-extrabold text-2xl">
            <div className="w-9 h-9 bg-brand-500 rounded-xl flex items-center justify-center text-white">
              <BuildingStorefrontIcon className="w-5 h-5" />
            </div>
            <span>Suaaka</span>
          </Link>
          <h2 className="text-2xl font-bold text-gray-900">Set New Password</h2>
          <p className="text-xs text-gray-500">
            {email ? `For ${email} — ` : ''}Please enter your new secure password below.
          </p>
        </div>

        <div className="card p-6 sm:p-8 space-y-5 bg-white border border-gray-100 shadow-xl rounded-3xl">
          {errorMessage && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-semibold rounded-xl flex items-center gap-2"
            >
              <span className="text-red-500 font-bold">⚠️</span>
              <span>{errorMessage}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">New Password</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Min 6 characters"
                  {...register('password', {
                    required: 'New password is required',
                    minLength: { value: 6, message: 'Password must be at least 6 characters' },
                  })}
                  className="input-field pl-10 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.password && (
                <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>
              )}
            </div>

            <div>
              <label className="text-xs font-bold text-gray-700 block mb-1">Confirm New Password</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Re-type new password"
                  {...register('confirmPassword', {
                    required: 'Please confirm your new password',
                    validate: (val) => val === password || 'Passwords do not match',
                  })}
                  className="input-field pl-10 text-sm"
                />
                <LockClosedIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
              {errors.confirmPassword && (
                <p className="text-red-500 text-xs mt-1">{errors.confirmPassword.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-brand w-full py-3 text-sm font-bold shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <CheckBadgeIcon className="w-5 h-5" />
                  <span>Update Password & Sign In</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-3 border-t border-gray-100 text-center">
            <Link
              href="/login"
              className="text-xs font-bold text-gray-500 hover:text-brand-600"
            >
              Cancel and return to Sign In
            </Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
