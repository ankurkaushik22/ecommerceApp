'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeftIcon, ChevronRightIcon, SparklesIcon } from '@heroicons/react/24/outline';

const SLIDES = [
  {
    id: 1,
    title: 'Next-Gen Wireless Noise Cancelling Headphones',
    subtitle: 'Experience spatial audio and industry-leading silence with up to 40 hours of battery.',
    tag: 'Exclusive Launch',
    link: '/products/sony-wh-1000xm5-wireless-headphones',
    bgGradient: 'from-slate-900 via-indigo-950 to-navy-900',
    accentColor: 'text-indigo-400',
    buttonColor: 'bg-brand-500 hover:bg-brand-600',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80',
    discount: '25% OFF',
  },
  {
    id: 2,
    title: 'Apple MacBook Pro M3 Max (16-inch)',
    subtitle: 'Extreme power for pros. Mind-blowing performance and unbelievable battery life.',
    tag: 'Super Deal',
    link: '/products/apple-macbook-pro-16-m3-max',
    bgGradient: 'from-gray-950 via-gray-900 to-black',
    accentColor: 'text-amber-400',
    buttonColor: 'bg-amber-500 hover:bg-amber-600',
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&auto=format&fit=crop&q=80',
    discount: '$200 OFF',
  },
  {
    id: 3,
    title: 'Nike Air Zoom Pegasus 40 Running Shoes',
    subtitle: 'A springy ride for every run. Responsive cushioning tuned for all athletes.',
    tag: 'Trending Now',
    link: '/products/nike-air-zoom-pegasus-40',
    bgGradient: 'from-orange-950 via-amber-950 to-neutral-900',
    accentColor: 'text-orange-400',
    buttonColor: 'bg-brand-500 hover:bg-brand-600',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
    discount: 'HOT DEAL',
  },
];

export default function HeroBanner() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const prevSlide = () => setCurrent((prev) => (prev === 0 ? SLIDES.length - 1 : prev - 1));
  const nextSlide = () => setCurrent((prev) => (prev + 1) % SLIDES.length);

  return (
    <div className="relative w-full overflow-hidden rounded-3xl shadow-2xl min-h-[460px] md:min-h-[500px]">
      <AnimatePresence mode="wait">
        <motion.div
          key={current}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.7 }}
          className={`absolute inset-0 bg-gradient-to-r ${SLIDES[current].bgGradient} flex items-center`}
        >
          <div className="max-w-7xl mx-auto px-6 md:px-12 py-10 w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Text details */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="text-white space-y-4 md:space-y-6 z-10"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold uppercase tracking-wider text-white">
                <SparklesIcon className="w-3.5 h-3.5 text-amber-400" />
                <span>{SLIDES[current].tag}</span>
                <span className="bg-brand-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
                  {SLIDES[current].discount}
                </span>
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight leading-tight">
                {SLIDES[current].title}
              </h1>

              <p className="text-sm md:text-base text-gray-300 max-w-lg leading-relaxed">
                {SLIDES[current].subtitle}
              </p>

              <div className="pt-2 flex items-center gap-4">
                <Link
                  href={SLIDES[current].link}
                  className={`inline-block px-7 py-3.5 rounded-xl font-bold text-white shadow-lg transition-transform active:scale-95 ${SLIDES[current].buttonColor}`}
                >
                  Shop Now →
                </Link>
                <Link
                  href="/deals"
                  className="px-6 py-3.5 rounded-xl font-semibold text-white bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/15 transition-all"
                >
                  View All Deals
                </Link>
              </div>
            </motion.div>

            {/* Banner Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="relative h-64 md:h-96 flex items-center justify-center"
            >
              <div className="relative w-full h-full max-w-md mx-auto drop-shadow-2xl">
                <img
                  src={SLIDES[current].image}
                  alt={SLIDES[current].title}
                  className="w-full h-full object-contain filter drop-shadow-[0_20px_30px_rgba(0,0,0,0.5)] transform hover:scale-105 transition-transform duration-500"
                />
              </div>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Nav Controls */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/30 hover:bg-black/60 text-white backdrop-blur-sm border border-white/10 transition-all z-20"
        aria-label="Previous Slide"
      >
        <ChevronLeftIcon className="w-5 h-5" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/30 hover:bg-black/60 text-white backdrop-blur-sm border border-white/10 transition-all z-20"
        aria-label="Next Slide"
      >
        <ChevronRightIcon className="w-5 h-5" />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
        {SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`h-2 rounded-full transition-all duration-300 ${
              i === current ? 'w-8 bg-brand-500' : 'w-2 bg-white/40 hover:bg-white/70'
            }`}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
