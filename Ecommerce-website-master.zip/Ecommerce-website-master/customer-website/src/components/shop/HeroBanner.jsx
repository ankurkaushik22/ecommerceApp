'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeftIcon, ChevronRightIcon, SparklesIcon } from '@heroicons/react/24/outline';
import { useQuery } from '@apollo/client';
import { GET_BANNERS } from '../../graphql/queries';

export default function HeroBanner() {
  const [current, setCurrent] = useState(0);
  const { data, loading, error } = useQuery(GET_BANNERS, {
    variables: { platform: 'website' }
  });

  const slides = data?.getBanners || [];

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const prevSlide = () => setCurrent((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  const nextSlide = () => setCurrent((prev) => (prev + 1) % slides.length);

  if (loading) {
    return (
      <div className="relative w-full overflow-hidden rounded-3xl shadow-2xl min-h-[460px] md:min-h-[500px] bg-gray-100 animate-pulse flex items-center justify-center">
        <span className="text-gray-400">Loading banners...</span>
      </div>
    );
  }

  if (error || slides.length === 0) return null;

  return (
    <div className="relative w-full overflow-hidden rounded-2xl shadow-xl aspect-[16/9] sm:aspect-[21/9] md:aspect-[7/2] lg:aspect-[4/1] min-h-[200px] max-h-[360px] bg-gray-100">
      <AnimatePresence mode="wait">
          <Link
            key={current}
            href={slides[current].link || '#'}
            className="absolute inset-0 block group cursor-pointer"
          >
            <motion.div
              initial={{ opacity: 0, scale: 1.05 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.7 }}
              className="relative w-full h-full"
            >
              {/* Background Image */}
              <img
                src={slides[current].image}
                alt={slides[current].title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
            </motion.div>
          </Link>
      </AnimatePresence>

      {/* Nav Controls */}
      {slides.length > 1 && (
        <>
          <button
            onClick={prevSlide}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/30 hover:bg-black/60 text-white backdrop-blur-sm border border-white/10 transition-all z-20"
            aria-label="Previous Slide"
          >
            <ChevronLeftIcon className="w-5 h-5" />
          </button>
          <button
            onClick={nextSlide}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/30 hover:bg-black/60 text-white backdrop-blur-sm border border-white/10 transition-all z-20"
            aria-label="Next Slide"
          >
            <ChevronRightIcon className="w-5 h-5" />
          </button>

          {/* Indicators */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  i === current ? 'w-8 bg-brand-500' : 'w-2 bg-white/40 hover:bg-white/70'
                }`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
