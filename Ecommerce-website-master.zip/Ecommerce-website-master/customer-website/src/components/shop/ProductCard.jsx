'use client';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { StarIcon, HeartIcon } from '@heroicons/react/20/solid';
import { HeartIcon as HeartOutline, ShoppingCartIcon } from '@heroicons/react/24/outline';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import { useMutation } from '@apollo/client';
import { TOGGLE_WISHLIST, ADD_TO_CART } from '@/graphql/mutations';
import { GET_ME, GET_CART } from '@/graphql/queries';
import toast from 'react-hot-toast';

export default function ProductCard({ product }) {
  const { user, isAuthenticated } = useAuthStore();
  const addItem = useCartStore((s) => s.addItem);

  const [toggleWishlistMutation] = useMutation(TOGGLE_WISHLIST, {
    refetchQueries: [{ query: GET_ME }],
    onError: (e) => toast.error(e.message),
  });

  const [addToCartMutation, { loading: addingToCart }] = useMutation(ADD_TO_CART, {
    refetchQueries: [{ query: GET_CART }],
    onCompleted: () => {
      toast.success(`Added ${product.name.substring(0, 20)}... to cart!`);
    },
    onError: (e) => toast.error(e.message),
  });

  const isWishlisted = user?.wishlist?.some((w) => w._id === product._id);

  const handleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isAuthenticated) {
      toast.error('Please login to save to wishlist');
      return;
    }
    toggleWishlistMutation({ variables: { productId: product._id } });
  };

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (isAuthenticated) {
      addToCartMutation({
        variables: {
          input: {
            productId: product._id,
            quantity: 1,
            variantIndex: -1,
          },
        },
      });
    } else {
      addItem(product, 1);
      toast.success('Added to cart!');
    }
  };

  const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80';
  const ratingAvg = product.rating?.average || 0;
  const ratingCount = product.rating?.count || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25 }}
      className="card group flex flex-col justify-between overflow-hidden relative bg-white border border-gray-100 hover:shadow-xl transition-all duration-300 rounded-2xl"
    >
      {/* Badges & Wishlist */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-none">
        <div className="flex flex-col gap-1">
          {product.discount > 0 && (
            <span className="bg-red-500 text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-sm">
              -{product.discount}% OFF
            </span>
          )}
          {product.freeShipping && (
            <span className="bg-emerald-600 text-white text-[10px] font-semibold px-2 py-0.5 rounded-full shadow-sm">
              Free Delivery
            </span>
          )}
        </div>
        <button
          onClick={handleWishlist}
          className="pointer-events-auto p-2 rounded-full bg-white/90 backdrop-blur-sm shadow-md hover:bg-white text-gray-400 hover:text-red-500 transition-colors"
          aria-label="Wishlist"
        >
          {isWishlisted ? (
            <HeartIcon className="w-5 h-5 text-red-500" />
          ) : (
            <HeartOutline className="w-5 h-5" />
          )}
        </button>
      </div>

      {/* Image */}
      <Link href={`/products/${product.slug}`} className="block relative pt-[90%] w-full overflow-hidden bg-gray-50">
        <img
          src={primaryImage}
          alt={product.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80';
          }}
        />
      </Link>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1 justify-between">
        <div>
          {/* Category */}
          {product.category && (
            <span className="text-[11px] font-semibold uppercase tracking-wider text-brand-600 block mb-1">
              {product.category.name}
            </span>
          )}

          {/* Title */}
          <Link href={`/products/${product.slug}`}>
            <h3 className="text-sm font-semibold text-gray-900 line-clamp-2 hover:text-brand-600 transition-colors">
              {product.name}
            </h3>
          </Link>

          {/* Ratings */}
          <div className="flex items-center gap-1.5 mt-2">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <StarIcon
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.round(ratingAvg) ? 'text-amber-400' : 'text-gray-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-gray-500 font-medium">
              {ratingAvg > 0 ? ratingAvg.toFixed(1) : 'New'} ({ratingCount})
            </span>
          </div>
        </div>

        {/* Price & Add to Cart */}
        <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-bold text-gray-900">
                ${product.price?.toFixed(2)}
              </span>
              {product.comparePrice && product.comparePrice > product.price && (
                <span className="text-xs text-gray-400 line-through">
                  ${product.comparePrice.toFixed(2)}
                </span>
              )}
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            disabled={addingToCart || product.stock <= 0}
            className="p-2.5 rounded-xl bg-brand-500 hover:bg-brand-600 active:scale-95 text-white transition-all shadow-md shadow-brand-500/20 disabled:opacity-50"
            title={product.stock <= 0 ? 'Out of Stock' : 'Add to Cart'}
          >
            <ShoppingCartIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
