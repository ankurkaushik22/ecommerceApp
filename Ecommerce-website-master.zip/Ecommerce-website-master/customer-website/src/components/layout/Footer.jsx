'use client';
import Link from 'next/link';
import { BuildingStorefrontIcon } from '@heroicons/react/24/outline';

export default function Footer() {
  return (
    <footer className="bg-navy-800 text-gray-300 mt-16">
      {/* Back to top */}
      <div
        className="bg-navy-700 text-center py-3 cursor-pointer hover:bg-navy-600 transition-colors text-sm text-white font-medium"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        ↑ Back to top
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Get to Know Us</h3>
            <ul className="space-y-2 text-sm">
              {['About ShopZone', 'Careers', 'Press Releases', 'ShopZone Cares', 'Gift a Smile', 'ShopZone Science'].map((item) => (
                <li key={item}><Link href="#" className="hover:text-white hover:underline transition-colors">{item}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Make Money with Us</h3>
            <ul className="space-y-2 text-sm">
              {['Sell products on ShopZone', 'Sell on ShopZone Business', 'Sell apps on ShopZone', 'Become an Affiliate', 'Advertise Your Products', 'ShopZone Fulfillment'].map((item) => (
                <li key={item}><Link href="#" className="hover:text-white hover:underline transition-colors">{item}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Payment Products</h3>
            <ul className="space-y-2 text-sm">
              {['ShopZone Business Card', 'Shop with Points', 'Reload Your Balance', 'ShopZone Currency Converter'].map((item) => (
                <li key={item}><Link href="#" className="hover:text-white hover:underline transition-colors">{item}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Let Us Help You</h3>
            <ul className="space-y-2 text-sm">
              {[
                { label: 'Your Account', href: '/account' },
                { label: 'Your Orders', href: '/orders' },
                { label: 'Shipping Rates & Policies', href: '#' },
                { label: 'Returns & Replacements', href: '#' },
                { label: 'Help', href: '#' },
              ].map((item) => (
                <li key={item.label}><Link href={item.href} className="hover:text-white hover:underline transition-colors">{item.label}</Link></li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-navy-700">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
              <BuildingStorefrontIcon className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-bold">ShopZone</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-gray-400">
            {['Conditions of Use', 'Privacy Notice', 'Interest-Based Ads'].map((item) => (
              <Link key={item} href="#" className="hover:text-white transition-colors">{item}</Link>
            ))}
          </div>

          <p className="text-xs text-gray-500">© {new Date().getFullYear()} ShopZone. All rights reserved.</p>
        </div>

        {/* Payment Icons */}
        <div className="border-t border-navy-700 py-4">
          <div className="max-w-7xl mx-auto px-4 flex items-center justify-center gap-3 flex-wrap">
            {['💳 Visa', '💳 Mastercard', '🔒 Stripe', '💵 Cash on Delivery', '🛡️ Secure Checkout'].map((item) => (
              <span key={item} className="text-xs text-gray-400 bg-navy-700 px-3 py-1.5 rounded-lg">{item}</span>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
