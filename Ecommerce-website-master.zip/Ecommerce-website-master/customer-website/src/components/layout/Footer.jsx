'use client';
import Link from 'next/link';
import { BuildingStorefrontIcon } from '@heroicons/react/24/outline';
import { useQuery } from '@apollo/client';
import { GET_STORE_SETTINGS } from '@/graphql/queries';

export default function Footer() {
  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;

  return (
    <footer className="bg-navy-800 text-gray-300 mt-16">
      {/* Back to top */}
      <div
        className="bg-navy-700 text-center py-3 cursor-pointer hover:bg-navy-600 transition-colors text-sm text-white font-medium"
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        ↑ Back to top
      </div>

      {/* Main Footer */}
      <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-12 md:gap-16">
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Get to Know Us</h3>
            <ul className="space-y-2 text-sm">
              {[
                { label: `About ${storeSettings?.storeName || 'Us'}`, href: '#' }
              ].map((item) => (
                <li key={item.label}><Link href={item.href} className="hover:text-white hover:underline transition-colors">{item.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Make Money with Us</h3>
            <ul className="space-y-2 text-sm">
              {[
                { label: `Sell on ${storeSettings?.storeName || 'Our Store'}`, href: '/business/register' }
              ].map((item) => (
                <li key={item.label}><Link href={item.href} className="hover:text-white hover:underline transition-colors">{item.label}</Link></li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-4 text-sm">Let Us Help You</h3>
            <ul className="space-y-2 text-sm">
              {[
                { label: 'Your Account', href: '/account' },
                { label: 'Your Orders', href: '/orders' },
                { label: 'Shipping Rates & Policies', href: '#' },
                { label: 'Returns & Replacements', href: '#' },
                { label: 'Customer Support & Helpdesk', href: '/support' },
              ].map((item) => (
                <li key={item.label}><Link href={item.href} className="hover:text-white hover:underline transition-colors">{item.label}</Link></li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-navy-700">
        <div className="w-full mx-auto px-4 sm:px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2">
            {storeSettings?.logoUrl ? (
              <>
                <img src={storeSettings.logoUrl} alt={storeSettings?.storeName || 'Suaaka'} className="h-7 w-auto object-contain" />
                <span className="text-white font-bold">{storeSettings?.storeName || 'Suaaka'}</span>
              </>
            ) : (
              <>
                <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center">
                  <BuildingStorefrontIcon className="w-4 h-4 text-white" />
                </div>
                <span className="text-white font-bold">{storeSettings?.storeName || 'Suaaka'}</span>
              </>
            )}
          </Link>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-gray-400">
            <Link href="/terms" className="hover:text-white transition-colors">Conditions of Use</Link>
            <Link href="/privacy" className="hover:text-white transition-colors">Privacy Notice</Link>
            <Link href="#" className="hover:text-white transition-colors">Interest-Based Ads</Link>
          </div>

          <p className="text-xs text-gray-500">© {new Date().getFullYear()} {storeSettings?.storeName || 'Suaaka'}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
