'use client';
import { Fragment } from 'react';
import Link from 'next/link';
import { useQuery, useMutation } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import { XMarkIcon, TrashIcon, ShoppingBagIcon, PlusIcon, MinusIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import { GET_CART } from '@/graphql/queries';
import { REMOVE_FROM_CART, UPDATE_CART_ITEM, CLEAR_CART } from '@/graphql/mutations';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import toast from 'react-hot-toast';
import Image from 'next/image';

export default function CartDrawer({ isOpen, onClose }) {
  const { isAuthenticated } = useAuthStore();
  const { items: localItems, updateQuantity: updateLocal, removeItem: removeLocal, subtotal: localSubtotal, clearCart: clearLocal } = useCartStore();

  const { data, loading, refetch } = useQuery(GET_CART, { skip: !isAuthenticated, fetchPolicy: 'cache-and-network' });

  const [removeFromCart] = useMutation(REMOVE_FROM_CART, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });
  const [updateCartItem] = useMutation(UPDATE_CART_ITEM, {
    onCompleted: () => refetch(),
    onError: (e) => toast.error(e.message),
  });

  const cart = isAuthenticated ? data?.getCart : null;
  const items = isAuthenticated ? (cart?.items || []) : localItems;
  const subtotal = items.reduce((sum, item) => sum + (Number(item.price) * Number(item.quantity)), 0);
  const itemCount = items.reduce((s, i) => s + i.quantity, 0);

  const handleRemove = (item) => {
    if (isAuthenticated) removeFromCart({ variables: { itemId: item._id } });
    else removeLocal(item._id);
  };

  const handleUpdateQty = (item, qty) => {
    if (isAuthenticated) updateCartItem({ variables: { itemId: item._id, quantity: qty } });
    else updateLocal(item._id, qty);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50"
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 220 }}
            className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-white z-50 flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <ShoppingBagIcon className="w-5 h-5 text-brand-500" />
                <h2 className="text-lg font-bold text-gray-900">Shopping Cart</h2>
                {itemCount > 0 && (
                  <span className="bg-brand-100 text-brand-700 text-xs font-bold px-2 py-0.5 rounded-full">{itemCount}</span>
                )}
              </div>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100 transition-colors">
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto py-4 px-5">
              {loading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex gap-3 animate-pulse">
                      <div className="w-20 h-20 bg-gray-100 rounded-xl" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-100 rounded w-3/4" />
                        <div className="h-4 bg-gray-100 rounded w-1/2" />
                        <div className="h-6 bg-gray-100 rounded w-1/3" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 text-center py-12">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center">
                    <ShoppingBagIcon className="w-10 h-10 text-gray-300" />
                  </div>
                  <div>
                    <p className="text-gray-500 font-medium">Your cart is empty</p>
                    <p className="text-gray-400 text-sm mt-1">Start adding items to your cart!</p>
                  </div>
                  <Link href="/products" onClick={onClose} className="btn-brand text-sm">
                    Shop Now
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  <AnimatePresence>
                    {items.map((item) => (
                      <motion.div
                        key={item._id}
                        layout
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="flex gap-3 p-3 bg-gray-50 rounded-xl"
                      >
                        {/* Product Image */}
                        <div className="relative w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-gray-100">
                          <img
                            src={item.product?.images?.[0] || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200'}
                            alt={item.product?.name || item.name || ''}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200';
                            }}
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <Link
                            href={`/products/${item.product?.slug || '#'}`}
                            onClick={onClose}
                            className="text-sm font-medium text-gray-800 line-clamp-2 hover:text-brand-600 transition-colors"
                          >
                            {item.product?.name || item.name}
                          </Link>
                          <p className="text-sm font-bold text-brand-600 mt-1">${(item.price * item.quantity).toFixed(2)}</p>
                          <p className="text-xs text-gray-400">${item.price} each</p>

                          <div className="flex items-center justify-between mt-2">
                            {/* Quantity */}
                            <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                              <button
                                onClick={() => handleUpdateQty(item, item.quantity - 1)}
                                className="w-7 h-7 flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors"
                              >
                                <MinusIcon className="w-3 h-3" />
                              </button>
                              <span className="w-8 text-center text-sm font-medium text-gray-700">{item.quantity}</span>
                              <button
                                onClick={() => handleUpdateQty(item, item.quantity + 1)}
                                className="w-7 h-7 flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors"
                              >
                                <PlusIcon className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Remove */}
                            <button
                              onClick={() => handleRemove(item)}
                              className="text-gray-400 hover:text-red-500 transition-colors p-1"
                            >
                              <TrashIcon className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="border-t border-gray-100 p-5 space-y-4">
                {cart?.couponCode && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-green-600 font-medium">🎫 {cart.couponCode} applied</span>
                    <span className="text-green-600 font-semibold">-${cart.couponDiscount?.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>Subtotal ({itemCount} items)</span>
                  <span className="text-lg font-bold text-gray-900">${subtotal.toFixed(2)}</span>
                </div>
                <p className="text-xs text-gray-400">Shipping & taxes calculated at checkout</p>
                <Link
                  href="/checkout"
                  onClick={onClose}
                  className="w-full btn-brand flex items-center justify-center gap-2 text-center"
                >
                  Proceed to Checkout
                  <ArrowRightIcon className="w-4 h-4" />
                </Link>
                <Link
                  href="/cart"
                  onClick={onClose}
                  className="w-full btn-gray text-center block text-sm"
                >
                  View Cart
                </Link>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
