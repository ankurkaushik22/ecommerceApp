'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useMutation, useQuery, useApolloClient } from '@apollo/client';
import { motion, AnimatePresence } from 'framer-motion';
import {
  MagnifyingGlassIcon, ShoppingCartIcon, HeartIcon,
  UserIcon, BellIcon, Bars3Icon, XMarkIcon,
  ChevronDownIcon, MapPinIcon, BuildingStorefrontIcon
} from '@heroicons/react/24/outline';
import { ShoppingCartIcon as CartSolid } from '@heroicons/react/24/solid';
import toast from 'react-hot-toast';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';
import { GET_CATEGORIES, GET_UNREAD_COUNT, GET_CART, GET_ALL_CATEGORIES, GET_STORE_SETTINGS } from '@/graphql/queries';
import { LOGOUT } from '@/graphql/mutations';
import CartDrawer from './CartDrawer';
import clsx from 'clsx';
import { filterItemsByVertical } from '@/utils/cartHelpers';

const NAV_LINKS = [
  { label: 'Home', href: '/' },
  { label: '🛍️ Shopping', href: '/shop', highlight: true, vertical: 'shopping' },
  { label: '🍔 Food Delivery', href: '/food', highlight: true, vertical: 'food' },
  { label: '🥦 Grocery', href: '/grocery', highlight: true, vertical: 'grocery' },
  { label: '🛠️ Services', href: '/services', highlight: true, vertical: 'services' },
  { label: "Today's Deals", href: '/deals' },
  { label: 'All Products', href: '/products' },
  { label: 'Electronics', href: '/category/electronics' },
  { label: 'Fashion', href: '/category/clothing' },
];

export default function Header() {
  const [search, setSearch] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);
  const [deliveryLocation, setDeliveryLocation] = useState('Meerut 250001');
  const [detectingLocation, setDetectingLocation] = useState(false);
  const [locationInput, setLocationInput] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const router = useRouter();
  const pathname = usePathname();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { items: localItems, isOpen, openCart, closeCart } = useCartStore();
  const userMenuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const { data: settingsData } = useQuery(GET_STORE_SETTINGS);
  const storeSettings = settingsData?.getStoreSettings;

  useEffect(() => {
    if (storeSettings?.faviconUrl) {
      let link = document.querySelector("link[rel~='icon']");
      if (!link) {
        link = document.createElement('link');
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = storeSettings.faviconUrl;
    }
    if (storeSettings?.storeName) {
      document.title = `${storeSettings.storeName} - Everything You Need, Delivered Fast`;
    }
  }, [storeSettings?.faviconUrl, storeSettings?.storeName]);

  const PINCODE_MAP = {
    '250001': 'Meerut',
    '250002': 'Meerut',
    '250003': 'Meerut',
    '250004': 'Meerut',
    '250005': 'Meerut',
    '250106': 'Meerut',
    '201001': 'Ghaziabad',
    '201002': 'Ghaziabad',
    '201009': 'Ghaziabad',
    '201010': 'Ghaziabad',
    '201301': 'Noida',
    '201303': 'Noida',
    '201304': 'Noida',
    '110001': 'New Delhi',
    '110020': 'South Delhi',
    '110092': 'East Delhi',
    '122001': 'Gurugram',
    '400001': 'Mumbai',
    '560001': 'Bengaluru',
    '500001': 'Hyderabad',
  };

  const resolvePincodeOrCity = (input) => {
    const trimmed = input.trim();
    if (PINCODE_MAP[trimmed]) {
      return `${PINCODE_MAP[trimmed]} ${trimmed}`;
    }
    if (/^\d{6}$/.test(trimmed)) {
      return `India ${trimmed}`;
    }
    return trimmed;
  };

  const requestLocationPermission = (showToast = false) => {
    if (typeof window === 'undefined') return;

    if (!navigator?.geolocation) {
      if (showToast) toast.error('Geolocation is not supported by your browser');
      return;
    }

    setDetectingLocation(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          
          let city = '';
          let pincode = '';

          // 1. Primary: OpenStreetMap Nominatim
          try {
            const nomRes = await fetch(
              `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`,
              { headers: { 'Accept-Language': 'en', 'User-Agent': 'ShopZoneApp/1.0' } }
            );
            if (nomRes.ok) {
              const nomData = await nomRes.json();
              const addr = nomData.address || {};
              city =
                addr.city ||
                addr.town ||
                addr.suburb ||
                addr.city_district ||
                addr.state_district ||
                addr.county ||
                addr.village ||
                addr.neighbourhood ||
                '';
              pincode = addr.postcode || '';
            }
          } catch { /* try next */ }

          // 2. Secondary: BigDataCloud
          if (!city || !pincode) {
            try {
              const res = await fetch(
                `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${latitude}&longitude=${longitude}&localityLanguage=en`
              );
              if (res.ok) {
                const data = await res.json();
                city = city || data.city || data.locality || data.principalSubdivision || '';
                pincode = pincode || data.postcode || '';
              }
            } catch { /* ignore */ }
          }

          if (city) {
            const formatted = pincode ? `${city} ${pincode}` : city;
            saveLocation(formatted, showToast);
          } else {
            saveLocation('Meerut 250001', showToast);
          }
        } catch {
          saveLocation('Meerut 250001', showToast);
        } finally {
          setDetectingLocation(false);
        }
      },
      (error) => {
        setDetectingLocation(false);
        if (showToast) {
          if (error.code === error.PERMISSION_DENIED) {
            toast.error('Location permission was denied. You can enter your pincode manually.');
          } else {
            toast.error('Browser GPS unavailable on this device. Please select your city or pincode.');
          }
        }
        setDeliveryLocation((prev) => (prev === 'Detecting...' ? 'Meerut 250001' : prev));
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
    );
  };

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('deliveryLocation');
      if (
        saved &&
        !saved.toLowerCase().includes('mathura') &&
        saved !== 'Detecting...' &&
        saved !== 'United States'
      ) {
        setDeliveryLocation(saved);
      } else if (user?.addresses?.length > 0) {
        const def = user.addresses.find((a) => a.isDefault) || user.addresses[0];
        const loc = `${def.city} ${def.postalCode || ''}`.trim() || def.city || 'Meerut 250001';
        setDeliveryLocation(loc);
      }
    }
  }, [user]);

  const { data: cartData } = useQuery(GET_CART, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
  });

  const serverItems = cartData?.getCart?.items || [];
  const rawItems = isAuthenticated && serverItems.length > 0 ? serverItems : localItems;
  const filteredItems = filterItemsByVertical(rawItems, pathname);
  const itemCount = filteredItems.reduce((s, i) => s + (i.quantity || 1), 0);

  const { data: notifData } = useQuery(GET_UNREAD_COUNT, {
    skip: !isAuthenticated,
    fetchPolicy: 'cache-and-network',
    pollInterval: 15000,
  });
  const unreadCount = notifData?.getUnreadNotificationCount || 0;

  const client = useApolloClient();

  const [logoutMutation] = useMutation(LOGOUT, {
    onCompleted: () => { 
      logout(); 
      client.clearStore();
      toast.success('Logged out'); 
      router.push('/'); 
    },
  });

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (search.trim()) {
      router.push(`/search?q=${encodeURIComponent(search.trim())}`);
      setSearch('');
    }
  };

  return (
    <>
      {/* Main Header */}
      <header className={clsx(
        'sticky top-0 z-50 transition-shadow duration-300 w-full',
        scrolled ? 'shadow-lg' : ''
      )}>
        {/* Top Bar - Crisp White */}
        <div className="bg-white border-b border-gray-200 w-full">
          <div className="w-full max-w-full px-3 sm:px-6 h-16 flex items-center gap-2 sm:gap-4">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0 group">
              {storeSettings?.logoUrl ? (
                <img src={storeSettings.logoUrl} alt={storeSettings?.storeName || 'Suaaka'} className="h-8 sm:h-10 md:h-12 w-auto object-contain max-w-[110px] sm:max-w-[200px]" />
              ) : (
                <>
                  <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center group-hover:bg-brand-400 transition-colors flex-shrink-0">
                    <BuildingStorefrontIcon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-gray-900 font-bold text-lg sm:text-xl hidden sm:block">{storeSettings?.storeName || 'Suaaka'}</span>
                </>
              )}
            </Link>

            {/* Deliver to */}
            <button
              onClick={() => setLocationModalOpen(true)}
              className="hidden lg:flex items-center gap-1 text-gray-600 hover:text-brand-600 transition-colors flex-shrink-0 cursor-pointer text-left"
              title="Click to change delivery location"
            >
              <MapPinIcon className="w-5 h-5 text-gray-500" />
              <div className="text-left">
                <p className="text-xs text-gray-500 leading-none">Deliver to</p>
                <p className="text-xs font-bold text-gray-800 leading-none mt-1 max-w-[130px] truncate">
                  {deliveryLocation}
                </p>
              </div>
            </button>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="flex-1 min-w-0 flex">
              <div className="flex w-full max-w-2xl mx-auto rounded-lg overflow-hidden border border-gray-300 focus-within:border-brand-500 bg-gray-50 transition-colors">
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search products..."
                  className="flex-1 min-w-0 px-2.5 sm:px-4 py-2 text-xs sm:text-sm text-gray-900 bg-transparent outline-none"
                />
                <button
                  type="submit"
                  className="bg-brand-500 hover:bg-brand-600 px-3 sm:px-5 flex items-center justify-center transition-colors flex-shrink-0"
                >
                  <MagnifyingGlassIcon className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
                </button>
              </div>
            </form>

            {/* Right Icons */}
            <div className="flex items-center gap-0.5 sm:gap-1 flex-shrink-0">
              {/* Desktop Account */}
              <div
                ref={userMenuRef}
                className="relative hidden sm:block"
                onMouseEnter={() => setUserMenuOpen(true)}
                onMouseLeave={() => setUserMenuOpen(false)}
              >
                <button
                  type="button"
                  onClick={() => {
                    if (isAuthenticated) {
                      setUserMenuOpen((prev) => !prev);
                    } else {
                      router.push('/login');
                    }
                  }}
                  className="flex flex-col items-start px-3 py-1 text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer select-none"
                >
                  <span className="text-xs">{isAuthenticated ? `Hi, ${user?.name?.split(' ')[0]}` : 'Hello, sign in'}</span>
                  <span className="text-xs font-bold flex items-center gap-0.5">
                    Account & Lists <ChevronDownIcon className="w-3 h-3" />
                  </span>
                </button>

                <AnimatePresence>
                  {userMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 top-full pt-1 w-60 z-50"
                    >
                      <div className="bg-white rounded-xl shadow-2xl border border-gray-100 py-2 overflow-hidden">
                        {isAuthenticated ? (
                          <>
                            <div className="px-4 py-3 bg-gray-50/70 border-b border-gray-100">
                              <p className="text-xs text-gray-500 font-medium">Signed in as</p>
                              <p className="text-sm font-bold text-gray-900 truncate">{user?.name}</p>
                              <p className="text-xs text-gray-400 truncate">{user?.email || user?.phone}</p>
                            </div>
                            {[
                              { label: 'My Account', href: '/account' },
                              { label: 'Your Orders', href: '/orders' },
                              { label: 'Your Wishlist', href: '/account/wishlist' },
                              { label: 'Saved Addresses', href: '/account/addresses' },
                              { label: 'Notifications', href: '/account/notifications' },
                            ].map((item) => (
                              <Link
                                key={item.href}
                                href={item.href}
                                onClick={() => setUserMenuOpen(false)}
                                className="block px-4 py-2 text-sm text-gray-700 hover:bg-brand-50 hover:text-brand-600 font-medium transition-colors"
                              >
                                {item.label}
                              </Link>
                            ))}
                            <div className="border-t border-gray-100 mt-1 pt-1">
                              <button
                                onClick={() => { logoutMutation(); setUserMenuOpen(false); }}
                                className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-semibold transition-colors cursor-pointer"
                              >
                                Sign Out
                              </button>
                            </div>
                          </>
                        ) : (
                          <div className="p-4 text-center space-y-2.5">
                            <Link
                              href="/login"
                              onClick={() => setUserMenuOpen(false)}
                              className="block w-full py-2 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-lg shadow-xs transition-colors"
                            >
                              Sign In
                            </Link>
                            <p className="text-xs text-gray-500">
                              New customer?{' '}
                              <Link
                                href="/login"
                                onClick={() => setUserMenuOpen(false)}
                                className="text-brand-600 hover:underline font-semibold"
                              >
                                Start here.
                              </Link>
                            </p>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Orders */}
              <Link href="/orders" className="hidden md:flex flex-col items-start px-3 py-1 text-gray-600 hover:text-brand-600 hover:bg-gray-50 rounded-lg transition-colors">
                <span className="text-xs">Returns</span>
                <span className="text-xs font-bold">& Orders</span>
              </Link>

              {/* Notifications */}
              {isAuthenticated && (
                <Link href="/account/notifications" className="relative px-2 py-2 text-gray-600 hover:text-brand-600 transition-colors">
                  <BellIcon className="w-6 h-6" />
                  {unreadCount > 0 && (
                     <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </Link>
              )}

              {/* Mobile Account Icon */}
              <Link
                href={isAuthenticated ? "/account" : "/login"}
                className="sm:hidden p-1.5 text-gray-600 hover:text-brand-600 flex items-center justify-center"
              >
                <UserIcon className="w-5 h-5 sm:w-6 sm:h-6" />
              </Link>

              {/* Cart */}
              <button
                onClick={openCart}
                className="relative flex items-end gap-1 p-1.5 sm:px-2 sm:py-2 text-gray-600 hover:text-brand-600 transition-colors"
              >
                <div className="relative">
                  <ShoppingCartIcon className="w-6 h-6 sm:w-7 sm:h-7" />
                  <AnimatePresence>
                    {itemCount > 0 && (
                      <motion.span
                        key={itemCount}
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0 }}
                        className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-brand-500 text-white text-[10px] sm:text-xs font-bold rounded-full flex items-center justify-center"
                      >
                        {itemCount > 99 ? '99+' : itemCount}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </div>
                <span className="hidden sm:block text-xs font-bold pb-1">Cart</span>
              </button>

              {/* Mobile Menu */}
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="md:hidden text-gray-600 hover:text-brand-600 p-1.5 flex items-center justify-center"
              >
                <Bars3Icon className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Nav Bar */}
        <div className="bg-gray-50 hidden md:block border-b border-gray-200">
          <div className="w-full mx-auto px-4 sm:px-6">
            <div className="flex items-center gap-1 h-10 overflow-x-auto scrollbar-none">
              {NAV_LINKS.filter(
                (l) => !l.vertical || !storeSettings?.disabledVerticals?.includes(l.vertical)
              ).map((link) => {
                const isActive =
                  link.href === '/'
                    ? pathname === '/'
                    : pathname === link.href || pathname?.startsWith(link.href + '/');

                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={clsx(
                      'px-3.5 py-1.5 text-xs font-semibold whitespace-nowrap rounded-md transition-all flex-shrink-0 relative',
                      isActive
                        ? 'bg-brand-100 text-brand-700 font-bold'
                        : link.highlight
                        ? 'text-brand-600 hover:text-brand-700 hover:bg-brand-50'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    )}
                  >
                    {link.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-50 md:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-72 bg-white z-50 shadow-2xl overflow-y-auto"
            >
              <div className="bg-navy-800 px-4 py-4 flex items-center justify-between">
                <span className="text-white font-bold text-lg">{storeSettings?.storeName || 'Suaaka'}</span>
                <button onClick={() => setMobileMenuOpen(false)} className="text-gray-300 hover:text-white">
                  <XMarkIcon className="w-6 h-6" />
                </button>
              </div>
              {isAuthenticated && (
                <div className="bg-brand-50 px-4 py-3 border-b border-brand-100">
                  <p className="text-sm font-semibold text-brand-800">Hello, {user?.name}</p>
                </div>
              )}
              <nav className="p-4 space-y-1">
                {NAV_LINKS.filter(
                  (l) => !l.vertical || !storeSettings?.disabledVerticals?.includes(l.vertical)
                ).map((link) => {
                  const isActive =
                    link.href === '/'
                      ? pathname === '/'
                      : pathname === link.href || pathname?.startsWith(link.href + '/');

                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className={clsx(
                        'block px-3 py-2.5 text-sm rounded-lg transition-colors font-medium',
                        isActive
                          ? 'bg-brand-50 text-brand-700 font-bold border-l-4 border-brand-500'
                          : 'text-gray-700 hover:bg-gray-50'
                      )}
                    >
                      {link.label}
                    </Link>
                  );
                })}
                <hr className="my-3" />
                {isAuthenticated ? (
                  <>
                    <Link href="/account" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2.5 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">My Account</Link>
                    <Link href="/orders" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2.5 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Orders</Link>
                    <button onClick={() => { logoutMutation(); setMobileMenuOpen(false); }} className="w-full text-left px-3 py-2.5 text-sm text-red-600 hover:bg-red-50 rounded-lg">Sign Out</button>
                  </>
                ) : (
                  <>
                    <Link href="/login" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2.5 text-sm font-medium text-brand-600 hover:bg-brand-50 rounded-lg">Sign In</Link>
                    <Link href="/register" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2.5 text-sm text-gray-700 hover:bg-gray-50 rounded-lg">Create Account</Link>
                  </>
                )}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Location Modal */}
      <AnimatePresence>
        {locationModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 text-gray-900"
            >
              <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                <h3 className="font-bold text-base text-gray-900 flex items-center gap-2">
                  <MapPinIcon className="w-5 h-5 text-brand-500" />
                  <span>Choose your location</span>
                </h3>
                <button onClick={() => setLocationModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <XMarkIcon className="w-5 h-5" />
                </button>
              </div>

              <p className="text-xs text-gray-500">
                Delivery options and speeds may vary based on your selected delivery address or pincode.
              </p>

              {/* Auto-detect button */}
              <button
                onClick={() => requestLocationPermission(true)}
                disabled={detectingLocation}
                className="w-full flex items-center justify-center gap-2 p-3 bg-brand-50 hover:bg-brand-100/80 border border-brand-200 rounded-2xl text-xs font-bold text-brand-700 transition-colors"
              >
                <MapPinIcon className="w-4 h-4 text-brand-600 animate-pulse" />
                <span>{detectingLocation ? 'Detecting your location...' : 'Use My Current Location (GPS)'}</span>
              </button>

              {/* Saved Addresses if logged in */}
              {user?.addresses?.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-bold uppercase text-gray-400">Saved Addresses:</p>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {user.addresses.map((addr) => (
                      <button
                        key={addr._id}
                        onClick={() => saveLocation(`${addr.city}, ${addr.postalCode || addr.country}`)}
                        className="w-full text-left p-2.5 rounded-xl border border-gray-100 hover:border-brand-300 hover:bg-brand-50/50 text-xs transition-colors"
                      >
                        <span className="font-bold text-gray-900">{addr.fullName} ({addr.label})</span>
                        <p className="text-gray-500 truncate">{addr.addressLine1}, {addr.city} {addr.postalCode}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick Popular Cities */}
              <div className="space-y-1.5 pt-1">
                <p className="text-[11px] font-bold text-gray-400 uppercase">Popular Delivery Locations:</p>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { label: '📍 Meerut', val: 'Meerut 250001' },
                    { label: '📍 Noida', val: 'Noida 201301' },
                    { label: '📍 Delhi', val: 'New Delhi 110001' },
                    { label: '📍 Ghaziabad', val: 'Ghaziabad 201009' },
                    { label: '📍 Gurugram', val: 'Gurugram 122001' },
                  ].map((city) => (
                    <button
                      key={city.val}
                      onClick={() => saveLocation(city.val)}
                      className="px-2.5 py-1 bg-gray-100 hover:bg-brand-50 hover:text-brand-700 hover:border-brand-300 border border-gray-200 rounded-lg text-xs font-semibold text-gray-700 transition-colors"
                    >
                      {city.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Enter Pincode / City */}
              <div className="space-y-2 pt-2 border-t border-gray-100">
                <label className="text-xs font-semibold text-gray-700 block">
                  Or enter your 6-digit Pincode / City:
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. 250001 or Meerut"
                    value={locationInput}
                    onChange={(e) => setLocationInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && locationInput.trim()) {
                        saveLocation(resolvePincodeOrCity(locationInput));
                        setLocationInput('');
                      }
                    }}
                    className="input-field text-xs flex-1"
                  />
                  <button
                    onClick={() => {
                      if (locationInput.trim()) {
                        saveLocation(resolvePincodeOrCity(locationInput));
                        setLocationInput('');
                      }
                    }}
                    className="btn-brand text-xs px-4 py-2"
                  >
                    Apply
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Cart Drawer */}
      <CartDrawer isOpen={isOpen} onClose={closeCart} />
    </>
  );
}
