'use client';
import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';
import { useCartStore } from '@/store/cartStore';

export default function AuthRestorer() {
  const restoreAuth = useAuthStore((s) => s.restoreAuth);
  const restoreCart = useCartStore((s) => s.restoreCart);
  useEffect(() => {
    restoreAuth();
    restoreCart();
  }, [restoreAuth, restoreCart]);
  return null;
}
