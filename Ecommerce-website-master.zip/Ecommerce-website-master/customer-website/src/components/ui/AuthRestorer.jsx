'use client';
import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';

export default function AuthRestorer() {
  const restoreAuth = useAuthStore((s) => s.restoreAuth);
  useEffect(() => { restoreAuth(); }, [restoreAuth]);
  return null;
}
