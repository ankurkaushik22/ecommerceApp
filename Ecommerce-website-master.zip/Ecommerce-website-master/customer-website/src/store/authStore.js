'use client';
import { create } from 'zustand';

export const useAuthStore = create((set, get) => ({
  user: null,
  token: null,
  isAuthenticated: false,

  login: (user, token, refreshToken) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('shopToken', token);
      localStorage.setItem('shopRefreshToken', refreshToken);
      localStorage.setItem('shopUser', JSON.stringify(user));
    }
    set({ user, token, isAuthenticated: true });
  },

  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('shopToken');
      localStorage.removeItem('shopRefreshToken');
      localStorage.removeItem('shopUser');
    }
    set({ user: null, token: null, isAuthenticated: false });
  },

  updateUser: (user) => {
    if (typeof window !== 'undefined') localStorage.setItem('shopUser', JSON.stringify(user));
    set({ user });
  },

  restoreAuth: () => {
    if (typeof window === 'undefined') return;
    const token = localStorage.getItem('shopToken');
    const userStr = localStorage.getItem('shopUser');
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        set({ user, token, isAuthenticated: true });
      } catch { /* ignore */ }
    }
  },
}));
