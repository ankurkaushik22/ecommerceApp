'use client';
import { create } from 'zustand';

export const useAuthStore = create((set, get) => ({
  user: null,
  token: null,
  isAuthenticated: false,

  login: (user, token, refreshToken) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('shopToken', token);
      localStorage.setItem('shopRefreshToken', refreshToken);
      localStorage.setItem('shopUser', JSON.stringify(user));
    }
    set({ user, token, isAuthenticated: true });
  },

  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('shopToken');
      localStorage.removeItem('shopRefreshToken');
      localStorage.removeItem('shopUser');
    }
    set({ user: null, token: null, isAuthenticated: false });
  },

  updateUser: (user) => {
    if (typeof window !== 'undefined') localStorage.setItem('shopUser', JSON.stringify(user));
    set({ user });
  },

  restoreAuth: () => {
    if (typeof window === 'undefined') return;
    const token = localStorage.getItem('shopToken');
    const userStr = localStorage.getItem('shopUser');
    if (token && userStr) {
      try {
        // Proactively check if token is expired
        const parts = token.split('.');
        if (parts.length === 3) {
          // Decode payload safely
          const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
          const payload = JSON.parse(atob(base64));
          if (payload.exp && payload.exp * 1000 < Date.now()) {
            // Token expired -> automatically clear session and log out
            localStorage.removeItem('shopToken');
            localStorage.removeItem('shopRefreshToken');
            localStorage.removeItem('shopUser');
            set({ user: null, token: null, isAuthenticated: false });
            return;
          }
        }
        const user = JSON.parse(userStr);
        set({ user, token, isAuthenticated: true });
      } catch {
        localStorage.removeItem('shopToken');
        localStorage.removeItem('shopRefreshToken');
        localStorage.removeItem('shopUser');
        set({ user: null, token: null, isAuthenticated: false });
      }
    } else {
      set({ user: null, token: null, isAuthenticated: false });
    }
  },
}));
