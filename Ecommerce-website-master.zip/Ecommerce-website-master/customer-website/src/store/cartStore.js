'use client';
import { create } from 'zustand';

const getInitialGuestItems = () => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('shopGuestCart');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

const saveGuestItems = (items) => {
  if (typeof window !== 'undefined') {
    try {
      if (!items || items.length === 0) {
        localStorage.removeItem('shopGuestCart');
      } else {
        localStorage.setItem('shopGuestCart', JSON.stringify(items));
      }
    } catch {
      // ignore
    }
  }
};

export const useCartStore = create((set, get) => ({
  items: getInitialGuestItems(),
  isOpen: false,

  get itemCount() {
    return get().items.reduce((sum, item) => sum + (Number(item.quantity) || 1), 0);
  },

  get subtotal() {
    return get().items.reduce((sum, item) => sum + (Number(item.price) || 0) * (Number(item.quantity) || 1), 0);
  },

  setCart: (cart) => {
    if (!cart) return;
    const items = cart.items || [];
    set({ items });
  },

  openCart: () => set({ isOpen: true }),
  closeCart: () => set({ isOpen: false }),

  addItem: (product, quantity = 1, variantIndex = -1) => {
    const { items } = get();
    const price = variantIndex >= 0
      ? product.variants?.[0]?.options?.[variantIndex]?.price ?? product.price
      : product.price;

    const existingIdx = items.findIndex(
      (i) => (i.product?._id || i.product) === product._id && i.variantIndex === variantIndex
    );

    let updated;
    if (existingIdx > -1) {
      updated = [...items];
      updated[existingIdx] = { ...updated[existingIdx], quantity: updated[existingIdx].quantity + quantity };
    } else {
      updated = [...items, { _id: `local-${Date.now()}`, product, variantIndex, quantity, price, total: price * quantity }];
    }
    saveGuestItems(updated);
    set({ items: updated, isOpen: true });
  },

  removeItem: (itemId) => {
    const updated = get().items.filter((i) => i._id !== itemId);
    saveGuestItems(updated);
    set({ items: updated });
  },

  updateQuantity: (itemId, quantity) => {
    if (quantity < 1) { get().removeItem(itemId); return; }
    const updated = get().items.map((i) => i._id === itemId ? { ...i, quantity, total: i.price * quantity } : i);
    saveGuestItems(updated);
    set({ items: updated });
  },

  clearCart: () => {
    saveGuestItems([]);
    set({ items: [] });
  },
}));
