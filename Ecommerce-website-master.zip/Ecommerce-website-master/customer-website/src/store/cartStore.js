'use client';
import { create } from 'zustand';

export const useCartStore = create((set, get) => ({
  items: [],
  isOpen: false,

  get itemCount() {
    return get().items.reduce((sum, item) => sum + item.quantity, 0);
  },

  get subtotal() {
    return get().items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  },

  setCart: (cart) => {
    if (!cart) return;
    set({ items: cart.items || [] });
  },

  openCart: () => set({ isOpen: true }),
  closeCart: () => set({ isOpen: false }),

  addItem: (product, quantity = 1, variantIndex = -1) => {
    const { items } = get();
    const price = variantIndex >= 0
      ? product.variants?.[0]?.options?.[variantIndex]?.price ?? product.price
      : product.price;

    const existingIdx = items.findIndex(
      (i) => i.product._id === product._id && i.variantIndex === variantIndex
    );

    if (existingIdx > -1) {
      const updated = [...items];
      updated[existingIdx] = { ...updated[existingIdx], quantity: updated[existingIdx].quantity + quantity };
      set({ items: updated });
    } else {
      set({ items: [...items, { _id: `local-${Date.now()}`, product, variantIndex, quantity, price, total: price * quantity }] });
    }
    set({ isOpen: true });
  },

  removeItem: (itemId) => {
    set({ items: get().items.filter((i) => i._id !== itemId) });
  },

  updateQuantity: (itemId, quantity) => {
    if (quantity < 1) { get().removeItem(itemId); return; }
    set({ items: get().items.map((i) => i._id === itemId ? { ...i, quantity, total: i.price * quantity } : i) });
  },

  clearCart: () => set({ items: [] }),
}));
