import { gql } from '@apollo/client';

export const REGISTER = gql`
  mutation Register($input: RegisterInput!) {
    register(input: $input) {
      token refreshToken
      user { _id name email role avatar }
    }
  }
`;

export const LOGIN = gql`
  mutation Login($input: LoginInput!) {
    login(input: $input) {
      token refreshToken
      user { _id name email role avatar }
    }
  }
`;

export const LOGOUT = gql`mutation Logout { logout }`;

export const UPDATE_PROFILE = gql`
  mutation UpdateProfile($name: String, $phone: String, $avatar: String) {
    updateProfile(name: $name, phone: $phone, avatar: $avatar) {
      _id name email phone avatar
    }
  }
`;

export const CHANGE_PASSWORD = gql`
  mutation ChangePassword($currentPassword: String!, $newPassword: String!) {
    changePassword(currentPassword: $currentPassword, newPassword: $newPassword)
  }
`;

export const ADD_ADDRESS = gql`
  mutation AddAddress($input: AddressInput!) {
    addAddress(input: $input) {
      _id addresses { _id label fullName phone addressLine1 addressLine2 city state postalCode country isDefault }
    }
  }
`;

export const UPDATE_ADDRESS = gql`
  mutation UpdateAddress($addressId: ID!, $input: AddressInput!) {
    updateAddress(addressId: $addressId, input: $input) {
      _id addresses { _id label fullName phone addressLine1 addressLine2 city state postalCode country isDefault }
    }
  }
`;

export const DELETE_ADDRESS = gql`
  mutation DeleteAddress($addressId: ID!) {
    deleteAddress(addressId: $addressId) {
      _id addresses { _id label fullName city state isDefault }
    }
  }
`;

export const TOGGLE_WISHLIST = gql`
  mutation ToggleWishlist($productId: ID!) {
    toggleWishlist(productId: $productId) {
      _id wishlist { _id name slug images price rating { average } }
    }
  }
`;

export const ADD_TO_CART = gql`
  mutation AddToCart($input: CartItemInput!) {
    addToCart(input: $input) {
      _id subtotal itemCount
      items { _id variantIndex quantity price total product { _id name images price } }
    }
  }
`;

export const SYNC_CART = gql`
  mutation SyncCart($items: [CartItemInput!]!) {
    syncCart(items: $items) {
      _id subtotal itemCount
      items { _id variantIndex quantity price total product { _id name images price } }
    }
  }
`;

export const UPDATE_CART_ITEM = gql`
  mutation UpdateCartItem($itemId: ID!, $quantity: Int!) {
    updateCartItem(itemId: $itemId, quantity: $quantity) {
      _id subtotal itemCount
      items { _id quantity price total product { _id name images } }
    }
  }
`;

export const REMOVE_FROM_CART = gql`
  mutation RemoveFromCart($itemId: ID!) {
    removeFromCart(itemId: $itemId) {
      _id subtotal itemCount
      items { _id quantity price total product { _id name images } }
    }
  }
`;

export const CLEAR_CART = gql`mutation ClearCart { clearCart }`;

export const APPLY_COUPON = gql`
  mutation ApplyCoupon($code: String!) {
    applyCoupon(code: $code) {
      _id couponCode couponDiscount subtotal itemCount
      items { _id quantity price total }
    }
  }
`;

export const REMOVE_COUPON = gql`
  mutation RemoveCoupon {
    removeCoupon { _id couponCode couponDiscount subtotal }
  }
`;

export const PLACE_ORDER = gql`
  mutation PlaceOrder($input: PlaceOrderInput!, $address: OrderAddressInput) {
    placeOrder(input: $input, address: $address) {
      _id orderNumber total status paymentMethod
      createdAt estimatedDelivery
    }
  }
`;

export const CANCEL_ORDER = gql`
  mutation CancelOrder($orderId: ID!, $reason: String!) {
    cancelOrder(orderId: $orderId, reason: $reason) {
      _id status cancelReason
    }
  }
`;

export const REQUEST_RETURN = gql`
  mutation RequestReturn($orderId: ID!, $reason: String!) {
    requestReturn(orderId: $orderId, reason: $reason) {
      _id returnStatus returnReason returnDate
    }
  }
`;

export const CREATE_PAYMENT_INTENT = gql`
  mutation CreatePaymentIntent($orderId: ID!) {
    createPaymentIntent(orderId: $orderId) {
      clientSecret paymentIntentId amount
    }
  }
`;

export const CONFIRM_PAYMENT = gql`
  mutation ConfirmPayment($orderId: ID!, $paymentIntentId: String!) {
    confirmPayment(orderId: $orderId, paymentIntentId: $paymentIntentId) {
      _id orderNumber status paymentStatus total
    }
  }
`;

export const ADD_REVIEW = gql`
  mutation AddReview($input: ReviewInput!) {
    addReview(input: $input) {
      _id rating title comment verified createdAt
      user { name avatar }
    }
  }
`;

export const MARK_HELPFUL = gql`
  mutation MarkHelpful($reviewId: ID!) {
    markReviewHelpful(reviewId: $reviewId) {
      _id helpfulCount
    }
  }
`;

export const MARK_NOTIFICATION_READ = gql`
  mutation MarkNotificationRead($id: ID!) {
    markNotificationRead(id: $id) { _id isRead }
  }
`;

export const MARK_ALL_READ = gql`mutation MarkAllRead { markAllNotificationsRead }`;

export const FORGOT_PASSWORD = gql`
  mutation ForgotPassword($email: String!) {
    forgotPassword(email: $email) {
      success
      message
      resetToken
    }
  }
`;

export const VERIFY_RESET_OTP = gql`
  mutation VerifyResetOTP($email: String!, $otp: String!) {
    verifyResetOTP(email: $email, otp: $otp) {
      success
      message
      resetToken
    }
  }
`;

export const RESET_PASSWORD = gql`
  mutation ResetPassword($token: String!, $newPassword: String!) {
    resetPassword(token: $token, newPassword: $newPassword) {
      token
      refreshToken
      user { _id name email role avatar }
    }
  }
`;

export const SEND_LOGIN_OTP = gql`
  mutation SendLoginOTP($email: String!) {
    sendLoginOTP(email: $email) {
      success
      message
    }
  }
`;

export const LOGIN_WITH_OTP = gql`
  mutation LoginWithOTP($email: String!, $otp: String!) {
    loginWithOTP(email: $email, otp: $otp) {
      token
      refreshToken
      user { _id name email role avatar }
    }
  }
`;

