import { gql } from '@apollo/client';

export const GET_STORE_SETTINGS = gql`
  query GetStoreSettings {
    getStoreSettings {
      _id
      storeName
      logoUrl
      faviconUrl
      appIconUrl
      disabledVerticals
      serviceBookingMode
      serviceContactPhone
    }
  }
`;

export const GET_FEATURED_PRODUCTS = gql`
  query GetFeaturedProducts($limit: Int) {
    getFeaturedProducts(limit: $limit) {
      _id name slug price comparePrice discount images
      freeShipping isFeatured stock
      category { _id name slug }
      rating { average count }
    }
  }
`;

export const CHECK_USER_EXISTS = gql`
  query CheckUserExists($identifier: String!) { 
    checkUserExists(identifier: $identifier) 
  }
`;

export const GET_DEALS_PRODUCTS = gql`
  query GetDealsProducts($limit: Int) {
    getDealsProducts(limit: $limit) {
      _id name slug price comparePrice discount images
      freeShipping isDeals stock
      category { _id name slug }
      rating { average count }
    }
  }
`;

export const GET_PRODUCTS = gql`
  query GetProducts($filter: ProductFilterInput, $sort: ProductSortInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, sort: $sort, pagination: $pagination) {
      products {
        _id name slug price comparePrice discount images stock
        freeShipping isFeatured isDeals
        category { _id name slug parent { _id name slug } }
        subcategory { _id name slug }
        vendor { _id name email avatar }
        rating { average count }
        isVeg cuisine preparationTime restaurantName vertical
      }
      total page pages hasNext
    }
  }
`;

export const GET_PRODUCT = gql`
  query GetProduct($slug: String!) {
    getProduct(slug: $slug) {
      _id name slug description shortDescription
      price comparePrice discount images stock sku
      freeShipping shippingCost tags specifications { key value } highlights
      variants { name options { label price stock sku thumbnail thumbnails } }
      category { _id name slug }
      subcategory { _id name slug }
      vendor { _id name email avatar }
      rating {
        average count
        distribution { star count percentage }
      }
      reviewsCount
      isActive
    }
  }
`;

export const GET_RELATED_PRODUCTS = gql`
  query GetRelatedProducts($productId: ID!, $limit: Int) {
    getRelatedProducts(productId: $productId, limit: $limit) {
      _id name slug price comparePrice discount images
      rating { average count }
      category { _id name slug }
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories($parentId: ID, $vertical: String) {
    getCategories(parentId: $parentId, vertical: $vertical) {
      _id name slug icon image vertical
      children { _id name slug }
    }
  }
`;

export const GET_ALL_CATEGORIES = gql`
  query GetAllCategoriesShop {
    getAllCategories {
      _id name slug icon image vertical
      parent { _id name }
      children { _id name slug }
    }
  }
`;

export const GET_CART = gql`
  query GetCart {
    getCart {
      _id user subtotal itemCount couponCode couponDiscount discount
      items {
        _id variantIndex quantity price total image variantLabel
        product {
          _id name slug images price stock freeShipping disableCOD vertical isVeg restaurantName cuisine unitMeasure
          variants { name options { label price stock sku thumbnail thumbnails } }
          category { _id name vertical }
        }
      }
    }
  }
`;

export const GET_ORDERS = gql`
  query GetOrders($status: String, $pagination: PaginationInput) {
    getOrders(status: $status, pagination: $pagination) {
      orders {
        _id orderNumber status paymentMethod paymentStatus
        total subtotal discount shippingCost createdAt estimatedDelivery
        items { name image price quantity }
        shippingAddress { fullName city state }
      }
      total page pages
    }
  }
`;

export const GET_ORDER = gql`
  query GetOrder($id: ID!) {
    getOrder(id: $id) {
      _id
      orderNumber
      invoiceNumber
      invoiceDate
      status
      paymentMethod
      paymentStatus
      subtotal
      discount
      shippingCost
      tax
      total
      createdAt
      estimatedDelivery
      returnStatus
      returnReason
      returnDate
      deliveredAt
      couponCode
      customer {
        _id
        name
        email
        phone
      }
      vendor {
        _id
        name
      }
      deliveryAgent {
        _id
        name
        phone
      }
      deliveryBoy {
        _id
        name
        phone
      }
      deliveryOption {
        name
        estimatedDays
        price
      }
      taxDetails {
        rate
        cgst
        sgst
        igst
        taxAmount
      }
      items {
        product {
          _id
          name
          slug
          images
        }
        name
        image
        price
        quantity
        variantLabel
        total
      }
      shippingAddress {
        fullName
        phone
        addressLine1
        addressLine2
        city
        state
        postalCode
        country
      }
      liveLocation {
        latitude
        longitude
        heading
        speed
        updatedAt
      }
      destinationLocation {
        latitude
        longitude
        address
      }
      trackingUpdates {
        status
        message
        timestamp
        location
      }
    }
  }
`;

export const GET_ME = gql`
  query GetMe {
    me {
      _id name email role avatar phone isVerified
      addresses { _id label fullName phone addressLine1 addressLine2 city state postalCode country isDefault }
      wishlist { _id name slug images price rating { average } }
    }
  }
`;

export const GET_PRODUCT_REVIEWS = gql`
  query GetProductReviews($productId: ID!, $pagination: PaginationInput) {
    getProductReviews(productId: $productId, pagination: $pagination) {
      _id rating title comment images helpfulCount verified createdAt
      user { _id name avatar }
      reply { comment repliedAt repliedBy { name } }
    }
  }
`;

export const SEARCH_PRODUCTS = gql`
  query SearchProducts($query: String!, $pagination: PaginationInput) {
    searchProducts(query: $query, pagination: $pagination) {
      products {
        _id name slug price comparePrice discount images stock
        category { _id name slug }
        rating { average count }
      }
      total page pages hasNext
    }
  }
`;

export const GET_NOTIFICATIONS = gql`
  query GetNotifications {
    getNotifications {
      _id title message type data isRead createdAt
    }
  }
`;

export const GET_UNREAD_COUNT = gql`
  query GetUnreadCount {
    getUnreadNotificationCount
  }
`;

export const VALIDATE_COUPON = gql`
  query ValidateCoupon($code: String!, $orderAmount: Float!) {
    validateCoupon(code: $code, orderAmount: $orderAmount) {
      valid discount message
      coupon { _id code type value }
    }
  }
`;

export const GET_DELIVERY_OPTIONS = gql`
  query GetDeliveryOptions($activeOnly: Boolean) {
    getDeliveryOptions(activeOnly: $activeOnly) {
      _id name description estimatedDays price minOrderForFree isDefault isActive sortOrder
    }
  }
`;

export const GET_TAX_SETTINGS = gql`
  query GetTaxSettings($activeOnly: Boolean) {
    getTaxSettings(activeOnly: $activeOnly) {
      _id name rate cgst sgst igst hsnCode isDefault isActive description
    }
  }
`;

export const GET_ORDER_INVOICE = gql`
  query GetOrderInvoice($orderId: ID!) {
    getOrderInvoice(orderId: $orderId) {
      invoiceNumber
      invoiceDate
      order {
        _id orderNumber createdAt paymentMethod paymentStatus subtotal discount shippingCost tax total
        shippingAddress { fullName phone addressLine1 addressLine2 city state postalCode country }
        customer { name email phone }
        items { name price quantity variantLabel total }
        taxDetails { rate taxAmount cgst sgst igst hsnCode }
        deliveryOption { name estimatedDays price }
      }
      companyDetails
    }
  }
`;

export const GET_BANNERS = gql`
  query GetBanners($platform: String) {
    getBanners(platform: $platform) {
      _id title subtitle tag image link discount platform bgGradient bgHex buttonColor accentColor isActive order createdAt
    }
  }
`;
