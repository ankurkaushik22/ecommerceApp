import { gql } from '@apollo/client';

export const GET_FEATURED_PRODUCTS = gql`
  query GetFeaturedProducts($limit: Int) {
    getFeaturedProducts(limit: $limit) {
      _id name slug price comparePrice discount images
      freeShipping isFeatured stock
      category { _id name slug }
      rating { average count }
    }
  }
`;

export const GET_DEALS_PRODUCTS = gql`
  query GetDealsProducts($limit: Int) {
    getDealsProducts(limit: $limit) {
      _id name slug price comparePrice discount images
      freeShipping isDeals stock
      category { _id name slug }
      rating { average count }
    }
  }
`;

export const GET_PRODUCTS = gql`
  query GetProducts($filter: ProductFilterInput, $sort: ProductSortInput, $pagination: PaginationInput) {
    getProducts(filter: $filter, sort: $sort, pagination: $pagination) {
      products {
        _id name slug price comparePrice discount images stock
        freeShipping isFeatured isDeals
        category { _id name slug }
        rating { average count }
      }
      total page pages hasNext
    }
  }
`;

export const GET_PRODUCT = gql`
  query GetProduct($slug: String!) {
    getProduct(slug: $slug) {
      _id name slug description shortDescription
      price comparePrice discount images stock sku
      freeShipping shippingCost tags
      specifications { key value }
      variants { name options { label price stock sku } }
      category { _id name slug }
      subcategory { _id name slug }
      vendor { name avatar }
      rating {
        average count
        distribution { star count percentage }
      }
      reviewsCount
      isActive
    }
  }
`;

export const GET_RELATED_PRODUCTS = gql`
  query GetRelatedProducts($productId: ID!, $limit: Int) {
    getRelatedProducts(productId: $productId, limit: $limit) {
      _id name slug price comparePrice discount images
      rating { average count }
      category { _id name slug }
    }
  }
`;

export const GET_CATEGORIES = gql`
  query GetCategories {
    getCategories {
      _id name slug icon image
      children { _id name slug }
    }
  }
`;

export const GET_ALL_CATEGORIES = gql`
  query GetAllCategoriesShop {
    getAllCategories {
      _id name slug icon image
      parent { _id name }
      children { _id name slug }
    }
  }
`;

export const GET_CART = gql`
  query GetCart {
    getCart {
      _id user subtotal itemCount couponCode couponDiscount discount
      items {
        _id variantIndex quantity price total
        product {
          _id name slug images price stock freeShipping
          category { _id name }
        }
      }
    }
  }
`;

export const GET_ORDERS = gql`
  query GetOrders($status: String, $pagination: PaginationInput) {
    getOrders(status: $status, pagination: $pagination) {
      orders {
        _id orderNumber status paymentMethod paymentStatus
        total subtotal discount shippingCost createdAt estimatedDelivery
        items { name image price quantity }
        shippingAddress { fullName city state }
      }
      total page pages
    }
  }
`;

export const GET_ORDER = gql`
  query GetOrder($id: ID!) {
    getOrder(id: $id) {
      _id orderNumber status paymentMethod paymentStatus
      subtotal discount shippingCost tax total
      createdAt estimatedDelivery deliveredAt couponCode
      items { product { _id name slug } name image price quantity variantLabel total }
      shippingAddress { fullName phone addressLine1 addressLine2 city state postalCode country }
      deliveryBoy { name phone }
      trackingUpdates { status message timestamp location }
    }
  }
`;

export const GET_ME = gql`
  query GetMe {
    me {
      _id name email role avatar phone isVerified
      addresses { _id label fullName phone addressLine1 addressLine2 city state postalCode country isDefault }
      wishlist { _id name slug images price rating { average } }
    }
  }
`;

export const GET_PRODUCT_REVIEWS = gql`
  query GetProductReviews($productId: ID!, $pagination: PaginationInput) {
    getProductReviews(productId: $productId, pagination: $pagination) {
      _id rating title comment images helpfulCount verified createdAt
      user { _id name avatar }
    }
  }
`;

export const SEARCH_PRODUCTS = gql`
  query SearchProducts($query: String!, $pagination: PaginationInput) {
    searchProducts(query: $query, pagination: $pagination) {
      products {
        _id name slug price comparePrice discount images stock
        category { _id name slug }
        rating { average count }
      }
      total page pages hasNext
    }
  }
`;

export const GET_NOTIFICATIONS = gql`
  query GetNotifications {
    getNotifications {
      _id title message type data isRead createdAt
    }
  }
`;

export const GET_UNREAD_COUNT = gql`
  query GetUnreadCount {
    getUnreadNotificationCount
  }
`;

export const VALIDATE_COUPON = gql`
  query ValidateCoupon($code: String!, $orderAmount: Float!) {
    validateCoupon(code: $code, orderAmount: $orderAmount) {
      valid discount message
      coupon { _id code type value }
    }
  }
`;
