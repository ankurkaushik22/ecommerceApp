import { validateData, registerInputSchema, loginInputSchema, objectIdSchema } from './src/utils/validators.js';
import { validateImageSignature, validateZipSignature, validateCsvContent, isExecutableContent } from './src/utils/fileValidator.js';
import { checkAccountAuthBackoff, recordAuthFailure, recordAuthSuccess, normalizeIdentifier } from './src/utils/rateLimiter.js';
import fs from 'fs';
import path from 'path';

let passed = 0;
let failed = 0;

function assert(condition, message) {
  if (condition) {
    console.log(`  ✅ PASS: ${message}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${message}`);
    failed++;
  }
}

async function runTests() {
  console.log('\n🔒 RUNNING BACKEND SECURITY CONTROL SUITE\n=========================================');

  // TEST 1: Strict Zod Input Validation
  console.log('\n1. Testing Strict Zod Schema Validation...');
  try {
    validateData(registerInputSchema, { email: 'invalid-email', password: '123' });
    assert(false, 'Should reject invalid email and short password');
  } catch (err) {
    assert(err.message.includes('Invalid input parameters'), 'Rejects invalid email format and short password with GraphQLError');
  }

  try {
    validateData(objectIdSchema, 'invalid-24-hex-id');
    assert(false, 'Should reject non-24-hex ObjectId');
  } catch (err) {
    assert(err.message.includes('Invalid ID format'), 'Rejects invalid Mongo ObjectId format');
  }

  try {
    const validData = validateData(loginInputSchema, { email: 'user@example.com', password: 'ValidPassword123' });
    assert(validData.email === 'user@example.com', 'Accepts valid login input');
  } catch (err) {
    assert(false, 'Valid input should pass without error');
  }

  // TEST 2: File Upload Magic-Byte & Executable Verification
  console.log('\n2. Testing File Upload Magic-Byte Signature Verification...');
  const fakeExeHeader = Buffer.from([0x4d, 0x5a, 0x90, 0x00, 0x03, 0x00]); // Windows EXE magic bytes
  assert(isExecutableContent(fakeExeHeader) === true, 'Detects executable binary content signature (MZ header)');

  const exeSpoofedAsJpg = Buffer.concat([fakeExeHeader, Buffer.from('fake jpg content')]);
  const imgCheck = validateImageSignature(exeSpoofedAsJpg);
  assert(imgCheck.valid === false && imgCheck.error.includes('Executable file content detected'), 'Rejects EXE file spoofed as .jpg');

  const validPngHeader = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52]);
  const validPngCheck = validateImageSignature(validPngHeader);
  assert(validPngCheck.valid === true, 'Accepts valid PNG magic bytes header');

  const validZipHeader = Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x00, 0x00]);
  const validZipCheck = validateZipSignature(validZipHeader);
  assert(validZipCheck.valid === true, 'Accepts valid ZIP magic bytes header');

  const invalidCsv = Buffer.from([0x4d, 0x5a, 0x00, 0x00]);
  const csvCheck = validateCsvContent(invalidCsv);
  assert(csvCheck.valid === false, 'Rejects binary null content in CSV');

  // TEST 3: Rate Limiting & Exponential Backoff
  console.log('\n3. Testing Per-Account Exponential Backoff...');
  const testAccount = 'testuser_' + Date.now() + '@example.com';

  let backoffStatus = await checkAccountAuthBackoff(testAccount);
  assert(backoffStatus.allowed === true, 'New account starts with zero backoff lock');

  // Record failures up to max threshold (5)
  for (let i = 0; i < 5; i++) {
    await recordAuthFailure(testAccount);
  }

  backoffStatus = await checkAccountAuthBackoff(testAccount);
  assert(backoffStatus.allowed === false, 'Enforces backoff lock after 5 consecutive failures');
  assert(backoffStatus.retryAfterSeconds > 0, `Returns exponential backoff retry-after time (${backoffStatus.retryAfterSeconds}s)`);

  await recordAuthSuccess(testAccount);
  backoffStatus = await checkAccountAuthBackoff(testAccount);
  assert(backoffStatus.allowed === true, 'Resets backoff state immediately on successful login');

  // TEST 4: Secret Scanning in Tracked Files
  console.log('\n4. Testing Secret Audit in Source Files...');
  const backendSrcDir = path.resolve('./src');
  const secretPattern = /(?:aws_secret_access_key|stripe_secret_key|jwt_secret)\s*=\s*['"][a-zA-Z0-9_\-]{20,}['"]/i;
  
  let leakedCount = 0;
  function scanDir(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        scanDir(fullPath);
      } else if (entry.isFile() && entry.name.endsWith('.js')) {
        const content = fs.readFileSync(fullPath, 'utf8');
        if (secretPattern.test(content)) {
          leakedCount++;
        }
      }
    }
  }
  scanDir(backendSrcDir);
  assert(leakedCount === 0, 'No hardcoded private keys or secrets found in backend source files');

  console.log(`\n=========================================`);
  console.log(`SUMMARY: ${passed} Passed, ${failed} Failed`);
  if (failed > 0) {
    process.exit(1);
  } else {
    console.log('✅ ALL BACKEND SECURITY VERIFICATION CHECKS PASSED SUCCESSFULLY!\n');
    process.exit(0);
  }
}

runTests().catch((err) => {
  console.error('Test suite error:', err);
  process.exit(1);
});
