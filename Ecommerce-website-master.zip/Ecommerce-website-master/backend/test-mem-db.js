import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';

async function run() {
  console.log('⏳ Starting MongoMemoryServer test...');
  try {
    const mongod = await MongoMemoryServer.create();
    const uri = mongod.getUri();
    console.log('✅ In-Memory URI:', uri);
    await mongoose.connect(uri);
    console.log('✅ Mongoose connected successfully to in-memory db!');
    await mongod.stop();
  } catch (err) {
    console.error('❌ MongoMemoryServer error:', err);
  }
}

run();
