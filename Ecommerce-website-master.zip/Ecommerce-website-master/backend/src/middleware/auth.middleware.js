import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { GraphQLError } from 'graphql';

export const authenticate = async (req) => {
  try {
    const authHeader = req.headers?.authorization || req.headers?.Authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return null;
    }

    const token = authHeader.substring(7);

    if (!token) return null;

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('+refreshToken');

    if (!user || !user.isActive) return null;

    return user;
  } catch (error) {
    return null; // Token expired or invalid - return null (not throw)
  }
};

export const requireAuth = (user) => {
  if (!user) {
    throw new GraphQLError('You must be logged in to perform this action', {
      extensions: { code: 'UNAUTHENTICATED' },
    });
  }
};

export const requireAdmin = (user) => {
  requireAuth(user);
  if (user.role !== 'admin') {
    throw new GraphQLError('You do not have permission to perform this action', {
      extensions: { code: 'FORBIDDEN' },
    });
  }
};

export const requireAdminOrVendor = (user) => {
  requireAuth(user);
  if (!['admin', 'vendor'].includes(user.role)) {
    throw new GraphQLError('You do not have permission to perform this action', {
      extensions: { code: 'FORBIDDEN' },
    });
  }
};
