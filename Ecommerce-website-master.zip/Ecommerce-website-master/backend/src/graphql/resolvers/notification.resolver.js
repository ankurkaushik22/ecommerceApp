import { GraphQLError } from 'graphql';
import { PubSub } from 'graphql-subscriptions';
import Notification from '../../models/Notification.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

export const pubsub = new PubSub();
const NOTIFICATION_RECEIVED = 'NOTIFICATION_RECEIVED';

const notificationResolvers = {
  Query: {
    getNotifications: async (_, __, { user }) => {
      requireAuth(user);
      return Notification.find({ user: user._id }).sort({ createdAt: -1 }).limit(50);
    },

    getUnreadNotificationCount: async (_, __, { user }) => {
      if (!user) return 0;
      return Notification.countDocuments({ user: user._id, isRead: false });
    },
  },

  Mutation: {
    markNotificationRead: async (_, { id }, { user }) => {
      requireAuth(user);
      const notification = await Notification.findOneAndUpdate(
        { _id: id, user: user._id },
        { isRead: true },
        { new: true }
      );
      if (!notification) {
        throw new GraphQLError('Notification not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return notification;
    },

    markAllNotificationsRead: async (_, __, { user }) => {
      requireAuth(user);
      await Notification.updateMany({ user: user._id, isRead: false }, { isRead: true });
      return true;
    },
  },

  Subscription: {
    notificationReceived: {
      subscribe: (_, { userId }) => {
        return pubsub.asyncIterator(`${NOTIFICATION_RECEIVED}_${userId}`);
      },
    },
  },
};

// Helper to publish notification (used by other resolvers)
export const publishNotification = async (userId, notificationData) => {
  const notification = await Notification.create({
    user: userId,
    ...notificationData,
  });
  pubsub.publish(`${NOTIFICATION_RECEIVED}_${userId}`, {
    notificationReceived: notification,
  });
  return notification;
};

export default notificationResolvers;
