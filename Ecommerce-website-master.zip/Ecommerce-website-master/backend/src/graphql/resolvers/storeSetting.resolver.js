import fetch from 'node-fetch';
import { StoreSetting } from '../../models/StoreSetting.js';
import { requireAdmin, requireSuperAdmin } from '../../middleware/auth.middleware.js';

const getGatewayBaseUrl = async () => {
  let url = process.env.WHATSAPP_GATEWAY_URL;
  if (!url) {
    const settings = await StoreSetting.findOne();
    url = settings?.whatsappGatewayUrl || 'https://ecommerce-whatsappservice.onrender.com';
  }
  url = url.replace(/\/api\/send-otp\/?$/, '');
  url = url.replace(/\/+$/, '');
  return url;
};

const API_KEY = process.env.WHATSAPP_API_KEY || 'suaaka_whatsapp_otp_secret_key_98765';

const storeSettingResolvers = {
  Query: {
    getStoreSettings: async () => {
      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = await StoreSetting.create({
          storeName: 'My Store',
          logoUrl: '',
          faviconUrl: '',
          appIconUrl: '',
          paymentMode: 'both',
        });
      }
      return settings;
    },

    getWhatsAppGatewayStatus: async (_, __, context) => {
      requireAdmin(context.user);
      const baseUrl = await getGatewayBaseUrl();
      try {
        const response = await fetch(`${baseUrl}/api/status`);
        const data = await response.json();
        return {
          success: true,
          status: data.status || 'DISCONNECTED',
          qrCodeDataUrl: data.qrCodeDataUrl || null,
          phone: data.phone || '',
          name: data.name || '',
          message: data.errorDetails ? `Gateway Info: ${data.errorDetails}` : 'Status fetched successfully',
        };
      } catch (err) {
        return {
          success: false,
          status: 'OFFLINE',
          qrCodeDataUrl: null,
          phone: '',
          name: '',
          message: `WhatsApp Gateway service unreachable at ${baseUrl} (${err.message})`,
        };
      }
    },
  },
  Mutation: {
    logoutWhatsAppGateway: async (_, __, context) => {
      requireAdmin(context.user);
      const baseUrl = await getGatewayBaseUrl();
      try {
        const response = await fetch(`${baseUrl}/api/logout`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${API_KEY}`,
          },
        });
        const data = await response.json();
        return {
          success: data.success ?? true,
          status: 'DISCONNECTED',
          qrCodeDataUrl: null,
          phone: '',
          name: '',
          message: data.message || 'Logged out successfully',
        };
      } catch (err) {
        return {
          success: false,
          status: 'ERROR',
          qrCodeDataUrl: null,
          phone: '',
          name: '',
          message: `Failed to logout WhatsApp Gateway: ${err.message}`,
        };
      }
    },
    updateStoreSettings: async (
      _,
      {
        storeName,
        logoUrl,
        faviconUrl,
        appIconUrl,
        disabledVerticals,
        serviceBookingMode,
        serviceContactPhone,
        paymentMode,
        latestCustomerVersion,
        customerApkUrl,
        latestDeliveryVersion,
        deliveryApkUrl,
        forceAppUpdate,
        websiteDisplayMode,
        customerPlayStoreUrl,
        customerIosUrl,
      },
      context
    ) => {
      requireAdmin(context.user);

      if (
        latestCustomerVersion !== undefined ||
        customerApkUrl !== undefined ||
        latestDeliveryVersion !== undefined ||
        deliveryApkUrl !== undefined ||
        forceAppUpdate !== undefined ||
        websiteDisplayMode !== undefined ||
        customerPlayStoreUrl !== undefined ||
        customerIosUrl !== undefined
      ) {
        requireSuperAdmin(context.user);
      }

      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = new StoreSetting();
      }

      if (storeName !== undefined) settings.storeName = storeName;
      if (logoUrl !== undefined) settings.logoUrl = logoUrl;
      if (faviconUrl !== undefined) settings.faviconUrl = faviconUrl;
      if (appIconUrl !== undefined) settings.appIconUrl = appIconUrl;
      if (disabledVerticals !== undefined) settings.disabledVerticals = disabledVerticals;
      if (serviceBookingMode !== undefined) settings.serviceBookingMode = serviceBookingMode;
      if (serviceContactPhone !== undefined) settings.serviceContactPhone = serviceContactPhone;
      if (paymentMode !== undefined) settings.paymentMode = paymentMode;
      if (latestCustomerVersion !== undefined) settings.latestCustomerVersion = latestCustomerVersion;
      if (customerApkUrl !== undefined) settings.customerApkUrl = customerApkUrl;
      if (latestDeliveryVersion !== undefined) settings.latestDeliveryVersion = latestDeliveryVersion;
      if (deliveryApkUrl !== undefined) settings.deliveryApkUrl = deliveryApkUrl;
      if (forceAppUpdate !== undefined) settings.forceAppUpdate = forceAppUpdate;
      if (websiteDisplayMode !== undefined) settings.websiteDisplayMode = websiteDisplayMode;
      if (customerPlayStoreUrl !== undefined) settings.customerPlayStoreUrl = customerPlayStoreUrl;
      if (customerIosUrl !== undefined) settings.customerIosUrl = customerIosUrl;

      await settings.save();
      return settings;
    },
  },
};

export default storeSettingResolvers;
