import { StoreSetting } from '../../models/StoreSetting.js';
import { requireSuperAdmin } from '../../middleware/auth.middleware.js';

const storeSettingResolvers = {
  Query: {
    getStoreSettings: async () => {
      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = await StoreSetting.create({
          storeName: 'My Store',
          logoUrl: '',
          faviconUrl: '',
          appIconUrl: ''
        });
      }
      return settings;
    },
  },
  Mutation: {
    updateStoreSettings: async (_, { storeName, logoUrl, faviconUrl, appIconUrl, disabledVerticals, serviceBookingMode, serviceContactPhone }, context) => {
      requireSuperAdmin(context.user);

      let settings = await StoreSetting.findOne();
      if (!settings) {
        settings = new StoreSetting();
      }

      if (storeName !== undefined) settings.storeName = storeName;
      if (logoUrl !== undefined) settings.logoUrl = logoUrl;
      if (faviconUrl !== undefined) settings.faviconUrl = faviconUrl;
      if (appIconUrl !== undefined) settings.appIconUrl = appIconUrl;
      if (disabledVerticals !== undefined) settings.disabledVerticals = disabledVerticals;
      if (serviceBookingMode !== undefined) settings.serviceBookingMode = serviceBookingMode;
      if (serviceContactPhone !== undefined) settings.serviceContactPhone = serviceContactPhone;

      await settings.save();
      return settings;
    },
  },
};

export default storeSettingResolvers;
