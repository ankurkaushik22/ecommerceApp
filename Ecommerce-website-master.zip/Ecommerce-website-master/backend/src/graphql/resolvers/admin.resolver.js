import { GraphQLError } from 'graphql';
import Order from '../../models/Order.js';
import Product from '../../models/Product.js';
import User from '../../models/User.js';
import { requireAdmin } from '../../middleware/auth.middleware.js';
import { subDays, format, startOfDay, endOfDay } from 'date-fns';

// Helper: get last N days label
const getDayLabel = (daysAgo) => {
  const date = subDays(new Date(), daysAgo);
  return format(date, 'MMM d');
};

const adminResolvers = {
  Query: {
    getDashboardStats: async (_, __, { user }) => {
      requireAdmin(user);

      const now = new Date();
      const todayStart = startOfDay(now);
      const todayEnd = endOfDay(now);

      const [
        totalRevenueResult,
        todayRevenueResult,
        totalOrders,
        todayOrders,
        totalProducts,
        totalUsers,
        totalVendors,
        pendingOrders,
        recentOrders,
        topProducts,
      ] = await Promise.all([
        Order.aggregate([
          { $match: { paymentStatus: 'paid' } },
          { $group: { _id: null, total: { $sum: '$total' } } },
        ]),
        Order.aggregate([
          {
            $match: {
              paymentStatus: 'paid',
              createdAt: { $gte: todayStart, $lte: todayEnd },
            },
          },
          { $group: { _id: null, total: { $sum: '$total' } } },
        ]),
        Order.countDocuments(),
        Order.countDocuments({ createdAt: { $gte: todayStart } }),
        Product.countDocuments({ isActive: true }),
        User.countDocuments({ role: 'customer' }),
        User.countDocuments({ role: 'vendor' }),
        Order.countDocuments({ status: 'pending' }),
        Order.find()
          .sort({ createdAt: -1 })
          .limit(5)
          .populate('customer', 'name email avatar'),
        Product.find({ isActive: true }).sort({ salesCount: -1 }).limit(5),
      ]);

      // Revenue chart - last 7 days
      const revenueChart = [];
      const ordersChart = [];

      for (let i = 6; i >= 0; i--) {
        const dayStart = startOfDay(subDays(now, i));
        const dayEnd = endOfDay(subDays(now, i));

        const [revResult, ordCount] = await Promise.all([
          Order.aggregate([
            {
              $match: {
                paymentStatus: 'paid',
                createdAt: { $gte: dayStart, $lte: dayEnd },
              },
            },
            { $group: { _id: null, total: { $sum: '$total' } } },
          ]),
          Order.countDocuments({
            createdAt: { $gte: dayStart, $lte: dayEnd },
          }),
        ]);

        const label = format(subDays(now, i), 'MMM d');
        revenueChart.push({ label, value: revResult[0]?.total || 0 });
        ordersChart.push({ label, value: ordCount });
      }

      return {
        totalRevenue: totalRevenueResult[0]?.total || 0,
        todayRevenue: todayRevenueResult[0]?.total || 0,
        totalOrders,
        todayOrders,
        totalProducts,
        totalUsers,
        totalVendors,
        pendingOrders,
        recentOrders,
        topProducts,
        revenueChart,
        ordersChart,
      };
    },

    getAllUsers: async (_, { role, pagination = {} }, { user }) => {
      requireAdmin(user);
      const { page = 1, limit = 20 } = pagination;
      const query = {};
      if (role) query.role = role;
      return User.find(query)
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit);
    },

    getVendors: async (_, { pagination = {} }, { user }) => {
      requireAdmin(user);
      const { page = 1, limit = 20 } = pagination;
      return User.find({ role: 'vendor' })
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit);
    },

    getAnalytics: async (_, { period = '30d' }, { user }) => {
      requireAdmin(user);
      const days = period === '7d' ? 7 : period === '90d' ? 90 : 30;
      const startDate = subDays(new Date(), days);

      const [ordersByStatus, revenueByCategory, monthlyRevenue] = await Promise.all([
        Order.aggregate([
          { $match: { createdAt: { $gte: startDate } } },
          { $group: { _id: '$status', count: { $sum: 1 } } },
        ]),
        Order.aggregate([
          { $match: { paymentStatus: 'paid', createdAt: { $gte: startDate } } },
          { $unwind: '$items' },
          {
            $lookup: {
              from: 'products',
              localField: 'items.product',
              foreignField: '_id',
              as: 'productData',
            },
          },
          { $unwind: { path: '$productData', preserveNullAndEmpty: true } },
          {
            $lookup: {
              from: 'categories',
              localField: 'productData.category',
              foreignField: '_id',
              as: 'categoryData',
            },
          },
          { $unwind: { path: '$categoryData', preserveNullAndEmpty: true } },
          {
            $group: {
              _id: '$categoryData.name',
              revenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } },
            },
          },
          { $sort: { revenue: -1 } },
          { $limit: 10 },
        ]),
        Order.aggregate([
          {
            $match: { paymentStatus: 'paid', createdAt: { $gte: startDate } },
          },
          {
            $group: {
              _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
              revenue: { $sum: '$total' },
              orders: { $sum: 1 },
            },
          },
          { $sort: { _id: 1 } },
        ]),
      ]);

      return {
        ordersByStatus,
        revenueByCategory,
        monthlyRevenue,
        period,
      };
    },
  },

  Mutation: {
    updateUserStatus: async (_, { userId, isActive }, { user }) => {
      requireAdmin(user);
      return User.findByIdAndUpdate(userId, { isActive }, { new: true });
    },

    updateUserRole: async (_, { userId, role }, { user }) => {
      requireAdmin(user);
      const validRoles = ['customer', 'admin', 'vendor', 'delivery'];
      if (!validRoles.includes(role)) {
        throw new GraphQLError('Invalid role', { extensions: { code: 'BAD_USER_INPUT' } });
      }
      return User.findByIdAndUpdate(userId, { role }, { new: true });
    },
  },
};

export default adminResolvers;
