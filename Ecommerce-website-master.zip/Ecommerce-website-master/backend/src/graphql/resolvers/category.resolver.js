import { GraphQLError } from 'graphql';
import slugify from 'slugify';
import Category from '../../models/Category.js';
import Product from '../../models/Product.js';
import RolePermission from '../../models/RolePermission.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const canManageCategories = async (user) => {
  requireAuth(user);

  // Check role-based permissions from DB
  const roleDoc = await RolePermission.findOne({ roleName: user.role });
  if (roleDoc && (roleDoc.modules?.includes('add_categories') || roleDoc.modules?.includes('categories'))) return true;

  // Check direct user permissions
  if (user.permissions?.includes('add_categories') || user.permissions?.includes('categories')) return true;

  throw new GraphQLError('Permission Denied: Adding or modifying categories is disabled for this role.', {
    extensions: { code: 'FORBIDDEN' },
  });
};

const categoryResolvers = {
  Query: {
    getCategories: async (_, { parentId, vertical }) => {
      const query = parentId ? { parent: parentId } : { parent: null };
      query.isActive = true;
      if (vertical && vertical !== 'all') {
        query.vertical = vertical;
      }
      return Category.find(query)
        .populate('parent')
        .populate({ path: 'children', match: { isActive: true } })
        .sort({ sortOrder: 1, name: 1 });
    },

    getAllCategories: async (_, { includeInactive = false }, { user }) => {
      const query = {};
      const isAdmin = user && ['superadmin', 'admin', 'vendor'].includes(user.role);
      if (!includeInactive && !isAdmin) {
        query.isActive = true;
      }
      return Category.find(query)
        .populate('parent')
        .populate({ path: 'children', match: !includeInactive && !isAdmin ? { isActive: true } : {} })
        .sort({ sortOrder: 1, name: 1 });
    },

    getCategory: async (_, { slug }) => {
      const category = await Category.findOne({ slug })
        .populate('parent')
        .populate({ path: 'children', match: { isActive: true } });
      if (!category) {
        throw new GraphQLError('Category not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return category;
    },
  },

  Mutation: {
    createCategory: async (_, { input }, { user }) => {
      await canManageCategories(user);

      const name = (input.name || '').trim();
      if (!name) {
        throw new GraphQLError('Category name is required', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      let slug = slugify(name, { lower: true, strict: true });
      const existing = await Category.findOne({ slug });
      if (existing) {
        slug = `${slug}-${Math.floor(100 + Math.random() * 900)}`;
      }

      const categoryData = {
        ...input,
        name,
        slug,
        parent: input.parentId || null,
      };
      delete categoryData.parentId;

      const category = await Category.create(categoryData);
      return Category.findById(category._id)
        .populate('parent')
        .populate('children');
    },

    updateCategory: async (_, { id, input }, { user }) => {
      await canManageCategories(user);

      const updateData = {
        ...input,
        parent: input.parentId || null,
      };
      delete updateData.parentId;

      if (input.name) {
        updateData.slug = slugify(input.name.trim(), { lower: true, strict: true });
      }

      const category = await Category.findByIdAndUpdate(id, updateData, { new: true })
        .populate('parent')
        .populate('children');

      if (!category) {
        throw new GraphQLError('Category not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return category;
    },

    deleteCategory: async (_, { id }, { user }) => {
      await canManageCategories(user);

      // Move children to root level
      await Category.updateMany({ parent: id }, { parent: null });
      await Category.findByIdAndDelete(id);
      return true;
    },
  },

  Category: {
    children: async (parent) => {
      return Category.find({ parent: parent._id }).sort({ sortOrder: 1, name: 1 });
    },
    productCount: async (parent) => {
      try {
        if (!parent?._id) return parent?.productCount || 0;
        const subcats = await Category.find({ parent: parent._id }).select('_id');
        const catIds = [parent._id, ...subcats.map((c) => c._id)];
        return await Product.countDocuments({
          $or: [
            { category: { $in: catIds } },
            { subcategory: { $in: catIds } },
          ],
          isActive: true,
        });
      } catch (e) {
        return parent?.productCount || 0;
      }
    },
  },
};

export default categoryResolvers;
