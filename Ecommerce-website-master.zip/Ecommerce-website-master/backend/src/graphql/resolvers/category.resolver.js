import { GraphQLError } from 'graphql';
import Category from '../../models/Category.js';
import { requireAdmin } from '../../middleware/auth.middleware.js';

const categoryResolvers = {
  Query: {
    getCategories: async (_, { parentId }) => {
      const query = parentId ? { parent: parentId } : { parent: null };
      query.isActive = true;
      return Category.find(query)
        .populate('parent')
        .populate({ path: 'children', match: { isActive: true } })
        .sort({ sortOrder: 1, name: 1 });
    },

    getAllCategories: async () => {
      return Category.find()
        .populate('parent')
        .populate({ path: 'children' })
        .sort({ sortOrder: 1, name: 1 });
    },

    getCategory: async (_, { slug }) => {
      const category = await Category.findOne({ slug })
        .populate('parent')
        .populate({ path: 'children', match: { isActive: true } });
      if (!category) {
        throw new GraphQLError('Category not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return category;
    },
  },

  Mutation: {
    createCategory: async (_, { input }, { user }) => {
      requireAdmin(user);
      const categoryData = {
        ...input,
        parent: input.parentId || null,
      };
      delete categoryData.parentId;

      const category = await Category.create(categoryData);
      return Category.findById(category._id)
        .populate('parent')
        .populate('children');
    },

    updateCategory: async (_, { id, input }, { user }) => {
      requireAdmin(user);
      const updateData = {
        ...input,
        parent: input.parentId || null,
      };
      delete updateData.parentId;

      const category = await Category.findByIdAndUpdate(id, updateData, { new: true })
        .populate('parent')
        .populate('children');

      if (!category) {
        throw new GraphQLError('Category not found', { extensions: { code: 'NOT_FOUND' } });
      }
      return category;
    },

    deleteCategory: async (_, { id }, { user }) => {
      requireAdmin(user);
      // Move children to root level
      await Category.updateMany({ parent: id }, { parent: null });
      await Category.findByIdAndDelete(id);
      return true;
    },
  },

  Category: {
    children: async (parent) => {
      return Category.find({ parent: parent._id }).sort({ sortOrder: 1, name: 1 });
    },
  },
};

export default categoryResolvers;
