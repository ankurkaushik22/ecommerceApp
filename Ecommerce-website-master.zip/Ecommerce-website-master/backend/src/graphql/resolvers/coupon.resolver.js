import { GraphQLError } from 'graphql';
import Coupon from '../../models/Coupon.js';
import Order from '../../models/Order.js';
import { requireAdminOrVendor } from '../../middleware/auth.middleware.js';

const couponResolvers = {
  Query: {
    getAllCoupons: async (_, __, { user }) => {
      requireAdminOrVendor(user);
      const queryFilter = user.role === 'vendor'
        ? {
            $or: [
              { vendor: user._id },
              { vendor: { $exists: false } },
              { vendor: null },
            ],
          }
        : {};

      const coupons = await Coupon.find(queryFilter)
        .populate('vendor', 'name email avatar role')
        .sort({ createdAt: -1 });

      const updatedCoupons = await Promise.all(
        coupons.map(async (coupon) => {
          try {
            const actualOrdersCount = await Order.countDocuments({
              couponCode: new RegExp(`^${coupon.code}$`, 'i'),
            });
            if (coupon.usedCount !== actualOrdersCount) {
              coupon.usedCount = actualOrdersCount;
              await Coupon.updateOne({ _id: coupon._id }, { usedCount: actualOrdersCount });
            }
          } catch (e) {
            console.error('Coupon count sync error:', e);
          }
          return coupon;
        })
      );

      return updatedCoupons;
    },
  },

  Mutation: {
    createCoupon: async (_, { input }, { user }) => {
      requireAdminOrVendor(user);
      const couponData = { ...input, code: input.code.toUpperCase() };

      if (user.role === 'vendor') {
        couponData.vendor = user._id;
      } else if (input.vendorId) {
        couponData.vendor = input.vendorId;
      }
      delete couponData.vendorId;

      if (couponData.maxDiscountAmount === undefined && couponData.maxDiscount !== undefined) {
        couponData.maxDiscountAmount = couponData.maxDiscount;
      }
      if (couponData.startsAt === undefined && couponData.validFrom !== undefined) {
        couponData.startsAt = couponData.validFrom;
      }
      if (couponData.expiresAt === undefined && couponData.validUntil !== undefined) {
        couponData.expiresAt = couponData.validUntil;
      }
      const created = await Coupon.create(couponData);
      return Coupon.findById(created._id).populate('vendor', 'name email avatar role');
    },

    updateCoupon: async (_, { id, input }, { user }) => {
      requireAdminOrVendor(user);
      const existing = await Coupon.findById(id);
      if (!existing) {
        throw new GraphQLError('Coupon not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isOwner = existing.vendor && String(existing.vendor) === String(user._id);

      if (!isStaff && user.role === 'vendor' && existing.vendor && !isOwner) {
        throw new GraphQLError('You do not have permission to edit this coupon', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const couponData = { ...input, code: input.code.toUpperCase() };
      if (input.vendorId !== undefined) {
        couponData.vendor = input.vendorId || null;
      }
      delete couponData.vendorId;

      if (couponData.maxDiscountAmount === undefined && couponData.maxDiscount !== undefined) {
        couponData.maxDiscountAmount = couponData.maxDiscount;
      }
      if (couponData.startsAt === undefined && couponData.validFrom !== undefined) {
        couponData.startsAt = couponData.validFrom;
      }
      if (couponData.expiresAt === undefined && couponData.validUntil !== undefined) {
        couponData.expiresAt = couponData.validUntil;
      }
      return Coupon.findByIdAndUpdate(id, couponData, { new: true }).populate('vendor', 'name email avatar role');
    },

    deleteCoupon: async (_, { id }, { user }) => {
      requireAdminOrVendor(user);
      const existing = await Coupon.findById(id);
      if (!existing) {
        throw new GraphQLError('Coupon not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isOwner = existing.vendor && String(existing.vendor) === String(user._id);

      if (!isStaff && user.role === 'vendor' && existing.vendor && !isOwner) {
        throw new GraphQLError('You do not have permission to delete this coupon', {
          extensions: { code: 'FORBIDDEN' },
        });
      }
      await Coupon.findByIdAndDelete(id);
      return true;
    },

    validateCoupon: async (_, { code, orderAmount }, { user }) => {
      const coupon = await Coupon.findOne({ code: code.toUpperCase() });
      if (!coupon) {
        return { valid: false, message: 'Coupon not found', discount: 0 };
      }

      const validation = coupon.isValid(orderAmount);
      if (!validation.valid) {
        return { valid: false, message: validation.message, discount: 0 };
      }

      const discount = coupon.calculateDiscount(orderAmount);
      return { valid: true, discount, coupon, message: `${coupon.value}${coupon.type === 'percentage' ? '%' : '₹'} off applied!` };
    },
  },
};

export default couponResolvers;
