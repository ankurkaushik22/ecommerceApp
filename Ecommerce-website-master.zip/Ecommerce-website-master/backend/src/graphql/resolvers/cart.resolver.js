import { GraphQLError } from 'graphql';
import Cart from '../../models/Cart.js';
import Product from '../../models/Product.js';
import Coupon from '../../models/Coupon.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const populateCart = (cart) =>
  cart.populate({
    path: 'items.product',
    populate: [{ path: 'category' }, { path: 'subcategory' }],
  });

const formatCart = (cart) => ({
  _id: cart._id,
  user: cart.user,
  items: cart.items.map((item) => ({
    _id: item._id,
    product: item.product,
    variantIndex: item.variantIndex,
    quantity: item.quantity,
    price: item.price,
    total: item.price * item.quantity,
  })),
  subtotal: cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0),
  itemCount: cart.items.reduce((sum, item) => sum + item.quantity, 0),
  couponCode: cart.couponCode,
  couponDiscount: cart.couponDiscount || 0,
  discount: cart.couponDiscount || 0,
  updatedAt: cart.updatedAt,
});

const cartResolvers = {
  Query: {
    getCart: async (_, __, { user }) => {
      requireAuth(user);
      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }
      await populateCart(cart);
      return formatCart(cart);
    },
  },

  Mutation: {
    addToCart: async (_, { input }, { user }) => {
      requireAuth(user);
      const { productId, variantIndex = -1, quantity } = input;

      const product = await Product.findById(productId);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      // Determine price
      let price = product.price;
      if (variantIndex >= 0 && product.variants?.length > 0) {
        const variant = product.variants[0]?.options?.[variantIndex];
        if (variant) price = variant.price;
      }

      // Check stock
      const availableStock = variantIndex >= 0
        ? product.variants?.[0]?.options?.[variantIndex]?.stock ?? product.stock
        : product.stock;

      if (availableStock < quantity) {
        throw new GraphQLError(`Only ${availableStock} items available in stock`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }

      // Check if item already in cart
      const existingItemIndex = cart.items.findIndex(
        (item) =>
          item.product.toString() === productId &&
          item.variantIndex === variantIndex
      );

      if (existingItemIndex > -1) {
        const newQty = cart.items[existingItemIndex].quantity + quantity;
        if (newQty > availableStock) {
          throw new GraphQLError(`Cannot add more. Only ${availableStock} items available.`, {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        cart.items[existingItemIndex].quantity = newQty;
      } else {
        cart.items.push({ product: productId, variantIndex, quantity, price });
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    updateCartItem: async (_, { itemId, quantity }, { user }) => {
      requireAuth(user);
      if (quantity < 1) {
        throw new GraphQLError('Quantity must be at least 1', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const item = cart.items.id(itemId);
      if (!item) throw new GraphQLError('Cart item not found', { extensions: { code: 'NOT_FOUND' } });

      // Check stock
      const product = await Product.findById(item.product);
      if (product && quantity > product.stock) {
        throw new GraphQLError(`Only ${product.stock} items available`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      item.quantity = quantity;
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeFromCart: async (_, { itemId }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      cart.items = cart.items.filter((item) => item._id.toString() !== itemId);
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    clearCart: async (_, __, { user }) => {
      requireAuth(user);
      await Cart.findOneAndUpdate({ user: user._id }, { items: [], couponCode: null, couponDiscount: 0 });
      return true;
    },

    applyCoupon: async (_, { code }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const coupon = await Coupon.findOne({ code: code.toUpperCase() });
      if (!coupon) {
        throw new GraphQLError('Invalid coupon code', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const subtotal = cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const validation = coupon.isValid(subtotal);

      if (!validation.valid) {
        throw new GraphQLError(validation.message, { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const discount = coupon.calculateDiscount(subtotal);
      cart.couponCode = coupon.code;
      cart.couponDiscount = discount;
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeCoupon: async (_, __, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOneAndUpdate(
        { user: user._id },
        { couponCode: null, couponDiscount: 0 },
        { new: true }
      );
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });
      await populateCart(cart);
      return formatCart(cart);
    },
  },
};

export default cartResolvers;
