import { GraphQLError } from 'graphql';
import Cart from '../../models/Cart.js';
import Product from '../../models/Product.js';
import Coupon from '../../models/Coupon.js';
import User from '../../models/User.js';
import { requireAuth } from '../../middleware/auth.middleware.js';
import { resolveVariantInfo } from './order.resolver.js';

export function isProductStockUnlimited(product) {
  if (!product) return true;
  if (product.isUnlimitedStock === true) return true;
  if (product.isStockCompulsory === false) return true;
  const vert = product.vertical || product.category?.vertical;
  const isFoodOrService =
    vert === 'services' ||
    vert === 'food' ||
    Boolean(product.restaurantName) ||
    product.isVeg !== undefined ||
    (Array.isArray(product.cuisine) && product.cuisine.length > 0) ||
    (Array.isArray(product.addons) && product.addons.length > 0) ||
    Boolean(product.serviceDuration);

  if (isFoodOrService) {
    if (product.isStockCompulsory === true && product.isUnlimitedStock === false && typeof product.stock === 'number' && product.stock > 0) {
      return false;
    }
    return true;
  }
  if (product.isUnlimitedStock === false || product.isStockCompulsory === true) return false;
  return false;
}

export function isProductStockCompulsory(product) {
  return !isProductStockUnlimited(product);
}

const syncCartCoupon = async (cart) => {
  if (!cart) return;
  const getItemPrice = (item) => (typeof item.price === 'number' && item.price > 0) ? item.price : Number(item.product?.price || 0);
  const subtotal = (cart.items || []).reduce((sum, item) => sum + getItemPrice(item) * (item.quantity || 1), 0);

  if (!cart.couponCode || subtotal <= 0 || !Array.isArray(cart.items) || cart.items.length === 0) {
    if (cart.couponCode !== null || cart.couponDiscount !== 0) {
      cart.couponCode = null;
      cart.couponDiscount = 0;
      await cart.save();
    }
    return;
  }

  try {
    const coupon = await Coupon.findOne({ code: String(cart.couponCode).toUpperCase() });
    if (!coupon) {
      cart.couponCode = null;
      cart.couponDiscount = 0;
      await cart.save();
      return;
    }

    const validation = coupon.isValid(subtotal);
    if (!validation.valid) {
      cart.couponCode = null;
      cart.couponDiscount = 0;
      await cart.save();
      return;
    }

    const freshDiscount = coupon.calculateDiscount(subtotal);
    const finalDiscount = Math.min(Math.max(0, freshDiscount), subtotal);

    if (cart.couponDiscount !== finalDiscount) {
      cart.couponDiscount = finalDiscount;
      await cart.save();
    }
  } catch (err) {
    console.error('Error syncing cart coupon:', err);
  }
};

const populateCart = async (cart) => {
  await cart.populate({
    path: 'items.product',
    populate: [{ path: 'category' }, { path: 'subcategory' }, { path: 'taxSetting' }],
  });
  await syncCartCoupon(cart);
};

const formatCart = (cart) => {
  const getItemPrice = (item) => (typeof item.price === 'number' && item.price > 0) ? item.price : Number(item.product?.price || 0);
  const subtotal = cart.items.reduce((sum, item) => sum + getItemPrice(item) * (item.quantity || 1), 0);
  const rawDiscount = cart.couponDiscount || cart.discount || 0;
  const discount = Math.min(Math.max(0, rawDiscount), subtotal);
  const taxableAmount = Math.max(0, subtotal - discount);

  let totalItemTax = 0;
  cart.items.forEach((item) => {
    const price = getItemPrice(item);
    const qty = Number(item.quantity || 1);
    const itemSubtotal = price * qty;
    const rate = (item.product?.taxSetting?.rate !== undefined && item.product?.taxSetting?.rate !== null)
      ? Number(item.product.taxSetting.rate)
      : 5;
    const itemTaxable = subtotal > 0 ? itemSubtotal * (taxableAmount / subtotal) : itemSubtotal;
    totalItemTax += itemTaxable * (rate / 100);
  });

  const tax = Math.round(totalItemTax * 100) / 100;
  const shippingCost = subtotal > 500 || subtotal === 0 ? 0 : 49;
  const total = Math.round(Math.max(0, taxableAmount + tax + shippingCost) * 100) / 100;

  return {
    _id: cart._id,
    user: cart.user,
    items: cart.items.map((item) => {
      const price = getItemPrice(item);
      const { variantLabel: resLabel, image, stock: varStock } = resolveVariantInfo(item.product, item.variantIndex);
      const isCompulsory = isProductStockCompulsory(item.product);
      const rawStock = item.product?.vertical === 'services'
        ? null
        : (item.variantIndex >= 0 ? varStock : item.product?.stock);
      const availableStock = (!isCompulsory || rawStock === null || rawStock === undefined) ? 999999 : rawStock;
      const finalVariantLabel = item.variantLabel || resLabel || null;
      return {
        _id: item._id,
        product: item.product,
        variantIndex: item.variantIndex,
        variantLabel: finalVariantLabel,
        image: image || item.product?.images?.[0] || '',
        quantity: item.quantity,
        price,
        total: price * (item.quantity || 1),
        availableStock,
        addons: item.addons || [],
        instructions: item.instructions || '',
      };
    }),
    subtotal,
    itemCount: cart.items.reduce((sum, item) => sum + (item.quantity || 1), 0),
    couponCode: cart.couponCode,
    couponDiscount: discount,
    discount,
    shippingCost,
    tax,
    total,
    updatedAt: cart.updatedAt,
  };
};

const cartResolvers = {
  Query: {
    getCart: async (_, __, { user }) => {
      requireAuth(user);
      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }
      await populateCart(cart);
      return formatCart(cart);
    },
  },

  Mutation: {
    addToCart: async (_, { input }, { user }) => {
      requireAuth(user);
      const { productId, variantIndex = -1, variantLabel: inputVariantLabel, quantity: rawQuantity, addons = [], instructions = '', customPrice } = input;
      const quantity = Math.max(1, Math.min(50, Math.floor(Number(rawQuantity) || 1)));

      const product = await Product.findById(productId).populate('category');
      if (!product || !product.isActive || product.approvalStatus === 'pending' || product.approvalStatus === 'rejected') {
        throw new GraphQLError('Product not found, inactive, or pending approval', { extensions: { code: 'NOT_FOUND' } });
      }

      if (product.vendor) {
        const vendorUser = await User.findById(product.vendor);
        if (vendorUser && vendorUser.role === 'vendor' && vendorUser.isOnline === false) {
          throw new GraphQLError(
            `Store "${vendorUser.name || 'Seller'}" is currently offline and not accepting orders right now.`,
            { extensions: { code: 'STORE_OFFLINE' } }
          );
        }
      }

      const { price: variantPrice, stock: varStock, variantLabel: resVariantLabel } = resolveVariantInfo(product, variantIndex);
      const finalVariantLabel = inputVariantLabel || resVariantLabel || null;

      const basePrice = (variantIndex >= 0 && variantPrice > 0) ? variantPrice : product.price;
      const addonSum = Array.isArray(addons) ? addons.reduce((sum, a) => sum + (Number(a.price) || 0), 0) : 0;
      const price = typeof customPrice === 'number' && customPrice > 0 ? customPrice : (basePrice + addonSum);

      // Check stock (only enforce if stock is compulsory)
      const isCompulsory = isProductStockCompulsory(product);
      const rawStock = variantIndex >= 0 ? varStock : product.stock;
      const availableStock = (!isCompulsory || rawStock === null || rawStock === undefined) ? 999999 : rawStock;

      if (isCompulsory && rawStock !== null && rawStock !== undefined && rawStock < quantity) {
        throw new GraphQLError(`Only ${rawStock} items available in stock`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }

      const addonsKeyStr = (arr) => (arr || []).map((a) => a.name).sort().join('|');
      const targetAddonsKey = addonsKeyStr(addons);
      const targetInstructions = (instructions || '').trim();

      // Check if exact same customized item already in cart
      const existingItemIndex = cart.items.findIndex(
        (item) =>
          item.product.toString() === productId &&
          item.variantIndex === variantIndex &&
          addonsKeyStr(item.addons) === targetAddonsKey &&
          (item.instructions || '').trim() === targetInstructions
      );

      if (existingItemIndex > -1) {
        const newQty = Math.min(50, cart.items[existingItemIndex].quantity + quantity);
        if (isCompulsory && newQty > availableStock) {
          throw new GraphQLError(`Cannot add more. Only ${availableStock} items available.`, {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        cart.items[existingItemIndex].quantity = newQty;
        cart.items[existingItemIndex].price = price;
        if (finalVariantLabel) {
          cart.items[existingItemIndex].variantLabel = finalVariantLabel;
        }
      } else {
        cart.items.push({
          product: productId,
          variantIndex,
          variantLabel: finalVariantLabel,
          quantity,
          price,
          addons: addons || [],
          instructions: targetInstructions,
        });
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    syncCart: async (_, { items = [] }, { user }) => {
      requireAuth(user);
      let cart = await Cart.findOne({ user: user._id });
      if (!cart) {
        cart = await Cart.create({ user: user._id, items: [] });
      }

      for (const item of items) {
        const { productId, variantIndex = -1, quantity: rawQuantity = 1 } = item;
        const quantity = Math.max(1, Math.min(50, Math.floor(Number(rawQuantity) || 1)));
        const product = await Product.findById(productId).populate('category');
        if (!product || !product.isActive) continue;

        const isCompulsory = isProductStockCompulsory(product);
        const { price: variantPrice, stock: varStock } = resolveVariantInfo(product, variantIndex);
        const price = (variantIndex >= 0 && variantPrice > 0) ? variantPrice : product.price;
        const rawStock = variantIndex >= 0 ? varStock : product.stock;
        const availableStock = (!isCompulsory || rawStock === null || rawStock === undefined) ? 999999 : rawStock;
        const clampedQty = Math.max(1, Math.min(quantity, Math.max(1, availableStock)));

        const existingItemIndex = cart.items.findIndex(
          (ci) => ci.product.toString() === productId && ci.variantIndex === variantIndex
        );

        if (existingItemIndex > -1) {
          cart.items[existingItemIndex].quantity = Math.min(
            availableStock || 50,
            Math.max(cart.items[existingItemIndex].quantity, clampedQty)
          );
        } else {
          cart.items.push({ product: productId, variantIndex, quantity: clampedQty, price });
        }
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    updateCartItem: async (_, { itemId, quantity: rawQuantity }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const itemStr = String(itemId);
      let item = cart.items.id(itemId);
      if (!item) {
        item = cart.items.find((i) => i._id.toString() === itemStr || i.product.toString() === itemStr);
      }
      if (!item) throw new GraphQLError('Cart item not found', { extensions: { code: 'NOT_FOUND' } });

      const targetQty = Number(rawQuantity);
      if (isNaN(targetQty) || targetQty <= 0) {
        cart.items = cart.items.filter((i) => i._id.toString() !== itemStr && i.product.toString() !== itemStr);
      } else {
        const quantity = Math.min(50, Math.floor(targetQty));
        // Check stock
        const product = await Product.findById(item.product).populate('category');
        if (product) {
          const isCompulsory = isProductStockCompulsory(product);
          const { stock: varStock, variantLabel } = resolveVariantInfo(product, item.variantIndex);
          const rawStock = item.variantIndex >= 0 ? varStock : product.stock;
          const availableStock = (!isCompulsory || rawStock === null || rawStock === undefined) ? 999999 : rawStock;
          if (isCompulsory && quantity > availableStock) {
            throw new GraphQLError(`Only ${availableStock} item${availableStock === 1 ? '' : 's'} available in stock${variantLabel ? ` (${variantLabel})` : ''}`, {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
        }
        item.quantity = quantity;
      }

      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeFromCart: async (_, { itemId }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const itemStr = String(itemId);
      cart.items = cart.items.filter((item) => item._id.toString() !== itemStr && item.product.toString() !== itemStr);
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    clearCart: async (_, __, { user }) => {
      requireAuth(user);
      await Cart.findOneAndUpdate({ user: user._id }, { items: [], couponCode: null, couponDiscount: 0 });
      return true;
    },

    applyCoupon: async (_, { code }, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOne({ user: user._id });
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });

      const coupon = await Coupon.findOne({ code: code.toUpperCase() });
      if (!coupon) {
        throw new GraphQLError('Invalid coupon code', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      await cart.populate({
        path: 'items.product',
        populate: [{ path: 'category' }, { path: 'subcategory' }, { path: 'taxSetting' }],
      });

      const getItemPrice = (item) => (typeof item.price === 'number' && item.price > 0) ? item.price : Number(item.product?.price || 0);
      const subtotal = cart.items.reduce((sum, item) => sum + getItemPrice(item) * (item.quantity || 1), 0);
      const validation = coupon.isValid(subtotal);

      if (!validation.valid) {
        throw new GraphQLError(validation.message, { extensions: { code: 'BAD_USER_INPUT' } });
      }

      const discount = Math.min(Math.max(0, coupon.calculateDiscount(subtotal)), subtotal);
      cart.couponCode = coupon.code;
      cart.couponDiscount = discount;
      await cart.save();
      await populateCart(cart);
      return formatCart(cart);
    },

    removeCoupon: async (_, __, { user }) => {
      requireAuth(user);
      const cart = await Cart.findOneAndUpdate(
        { user: user._id },
        { couponCode: null, couponDiscount: 0 },
        { new: true }
      );
      if (!cart) throw new GraphQLError('Cart not found', { extensions: { code: 'NOT_FOUND' } });
      await populateCart(cart);
      return formatCart(cart);
    },
  },
};

export default cartResolvers;
