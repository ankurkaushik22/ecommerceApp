import { GraphQLError } from 'graphql';
import Review from '../../models/Review.js';
import Order from '../../models/Order.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const reviewResolvers = {
  Query: {
    getProductReviews: async (_, { productId, pagination = {} }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;
      return Review.find({ product: productId, targetType: 'product' })
        .populate('user', 'name avatar')
        .populate('product')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },

    getVendorReviews: async (_, { vendorId }) => {
      return Review.find({ vendor: vendorId, targetType: 'seller' })
        .populate('user', 'name avatar')
        .populate('vendor', 'name')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 });
    },

    getDeliveryReviews: async (_, { deliveryAgentId }) => {
      return Review.find({ deliveryAgent: deliveryAgentId, targetType: 'delivery' })
        .populate('user', 'name avatar')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 });
    },

    getOrderReviews: async (_, { orderId }) => {
      return Review.find({ order: orderId })
        .populate('user', 'name avatar email')
        .populate('product', 'name images slug')
        .populate('vendor', 'name email')
        .populate('deliveryAgent', 'name email avatar')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 });
    },

    getAllReviews: async (_, { targetType, pagination = {} }, { user }) => {
      requireAuth(user);
      if (!['superadmin', 'admin', 'vendor'].includes(user.role)) {
        throw new GraphQLError('Access denied to all reviews management', { extensions: { code: 'FORBIDDEN' } });
      }
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;
      const query = {};
      if (targetType && targetType !== 'all') query.targetType = targetType;

      // If logged in as vendor, filter reviews for vendor's products or vendor profile
      if (user.role === 'vendor') {
        query.$or = [{ vendor: user._id }];
      }

      return Review.find(query)
        .populate('user', 'name avatar email')
        .populate('product', 'name images slug')
        .populate('vendor', 'name email')
        .populate('deliveryAgent', 'name email')
        .populate('order', 'orderNumber')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },
  },

  Mutation: {
    addReview: async (_, { input }, { user }) => {
      requireAuth(user);
      let {
        targetType,
        productId,
        vendorId,
        deliveryAgentId,
        orderId,
        rating,
        title,
        comment,
        images,
      } = input;

      // Smart inference if targetType was omitted by client
      if (!targetType) {
        if (deliveryAgentId && !productId) {
          targetType = 'delivery';
        } else if (vendorId && !productId) {
          targetType = 'seller';
        } else {
          targetType = 'product';
        }
      }

      // If orderId is supplied, lookup missing vendor / deliveryAgent from Order
      if (orderId && (targetType === 'seller' || targetType === 'delivery')) {
        try {
          const Order = (await import('../../models/Order.js')).default;
          const orderDoc = await Order.findById(orderId).select('vendor deliveryAgent deliveryBoy items');
          if (orderDoc) {
            if (targetType === 'seller' && !vendorId) {
              vendorId = orderDoc.vendor || orderDoc.items?.[0]?.vendor;
            }
            if (targetType === 'delivery' && !deliveryAgentId) {
              deliveryAgentId = orderDoc.deliveryAgent || orderDoc.deliveryBoy;
            }
          }
        } catch (e) {
          console.error('Error fetching order details for review target lookup:', e);
        }
      }

      // Duplicate review prevention
      const query = { user: user._id, targetType };
      if (orderId) {
        query.order = orderId;
      }
      if (targetType === 'product' && productId) query.product = productId;
      else if (targetType === 'seller' && vendorId) query.vendor = vendorId;
      else if (targetType === 'delivery' && deliveryAgentId) query.deliveryAgent = deliveryAgentId;

      const existingReview = await Review.findOne(query);
      if (existingReview) {
        throw new GraphQLError(`You have already reviewed this ${targetType === 'delivery' ? 'delivery' : targetType} for this order.`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Check if user purchased the product or has a delivered order (verified review)
      let hasPurchased = false;
      if (productId) {
        hasPurchased = await Order.findOne({
          customer: user._id,
          'items.product': productId,
          status: 'delivered',
        });
      }

      let review;
      try {
        review = await Review.create({
          targetType,
          product: targetType === 'product' ? productId || undefined : undefined,
          vendor: targetType === 'seller' ? vendorId || undefined : undefined,
          deliveryAgent: targetType === 'delivery' ? deliveryAgentId || undefined : undefined,
          order: orderId || undefined,
          user: user._id,
          rating: Math.max(1, Math.min(5, Number(rating) || 5)),
          title: (title || '').slice(0, 150),
          comment: (comment || '').slice(0, 2000),
          images: (images || []).slice(0, 5),
          verified: !!hasPurchased,
        });
      } catch (err) {
        if (err?.code === 11000 || err?.name === 'MongoServerError' || String(err?.message).includes('E11000')) {
          throw new GraphQLError(`You have already submitted a review for this ${targetType === 'delivery' ? 'delivery' : targetType}.`, {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        throw err;
      }

      if (orderId && targetType === 'delivery') {
        try {
          const Order = (await import('../../models/Order.js')).default;
          await Order.findByIdAndUpdate(orderId, { deliveryRating: Math.max(1, Math.min(5, Number(rating) || 5)) });
        } catch (e) {}
      }

      // Notify admins and vendor
      const User = (await import('../../models/User.js')).default;
      const { publishNotification } = await import('./notification.resolver.js');
      const admins = await User.find({ role: { $in: ['superadmin', 'admin'] } }).select('_id');
      for (const admin of admins) {
        publishNotification(admin._id, {
          title: 'New Review Submitted',
          message: `${rating}★ ${targetType} review submitted by ${user.name || 'Customer'}`,
          type: 'review',
          data: { reviewId: review._id, orderId }
        }).catch(console.error);
      }

      // Notify Vendor if order has vendor assigned
      if (orderId || vendorId) {
        try {
          const OrderModel = (await import('../../models/Order.js')).default;
          const orderDoc = orderId ? await OrderModel.findById(orderId).select('vendor items orderNumber') : null;
          const targetVendorId = vendorId || orderDoc?.vendor || orderDoc?.items?.[0]?.vendor;
          if (targetVendorId && targetVendorId.toString() !== user._id.toString()) {
            publishNotification(targetVendorId, {
              title: 'New Store Review',
              message: `${rating}★ ${targetType} review received${orderDoc ? ` for order #${orderDoc.orderNumber}` : ''}`,
              type: 'review',
              data: { reviewId: review._id, orderId }
            }).catch(console.error);
          }
        } catch (e) {}
      }

      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },

    replyToReview: async (_, { reviewId, comment }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) {
        throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isVendorOwner = user.role === 'vendor' && review.vendor?.toString() === user._id.toString();

      if (!isStaff && !isVendorOwner) {
        throw new GraphQLError('Only administrators and the assigned vendor can reply to this review', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      review.reply = {
        comment: (comment || '').slice(0, 2000),
        repliedBy: user._id,
        repliedAt: new Date(),
      };

      await review.save();

      // Notify customer of reply
      if (review.user && review.user.toString() !== user._id.toString()) {
        try {
          const { publishNotification } = await import('./notification.resolver.js');
          const replierTitle = user.role === 'vendor' ? 'Seller' : 'Support Team';
          publishNotification(review.user, {
            title: 'Reply to Your Review',
            message: `${replierTitle} replied: "${(comment || '').slice(0, 80)}"`,
            type: 'review_reply',
            data: { reviewId: review._id, orderId: review.order }
          }).catch(console.error);
        } catch (e) {}
      }

      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },

    updateReview: async (_, { reviewId, input }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      if (review.user.toString() !== user._id.toString()) {
        throw new GraphQLError('You can only edit your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }

      const updated = await Review.findByIdAndUpdate(
        reviewId,
        {
          rating: Math.max(1, Math.min(5, Number(input.rating) || 5)),
          title: (input.title || '').slice(0, 150),
          comment: (input.comment || '').slice(0, 2000),
          images: input.images || review.images,
        },
        { new: true }
      )
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');

      return updated;
    },

    deleteReview: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isOwner = review.user.toString() === user._id.toString();

      if (!isStaff && !isOwner) {
        throw new GraphQLError('You can only delete your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }
      await review.deleteOne();
      return true;
    },

    markReviewHelpful: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });

      const alreadyMarked = review.helpful.includes(user._id);
      if (alreadyMarked) {
        review.helpful = review.helpful.filter((id) => id.toString() !== user._id.toString());
      } else {
        review.helpful.push(user._id);
      }

      await review.save();
      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },
  },
};

export default reviewResolvers;
