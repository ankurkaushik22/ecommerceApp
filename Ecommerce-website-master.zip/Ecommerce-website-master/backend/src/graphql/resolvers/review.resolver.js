import { GraphQLError } from 'graphql';
import Review from '../../models/Review.js';
import Order from '../../models/Order.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const reviewResolvers = {
  Query: {
    getProductReviews: async (_, { productId, pagination = {} }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;
      return Review.find({ product: productId, targetType: 'product' })
        .populate('user', 'name avatar')
        .populate('product')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },

    getVendorReviews: async (_, { vendorId }) => {
      return Review.find({ vendor: vendorId, targetType: 'seller' })
        .populate('user', 'name avatar')
        .populate('vendor', 'name')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 });
    },

    getDeliveryReviews: async (_, { deliveryAgentId }) => {
      return Review.find({ deliveryAgent: deliveryAgentId, targetType: 'delivery' })
        .populate('user', 'name avatar')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 });
    },

    getAllReviews: async (_, { targetType, pagination = {} }, { user }) => {
      requireAuth(user);
      if (!['superadmin', 'admin', 'vendor'].includes(user.role)) {
        throw new GraphQLError('Access denied to all reviews management', { extensions: { code: 'FORBIDDEN' } });
      }
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;
      const query = {};
      if (targetType && targetType !== 'all') query.targetType = targetType;

      // If logged in as vendor, filter reviews for vendor's products or vendor profile
      if (user.role === 'vendor') {
        query.$or = [{ vendor: user._id }];
      }

      return Review.find(query)
        .populate('user', 'name avatar email')
        .populate('product', 'name images slug')
        .populate('vendor', 'name email')
        .populate('deliveryAgent', 'name email')
        .populate('order', 'orderNumber')
        .populate('reply.repliedBy', 'name role avatar')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },
  },

  Mutation: {
    addReview: async (_, { input }, { user }) => {
      requireAuth(user);
      const {
        targetType = 'product',
        productId,
        vendorId,
        deliveryAgentId,
        orderId,
        rating,
        title,
        comment,
        images,
      } = input;

      // Duplicate review prevention
      const query = { user: user._id, targetType };
      if (targetType === 'product') query.product = productId;
      else if (targetType === 'seller') query.vendor = vendorId;
      else if (targetType === 'delivery') query.deliveryAgent = deliveryAgentId;

      const existingReview = await Review.findOne(query);
      if (existingReview) {
        throw new GraphQLError(`You have already reviewed this ${targetType}`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Check if user purchased the product or has a delivered order (verified review)
      let hasPurchased = false;
      if (productId) {
        hasPurchased = await Order.findOne({
          customer: user._id,
          'items.product': productId,
          status: 'delivered',
        });
      }

      const review = await Review.create({
        targetType,
        product: productId || undefined,
        vendor: vendorId || undefined,
        deliveryAgent: deliveryAgentId || undefined,
        order: orderId || undefined,
        user: user._id,
        rating: Math.max(1, Math.min(5, Number(rating) || 5)),
        title: (title || '').slice(0, 150),
        comment: (comment || '').slice(0, 2000),
        images: (images || []).slice(0, 5),
        verified: !!hasPurchased,
      });

      // Notify admins
      const User = (await import('../../models/User.js')).default;
      const { publishNotification } = await import('./notification.resolver.js');
      const admins = await User.find({ role: { $in: ['superadmin', 'admin'] } }).select('_id');
      for (const admin of admins) {
        publishNotification(admin._id, {
          title: 'New Review Submitted',
          message: `${rating} star review submitted by ${user.name || 'User'}`,
          type: 'review',
          data: { reviewId: review._id }
        }).catch(console.error);
      }

      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },

    replyToReview: async (_, { reviewId, comment }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) {
        throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isVendorOwner = user.role === 'vendor' && review.vendor?.toString() === user._id.toString();

      if (!isStaff && !isVendorOwner) {
        throw new GraphQLError('Only administrators and the assigned vendor can reply to this review', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      review.reply = {
        comment: (comment || '').slice(0, 2000),
        repliedBy: user._id,
        repliedAt: new Date(),
      };

      await review.save();

      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },

    updateReview: async (_, { reviewId, input }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      if (review.user.toString() !== user._id.toString()) {
        throw new GraphQLError('You can only edit your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }

      const updated = await Review.findByIdAndUpdate(
        reviewId,
        {
          rating: Math.max(1, Math.min(5, Number(input.rating) || 5)),
          title: (input.title || '').slice(0, 150),
          comment: (input.comment || '').slice(0, 2000),
          images: input.images || review.images,
        },
        { new: true }
      )
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');

      return updated;
    },

    deleteReview: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isOwner = review.user.toString() === user._id.toString();

      if (!isStaff && !isOwner) {
        throw new GraphQLError('You can only delete your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }
      await review.deleteOne();
      return true;
    },

    markReviewHelpful: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });

      const alreadyMarked = review.helpful.includes(user._id);
      if (alreadyMarked) {
        review.helpful = review.helpful.filter((id) => id.toString() !== user._id.toString());
      } else {
        review.helpful.push(user._id);
      }

      await review.save();
      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product')
        .populate('vendor', 'name')
        .populate('deliveryAgent', 'name')
        .populate('reply.repliedBy', 'name role avatar');
    },
  },
};

export default reviewResolvers;
