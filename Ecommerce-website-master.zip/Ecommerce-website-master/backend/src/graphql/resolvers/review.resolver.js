import { GraphQLError } from 'graphql';
import Review from '../../models/Review.js';
import Order from '../../models/Order.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const reviewResolvers = {
  Query: {
    getProductReviews: async (_, { productId, pagination = {} }) => {
      const { page = 1, limit = 10 } = pagination;
      const skip = (page - 1) * limit;
      return Review.find({ product: productId })
        .populate('user', 'name avatar')
        .populate('product')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    },
  },

  Mutation: {
    addReview: async (_, { input }, { user }) => {
      requireAuth(user);
      const { productId, rating, title, comment, images } = input;

      // Check if already reviewed
      const existingReview = await Review.findOne({ product: productId, user: user._id });
      if (existingReview) {
        throw new GraphQLError('You have already reviewed this product', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Check if user purchased the product (verified review)
      const hasPurchased = await Order.findOne({
        customer: user._id,
        'items.product': productId,
        status: 'delivered',
      });

      const review = await Review.create({
        product: productId,
        user: user._id,
        rating,
        title,
        comment,
        images: images || [],
        verified: !!hasPurchased,
      });

      return Review.findById(review._id)
        .populate('user', 'name avatar')
        .populate('product');
    },

    updateReview: async (_, { reviewId, input }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      if (review.user.toString() !== user._id.toString()) {
        throw new GraphQLError('You can only edit your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }

      const updated = await Review.findByIdAndUpdate(
        reviewId,
        {
          rating: input.rating,
          title: input.title,
          comment: input.comment,
          images: input.images || review.images,
        },
        { new: true }
      )
        .populate('user', 'name avatar')
        .populate('product');

      return updated;
    },

    deleteReview: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });
      if (review.user.toString() !== user._id.toString() && user.role !== 'admin') {
        throw new GraphQLError('You can only delete your own reviews', { extensions: { code: 'FORBIDDEN' } });
      }
      await review.deleteOne();
      return true;
    },

    markReviewHelpful: async (_, { reviewId }, { user }) => {
      requireAuth(user);
      const review = await Review.findById(reviewId);
      if (!review) throw new GraphQLError('Review not found', { extensions: { code: 'NOT_FOUND' } });

      const alreadyMarked = review.helpful.includes(user._id);
      if (alreadyMarked) {
        review.helpful = review.helpful.filter((id) => id.toString() !== user._id.toString());
      } else {
        review.helpful.push(user._id);
      }

      await review.save();
      return Review.findById(reviewId)
        .populate('user', 'name avatar')
        .populate('product');
    },
  },

  Review: {
    helpfulCount: (review) => review.helpful?.length || 0,
  },
};

export default reviewResolvers;
