import { GraphQLError } from 'graphql';
import User from '../../models/User.js';
import Order from '../../models/Order.js';
import Product from '../../models/Product.js';
import PayoutRequest from '../../models/PayoutRequest.js';

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export const payoutResolver = {
  Query: {
    getVendorPayoutSummary: async (_, { vendorId }, { user }) => {
      const targetVendorId = vendorId || user?._id;
      if (!targetVendorId) {
        throw new Error('Vendor ID is required');
      }

      const vendorDoc = await User.findById(targetVendorId);
      if (!vendorDoc) {
        throw new Error('Vendor not found');
      }

      // Find all non-cancelled orders associated with this vendor
      const orders = await Order.find({
        $or: [
          { vendor: targetVendorId },
          { 'items.vendor': targetVendorId },
        ],
        status: { $ne: 'cancelled' },
      }).populate('items.product');

      let totalSales = 0;
      let totalCommission = 0;
      let totalEarnings = 0;
      let eligibleEarnings = 0;
      let returnPendingBalance = 0;

      const now = Date.now();

      for (const order of orders) {
        // Skip refunded orders
        if (order.returnStatus === 'refunded') continue;

        const isOrderDeliveredOrCompleted = ['delivered', 'completed'].includes(order.status);
        const orderVertical = order.vertical || 'shopping';

        for (const item of order.items) {
          // Verify item belongs to vendor (if order is assigned to vendor or item has vendor ID)
          const itemVendorId = item.vendor ? item.vendor.toString() : (order.vendor ? order.vendor.toString() : null);
          if (itemVendorId !== targetVendorId.toString()) continue;

          const itemSales = (item.price || 0) * (item.quantity || 1);

          // Calculate Commission
          let itemCommission = 0;
          const product = item.product;
          if (product) {
            if (product.commissionType === 'flat') {
              itemCommission = (product.commissionValue || 0) * (item.quantity || 1);
            } else if (product.commissionType === 'percentage') {
              itemCommission = (itemSales * (product.commissionValue || 0)) / 100;
            } else {
              itemCommission = (itemSales * 10) / 100; // Default 10%
            }
          } else {
            itemCommission = (itemSales * 10) / 100;
          }

          const itemNet = Math.max(0, itemSales - itemCommission);

          totalSales += itemSales;
          totalCommission += itemCommission;
          totalEarnings += itemNet;

          // Check eligibility rules
          if (isOrderDeliveredOrCompleted) {
            if (order.status === 'completed' || orderVertical !== 'shopping') {
              // Completed orders or non-shopping verticals: eligible immediately upon delivery/completion
              eligibleEarnings += itemNet;
            } else {
              // Check 7-day return period
              const deliveredTime = new Date(order.updatedAt || order.createdAt).getTime();
              const isReturnWindowPassed = (now - deliveredTime) >= SEVEN_DAYS_MS;
              const hasNoReturnRequest = !order.returnStatus || order.returnStatus === 'none';

              if (isReturnWindowPassed && hasNoReturnRequest) {
                eligibleEarnings += itemNet;
                if (order.status === 'delivered') {
                  Order.findByIdAndUpdate(order._id, { status: 'completed' }).catch(console.error);
                }
              } else if (hasNoReturnRequest) {
                returnPendingBalance += itemNet;
              }
            }
          }
        }
      }

      // Fetch existing PayoutRequests
      const payoutRequests = await PayoutRequest.find({ vendor: targetVendorId });

      let pendingPayout = 0;
      let totalPaidOut = 0;

      for (const pr of payoutRequests) {
        if (['pending', 'approved'].includes(pr.status)) {
          pendingPayout += pr.amount;
        } else if (pr.status === 'paid') {
          totalPaidOut += pr.amount;
        }
      }

      const eligibleBalance = Math.max(0, Math.round((eligibleEarnings - pendingPayout - totalPaidOut) * 100) / 100);

      return {
        totalSales: Math.round(totalSales * 100) / 100,
        totalCommission: Math.round(totalCommission * 100) / 100,
        totalEarnings: Math.round(totalEarnings * 100) / 100,
        eligibleBalance,
        pendingPayout: Math.round(pendingPayout * 100) / 100,
        totalPaidOut: Math.round(totalPaidOut * 100) / 100,
        returnPendingBalance: Math.round(returnPendingBalance * 100) / 100,
        bankDetails: vendorDoc.bankDetails || null,
      };
    },

    getPayoutRequests: async (_, { status, vendorId }, { user }) => {
      if (!user) throw new Error('Not authenticated');

      const filter = {};
      if (status) filter.status = status;

      if (user.role === 'vendor') {
        filter.vendor = user._id;
      } else if (vendorId) {
        filter.vendor = vendorId;
      }

      const requests = await PayoutRequest.find(filter)
        .populate('vendor', '_id name email phone avatar vendorCategory bankDetails')
        .populate('processedBy', '_id name email')
        .sort({ createdAt: -1 });

      return requests;
    },

    getVendorBankDetails: async (_, { vendorId }, { user }) => {
      const targetId = vendorId || user?._id;
      if (!targetId) throw new Error('Vendor ID required');
      const vendorDoc = await User.findById(targetId);
      return vendorDoc?.bankDetails || null;
    },

    getAdminPayoutSummary: async (_, __, { user }) => {
      if (!user || !['admin', 'superadmin'].includes(user.role)) {
        throw new Error('Not authorized');
      }

      const vendors = await User.find({ role: 'vendor' }).sort({ name: 1 });
      const vendorPayoutsList = [];

      let totalEligiblePayoutsPending = 0;
      let totalPendingRequestsAmount = 0;
      let totalPaidOut = 0;

      for (const vendor of vendors) {
        const summary = await payoutResolver.Query.getVendorPayoutSummary(null, { vendorId: vendor._id }, { user });
        vendorPayoutsList.push({
          vendor,
          eligibleBalance: summary.eligibleBalance,
          pendingPayout: summary.pendingPayout,
          totalEarnings: summary.totalEarnings,
          totalPaidOut: summary.totalPaidOut,
          returnPendingBalance: summary.returnPendingBalance,
        });

        totalEligiblePayoutsPending += (summary.eligibleBalance + summary.pendingPayout);
        totalPendingRequestsAmount += summary.pendingPayout;
        totalPaidOut += summary.totalPaidOut;
      }

      return {
        totalEligiblePayoutsPending,
        totalPendingRequestsAmount,
        totalPaidOut,
        vendorPayoutsList,
      };
    },
  },

  Mutation: {
    updateVendorBankDetails: async (_, { input, vendorId }, { user }) => {
      if (!user) throw new Error('Not authenticated');

      const targetId = (user.role === 'admin' || user.role === 'superadmin') && vendorId
        ? vendorId
        : user._id;

      const vendorDoc = await User.findById(targetId);
      if (!vendorDoc) throw new Error('Vendor not found');

      vendorDoc.bankDetails = {
        accountHolderName: input.accountHolderName || '',
        accountNumber: input.accountNumber || '',
        bankName: input.bankName || '',
        ifscCode: input.ifscCode || '',
        upiId: input.upiId || '',
      };

      await vendorDoc.save();
      return vendorDoc.bankDetails;
    },

    requestVendorPayout: async (_, { amount }, { user }) => {
      if (!user) throw new GraphQLError('Not authenticated', { extensions: { code: 'UNAUTHENTICATED' } });
      if (user.role !== 'vendor') throw new GraphQLError('Only vendors can request payouts', { extensions: { code: 'FORBIDDEN' } });

      const vendorDoc = await User.findById(user._id);
      const bank = vendorDoc?.bankDetails || {};
      if (!bank.accountNumber && !bank.upiId) {
        throw new GraphQLError('Please link your Bank Account or UPI ID in profile settings before requesting payouts.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      if (typeof amount !== 'number' || isNaN(amount) || amount < 100) {
        throw new GraphQLError('Minimum withdrawal amount is ₹100.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      if (amount > 99999.99) {
        throw new GraphQLError('Withdrawal amount cannot exceed 5 digits (Max ₹99,999).', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Fetch summary to verify eligible balance
      const summary = await payoutResolver.Query.getVendorPayoutSummary(null, {}, { user });
      const roundedReqAmount = Math.round(amount * 100) / 100;
      const roundedEligible = Math.round((summary?.eligibleBalance || 0) * 100) / 100;

      if (summary.eligibleBalance <= 0 || roundedEligible <= 0) {
        throw new GraphQLError('You currently have no eligible balance available for withdrawal.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      if (roundedReqAmount > roundedEligible) {
        throw new GraphQLError(`Requested amount ₹${roundedReqAmount.toFixed(2)} exceeds your eligible balance of ₹${roundedEligible.toFixed(2)}.`, {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const payoutReq = new PayoutRequest({
        vendor: user._id,
        amount: amount,
        status: 'pending',
        bankDetails: vendorDoc?.bankDetails || {},
      });

      await payoutReq.save();

      // Dispatch Notification to Admins/Superadmins
      try {
        const { publishNotification } = await import('./notification.resolver.js');
        const adminUsers = await User.find({ role: { $in: ['admin', 'superadmin'] } });
        for (const adminUser of adminUsers) {
          publishNotification(adminUser._id, {
            title: 'New Vendor Payout Request 💸',
            message: `Vendor "${vendorDoc?.name || 'Merchant'}" requested payout of ₹${amount.toFixed(2)}`,
            type: 'payout',
            data: { payoutId: payoutReq._id, vendorId: user._id },
          }).catch(console.error);
        }
      } catch (notifErr) {
        console.error('Error notifying admins of payout request:', notifErr);
      }

      return await PayoutRequest.findById(payoutReq._id)
        .populate('vendor', '_id name email phone avatar vendorCategory bankDetails');
    },

    adminReleaseVendorPayout: async (_, { vendorId, amount, adminNotes }, { user }) => {
      if (!user || !['admin', 'superadmin'].includes(user.role)) {
        throw new Error('Not authorized to release vendor payouts');
      }

      const vendorDoc = await User.findById(vendorId);
      if (!vendorDoc) throw new Error('Vendor not found');

      const summary = await payoutResolver.Query.getVendorPayoutSummary(null, { vendorId }, { user });
      const releaseAmount = (typeof amount === 'number' && amount > 0) ? amount : summary.eligibleBalance;

      const roundedRelease = Math.round(releaseAmount * 100) / 100;
      const roundedEligible = Math.round((summary?.eligibleBalance || 0) * 100) / 100;

      if (releaseAmount <= 0 || roundedEligible <= 0) {
        throw new Error(`Vendor "${vendorDoc.name}" has no eligible balance available to release`);
      }

      if (roundedRelease > roundedEligible) {
        throw new Error(`Release amount ₹${roundedRelease.toFixed(2)} exceeds vendor's eligible balance ₹${roundedEligible.toFixed(2)}`);
      }

      const payoutReq = new PayoutRequest({
        vendor: vendorId,
        amount: releaseAmount,
        status: 'paid',
        bankDetails: vendorDoc.bankDetails || {},
        adminNotes: adminNotes ? adminNotes.trim() : 'Direct payout released by Admin',
        processedAt: new Date(),
        processedBy: user._id,
      });

      await payoutReq.save();

      // Dispatch Notification to Vendor
      try {
        const { publishNotification } = await import('./notification.resolver.js');
        publishNotification(vendorId, {
          title: 'Payout Released 🎉',
          message: `Admin has transferred ₹${releaseAmount.toFixed(2)} eligible payout to your account.${adminNotes ? ` Note: ${adminNotes}` : ''}`,
          type: 'payout',
          data: { payoutId: payoutReq._id, amount: releaseAmount },
        }).catch(console.error);
      } catch (notifErr) {
        console.error('Error notifying vendor of payout release:', notifErr);
      }

      return await PayoutRequest.findById(payoutReq._id)
        .populate('vendor', '_id name email phone avatar vendorCategory bankDetails')
        .populate('processedBy', '_id name email');
    },

    updatePayoutRequestStatus: async (_, { id, status, adminNotes }, { user }) => {
      if (!user || !['admin', 'superadmin'].includes(user.role)) {
        throw new Error('Not authorized to update payout requests');
      }

      const payoutReq = await PayoutRequest.findById(id);
      if (!payoutReq) throw new Error('Payout request not found');

      if (payoutReq.status === 'paid') {
        throw new Error('This payout request has already been processed and marked as paid.');
      }

      payoutReq.status = status;
      if (adminNotes !== undefined) payoutReq.adminNotes = adminNotes;
      payoutReq.processedAt = new Date();
      payoutReq.processedBy = user._id;

      await payoutReq.save();

      return await PayoutRequest.findById(id)
        .populate('vendor', '_id name email phone avatar vendorCategory bankDetails')
        .populate('processedBy', '_id name email');
    },
  },
};
