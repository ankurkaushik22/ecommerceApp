import { GraphQLError } from 'graphql';
import { PubSub } from 'graphql-subscriptions';
import Order from '../../models/Order.js';
import Cart from '../../models/Cart.js';
import Product from '../../models/Product.js';
import User from '../../models/User.js';
import Notification from '../../models/Notification.js';
import { requireAuth, requireAdmin } from '../../middleware/auth.middleware.js';

export const pubsub = new PubSub();

const ORDER_STATUS_UPDATED = 'ORDER_STATUS_UPDATED';
const NEW_ORDER_NOTIFICATION = 'NEW_ORDER_NOTIFICATION';

const populateOrder = (orderQuery) =>
  orderQuery
    .populate('customer', 'name email phone avatar')
    .populate('vendor', 'name email')
    .populate('deliveryBoy', 'name email phone')
    .populate({ path: 'items.product', select: 'name images slug' });

const statusMessages = {
  confirmed: 'Your order has been confirmed! We\'re preparing it for you.',
  preparing: 'Great news! Your order is being prepared.',
  dispatched: 'Your order has been dispatched and is on its way!',
  out_for_delivery: 'Your order is out for delivery. Expect it soon!',
  delivered: 'Your order has been delivered. Enjoy!',
  cancelled: 'Your order has been cancelled.',
  refunded: 'Your refund has been processed.',
};

const orderResolvers = {
  Query: {
    getOrders: async (_, { status, pagination = {} }, { user }) => {
      requireAuth(user);
      const { page = 1, limit = 10 } = pagination;
      const skip = (page - 1) * limit;

      const query = { customer: user._id };
      if (status) query.status = status;

      const [orders, total] = await Promise.all([
        populateOrder(Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)),
        Order.countDocuments(query),
      ]);

      return {
        orders,
        total,
        page,
        pages: Math.ceil(total / limit),
      };
    },

    getOrder: async (_, { id }, { user }) => {
      requireAuth(user);
      const order = await populateOrder(Order.findById(id));
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });
      if (user.role !== 'admin' && order.customer._id.toString() !== user._id.toString()) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }
      return order;
    },

    getOrderByNumber: async (_, { orderNumber }, { user }) => {
      requireAuth(user);
      const order = await populateOrder(Order.findOne({ orderNumber }));
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });
      return order;
    },

    trackOrder: async (_, { orderId }, { user }) => {
      requireAuth(user);
      return populateOrder(Order.findById(orderId));
    },

    getAllOrders: async (_, { status, pagination = {} }, { user }) => {
      requireAdmin(user);
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;

      const query = {};
      if (status) query.status = status;

      const [orders, total] = await Promise.all([
        populateOrder(Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)),
        Order.countDocuments(query),
      ]);

      return {
        orders,
        total,
        page,
        pages: Math.ceil(total / limit),
      };
    },
  },

  Mutation: {
    placeOrder: async (_, { input, address }, { user }) => {
      requireAuth(user);
      const { paymentMethod, notes, shippingAddressId } = input;

      // Get cart
      const cart = await Cart.findOne({ user: user._id }).populate('items.product');
      if (!cart || cart.items.length === 0) {
        throw new GraphQLError('Your cart is empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      // Determine shipping address
      let shippingAddress;
      if (shippingAddressId) {
        const fullUser = await User.findById(user._id);
        const savedAddress = fullUser.addresses.id(shippingAddressId);
        if (!savedAddress) throw new GraphQLError('Address not found');
        shippingAddress = savedAddress.toObject();
      } else if (address) {
        shippingAddress = address;
      } else {
        const fullUser = await User.findById(user._id);
        const defaultAddress = fullUser.addresses.find((a) => a.isDefault);
        if (!defaultAddress) {
          throw new GraphQLError('Please provide a shipping address', {
            extensions: { code: 'BAD_USER_INPUT' },
          });
        }
        shippingAddress = defaultAddress.toObject();
      }

      // Validate stock and build order items
      const orderItems = [];
      for (const item of cart.items) {
        const product = item.product;
        if (!product || !product.isActive) {
          throw new GraphQLError(`Product "${item.product.name || 'Unknown'}" is no longer available`);
        }
        if (product.stock < item.quantity) {
          throw new GraphQLError(`Insufficient stock for "${product.name}". Available: ${product.stock}`);
        }
        orderItems.push({
          product: product._id,
          name: product.name,
          image: product.images?.[0] || '',
          price: item.price,
          quantity: item.quantity,
          variantLabel: item.variantIndex >= 0 ? `Variant ${item.variantIndex + 1}` : null,
        });
      }

      const subtotal = cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
      const discount = cart.couponDiscount || 0;
      const shippingCost = subtotal > 50 ? 0 : 9.99;
      const tax = Math.round((Math.max(0, subtotal - discount) * 0.08) * 100) / 100; // 8% tax
      const total = Math.round((subtotal - discount + shippingCost + tax) * 100) / 100;

      // Create order
      const estimatedDelivery = new Date();
      estimatedDelivery.setDate(estimatedDelivery.getDate() + 5);

      const order = await Order.create({
        customer: user._id,
        items: orderItems,
        shippingAddress,
        paymentMethod,
        paymentStatus: paymentMethod === 'cod' ? 'pending' : 'pending',
        subtotal,
        discount,
        shippingCost,
        tax: Math.round(tax * 100) / 100,
        total: Math.round(total * 100) / 100,
        couponCode: cart.couponCode,
        estimatedDelivery,
        notes,
        trackingUpdates: [
          {
            status: 'pending',
            message: 'Order placed successfully',
            timestamp: new Date(),
          },
        ],
      });

      // Deduct stock
      for (const item of cart.items) {
        await Product.findByIdAndUpdate(item.product._id, {
          $inc: { stock: -item.quantity, salesCount: item.quantity },
        });
      }

      // Clear cart
      await Cart.findOneAndUpdate(
        { user: user._id },
        { items: [], couponCode: null, couponDiscount: 0 }
      );

      // Create notification for customer
      await Notification.create({
        user: user._id,
        title: 'Order Placed! 🎉',
        message: `Your order #${order.orderNumber} has been placed successfully.`,
        type: 'order',
        data: { orderId: order._id },
      });

      // Populate and publish
      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(NEW_ORDER_NOTIFICATION, { newOrderNotification: populatedOrder });

      return populatedOrder;
    },

    cancelOrder: async (_, { orderId, reason }, { user }) => {
      requireAuth(user);
      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      if (user.role !== 'admin' && order.customer.toString() !== user._id.toString()) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }

      const cancellableStatuses = ['pending', 'confirmed'];
      if (!cancellableStatuses.includes(order.status)) {
        throw new GraphQLError('This order cannot be cancelled at this stage', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Restore stock
      for (const item of order.items) {
        if (item.product) {
          await Product.findByIdAndUpdate(item.product, {
            $inc: { stock: item.quantity },
          });
        }
      }

      order.status = 'cancelled';
      order.cancelReason = reason;
      order.trackingUpdates.push({
        status: 'cancelled',
        message: `Order cancelled: ${reason}`,
        timestamp: new Date(),
      });

      await order.save();

      // Create notification
      await Notification.create({
        user: order.customer,
        title: 'Order Cancelled',
        message: `Your order #${order.orderNumber} has been cancelled.`,
        type: 'order',
        data: { orderId: order._id },
      });

      const populatedOrder = await populateOrder(Order.findById(orderId));
      pubsub.publish(ORDER_STATUS_UPDATED, {
        orderStatusUpdated: populatedOrder,
        orderId: orderId,
      });

      return populatedOrder;
    },

    updateOrderStatus: async (_, { orderId, status, message, location }, { user }) => {
      requireAdmin(user);
      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      order.status = status;
      order.trackingUpdates.push({
        status,
        message: message || statusMessages[status] || `Status updated to ${status}`,
        timestamp: new Date(),
        location: location || null,
      });

      if (status === 'delivered') {
        order.deliveredAt = new Date();
        order.paymentStatus = 'paid'; // COD orders paid on delivery
      }

      await order.save();

      // Notify customer
      await Notification.create({
        user: order.customer,
        title: 'Order Update 📦',
        message: message || statusMessages[status] || `Your order status is now: ${status}`,
        type: 'order',
        data: { orderId: order._id, status },
      });

      const populatedOrder = await populateOrder(Order.findById(orderId));

      // Publish subscription
      pubsub.publish(`${ORDER_STATUS_UPDATED}_${orderId}`, {
        orderStatusUpdated: populatedOrder,
      });

      return populatedOrder;
    },

    assignDeliveryBoy: async (_, { orderId, deliveryBoyId }, { user }) => {
      requireAdmin(user);

      const deliveryBoy = await User.findOne({ _id: deliveryBoyId, role: 'delivery' });
      if (!deliveryBoy) {
        throw new GraphQLError('Delivery person not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const order = await Order.findByIdAndUpdate(
        orderId,
        { deliveryBoy: deliveryBoyId },
        { new: true }
      );

      return populateOrder(Order.findById(orderId));
    },
  },

  Subscription: {
    orderStatusUpdated: {
      subscribe: (_, { orderId }) => {
        return pubsub.asyncIterator(`${ORDER_STATUS_UPDATED}_${orderId}`);
      },
    },
    newOrderNotification: {
      subscribe: () => pubsub.asyncIterator([NEW_ORDER_NOTIFICATION]),
    },
  },

  Order: {
    items: (order) => {
      if (!order.items) return [];
      return order.items.map((item) => ({
        ...item.toObject ? item.toObject() : item,
        total: item.price * item.quantity,
      }));
    },
  },
};

export default orderResolvers;
