import mongoose from 'mongoose';
import { GraphQLError } from 'graphql';
import { PubSub } from 'graphql-subscriptions';
import Order from '../../models/Order.js';
import Cart from '../../models/Cart.js';
import Product from '../../models/Product.js';
import User from '../../models/User.js';
import Coupon from '../../models/Coupon.js';
import TaxSetting from '../../models/TaxSetting.js';
import DeliveryOption from '../../models/DeliveryOption.js';
import Notification from '../../models/Notification.js';
import { requireAuth, requireAdmin, requireAdminOrVendor } from '../../middleware/auth.middleware.js';
import { sendOrderEmail } from '../../utils/mailer.js';

export const pubsub = new PubSub();

const ORDER_STATUS_UPDATED = 'ORDER_STATUS_UPDATED';
const NEW_ORDER_NOTIFICATION = 'NEW_ORDER_NOTIFICATION';

export function isProductStockUnlimited(product) {
  if (!product) return true;
  if (product.isUnlimitedStock === true) return true;
  if (product.isStockCompulsory === false) return true;
  const vert = product.vertical || product.category?.vertical;
  const isFoodOrService =
    vert === 'services' ||
    vert === 'food' ||
    Boolean(product.restaurantName) ||
    product.isVeg !== undefined ||
    (Array.isArray(product.cuisine) && product.cuisine.length > 0) ||
    (Array.isArray(product.addons) && product.addons.length > 0) ||
    Boolean(product.serviceDuration);

  if (isFoodOrService) {
    if (product.isStockCompulsory === true && product.isUnlimitedStock === false && typeof product.stock === 'number' && product.stock > 0) {
      return false;
    }
    return true;
  }
  if (product.isUnlimitedStock === false || product.isStockCompulsory === true) return false;
  return false;
}

export function isProductStockCompulsory(product) {
  return !isProductStockUnlimited(product);
}

export function resolveVariantInfo(product, variantIndex = -1, targetPrice = null) {
  if (!product || !product.variants || !Array.isArray(product.variants) || product.variants.length === 0) {
    return {
      variantLabel: null,
      image: product?.images?.[0] || '',
      price: product?.price || 0,
      stock: (product?.stock !== undefined && product?.stock !== null) ? product.stock : null,
    };
  }

  const flat = [];
  for (let s = 0; s < product.variants.length; s++) {
    const vGroup = product.variants[s];
    if (!vGroup) continue;

    if (Array.isArray(vGroup.options) && vGroup.options.length > 0) {
      const groupName = vGroup.name || '';
      const options = vGroup.options || [];
      for (let c = 0; c < options.length; c++) {
        flat.push({
          groupName,
          option: options[c],
        });
      }
    } else if (vGroup.label || vGroup.name || vGroup.option) {
      flat.push({
        groupName: vGroup.name && vGroup.label ? vGroup.name : '',
        option: vGroup.label ? vGroup : (vGroup.option || vGroup),
      });
    }
  }

  let match = (variantIndex >= 0 && variantIndex < flat.length) ? flat[variantIndex] : null;
  if (!match && typeof targetPrice === 'number' && targetPrice > 0) {
    match = flat.find((f) => {
      const optPrice = f.option?.price;
      if (typeof optPrice === 'number' && optPrice > 0) {
        return Math.abs(optPrice - targetPrice) < 0.01;
      }
      return false;
    });
  }

  if (!match) {
    return {
      variantLabel: null,
      image: product?.images?.[0] || '',
      price: product?.price || 0,
      stock: (product?.stock !== undefined && product?.stock !== null) ? product.stock : null,
    };
  }

  const { groupName, option } = match;
  const optionLabel = option?.label || option?.name || '';
  const thumbnail = option?.thumbnail || (option?.thumbnails && option.thumbnails[0]) || product?.images?.[0] || '';

  let variantLabel = '';
  const gNameLower = (groupName || '').toLowerCase().trim();
  const optLabelLower = (optionLabel || '').toLowerCase().trim();

  const genericNames = ['variant', 'varient', 'subvariant', 'subvarient', 'default', 'portion', 'size', 'options', 'option', 'choice', 'type', 'weight', 'quantity'];

  if (!gNameLower || genericNames.some((gn) => gNameLower.includes(gn))) {
    if (optLabelLower && optLabelLower !== 'default') {
      variantLabel = optionLabel;
    } else {
      variantLabel = groupName || optionLabel;
    }
  } else if (optLabelLower && optLabelLower !== 'default') {
    variantLabel = `${groupName}: ${optionLabel}`;
  } else {
    variantLabel = groupName || optionLabel;
  }

  return {
    variantLabel: variantLabel || optionLabel || null,
    image: thumbnail || product?.images?.[0] || '',
    price: typeof option?.price === 'number' && option.price > 0 ? option.price : product?.price || 0,
    stock: (typeof option?.stock === 'number' && option.stock !== null) ? option.stock : ((product?.stock !== undefined && product?.stock !== null) ? product.stock : null),
  };
}

export function formatOrder(order) {
  if (!order) return order;
  const obj = order.toObject ? order.toObject() : { ...order };
  if (Array.isArray(obj.items)) {
    obj.items = obj.items.map((item) => {
      const itemObj = item.toObject ? item.toObject() : { ...item };
      const p = itemObj.product;
      let variantLabel = itemObj.variantLabel;
      let image = itemObj.image;

      if (p && typeof p === 'object') {
        const res = resolveVariantInfo(p, itemObj.variantIndex ?? -1, itemObj.price);
        if (res.variantLabel) {
          if (!variantLabel || variantLabel.toLowerCase().startsWith('variant')) {
            variantLabel = res.variantLabel;
          }
        }
        if (res.image) {
          if (!image || image === p.images?.[0]) {
            image = res.image;
          }
        }
      }

      return {
        ...itemObj,
        variantLabel: variantLabel || null,
        image: image || (p?.images?.[0] || ''),
      };
    });
  }
  return obj;
}

const populateOrder = (orderQuery) =>
  orderQuery
    .populate('customer', 'name email phone avatar')
    .populate('vendor', 'name email phone vendorCategory vendorVertical vendorVerticals')
    .populate('deliveryAgent', 'name email phone avatar')
    .populate('deliveryBoy', 'name email phone avatar')
    .populate('items.vendor', 'name email phone vendorCategory')
    .populate({
      path: 'items.product',
      select: 'name images slug price category variants restaurantName vendor',
      populate: { path: 'vendor', select: 'name email phone vendorCategory' },
    });

const statusMessages = {
  confirmed: "Your order has been confirmed! We're preparing it for you.",
  preparing: 'Great news! Your order is being prepared.',
  dispatched: 'Your order has been dispatched and is on its way!',
  out_for_delivery: 'Your order is out for delivery. Expect it soon!',
  delivered: 'Your order has been delivered. Enjoy your purchase!',
  cancelled: 'Your order has been cancelled.',
  refunded: 'Your refund has been processed.',
};

const is24HexId = (str) => typeof str === 'string' && /^[0-9a-fA-F]{24}$/.test(str.trim());

const getItemVertical = (item) => {
  if (!item) return 'shopping';
  const prod = item.product || item;

  const vert = item.vertical || prod.vertical || prod.category?.vertical;
  if (vert && ['food', 'grocery', 'services'].includes(vert)) {
    return vert;
  }

  if (
    prod.restaurantName ||
    (Array.isArray(prod.cuisine) && prod.cuisine.length > 0) ||
    prod.isVeg !== undefined ||
    (Array.isArray(item.addons) && item.addons.length > 0) ||
    item.instructions
  ) {
    return 'food';
  }
  if (
    prod.unitMeasure ||
    (Array.isArray(prod.nutritionalHighlights) && prod.nutritionalHighlights.length > 0)
  ) {
    return 'grocery';
  }
  if (
    prod.serviceDuration ||
    (Array.isArray(prod.includedFeatures) && prod.includedFeatures.length > 0)
  ) {
    return 'services';
  }

  const name = (prod.name || item.name || '').toLowerCase();
  const cat = (prod.category?.name || prod.category?.slug || item.category?.name || item.category?.slug || '').toLowerCase();

  if (
    cat.includes('food') || cat.includes('restaurant') || cat.includes('biryani') || cat.includes('pizza') || cat.includes('burger') || cat.includes('pasta') ||
    name.includes('biryani') || name.includes('pizza') || name.includes('burger') || name.includes('pasta') || name.includes('margherita') ||
    name.includes('tikka') || name.includes('momo') || name.includes('shake') || name.includes('wrap') || name.includes('roll') ||
    name.includes('thali') || name.includes('paneer tikka') || name.includes('kathi wrap') || name.includes('kathi') ||
    name.includes('dosa') || name.includes('chhole') || name.includes('paneer') || name.includes('chowmein')
  ) {
    return 'food';
  }

  if (
    cat.includes('grocery') || cat.includes('dairy') || cat.includes('vegetable') || cat.includes('fruit') || cat.includes('meat') || cat.includes('poultry') || cat.includes('bakery') || cat.includes('seafood') ||
    name.includes('milk') || name.includes('icecream') || name.includes('ice cream') || name.includes('bread') || name.includes('butter') || name.includes('curd') || name.includes('cheese') || name.includes('atta') || name.includes('rice') || name.includes('dal') || name.includes('oil') || name.includes('banana') || name.includes('apple') || name.includes('avocado') || name.includes('spinach') || name.includes('carrot') || name.includes('strawberry') || name.includes('chicken') || name.includes('mutton') || name.includes('meat') || name.includes('egg') || name.includes('eggs') || name.includes('fish') || name.includes('prawn') || name.includes('tomato') || name.includes('tomatoes') || name.includes('curry cut') || name.includes('boneless')
  ) {
    return 'grocery';
  }

  if (cat.includes('service') || name.includes('plumbing') || name.includes('cleaning') || name.includes('repair')) {
    return 'services';
  }

  return 'shopping';
};

const orderResolvers = {
  Query: {
    getOrders: async (_, { status, search, vertical, pagination = {} }, { user }) => {
      requireAuth(user);
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;

      const fullUser = await User.findById(user._id);
      const userEmail = fullUser?.email || user.email;

      let query = {};
      if (user.role === 'superadmin' || user.role === 'admin' || user.role === 'delivery') {
        query = {};
      } else if (user.role === 'vendor') {
        const vendorObjId = new mongoose.Types.ObjectId(user._id.toString());
        query = {
          $or: [
            { vendor: vendorObjId },
            { 'items.vendor': vendorObjId },
          ],
        };
      } else {
        query = {
          $or: [
            { customer: user._id },
            ...(userEmail ? [{ 'shippingAddress.email': new RegExp(`^${userEmail.trim()}$`, 'i') }] : []),
          ],
        };
      }
      if (status && status !== 'all') {
        if (status === 'pending') {
          query.status = { $in: ['placed', 'pending', 'accepted', 'processing', 'ready_for_pickup'] };
        } else if (status === 'out_for_delivery') {
          query.status = { $in: ['out_for_delivery', 'picked_up', 'shipped'] };
        } else if (status === 'delivered') {
          query.status = { $in: ['delivered', 'completed'] };
        } else {
          query.status = status;
        }
      }
      if (vertical && vertical !== 'all') query.vertical = vertical;

      if (search) {
        const searchRegex = new RegExp(search, 'i');
        const matchingUsers = await User.find({
          $or: [{ name: searchRegex }, { email: searchRegex }],
        }).select('_id');
        const matchingUserIds = matchingUsers.map((u) => u._id);

        if (is24HexId(search)) matchingUserIds.push(search);

        query.$and = [
          {
            $or: [
              { orderNumber: { $regex: searchRegex } },
              { customer: { $in: matchingUserIds } },
            ],
          },
        ];
      }

      const [orders, total] = await Promise.all([
        populateOrder(Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)),
        Order.countDocuments(query),
      ]);

      return {
        orders: orders.map(formatOrder),
        total,
        page,
        pages: Math.ceil(total / limit) || 1,
      };
    },

    getOrder: async (_, { id }, { user }) => {
      requireAuth(user);
      try {
        const decodedId = decodeURIComponent(id || '').trim();
        const query = is24HexId(decodedId) ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };
        const order = await populateOrder(Order.findOne(query));
        if (!order) throw new GraphQLError(`Order not found (${decodedId})`, { extensions: { code: 'NOT_FOUND' } });

        const userIdStr = user._id.toString();
        const custIdStr = (order.customer?._id || order.customer)?.toString();
        const isOwner =
          custIdStr === userIdStr ||
          (user.email && order.shippingAddress?.email?.toLowerCase() === user.email.toLowerCase());
        const isStaff = ['superadmin', 'admin', 'delivery'].includes(user.role);
        const isAssignedVendor = user.role === 'vendor' && (order.vendor?.toString() === userIdStr || order.items?.some(i => i.vendor?.toString() === userIdStr));

        if (!isOwner && !isStaff && !isAssignedVendor) {
          throw new GraphQLError('Access denied to this order', { extensions: { code: 'FORBIDDEN' } });
        }
        return formatOrder(order);
      } catch (err) {
        if (err instanceof GraphQLError) throw err;
        throw new GraphQLError(err.message || 'Error fetching order', { extensions: { code: 'BAD_USER_INPUT' } });
      }
    },

    getOrderByNumber: async (_, { orderNumber }, { user }) => {
      requireAuth(user);
      try {
        const decodedOrderNumber = decodeURIComponent(orderNumber || '').trim();
        const order = await populateOrder(Order.findOne({ orderNumber: decodedOrderNumber }));
        if (!order) throw new GraphQLError(`Order not found (${decodedOrderNumber})`, { extensions: { code: 'NOT_FOUND' } });

        const userIdStr = user._id.toString();
        const custIdStr = (order.customer?._id || order.customer)?.toString();
        const isOwner =
          custIdStr === userIdStr ||
          (user.email && order.shippingAddress?.email?.toLowerCase() === user.email.toLowerCase());
        const isStaff = ['superadmin', 'admin', 'delivery'].includes(user.role);
        const isAssignedVendor = user.role === 'vendor' && (order.vendor?.toString() === userIdStr || order.items?.some(i => i.vendor?.toString() === userIdStr));

        if (!isOwner && !isStaff && !isAssignedVendor) {
          throw new GraphQLError('Access denied to this order', { extensions: { code: 'FORBIDDEN' } });
        }
        return formatOrder(order);
      } catch (err) {
        if (err instanceof GraphQLError) throw err;
        throw new GraphQLError(err.message || 'Error fetching order', { extensions: { code: 'BAD_USER_INPUT' } });
      }
    },

    trackOrder: async (_, { orderId }, { user }) => {
      requireAuth(user);
      try {
        const decodedId = decodeURIComponent(orderId || '').trim();
        const query = is24HexId(decodedId) ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };
        const order = await populateOrder(Order.findOne(query));
        if (!order) throw new GraphQLError(`Order not found (${decodedId})`, { extensions: { code: 'NOT_FOUND' } });

        const userIdStr = user._id.toString();
        const custIdStr = (order.customer?._id || order.customer)?.toString();
        const isOwner =
          custIdStr === userIdStr ||
          (user.email && order.shippingAddress?.email?.toLowerCase() === user.email.toLowerCase());
        const isStaff = ['superadmin', 'admin', 'delivery'].includes(user.role);
        const isAssignedVendor = user.role === 'vendor' && (order.vendor?.toString() === userIdStr || order.items?.some(i => i.vendor?.toString() === userIdStr));

        if (!isOwner && !isStaff && !isAssignedVendor) {
          throw new GraphQLError('Access denied to this order', { extensions: { code: 'FORBIDDEN' } });
        }
        return formatOrder(order);
      } catch (err) {
        if (err instanceof GraphQLError) throw err;
        throw new GraphQLError(err.message || 'Error tracking order', { extensions: { code: 'BAD_USER_INPUT' } });
      }
    },

    getAllOrders: async (_, { status, search, vertical, pagination = {} }, { user }) => {
      requireAuth(user);
      if (!['superadmin', 'admin', 'vendor'].includes(user.role)) {
        throw new GraphQLError('Access denied to management orders', { extensions: { code: 'FORBIDDEN' } });
      }
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;

      const query = {};
      if (status && status !== 'all') {
        if (status === 'pending') {
          query.status = { $in: ['placed', 'pending', 'accepted', 'processing', 'ready_for_pickup'] };
        } else if (status === 'out_for_delivery') {
          query.status = { $in: ['out_for_delivery', 'picked_up', 'shipped'] };
        } else if (status === 'delivered') {
          query.status = { $in: ['delivered', 'completed'] };
        } else if (status === 'cancelled') {
          query.status = { $in: ['cancelled', 'refunded'] };
        } else {
          query.status = status;
        }
      }
      if (vertical && vertical !== 'all') query.vertical = vertical;

      if (search) {
        const searchRegex = new RegExp(search, 'i');
        const matchingUsers = await User.find({
          $or: [{ name: searchRegex }, { email: searchRegex }],
        }).select('_id');
        const userIds = matchingUsers.map(u => u._id);
        
        // If search is a direct user ID
        const isValidObjectId = mongoose.Types.ObjectId.isValid(search) && String(new mongoose.Types.ObjectId(search)) === search;
        if (isValidObjectId) userIds.push(search);

        query.$or = [
          { orderNumber: { $regex: searchRegex } },
          { customer: { $in: userIds } },
        ];
      }

      if (user.role === 'vendor') {
        if (query.$or) {
          query.$and = [
            { $or: query.$or },
            { $or: [{ vendor: user._id }, { 'items.vendor': user._id }] }
          ];
          delete query.$or;
        } else {
          query.$or = [{ vendor: user._id }, { 'items.vendor': user._id }];
        }
      }

      const [orders, total] = await Promise.all([
        populateOrder(Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)),
        Order.countDocuments(query),
      ]);

      return {
        orders: orders.map(formatOrder),
        total,
        page,
        pages: Math.ceil(total / limit),
      };
    },

    getAssignedDeliveries: async (_, { status, pagination = {} }, { user }) => {
      requireAuth(user);
      if (!['delivery', 'admin', 'superadmin'].includes(user.role)) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }
      const { page = 1, limit = 50 } = pagination;
      const skip = (page - 1) * limit;

      const query = {
        $or: [{ deliveryAgent: user._id }, { deliveryBoy: user._id }],
      };
      if (status && status !== 'all') query.status = status;

      const [orders, total] = await Promise.all([
        populateOrder(Order.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)),
        Order.countDocuments(query),
      ]);

      return {
        orders: orders.map(formatOrder),
        total,
        page,
        pages: Math.ceil(total / limit),
      };
    },

    getOrderInvoice: async (_, { orderId }, { user }) => {
      requireAuth(user);
      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };
      const order = await populateOrder(Order.findOne(query));
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      const isOwner = order.customer?._id?.toString() === user._id.toString() || order.customer?.toString() === user._id.toString();
      const isStaff = ['superadmin', 'admin'].includes(user.role);

      if (!isOwner && !isStaff) {
        throw new GraphQLError('Access denied to this invoice', { extensions: { code: 'FORBIDDEN' } });
      }

      return {
        invoiceNumber: order.invoiceNumber || `INV-${order.orderNumber}`,
        invoiceDate: order.invoiceDate || order.createdAt || new Date(),
        order: formatOrder(order),
        companyDetails: {
          name: 'Suaaka E-Commerce Private Limited',
          address: 'Plot 42, Tech City, Meerut, Uttar Pradesh, India - 250001',
          gstin: '09AAACH7409R1ZZ',
          pan: 'AAACH7409R',
          email: 'support@suaaka.com',
          phone: '+91 98765 43210',
          website: 'https://ecommerce-website-zeta-lilac.vercel.app',
        },
      };
    },

    getOrderLiveLocation: async (_, { orderId }, { user }) => {
      requireAuth(user);
      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };
      const order = await Order.findOne(query).select('customer deliveryAgent liveLocation destinationLocation status');
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      const isOwner = order.customer?.toString() === user._id.toString();
      const isStaff = ['superadmin', 'admin', 'delivery'].includes(user.role);

      if (!isOwner && !isStaff) {
        throw new GraphQLError('Access denied to live location', { extensions: { code: 'FORBIDDEN' } });
      }
      return order.liveLocation || null;
    },

    getDeliveryAgentOrders: async (_, { status }, { user }) => {
      requireAuth(user);
      if (!['delivery', 'admin', 'superadmin'].includes(user.role)) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }
      let query;
      if (user.role === 'delivery') {
        query = {
          $or: [
            { deliveryAgent: user._id },
            { deliveryBoy: user._id },
            {
              $and: [
                { deliveryAgent: null },
                { deliveryBoy: null },
                { status: { $in: ['confirmed', 'dispatched', 'ready_for_pickup', 'out_for_delivery'] } },
              ],
            },
          ],
        };
      } else {
        query = {};
      }
      if (status && status !== 'all') query.status = status;
      const rawOrders = await populateOrder(Order.find(query).sort({ createdAt: -1 }));
      return rawOrders.map(formatOrder);
    },

    getVendorCommissions: async (_, { sort = 'top_paying', search }, { user }) => {
      requireAdmin(user);

      const orders = await Order.find({ status: { $ne: 'cancelled' } })
        .populate('vendor')
        .populate({ path: 'items.product', select: 'name price commissionType commissionValue vendor' });

      const vendorMap = new Map();

      for (const order of orders) {
        const items = order.items || [];
        for (const item of items) {
          const prod = item.product;
          const vendorId = (prod?.vendor || order.vendor?._id || order.vendor)?.toString();
          if (!vendorId) continue;

          if (!vendorMap.has(vendorId)) {
            const vendorUser = (order.vendor && order.vendor._id?.toString() === vendorId) ? order.vendor : null;
            vendorMap.set(vendorId, {
              vendorId,
              vendorUser,
              totalOrders: 0,
              totalSales: 0,
              totalCommission: 0,
            });
          }

          const record = vendorMap.get(vendorId);
          const price = Number(item.price || prod?.price || 0);
          const qty = Number(item.quantity || 1);
          const itemSales = price * qty;

          const commType = prod?.commissionType || 'percentage';
          const commVal = prod?.commissionValue !== undefined ? prod.commissionValue : 10;

          let itemComm = 0;
          if (commType === 'flat') {
            itemComm = commVal * qty;
          } else {
            itemComm = (itemSales * commVal) / 100;
          }

          record.totalOrders += 1;
          record.totalSales += itemSales;
          record.totalCommission += itemComm;
        }
      }

      const vendorIds = Array.from(vendorMap.keys());
      const vendorUsers = await User.find({ _id: { $in: vendorIds } });
      const userByIdMap = new Map(vendorUsers.map((u) => [u._id.toString(), u]));

      let itemsList = Array.from(vendorMap.values()).map((rec) => {
        const u = userByIdMap.get(rec.vendorId) || rec.vendorUser;
        const avgRate = rec.totalSales > 0 ? (rec.totalCommission / rec.totalSales) * 100 : 10;
        return {
          vendor: u,
          totalOrders: rec.totalOrders,
          totalSales: Math.round(rec.totalSales * 100) / 100,
          totalCommission: Math.round(rec.totalCommission * 100) / 100,
          avgCommissionRate: Math.round(avgRate * 10) / 10,
        };
      });

      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        itemsList = itemsList.filter((i) => {
          const name = (i.vendor?.name || '').toLowerCase();
          const email = (i.vendor?.email || '').toLowerCase();
          return name.includes(q) || email.includes(q);
        });
      }

      if (sort === 'top_paying' || sort === 'commission_desc') {
        itemsList.sort((a, b) => b.totalCommission - a.totalCommission);
      } else if (sort === 'commission_asc') {
        itemsList.sort((a, b) => a.totalCommission - b.totalCommission);
      } else if (sort === 'sales_desc') {
        itemsList.sort((a, b) => b.totalSales - a.totalSales);
      } else if (sort === 'orders_desc') {
        itemsList.sort((a, b) => b.totalOrders - a.totalOrders);
      }

      const totalCommissionEarned = itemsList.reduce((sum, i) => sum + i.totalCommission, 0);
      const totalGrossSales = itemsList.reduce((sum, i) => sum + i.totalSales, 0);
      const totalOrdersCount = itemsList.reduce((sum, i) => sum + i.totalOrders, 0);

      return {
        vendors: itemsList,
        totalCommissionEarned: Math.round(totalCommissionEarned * 100) / 100,
        totalGrossSales: Math.round(totalGrossSales * 100) / 100,
        totalOrdersCount,
      };
    },
  },

  Mutation: {
    placeOrder: async (_, { input, address }, { user }) => {
      requireAuth(user);
      try {
        const {
          paymentMethod,
          paymentStatus: inputPaymentStatus,
          paymentTxnId,
          notes,
          deliveryInstructions,
          shippingAddressId,
          deliveryOptionId,
          deliverySlot,
          vertical,
          serviceDate,
          serviceTimeSlot,
          tableOrNotes,
          saveAsDefault,
        } = input;

        // Get user cart
        const cart = await Cart.findOne({ user: user._id }).populate({
          path: 'items.product',
          populate: [{ path: 'category' }, { path: 'taxSetting' }],
        });
        if (!cart || !cart.items || cart.items.length === 0) {
          throw new GraphQLError('Cart is empty', { extensions: { code: 'BAD_USER_INPUT' } });
        }

        // Filter cart items by requested vertical if specified
        let itemsToOrder = cart.items;
        if (vertical && vertical !== 'all') {
          // Priority: 1) stored item.vertical, 2) populated product.vertical, 3) heuristics
          const filtered = cart.items.filter((i) => {
            const storedVert = i.vertical; // from cartItemSchema.vertical
            if (storedVert) return storedVert === vertical;
            const productVert = i.product?.vertical; // from populated Product.vertical
            if (productVert) return productVert === vertical;
            return getItemVertical(i) === vertical; // heuristic fallback
          });
          if (filtered.length > 0) {
            itemsToOrder = filtered;
          }
          // If still empty: don't silently fall back to ALL items — skip ordering
          // (prevents food order from also placing shopping order)
        }

        // Determine shipping address
        let rawAddress = null;
        if (address && typeof address === 'object') {
          rawAddress = address;
        } else if (shippingAddressId) {
          const fullUser = await User.findById(user._id);
          const addrList = fullUser?.addresses || [];
          const savedAddress = addrList.find(a => a._id?.toString() === String(shippingAddressId));
          rawAddress = savedAddress ? (savedAddress.toObject ? savedAddress.toObject() : savedAddress) : null;
        }

        if (!rawAddress || !rawAddress.addressLine1) {
          const fullUser = await User.findById(user._id);
          const defaultAddress = fullUser?.addresses?.find((a) => a.isDefault) || fullUser?.addresses?.[0];
          if (defaultAddress) {
            rawAddress = defaultAddress.toObject ? defaultAddress.toObject() : defaultAddress;
          }
        }

        const shippingAddress = {
          fullName: String(rawAddress?.fullName || user.name || 'Customer').trim(),
          phone: String(rawAddress?.phone || user.phone || '9876543210').trim(),
          addressLine1: String(rawAddress?.addressLine1 || 'Main Street').trim(),
          addressLine2: String(rawAddress?.addressLine2 || '').trim(),
          city: String(rawAddress?.city || 'Gurugram').trim(),
          state: String(rawAddress?.state || 'Haryana').trim(),
          postalCode: String(rawAddress?.postalCode || '122001').trim(),
          country: String(rawAddress?.country || 'India').trim(),
        };

        // If saveAsDefault is requested, save/update address in User document
        if (saveAsDefault && user?._id) {
          try {
            const fullUser = await User.findById(user._id);
            if (fullUser) {
              // Unset default on all existing addresses
              (fullUser.addresses || []).forEach((a) => {
                a.isDefault = false;
              });

              // Check if address already exists by ID or match by addressLine1 & postalCode
              const existingIndex = fullUser.addresses.findIndex(
                (a) =>
                  (shippingAddressId && String(a._id) === String(shippingAddressId)) ||
                  (a.addressLine1?.toLowerCase().trim() === shippingAddress.addressLine1.toLowerCase().trim() &&
                    a.postalCode?.trim() === shippingAddress.postalCode.trim())
              );

              if (existingIndex >= 0) {
                fullUser.addresses[existingIndex].isDefault = true;
                fullUser.addresses[existingIndex].fullName = shippingAddress.fullName;
                fullUser.addresses[existingIndex].phone = shippingAddress.phone;
                fullUser.addresses[existingIndex].addressLine1 = shippingAddress.addressLine1;
                fullUser.addresses[existingIndex].addressLine2 = shippingAddress.addressLine2;
                fullUser.addresses[existingIndex].city = shippingAddress.city;
                fullUser.addresses[existingIndex].state = shippingAddress.state;
                fullUser.addresses[existingIndex].postalCode = shippingAddress.postalCode;
              } else {
                fullUser.addresses.push({
                  label: 'Home',
                  fullName: shippingAddress.fullName,
                  phone: shippingAddress.phone,
                  addressLine1: shippingAddress.addressLine1,
                  addressLine2: shippingAddress.addressLine2,
                  city: shippingAddress.city,
                  state: shippingAddress.state,
                  postalCode: shippingAddress.postalCode,
                  country: shippingAddress.country || 'India',
                  isDefault: true,
                });
              }
              await fullUser.save();
            }
          } catch (addrSaveErr) {
            console.error('Error saving address as default in placeOrder:', addrSaveErr);
          }
        }

        const normalizedPaymentMethod = ['stripe', 'cod', 'upi', 'card', 'online', 'wallet', 'netbanking'].includes(paymentMethod?.toLowerCase())
          ? paymentMethod.toLowerCase()
          : 'cod';

        // Validate stock and build order items with fresh product queries
        const freshProductIds = [...new Set(itemsToOrder.map((i) => i.product?._id || i.product).filter(Boolean))];
        const freshProducts = await Product.find({ _id: { $in: freshProductIds } });
        const productMap = new Map(freshProducts.map((p) => [p._id.toString(), p]));

        // Aggregate total requested quantity per product & variant
        const requestedQuantities = new Map();
        for (const item of itemsToOrder) {
          const pId = (item.product?._id || item.product)?.toString();
          const vIdx = item.variantIndex >= 0 ? item.variantIndex : -1;
          const key = `${pId}__${vIdx}`;
          requestedQuantities.set(key, (requestedQuantities.get(key) || 0) + (item.quantity || 1));
        }

        const orderItems = [];
        for (const item of itemsToOrder) {
          const pId = (item.product?._id || item.product)?.toString();
          const product = productMap.get(pId) || item.product;
          if (!product || product.isActive === false) {
            throw new GraphQLError(`Product "${item.product?.name || 'Unknown'}" is no longer available`, {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
          const { variantLabel, image, stock: variantStock } = resolveVariantInfo(product, item.variantIndex);
          const availableStock = (item.variantIndex >= 0 && variantStock !== null && variantStock !== undefined) ? variantStock : product.stock;
          const vIdx = item.variantIndex >= 0 ? item.variantIndex : -1;
          const totalRequested = requestedQuantities.get(`${pId}__${vIdx}`) || item.quantity;
          const isStockCompulsory = isProductStockCompulsory(product);
          if (isStockCompulsory && availableStock !== null && availableStock !== undefined && availableStock < totalRequested) {
            throw new GraphQLError(`Insufficient stock for "${product.name}${variantLabel ? ` (${variantLabel})` : ''}". Available: ${availableStock}, requested: ${totalRequested}`, {
              extensions: { code: 'BAD_USER_INPUT' },
            });
          }
          const rawPrice = (typeof item.price === 'number' && item.price > 0) ? item.price : Number(product.price || 0);
          const itemPrice = isNaN(rawPrice) ? 0 : rawPrice;
          orderItems.push({
            product: product._id,
            name: product.name,
            image: image || product.images?.[0] || '',
            price: itemPrice,
            quantity: item.quantity,
            variantLabel: item.variantLabel || variantLabel || (item.variantIndex >= 0 ? `Variant ${item.variantIndex + 1}` : null),
            variantIndex: item.variantIndex >= 0 ? item.variantIndex : -1,
            addons: Array.isArray(item.addons) ? item.addons.map((a) => ({ name: a.name, price: Number(a.price) || 0, icon: a.icon || '' })) : [],
            instructions: item.instructions || undefined,
            vendor: product.vendor || undefined,
          });
        }

        // Verify no vendor in the order is offline
        const vendorIdsInOrder = new Set();
        for (const oi of orderItems) {
          if (oi.vendor) {
            vendorIdsInOrder.add(oi.vendor.toString());
          }
        }
        if (vendorIdsInOrder.size > 0) {
          const offlineVendors = await User.find({
            _id: { $in: Array.from(vendorIdsInOrder) },
            role: 'vendor',
            isOnline: false,
          }).select('name');
          if (offlineVendors.length > 0) {
            const offlineNames = offlineVendors.map((v) => v.name || 'Seller').join(', ');
            throw new GraphQLError(
              `Store "${offlineNames}" is currently offline and not accepting orders right now. Please remove items from offline store(s) to place your order.`,
              { extensions: { code: 'STORE_OFFLINE' } }
            );
          }
        }

        const subtotal = itemsToOrder.reduce((sum, item) => {
          const p = (typeof item.price === 'number' && item.price > 0)
            ? item.price
            : Number(item.product?.price || 0);
          const q = Number(item.quantity ?? 1);
          return sum + ((isNaN(p) ? 0 : p) * (isNaN(q) ? 1 : q));
        }, 0);

        let discount = 0;
        if (cart.couponCode && subtotal > 0) {
          const coupon = await Coupon.findOne({ code: String(cart.couponCode).toUpperCase() });
          if (coupon && coupon.isValid(subtotal).valid) {
            discount = coupon.calculateDiscount(subtotal);
          }
        }
        discount = Math.min(Math.max(0, discount), subtotal);
        const taxableAmount = Math.max(0, subtotal - discount);

        // Fetch active Delivery Option
        let deliveryOptionDoc = null;
        if (deliveryOptionId) {
          if (/^[0-9a-fA-F]{24}$/.test(String(deliveryOptionId))) {
            deliveryOptionDoc = await DeliveryOption.findById(deliveryOptionId);
          } else {
            deliveryOptionDoc = await DeliveryOption.findOne({
              $or: [
                { name: new RegExp(String(deliveryOptionId), 'i') },
                { estimatedDays: new RegExp(String(deliveryOptionId), 'i') },
              ],
              isActive: true,
            });
          }
        }

        if (!deliveryOptionDoc) {
          if (deliveryOptionId === 'exp' || deliveryOptionId === 'express') {
            deliveryOptionDoc = {
              name: 'Express Delivery (24-48 Hours)',
              estimatedDays: '1-2 Business Days',
              price: 99,
              minOrderForFree: 1499,
            };
          } else if (deliveryOptionId === 'same_day') {
            deliveryOptionDoc = {
              name: 'Same Day Delivery',
              estimatedDays: 'Within 24 Hours',
              price: 149,
              minOrderForFree: 1999,
            };
          } else {
            deliveryOptionDoc =
              (await DeliveryOption.findOne({ isDefault: true, isActive: true })) ||
              (await DeliveryOption.findOne({ isActive: true })) || {
                name: 'Standard Delivery',
                estimatedDays: '3-5 Business Days',
                price: 49,
                minOrderForFree: 499,
              };
          }
        }

        let shippingCost = 0;
        let deliveryOptionInfo = {
          name: deliveryOptionDoc?.name || 'Standard Delivery',
          estimatedDays: deliveryOptionDoc?.estimatedDays || '3-5 Business Days',
          price: Number(deliveryOptionDoc?.price || 49),
        };

        if (deliveryOptionDoc) {
          const isFree =
            deliveryOptionDoc.minOrderForFree > 0 && subtotal >= deliveryOptionDoc.minOrderForFree;
          shippingCost = isFree ? 0 : Number(deliveryOptionDoc.price || 0);
          deliveryOptionInfo.price = shippingCost;
        } else {
          shippingCost = subtotal >= 499 ? 0 : 49;
        }

        // Fetch active default Tax Setting (GST)
        const defaultTaxSetting = (await TaxSetting.findOne({ isDefault: true, isActive: true })) ||
          (await TaxSetting.findOne({ isActive: true })) || {
            rate: 18,
            cgst: 9,
            sgst: 9,
            igst: 18,
            hsnCode: '9983',
          };

        const defaultTaxRate = Number(defaultTaxSetting.rate || 18);

        // Calculate itemized tax amount
        let totalItemTax = 0;
        itemsToOrder.forEach((item) => {
          const p = (typeof item.price === 'number' && item.price > 0)
            ? item.price
            : Number(item.product?.price || 0);
          const q = Number(item.quantity ?? 1);
          const itemSubtotal = (isNaN(p) ? 0 : p) * (isNaN(q) ? 1 : q);
          
          // Use product tax setting if present, otherwise default tax rate
          const productTaxRate = item.product?.taxSetting?.rate !== undefined && item.product?.taxSetting?.rate !== null
            ? Number(item.product.taxSetting.rate)
            : defaultTaxRate;

          const itemTaxable = subtotal > 0 ? itemSubtotal * (taxableAmount / subtotal) : itemSubtotal;
          totalItemTax += itemTaxable * (productTaxRate / 100);
        });

        const taxAmount = Math.round(totalItemTax * 100) / 100;
        const cgstAmount = Math.round((taxAmount / 2) * 100) / 100;
        const sgstAmount = Math.round((taxAmount / 2) * 100) / 100;

        const total = Math.round((taxableAmount + shippingCost + taxAmount) * 100) / 100;

        const estimatedDelivery = new Date();
        estimatedDelivery.setDate(estimatedDelivery.getDate() + 4);

        let determinedVertical = vertical;
        if (!determinedVertical) {
          const itemVerticals = cart.items.map((i) => i.product?.vertical).filter(Boolean);
          determinedVertical = itemVerticals[0] || 'shopping';
        }

        let parsedServiceDate = null;
        if (serviceDate) {
          const d = new Date(serviceDate);
          if (!isNaN(d.getTime())) parsedServiceDate = d;
        }

        // Group order items by vendor ID or restaurant name to support multi-vendor order splitting (Amazon/Swiggy style)
        const itemsByVendor = new Map();
        for (const item of orderItems) {
          const prodDoc = productMap.get(item.product?.toString());
          let vKey = 'default';
          if (item.vendor) {
            vKey = item.vendor.toString();
          } else if (prodDoc?.vendor) {
            vKey = prodDoc.vendor.toString();
          } else if (prodDoc?.restaurantName && prodDoc.restaurantName.trim()) {
            vKey = `restaurant_${prodDoc.restaurantName.trim().toLowerCase()}`;
          }

          if (!itemsByVendor.has(vKey)) {
            itemsByVendor.set(vKey, []);
          }
          itemsByVendor.get(vKey).push(item);
        }

        const numVendors = itemsByVendor.size;
        const createdOrders = [];

        for (const [vIdStr, groupItems] of itemsByVendor.entries()) {
          const groupSubtotal = groupItems.reduce((sum, i) => sum + (Number(i.price || 0) * Number(i.quantity || 1)), 0);
          const proportion = subtotal > 0 ? (groupSubtotal / subtotal) : (1 / numVendors);

          const groupDiscount = Math.round((discount * proportion) * 100) / 100;
          const groupTaxable = Math.max(0, groupSubtotal - groupDiscount);
          const groupTax = Math.round((taxAmount * proportion) * 100) / 100;
          const groupShipping = numVendors === 1 ? shippingCost : Math.round((shippingCost / numVendors) * 100) / 100;
          const groupTotal = Math.round((groupTaxable + groupShipping + groupTax) * 100) / 100;

          let actualVendor = undefined;
          if (vIdStr.startsWith('restaurant_')) {
            const restName = vIdStr.replace('restaurant_', '');
            const matchingVendorUser = await User.findOne({
              role: 'vendor',
              $or: [
                { name: new RegExp('^' + restName + '$', 'i') },
                { vendorCategory: new RegExp('^' + restName + '$', 'i') },
              ],
            }).select('_id');
            if (matchingVendorUser) {
              actualVendor = matchingVendorUser._id;
            }
          } else if (vIdStr !== 'default') {
            actualVendor = vIdStr;
          }

          const groupVertical = groupItems[0]?.product?.vertical || determinedVertical;

          const orderDoc = await Order.create({
            customer: user._id,
            vendor: actualVendor,
            items: groupItems,
            shippingAddress,
            paymentMethod: normalizedPaymentMethod,
            paymentStatus: inputPaymentStatus || (normalizedPaymentMethod === 'upi' && paymentTxnId ? 'paid' : (normalizedPaymentMethod === 'stripe' ? 'paid' : 'pending')),
            paymentIntentId: paymentTxnId || null,
            subtotal: groupSubtotal,
            discount: groupDiscount,
            shippingCost: groupShipping,
            tax: groupTax,
            total: groupTotal,
            couponCode: cart.couponCode,
            vertical: groupVertical,
            deliveryOption: deliveryOptionInfo,
            deliverySlot: deliverySlot || null,
            serviceDate: parsedServiceDate,
            serviceTimeSlot: serviceTimeSlot || null,
            tableOrNotes: tableOrNotes || null,
            taxDetails: {
              rate: defaultTaxRate,
              taxAmount: groupTax,
              cgst: Math.round((groupTax / 2) * 100) / 100,
              sgst: Math.round((groupTax / 2) * 100) / 100,
              igst: groupTax,
              hsnCode: defaultTaxSetting?.hsnCode || '9983',
            },
            estimatedDelivery,
            notes: notes || deliveryInstructions || null,
            trackingUpdates: [
              {
                status: 'pending',
                message: 'Order placed successfully',
                timestamp: new Date(),
              },
            ],
          });

          createdOrders.push(orderDoc);
        }

        const primaryOrder = createdOrders[0];

        // Increment coupon usage count & record usage entry
        if (cart.couponCode) {
          try {
            await Coupon.findOneAndUpdate(
              { code: new RegExp(`^${cart.couponCode.trim()}$`, 'i') },
              {
                $inc: { usedCount: 1 },
                $push: {
                  usedBy: {
                    user: user._id,
                    orderId: primaryOrder._id,
                    usedAt: new Date(),
                  },
                },
              }
            );
          } catch (couponErr) {
            console.error('Failed to update coupon usage:', couponErr);
          }
        }

        // Deduct stock & increment sales for ordered items
        for (const item of itemsToOrder) {
          if (item.product?._id) {
            const prodDoc = await Product.findById(item.product._id);
            if (prodDoc) {
              const isCompulsory = isProductStockCompulsory(prodDoc);
              if (item.variantIndex >= 0 && Array.isArray(prodDoc.variants) && prodDoc.variants.length > 0) {
                if (isCompulsory) {
                  let flatCount = 0;
                  let found = false;
                  for (let s = 0; s < prodDoc.variants.length; s++) {
                    const opts = prodDoc.variants[s].options || [];
                    for (let c = 0; c < opts.length; c++) {
                      if (flatCount === item.variantIndex) {
                        if (opts[c].stock !== null && opts[c].stock !== undefined) {
                          opts[c].stock = Math.max(0, opts[c].stock - item.quantity);
                        }
                        found = true;
                        break;
                      }
                      flatCount++;
                    }
                    if (found) break;
                  }
                  let totalVarStock = 0;
                  let hasVarLimit = false;
                  for (const vGroup of prodDoc.variants) {
                    for (const opt of vGroup.options || []) {
                      if (opt.stock !== null && opt.stock !== undefined) {
                        totalVarStock += (Number(opt.stock) || 0);
                        hasVarLimit = true;
                      }
                    }
                  }
                  if (hasVarLimit) {
                    prodDoc.stock = totalVarStock;
                  }
                }
                prodDoc.salesCount = (prodDoc.salesCount || 0) + item.quantity;
                await prodDoc.save();
              } else {
                if (isCompulsory && prodDoc.stock !== null && prodDoc.stock !== undefined) {
                  prodDoc.stock = Math.max(0, prodDoc.stock - item.quantity);
                }
                prodDoc.salesCount = (prodDoc.salesCount || 0) + item.quantity;
                await prodDoc.save();
              }
            }
          }
        }

        // Clear ONLY ordered items from cart, preserving remaining items for other verticals
        const orderedItemIds = new Set(itemsToOrder.map((i) => i._id?.toString() || i.product?._id?.toString()).filter(Boolean));
        const remainingItems = cart.items.filter((i) => {
          const id1 = i._id?.toString();
          const id2 = i.product?._id?.toString() || i.product?.toString();
          return !orderedItemIds.has(id1) && !orderedItemIds.has(id2);
        });

        await Cart.findOneAndUpdate(
          { user: user._id },
          {
            items: remainingItems,
            couponCode: remainingItems.length === 0 ? null : cart.couponCode,
            couponDiscount: remainingItems.length === 0 ? 0 : cart.couponDiscount,
          }
        );

        const populatedPrimaryOrder = (await populateOrder(Order.findById(primaryOrder._id))) || primaryOrder;

        try {
          const { publishNotification } = await import('./notification.resolver.js');
          const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } }).select('_id');

          for (const currentOrd of createdOrders) {
            const currentPopulated = (await populateOrder(Order.findById(currentOrd._id))) || currentOrd;

            // Create notification for customer
            publishNotification(user._id, {
              title: 'Order Placed! 🎉',
              message: `Your order #${currentOrd.orderNumber} for ₹${currentOrd.total} has been confirmed.`,
              type: 'order',
              data: { orderId: currentOrd._id },
            }).catch(console.error);

            // Generate notifications for admin and superadmin
            for (const admin of admins) {
              publishNotification(admin._id, {
                title: 'New Order Received! 🛍️',
                message: `Order #${currentOrd.orderNumber} for ₹${currentOrd.total} has been placed.`,
                type: 'order',
                data: { orderId: currentOrd._id },
              }).catch(console.error);
            }

            // Generate notification for vendor of this specific order
            if (currentOrd.vendor) {
              publishNotification(currentOrd.vendor, {
                title: 'New Order Received! 🛍️',
                message: `New order #${currentOrd.orderNumber} containing your product(s) for ₹${currentOrd.total} has been placed.`,
                type: 'order',
                data: { orderId: currentOrd._id },
              }).catch(console.error);
            }

            if (pubsub && typeof pubsub.publish === 'function') {
              pubsub.publish(NEW_ORDER_NOTIFICATION, { newOrderNotification: currentPopulated });
            }
          }

          const fullUser = await User.findById(user._id);
          if (fullUser && fullUser.email) {
            for (const currentOrd of createdOrders) {
              const currentPopulated = (await populateOrder(Order.findById(currentOrd._id))) || currentOrd;
              sendOrderEmail(fullUser.email, currentPopulated, 'Placed').catch(console.error);
            }
          }
        } catch (sideEffectErr) {
          console.warn('Post-order side effects warning:', sideEffectErr.message);
        }

        return formatOrder(populatedPrimaryOrder);
      } catch (err) {
        console.error('placeOrder error:', err);
        if (err instanceof GraphQLError) {
          throw err;
        }
        throw new GraphQLError(err.message || 'Failed to place order', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }
    },

    cancelOrder: async (_, { orderId, reason }, { user }) => {
      requireAuth(user);
      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      const isSuperAdmin = user.role === 'superadmin';
      const isAdmin = user.role === 'admin';
      const isOwner = order.customer.toString() === user._id.toString();

      if (!isSuperAdmin && !isAdmin && !isOwner) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }

      const cancellableStatuses = ['pending', 'confirmed'];
      if (!cancellableStatuses.includes(order.status)) {
        throw new GraphQLError('This order cannot be cancelled at this stage', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      for (const item of order.items) {
        if (item.product) {
          await Product.findByIdAndUpdate(item.product, {
            $inc: { stock: item.quantity },
          });
        }
      }

      order.status = 'cancelled';
      order.cancelReason = reason;

      const isPrepaid = order.paymentStatus === 'paid' || (order.paymentMethod && order.paymentMethod !== 'cod');
      if (isPrepaid) {
        order.paymentStatus = 'refunded';
      }
      const refundNote = isPrepaid ? ' Refund initiated to your original payment method.' : '';

      order.trackingUpdates.push({
        status: 'cancelled',
        message: `Order cancelled: ${reason}.${refundNote}`,
        timestamp: new Date(),
      });

      await order.save();

      const { publishNotification } = await import('./notification.resolver.js');
      
      const customerMsg = isPrepaid
        ? `Order #${order.orderNumber} has been cancelled. Refund initiated to your original payment method.`
        : `Order #${order.orderNumber} has been cancelled.`;

      publishNotification(order.customer, {
        title: 'Order Cancelled',
        message: customerMsg,
        type: 'order',
        data: { orderId: order._id },
      }).catch(console.error);
      
      const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } }).select('_id');
      for (const admin of admins) {
        publishNotification(admin._id, {
          title: 'Order Cancelled',
          message: `User cancelled Order #${order.orderNumber}. Reason: ${reason}`,
          type: 'order',
          data: { orderId: order._id },
        }).catch(console.error);
      }

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });

      return formatOrder(populatedOrder);
    },

    updateOrderStatus: async (_, { orderId, status, message, location, deliverySlot }, { user }) => {
      requireAuth(user);
      
      const isSuperAdmin = user.role === 'superadmin';
      const isVendorOrDelivery = ['vendor', 'delivery'].includes(user.role);
      const hasOrderPermission = user.role === 'admin' && user.permissions?.includes('orders');

      if (!isSuperAdmin && !isVendorOrDelivery && !hasOrderPermission) {
        throw new GraphQLError('Permission denied to update order status', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      if (status === 'completed' && !isSuperAdmin) {
        throw new GraphQLError('Only Super Admin can mark orders as completed', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      if (user.role === 'vendor') {
        const isVendorOrder = order.vendor?.toString() === user._id.toString() || order.items?.some(i => i.vendor?.toString() === user._id.toString());
        if (!isVendorOrder) {
          throw new GraphQLError('You can only update status for your own vendor orders', { extensions: { code: 'FORBIDDEN' } });
        }
      }

      if (user.role === 'delivery') {
        const isAssigned = order.deliveryAgent?.toString() === user._id.toString() || order.deliveryBoy?.toString() === user._id.toString();
        if (!isAssigned) {
          throw new GraphQLError('You can only update status for orders assigned to you', { extensions: { code: 'FORBIDDEN' } });
        }
      }

      order.status = status;
      if (status === 'delivered') {
        order.deliveredAt = new Date();
        order.paymentStatus = 'paid';
      }
      if (status === 'refunded') {
        order.paymentStatus = 'refunded';
        order.returnStatus = 'refunded';
      }

      if (deliverySlot) {
        order.deliverySlot = deliverySlot;
      }

      const defaultMsg = (status === 'accepted' && (deliverySlot || order.deliverySlot))
        ? `Order accepted by seller. Delivery slot: ${deliverySlot || order.deliverySlot}`
        : (statusMessages[status] || `Order status updated to ${status}`);
      const updateMessage = message || defaultMsg;

      order.trackingUpdates.push({
        status,
        message: updateMessage,
        location: location || undefined,
        timestamp: new Date(),
      });
      if (message && ['vendor', 'admin', 'superadmin'].includes(user.role)) {
        order.vendorNotes = message;
      }

      await order.save();

      const { publishNotification } = await import('./notification.resolver.js');
      publishNotification(order.customer, {
        title: `Order ${status.toUpperCase()} 📦`,
        message: updateMessage,
        type: 'order',
        data: { orderId: order._id },
      }).catch(console.error);

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });

      if (populatedOrder.customer && populatedOrder.customer.email) {
        sendOrderEmail(populatedOrder.customer.email, populatedOrder, status).catch(console.error);
      }

      return formatOrder(populatedOrder);
    },

    updateOrderDeliverySlot: async (_, { orderId, deliverySlot }, { user }) => {
      requireAuth(user);

      const isSuperAdmin = user.role === 'superadmin';
      const isVendor = user.role === 'vendor';
      const hasOrderPermission = user.role === 'admin' && user.permissions?.includes('orders');

      if (!isSuperAdmin && !isVendor && !hasOrderPermission) {
        throw new GraphQLError('Permission denied to update delivery slot', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };

      const order = await Order.findOne(query);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      if (user.role === 'vendor') {
        const isVendorOrder = order.vendor?.toString() === user._id.toString() || order.items?.some(i => i.vendor?.toString() === user._id.toString());
        if (!isVendorOrder) {
          throw new GraphQLError('You can only update delivery slot for your own orders', { extensions: { code: 'FORBIDDEN' } });
        }
      }

      order.deliverySlot = deliverySlot;
      order.trackingUpdates.push({
        status: order.status,
        message: `Delivery slot confirmed: ${deliverySlot}`,
        timestamp: new Date(),
      });

      await order.save();

      const { publishNotification } = await import('./notification.resolver.js');
      publishNotification(order.customer, {
        title: 'Delivery Slot Assigned ⏰',
        message: `Your delivery has been scheduled for ${deliverySlot}`,
        type: 'order',
        data: { orderId: order._id },
      }).catch(console.error);

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });

      return formatOrder(populatedOrder);
    },

    addOrderComment: async (_, { orderId, message }, { user }) => {
      requireAuth(user);

      const isSuperAdmin = user.role === 'superadmin';
      const isVendor = user.role === 'vendor';
      const hasOrderPermission = user.role === 'admin' && user.permissions?.includes('orders');

      if (!isSuperAdmin && !isVendor && !hasOrderPermission) {
        throw new GraphQLError('Permission denied to add order comment', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };

      const order = await Order.findOne(query);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      if (user.role === 'vendor') {
        const isVendorOrder = order.vendor?.toString() === user._id.toString() || order.items?.some(i => i.vendor?.toString() === user._id.toString());
        if (!isVendorOrder) {
          throw new GraphQLError('You can only add comments to your own vendor orders', { extensions: { code: 'FORBIDDEN' } });
        }
      }

      const trimmedMessage = (message || '').trim();
      if (!trimmedMessage) {
        throw new GraphQLError('Comment message cannot be empty', { extensions: { code: 'BAD_USER_INPUT' } });
      }

      order.trackingUpdates.push({
        status: order.status,
        message: trimmedMessage,
        timestamp: new Date(),
      });
      order.vendorNotes = trimmedMessage;

      await order.save();

      const { publishNotification } = await import('./notification.resolver.js');
      publishNotification(order.customer, {
        title: 'New Update from Seller 💬',
        message: trimmedMessage,
        type: 'order',
        data: { orderId: order._id },
      }).catch(console.error);

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });

      return formatOrder(populatedOrder);
    },

    requestReturn: async (_, { orderId, reason }, { user }) => {
      requireAuth(user);
      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      if (order.status === 'completed') {
        throw new GraphQLError('Return period for this order has expired / completed', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }
      
      if (order.customer.toString() !== user._id.toString()) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }

      order.returnStatus = 'requested';
      order.returnReason = reason;
      order.returnDate = new Date();
      await order.save();

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });
      
      const { publishNotification } = await import('./notification.resolver.js');
      const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } }).select('_id');
      for (const admin of admins) {
        publishNotification(admin._id, {
          title: 'Return Request',
          message: `User requested a return for Order #${populatedOrder.orderNumber}`,
          type: 'order',
          data: { orderId: order._id }
        }).catch(console.error);
      }

      return populatedOrder;
    },

    updateReturnStatus: async (_, { orderId, status }, { user }) => {
      requireAuth(user);
      
      const isSuperAdmin = user.role === 'superadmin';
      const isVendor = user.role === 'vendor';
      const hasReturnsPermission = user.role === 'admin' && user.permissions?.includes('returns');

      if (!isSuperAdmin && !isVendor && !hasReturnsPermission) {
        throw new GraphQLError('Permission denied', { extensions: { code: 'FORBIDDEN' } });
      }

      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      order.returnStatus = status;

      const { publishNotification } = await import('./notification.resolver.js');

      if (status === 'approved') {
        order.trackingUpdates.push({
          status: 'return_approved',
          message: 'Return request approved. Refund initiated to original payment source.',
          timestamp: new Date(),
        });
        publishNotification(order.customer, {
          title: 'Return Request Approved',
          message: `Your return request for Order #${order.orderNumber} has been approved. Refund initiated.`,
          type: 'order',
          data: { orderId: order._id },
        }).catch(console.error);
      } else if (status === 'refunded') {
        order.status = 'refunded';
        order.paymentStatus = 'refunded';
        order.trackingUpdates.push({
          status: 'refunded',
          message: `Refund of ₹${order.total || 0} completed and credited to your payment source.`,
          timestamp: new Date(),
        });
        publishNotification(order.customer, {
          title: 'Refund Completed',
          message: `Refund of ₹${order.total || 0} for Order #${order.orderNumber} has been completed.`,
          type: 'order',
          data: { orderId: order._id },
        }).catch(console.error);
      } else if (status === 'rejected') {
        order.trackingUpdates.push({
          status: 'return_rejected',
          message: 'Return request was reviewed and rejected.',
          timestamp: new Date(),
        });
        publishNotification(order.customer, {
          title: 'Return Request Rejected',
          message: `Your return request for Order #${order.orderNumber} was not approved.`,
          type: 'order',
          data: { orderId: order._id },
        }).catch(console.error);
      }

      await order.save();

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });
      return populatedOrder;
    },

    assignDeliveryBoy: async (_, { orderId, deliveryBoyId }, { user }) => {
      requireAdminOrVendor(user);
      const order = await Order.findByIdAndUpdate(
        orderId,
        { deliveryBoy: deliveryBoyId, deliveryAgent: deliveryBoyId },
        { new: true }
      );
      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });
      return populatedOrder;
    },

    assignDeliveryAgent: async (_, { orderId, deliveryAgentId }, { user }) => {
      requireAuth(user);
      if (!['superadmin', 'admin', 'vendor'].includes(user.role)) {
        throw new GraphQLError('Permission denied', { extensions: { code: 'FORBIDDEN' } });
      }
      const order = await Order.findByIdAndUpdate(
        orderId,
        { deliveryAgent: deliveryAgentId, deliveryBoy: deliveryAgentId },
        { new: true }
      );
      return populateOrder(Order.findById(order._id));
    },

    updateDeliveryLocation: async (_, { orderId, latitude, longitude, heading = 0, speed = 0 }, { user }) => {
      requireAuth(user);
      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };

      const order = await Order.findOne(query);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      order.liveLocation = {
        latitude,
        longitude,
        heading: heading || 0,
        speed: speed || 0,
        updatedAt: new Date(),
      };

      order.deliveryLocationUpdates = order.deliveryLocationUpdates || [];
      order.deliveryLocationUpdates.push({
        latitude,
        longitude,
        heading: heading || 0,
        status: order.status,
        timestamp: new Date(),
      });

      await User.findByIdAndUpdate(user._id, {
        currentLocation: { latitude, longitude, heading, updatedAt: new Date() },
        isOnline: true,
      });

      await order.save();
      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });
      return populatedOrder;
    },

    updateDeliveryStatus: async (_, { orderId, status, notes, latitude, longitude }, { user }) => {
      requireAuth(user);
      const decodedId = decodeURIComponent(orderId || '').trim();
      const isValidObjectId = mongoose.Types.ObjectId.isValid(decodedId) && String(new mongoose.Types.ObjectId(decodedId)) === decodedId;
      const query = isValidObjectId ? { $or: [{ _id: decodedId }, { orderNumber: decodedId }] } : { orderNumber: decodedId };

      const order = await Order.findOne(query);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      order.status = status;
      if (status === 'delivered') {
        order.deliveredAt = new Date();
        order.paymentStatus = 'paid';
      } else if (status === 'cancelled') {
        order.cancelReason = notes || 'Delivery marked as failed by delivery partner';
      }

      if (latitude !== undefined && longitude !== undefined) {
        order.liveLocation = {
          latitude,
          longitude,
          heading: 0,
          speed: 0,
          updatedAt: new Date(),
        };
      }

      const updateMessage = notes || statusMessages[status] || `Delivery status changed to ${status}`;
      order.trackingUpdates.push({
        status,
        message: updateMessage,
        location: latitude && longitude ? `${latitude.toFixed(4)}, ${longitude.toFixed(4)}` : undefined,
        timestamp: new Date(),
      });

      await order.save();

      const { publishNotification } = await import('./notification.resolver.js');
      publishNotification(order.customer, {
        title: `Package ${status.replace(/_/g, ' ').toUpperCase()} 🚚`,
        message: updateMessage,
        type: 'order',
        data: { orderId: order._id },
      }).catch(console.error);

      const populatedOrder = await populateOrder(Order.findById(order._id));
      pubsub.publish(ORDER_STATUS_UPDATED, { orderStatusUpdated: populatedOrder });
      return populatedOrder;
    },

    updateAgentDutyStatus: async (_, { isOnline, latitude, longitude }, { user }) => {
      requireAuth(user);
      const updateData = { isOnline };
      if (latitude !== undefined && longitude !== undefined) {
        updateData.currentLocation = {
          latitude,
          longitude,
          updatedAt: new Date(),
        };
      }
      const updatedUser = await User.findByIdAndUpdate(user._id, updateData, { new: true });
      return updatedUser;
    },
  },

  Subscription: {
    orderStatusUpdated: {
      subscribe: () => pubsub.asyncIterator([ORDER_STATUS_UPDATED]),
    },
    newOrderNotification: {
      subscribe: () => pubsub.asyncIterator([NEW_ORDER_NOTIFICATION]),
    },
  },

  OrderItem: {
    total: (item) => (item.total !== undefined && item.total !== null) ? item.total : (item.price * item.quantity),
  },

  Order: {
    invoiceNumber: (order) => order.invoiceNumber || (order.orderNumber ? `INV-${order.orderNumber}` : null),
    invoiceDate: (order) => order.invoiceDate || order.createdAt || null,
    total: (order) => {
      if (typeof order.total === 'number' && order.total > 0) return order.total;
      const sub = Number(order.subtotal || 0);
      const disc = Number(order.discount || 0);
      const ship = Number(order.shippingCost || 0);
      const tax = Number(order.tax || 0);
      const calculated = Math.max(0, sub - disc + ship + tax);
      return Math.round(calculated * 100) / 100;
    },
    deliveryInstructions: (order) => order.notes || order.deliveryInstructions || order.tableOrNotes || null,
    reviews: async (order) => {
      try {
        const Review = (await import('../../models/Review.js')).default;
        return await Review.find({ order: order._id })
          .populate('user', 'name avatar email')
          .populate('product', 'name images slug')
          .populate('vendor', 'name email')
          .populate('deliveryAgent', 'name email avatar')
          .populate('reply.repliedBy', 'name role avatar')
          .sort({ createdAt: -1 });
      } catch (err) {
        console.error('Error populating order reviews:', err);
        return [];
      }
    },
    deliveryRating: async (order) => {
      if (typeof order.deliveryRating === 'number' && order.deliveryRating > 0) {
        return order.deliveryRating;
      }
      try {
        const Review = (await import('../../models/Review.js')).default;
        const rev = await Review.findOne({ order: order._id, targetType: 'delivery' });
        if (rev && rev.rating) return rev.rating;
      } catch {}
      if (['delivered', 'completed'].includes(order.status)) {
        // Fallback for delivered orders without explicit review: rating 5.0
        return 5.0;
      }
      return null;
    },
  },
};

export default orderResolvers;
