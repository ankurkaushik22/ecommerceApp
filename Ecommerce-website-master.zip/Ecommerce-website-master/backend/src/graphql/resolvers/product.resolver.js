import { GraphQLError } from 'graphql';
import Product from '../../models/Product.js';
import Review from '../../models/Review.js';
import Category from '../../models/Category.js';
import { requireAuth, requireAdminOrVendor } from '../../middleware/auth.middleware.js';

const productResolvers = {
  Query: {
    getProducts: async (_, { filter = {}, sort = {}, pagination = {} }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;

      // Build filter query
      const query = { isActive: true };

      const catId = filter.categoryId || filter.category;
      if (catId) {
        // Include any subcategories under this parent category
        const subcats = await Category.find({ parent: catId }).select('_id');
        const catIds = [catId, ...subcats.map((c) => c._id)];
        query.$or = [
          { category: { $in: catIds } },
          { subcategory: { $in: catIds } },
        ];
      }

      const subcatId = filter.subcategoryId || filter.subcategory;
      if (subcatId) query.subcategory = subcatId;
      if (filter.vendorId) query.vendor = filter.vendorId;
      if (filter.isFeatured !== undefined) query.isFeatured = filter.isFeatured;
      if (filter.isDeals !== undefined) query.isDeals = filter.isDeals;
      if (filter.freeShipping !== undefined) query.freeShipping = filter.freeShipping;
      if (filter.inStock) query.stock = { $gt: 0 };
      if (filter.rating) query['rating.average'] = { $gte: filter.rating };
      if (filter.tags?.length) query.tags = { $in: filter.tags };

      if (filter.minPrice !== undefined || filter.maxPrice !== undefined) {
        query.price = {};
        if (filter.minPrice !== undefined) query.price.$gte = filter.minPrice;
        if (filter.maxPrice !== undefined) query.price.$lte = filter.maxPrice;
      }

      if (filter.search) {
        query.$text = { $search: filter.search };
      }

      // Build sort options
      const sortOptions = {};
      if (sort.field) {
        const fieldMap = {
          price: 'price',
          rating: 'rating.average',
          newest: 'createdAt',
          popular: 'salesCount',
          name: 'name',
        };
        sortOptions[fieldMap[sort.field] || sort.field] = sort.order === 'desc' ? -1 : 1;
      } else {
        sortOptions.createdAt = -1;
      }

      const [products, total] = await Promise.all([
        Product.find(query)
          .populate('category')
          .populate('subcategory')
          .populate('vendor', 'name avatar')
          .sort(sortOptions)
          .skip(skip)
          .limit(limit)
          .lean({ virtuals: true }),
        Product.countDocuments(query),
      ]);

      return {
        products,
        total,
        page,
        pages: Math.ceil(total / limit),
        hasNext: page * limit < total,
      };
    },

    getProduct: async (_, { slug }) => {
      const product = await Product.findOne({ slug, isActive: true })
        .populate('category')
        .populate('subcategory')
        .populate('vendor', 'name avatar')
        .lean({ virtuals: true });

      if (!product) {
        throw new GraphQLError('Product not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      // Calculate rating distribution
      const distribution = await Review.aggregate([
        { $match: { product: product._id } },
        { $group: { _id: '$rating', count: { $sum: 1 } } },
        { $sort: { _id: -1 } },
      ]);

      const totalReviews = distribution.reduce((sum, d) => sum + d.count, 0);

      product.rating = {
        ...product.rating,
        distribution: [5, 4, 3, 2, 1].map((star) => {
          const found = distribution.find((d) => d._id === star);
          const count = found ? found.count : 0;
          return {
            star,
            count,
            percentage: totalReviews > 0 ? Math.round((count / totalReviews) * 100) : 0,
          };
        }),
      };

      const reviewsCount = await Review.countDocuments({ product: product._id });
      product.reviewsCount = reviewsCount;

      return product;
    },

    getProductById: async (_, { id }) => {
      return Product.findById(id)
        .populate('category')
        .populate('subcategory')
        .populate('vendor', 'name avatar')
        .lean({ virtuals: true });
    },

    getFeaturedProducts: async (_, { limit = 12 }) => {
      return Product.find({ isFeatured: true, isActive: true, stock: { $gt: 0 } })
        .populate('category')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    getDealsProducts: async (_, { limit = 12 }) => {
      return Product.find({
        isDeals: true,
        isActive: true,
        stock: { $gt: 0 },
        comparePrice: { $exists: true, $gt: 0 },
      })
        .populate('category')
        .sort({ 'rating.average': -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    getRelatedProducts: async (_, { productId, limit = 8 }) => {
      const product = await Product.findById(productId);
      if (!product) return [];

      return Product.find({
        category: product.category,
        _id: { $ne: productId },
        isActive: true,
      })
        .populate('category')
        .sort({ 'rating.average': -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    searchProducts: async (_, { query, pagination = {} }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;

      const searchQuery = {
        isActive: true,
        $text: { $search: query },
      };

      const [products, total] = await Promise.all([
        Product.find(searchQuery, { score: { $meta: 'textScore' } })
          .populate('category')
          .sort({ score: { $meta: 'textScore' } })
          .skip(skip)
          .limit(limit)
          .lean({ virtuals: true }),
        Product.countDocuments(searchQuery),
      ]);

      return {
        products,
        total,
        page,
        pages: Math.ceil(total / limit),
        hasNext: page * limit < total,
      };
    },
  },

  Mutation: {
    createProduct: async (_, { input }, { user }) => {
      requireAdminOrVendor(user);

      const productData = {
        ...input,
        category: input.categoryId,
        subcategory: input.subcategoryId || null,
        vendor: user._id,
      };

      delete productData.categoryId;
      delete productData.subcategoryId;

      const product = await Product.create(productData);
      return Product.findById(product._id)
        .populate('category')
        .populate('subcategory')
        .lean({ virtuals: true });
    },

    updateProduct: async (_, { id, input }, { user }) => {
      requireAdminOrVendor(user);

      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      if (user.role !== 'admin' && product.vendor?.toString() !== user._id.toString()) {
        throw new GraphQLError('You can only edit your own products', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const updateData = {
        ...input,
        category: input.categoryId,
        subcategory: input.subcategoryId || null,
      };
      delete updateData.categoryId;
      delete updateData.subcategoryId;

      const updated = await Product.findByIdAndUpdate(id, updateData, { new: true })
        .populate('category')
        .populate('subcategory')
        .lean({ virtuals: true });

      return updated;
    },

    deleteProduct: async (_, { id }, { user }) => {
      requireAdminOrVendor(user);
      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }
      await Product.findByIdAndDelete(id);
      return true;
    },

    toggleProductStatus: async (_, { id }, { user }) => {
      requireAdminOrVendor(user);
      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }
      product.isActive = !product.isActive;
      await product.save();
      return Product.findById(id).populate('category').lean({ virtuals: true });
    },
  },

  Product: {
    discount: (product) => {
      if (product.comparePrice && product.comparePrice > product.price) {
        return Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100);
      }
      return 0;
    },
  },
};

export default productResolvers;
