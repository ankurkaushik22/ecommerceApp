import { GraphQLError } from 'graphql';
import Product from '../../models/Product.js';
import Review from '../../models/Review.js';
import Category from '../../models/Category.js';
import User from '../../models/User.js';
import { requireAuth, requireAdminOrVendor } from '../../middleware/auth.middleware.js';
import { publishNotification } from './notification.resolver.js';

const APPROVED_FILTER = {
  $or: [
    { approvalStatus: 'approved' },
    { approvalStatus: { $exists: false } },
    { approvalStatus: null },
  ],
};

export const productResolvers = {
  Query: {
    getProducts: async (_, { filter = {}, sort = {}, pagination = {} }, { user }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;

      // Build filter query
      const query = {};

      // If the caller is an authenticated vendor (seller), scope strictly to their own products
      if (user && user.role === 'vendor') {
        query.vendor = user._id;
      } else if (filter.vendorId) {
        if (/^[0-9a-fA-F]{24}$/.test(filter.vendorId)) {
          query.vendor = filter.vendorId;
        } else {
          const vendorUser = await User.findOne({
            $or: [
              { name: new RegExp(`^${filter.vendorId}$`, 'i') },
              { email: new RegExp(`^${filter.vendorId}$`, 'i') },
            ],
          }).select('_id');
          if (vendorUser) {
            query.vendor = vendorUser._id;
          } else {
            query.vendor = filter.vendorId;
          }
        }
      }

      if (filter.isActive !== undefined) {
        query.isActive = filter.isActive;
      } else if (!filter.all && !filter.includeInactive) {
        query.isActive = true;
      }

      if (filter.vertical) {
        query.vertical = filter.vertical;
      }
      if (filter.approvalStatus) {
        if (filter.approvalStatus === 'approved') {
          query.$and = query.$and || [];
          query.$and.push(APPROVED_FILTER);
        } else {
          query.approvalStatus = filter.approvalStatus;
        }
      } else {
        // Enforce approved products only for public/unspecified queries
        query.$and = query.$and || [];
        query.$and.push(APPROVED_FILTER);
      }

      const catInput = filter.categoryId || filter.category;
      if (catInput && catInput !== 'all') {
        let catDoc = null;
        if (/^[0-9a-fA-F]{24}$/.test(catInput)) {
          catDoc = await Category.findById(catInput);
        } else {
          catDoc = await Category.findOne({
            $or: [{ slug: catInput }, { name: new RegExp(`^${catInput}$`, 'i') }],
          });
        }
        if (catDoc) {
          const subcats = await Category.find({ parent: catDoc._id }).select('_id');
          const catIds = [catDoc._id, ...subcats.map((c) => c._id)];
          query.$and = query.$and || [];
          query.$and.push({
            $or: [
              { category: { $in: catIds } },
              { subcategory: { $in: catIds } },
            ],
          });
        } else if (/^[0-9a-fA-F]{24}$/.test(catInput)) {
          query.category = catInput;
        } else {
          const cleanedKey = catInput.replace(/s$/, '');
          const matchingCats = await Category.find({
            $or: [
              { slug: new RegExp(cleanedKey, 'i') },
              { name: new RegExp(cleanedKey, 'i') },
              { slug: new RegExp(catInput, 'i') },
              { name: new RegExp(catInput, 'i') },
            ],
          }).select('_id');

          if (matchingCats.length > 0) {
            const catIds = matchingCats.map((c) => c._id);
            query.$and = query.$and || [];
            query.$and.push({
              $or: [
                { category: { $in: catIds } },
                { subcategory: { $in: catIds } },
              ],
            });
          }
        }
      }

      const subcatId = filter.subcategoryId || filter.subcategory;
      if (subcatId) query.subcategory = subcatId;
      if (filter.isFeatured !== undefined) query.isFeatured = filter.isFeatured;
      if (filter.isDeals !== undefined) query.isDeals = filter.isDeals;
      if (filter.freeShipping !== undefined) query.freeShipping = filter.freeShipping;
      if (filter.inStock) query.stock = { $gt: 0 };
      
      const ratingFilter = filter.minRating || filter.rating;
      if (ratingFilter) query['rating.average'] = { $gte: ratingFilter };
      if (filter.tags?.length) query.tags = { $in: filter.tags };

      if (filter.isVeg !== undefined) {
        query.isVeg = filter.isVeg;
      }
      if (filter.cuisine?.length) {
        query.cuisine = { $in: filter.cuisine };
      }
      if (filter.restaurantName) {
        query.restaurantName = new RegExp(filter.restaurantName.trim(), 'i');
      }

      if (filter.minPrice !== undefined || filter.maxPrice !== undefined) {
        query.price = {};
        if (filter.minPrice !== undefined) query.price.$gte = filter.minPrice;
        if (filter.maxPrice !== undefined) query.price.$lte = filter.maxPrice;
      }

      if (filter.search) {
        const searchRegex = { $regex: filter.search.trim(), $options: 'i' };
        query.$and = query.$and || [];
        query.$and.push({
          $or: [
            { name: searchRegex },
            { description: searchRegex },
            { brand: searchRegex },
          ],
        });
      }

      // Build sort options
      const sortOptions = {};
      const sortKey = filter.sort || sort.field;
      if (sortKey === 'price_asc') {
        sortOptions.price = 1;
      } else if (sortKey === 'price_desc') {
        sortOptions.price = -1;
      } else if (sortKey === 'rating') {
        sortOptions['rating.average'] = -1;
      } else if (sortKey === 'newest') {
        sortOptions.createdAt = -1;
      } else if (sort.field) {
        const fieldMap = {
          price: 'price',
          rating: 'rating.average',
          newest: 'createdAt',
          popular: 'salesCount',
          name: 'name',
        };
        sortOptions[fieldMap[sort.field] || sort.field] = sort.order === 'desc' ? -1 : 1;
      } else {
        sortOptions.createdAt = -1;
      }

      const [products, total] = await Promise.all([
        Product.find(query)
          .populate('category')
          .populate('subcategory')
          .populate('vendor', 'name email avatar')
          .sort(sortOptions)
          .skip(skip)
          .limit(limit)
          .lean({ virtuals: true }),
        Product.countDocuments(query),
      ]);

      return {
        products,
        total,
        page,
        pages: Math.ceil(total / limit),
        hasNext: page * limit < total,
      };
    },

    getProduct: async (_, { slug }, { user }) => {
      const isObjectId = /^[0-9a-fA-F]{24}$/.test(slug);
      const query = isObjectId ? { $or: [{ _id: slug }, { slug }] } : { slug };
      const product = await Product.findOne(query)
        .populate('category')
        .populate('subcategory')
        .populate('vendor', 'name email avatar')
        .lean({ virtuals: true });

      if (!product) {
        throw new GraphQLError('Product not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      if (product.approvalStatus === 'pending' || product.approvalStatus === 'rejected') {
        const isAuthorized = user && (
          user.role === 'admin' ||
          user.role === 'superadmin' ||
          (user.role === 'vendor' && String(product.vendor?._id || product.vendor) === String(user._id))
        );
        if (!isAuthorized) {
          throw new GraphQLError('Product is pending admin approval', {
            extensions: { code: 'FORBIDDEN' },
          });
        }
      }

      // Calculate rating distribution
      const distribution = await Review.aggregate([
        { $match: { product: product._id } },
        { $group: { _id: '$rating', count: { $sum: 1 } } },
        { $sort: { _id: -1 } },
      ]);

      const totalReviews = distribution.reduce((sum, d) => sum + d.count, 0);

      product.rating = {
        ...product.rating,
        distribution: [5, 4, 3, 2, 1].map((star) => {
          const found = distribution.find((d) => d._id === star);
          const count = found ? found.count : 0;
          return {
            star,
            count,
            percentage: totalReviews > 0 ? Math.round((count / totalReviews) * 100) : 0,
          };
        }),
      };

      const reviewsCount = await Review.countDocuments({ product: product._id });
      product.reviewsCount = reviewsCount;

      return product;
    },

    getProductById: async (_, { id }) => {
      return Product.findById(id)
        .populate('category')
        .populate('subcategory')
        .populate('vendor', 'name email avatar')
        .lean({ virtuals: true });
    },

    getFeaturedProducts: async (_, { limit = 12 }) => {
      return Product.find({ isFeatured: true, isActive: true, stock: { $gt: 0 }, ...APPROVED_FILTER })
        .populate('category')
        .sort({ createdAt: -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    getProductBySlug: async (parent, args, context, info) => {
      return productResolvers.Query.getProduct(parent, args, context, info);
    },

    getDealsProducts: async (_, { limit = 12 }) => {
      return Product.find({
        isDeals: true,
        isActive: true,
        stock: { $gt: 0 },
        comparePrice: { $exists: true, $gt: 0 },
        ...APPROVED_FILTER,
      })
        .populate('category')
        .sort({ 'rating.average': -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    getDeals: async (_, { limit = 20 }) => {
      return Product.find({
        $or: [
          { isDeals: true },
          { isDeal: true },
          { dealDiscount: { $gt: 0 } },
          { comparePrice: { $exists: true, $gt: 0 } },
        ],
        isActive: true,
        stock: { $gt: 0 },
        ...APPROVED_FILTER,
      })
        .populate('category')
        .sort({ 'rating.average': -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    getRelatedProducts: async (_, { productId, limit = 8 }) => {
      const product = await Product.findById(productId);
      if (!product) return [];

      return Product.find({
        category: product.category,
        _id: { $ne: productId },
        isActive: true,
        ...APPROVED_FILTER,
      })
        .populate('category')
        .sort({ 'rating.average': -1 })
        .limit(limit)
        .lean({ virtuals: true });
    },

    searchProducts: async (_, { query, pagination = {} }) => {
      const { page = 1, limit = 20 } = pagination;
      const skip = (page - 1) * limit;

      const searchQuery = {
        isActive: true,
        $text: { $search: query },
        ...APPROVED_FILTER,
      };

      const [products, total] = await Promise.all([
        Product.find(searchQuery, { score: { $meta: 'textScore' } })
          .populate('category')
          .sort({ score: { $meta: 'textScore' } })
          .skip(skip)
          .limit(limit)
          .lean({ virtuals: true }),
        Product.countDocuments(searchQuery),
      ]);

      return {
        products,
        total,
        page,
        pages: Math.ceil(total / limit),
        hasNext: page * limit < total,
      };
    },
  },

  Mutation: {
    createProduct: async (_, { input }, { user }) => {
      requireAdminOrVendor(user);

      const isVendor = user.role === 'vendor';
      const productData = {
        ...input,
        category: input.categoryId,
        subcategory: input.subcategoryId || null,
        vendor: user._id,
        approvalStatus: isVendor ? 'pending' : (input.approvalStatus || 'approved'),
        commissionType: input.commissionType || 'percentage',
        commissionValue: input.commissionValue !== undefined ? input.commissionValue : 10,
      };

      if (Array.isArray(productData.variants) && productData.variants.length > 0) {
        let totalVarStock = 0;
        let hasOptions = false;
        for (const g of productData.variants) {
          for (const opt of g.options || []) {
            totalVarStock += (Number(opt.stock) || 0);
            hasOptions = true;
          }
        }
        if (hasOptions) {
          productData.stock = totalVarStock;
        }
      }

      if (input.categoryId) {
        const catDoc = await Category.findById(input.categoryId);
        if (catDoc && catDoc.vertical) {
          productData.vertical = catDoc.vertical;
        }
      }

      delete productData.categoryId;
      delete productData.subcategoryId;

      const product = await Product.create(productData);

      if (isVendor) {
        try {
          const adminUsers = await User.find({ role: { $in: ['admin', 'superadmin'] } }).select('_id');
          for (const admin of adminUsers) {
            await publishNotification(admin._id, {
              title: 'New Product Approval Request 📦',
              message: `Vendor "${user.name || 'Vendor'}" requested approval for product "${product.name}".`,
              type: 'product',
              data: { productId: product._id, vendorId: user._id },
            });
          }
        } catch (err) {
          console.error('Failed to notify admins of product request:', err);
        }
      }

      return Product.findById(product._id)
        .populate('category')
        .populate('subcategory')
        .lean({ virtuals: true });
    },

    updateProduct: async (_, { id, input }, { user }) => {
      requireAdminOrVendor(user);

      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isVendorOwner = user.role === 'vendor' && product.vendor?.toString() === user._id.toString();

      if (!isStaff && !isVendorOwner) {
        throw new GraphQLError('You can only edit your own products', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const isVendor = user.role === 'vendor';

      const updateData = {
        ...input,
        category: input.categoryId,
        subcategory: input.subcategoryId || null,
      };

      if (isVendor) {
        if (product.approvalStatus === 'approved') {
          let isCriticalDetailChanged = false;

          if (input.name !== undefined && input.name !== product.name) {
            isCriticalDetailChanged = true;
          }
          if (input.description !== undefined && input.description !== product.description) {
            isCriticalDetailChanged = true;
          }
          if (input.shortDescription !== undefined && input.shortDescription !== product.shortDescription) {
            isCriticalDetailChanged = true;
          }
          if (input.categoryId !== undefined && String(input.categoryId) !== String(product.category?._id || product.category || '')) {
            isCriticalDetailChanged = true;
          }
          if (input.subcategoryId !== undefined && String(input.subcategoryId || '') !== String(product.subcategory?._id || product.subcategory || '')) {
            isCriticalDetailChanged = true;
          }
          if (input.images !== undefined) {
            const oldImgs = JSON.stringify(product.images || []);
            const newImgs = JSON.stringify(input.images || []);
            if (oldImgs !== newImgs) {
              isCriticalDetailChanged = true;
            }
          }
          if (input.variants !== undefined && Array.isArray(input.variants)) {
            const oldThumbnails = JSON.stringify((product.variants || []).map(v => (v.options || []).map(o => o.thumbnail || '')));
            const newThumbnails = JSON.stringify((input.variants || []).map(v => (v.options || []).map(o => o.thumbnail || '')));
            if (oldThumbnails !== newThumbnails) {
              isCriticalDetailChanged = true;
            }
          }

          if (isCriticalDetailChanged) {
            updateData.approvalStatus = 'pending';
          } else {
            updateData.approvalStatus = 'approved';
          }
        } else {
          updateData.approvalStatus = 'pending';
        }
      }

      const targetVariants = updateData.variants !== undefined ? updateData.variants : product.variants;
      if (Array.isArray(targetVariants) && targetVariants.length > 0) {
        let totalVarStock = 0;
        let hasOptions = false;
        for (const g of targetVariants) {
          for (const opt of g.options || []) {
            totalVarStock += (Number(opt.stock) || 0);
            hasOptions = true;
          }
        }
        if (hasOptions) {
          updateData.stock = totalVarStock;
        }
      }

      if (input.categoryId) {
        const catDoc = await Category.findById(input.categoryId);
        if (catDoc && catDoc.vertical) {
          updateData.vertical = catDoc.vertical;
        }
      }

      delete updateData.categoryId;
      delete updateData.subcategoryId;

      const updated = await Product.findByIdAndUpdate(id, updateData, { new: true })
        .populate('category')
        .populate('subcategory')
        .lean({ virtuals: true });

      if (isVendor && updated.approvalStatus === 'pending') {
        try {
          const adminUsers = await User.find({ role: { $in: ['admin', 'superadmin'] } }).select('_id');
          for (const admin of adminUsers) {
            await publishNotification(admin._id, {
              title: 'Product Update Request 📝',
              message: `Vendor "${user.name || 'Vendor'}" requested detail/image changes for product "${updated.name}".`,
              type: 'product',
              data: { productId: updated._id, vendorId: user._id, isUpdate: true },
            });
          }
        } catch (err) {
          console.error('Failed to notify admins of product update request:', err);
        }
      }

      return updated;
    },

    deleteProduct: async (_, { id }, { user }) => {
      requireAdminOrVendor(user);
      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isVendorOwner = user.role === 'vendor' && product.vendor?.toString() === user._id.toString();

      if (!isStaff && !isVendorOwner) {
        throw new GraphQLError('You can only delete your own products', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      await Product.findByIdAndDelete(id);
      return true;
    },

    toggleProductStatus: async (_, { id }, { user }) => {
      requireAdminOrVendor(user);
      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      const isStaff = ['superadmin', 'admin'].includes(user.role);
      const isVendorOwner = user.role === 'vendor' && product.vendor?.toString() === user._id.toString();

      if (!isStaff && !isVendorOwner) {
        throw new GraphQLError('You can only toggle status for your own products', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      product.isActive = !product.isActive;
      await product.save();
      return Product.findById(id).populate('category').lean({ virtuals: true });
    },

    updateProductApproval: async (_, { id, status, reason, commissionType, commissionValue }, { user }) => {
      requireAdminOrVendor(user);
      const product = await Product.findById(id);
      if (!product) {
        throw new GraphQLError('Product not found', { extensions: { code: 'NOT_FOUND' } });
      }

      product.approvalStatus = status;
      if (status === 'approved') product.isActive = true;
      if (status === 'rejected') product.isActive = false;

      if (commissionType !== undefined) product.commissionType = commissionType;
      if (commissionValue !== undefined && commissionValue !== null) product.commissionValue = Number(commissionValue);

      await product.save();

      // Notify vendor
      if (product.vendor) {
        try {
          if (status === 'approved') {
            await publishNotification(product.vendor, {
              title: 'Product Request Approved 🎉',
              message: `Your product "${product.name}" has been approved by admin and is now live on the store.`,
              type: 'product',
              data: { productId: product._id, status: 'approved' },
            });
          } else if (status === 'rejected') {
            const reasonMsg = reason?.trim() ? ` Reason: ${reason.trim()}` : '';
            await publishNotification(product.vendor, {
              title: 'Product Request Rejected ❌',
              message: `Your product "${product.name}" request was rejected by admin.${reasonMsg}`,
              type: 'product',
              data: { productId: product._id, status: 'rejected', reason: reason?.trim() || '' },
            });
          }
        } catch (err) {
          console.error('Failed to send vendor approval notification:', err);
        }
      }

      return Product.findById(id).populate('category').lean({ virtuals: true });
    },
  },

  Product: {
    discount: (product) => {
      if (product.comparePrice && product.comparePrice > product.price) {
        return Math.round(((product.comparePrice - product.price) / product.comparePrice) * 100);
      }
      return 0;
    },
  },
};

export default productResolvers;
