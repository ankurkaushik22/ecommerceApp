import { GraphQLScalarType, Kind } from 'graphql';
import authResolvers from './auth.resolver.js';
import productResolvers from './product.resolver.js';
import categoryResolvers from './category.resolver.js';
import cartResolvers from './cart.resolver.js';
import orderResolvers from './order.resolver.js';
import paymentResolvers from './payment.resolver.js';
import reviewResolvers from './review.resolver.js';
import couponResolvers from './coupon.resolver.js';
import adminResolvers from './admin.resolver.js';
import notificationResolvers from './notification.resolver.js';
import legalPageResolvers from './legalPage.resolver.js';
import { bannerResolver } from './banner.resolver.js';
import storeSettingResolvers from './storeSetting.resolver.js';
import supportResolvers from './support.resolver.js';
import { payoutResolver } from './payout.resolver.js';

// Custom Date scalar
const DateScalar = new GraphQLScalarType({
  name: 'Date',
  description: 'Date custom scalar type',
  serialize(value) {
    if (value instanceof Date) return value.toISOString();
    if (typeof value === 'string') return new Date(value).toISOString();
    return value;
  },
  parseValue(value) {
    return new Date(value);
  },
  parseLiteral(ast) {
    if (ast.kind === Kind.STRING) return new Date(ast.value);
    return null;
  },
});

// Custom JSON scalar
const JSONScalar = new GraphQLScalarType({
  name: 'JSON',
  description: 'JSON custom scalar type',
  serialize: (value) => value,
  parseValue: (value) => value,
  parseLiteral: (ast) => {
    if (ast.kind === Kind.STRING) {
      try { return JSON.parse(ast.value); } catch { return ast.value; }
    }
    return null;
  },
});

// Deep merge resolver objects
const mergeResolvers = (...resolverArrays) => {
  return resolverArrays.reduce((merged, resolver) => {
    Object.keys(resolver).forEach((key) => {
      if (!merged[key]) {
        merged[key] = resolver[key];
      } else if (typeof resolver[key] === 'object' && !Array.isArray(resolver[key])) {
        merged[key] = { ...merged[key], ...resolver[key] };
      }
    });
    return merged;
  }, {});
};

const resolvers = mergeResolvers(
  { Date: DateScalar, JSON: JSONScalar },
  authResolvers,
  productResolvers,
  categoryResolvers,
  cartResolvers,
  orderResolvers,
  paymentResolvers,
  reviewResolvers,
  couponResolvers,
  adminResolvers,
  notificationResolvers,
  legalPageResolvers,
  bannerResolver,
  storeSettingResolvers,
  supportResolvers,
  payoutResolver
);

export default resolvers;
