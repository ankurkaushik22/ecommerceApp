import { GraphQLError } from 'graphql';
import Stripe from 'stripe';
import Order from '../../models/Order.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const getStripe = () => {
  if (!process.env.STRIPE_SECRET_KEY || process.env.STRIPE_SECRET_KEY === 'sk_test_placeholder') {
    return null;
  }
  return new Stripe(process.env.STRIPE_SECRET_KEY);
};

const paymentResolvers = {
  Mutation: {
    createPaymentIntent: async (_, { orderId }, { user }) => {
      requireAuth(user);
      const order = await Order.findById(orderId);
      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });
      if (order.customer.toString() !== user._id.toString()) {
        throw new GraphQLError('Access denied', { extensions: { code: 'FORBIDDEN' } });
      }

      const stripe = getStripe();
      if (!stripe) {
        // Return mock for development without Stripe keys
        return {
          clientSecret: 'mock_client_secret_for_development',
          paymentIntentId: 'mock_pi_id',
          amount: order.total,
        };
      }

      const amountInCents = Math.round(order.total * 100);

      const paymentIntent = await stripe.paymentIntents.create({
        amount: amountInCents,
        currency: 'usd',
        metadata: {
          orderId: orderId,
          customerId: user._id.toString(),
          orderNumber: order.orderNumber,
        },
      });

      // Save payment intent ID on order
      await Order.findByIdAndUpdate(orderId, {
        paymentIntentId: paymentIntent.id,
      });

      return {
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id,
        amount: order.total,
      };
    },

    confirmPayment: async (_, { orderId, paymentIntentId }, { user }) => {
      requireAuth(user);
      const order = await Order.findById(orderId)
        .populate('customer', 'name email')
        .populate({ path: 'items.product', select: 'name images' });

      if (!order) throw new GraphQLError('Order not found', { extensions: { code: 'NOT_FOUND' } });

      const isOwner = order.customer?._id?.toString() === user._id.toString() || order.customer?.toString() === user._id.toString();
      const isStaff = ['superadmin', 'admin'].includes(user.role);

      if (!isOwner && !isStaff) {
        throw new GraphQLError('Access denied to confirm payment for this order', { extensions: { code: 'FORBIDDEN' } });
      }

      if (order.paymentStatus === 'paid') {
        return order; // Idempotent return
      }

      const stripe = getStripe();
      if (stripe) {
        try {
          const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
          if (paymentIntent.status !== 'succeeded') {
            throw new GraphQLError('Payment not successful', { extensions: { code: 'BAD_USER_INPUT' } });
          }
        } catch (error) {
          if (error.extensions?.code) throw error;
        }
      }

      order.paymentStatus = 'paid';
      order.paymentIntentId = paymentIntentId;
      order.status = 'confirmed';
      order.trackingUpdates.push({
        status: 'confirmed',
        message: 'Payment received. Your order is confirmed!',
        timestamp: new Date(),
      });

      await order.save();
      return order;
    },
  },
};

export default paymentResolvers;
