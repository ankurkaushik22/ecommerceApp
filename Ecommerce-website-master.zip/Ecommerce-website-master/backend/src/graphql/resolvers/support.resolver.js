import { GraphQLError } from 'graphql';
import SupportTicket from '../../models/SupportTicket.js';
import Notification from '../../models/Notification.js';
import User from '../../models/User.js';
import { requireAuth, requireAdmin } from '../../middleware/auth.middleware.js';

const supportResolvers = {
  Query: {
    getMySupportTickets: async (_, __, { user }) => {
      requireAuth(user);
      return SupportTicket.find({
        $or: [{ user: user._id }, { email: user.email }],
      })
        .populate('user')
        .populate('repliedBy')
        .sort({ createdAt: -1 });
    },

    getAllSupportTickets: async (_, { status, search, pagination }, { user }) => {
      requireAdmin(user);
      const query = {};
      if (status && status !== 'all') {
        query.status = status;
      }
      if (search && search.trim()) {
        const s = search.trim();
        query.$or = [
          { ticketNumber: { $regex: s, $options: 'i' } },
          { subject: { $regex: s, $options: 'i' } },
          { message: { $regex: s, $options: 'i' } },
          { name: { $regex: s, $options: 'i' } },
          { email: { $regex: s, $options: 'i' } },
        ];
      }

      const page = Math.max(1, pagination?.page || 1);
      const limit = Math.min(100, Math.max(1, pagination?.limit || 50));
      const skip = (page - 1) * limit;

      const [tickets, total] = await Promise.all([
        SupportTicket.find(query)
          .populate('user')
          .populate('repliedBy')
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(limit),
        SupportTicket.countDocuments(query),
      ]);

      return tickets;
    },

    getSupportTicket: async (_, { id }, { user }) => {
      requireAuth(user);
      const cleanId = (id || '').trim();
      const isObjectId = /^[0-9a-fA-F]{24}$/.test(cleanId);
      const query = isObjectId ? { _id: cleanId } : { ticketNumber: cleanId };

      const ticket = await SupportTicket.findOne(query).populate('user').populate('repliedBy');
      if (!ticket) {
        throw new GraphQLError('Ticket not found', { extensions: { code: 'NOT_FOUND' } });
      }
      if (
        !['admin', 'superadmin'].includes(user.role) &&
        ticket.user?._id?.toString() !== user._id.toString() &&
        ticket.email !== user?.email
      ) {
        throw new GraphQLError('Not authorized', { extensions: { code: 'FORBIDDEN' } });
      }
      return ticket;
    },
  },

  Mutation: {
    createSupportTicket: async (_, { input }, { user }) => {
      const name = input.name || user?.name || 'Customer';
      const email = input.email || user?.email || 'customer@example.com';
      const phone = input.phone || user?.phone;
      const subject = (input.subject || '').trim();
      const message = (input.message || '').trim();

      if (!subject || !message) {
        throw new GraphQLError('Subject and message are required', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const ticket = await SupportTicket.create({
        user: user ? user._id : undefined,
        name,
        email,
        phone,
        subject,
        message,
        category: input.category || 'general',
        priority: input.priority || 'medium',
        status: 'open',
      });

      // Notify all admins and superadmins
      try {
        const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } });
        const notifications = admins.map((admin) => ({
          user: admin._id,
          title: `New Support Ticket #${ticket.ticketNumber}`,
          message: `${name}: "${subject}"`,
          type: 'system',
          data: { ticketId: ticket._id, ticketNumber: ticket.ticketNumber },
        }));
        if (notifications.length > 0) {
          await Notification.insertMany(notifications);
        }
      } catch (err) {
        console.error('Error creating admin notifications for support ticket:', err.message);
      }

      return ticket;
    },

    replySupportTicket: async (_, { ticketId, reply, status }, { user }) => {
      requireAdmin(user);
      const update = {
        adminReply: reply,
        repliedBy: user._id,
        repliedAt: new Date(),
      };
      if (status) {
        update.status = status;
      }

      const ticket = await SupportTicket.findByIdAndUpdate(ticketId, update, { new: true })
        .populate('user')
        .populate('repliedBy');

      if (!ticket) {
        throw new GraphQLError('Ticket not found', { extensions: { code: 'NOT_FOUND' } });
      }

      // Notify user
      if (ticket.user) {
        try {
          await Notification.create({
            user: ticket.user._id,
            title: `Reply on Support Ticket #${ticket.ticketNumber}`,
            message: `Admin replied: "${reply.slice(0, 80)}..."`,
            type: 'system',
            data: { ticketId: ticket._id },
          });
        } catch (err) {
          console.error('Error notifying user about ticket reply:', err.message);
        }
      }

      return ticket;
    },

    updateSupportTicketStatus: async (_, { id, status, adminNotes }, { user }) => {
      requireAdmin(user);
      const update = { status };
      if (adminNotes !== undefined) update.adminNotes = adminNotes;

      const ticket = await SupportTicket.findByIdAndUpdate(id, update, { new: true })
        .populate('user')
        .populate('repliedBy');

      if (!ticket) {
        throw new GraphQLError('Ticket not found', { extensions: { code: 'NOT_FOUND' } });
      }

      // Notify customer if ticket is tied to a user
      if (ticket.user) {
        try {
          await Notification.create({
            user: ticket.user._id,
            title: `Support Ticket #${ticket.ticketNumber} Updated`,
            message: `Your ticket status is now: ${status.replace(/_/g, ' ').toUpperCase()}`,
            type: 'system',
            data: { ticketId: ticket._id },
          });
        } catch (err) {
          console.error('Error notifying user about ticket status:', err.message);
        }
      }

      return ticket;
    },
  },
};

export default supportResolvers;
