import { GraphQLError } from 'graphql';
import LegalPage from '../../models/LegalPage.js';
import { requireAdmin, requireSuperAdmin } from '../../middleware/auth.middleware.js';

const legalPageResolvers = {
  Query: {
    getLegalPage: async (_, { slug }) => {
      return LegalPage.findOne({ slug, isActive: true });
    },
    getLegalPages: async (_, __, { user }) => {
      requireAdmin(user);
      return LegalPage.find().sort({ slug: 1 }).populate('updatedBy');
    },
  },
  Mutation: {
    updateLegalPage: async (_, { slug, title, content }, { user }) => {
      requireSuperAdmin(user);
      
      const updatedPage = await LegalPage.findOneAndUpdate(
        { slug: slug.toLowerCase().trim() },
        { 
          $set: { title, content, updatedBy: user._id },
          $inc: { version: 1 }
        },
        { new: true, upsert: true }
      ).populate('updatedBy');

      return updatedPage;
    }
  }
};

export default legalPageResolvers;
