import { GraphQLError } from 'graphql';
import jwt from 'jsonwebtoken';
import User from '../../models/User.js';
import { requireAuth } from '../../middleware/auth.middleware.js';

const authResolvers = {
  Query: {
    me: async (_, __, { user }) => {
      requireAuth(user);
      return User.findById(user._id).populate('wishlist');
    },
  },

  Mutation: {
    register: async (_, { input }) => {
      const { name, email, password, phone, role } = input;

      // Check if user exists
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        throw new GraphQLError('An account with this email already exists', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Create user
      const newUser = await User.create({
        name,
        email,
        password,
        phone,
        role: role || 'customer',
      });

      // Generate tokens
      const token = newUser.generateAuthToken();
      const refreshToken = newUser.generateRefreshToken();

      // Save refresh token
      await User.findByIdAndUpdate(newUser._id, { refreshToken });

      return { token, refreshToken, user: newUser };
    },

    login: async (_, { input }) => {
      const { email, password } = input;

      // Find user with password
      const user = await User.findOne({ email }).select('+password +refreshToken');
      if (!user) {
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      if (!user.isActive) {
        throw new GraphQLError('Your account has been suspended. Please contact support.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      const token = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();

      await User.findByIdAndUpdate(user._id, { refreshToken });

      return { token, refreshToken, user };
    },

    logout: async (_, __, { user }) => {
      if (user) {
        await User.findByIdAndUpdate(user._id, { refreshToken: null });
      }
      return true;
    },

    refreshToken: async (_, { token }) => {
      try {
        const decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
        const user = await User.findById(decoded.id).select('+refreshToken');

        if (!user || user.refreshToken !== token) {
          throw new GraphQLError('Invalid refresh token', {
            extensions: { code: 'UNAUTHENTICATED' },
          });
        }

        const newToken = user.generateAuthToken();
        const newRefreshToken = user.generateRefreshToken();

        await User.findByIdAndUpdate(user._id, { refreshToken: newRefreshToken });

        return { token: newToken, refreshToken: newRefreshToken, user };
      } catch (error) {
        throw new GraphQLError('Invalid or expired refresh token', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }
    },

    updateProfile: async (_, { name, phone, avatar }, { user }) => {
      requireAuth(user);
      const updates = {};
      if (name) updates.name = name;
      if (phone) updates.phone = phone;
      if (avatar) updates.avatar = avatar;

      return User.findByIdAndUpdate(user._id, updates, { new: true }).populate('wishlist');
    },

    changePassword: async (_, { currentPassword, newPassword }, { user }) => {
      requireAuth(user);

      const fullUser = await User.findById(user._id).select('+password');
      const isMatch = await fullUser.comparePassword(currentPassword);

      if (!isMatch) {
        throw new GraphQLError('Current password is incorrect', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      if (newPassword.length < 6) {
        throw new GraphQLError('New password must be at least 6 characters', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      fullUser.password = newPassword;
      await fullUser.save();
      return true;
    },

    addAddress: async (_, { input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);

      // If this is default or first address, remove default from others
      if (input.isDefault || fullUser.addresses.length === 0) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
        input.isDefault = true;
      }

      fullUser.addresses.push(input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateAddress: async (_, { addressId, input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const address = fullUser.addresses.id(addressId);

      if (!address) {
        throw new GraphQLError('Address not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      if (input.isDefault) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
      }

      Object.assign(address, input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    deleteAddress: async (_, { addressId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      fullUser.addresses = fullUser.addresses.filter(
        (addr) => addr._id.toString() !== addressId
      );
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    toggleWishlist: async (_, { productId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const isInWishlist = fullUser.wishlist.some(
        (id) => id.toString() === productId
      );

      if (isInWishlist) {
        fullUser.wishlist = fullUser.wishlist.filter(
          (id) => id.toString() !== productId
        );
      } else {
        fullUser.wishlist.push(productId);
      }

      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateFcmToken: async (_, { token }, { user }) => {
      if (!user) return false;
      await User.findByIdAndUpdate(user._id, { fcmToken: token });
      return true;
    },
  },
};

export default authResolvers;
