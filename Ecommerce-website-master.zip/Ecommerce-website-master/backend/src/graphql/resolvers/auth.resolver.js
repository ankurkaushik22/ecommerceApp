import { GraphQLError } from 'graphql';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import User from '../../models/User.js';
import RolePermission from '../../models/RolePermission.js';
import { requireAuth } from '../../middleware/auth.middleware.js';
import { sendResetPasswordEmail, sendLoginOtpEmail } from '../../utils/mailer.js';
import { publishNotification } from './notification.resolver.js';

const authResolvers = {
  Query: {
    me: async (_, __, { user }) => {
      requireAuth(user);
      return User.findById(user._id).populate('wishlist');
    },
    checkUserExists: async (_, { identifier }) => {
      const user = await User.findOne({
        $or: [{ email: identifier }, { phone: identifier }],
      });
      return !!user;
    },
  },

  Mutation: {
    register: async (_, { input }) => {
      const { name, email: identifierInput, password, phone, role, acceptedTerms } = input;

      const isEmail = identifierInput && identifierInput.includes('@');
      const actualEmail = isEmail ? identifierInput : undefined;
      const actualPhone = !isEmail ? identifierInput : phone;

      if (!actualEmail && !actualPhone) {
        throw new GraphQLError('Email or phone number is required', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Check if user exists
      const existingUser = await User.findOne({ 
        $or: [
          ...(actualEmail ? [{ email: actualEmail }] : []),
          ...(actualPhone ? [{ phone: actualPhone }] : [])
        ] 
      });
      if (existingUser) {
        throw new GraphQLError('An account with this email/phone already exists', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const defaultName = actualEmail ? actualEmail.split('@')[0] : actualPhone;

      // Sanitize role: public registration can only create 'customer' or 'vendor'
      const requestedRole = (role || 'customer').toLowerCase().trim();
      const safeRole = requestedRole === 'vendor' ? 'vendor' : 'customer';

      // Create user
      const newUser = await User.create({
        name: name || defaultName,
        email: actualEmail,
        password,
        phone: actualPhone,
        role: safeRole,
        vendorCategory: input.vendorCategory,
        vendorVertical: input.vendorVertical,
      });

      if (acceptedTerms) {
        await User.findByIdAndUpdate(newUser._id, { 
          termsAcceptedAt: new Date(), 
          privacyAcceptedAt: new Date() 
        });
      }

      // Notify admins if a vendor registered
      if (safeRole === 'vendor') {
        try {
          const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } });
          for (const adminUser of admins) {
            await publishNotification(adminUser._id, {
              title: 'New Vendor Registered',
              message: `Vendor "${newUser.name}" (${newUser.email || newUser.phone}) registered and requires verification.`,
              type: 'vendor_registered',
              link: '/vendors',
            });
          }
        } catch (err) {
          console.error('Failed to notify admins of vendor registration:', err);
        }
      }

      // Generate tokens
      const token = newUser.generateAuthToken();
      const refreshToken = newUser.generateRefreshToken();

      // Save refresh token
      await User.findByIdAndUpdate(newUser._id, { refreshToken });

      return { token, refreshToken, user: newUser };
    },

    login: async (_, { input }) => {
      const { email: identifierInput, password } = input;

      // Find user with password
      const user = await User.findOne({ 
        $or: [{ email: identifierInput }, { phone: identifierInput }] 
      }).select('+password +refreshToken');
      if (!user) {
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      if (!user.isActive) {
        throw new GraphQLError('Your account has been suspended. Please contact support.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      const token = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();

      await User.findByIdAndUpdate(user._id, { refreshToken });

      return { token, refreshToken, user };
    },

    sendLoginOTP: async (_, { email }) => {
      const user = await User.findOne({ email: email.toLowerCase().trim() });
      if (!user) {
        // Prevent user enumeration by returning a generic success message
        return {
          success: true,
          message: 'If an account exists, a one-time password has been sent to your email.',
        };
      }

      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      user.loginOtp = otp;
      user.loginOtpExpires = Date.now() + 10 * 60 * 1000;
      await user.save({ validateBeforeSave: false });

      // Send email asynchronously in the background so it doesn't hang the UI
      sendLoginOtpEmail(user.email, otp).catch(console.error);

      return {
        success: true,
        message: 'If an account exists, a one-time password has been sent to your email.',
      };
    },

    loginWithOTP: async (_, { email, otp }) => {
      const user = await User.findOne({
        email: email.toLowerCase().trim(),
        loginOtpExpires: { $gt: Date.now() },
      }).select('+loginOtp +refreshToken');

      if (!user || user.loginOtp !== otp) {
        throw new GraphQLError('Invalid or expired OTP', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      if (!user.isActive) {
        throw new GraphQLError('Your account has been suspended.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      user.loginOtp = undefined;
      user.loginOtpExpires = undefined;

      const token = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();
      user.refreshToken = refreshToken;
      await user.save({ validateBeforeSave: false });

      return {
        success: true,
        message: 'Login successful',
        token,
        refreshToken,
        user,
      };
    },

    forgotPassword: async (_, { email }) => {
      const user = await User.findOne({ email: email.toLowerCase().trim() });
      if (!user) {
        // Return generic message to prevent email enumeration
        return {
          success: true,
          message: 'If an account exists with this email, password reset instructions have been sent.',
          resetToken: null,
        };
      }

      const { otp } = user.createPasswordResetToken();
      await user.save({ validateBeforeSave: false });

      sendResetPasswordEmail(user.email, otp).catch(console.error);

      return {
        success: true,
        message: 'If an account exists with this email, password reset instructions have been sent.',
        resetToken: null,
      };
    },

    verifyResetOTP: async (_, { email, otp }) => {
      const user = await User.findOne({
        email: email.toLowerCase().trim(),
        passwordResetExpires: { $gt: Date.now() },
      }).select('+passwordResetOTP +passwordResetToken');

      if (!user || user.passwordResetOTP !== otp) {
        throw new GraphQLError('Invalid or expired OTP. Please request a new one.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Generate a fresh reset token
      const rawToken = crypto.randomBytes(32).toString('hex');
      user.passwordResetToken = crypto.createHash('sha256').update(rawToken).digest('hex');
      await user.save({ validateBeforeSave: false });

      return {
        success: true,
        message: 'OTP verified successfully.',
        resetToken: rawToken,
      };
    },

    resetPassword: async (_, { token, newPassword }) => {
      if (!newPassword || newPassword.length < 6) {
        throw new GraphQLError('Password must be at least 6 characters long', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

      const user = await User.findOne({
        $or: [
          { passwordResetToken: hashedToken },
          { passwordResetToken: token },
        ],
        passwordResetExpires: { $gt: Date.now() },
      });

      if (!user) {
        throw new GraphQLError('Password reset token is invalid or has expired. Please request a new one.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      user.password = newPassword;
      user.passwordResetToken = undefined;
      user.passwordResetExpires = undefined;
      user.passwordResetOTP = undefined;
      await user.save();

      const authToken = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();
      await User.findByIdAndUpdate(user._id, { refreshToken });

      return {
        token: authToken,
        refreshToken,
        user,
      };
    },

    logout: async (_, __, { user }) => {
      if (user) {
        await User.findByIdAndUpdate(user._id, { refreshToken: null });
      }
      return true;
    },

    refreshToken: async (_, { token }) => {
      try {
        const decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
        const user = await User.findById(decoded.id).select('+refreshToken');

        if (!user || user.refreshToken !== token) {
          throw new GraphQLError('Invalid refresh token', {
            extensions: { code: 'UNAUTHENTICATED' },
          });
        }

        const newAuthToken = user.generateAuthToken();
        const newRefreshToken = user.generateRefreshToken();

        await User.findByIdAndUpdate(user._id, { refreshToken: newRefreshToken });

        return { token: newAuthToken, refreshToken: newRefreshToken, user };
      } catch {
        throw new GraphQLError('Invalid or expired refresh token', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }
    },

    updateProfile: async (_, { name, phone, avatar }, { user }) => {
      requireAuth(user);
      const updates = {};
      if (name) updates.name = name;
      if (phone !== undefined) updates.phone = phone;
      if (avatar) updates.avatar = avatar;

      return User.findByIdAndUpdate(user._id, updates, { new: true });
    },

    changePassword: async (_, { currentPassword, newPassword }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id).select('+password');

      const isMatch = await fullUser.comparePassword(currentPassword);
      if (!isMatch) {
        throw new GraphQLError('Current password is incorrect', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      fullUser.password = newPassword;
      await fullUser.save();
      return true;
    },

    addAddress: async (_, { input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);

      if (input.isDefault) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
      } else if (fullUser.addresses.length === 0) {
        input.isDefault = true;
      }

      fullUser.addresses.push(input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateAddress: async (_, { addressId, input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const address = fullUser.addresses.id(addressId);

      if (!address) {
        throw new GraphQLError('Address not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      if (input.isDefault) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
      }

      Object.assign(address, input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    deleteAddress: async (_, { addressId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      fullUser.addresses = fullUser.addresses.filter(
        (addr) => addr._id.toString() !== addressId
      );
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    toggleWishlist: async (_, { productId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const isInWishlist = fullUser.wishlist.some(
        (id) => id.toString() === productId
      );

      if (isInWishlist) {
        fullUser.wishlist = fullUser.wishlist.filter(
          (id) => id.toString() !== productId
        );
      } else {
        fullUser.wishlist.push(productId);
      }

      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateFcmToken: async (_, { token }, { user }) => {
      if (!user) return false;
      await User.findByIdAndUpdate(user._id, { fcmToken: token });
      return true;
    },
  },

  User: {
    permissions: async (parent) => {
      const direct = Array.isArray(parent.permissions) ? parent.permissions : [];
      try {
        const roleDoc = await RolePermission.findOne({ roleName: parent.role });
        if (roleDoc && Array.isArray(roleDoc.modules)) {
          return Array.from(new Set([...direct, ...roleDoc.modules]));
        }
        return direct;
      } catch {
        return direct;
      }
    },
  },
};

export default authResolvers;
