import { GraphQLError } from 'graphql';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import User from '../../models/User.js';
import RolePermission from '../../models/RolePermission.js';
import { requireAuth } from '../../middleware/auth.middleware.js';
import { sendResetPasswordEmail, sendLoginOtpEmail } from '../../utils/mailer.js';
import { sendWhatsAppOTP } from '../../utils/sendWhatsAppOtp.js';
import { publishNotification } from './notification.resolver.js';
import {
  validateData,
  registerInputSchema,
  loginInputSchema,
  sendOTPSchema,
  loginWithOTPSchema,
  forgotPasswordSchema,
  verifyResetOTPSchema,
  resetPasswordSchema,
  changePasswordSchema,
  updateProfileSchema,
  addressInputSchema,
  identifierSchema,
} from '../../utils/validators.js';
import {
  checkAccountAuthBackoff,
  recordAuthFailure,
  recordAuthSuccess,
} from '../../utils/rateLimiter.js';

const authResolvers = {
  Query: {
    me: async (_, __, { user }) => {
      requireAuth(user);
      return User.findById(user._id).populate('wishlist');
    },
    checkUserExists: async (_, { identifier }) => {
      validateData(identifierSchema, identifier);
      const user = await User.findOne({
        $or: [{ email: identifier }, { phone: identifier }],
      });
      return !!user;
    },
  },

  Mutation: {
    register: async (_, { input }) => {
      const validatedInput = validateData(registerInputSchema, input);
      const { name, email: identifierInput, password, phone, role, acceptedTerms } = validatedInput;

      const isEmail = identifierInput && identifierInput.includes('@');
      const actualEmail = isEmail ? identifierInput : undefined;
      const actualPhone = !isEmail ? identifierInput : phone;

      if (!actualEmail && !actualPhone) {
        throw new GraphQLError('Email or phone number is required', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Check if user exists
      const existingUser = await User.findOne({ 
        $or: [
          ...(actualEmail ? [{ email: actualEmail }] : []),
          ...(actualPhone ? [{ phone: actualPhone }] : [])
        ] 
      });
      if (existingUser) {
        throw new GraphQLError('An account with this email/phone already exists', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      const defaultName = actualEmail ? actualEmail.split('@')[0] : actualPhone;

      // Sanitize role: public registration can only create 'customer' or 'vendor'
      const requestedRole = (role || 'customer').toLowerCase().trim();
      const safeRole = requestedRole === 'vendor' ? 'vendor' : 'customer';

      // Create user
      const newUser = await User.create({
        name: name || defaultName,
        email: actualEmail,
        password,
        phone: actualPhone,
        role: safeRole,
        vendorCategory: validatedInput.vendorCategory,
        vendorVertical: validatedInput.vendorVertical,
      });

      if (acceptedTerms) {
        await User.findByIdAndUpdate(newUser._id, { 
          termsAcceptedAt: new Date(), 
          privacyAcceptedAt: new Date() 
        });
      }

      // Reset any auth backoff for this identifier
      await recordAuthSuccess(actualEmail || actualPhone);

      // Notify admins if a vendor registered
      if (safeRole === 'vendor') {
        try {
          const admins = await User.find({ role: { $in: ['admin', 'superadmin'] } });
          for (const adminUser of admins) {
            await publishNotification(adminUser._id, {
              title: 'New Vendor Registered',
              message: `Vendor "${newUser.name}" (${newUser.email || newUser.phone}) registered and requires verification.`,
              type: 'vendor_registered',
              link: '/vendors',
            });
          }
        } catch (err) {
          console.error('Failed to notify admins of vendor registration:', err);
        }
      }

      // Generate tokens
      const token = newUser.generateAuthToken();
      const refreshToken = newUser.generateRefreshToken();

      // Save refresh token
      await User.findByIdAndUpdate(newUser._id, { refreshToken });

      return { token, refreshToken, user: newUser };
    },

    login: async (_, { input }) => {
      const validatedInput = validateData(loginInputSchema, input);
      const { email: identifierInput, password } = validatedInput;

      // Check per-account exponential backoff
      const backoff = await checkAccountAuthBackoff(identifierInput);
      if (!backoff.allowed) {
        throw new GraphQLError(backoff.message, {
          extensions: {
            code: 'TOO_MANY_REQUESTS',
            retryAfterSeconds: backoff.retryAfterSeconds,
          },
        });
      }

      // Find user with password
      const user = await User.findOne({ 
        $or: [{ email: identifierInput }, { phone: identifierInput }] 
      }).select('+password +refreshToken');
      if (!user) {
        await recordAuthFailure(identifierInput);
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      if (!user.isActive) {
        throw new GraphQLError('Your account has been suspended. Please contact support.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        await recordAuthFailure(identifierInput);
        throw new GraphQLError('Invalid email or password', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      // Success: reset exponential backoff counter
      await recordAuthSuccess(identifierInput);

      const token = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();

      await User.findByIdAndUpdate(user._id, { refreshToken });

      return { token, refreshToken, user };
    },

    sendLoginOTP: async (_, { email }) => {
      validateData(sendOTPSchema, { email });
      const rawInput = email.trim();
      const isEmail = rawInput.includes('@');

      const user = await User.findOne({
        $or: [
          { email: rawInput.toLowerCase() },
          { phone: rawInput },
        ],
      });

      if (!user) {
        // Prevent user enumeration by returning a generic success message
        return {
          success: true,
          message: 'If an account exists, a one-time password has been sent to your WhatsApp / Email.',
        };
      }

      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      user.loginOtp = otp;
      user.loginOtpExpires = Date.now() + 10 * 60 * 1000;
      await user.save({ validateBeforeSave: false });

      // Send OTP via WhatsApp (if user has phone or inputted phone)
      const targetPhone = user.phone || (!isEmail ? rawInput : null);
      if (targetPhone) {
        sendWhatsAppOTP(targetPhone, otp).catch(console.error);
      }

      // Send email as fallback / secondary channel if email exists
      if (user.email) {
        sendLoginOtpEmail(user.email, otp).catch(console.error);
      }

      return {
        success: true,
        message: 'If an account exists, a one-time password has been sent to your WhatsApp / Email.',
      };
    },

    loginWithOTP: async (_, { email, otp }) => {
      validateData(loginWithOTPSchema, { email, otp });
      const rawInput = email.trim();

      const backoff = await checkAccountAuthBackoff(rawInput);
      if (!backoff.allowed) {
        throw new GraphQLError(backoff.message, {
          extensions: {
            code: 'TOO_MANY_REQUESTS',
            retryAfterSeconds: backoff.retryAfterSeconds,
          },
        });
      }

      const user = await User.findOne({
        $or: [
          { email: rawInput.toLowerCase() },
          { phone: rawInput },
        ],
        loginOtpExpires: { $gt: Date.now() },
      }).select('+loginOtp +refreshToken');

      if (!user || user.loginOtp !== otp) {
        await recordAuthFailure(rawInput);
        throw new GraphQLError('Invalid or expired OTP', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }

      if (!user.isActive) {
        throw new GraphQLError('Your account has been suspended.', {
          extensions: { code: 'FORBIDDEN' },
        });
      }

      await recordAuthSuccess(rawInput);

      user.loginOtp = undefined;
      user.loginOtpExpires = undefined;

      const token = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();
      user.refreshToken = refreshToken;
      await user.save({ validateBeforeSave: false });

      await recordAuthSuccess(email);

      return {
        success: true,
        message: 'Login successful',
        token,
        refreshToken,
        user,
      };
    },

    forgotPassword: async (_, { email }) => {
      validateData(forgotPasswordSchema, { email });
      const term = email.trim();
      const user = await User.findOne({
        $or: [{ email: term.toLowerCase() }, { phone: term }],
      });
      if (!user) {
        return {
          success: true,
          message: 'If an account exists, password reset instructions have been sent.',
          resetToken: null,
        };
      }

      const { otp } = user.createPasswordResetToken();
      await user.save({ validateBeforeSave: false });

      if (user.email) {
        sendResetPasswordEmail(user.email, otp).catch(console.error);
      }

      return {
        success: true,
        message: `OTP generated for reset: ${otp}`,
        resetToken: null,
      };
    },

    verifyResetOTP: async (_, { email, otp }) => {
      validateData(verifyResetOTPSchema, { email, otp });

      const backoff = await checkAccountAuthBackoff(email);
      if (!backoff.allowed) {
        throw new GraphQLError(backoff.message, {
          extensions: {
            code: 'TOO_MANY_REQUESTS',
            retryAfterSeconds: backoff.retryAfterSeconds,
          },
        });
      }

      const term = email.trim();
      const user = await User.findOne({
        $or: [{ email: term.toLowerCase() }, { phone: term }],
        passwordResetExpires: { $gt: Date.now() },
      }).select('+passwordResetOTP +passwordResetToken');

      if (!user || user.passwordResetOTP !== otp) {
        await recordAuthFailure(email);
        throw new GraphQLError('Invalid or expired OTP. Please request a new one.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      // Generate a fresh reset token
      const rawToken = crypto.randomBytes(32).toString('hex');
      user.passwordResetToken = crypto.createHash('sha256').update(rawToken).digest('hex');
      await user.save({ validateBeforeSave: false });

      await recordAuthSuccess(email);

      return {
        success: true,
        message: 'OTP verified successfully.',
        resetToken: rawToken,
      };
    },

    resetPassword: async (_, { token, newPassword }) => {
      validateData(resetPasswordSchema, { token, newPassword });

      const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

      const user = await User.findOne({
        $or: [
          { passwordResetToken: hashedToken },
          { passwordResetToken: token },
        ],
        passwordResetExpires: { $gt: Date.now() },
      });

      if (!user) {
        throw new GraphQLError('Password reset token is invalid or has expired. Please request a new one.', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      user.password = newPassword;
      user.passwordResetToken = undefined;
      user.passwordResetExpires = undefined;
      user.passwordResetOTP = undefined;
      await user.save();

      const authToken = user.generateAuthToken();
      const refreshToken = user.generateRefreshToken();
      await User.findByIdAndUpdate(user._id, { refreshToken });

      return {
        token: authToken,
        refreshToken,
        user,
      };
    },

    logout: async (_, __, { user }) => {
      if (user) {
        await User.findByIdAndUpdate(user._id, { refreshToken: null });
      }
      return true;
    },

    refreshToken: async (_, { token }) => {
      try {
        const decoded = jwt.verify(token, process.env.REFRESH_TOKEN_SECRET);
        const user = await User.findById(decoded.id).select('+refreshToken');

        if (!user || user.refreshToken !== token) {
          throw new GraphQLError('Invalid refresh token', {
            extensions: { code: 'UNAUTHENTICATED' },
          });
        }

        const newAuthToken = user.generateAuthToken();
        const newRefreshToken = user.generateRefreshToken();

        await User.findByIdAndUpdate(user._id, { refreshToken: newRefreshToken });

        return { token: newAuthToken, refreshToken: newRefreshToken, user };
      } catch {
        throw new GraphQLError('Invalid or expired refresh token', {
          extensions: { code: 'UNAUTHENTICATED' },
        });
      }
    },

    updateProfile: async (_, { name, phone, avatar }, { user }) => {
      requireAuth(user);
      validateData(updateProfileSchema, { name, phone, avatar });
      const updates = {};
      if (name) updates.name = name;
      if (phone !== undefined) updates.phone = phone;
      if (avatar) updates.avatar = avatar;

      return User.findByIdAndUpdate(user._id, updates, { new: true });
    },

    changePassword: async (_, { currentPassword, newPassword }, { user }) => {
      requireAuth(user);
      validateData(changePasswordSchema, { currentPassword, newPassword });
      const fullUser = await User.findById(user._id).select('+password');

      const isMatch = await fullUser.comparePassword(currentPassword);
      if (!isMatch) {
        throw new GraphQLError('Current password is incorrect', {
          extensions: { code: 'BAD_USER_INPUT' },
        });
      }

      fullUser.password = newPassword;
      await fullUser.save();
      return true;
    },

    addAddress: async (_, { input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);

      if (input.isDefault) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
      } else if (fullUser.addresses.length === 0) {
        input.isDefault = true;
      }

      fullUser.addresses.push(input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateAddress: async (_, { addressId, input }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const address = fullUser.addresses.id(addressId);

      if (!address) {
        throw new GraphQLError('Address not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }

      if (input.isDefault) {
        fullUser.addresses.forEach((addr) => (addr.isDefault = false));
      }

      Object.assign(address, input);
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    deleteAddress: async (_, { addressId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      fullUser.addresses = fullUser.addresses.filter(
        (addr) => addr._id.toString() !== addressId
      );
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    setDefaultAddress: async (_, { addressId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      let found = false;
      fullUser.addresses.forEach((addr) => {
        if (addr._id.toString() === addressId) {
          addr.isDefault = true;
          found = true;
        } else {
          addr.isDefault = false;
        }
      });
      if (!found) {
        throw new GraphQLError('Address not found', {
          extensions: { code: 'NOT_FOUND' },
        });
      }
      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    toggleWishlist: async (_, { productId }, { user }) => {
      requireAuth(user);
      const fullUser = await User.findById(user._id);
      const isInWishlist = fullUser.wishlist.some(
        (id) => id.toString() === productId
      );

      if (isInWishlist) {
        fullUser.wishlist = fullUser.wishlist.filter(
          (id) => id.toString() !== productId
        );
      } else {
        fullUser.wishlist.push(productId);
      }

      await fullUser.save();
      return fullUser.populate('wishlist');
    },

    updateFcmToken: async (_, { token }, { user }) => {
      if (!user) return false;
      await User.findByIdAndUpdate(user._id, { fcmToken: token });
      return true;
    },
  },

  User: {
    isOnline: (parent) => {
      if (!parent) return true;
      if (['admin', 'superadmin', 'customer'].includes(parent.role) || !parent.role) {
        return true;
      }
      return parent.isOnline !== false;
    },
    permissions: async (parent) => {
      const direct = Array.isArray(parent.permissions) ? parent.permissions : [];
      try {
        const roleDoc = await RolePermission.findOne({ roleName: parent.role });
        if (roleDoc && Array.isArray(roleDoc.modules)) {
          return Array.from(new Set([...direct, ...roleDoc.modules]));
        }
        return direct;
      } catch {
        return direct;
      }
    },
    deliveryRating: async (parent) => {
      if (parent.deliveryRating && typeof parent.deliveryRating.average === 'number' && parent.deliveryRating.count > 0) {
        return parent.deliveryRating;
      }
      try {
        const Order = (await import('../../models/Order.js')).default;
        const Review = (await import('../../models/Review.js')).default;
        const reviews = await Review.find({ deliveryAgent: parent._id, targetType: 'delivery' });
        if (reviews.length > 0) {
          const avg = Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 10) / 10;
          return { average: avg, count: reviews.length };
        }
        const deliveredCount = await Order.countDocuments({
          $or: [{ deliveryAgent: parent._id }, { deliveryBoy: parent._id }],
          status: { $in: ['delivered', 'completed'] },
        });
        if (deliveredCount > 0) {
          return { average: 5.0, count: deliveredCount };
        }
      } catch {}
      return { average: 5.0, count: 0 };
    },
  },
};

export default authResolvers;
