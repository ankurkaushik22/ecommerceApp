import Banner from '../../models/Banner.js';
import { requireAdmin } from '../../middleware/auth.middleware.js';
import { GraphQLError } from 'graphql';

export const bannerResolver = {
  Query: {
    getBanners: async (_, { platform, vertical }, context) => {
      try {
        const query = {};
        
        // If not admin/superadmin, only show active banners
        if (!context.user || !['superadmin', 'admin'].includes(context.user.role)) {
          query.isActive = true;
        }

        if (platform) {
          query.platform = { $in: [platform, 'both'] };
        }

        if (vertical && vertical !== 'all') {
          query.vertical = { $in: [vertical, 'all'] };
        }

        return await Banner.find(query).sort({ order: 1 });
      } catch (error) {
        throw new GraphQLError(error.message, {
          extensions: { code: 'INTERNAL_SERVER_ERROR' }
        });
      }
    }
  },
  Mutation: {
    createBanner: async (_, { input }, context) => {
      try {
        requireAdmin(context.user);
        
        const banner = new Banner(input);
        await banner.save();
        
        return banner;
      } catch (error) {
        throw new GraphQLError(error.message, {
          extensions: { code: 'BAD_REQUEST' }
        });
      }
    },
    updateBanner: async (_, { id, input }, context) => {
      try {
        requireAdmin(context.user);
        
        const banner = await Banner.findByIdAndUpdate(
          id,
          { $set: input },
          { new: true, runValidators: true }
        );

        if (!banner) {
          throw new Error('Banner not found');
        }
        
        return banner;
      } catch (error) {
        throw new GraphQLError(error.message, {
          extensions: { code: 'BAD_REQUEST' }
        });
      }
    },
    deleteBanner: async (_, { id }, context) => {
      try {
        requireAdmin(context.user);
        
        const banner = await Banner.findByIdAndDelete(id);
        
        if (!banner) {
          throw new Error('Banner not found');
        }
        
        return true;
      } catch (error) {
        throw new GraphQLError(error.message, {
          extensions: { code: 'BAD_REQUEST' }
        });
      }
    }
  }
};
