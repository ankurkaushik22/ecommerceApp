export const typeDefs = `#graphql
  scalar Date
  scalar JSON

  # ===================== AUTH =====================
  type AuthPayload {
    token: String!
    refreshToken: String!
    user: User!
  }

  # ===================== USER =====================
  type Address {
    _id: ID!
    label: String
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
    isDefault: Boolean
  }

  type User {
    _id: ID!
    name: String!
    email: String!
    role: String!
    avatar: String
    phone: String
    addresses: [Address]
    wishlist: [Product]
    isVerified: Boolean
    isActive: Boolean
    createdAt: Date
  }

  # ===================== CATEGORY =====================
  type Category {
    _id: ID!
    name: String!
    slug: String!
    description: String
    image: String
    icon: String
    parent: Category
    children: [Category]
    isActive: Boolean
    sortOrder: Int
    productCount: Int
    createdAt: Date
  }

  # ===================== PRODUCT =====================
  type Specification {
    key: String!
    value: String!
  }

  type VariantOption {
    label: String!
    price: Float!
    stock: Int!
    sku: String
  }

  type ProductVariant {
    name: String!
    options: [VariantOption!]!
  }

  type RatingDistribution {
    star: Int!
    count: Int!
    percentage: Float!
  }

  type ProductRating {
    average: Float!
    count: Int!
    distribution: [RatingDistribution]
  }

  type Product {
    _id: ID!
    name: String!
    slug: String!
    description: String!
    shortDescription: String
    price: Float!
    comparePrice: Float
    discount: Float
    images: [String!]!
    category: Category!
    subcategory: Category
    vendor: User
    stock: Int!
    sku: String
    tags: [String]
    specifications: [Specification]
    variants: [ProductVariant]
    rating: ProductRating
    reviews: [Review]
    reviewsCount: Int
    isActive: Boolean!
    isFeatured: Boolean!
    isDeals: Boolean!
    freeShipping: Boolean!
    shippingCost: Float
    salesCount: Int
    createdAt: Date
  }

  type ProductsResult {
    products: [Product!]!
    total: Int!
    page: Int!
    pages: Int!
    hasNext: Boolean!
  }

  # ===================== REVIEW =====================
  type Review {
    _id: ID!
    product: Product!
    user: User!
    rating: Int!
    title: String
    comment: String!
    images: [String]
    helpful: [ID]
    helpfulCount: Int
    verified: Boolean
    createdAt: Date
  }

  # ===================== CART =====================
  type CartItem {
    _id: ID!
    product: Product!
    variantIndex: Int
    quantity: Int!
    price: Float!
    total: Float!
  }

  type Cart {
    _id: ID!
    user: ID!
    items: [CartItem!]!
    subtotal: Float!
    itemCount: Int!
    couponCode: String
    couponDiscount: Float
    discount: Float
    updatedAt: Date
  }

  # ===================== ORDER =====================
  type ShippingAddress {
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
  }

  type TrackingUpdate {
    status: String!
    message: String!
    timestamp: Date!
    location: String
  }

  type OrderItem {
    product: Product
    name: String!
    image: String
    price: Float!
    quantity: Int!
    variantLabel: String
    total: Float!
  }

  type Order {
    _id: ID!
    orderNumber: String!
    customer: User!
    vendor: User
    items: [OrderItem!]!
    shippingAddress: ShippingAddress!
    status: String!
    paymentMethod: String!
    paymentStatus: String!
    subtotal: Float!
    discount: Float
    shippingCost: Float
    tax: Float
    total: Float!
    couponCode: String
    deliveryBoy: User
    estimatedDelivery: Date
    deliveredAt: Date
    cancelReason: String
    trackingUpdates: [TrackingUpdate]
    notes: String
    createdAt: Date
  }

  type OrdersResult {
    orders: [Order!]!
    total: Int!
    page: Int!
    pages: Int!
  }

  # ===================== COUPON =====================
  type Coupon {
    _id: ID!
    code: String!
    type: String!
    value: Float!
    description: String
    minOrderAmount: Float
    maxDiscountAmount: Float
    usageLimit: Int
    usedCount: Int
    isActive: Boolean
    startsAt: Date
    expiresAt: Date
    createdAt: Date
  }

  type CouponValidation {
    valid: Boolean!
    discount: Float
    message: String
    coupon: Coupon
  }

  # ===================== PAYMENT =====================
  type PaymentIntent {
    clientSecret: String!
    paymentIntentId: String!
    amount: Float!
  }

  # ===================== NOTIFICATION =====================
  type Notification {
    _id: ID!
    title: String!
    message: String!
    type: String!
    data: JSON
    isRead: Boolean!
    createdAt: Date
  }

  # ===================== DASHBOARD =====================
  type ChartDataPoint {
    label: String!
    value: Float!
  }

  type DashboardStats {
    totalRevenue: Float!
    todayRevenue: Float!
    totalOrders: Int!
    todayOrders: Int!
    totalProducts: Int!
    totalUsers: Int!
    totalVendors: Int!
    pendingOrders: Int!
    recentOrders: [Order]
    topProducts: [Product]
    revenueChart: [ChartDataPoint]
    ordersChart: [ChartDataPoint]
  }

  # ===================== INPUTS =====================
  input RegisterInput {
    name: String!
    email: String!
    password: String!
    phone: String
    role: String
  }

  input LoginInput {
    email: String!
    password: String!
  }

  input AddressInput {
    label: String
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
    isDefault: Boolean
  }

  input ProductInput {
    name: String!
    description: String!
    shortDescription: String
    price: Float!
    comparePrice: Float
    images: [String!]!
    categoryId: ID!
    subcategoryId: ID
    stock: Int!
    sku: String
    weight: Float
    tags: [String]
    specifications: [SpecificationInput]
    isFeatured: Boolean
    isDeals: Boolean
    freeShipping: Boolean
    shippingCost: Float
  }

  input SpecificationInput {
    key: String!
    value: String!
  }

  input ProductFilterInput {
    categoryId: ID
    category: ID
    subcategoryId: ID
    subcategory: ID
    minPrice: Float
    maxPrice: Float
    rating: Float
    inStock: Boolean
    isFeatured: Boolean
    isDeals: Boolean
    freeShipping: Boolean
    tags: [String]
    search: String
    vendorId: ID
  }

  input ProductSortInput {
    field: String!
    order: String!
  }

  input CartItemInput {
    productId: ID!
    variantIndex: Int
    quantity: Int!
  }

  input OrderAddressInput {
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
  }

  input PlaceOrderInput {
    paymentMethod: String!
    notes: String
    shippingAddressId: ID
  }

  input ReviewInput {
    productId: ID!
    rating: Int!
    title: String
    comment: String!
    images: [String]
  }

  input CouponInput {
    code: String!
    type: String!
    value: Float!
    description: String
    minOrderAmount: Float
    maxDiscountAmount: Float
    usageLimit: Int
    startsAt: Date
    expiresAt: Date
    isActive: Boolean
  }

  input CategoryInput {
    name: String!
    description: String
    image: String
    icon: String
    parentId: ID
    sortOrder: Int
    isActive: Boolean
  }

  input PaginationInput {
    page: Int
    limit: Int
  }

  # ===================== QUERIES =====================
  type Query {
    # Auth
    me: User

    # Products
    getProducts(
      filter: ProductFilterInput
      sort: ProductSortInput
      pagination: PaginationInput
    ): ProductsResult!
    getProduct(slug: String!): Product
    getProductById(id: ID!): Product
    getFeaturedProducts(limit: Int): [Product!]!
    getDealsProducts(limit: Int): [Product!]!
    getRelatedProducts(productId: ID!, limit: Int): [Product!]!
    searchProducts(query: String!, pagination: PaginationInput): ProductsResult!

    # Categories
    getCategories(parentId: ID): [Category!]!
    getCategory(slug: String!): Category
    getAllCategories: [Category!]!

    # Cart
    getCart: Cart

    # Orders (Customer)
    getOrders(status: String, pagination: PaginationInput): OrdersResult!
    getOrder(id: ID!): Order
    getOrderByNumber(orderNumber: String!): Order
    trackOrder(orderId: ID!): Order

    # Admin Queries
    getAllOrders(status: String, pagination: PaginationInput): OrdersResult!
    getAllUsers(role: String, pagination: PaginationInput): [User!]!
    getDashboardStats: DashboardStats!
    getAllCoupons: [Coupon!]!
    getAnalytics(period: String): JSON
    getVendors(pagination: PaginationInput): [User!]!

    # Notifications
    getNotifications: [Notification!]!
    getUnreadNotificationCount: Int!

    # Reviews
    getProductReviews(productId: ID!, pagination: PaginationInput): [Review!]!
  }

  # ===================== MUTATIONS =====================
  type Mutation {
    # Auth
    register(input: RegisterInput!): AuthPayload!
    login(input: LoginInput!): AuthPayload!
    logout: Boolean!
    refreshToken(token: String!): AuthPayload!
    updateProfile(name: String, phone: String, avatar: String): User!
    changePassword(currentPassword: String!, newPassword: String!): Boolean!

    # Address
    addAddress(input: AddressInput!): User!
    updateAddress(addressId: ID!, input: AddressInput!): User!
    deleteAddress(addressId: ID!): User!

    # Wishlist
    toggleWishlist(productId: ID!): User!

    # Products (Admin/Vendor)
    createProduct(input: ProductInput!): Product!
    updateProduct(id: ID!, input: ProductInput!): Product!
    deleteProduct(id: ID!): Boolean!
    toggleProductStatus(id: ID!): Product!

    # Categories (Admin)
    createCategory(input: CategoryInput!): Category!
    updateCategory(id: ID!, input: CategoryInput!): Category!
    deleteCategory(id: ID!): Boolean!

    # Cart
    addToCart(input: CartItemInput!): Cart!
    updateCartItem(itemId: ID!, quantity: Int!): Cart!
    removeFromCart(itemId: ID!): Cart!
    clearCart: Boolean!
    applyCoupon(code: String!): Cart!
    removeCoupon: Cart!

    # Orders
    placeOrder(input: PlaceOrderInput!, address: OrderAddressInput): Order!
    cancelOrder(orderId: ID!, reason: String!): Order!
    updateOrderStatus(
      orderId: ID!
      status: String!
      message: String
      location: String
    ): Order!
    assignDeliveryBoy(orderId: ID!, deliveryBoyId: ID!): Order!

    # Payments
    createPaymentIntent(orderId: ID!): PaymentIntent!
    confirmPayment(orderId: ID!, paymentIntentId: String!): Order!

    # Reviews
    addReview(input: ReviewInput!): Review!
    updateReview(reviewId: ID!, input: ReviewInput!): Review!
    deleteReview(reviewId: ID!): Boolean!
    markReviewHelpful(reviewId: ID!): Review!

    # Coupons (Admin)
    createCoupon(input: CouponInput!): Coupon!
    updateCoupon(id: ID!, input: CouponInput!): Coupon!
    deleteCoupon(id: ID!): Boolean!
    validateCoupon(code: String!, orderAmount: Float!): CouponValidation!

    # Admin User Management
    updateUserStatus(userId: ID!, isActive: Boolean!): User!
    updateUserRole(userId: ID!, role: String!): User!

    # Notifications
    markNotificationRead(id: ID!): Notification!
    markAllNotificationsRead: Boolean!
    updateFcmToken(token: String!): Boolean!
  }

  # ===================== SUBSCRIPTIONS =====================
  type Subscription {
    orderStatusUpdated(orderId: ID!): Order!
    newOrderNotification: Order!
    notificationReceived(userId: ID!): Notification!
  }
`;
