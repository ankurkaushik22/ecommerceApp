export const typeDefs = `#graphql
  scalar Date
  scalar JSON

  # ===================== AUTH =====================
  type AuthPayload {
    token: String!
    refreshToken: String!
    user: User!
  }

  type AuthResponse {
    success: Boolean!
    message: String!
    token: String
    refreshToken: String
    user: User
  }

  type ForgotPasswordResponse {
    success: Boolean!
    message: String!
    resetToken: String
  }

  # ===================== LEGAL PAGE =====================
  type LegalPage {
    _id: ID!
    slug: String!
    title: String!
    content: String!
    isActive: Boolean!
    version: Int!
    updatedBy: User
    createdAt: Date
    updatedAt: Date
  }

  # ===================== USER & ROLES =====================
  type Address {
    _id: ID!
    label: String
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
    isDefault: Boolean
  }

  type User {
    _id: ID!
    name: String!
    email: String
    role: String!
    permissions: [String]
    avatar: String
    phone: String
    addresses: [Address]
    wishlist: [Product]
    isVerified: Boolean
    isActive: Boolean
    isOnline: Boolean
    currentLocation: LiveLocation
    vendorCategory: String
    vendorVertical: String
    vendorVerticals: [String]
    commissionRate: Float
    bankDetails: BankDetails
    createdAt: Date
  }

  type RolePermission {
    _id: ID!
    roleName: String!
    displayName: String!
    description: String
    modules: [String!]!
    isSystem: Boolean
    createdAt: Date
  }

  # ===================== TAX & DELIVERY =====================
  type TaxSetting {
    _id: ID!
    name: String!
    rate: Float!
    cgst: Float
    sgst: Float
    igst: Float
    hsnCode: String
    isDefault: Boolean
    isActive: Boolean
    description: String
    createdAt: Date
  }

  type DeliveryOption {
    _id: ID!
    name: String!
    description: String
    estimatedDays: String!
    price: Float!
    minOrderForFree: Float
    isDefault: Boolean
    isActive: Boolean
    sortOrder: Int
    createdAt: Date
  }

  type DeliveryOptionInfo {
    name: String
    estimatedDays: String
    price: Float
  }

  type TaxDetailsInfo {
    rate: Float
    taxAmount: Float
    totalTax: Float
    cgst: Float
    sgst: Float
    igst: Float
    hsnCode: String
  }

  # ===================== CATEGORY =====================
  type Category {
    _id: ID!
    name: String!
    slug: String!
    description: String
    image: String
    icon: String
    parent: Category
    children: [Category]
    vertical: String
    isActive: Boolean
    sortOrder: Int
    productCount: Int
    createdAt: Date
  }

  # ===================== PRODUCT =====================
  type Specification {
    key: String!
    value: String!
  }

  type VariantOption {
    label: String
    price: Float
    stock: Int
    sku: String
    thumbnail: String
    thumbnails: [String]
  }

  type ProductVariant {
    name: String
    options: [VariantOption]
  }

  type RatingDistribution {
    star: Int!
    count: Int!
    percentage: Float!
  }

  type ProductRating {
    average: Float!
    count: Int!
    distribution: [RatingDistribution]
  }

  type Product {
    _id: ID!
    name: String!
    slug: String!
    description: String!
    shortDescription: String
    price: Float!
    comparePrice: Float
    discount: Float
    images: [String!]!
    category: Category
    subcategory: Category
    vendor: User
    stock: Int!
    sku: String
    tags: [String]
    specifications: [Specification]
    highlights: [String]
    variants: [ProductVariant]
    rating: ProductRating
    reviews: [Review]
    reviewsCount: Int
    isActive: Boolean!
    approvalStatus: String
    commissionType: String
    commissionValue: Float
    isFeatured: Boolean!
    isDeals: Boolean!
    freeShipping: Boolean!
    shippingCost: Float
    salesCount: Int
    disableCOD: Boolean
    vertical: String
    unitMeasure: String
    nutritionalHighlights: [String]
    isVeg: Boolean
    cuisine: [String]
    preparationTime: Int
    restaurantName: String
    serviceDuration: String
    includedFeatures: [String]
    warranty: String
    createdAt: Date
  }

  type ProductsResult {
    products: [Product!]!
    total: Int!
    page: Int!
    pages: Int!
    hasNext: Boolean!
  }

  # ===================== REVIEW =====================
  type ReviewReply {
    comment: String!
    repliedBy: User
    repliedAt: Date!
  }

  type Review {
    _id: ID!
    targetType: String!
    product: Product
    vendor: User
    deliveryAgent: User
    order: Order
    user: User!
    rating: Int!
    title: String
    comment: String!
    images: [String]
    helpful: [ID]
    helpfulCount: Int
    verified: Boolean
    reply: ReviewReply
    createdAt: Date
  }

  # ===================== CART =====================
  type CartItem {
    _id: ID!
    product: Product!
    variantIndex: Int
    variantLabel: String
    image: String
    quantity: Int!
    price: Float!
    total: Float!
  }

  type Cart {
    _id: ID!
    user: ID!
    items: [CartItem!]!
    subtotal: Float!
    itemCount: Int!
    couponCode: String
    couponDiscount: Float
    discount: Float
    shippingCost: Float
    tax: Float
    total: Float
    updatedAt: Date
  }

  # ===================== ORDER & INVOICE =====================
  type ShippingAddress {
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
  }

  type TrackingUpdate {
    status: String!
    message: String!
    timestamp: Date!
    location: String
  }

  type DeliveryOptionInfo {
    name: String
    estimatedDays: String
    price: Float
  }

  type TaxDetailsInfo {
    rate: Float
    taxAmount: Float
    cgst: Float
    sgst: Float
    igst: Float
    hsnCode: String
  }

  type OrderItem {
    product: Product
    name: String!
    image: String
    price: Float!
    quantity: Int!
    variantLabel: String
    variantIndex: Int
    total: Float
  }

  type Order {
    _id: ID!
    orderNumber: String!
    invoiceNumber: String
    invoiceDate: Date
    customer: User
    vendor: User
    deliveryAgent: User
    deliveryBoy: User
    deliveryOption: DeliveryOptionInfo
    taxDetails: TaxDetailsInfo
    items: [OrderItem!]!
    shippingAddress: ShippingAddress
    status: String!
    paymentMethod: String!
    paymentStatus: String!
    subtotal: Float!
    discount: Float
    shippingCost: Float
    tax: Float
    total: Float!
    couponCode: String
    vertical: String
    deliverySlot: String
    serviceDate: Date
    serviceTimeSlot: String
    tableOrNotes: String
    estimatedDelivery: Date
    deliveredAt: Date
    cancelReason: String
    liveLocation: LiveLocation
    destinationLocation: DestinationLocation
    deliveryLocationUpdates: [LocationUpdatePoint]
    trackingUpdates: [TrackingUpdate]
    notes: String
    returnStatus: String
    returnReason: String
    returnDate: Date
    createdAt: Date
  }

  type LiveLocation {
    latitude: Float
    longitude: Float
    heading: Float
    speed: Float
    updatedAt: Date
  }

  type DestinationLocation {
    latitude: Float
    longitude: Float
    address: String
  }

  type LocationUpdatePoint {
    latitude: Float
    longitude: Float
    heading: Float
    timestamp: Date
    status: String
  }

  type OrdersResult {
    orders: [Order!]!
    total: Int!
    page: Int!
    pages: Int!
  }

  type Invoice {
    invoiceNumber: String!
    invoiceDate: Date!
    order: Order!
    companyDetails: JSON!
  }

  # ===================== COUPON =====================
  type Coupon {
    _id: ID!
    code: String!
    type: String!
    value: Float!
    description: String
    minOrderAmount: Float
    maxDiscountAmount: Float
    usageLimit: Int
    usedCount: Int
    isActive: Boolean
    startsAt: Date
    expiresAt: Date
    createdAt: Date
  }

  type CouponValidation {
    valid: Boolean!
    discount: Float
    message: String
    coupon: Coupon
  }

  # ===================== PAYMENT =====================
  type PaymentIntent {
    clientSecret: String!
    paymentIntentId: String!
    amount: Float!
  }

  # ===================== NOTIFICATION =====================
  type Notification {
    _id: ID!
    title: String!
    message: String!
    type: String!
    data: JSON
    isRead: Boolean!
    createdAt: Date
  }

  # ===================== DASHBOARD =====================
  type ChartDataPoint {
    label: String!
    value: Float!
  }

  type DashboardStats {
    totalRevenue: Float!
    todayRevenue: Float!
    totalOrders: Int!
    todayOrders: Int!
    totalProducts: Int!
    totalUsers: Int!
    totalVendors: Int!
    pendingOrders: Int!
    pendingVendorCount: Int!
    pendingProductCount: Int!
    recentOrders: [Order]
    topProducts: [Product]
    revenueChart: [ChartDataPoint]
    ordersChart: [ChartDataPoint]
  }

  # ===================== BANNER =====================
  type Banner {
    _id: ID!
    title: String!
    subtitle: String
    tag: String
    image: String!
    link: String
    discount: String
    platform: String!
    bgGradient: String
    bgHex: String
    buttonColor: String
    accentColor: String
    vertical: String
    isActive: Boolean!
    order: Int!
    createdAt: Date
    updatedAt: Date
  }

  input BannerInput {
    title: String!
    subtitle: String
    tag: String
    image: String!
    link: String
    discount: String
    platform: String
    bgGradient: String
    bgHex: String
    buttonColor: String
    accentColor: String
    vertical: String
    isActive: Boolean
    order: Int
  }

  # ===================== STORE SETTINGS =====================
  type StoreSetting {
    _id: ID!
    storeName: String
    logoUrl: String
    faviconUrl: String
    appIconUrl: String
    disabledVerticals: [String]
    serviceBookingMode: String
    serviceContactPhone: String
    createdAt: Date
    updatedAt: Date
  }

  # ===================== SUPPORT TICKET =====================
  type SupportTicket {
    _id: ID!
    ticketNumber: String!
    user: User
    name: String
    email: String
    phone: String
    subject: String!
    message: String!
    category: String
    status: String!
    priority: String
    adminReply: String
    adminNotes: String
    repliedBy: User
    repliedAt: Date
    createdAt: Date
    updatedAt: Date
  }

  input CreateSupportTicketInput {
    subject: String!
    message: String!
    category: String
    name: String
    email: String
    phone: String
    priority: String
  }

  # ===================== INPUTS =====================
  input RegisterInput {
    name: String
    email: String!
    password: String!
    phone: String
    role: String
    acceptedTerms: Boolean
    vendorCategory: String
    vendorVertical: String
    vendorVerticals: [String]
  }

  input LoginInput {
    email: String!
    password: String!
  }

  input CreateUserInput {
    name: String!
    email: String!
    password: String!
    role: String!
    phone: String
    permissions: [String]
    vendorCategory: String
    vendorVertical: String
    vendorVerticals: [String]
    commissionRate: Float
  }

  input UpdateUserInput {
    name: String
    email: String
    role: String
    phone: String
    isActive: Boolean
    isVerified: Boolean
    permissions: [String]
    password: String
    vendorCategory: String
    vendorVertical: String
    vendorVerticals: [String]
    commissionRate: Float
  }

  input RolePermissionInput {
    roleName: String!
    displayName: String!
    description: String
    modules: [String!]!
  }

  input DeliveryOptionInput {
    name: String!
    description: String
    estimatedDays: String!
    price: Float!
    minOrderForFree: Float
    isDefault: Boolean
    isActive: Boolean
    sortOrder: Int
  }

  input TaxSettingInput {
    name: String!
    rate: Float!
    cgst: Float
    sgst: Float
    igst: Float
    hsnCode: String
    isDefault: Boolean
    isActive: Boolean
    description: String
  }

  input AddressInput {
    label: String
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String!
    isDefault: Boolean
  }

  type SupportTicket {
    _id: ID!
    ticketNumber: String
    user: User
    name: String!
    email: String!
    phone: String
    subject: String!
    message: String!
    category: String
    status: String!
    priority: String
    adminReply: String
    adminNotes: String
    repliedBy: User
    repliedAt: Date
    createdAt: Date
    updatedAt: Date
  }

  input CreateSupportTicketInput {
    subject: String!
    message: String!
    name: String
    email: String
    phone: String
    category: String
    priority: String
  }

  input SpecificationInput {
    key: String!
    value: String!
  }

  input ProductInput {
    name: String!
    description: String!
    shortDescription: String
    price: Float!
    comparePrice: Float
    images: [String!]!
    categoryId: ID!
    subcategoryId: ID
    stock: Int!
    sku: String
    weight: Float
    tags: [String]
    specifications: [SpecificationInput]
    highlights: [String]
    isFeatured: Boolean
    isDeals: Boolean
    freeShipping: Boolean
    shippingCost: Float
    disableCOD: Boolean
    vertical: String
    unitMeasure: String
    nutritionalHighlights: [String]
    isVeg: Boolean
    cuisine: [String]
    preparationTime: Int
    restaurantName: String
    serviceDuration: String
    includedFeatures: [String]
    warranty: String
    variants: [ProductVariantInput]
    approvalStatus: String
    commissionType: String
    commissionValue: Float
  }

  type VendorCommissionItem {
    vendor: User
    totalOrders: Int!
    totalSales: Float!
    totalCommission: Float!
    avgCommissionRate: Float!
  }

  type VendorCommissionResult {
    vendors: [VendorCommissionItem!]!
    totalCommissionEarned: Float!
    totalGrossSales: Float!
    totalOrdersCount: Int!
  }

  input VariantOptionInput {
    label: String!
    price: Float!
    stock: Int!
    sku: String
    thumbnail: String
    thumbnails: [String]
  }

  input ProductVariantInput {
    name: String!
    options: [VariantOptionInput!]!
  }

  input SpecificationInput {
    key: String!
    value: String!
  }

  input ProductFilterInput {
    categoryId: String
    category: String
    subcategoryId: String
    subcategory: String
    vertical: String
    isVeg: Boolean
    cuisine: [String]
    restaurantName: String
    minPrice: Float
    maxPrice: Float
    rating: Float
    minRating: Float
    inStock: Boolean
    isFeatured: Boolean
    isDeals: Boolean
    freeShipping: Boolean
    tags: [String]
    search: String
    vendorId: ID
    sort: String
    isActive: Boolean
    approvalStatus: String
    all: Boolean
    includeInactive: Boolean
  }

  input ProductSortInput {
    field: String
    order: String
  }

  input CartItemInput {
    productId: ID!
    variantIndex: Int
    quantity: Int!
  }

  input AddToCartInput {
    productId: ID!
    variantIndex: Int
    quantity: Int!
  }

  input OrderAddressInput {
    fullName: String!
    phone: String!
    addressLine1: String!
    addressLine2: String
    city: String!
    state: String!
    postalCode: String!
    country: String
  }

  input PlaceOrderInput {
    paymentMethod: String!
    notes: String
    shippingAddressId: ID
    deliveryOptionId: String
    deliverySlot: String
    vertical: String
    serviceDate: Date
    serviceTimeSlot: String
    tableOrNotes: String
    saveAsDefault: Boolean
  }

  input ReviewInput {
    targetType: String
    productId: ID
    vendorId: ID
    deliveryAgentId: ID
    orderId: ID
    rating: Int!
    title: String
    comment: String!
    images: [String]
  }

  input CouponInput {
    code: String!
    type: String!
    value: Float!
    description: String
    minOrderAmount: Float
    maxDiscount: Float
    validFrom: Date
    validUntil: Date
    usageLimit: Int
    isActive: Boolean
  }

  input CategoryInput {
    name: String!
    description: String
    image: String
    icon: String
    parentId: ID
    vertical: String
    sortOrder: Int
    isActive: Boolean
  }

  input PaginationInput {
    page: Int
    limit: Int
  }

  type BankDetails {
    accountHolderName: String
    accountNumber: String
    bankName: String
    ifscCode: String
    upiId: String
  }

  input BankDetailsInput {
    accountHolderName: String
    accountNumber: String
    bankName: String
    ifscCode: String
    upiId: String
  }

  type PayoutRequest {
    _id: ID!
    vendor: User!
    amount: Float!
    status: String!
    bankDetails: BankDetails
    adminNotes: String
    processedAt: Date
    processedBy: User
    createdAt: Date
    updatedAt: Date
  }

  type PayoutSummary {
    totalSales: Float!
    totalCommission: Float!
    totalEarnings: Float!
    eligibleBalance: Float!
    pendingPayout: Float!
    totalPaidOut: Float!
    returnPendingBalance: Float!
    bankDetails: BankDetails
  }

  type AdminVendorPayoutItem {
    vendor: User!
    eligibleBalance: Float!
    pendingPayout: Float!
    totalEarnings: Float!
    totalPaidOut: Float!
    returnPendingBalance: Float!
  }

  type AdminPayoutSummary {
    totalEligiblePayoutsPending: Float!
    totalPendingRequestsAmount: Float!
    totalPaidOut: Float!
    vendorPayoutsList: [AdminVendorPayoutItem!]!
  }

  # ===================== QUERIES =====================
  type Query {
    # Auth
    me: User
    checkUserExists(identifier: String!): Boolean!

    # Legal
    getLegalPage(slug: String!): LegalPage
    getLegalPages: [LegalPage!]!

    # Products
    getProducts(
      filter: ProductFilterInput
      sort: ProductSortInput
      pagination: PaginationInput
    ): ProductsResult!
    getProduct(slug: String!): Product
    getProductBySlug(slug: String!): Product
    getProductById(id: ID!): Product
    getFeaturedProducts(limit: Int): [Product!]!
    getDealsProducts(limit: Int): [Product!]!
    getDeals: [Product!]!
    getRelatedProducts(productId: ID!, limit: Int): [Product!]!
    searchProducts(query: String!, pagination: PaginationInput): ProductsResult!

    # Categories
    getCategories(parentId: ID, vertical: String): [Category!]!
    getCategory(slug: String!): Category
    getAllCategories: [Category!]!

    # Cart
    getCart: Cart

    # Orders (Customer & Vendor)
    getOrders(status: String, search: String, vertical: String, pagination: PaginationInput): OrdersResult!
    getOrder(id: ID!): Order
    getOrderByNumber(orderNumber: String!): Order
    trackOrder(orderId: ID!): Order
    getOrderInvoice(orderId: ID!): Invoice!
    getAssignedDeliveries(status: String, pagination: PaginationInput): OrdersResult!
    getDeliveryAgentOrders(status: String): [Order!]!
    getOrderLiveLocation(orderId: ID!): LiveLocation

    # Delivery & Tax Options
    getDeliveryOptions(activeOnly: Boolean): [DeliveryOption!]!
    getTaxSettings(activeOnly: Boolean): [TaxSetting!]!

    # Role Permissions
    getRoles: [RolePermission!]!
    getUserById(id: ID!): User

    # Admin Queries
    getAllOrders(status: String, search: String, vertical: String, pagination: PaginationInput): OrdersResult!
    getAllUsers(role: String, pagination: PaginationInput): [User!]!
    getDashboardStats(vertical: String): DashboardStats!
    getAllCoupons: [Coupon!]!
    getAnalytics(period: String): JSON
    getVendors(pagination: PaginationInput): [User!]!
    getVendorCommissions(sort: String, search: String): VendorCommissionResult!
    getDeliveryAgents: [User!]!

    # Notifications
    getNotifications: [Notification!]!
    getUnreadNotificationCount: Int!

    # Reviews
    getProductReviews(productId: ID!, pagination: PaginationInput): [Review!]!
    getVendorReviews(vendorId: ID!): [Review!]!
    getDeliveryReviews(deliveryAgentId: ID!): [Review!]!
    getAllReviews(targetType: String, pagination: PaginationInput): [Review!]!

    # Banners
    getBanners(platform: String, vertical: String): [Banner!]!

    # Store Settings
    getStoreSettings: StoreSetting

    # Support Tickets
    getMySupportTickets: [SupportTicket!]!
    getAllSupportTickets(status: String, search: String, pagination: PaginationInput): [SupportTicket!]!
    getSupportTicket(id: ID!): SupportTicket

    # Payouts & Vendor Bank Details
    getVendorPayoutSummary(vendorId: ID): PayoutSummary!
    getAdminPayoutSummary: AdminPayoutSummary!
    getPayoutRequests(status: String, vendorId: ID): [PayoutRequest!]!
    getVendorBankDetails(vendorId: ID): BankDetails
  }

  # ===================== MUTATIONS =====================
  type Mutation {
    # Payouts & Vendor Bank Details
    updateVendorBankDetails(input: BankDetailsInput!, vendorId: ID): BankDetails!
    requestVendorPayout(amount: Float): PayoutRequest!
    updatePayoutRequestStatus(id: ID!, status: String!, adminNotes: String): PayoutRequest!
    # Auth & Forgot Password
    register(input: RegisterInput!): AuthPayload!
    login(input: LoginInput!): AuthPayload!
    sendLoginOTP(email: String!): AuthResponse!
    loginWithOTP(email: String!, otp: String!): AuthResponse!
    forgotPassword(email: String!): ForgotPasswordResponse!
    resetPassword(token: String!, newPassword: String!): AuthPayload!
    verifyResetOTP(email: String!, otp: String!): ForgotPasswordResponse!
    logout: Boolean!
    refreshToken(token: String!): AuthPayload!
    updateProfile(name: String, phone: String, avatar: String): User!
    changePassword(currentPassword: String!, newPassword: String!): Boolean!

    # Legal
    updateLegalPage(slug: String!, title: String!, content: String!): LegalPage!

    # Address
    addAddress(input: AddressInput!): User!
    updateAddress(addressId: ID!, input: AddressInput!): User!
    deleteAddress(addressId: ID!): User!

    # Wishlist
    toggleWishlist(productId: ID!): User!

    # Products (Admin/Vendor)
    createProduct(input: ProductInput!): Product!
    updateProduct(id: ID!, input: ProductInput!): Product!
    deleteProduct(id: ID!): Boolean!
    toggleProductStatus(id: ID!): Product!
    updateProductApproval(id: ID!, status: String!, reason: String, commissionType: String, commissionValue: Float): Product!

    # Categories (Admin)
    createCategory(input: CategoryInput!): Category!
    updateCategory(id: ID!, input: CategoryInput!): Category!
    deleteCategory(id: ID!): Boolean!

    # Cart
    addToCart(input: CartItemInput!): Cart!
    syncCart(items: [CartItemInput!]!): Cart!
    updateCartItem(itemId: ID!, quantity: Int!): Cart!
    removeFromCart(itemId: ID!): Cart!
    clearCart: Boolean!
    applyCoupon(code: String!): Cart!
    removeCoupon: Cart!

    # Orders
    placeOrder(input: PlaceOrderInput!, address: OrderAddressInput): Order!
    cancelOrder(orderId: ID!, reason: String!): Order!
    updateOrderStatus(
      orderId: ID!
      status: String!
      message: String
      location: String
    ): Order!
    requestReturn(orderId: ID!, reason: String!): Order!
    updateReturnStatus(orderId: ID!, status: String!): Order!
    assignDeliveryBoy(orderId: ID!, deliveryBoyId: ID!): Order!
    assignDeliveryAgent(orderId: ID!, deliveryAgentId: ID!): Order!
    updateDeliveryLocation(
      orderId: ID!
      latitude: Float!
      longitude: Float!
      heading: Float
      speed: Float
    ): Order!
    updateDeliveryStatus(
      orderId: ID!
      status: String!
      notes: String
      latitude: Float
      longitude: Float
    ): Order!
    updateAgentDutyStatus(
      isOnline: Boolean!
      latitude: Float
      longitude: Float
    ): User!

    # Delivery Options (Admin)
    createDeliveryOption(input: DeliveryOptionInput!): DeliveryOption!
    updateDeliveryOption(id: ID!, input: DeliveryOptionInput!): DeliveryOption!
    deleteDeliveryOption(id: ID!): Boolean!

    # Tax Management (Admin)
    createTaxSetting(input: TaxSettingInput!): TaxSetting!
    updateTaxSetting(id: ID!, input: TaxSettingInput!): TaxSetting!
    deleteTaxSetting(id: ID!): Boolean!

    # Role Management (Admin)
    saveRolePermissions(input: RolePermissionInput!): RolePermission!
    deleteRole(id: ID!): Boolean!

    # Admin User Management
    createUser(input: CreateUserInput!): User!
    updateUser(id: ID!, input: UpdateUserInput!): User!
    deleteUser(id: ID!): Boolean!
    updateUserStatus(userId: ID!, isActive: Boolean!): User!
    updateUserRole(userId: ID!, role: String!): User!

    # Payments
    createPaymentIntent(orderId: ID!): PaymentIntent!
    confirmPayment(orderId: ID!, paymentIntentId: String!): Order!

    # Reviews & Replies
    addReview(input: ReviewInput!): Review!
    replyToReview(reviewId: ID!, comment: String!): Review!
    updateReview(reviewId: ID!, input: ReviewInput!): Review!
    deleteReview(reviewId: ID!): Boolean!
    markReviewHelpful(reviewId: ID!): Review!

    # Coupons (Admin)
    createCoupon(input: CouponInput!): Coupon!
    updateCoupon(id: ID!, input: CouponInput!): Coupon!
    deleteCoupon(id: ID!): Boolean!
    validateCoupon(code: String!, orderAmount: Float!): CouponValidation!

    # Notifications
    markNotificationRead(id: ID!): Notification!
    markAllNotificationsRead: Boolean!
    updateFcmToken(token: String!): Boolean!

    # Banners (Admin)
    createBanner(input: BannerInput!): Banner!
    updateBanner(id: ID!, input: BannerInput!): Banner!
    deleteBanner(id: ID!): Boolean!

    # Store Settings (Superadmin)
    updateStoreSettings(storeName: String, logoUrl: String, faviconUrl: String, appIconUrl: String, disabledVerticals: [String], serviceBookingMode: String, serviceContactPhone: String): StoreSetting

    # Support Tickets
    createSupportTicket(input: CreateSupportTicketInput!): SupportTicket!
    replySupportTicket(ticketId: ID!, reply: String!, status: String): SupportTicket!
    updateSupportTicketStatus(id: ID!, status: String!, adminNotes: String): SupportTicket!
  }

  # ===================== SUBSCRIPTIONS =====================
  type Subscription {
    orderStatusUpdated(orderId: ID!): Order!
    newOrderNotification: Order!
    notificationReceived(userId: ID!): Notification!
  }
`;
