// Version: 1.0.1 - Enable Super Category Verticals storewide
import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer';
import { makeExecutableSchema } from '@graphql-tools/schema';
import { WebSocketServer } from 'ws';
import { useServer } from 'graphql-ws/lib/use/ws';
import rateLimit from 'express-rate-limit';
import bodyParser from 'body-parser';
import multer from 'multer';

import connectDB from './config/database.js';
import { typeDefs } from './graphql/schema/typeDefs.js';
import resolvers from './graphql/resolvers/index.js';
import { authenticate } from './middleware/auth.middleware.js';
import { uploadImage } from './config/cloudinary.js';

import { autoSeed } from './utils/autoSeed.js';

import AdmZip from 'adm-zip';
import { parse } from 'csv-parse/sync';
import slugify from 'slugify';
import Order from './models/Order.js';
import Product from './models/Product.js';
import Category from './models/Category.js';

import { validateEnv } from './config/validateEnv.js';
import { checkIpRateLimit } from './utils/rateLimiter.js';
import { validateImageSignature, validateZipSignature, validateCsvContent } from './utils/fileValidator.js';

// Validate environment variables on startup
validateEnv();

const app = express();

// Configure secure multer with file filter and size limits
const ALLOWED_IMAGE_MIMES = ['image/jpeg', 'image/png', 'image/webp'];
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    if (ALLOWED_IMAGE_MIMES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, and WebP images are allowed.'));
    }
  },
});
const uploadZip = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB zip limit
});
const uploadCsv = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB csv limit
});

const httpServer = http.createServer(app);

// Create GraphQL schema
const schema = makeExecutableSchema({ typeDefs, resolvers });

// WebSocket server for subscriptions
const wsServer = new WebSocketServer({
  server: httpServer,
  path: '/graphql',
});

const serverCleanup = useServer(
  {
    schema,
    context: async (ctx) => {
      // Extract auth token from WebSocket connection params
      const token = ctx.connectionParams?.Authorization || ctx.connectionParams?.authorization;
      let user = null;
      if (token) {
        try {
          const req = { headers: { authorization: token } };
          user = await authenticate(req);
        } catch (e) {
          // Ignore auth errors for subscriptions
        }
      }
      return { user };
    },
  },
  wsServer
);

// Apollo Server
const server = new ApolloServer({
  schema,
  plugins: [
    ApolloServerPluginDrainHttpServer({ httpServer }),
    {
      async serverWillStart() {
        return {
          async drainServer() {
            await serverCleanup.dispose();
          },
        };
      },
    },
  ],
  formatError: (formattedError, error) => {
    // Log FULL error details server-side for debugging
    console.error('[GraphQL Error Detail]', {
      message: error?.message || formattedError.message,
      code: formattedError.extensions?.code,
      path: formattedError.path,
      stack: error?.stack || error?.originalError?.stack,
    });

    const rawMessage = `${formattedError.message || ''} ${error?.originalError?.message || ''} ${error?.message || ''}`;

    // Handle MongoDB Duplicate Key Error (Code 11000 / E11000)
    if (
      rawMessage.includes('E11000') ||
      rawMessage.includes('duplicate key error') ||
      error?.originalError?.code === 11000 ||
      error?.originalError?.name === 'MongoServerError'
    ) {
      let userFriendlyMessage = 'An entry with this information already exists.';
      if (rawMessage.toLowerCase().includes('review') || rawMessage.includes('reviews')) {
        userFriendlyMessage = 'You have already submitted a review for this target/order.';
      } else if (rawMessage.includes('phone') || rawMessage.includes('phone_1')) {
        userFriendlyMessage = 'A user with this phone number already exists.';
      } else if (rawMessage.includes('email') || rawMessage.includes('email_1')) {
        userFriendlyMessage = 'A user with this email address already exists.';
      } else if (rawMessage.toLowerCase().includes('user')) {
        userFriendlyMessage = 'An account with this information already exists.';
      }

      return {
        message: userFriendlyMessage,
        extensions: {
          code: 'BAD_USER_INPUT',
          field: rawMessage.includes('phone') ? 'phone' : rawMessage.includes('email') ? 'email' : 'duplicate',
        },
      };
    }

    // Mask internal server / DB / filesystem errors
    const isInternalOrDb =
      rawMessage.includes('Cast to ObjectId') ||
      rawMessage.includes('Mongo') ||
      rawMessage.includes('Mongoose') ||
      rawMessage.includes('EACCES') ||
      rawMessage.includes('ENOENT') ||
      /([A-Z]:\\[^\s]+|\/[^\s]+)/i.test(rawMessage);

    const code = formattedError.extensions?.code || 'INTERNAL_SERVER_ERROR';

    if (code === 'INTERNAL_SERVER_ERROR' || isInternalOrDb) {
      return {
        message: isInternalOrDb
          ? 'Invalid request parameters or resource format'
          : 'An unexpected internal error occurred. Please try again later.',
        extensions: { code: isInternalOrDb ? 'BAD_USER_INPUT' : 'INTERNAL_SERVER_ERROR' },
      };
    }

    // Always strip stack trace and exception extensions before sending to client
    const { exception, stacktrace, ...safeExtensions } = formattedError.extensions || {};
    return {
      message: formattedError.message,
      extensions: safeExtensions,
      locations: formattedError.locations,
      path: formattedError.path,
    };
  },
  introspection: true,
});

const startServer = async () => {
  // Start Apollo Server
  await server.start();

  // Connect to MongoDB
  try {
    await connectDB();
  } catch (err) {
    console.warn('⚠️ Database connection warning:', err.message);
  }

  // Middleware
  app.use(
    helmet({
      contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false,
      crossOriginEmbedderPolicy: false,
    })
  );

  const allowedOrigins = [
    'https://ecommerce-website-zeta-lilac.vercel.app',
    'https://ecommerce-admin-mu.vercel.app',
    process.env.FRONTEND_URL,
    process.env.ADMIN_URL,
  ].filter(Boolean);

  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow mobile apps, curl, Postman (no origin header)
        if (!origin) return callback(null, true);
        if (
          allowedOrigins.includes(origin) ||
          /^https?:\/\/(localhost|127\.0\.0\.1|192\.168\.\d+\.\d+|10\.\d+\.\d+\.\d+)(:\d+)?$/.test(origin) ||
          /\.vercel\.app$/.test(origin) ||
          /\.onrender\.com$/.test(origin)
        ) {
          return callback(null, true);
        }
        return callback(new Error('CORS policy: Not allowed by CORS'));
      },
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept'],
    })
  );

  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

  // Trust Render's load balancer proxy for accurate rate limiting
  app.set('trust proxy', 1);

  // Configurable Tiered Rate Limiting Middleware
  const tieredRateLimiter = async (req, res, next) => {
    try {
      const ip = req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
      let tier = 'public';

      if (req.headers.authorization) {
        tier = 'authenticated';
      }

      // Check if GraphQL body contains Auth mutations
      if (req.path === '/graphql' && req.body) {
        const bodyStr = JSON.stringify(req.body);
        if (
          bodyStr.includes('login(') ||
          bodyStr.includes('register(') ||
          bodyStr.includes('forgotPassword') ||
          bodyStr.includes('resetPassword') ||
          bodyStr.includes('sendLoginOTP') ||
          bodyStr.includes('loginWithOTP') ||
          bodyStr.includes('verifyResetOTP')
        ) {
          tier = 'auth';
        }
      }

      const rateCheck = await checkIpRateLimit(ip, tier);
      res.setHeader('X-RateLimit-Limit', rateCheck.total || 100);
      res.setHeader('X-RateLimit-Remaining', rateCheck.remaining || 0);

      if (!rateCheck.allowed) {
        return res.status(429).json({
          errors: [
            {
              message: `Too many requests on ${tier} endpoints. Please try again later.`,
              extensions: { code: 'TOO_MANY_REQUESTS' },
            },
          ],
        });
      }
      next();
    } catch (err) {
      console.error('Rate limiting middleware error:', err);
      next();
    }
  };

  app.use(bodyParser.json({ limit: '10mb' }));
  app.use(tieredRateLimiter);

  // GraphQL endpoint
  app.use(
    '/graphql',
    expressMiddleware(server, {
      context: async ({ req }) => {
        const user = await authenticate(req);
        return { user, req };
      },
    })
  );

  // Health check endpoint
  app.get('/health', (req, res) => {
    res.json({
      status: 'OK',
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      cloudinary: !!process.env.CLOUDINARY_API_KEY && process.env.CLOUDINARY_API_KEY !== 'placeholder'
    });
  });

  // Single Image Upload endpoint with Buffer Magic Byte Verification
  app.post('/api/upload', upload.single('image'), async (req, res) => {
    try {
      const user = await authenticate(req);
      if (!user) {
        return res.status(401).json({ success: false, error: 'Unauthenticated' });
      }
      if (!req.file) {
        return res.status(400).json({ success: false, error: 'No image provided' });
      }

      // Content Magic-Byte Signature Validation
      const sigCheck = validateImageSignature(req.file.buffer);
      if (!sigCheck.valid) {
        return res.status(400).json({ success: false, error: sigCheck.error });
      }
      
      const result = await uploadImage(req.file.buffer, 'ecommerce');
      return res.json({ success: true, url: result.secure_url });
    } catch (error) {
      console.error('Upload error:', error);
      return res.status(500).json({ 
        success: false, 
        error: 'Image upload failed' 
      });
    }
  });

  // Multiple Images Upload endpoint with Buffer Magic Byte Verification
  app.post('/api/upload/multiple', upload.array('images', 5), async (req, res) => {
    try {
      const user = await authenticate(req);
      if (!user) {
        return res.status(401).json({ success: false, error: 'Unauthenticated' });
      }
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ success: false, error: 'No images provided' });
      }

      for (const file of req.files) {
        const sigCheck = validateImageSignature(file.buffer);
        if (!sigCheck.valid) {
          return res.status(400).json({ success: false, error: `${file.originalname}: ${sigCheck.error}` });
        }
      }

      const urls = [];
      for (const file of req.files) {
        const result = await uploadImage(file.buffer, 'ecommerce');
        urls.push(result.secure_url);
      }
      
      return res.json({ success: true, urls });
    } catch (error) {
      console.error('Multiple upload error:', error);
      return res.status(500).json({ 
        success: false, 
        error: 'Multiple images upload failed' 
      });
    }
  });

  // Bulk Upload Images with ZIP Magic Byte Verification
  app.post('/api/products/bulk-images', uploadZip.single('zip'), async (req, res) => {
    try {
      const user = await authenticate(req);
      if (!user || !['superadmin', 'admin', 'vendor'].includes(user.role)) {
        return res.status(401).json({ success: false, error: 'Unauthorized' });
      }
      if (!req.file) {
        return res.status(400).json({ success: false, error: 'No zip file provided' });
      }

      const zipSigCheck = validateZipSignature(req.file.buffer);
      if (!zipSigCheck.valid) {
        return res.status(400).json({ success: false, error: zipSigCheck.error });
      }
      
      const zip = new AdmZip(req.file.buffer);
      const zipEntries = zip.getEntries();
      
      for (const zipEntry of zipEntries) {
        // Prevent path traversal and malicious filenames
        if (zipEntry.isDirectory || zipEntry.name.includes('..') || zipEntry.name.startsWith('/') || !zipEntry.name.match(/\.(jpg|jpeg|png|webp)$/i)) continue;
        
        const filename = zipEntry.name.replace(/^.*[\\\/]/, ''); // sanitize basename
        const match = filename.match(/^([a-f\d]{24})(?:_(\d+))?\./i);
        if (!match) continue;
        
        const productId = match[1];
        const buffer = zipEntry.getData();

        // Validate extracted image magic bytes
        const imgSig = validateImageSignature(buffer);
        if (!imgSig.valid) continue;

        const result = await uploadImage(buffer, 'ecommerce');
        const url = result.secure_url;
        
        const productQuery = user.role === 'vendor' ? { _id: productId, vendor: user._id } : { _id: productId };
        const product = await Product.findOne(productQuery);
        if (product) {
          if (!product.images) product.images = [];
          if (product.images.length === 0 || !match[2]) {
             product.images = [url, ...product.images.filter(i => i !== url)];
          } else {
             product.images.push(url);
          }
          await product.save();
        }
      }
      
      return res.json({ success: true, message: 'Images uploaded and processed' });
    } catch (error) {
      console.error('Bulk image error:', error);
      return res.status(500).json({ success: false, error: 'Processing bulk images failed' });
    }
  });

  // Bulk Upload CSV with Content Verification
  app.post('/api/products/bulk-upload', uploadCsv.single('csv'), async (req, res) => {
    try {
      const user = await authenticate(req);
      if (!user || !['superadmin', 'admin', 'vendor'].includes(user.role)) {
        return res.status(401).json({ success: false, error: 'Unauthorized' });
      }
      if (!req.file) {
        return res.status(400).json({ success: false, error: 'No csv file provided' });
      }

      const csvSigCheck = validateCsvContent(req.file.buffer);
      if (!csvSigCheck.valid) {
        return res.status(400).json({ success: false, error: csvSigCheck.error });
      }
      
      const records = parse(req.file.buffer, {
        columns: true,
        skip_empty_lines: true
      });
      
      let count = 0;
      for (const row of records) {
        let slug = row.slug;
        if (!slug && row.name) {
           slug = slugify(row.name, { lower: true, strict: true });
        }
        
        let categoryId = row.categoryId || row.category;
        
        // If category is provided but is not a valid 24-character hex string (ObjectId), try to find it by name
        if (categoryId && !/^[0-9a-fA-F]{24}$/.test(categoryId)) {
          const categoryDoc = await Category.findOne({ name: { $regex: new RegExp(`^${categoryId}$`, 'i') } });
          if (categoryDoc) {
            categoryId = categoryDoc._id;
          } else {
            throw new Error(`Category "${categoryId}" not found. Please create it first or provide a valid category ID.`);
          }
        }
        
        const productData = {
           name: row.name,
           description: row.description,
           price: parseFloat(row.price || 0),
           stock: parseInt(row.stock || 0),
           category: categoryId,
           slug,
        };
        
        if (user.role === 'vendor') {
           productData.vendor = user._id;
        } else if (row.vendorId) {
           productData.vendor = row.vendorId;
        }
        
        if (row._id) {
           const updateQuery = user.role === 'vendor' ? { _id: row._id, vendor: user._id } : { _id: row._id };
           await Product.findOneAndUpdate(updateQuery, productData);
        } else if (slug) {
           await Product.findOneAndUpdate({ slug }, productData, { upsert: true, new: true });
        }
        count++;
      }
      
      return res.json({ success: true, message: `Processed ${count} products` });
    } catch (error) {
      console.error('Bulk csv error:', error);
      return res.status(500).json({ success: false, error: 'Processing bulk CSV failed' });
    }
  });

  // Root endpoint info
  app.get('/', (req, res) => {
    res.json({
      name: 'E-Commerce API',
      version: '1.0.0',
      graphql: `http://localhost:${process.env.PORT || 4000}/graphql`,
      health: `http://localhost:${process.env.PORT || 4000}/health`,
    });
  });

  const PORT = process.env.PORT || 4000;
  httpServer.listen(PORT, async () => {
    console.log(`🚀 Server ready at http://localhost:${PORT}/graphql`);
    console.log(`📡 Subscriptions ready at ws://localhost:${PORT}/graphql`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV}`);
    
    // Sync indexes to apply schema changes (like removing unique/required constraints)
    try {
      const mongoose = await import('mongoose');
      const User = mongoose.model('User');
      await User.syncIndexes();
      console.log('✅ User indexes synced successfully');

      // Auto-correct any legacy 0-amount orders in database
      const zeroOrders = await Order.find({ $or: [{ total: { $lte: 0 } }, { total: null }, { subtotal: { $lte: 0 } }] });
      if (zeroOrders.length > 0) {
        console.log(`🛠️ Fixing ${zeroOrders.length} zero-amount orders in MongoDB...`);
        for (const ord of zeroOrders) {
          let itemsSubtotal = 0;
          if (Array.isArray(ord.items)) {
            for (const item of ord.items) {
              const p = Number(item.price || 0);
              const q = Number(item.quantity || 1);
              itemsSubtotal += p * q;
            }
          }
          const sub = ord.subtotal && ord.subtotal > 0 ? ord.subtotal : itemsSubtotal;
          const disc = Number(ord.discount || 0);
          const ship = Number(ord.shippingCost || 0);
          const tax = ord.tax && ord.tax > 0 ? ord.tax : Math.round(Math.max(0, sub - disc) * 0.18 * 100) / 100;
          const calcTotal = Math.round(Math.max(0, sub - disc + ship + tax) * 100) / 100;
          if (calcTotal > 0) {
            ord.subtotal = sub;
            ord.tax = tax;
            ord.total = calcTotal;
            await ord.save();
          }
        }
        console.log(`✅ Zero-amount orders auto-corrected in MongoDB!`);
      }
    } catch (err) {
      console.log('⚠️ Failed to sync User indexes / fix zero orders:', err.message);
    }
  });

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('SIGTERM received. Shutting down gracefully...');
    await server.stop();
    httpServer.close(() => {
      console.log('Server closed.');
      process.exit(0);
    });
  });
};

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
