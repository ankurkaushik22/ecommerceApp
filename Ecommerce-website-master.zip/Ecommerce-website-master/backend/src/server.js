import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer';
import { makeExecutableSchema } from '@graphql-tools/schema';
import { WebSocketServer } from 'ws';
import { useServer } from 'graphql-ws/lib/use/ws';
import rateLimit from 'express-rate-limit';
import bodyParser from 'body-parser';

import connectDB from './config/database.js';
import { typeDefs } from './graphql/schema/typeDefs.js';
import resolvers from './graphql/resolvers/index.js';
import { authenticate } from './middleware/auth.middleware.js';

import { autoSeed } from './utils/autoSeed.js';

const app = express();
const httpServer = http.createServer(app);

// Create GraphQL schema
const schema = makeExecutableSchema({ typeDefs, resolvers });

// WebSocket server for subscriptions
const wsServer = new WebSocketServer({
  server: httpServer,
  path: '/graphql',
});

const serverCleanup = useServer(
  {
    schema,
    context: async (ctx) => {
      // Extract auth token from WebSocket connection params
      const token = ctx.connectionParams?.Authorization || ctx.connectionParams?.authorization;
      let user = null;
      if (token) {
        try {
          const req = { headers: { authorization: token } };
          user = await authenticate(req);
        } catch (e) {
          // Ignore auth errors for subscriptions
        }
      }
      return { user };
    },
  },
  wsServer
);

// Apollo Server
const server = new ApolloServer({
  schema,
  plugins: [
    ApolloServerPluginDrainHttpServer({ httpServer }),
    {
      async serverWillStart() {
        return {
          async drainServer() {
            await serverCleanup.dispose();
          },
        };
      },
    },
  ],
  formatError: (formattedError, error) => {
    // Don't leak internal errors in production
    if (process.env.NODE_ENV === 'production') {
      if (formattedError.extensions?.code === 'INTERNAL_SERVER_ERROR') {
        return { message: 'An internal error occurred', extensions: { code: 'INTERNAL_SERVER_ERROR' } };
      }
    }
    return formattedError;
  },
  introspection: true, // Allow GraphQL Playground in dev
});

const startServer = async () => {
  // Start Apollo Server
  await server.start();

  // Connect to MongoDB in background so server opens instantly
  connectDB().catch((err) => {
    console.warn('⚠️ Database connection warning:', err.message);
  });

  // Middleware
  app.use(
    helmet({
      contentSecurityPolicy: process.env.NODE_ENV === 'production' ? undefined : false,
      crossOriginEmbedderPolicy: false,
    })
  );

  app.use(
    cors({
      origin: [
        process.env.CLIENT_URL || 'http://localhost:3000',
        process.env.ADMIN_URL || 'http://localhost:5173',
        'http://localhost:3001',
        'http://localhost:5174',
      ],
      credentials: true,
    })
  );

  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 500, // Limit each IP to 500 requests per window
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
  });
  app.use('/graphql', limiter);

  // GraphQL endpoint
  app.use(
    '/graphql',
    bodyParser.json({ limit: '10mb' }),
    expressMiddleware(server, {
      context: async ({ req }) => {
        const user = await authenticate(req);
        return { user, req };
      },
    })
  );

  // Health check endpoint
  app.get('/health', (req, res) => {
    res.json({
      status: 'OK',
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
    });
  });

// Seed database (temporary route)
app.get('/seed-db', async (req, res) => {
  try {
    await autoSeed();
    res.json({
      success: true,
      message: 'Database seeded successfully!',
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

  // Root endpoint info
  app.get('/', (req, res) => {
    res.json({
      name: 'E-Commerce API',
      version: '1.0.0',
      graphql: `http://localhost:${process.env.PORT || 4000}/graphql`,
      health: `http://localhost:${process.env.PORT || 4000}/health`,
    });
  });

  const PORT = process.env.PORT || 4000;
  httpServer.listen(PORT, () => {
    console.log(`🚀 Server ready at http://localhost:${PORT}/graphql`);
    console.log(`📡 Subscriptions ready at ws://localhost:${PORT}/graphql`);
    console.log(`🌍 Environment: ${process.env.NODE_ENV}`);
  });

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('SIGTERM received. Shutting down gracefully...');
    await server.stop();
    httpServer.close(() => {
      console.log('Server closed.');
      process.exit(0);
    });
  });
};

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
