import Redis from 'ioredis';

let redis;

const createRedisClient = () => {
  try {
    const client = new Redis(process.env.REDIS_URL || 'redis://localhost:6379', {
      maxRetriesPerRequest: 3,
      retryStrategy(times) {
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
      reconnectOnError(err) {
        const targetError = 'READONLY';
        if (err.message.includes(targetError)) {
          return true;
        }
        return false;
      },
    });

    client.on('connect', () => {
      console.log('✅ Redis Connected');
    });

    client.on('error', (err) => {
      console.error('❌ Redis error:', err.message);
    });

    client.on('reconnecting', () => {
      console.warn('⚠️ Redis reconnecting...');
    });

    return client;
  } catch (error) {
    console.error('❌ Failed to create Redis client:', error.message);
    // Return a mock client that fails gracefully
    return {
      get: async () => null,
      set: async () => null,
      del: async () => null,
      setex: async () => null,
    };
  }
};

redis = createRedisClient();

export default redis;
