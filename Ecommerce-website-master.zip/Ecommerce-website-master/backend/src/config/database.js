import mongoose from 'mongoose';
import dns from 'node:dns';

// Fix Node.js Windows DNS SRV lookup for mongodb+srv:// Atlas URIs
try {
  dns.setServers(['8.8.8.8', '1.1.1.1', '8.8.4.4']);
} catch {
  // Ignore in environments where setting servers is restricted
}

const connectDB = async () => {
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/ecommerce';
  
  // Allow standard query buffering
  mongoose.set('bufferCommands', true);

  try {
    const conn = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
      autoIndex: true,
    });
    console.log(`✅ MongoDB Connected Successfully: ${conn.connection.host}`);

    mongoose.connection.on('error', (err) => {
      console.error('❌ MongoDB connection error:', err.message);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️ MongoDB disconnected.');
    });

    return conn;
  } catch (error) {
    console.error(`❌ Failed to connect to MongoDB at: ${uri}`);
    console.error(`👉 Error details: ${error.message}`);
    console.error(`💡 If using MongoDB Compass / Local: Please ensure MongoDB Community Server is installed and running on port 27017.`);
    console.error(`💡 If using MongoDB Atlas (Cloud): Please paste your connection string in backend/.env as MONGODB_URI=mongodb+srv://...`);
    throw error;
  }
};

export default connectDB;
