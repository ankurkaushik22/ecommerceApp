export const validateEnv = () => {
  const required = ['MONGODB_URI', 'JWT_SECRET', 'REFRESH_TOKEN_SECRET'];
  const missing = required.filter((key) => !process.env[key]);

  if (missing.length > 0) {
    console.error(`❌ FATAL: Missing critical environment variables: ${missing.join(', ')}`);
    if (process.env.NODE_ENV === 'production') {
      process.exit(1);
    } else {
      console.warn('⚠️ Running in non-production mode with fallback defaults.');
    }
  }

  // Check weak secrets in production
  if (process.env.NODE_ENV === 'production') {
    if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) {
      console.warn('⚠️ WARNING: JWT_SECRET should be at least 32 characters long for production security.');
    }
  }

  // Set default WhatsApp Gateway configuration (Live Render URL fallback)
  process.env.WHATSAPP_GATEWAY_URL = process.env.WHATSAPP_GATEWAY_URL || 'https://ecommerce-whatsappservice.onrender.com';
  process.env.WHATSAPP_API_KEY = process.env.WHATSAPP_API_KEY || 'suaaka_whatsapp_otp_secret_key_98765';

  // Set & log rate limit configuration defaults
  process.env.RATE_LIMIT_AUTH_IP_WINDOW_MS = process.env.RATE_LIMIT_AUTH_IP_WINDOW_MS || '900000';
  process.env.RATE_LIMIT_AUTH_IP_MAX = process.env.RATE_LIMIT_AUTH_IP_MAX || '15';
  process.env.RATE_LIMIT_AUTH_ACCOUNT_MAX = process.env.RATE_LIMIT_AUTH_ACCOUNT_MAX || '5';
  process.env.RATE_LIMIT_AUTH_BACKOFF_BASE_SEC = process.env.RATE_LIMIT_AUTH_BACKOFF_BASE_SEC || '2';
  process.env.RATE_LIMIT_AUTH_BACKOFF_MAX_SEC = process.env.RATE_LIMIT_AUTH_BACKOFF_MAX_SEC || '3600';
  process.env.RATE_LIMIT_PUBLIC_WINDOW_MS = process.env.RATE_LIMIT_PUBLIC_WINDOW_MS || '900000';
  process.env.RATE_LIMIT_PUBLIC_MAX = process.env.RATE_LIMIT_PUBLIC_MAX || '300';
  process.env.RATE_LIMIT_AUTHENTICATED_WINDOW_MS = process.env.RATE_LIMIT_AUTHENTICATED_WINDOW_MS || '900000';
  process.env.RATE_LIMIT_AUTHENTICATED_MAX = process.env.RATE_LIMIT_AUTHENTICATED_MAX || '2000';
};
