import express from 'express';
import pkg from 'whatsapp-web.js';
import qrcodeTerminal from 'qrcode-terminal';
import QRCode from 'qrcode';
import puppeteer from 'puppeteer';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, '../../../.env') });

const { Client, LocalAuth } = pkg;
const app = express();
app.use(express.json());

const PORT = process.env.PORT || process.env.WHATSAPP_PORT || 5001;
const API_SECRET_KEY = process.env.WHATSAPP_API_KEY || 'suaaka_whatsapp_otp_secret_key_98765';
const AUTH_DIR = path.resolve(__dirname, './.wwebjs_auth');

let client = null;
let gatewayStatus = 'DISCONNECTED'; // 'DISCONNECTED' | 'INITIALIZING' | 'QR_READY' | 'CONNECTED'
let qrCodeDataUrl = null;
let connectedInfo = null;
let lastError = null;

// Helper to convert ASCII QR string from qrcode-terminal into SVG Data URL
function asciiToSvgDataUrl(asciiStr) {
  if (!asciiStr) return null;
  const lines = asciiStr.split('\n').filter((line) => line.length > 0);
  const height = lines.length;
  const width = lines[0] ? lines[0].length : 0;

  let rects = '';
  for (let r = 0; r < height; r++) {
    const line = lines[r];
    for (let c = 0; c < line.length; c++) {
      const char = line[c];
      if (char === '█') {
        rects += `<rect x="${c}" y="${r * 2}" width="1" height="2" fill="#000"/>`;
      } else if (char === '▀') {
        rects += `<rect x="${c}" y="${r * 2}" width="1" height="1" fill="#000"/>`;
      } else if (char === '▄') {
        rects += `<rect x="${c}" y="${r * 2 + 1}" width="1" height="1" fill="#000"/>`;
      }
    }
  }
  const svgHeight = height * 2;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${svgHeight}" width="280" height="280" style="background:#ffffff;padding:16px;border-radius:12px;">${rects}</svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
}

// Clean up any stale Chromium lock files if present
function removeChromiumLocks(dirPath) {
  if (!fs.existsSync(dirPath)) return;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        removeChromiumLocks(fullPath);
      } else if (
        entry.name.includes('SingletonLock') ||
        entry.name.includes('SingletonCookie') ||
        entry.name.includes('SingletonSocket')
      ) {
        try {
          fs.unlinkSync(fullPath);
          console.log(`🧹 Removed stale lock file: ${entry.name}`);
        } catch (e) {
          // ignore
        }
      }
    }
  } catch (err) {
    console.warn('Notice clearing lock files:', err.message);
  }
}

function initWhatsAppClient() {
  gatewayStatus = 'INITIALIZING';
  qrCodeDataUrl = null;
  connectedInfo = null;
  lastError = null;

  removeChromiumLocks(AUTH_DIR);

  const puppeteerArgs = [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--no-first-run',
    '--no-zygote',
    '--disable-gpu',
  ];

  let execPath = process.env.PUPPETEER_EXECUTABLE_PATH;
  if (!execPath) {
    try {
      execPath = puppeteer.executablePath();
    } catch (e) {
      console.warn('Could not resolve puppeteer executablePath:', e.message);
    }
  }

  const puppeteerConfig = {
    headless: true,
    args: puppeteerArgs,
  };

  if (execPath) {
    puppeteerConfig.executablePath = execPath;
  }

  client = new Client({
    authStrategy: new LocalAuth({ dataPath: AUTH_DIR }),
    puppeteer: puppeteerConfig,
  });

  client.on('qr', async (qr) => {
    gatewayStatus = 'QR_READY';
    lastError = null;
    console.log('\n================================================================');
    console.log('📱 SCAN THIS QR CODE WITH YOUR SENDER WHATSAPP PHONE TO LINK:');
    console.log('================================================================\n');
    qrcodeTerminal.generate(qr, { small: true });

    try {
      qrCodeDataUrl = await QRCode.toDataURL(qr, { margin: 2, scale: 8, color: { dark: '#000000', light: '#ffffff' } });
    } catch (err) {
      console.error('Error generating PNG QR Code:', err.message);
    }
  });

  client.on('ready', () => {
    gatewayStatus = 'CONNECTED';
    qrCodeDataUrl = null;
    lastError = null;
    const wid = client.info?.wid?.user || '';
    const name = client.info?.pushname || 'WhatsApp Admin';
    connectedInfo = { phone: wid ? `+${wid}` : '', name };
    console.log(`✅ WhatsApp Gateway is READY & Connected as ${name} (${wid})!`);
  });

  client.on('authenticated', () => {
    gatewayStatus = 'AUTHENTICATING';
    qrCodeDataUrl = null;
    lastError = null;
    console.log('🔒 WhatsApp Session Authenticated Successfully. Syncing account details...');
  });

  client.on('auth_failure', (msg) => {
    gatewayStatus = 'DISCONNECTED';
    qrCodeDataUrl = null;
    lastError = `Authentication Failure: ${msg}`;
    console.error('❌ WhatsApp Authentication Failed:', msg);
  });

  client.on('disconnected', (reason) => {
    gatewayStatus = 'DISCONNECTED';
    qrCodeDataUrl = null;
    connectedInfo = null;
    lastError = `Disconnected: ${reason}`;
    console.warn('⚠️ WhatsApp Disconnected. Reason:', reason);
  });

  client.initialize().catch((err) => {
    console.error('Failed to initialize client:', err.message);
    gatewayStatus = 'DISCONNECTED';
    lastError = err.message;
  });
}

// Start initial WhatsApp client
initWhatsAppClient();

// Get Gateway Status & QR Code Data URL
app.get('/api/status', (req, res) => {
  return res.json({
    success: true,
    status: gatewayStatus,
    qrCodeDataUrl,
    phone: connectedInfo?.phone || '',
    name: connectedInfo?.name || '',
    errorDetails: lastError,
  });
});

// Logout & Clear Session (triggers new QR code generation)
app.post('/api/logout', async (req, res) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader || authHeader !== `Bearer ${API_SECRET_KEY}`) {
      return res.status(401).json({ success: false, message: 'Unauthorized request' });
    }

    console.log('🚪 Disconnecting WhatsApp session & clearing saved auth credentials...');
    gatewayStatus = 'DISCONNECTED';
    qrCodeDataUrl = null;
    connectedInfo = null;

    if (client) {
      try {
        await client.logout();
      } catch (err) {
        console.warn('Logout notice:', err.message);
      }
      try {
        await client.destroy();
      } catch (err) {
        console.warn('Destroy notice:', err.message);
      }
    }

    // Remove saved session directory
    if (fs.existsSync(AUTH_DIR)) {
      fs.rmSync(AUTH_DIR, { recursive: true, force: true });
    }

    // Re-initialize client to generate a fresh QR code
    setTimeout(() => {
      initWhatsAppClient();
    }, 1000);

    return res.json({
      success: true,
      message: 'WhatsApp session logged out successfully. A new QR code is being generated.',
    });
  } catch (error) {
    console.error('❌ Error logging out WhatsApp session:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
});

// REST API Endpoint to Send WhatsApp OTP
app.post('/api/send-otp', async (req, res) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader || authHeader !== `Bearer ${API_SECRET_KEY}`) {
      return res.status(401).json({ success: false, message: 'Unauthorized request' });
    }

    const { phone, otp, appName = 'Suaaka Store' } = req.body;

    if (!phone || !otp) {
      return res.status(400).json({ success: false, message: 'Phone number and OTP are required' });
    }

    if (gatewayStatus !== 'CONNECTED') {
      return res.status(503).json({ success: false, message: 'WhatsApp Gateway is not connected yet' });
    }

    // Standardize phone number for WhatsApp ID (e.g. +919876543210 -> 919876543210@c.us)
    let cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length === 10) {
      cleanPhone = `91${cleanPhone}`; // Default country code if 10 digits
    }
    const chatId = `${cleanPhone}@c.us`;

    const message = `🔐 *${appName} Verification Code*\n\nYour login OTP is: *${otp}*\n\n⏱️ Valid for 5 minutes.\n⚠️ Do not share this code with anyone for security reasons.`;

    await client.sendMessage(chatId, message);

    console.log(`📩 WhatsApp OTP delivered successfully to +${cleanPhone}`);
    return res.json({ success: true, message: 'OTP delivered via WhatsApp successfully' });
  } catch (error) {
    console.error('❌ Error sending WhatsApp OTP:', error);
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ ready: gatewayStatus === 'CONNECTED', status: gatewayStatus });
});

app.listen(PORT, () => {
  console.log(`🚀 WhatsApp OTP Gateway running on http://localhost:${PORT}`);
});
