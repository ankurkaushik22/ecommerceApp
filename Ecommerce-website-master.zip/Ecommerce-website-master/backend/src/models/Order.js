import mongoose from 'mongoose';

const trackingUpdateSchema = new mongoose.Schema({
  status: { type: String, required: true },
  message: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  location: { type: String },
});

const orderItemSchema = new mongoose.Schema({
  product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  name: { type: String, required: true },
  image: { type: String },
  price: { type: Number, required: true },
  quantity: { type: Number, required: true },
  variantLabel: { type: String },
  variantIndex: { type: Number, default: -1 },
  vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
});

const shippingAddressSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  phone: { type: String, required: true },
  addressLine1: { type: String, required: true },
  addressLine2: { type: String },
  city: { type: String, required: true },
  state: { type: String, required: true },
  postalCode: { type: String, required: true },
  country: { type: String, required: true },
});

const deliveryOptionSubSchema = new mongoose.Schema({
  name: { type: String, default: 'Standard Delivery' },
  estimatedDays: { type: String, default: '3-5 Business Days' },
  price: { type: Number, default: 0 },
});

const taxDetailsSubSchema = new mongoose.Schema({
  rate: { type: Number, default: 18 },
  taxAmount: { type: Number, default: 0 },
  cgst: { type: Number, default: 0 },
  sgst: { type: Number, default: 0 },
  igst: { type: Number, default: 0 },
  hsnCode: { type: String, default: '9983' },
});

const orderSchema = new mongoose.Schema(
  {
    orderNumber: { type: String, unique: true },
    invoiceNumber: { type: String, unique: true, sparse: true },
    invoiceDate: { type: Date },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    deliveryAgent: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    deliveryBoy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }, // legacy alias
    deliveryOption: { type: deliveryOptionSubSchema, default: () => ({}) },
    taxDetails: { type: taxDetailsSubSchema, default: () => ({}) },
    items: [orderItemSchema],
    shippingAddress: { type: shippingAddressSchema, required: true },
    status: {
      type: String,
      enum: [
        'placed',
        'accepted',
        'processing',
        'ready_for_pickup',
        'picked_up',
        'out_for_delivery',
        'delivered',
        'completed',
        'cancelled',
        'refunded',
      ],
      default: 'placed',
    },
    paymentMethod: {
      type: String,
      enum: ['stripe', 'cod', 'upi', 'card', 'online', 'wallet', 'netbanking'],
      required: true,
      default: 'cod',
    },
    paymentStatus: {
      type: String,
      enum: ['pending', 'paid', 'failed', 'refunded'],
      default: 'pending',
    },
    paymentIntentId: { type: String },
    subtotal: { type: Number, required: true },
    discount: { type: Number, default: 0 },
    shippingCost: { type: Number, default: 0 },
    tax: { type: Number, default: 0 },
    total: { type: Number, required: true, default: 0 },
    couponCode: { type: String },
    vertical: {
      type: String,
      enum: ['shopping', 'food', 'grocery', 'services'],
      default: 'shopping',
      index: true,
    },
    deliverySlot: { type: String }, // For Grocery: e.g. Today: 3PM - 5PM, Tomorrow: 9AM - 11AM
    serviceDate: { type: Date }, // For Services: Appointment Date
    serviceTimeSlot: { type: String }, // For Services: e.g. 10:00 AM - 12:00 PM
    tableOrNotes: { type: String }, // For Food / Dining instructions
    estimatedDelivery: { type: Date },
    deliveredAt: { type: Date },
    cancelReason: { type: String },
    liveLocation: {
      latitude: { type: Number },
      longitude: { type: Number },
      heading: { type: Number, default: 0 },
      speed: { type: Number, default: 0 },
      updatedAt: { type: Date, default: Date.now },
    },
    destinationLocation: {
      latitude: { type: Number },
      longitude: { type: Number },
      address: { type: String },
    },
    deliveryLocationUpdates: [
      {
        latitude: { type: Number },
        longitude: { type: Number },
        heading: { type: Number },
        timestamp: { type: Date, default: Date.now },
        status: { type: String },
      },
    ],
    trackingUpdates: [trackingUpdateSchema],
    notes: { type: String },
    returnStatus: {
      type: String,
      enum: ['none', 'requested', 'approved', 'rejected', 'refunded'],
      default: 'none',
    },
    returnReason: { type: String },
    returnDate: { type: Date },
  },
  { timestamps: true }
);

// Pre-save: generate order and invoice number
orderSchema.pre('save', async function (next) {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const randomStr = Math.floor(100000 + Math.random() * 900000).toString();

  if (this.isNew && !this.orderNumber) {
    this.orderNumber = `ORD-${year}${month}${day}-${randomStr}`;
  }

  if (!this.invoiceNumber) {
    this.invoiceNumber = `INV-${year}${month}-${randomStr}`;
    this.invoiceDate = new Date();
  }

  if (!this.total || this.total <= 0) {
    const sub = Number(this.subtotal || 0);
    const disc = Number(this.discount || 0);
    const ship = Number(this.shippingCost || 0);
    const tax = Number(this.tax || 0);
    const calc = Math.max(0, sub - disc + ship + tax);
    if (calc > 0) {
      this.total = Math.round(calc * 100) / 100;
    }
  }

  next();
});

const Order = mongoose.models.Order || mongoose.model('Order', orderSchema);
export default Order;
