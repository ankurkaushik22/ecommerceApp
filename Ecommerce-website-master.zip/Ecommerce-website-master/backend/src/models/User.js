import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

const addressSchema = new mongoose.Schema({
  label: { type: String, default: 'Home' },
  fullName: { type: String, required: true },
  phone: { type: String, required: true },
  addressLine1: { type: String, required: true },
  addressLine2: { type: String },
  city: { type: String, required: true },
  state: { type: String, required: true },
  postalCode: { type: String, required: true },
  country: { type: String, required: true, default: 'IN' },
  isDefault: { type: Boolean, default: false },
});

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: {
      type: String,
      unique: true,
      sparse: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email'],
    },
    password: {
      type: String,
      minlength: 6,
      select: false,
    },
    role: {
      type: String,
      default: 'customer',
      trim: true,
      lowercase: true,
    },
    permissions: [{ type: String, trim: true }],
    avatar: {
      type: String,
      default: function () {
        return `https://ui-avatars.com/api/?name=${encodeURIComponent(this.name || 'User')}&background=6366f1&color=fff&size=200`;
      },
    },
    phone: { 
      type: String, 
      unique: true,
      sparse: true,
      trim: true 
    },
    addresses: [addressSchema],
    fcmToken: { type: String, select: false },
    isVerified: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    isOnline: { type: Boolean, default: false },
    currentLocation: {
      latitude: { type: Number },
      longitude: { type: Number },
      heading: { type: Number, default: 0 },
      updatedAt: { type: Date, default: Date.now },
    },
    googleId: { type: String },
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
    refreshToken: { type: String, select: false },
    passwordResetToken: { type: String, select: false },
    passwordResetExpires: { type: Date, select: false },
    passwordResetOTP: { type: String, select: false },
    loginOtp: { type: String, select: false },
    loginOtpExpires: { type: Date, select: false },
    termsAcceptedAt: { type: Date },
    privacyAcceptedAt: { type: Date },
    vendorCategory: { type: String, trim: true },
    vendorVertical: { type: String, trim: true },
    vendorVerticals: [{ type: String, trim: true }],
    commissionRate: { type: Number, default: 10 },
    bankDetails: {
      accountHolderName: { type: String, trim: true },
      accountNumber: { type: String, trim: true },
      bankName: { type: String, trim: true },
      ifscCode: { type: String, trim: true },
      upiId: { type: String, trim: true },
    },
  },
  { timestamps: true }
);

// Pre-save: hash password
userSchema.pre('save', async function (next) {
  if (!this.isModified('password') || !this.password) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Method: compare password
userSchema.methods.comparePassword = async function (candidatePassword) {
  if (!this.password) return false;
  return bcrypt.compare(candidatePassword, this.password);
};

// Method: generate access token
userSchema.methods.generateAuthToken = function () {
  return jwt.sign(
    { id: this._id, email: this.email, role: this.role, permissions: this.permissions || [] },
    process.env.JWT_SECRET
    // { expiresIn: process.env.JWT_EXPIRES_IN || '15m' } // Commented out session expire time as requested
  );
};

// Method: generate refresh token
userSchema.methods.generateRefreshToken = function () {
  return jwt.sign(
    { id: this._id },
    process.env.REFRESH_TOKEN_SECRET
    // { expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d' } // Commented out session expire time as requested
  );
};

// Method: create password reset token & OTP
userSchema.methods.createPasswordResetToken = function () {
  const resetToken = crypto.randomBytes(32).toString('hex');
  const otp = Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP

  this.passwordResetToken = crypto.createHash('sha256').update(resetToken).digest('hex');
  this.passwordResetOTP = otp;
  this.passwordResetExpires = Date.now() + 15 * 60 * 1000; // 15 minutes validity

  return { resetToken, otp };
};

// Virtual: avatar URL fallback
userSchema.virtual('avatarUrl').get(function () {
  return this.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(this.name)}&background=6366f1&color=fff&size=200`;
});

const User = mongoose.models.User || mongoose.model('User', userSchema);
export default User;
