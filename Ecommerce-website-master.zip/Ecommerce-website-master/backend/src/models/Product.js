import mongoose from 'mongoose';
import slugify from 'slugify';
import { v4 as uuidv4 } from 'uuid';

const specificationSchema = new mongoose.Schema({
  key: { type: String, required: true },
  value: { type: String, required: true },
});

const variantOptionSchema = new mongoose.Schema({
  label: { type: String, required: true },
  price: { type: Number, required: true },
  stock: { type: Number, required: true, default: 0 },
  sku: { type: String },
  thumbnail: { type: String },
  thumbnails: [{ type: String }],
});

const variantSchema = new mongoose.Schema({
  name: { type: String, required: true }, // e.g., "Color", "Size"
  options: [variantOptionSchema],
});

const productSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, unique: true },
    description: { type: String, required: true },
    shortDescription: { type: String },
    price: { type: Number, required: true, min: 0 },
    comparePrice: { type: Number, min: 0 }, // Original price before discount
    images: [{ type: String }],
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true,
    },
    subcategory: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      default: null,
    },
    vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    stock: { type: Number, required: true, default: 0, min: 0 },
    sku: { type: String, unique: true, sparse: true },
    weight: { type: Number }, // in grams
    dimensions: {
      length: { type: Number },
      width: { type: Number },
      height: { type: Number },
    },
    tags: [{ type: String, lowercase: true }],
    specifications: [specificationSchema],
    highlights: [{ type: String }],
    variants: [variantSchema],
    rating: {
      average: { type: Number, default: 0, min: 0, max: 5 },
      count: { type: Number, default: 0 },
    },
    isActive: { type: Boolean, default: true },
    approvalStatus: {
      type: String,
      enum: ['approved', 'pending', 'rejected'],
      default: 'approved',
      index: true,
    },
    commissionType: {
      type: String,
      enum: ['percentage', 'flat'],
      default: 'percentage',
    },
    commissionValue: { type: Number, default: 10, min: 0 },
    isFeatured: { type: Boolean, default: false },
    isDeals: { type: Boolean, default: false },
    freeShipping: { type: Boolean, default: false },
    shippingCost: { type: Number, default: 0 },
    salesCount: { type: Number, default: 0 },
    disableCOD: { type: Boolean, default: false },
    vertical: {
      type: String,
      enum: ['shopping', 'food', 'grocery', 'services'],
      default: 'shopping',
      index: true,
    },
    // Grocery specific
    unitMeasure: { type: String, default: '' }, // e.g. 500g, 1 lb bunch, 1kg (Approx 5 pcs)
    nutritionalHighlights: [{ type: String }], // e.g. Healthy Fats, High Fiber, Vitamin C
    // Food Delivery specific
    isVeg: { type: Boolean, default: true },
    cuisine: [{ type: String }], // e.g. North Indian, Italian, Biryani
    preparationTime: { type: Number, default: 25 }, // in minutes
    restaurantName: { type: String, trim: true },
    // Home Services specific
    serviceDuration: { type: String }, // e.g. 45 mins, 2 hours
    includedFeatures: [{ type: String }], // e.g. Deep clean, chemical wash, filter check
    warranty: { type: String }, // e.g. 30 Days Warranty
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// Index for full-text search
productSchema.index({ name: 'text', description: 'text', tags: 'text' });
productSchema.index({ category: 1, isActive: 1 });
productSchema.index({ price: 1 });
productSchema.index({ 'rating.average': -1 });
productSchema.index({ isFeatured: 1, isActive: 1 });
productSchema.index({ isDeals: 1, isActive: 1 });

// Virtual: discount percentage
productSchema.virtual('discount').get(function () {
  if (this.comparePrice && this.comparePrice > this.price) {
    return Math.round(((this.comparePrice - this.price) / this.comparePrice) * 100);
  }
  return 0;
});

// Virtual: reviews
productSchema.virtual('reviews', {
  ref: 'Review',
  localField: '_id',
  foreignField: 'product',
  justOne: false,
});

// Pre-save: auto sync vertical from category if not explicitly set and generate slug
productSchema.pre('save', async function (next) {
  try {
    if (this.isModified('name') || this.isNew) {
      const baseSlug = slugify(this.name, { lower: true, strict: true });
      const existingProduct = await mongoose.model('Product').findOne({
        slug: baseSlug,
        _id: { $ne: this._id },
      });
      if (existingProduct) {
        this.slug = `${baseSlug}-${uuidv4().slice(0, 8)}`;
      } else {
        this.slug = baseSlug;
      }
    }

    // If category is assigned, ensure product vertical aligns with category vertical
    if (this.category && (!this.vertical || this.vertical === 'shopping')) {
      const CategoryModel = mongoose.model('Category');
      const catDoc = await CategoryModel.findById(this.category);
      if (catDoc && catDoc.vertical) {
        this.vertical = catDoc.vertical;
      }
    }
  } catch (err) {
    // Continue on pre-save hook errors
  }
  next();
});

const Product = mongoose.model('Product', productSchema);
export default Product;
