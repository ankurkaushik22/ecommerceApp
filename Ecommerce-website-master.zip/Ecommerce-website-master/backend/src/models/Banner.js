import mongoose from 'mongoose';

const bannerSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  subtitle: {
    type: String,
  },
  tag: {
    type: String,
  },
  image: {
    type: String,
    required: true,
  },
  link: {
    type: String,
  },
  discount: {
    type: String,
  },
  platform: {
    type: String,
    enum: ['website', 'mobile', 'both'],
    default: 'both',
  },
  bgGradient: {
    type: String,
  },
  bgHex: {
    type: String,
  },
  buttonColor: {
    type: String,
  },
  accentColor: {
    type: String,
  },
  vertical: {
    type: String,
    enum: ['all', 'shopping', 'food', 'grocery', 'services'],
    default: 'all',
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  order: {
    type: Number,
    default: 0,
  }
}, {
  timestamps: true
});

const Banner = mongoose.model('Banner', bannerSchema);

export default Banner;
