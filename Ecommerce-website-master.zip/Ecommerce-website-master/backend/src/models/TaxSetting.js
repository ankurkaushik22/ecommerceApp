import mongoose from 'mongoose';

const taxSettingSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true }, // e.g. 'Standard GST (18%)'
    rate: { type: Number, required: true, default: 18 }, // total tax %
    cgst: { type: Number, default: 9 }, // Central GST %
    sgst: { type: Number, default: 9 }, // State GST %
    igst: { type: Number, default: 18 }, // Integrated GST %
    hsnCode: { type: String, default: '9983' },
    isDefault: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    description: { type: String },
  },
  { timestamps: true }
);

// Ensure only one default tax setting exists
taxSettingSchema.pre('save', async function (next) {
  if (this.isDefault) {
    await this.constructor.updateMany({ _id: { $ne: this._id } }, { isDefault: false });
  }
  next();
});

const TaxSetting = mongoose.models.TaxSetting || mongoose.model('TaxSetting', taxSettingSchema);
export default TaxSetting;
