import mongoose from 'mongoose';

const storeSettingSchema = new mongoose.Schema(
  {
    storeName: {
      type: String,
    },
    logoUrl: {
      type: String,
    },
    faviconUrl: {
      type: String,
    },
    appIconUrl: {
      type: String,
    },
    disabledVerticals: [
      {
        type: String,
      },
    ],
    serviceBookingMode: {
      type: String,
      enum: ['call_now', 'book_now'],
      default: 'call_now',
    },
    serviceContactPhone: {
      type: String,
      default: '+91 98765 43210',
    },
  },
  {
    timestamps: true,
  }
);

export const StoreSetting = mongoose.model('StoreSetting', storeSettingSchema);
