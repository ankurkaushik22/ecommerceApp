import mongoose from 'mongoose';

const rolePermissionSchema = new mongoose.Schema(
  {
    roleName: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    }, // 'admin', 'vendor', 'delivery', 'manager', 'support', etc.
    displayName: { type: String, required: true },
    description: { type: String },
    modules: [{ type: String, trim: true }],
    isSystem: { type: Boolean, default: false }, // System roles cannot be deleted
  },
  { timestamps: true }
);

const RolePermission = mongoose.models.RolePermission || mongoose.model('RolePermission', rolePermissionSchema);
export default RolePermission;
