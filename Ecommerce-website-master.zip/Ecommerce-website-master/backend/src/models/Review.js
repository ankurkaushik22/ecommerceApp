import mongoose from 'mongoose';

const reviewReplySchema = new mongoose.Schema({
  comment: { type: String, required: true, trim: true },
  repliedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  repliedAt: { type: Date, default: Date.now },
});

const reviewSchema = new mongoose.Schema(
  {
    targetType: {
      type: String,
      enum: ['product', 'seller', 'delivery'],
      default: 'product',
    },
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: function () {
        return this.targetType === 'product';
      },
    },
    vendor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: function () {
        return this.targetType === 'seller';
      },
    },
    deliveryAgent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: function () {
        return this.targetType === 'delivery';
      },
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Order',
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rating: { type: Number, required: true, min: 1, max: 5 },
    title: { type: String, trim: true },
    comment: { type: String, required: true, trim: true },
    images: [{ type: String }],
    helpful: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    verified: { type: Boolean, default: false }, // verified purchase
    reply: reviewReplySchema,
  },
  { timestamps: true }
);

// Indexes
reviewSchema.index({ product: 1, user: 1, targetType: 1 });
reviewSchema.index({ vendor: 1, user: 1, targetType: 1 });
reviewSchema.index({ deliveryAgent: 1, user: 1, targetType: 1 });

// Static method: update product rating after review save/delete
reviewSchema.statics.updateProductRating = async function (productId) {
  if (!productId) return;
  const stats = await this.aggregate([
    { $match: { product: new mongoose.Types.ObjectId(productId), targetType: 'product' } },
    {
      $group: {
        _id: '$product',
        avgRating: { $avg: '$rating' },
        count: { $sum: 1 },
      },
    },
  ]);

  if (stats.length > 0) {
    await mongoose.model('Product').findByIdAndUpdate(productId, {
      'rating.average': Math.round(stats[0].avgRating * 10) / 10,
      'rating.count': stats[0].count,
    });
  } else {
    await mongoose.model('Product').findByIdAndUpdate(productId, {
      'rating.average': 0,
      'rating.count': 0,
    });
  }
};

reviewSchema.post('save', function () {
  if (this.targetType === 'product' && this.product) {
    this.constructor.updateProductRating(this.product);
  }
});

reviewSchema.post('deleteOne', { document: true, query: false }, function () {
  if (this.targetType === 'product' && this.product) {
    this.constructor.updateProductRating(this.product);
  }
});

const Review = mongoose.models.Review || mongoose.model('Review', reviewSchema);
export default Review;
