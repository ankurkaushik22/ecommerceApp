import mongoose from 'mongoose';

const couponSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true,
    },
    type: {
      type: String,
      enum: ['percentage', 'fixed'],
      required: true,
    },
    value: { type: Number, required: true, min: 0 },
    description: { type: String },
    minOrderAmount: { type: Number, default: 0 },
    maxDiscountAmount: { type: Number }, // for percentage coupons
    usageLimit: { type: Number },
    usedCount: { type: Number, default: 0 },
    usedBy: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order' },
        usedAt: { type: Date, default: Date.now },
      },
    ],
    isActive: { type: Boolean, default: true },
    startsAt: { type: Date },
    expiresAt: { type: Date },
    applicableCategories: [
      { type: mongoose.Schema.Types.ObjectId, ref: 'Category' },
    ],
  },
  { timestamps: true }
);

// Method: calculate discount amount
couponSchema.methods.calculateDiscount = function (orderAmount) {
  if (this.type === 'percentage') {
    const discount = (orderAmount * this.value) / 100;
    if (this.maxDiscountAmount) {
      return Math.min(discount, this.maxDiscountAmount);
    }
    return discount;
  } else {
    return Math.min(this.value, orderAmount);
  }
};

// Method: validate coupon
couponSchema.methods.isValid = function (orderAmount) {
  const now = new Date();

  if (!this.isActive) return { valid: false, message: 'This coupon is not active' };
  if (this.startsAt && now < this.startsAt) return { valid: false, message: 'This coupon is not yet valid' };
  if (this.expiresAt && now > this.expiresAt) return { valid: false, message: 'This coupon has expired' };
  if (this.usageLimit && this.usedCount >= this.usageLimit) return { valid: false, message: 'This coupon has reached its usage limit' };
  if (orderAmount < this.minOrderAmount) {
    return {
      valid: false,
      message: `Minimum order amount is $${this.minOrderAmount}`,
    };
  }

  return { valid: true };
};

const Coupon = mongoose.model('Coupon', couponSchema);
export default Coupon;
