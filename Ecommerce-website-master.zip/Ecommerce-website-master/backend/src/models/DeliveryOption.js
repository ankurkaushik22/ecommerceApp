import mongoose from 'mongoose';

const deliveryOptionSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true }, // e.g., 'Standard Delivery', 'Express 24H', 'Same Day Delivery'
    description: { type: String, trim: true },
    estimatedDays: { type: String, required: true, default: '3-5 Business Days' },
    price: { type: Number, required: true, default: 49 }, // in ₹ INR
    minOrderForFree: { type: Number, default: 499 }, // Free delivery if order total >= minOrderForFree
    isDefault: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);

deliveryOptionSchema.pre('save', async function (next) {
  if (this.isDefault) {
    await this.constructor.updateMany({ _id: { $ne: this._id } }, { isDefault: false });
  }
  next();
});

const DeliveryOption = mongoose.models.DeliveryOption || mongoose.model('DeliveryOption', deliveryOptionSchema);
export default DeliveryOption;
