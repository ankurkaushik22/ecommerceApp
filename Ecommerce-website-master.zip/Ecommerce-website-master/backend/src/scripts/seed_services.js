import 'dotenv/config';
import connectDB from '../config/database.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';

async function seed() {
  await connectDB();

  let servCat = await Category.findOne({ $or: [{ slug: 'services' }, { slug: 'home-services' }] });
  if (servCat) {
    servCat.slug = 'services';
    servCat.name = 'Home Services';
    servCat.icon = '??';
    servCat.image = 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=500';
    await servCat.save();
  } else {
    servCat = await Category.create({
      name: 'Home Services',
      slug: 'services',
      description: 'Trusted doorstep home maintenance, cleaning, electrical, and appliance services',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=500',
      icon: '??',
      isActive: true,
    });
  }

  // Also create home-services alias category
  let homeServCat = await Category.findOne({ slug: 'home-services' });
  if (!homeServCat) {
    homeServCat = await Category.create({
      name: 'Home Services',
      slug: 'home-services',
      description: 'Trusted doorstep home maintenance, cleaning, electrical, and appliance services',
      image: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=500',
      icon: '??',
      isActive: true,
    });
  }

  const serviceItems = [
    {
      name: 'Complete Home Deep Cleaning & Sanitization Service',
      slug: 'complete-home-deep-cleaning-service',
      description: 'Professional 4-hour full home deep cleaning including kitchen degreasing, bathroom scrubbing, floor polishing, and sofa vacuuming with eco-friendly solutions.',
      price: 1499,
      comparePrice: 1999,
      discount: 25,
      stock: 40,
      category: servCat._id,
      images: [
        'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600',
        'https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=600',
      ],
      rating: { average: 4.9, count: 58 },
      numReviews: 58,
      isFeatured: true,
      isActive: true,
    },
    {
      name: 'AC Master Jet Servicing & Cooling Tune-Up',
      slug: 'ac-master-jet-servicing-and-tuneup',
      description: 'High-pressure power jet cleaning of AC indoor & outdoor units, cooling coil wash, filter cleanup, gas pressure check, and performance report.',
      price: 499,
      comparePrice: 799,
      discount: 37,
      stock: 50,
      category: servCat._id,
      images: [
        'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600',
        'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600',
      ],
      rating: { average: 4.8, count: 76 },
      numReviews: 76,
      isDeals: true,
      isActive: true,
    },
    {
      name: 'Expert Electrician Home Visit & Inspection (1 Hour)',
      slug: 'expert-electrician-home-visit',
      description: 'Certified background-verified electrician for wiring repair, switchboard installation, ceiling fan fitting, MCB diagnostics, and lighting fixes.',
      price: 199,
      comparePrice: 299,
      discount: 33,
      stock: 35,
      category: servCat._id,
      images: [
        'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600',
      ],
      rating: { average: 4.7, count: 32 },
      numReviews: 32,
      isActive: true,
    },
    {
      name: 'Plumbing Repair & Pipe Leakage Fix Service',
      slug: 'plumbing-repair-and-leakage-fix',
      description: 'Fast doorstep plumbing service for tap repairs, pipe blockages, drain cleaning, water heater installation, and bathroom fittings.',
      price: 249,
      comparePrice: 349,
      discount: 28,
      stock: 30,
      category: servCat._id,
      images: [
        'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=600',
      ],
      rating: { average: 4.8, count: 41 },
      numReviews: 41,
      isActive: true,
    }
  ];

  await Product.deleteMany({ category: { $in: [servCat._id, homeServCat._id] } });
  for (const item of serviceItems) {
    await Product.create(item);
  }

  console.log('Fixed services categories and seeded 4 services cleanly!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed error:', err);
  process.exit(1);
});
