import 'dotenv/config';
import connectDB from '../config/database.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';

async function seed() {
  await connectDB();

  let foodCat = await Category.findOne({ $or: [{ slug: 'food-and-dining' }, { slug: 'food-delivery' }] });
  if (!foodCat) {
    foodCat = await Category.create({
      name: 'Food & Dining',
      slug: 'food-and-dining',
      description: 'Order from top restaurants, fast food, and gourmet meals',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500',
      icon: '??',
      isActive: true,
    });
  } else {
    foodCat.name = 'Food & Dining';
    foodCat.slug = 'food-and-dining';
    foodCat.icon = '??';
    foodCat.image = 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500';
    await foodCat.save();
  }

  // Also update/create food-delivery alias category if queried
  let foodDeliveryCat = await Category.findOne({ slug: 'food-delivery' });
  if (!foodDeliveryCat) {
    foodDeliveryCat = await Category.create({
      name: 'Food Delivery',
      slug: 'food-delivery',
      description: 'Order from your favourite restaurants & cafes',
      image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500',
      icon: '??',
      isActive: true,
    });
  }

  const foodItems = [
    {
      name: 'Gourmet Double Cheese Burger Deluxe',
      slug: 'gourmet-double-cheese-burger-deluxe',
      description: 'Juicy flame-grilled patty loaded with aged cheddar cheese, caramelized onions, fresh lettuce, tomato, and crispy golden fries on the side.',
      price: 249,
      comparePrice: 349,
      discount: 28,
      stock: 50,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600',
        'https://images.unsplash.com/photo-1550547660-d9450f859349?w=600',
      ],
      rating: { average: 4.8, count: 42 },
      numReviews: 42,
      isFeatured: true,
      isDeals: true,
      isActive: true,
      variants: [
        {
          name: 'Portion Size',
          options: [
            { label: 'Single Patty', price: 249, stock: 30, sku: 'BRG-SGL' },
            { label: 'Double Patty (+Fries)', price: 349, stock: 20, sku: 'BRG-DBL' },
          ]
        }
      ]
    },
    {
      name: 'Artisan Wood-Fired Margherita Pizza (12-inch)',
      slug: 'artisan-wood-fired-margherita-pizza',
      description: 'Authentic hand-tossed Neapolitan crust with San Marzano tomato sauce, fresh buffalo mozzarella, virgin olive oil, and organic basil.',
      price: 399,
      comparePrice: 499,
      discount: 20,
      stock: 40,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?w=600',
        'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600',
      ],
      rating: { average: 4.9, count: 68 },
      numReviews: 68,
      isFeatured: true,
      isActive: true,
      variants: [
        {
          name: 'Crust Type',
          options: [
            { label: 'Classic Thin Crust', price: 399, stock: 25, sku: 'PIZ-THN' },
            { label: 'Cheese Burst Crust', price: 479, stock: 15, sku: 'PIZ-CHS' },
          ]
        }
      ]
    },
    {
      name: 'Royal Hyderabadi Chicken Dum Biryani Handi',
      slug: 'royal-hyderabadi-chicken-dum-biryani',
      description: 'Slow-cooked aromatic basmati rice layered with succulent marinated chicken, saffron, ghee, and secret Mughlai spices. Served with raita and mirchi ka salan.',
      price: 349,
      comparePrice: 449,
      discount: 22,
      stock: 60,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=600',
        'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=600',
      ],
      rating: { average: 4.9, count: 120 },
      numReviews: 120,
      isFeatured: true,
      isActive: true,
    },
    {
      name: 'Signature Paneer Tikka Butter Masala Combo',
      slug: 'signature-paneer-tikka-butter-masala',
      description: 'Char-grilled cottage cheese cubes simmered in a rich, buttery tomato cashew gravy. Served with 2 butter garlic naans and salad.',
      price: 299,
      comparePrice: 380,
      discount: 21,
      stock: 35,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600',
        'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=600',
      ],
      rating: { average: 4.7, count: 35 },
      numReviews: 35,
      isActive: true,
    },
    {
      name: 'Crispy Korean Fried Chicken Wings Bucket (8 pcs)',
      slug: 'crispy-korean-fried-chicken-wings',
      description: 'Extra crispy double-fried chicken wings glazed with sweet & spicy Gochujang chili sauce and toasted sesame seeds.',
      price: 279,
      comparePrice: 349,
      discount: 20,
      stock: 45,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1527477321005-4d45d304bc33?w=600',
        'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=600',
      ],
      rating: { average: 4.8, count: 54 },
      numReviews: 54,
      isDeals: true,
      isActive: true,
    },
    {
      name: 'Warm Belgian Chocolate Lava Cake with Vanilla Ice Cream',
      slug: 'warm-belgian-chocolate-lava-cake',
      description: 'Rich dark chocolate cake with a warm, gooey molten chocolate center, served with a scoop of premium Madagascan vanilla ice cream.',
      price: 189,
      comparePrice: 249,
      discount: 24,
      stock: 30,
      category: foodCat._id,
      images: [
        'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600',
        'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=600',
      ],
      rating: { average: 5.0, count: 29 },
      numReviews: 29,
      isActive: true,
    }
  ];

  await Product.deleteMany({ category: { $in: [foodCat._id, foodDeliveryCat._id] } });

  for (const item of foodItems) {
    await Product.create(item);
  }

  console.log('Successfully seeded 6 delicious demo food & dining products into MongoDB Atlas!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed error:', err);
  process.exit(1);
});
