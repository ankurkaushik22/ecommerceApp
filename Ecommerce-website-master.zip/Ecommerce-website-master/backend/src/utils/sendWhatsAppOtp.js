import fetch from 'node-fetch';

export const sendWhatsAppOTP = async (phone, otp, appName = 'Suaaka Store') => {
  try {
    if (!phone) {
      throw new Error('Phone number is required for WhatsApp OTP delivery');
    }

    let cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length === 10) {
      cleanPhone = `91${cleanPhone}`;
    }

    // Option 1: Meta Official WhatsApp Cloud API (100% Serverless & Vercel compatible)
    const cloudApiToken = process.env.WHATSAPP_CLOUD_API_TOKEN;
    const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;

    if (cloudApiToken && phoneNumberId) {
      const metaUrl = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;
      const response = await fetch(metaUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${cloudApiToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: cleanPhone,
          type: 'text',
          text: {
            body: `🔐 *${appName} Verification Code*\n\nYour login OTP is: *${otp}*\n\n⏱️ Valid for 5 minutes.\n⚠️ Do not share this code with anyone for security reasons.`,
          },
        }),
      });

      const result = await response.json();
      if (result.error) {
        console.warn(`⚠️ Meta WhatsApp Cloud API error: ${result.error.message}`);
        return { success: false, message: result.error.message };
      }
      console.log(`📩 WhatsApp OTP delivered via Meta Cloud API to +${cleanPhone}`);
      return { success: true, message: 'OTP delivered via Meta WhatsApp Cloud API' };
    }

    // Option 2: Self-hosted WhatsApp Web Gateway microservice
    let gatewayUrl = process.env.WHATSAPP_GATEWAY_URL || 'https://ecommerce-whatsappservice.onrender.com/api/send-otp';
    if (!gatewayUrl.endsWith('/api/send-otp')) {
      gatewayUrl = `${gatewayUrl.replace(/\/+$/, '')}/api/send-otp`;
    }
    const apiKey = process.env.WHATSAPP_API_KEY || 'suaaka_whatsapp_otp_secret_key_98765';

    const response = await fetch(gatewayUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        phone: cleanPhone,
        otp,
        appName,
      }),
    });

    const result = await response.json();
    if (!result.success) {
      console.warn(`⚠️ WhatsApp Gateway response: ${result.message}`);
    }

    return result;
  } catch (error) {
    console.error('❌ Failed to send WhatsApp OTP:', error.message);
    return { success: false, message: error.message };
  }
};
