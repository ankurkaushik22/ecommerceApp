import { z } from 'zod';
import { GraphQLError } from 'graphql';

// Common Base Schemas
export const objectIdSchema = z.string().trim().regex(/^[0-9a-fA-F]{24}$/, 'Invalid ID format (must be 24-character hex ObjectId)');
export const emailSchema = z.string().trim().email('Invalid email address format').max(254, 'Email too long');
export const phoneSchema = z.string().trim().regex(/^\+?[1-9]\d{6,14}$/, 'Invalid phone number format');
export const identifierSchema = z.string().trim().min(3, 'Identifier must be at least 3 characters').max(254, 'Identifier too long');

// Auth Schemas
export const registerInputSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(100, 'Name max 100 characters').optional(),
  email: z.string().trim().min(3).max(254),
  password: z.string().min(6, 'Password must be at least 6 characters').max(128, 'Password too long'),
  phone: z.string().trim().optional(),
  role: z.enum(['customer', 'vendor']).optional().default('customer'),
  vendorCategory: z.string().trim().optional(),
  vendorVertical: z.string().trim().optional(),
  acceptedTerms: z.boolean().optional(),
});

export const loginInputSchema = z.object({
  email: identifierSchema,
  password: z.string().min(1, 'Password is required').max(128),
});

export const sendOTPSchema = z.object({
  email: identifierSchema,
});

export const loginWithOTPSchema = z.object({
  email: identifierSchema,
  otp: z.string().trim().regex(/^\d{6}$/, 'OTP must be 6 digits'),
});

export const forgotPasswordSchema = z.object({
  email: identifierSchema,
});

export const verifyResetOTPSchema = z.object({
  email: identifierSchema,
  otp: z.string().trim().regex(/^\d{6}$/, 'OTP must be 6 digits'),
});

export const resetPasswordSchema = z.object({
  token: z.string().trim().min(10, 'Invalid token format'),
  newPassword: z.string().min(6, 'Password must be at least 6 characters').max(128),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string().min(6, 'Password must be at least 6 characters').max(128),
});

// Profile & Address Schemas
export const updateProfileSchema = z.object({
  name: z.string().trim().min(2).max(100).optional(),
  phone: z.string().trim().optional(),
  avatar: z.string().trim().url('Invalid avatar URL').optional().or(z.literal('')),
});

export const addressInputSchema = z.object({
  street: z.string().trim().min(3, 'Street address is required').max(200),
  city: z.string().trim().min(2, 'City is required').max(100),
  state: z.string().trim().min(2, 'State is required').max(100),
  zipCode: z.string().trim().min(3, 'Zip code is required').max(20),
  country: z.string().trim().min(2).max(100).optional().default('India'),
  isDefault: z.boolean().optional(),
});

// Order & Product Schemas
export const orderItemInputSchema = z.object({
  product: objectIdSchema,
  quantity: z.number().int().positive('Quantity must be at least 1').max(1000),
  price: z.number().nonnegative('Price cannot be negative'),
  selectedVariant: z.object({
    size: z.string().optional(),
    color: z.string().optional(),
  }).optional(),
});

export const createOrderInputSchema = z.object({
  items: z.array(orderItemInputSchema).min(1, 'Order must contain at least 1 item'),
  shippingAddress: addressInputSchema,
  paymentMethod: z.enum(['cod', 'stripe', 'razorpay', 'upi', 'card', 'wallet', 'netbanking']),
  couponCode: z.string().trim().max(50).optional(),
});

export const updateOrderStatusSchema = z.object({
  orderId: objectIdSchema,
  status: z.enum([
    'placed', 'accepted', 'processing', 'ready_for_pickup',
    'picked_up', 'out_for_delivery', 'delivered', 'completed', 'cancelled', 'refunded'
  ]),
});

export const requestReturnSchema = z.object({
  orderId: objectIdSchema,
  reason: z.string().trim().min(5, 'Reason must be at least 5 characters').max(500),
});

/**
 * Helper function to validate input data against a Zod schema.
 * Throws GraphQLError with BAD_USER_INPUT extension code on validation failure.
 */
export function validateData(schema, data) {
  const result = schema.safeParse(data);
  if (!result.success) {
    const issueMessages = result.error.issues
      .map((i) => {
        const fieldName = i.path.length > 0 ? i.path.join('.') : 'input';
        return `${fieldName}: ${i.message}`;
      })
      .join('\n');
    throw new GraphQLError(issueMessages, {
      extensions: {
        code: 'BAD_USER_INPUT',
        details: result.error.issues,
      },
    });
  }
  return result.data;
}
