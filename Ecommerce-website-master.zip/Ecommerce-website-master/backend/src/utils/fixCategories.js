import 'dotenv/config';
import connectDB from '../config/database.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';
import User from '../models/User.js';

async function fix() {
  await connectDB();
  
  let homeCat = await Category.findOne({ slug: 'home-and-kitchen' });
  if (!homeCat) {
    homeCat = await Category.create({
      name: 'Home & Kitchen',
      slug: 'home-and-kitchen',
      icon: '🏠',
      description: 'Home appliances and furniture',
      isActive: true,
    });
    console.log('Created Home & Kitchen category:', homeCat._id);
  }

  const allCats = await Category.find();
  const validCatIds = allCats.map((c) => c._id.toString());
  const defaultVendor = (await User.findOne({ role: 'vendor' })) || (await User.findOne({ role: 'admin' }));

  const products = await Product.find();
  let fixedCount = 0;

  for (const prod of products) {
    let modified = false;

    if (!prod.category || !validCatIds.includes(prod.category.toString())) {
      prod.category = homeCat._id;
      modified = true;
      console.log(`Assigned Home & Kitchen category to: ${prod.name}`);
    }

    if (!prod.vendor && defaultVendor) {
      prod.vendor = defaultVendor._id;
      modified = true;
      console.log(`Assigned default vendor to: ${prod.name}`);
    }

    if (modified) {
      await prod.save();
      fixedCount++;
    }
  }

  console.log(`✅ Successfully fixed ${fixedCount} products in Atlas database!`);
  process.exit(0);
}

fix().catch((err) => {
  console.error(err);
  process.exit(1);
});
