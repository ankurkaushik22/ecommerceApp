import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import connectDB from '../config/database.js';
import User from '../models/User.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';
import Coupon from '../models/Coupon.js';
import Order from '../models/Order.js';

const categories = [
  { name: 'Electronics', icon: '📱', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400', description: 'Latest gadgets and devices' },
  { name: 'Clothing', icon: '👕', image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400', description: 'Fashion for everyone' },
  { name: 'Home & Garden', icon: '🏠', image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=400', description: 'Everything for your home' },
  { name: 'Sports & Outdoors', icon: '⚽', image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400', description: 'Stay active and fit' },
  { name: 'Books', icon: '📚', image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400', description: 'Knowledge at your fingertips' },
  { name: 'Toys & Games', icon: '🎮', image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', description: 'Fun for all ages' },
  { name: 'Beauty & Health', icon: '💄', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400', description: 'Look and feel your best' },
  { name: 'Automotive', icon: '🚗', image: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=400', description: 'Parts and accessories' },
  { name: 'Grocery', icon: '🛒', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=400', description: 'Fresh everyday essentials' },
  { name: 'Jewelry', icon: '💎', image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400', description: 'Timeless pieces' },
];

const productImages = {
  Electronics: [
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=600',
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600',
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=600',
    'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=600',
    'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=600',
  ],
  Clothing: [
    'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?w=600',
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600',
    'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=600',
    'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=600',
    'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600',
  ],
  'Home & Garden': [
    'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600',
    'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600',
    'https://images.unsplash.com/photo-1538688525198-9b88f6f53126?w=600',
    'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600',
  ],
  'Sports & Outdoors': [
    'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600',
    'https://images.unsplash.com/photo-1546519638-68e109498ffc?w=600',
    'https://images.unsplash.com/photo-1544966503-7cc5ac882d5d?w=600',
  ],
};

const getImages = (catName) => {
  const imgs = productImages[catName] || productImages.Electronics;
  return imgs.slice(0, 3);
};

const seed = async () => {
  try {
    await connectDB();
    console.log('🌱 Starting database seeding...');

    // Clear existing data
    await Promise.all([
      User.deleteMany({}),
      Category.deleteMany({}),
      Product.deleteMany({}),
      Coupon.deleteMany({}),
      Order.deleteMany({}),
    ]);
    console.log('🗑️ Cleared existing data');

    // Create users
    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@shopzone.com',
      password: '123456',
      role: 'admin',
      isVerified: true,
      avatar: 'https://ui-avatars.com/api/?name=Admin+User&background=6366f1&color=fff&size=200',
    });

    const superAdminUser = await User.create({
      name: 'Super Admin',
      email: 'superadmin@shopzone.com',
      password: '123456',
      role: 'admin',
      isVerified: true,
      avatar: 'https://ui-avatars.com/api/?name=Super+Admin&background=ef4444&color=fff&size=200',
    });

    const vendorUser = await User.create({
      name: 'ShopZone Vendor',
      email: 'vendor@shopzone.com',
      password: 'Vendor@123',
      role: 'vendor',
      isVerified: true,
      avatar: 'https://ui-avatars.com/api/?name=ShopZone+Vendor&background=f59e0b&color=fff&size=200',
    });

    const deliveryUser = await User.create({
      name: 'Delivery Agent',
      email: 'delivery@shopzone.com',
      password: 'Delivery@123',
      role: 'delivery',
      isVerified: true,
    });

    const customer1 = await User.create({
      name: 'John Smith',
      email: 'john@example.com',
      password: 'John@123',
      role: 'customer',
      isVerified: true,
      phone: '+1-555-0101',
      addresses: [
        {
          label: 'Home',
          fullName: 'John Smith',
          phone: '+1-555-0101',
          addressLine1: '123 Main Street',
          city: 'New York',
          state: 'NY',
          postalCode: '10001',
          country: 'US',
          isDefault: true,
        },
      ],
    });

    const customer2 = await User.create({
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      password: 'Sarah@123',
      role: 'customer',
      isVerified: true,
    });

    console.log('✅ Users created');

    // Create categories
    const createdCategories = {};
    for (const cat of categories) {
      const category = await Category.create({
        name: cat.name,
        icon: cat.icon,
        image: cat.image,
        description: cat.description,
        isActive: true,
      });
      createdCategories[cat.name] = category;
    }
    console.log('✅ Categories created');

    // Create products
    const products = [
      // Electronics
      { name: 'iPhone 15 Pro Max 256GB', category: 'Electronics', price: 1199.99, comparePrice: 1399.99, stock: 45, isFeatured: true, isDeals: true, rating: { average: 4.8, count: 1250 }, shortDescription: 'The most advanced iPhone ever.', description: 'Experience the power of the A17 Pro chip with titanium design, 48MP camera system, and Action Button. Now with USB-C connectivity and up to 29 hours video playback.', tags: ['apple', 'smartphone', 'flagship'], specifications: [{ key: 'Display', value: '6.7" Super Retina XDR OLED' }, { key: 'Chip', value: 'A17 Pro' }, { key: 'Storage', value: '256GB' }, { key: 'Camera', value: '48MP + 12MP + 12MP Triple' }] },
      { name: 'Samsung 4K QLED Smart TV 55"', category: 'Electronics', price: 899.99, comparePrice: 1199.99, stock: 20, isFeatured: true, isDeals: true, rating: { average: 4.6, count: 890 }, shortDescription: 'Stunning 4K QLED display with smart features.', description: 'Experience true 4K HDR with Quantum Color technology. Features Smart TV powered by Tizen OS, built-in Alexa, and gaming-optimized features at 120Hz.', tags: ['samsung', 'tv', 'smart-tv', '4k'], specifications: [{ key: 'Screen Size', value: '55 Inches' }, { key: 'Resolution', value: '4K Ultra HD' }, { key: 'Display Technology', value: 'QLED' }, { key: 'Refresh Rate', value: '120Hz' }] },
      { name: 'Sony WH-1000XM5 Headphones', category: 'Electronics', price: 349.99, comparePrice: 449.99, stock: 78, isFeatured: true, rating: { average: 4.9, count: 2100 }, shortDescription: 'Industry-leading noise canceling headphones.', description: 'Best-in-class noise cancellation with the Integrated Processor V1. 30-hour battery life, multipoint connection, speak-to-chat technology.', tags: ['sony', 'headphones', 'wireless', 'noise-canceling'], specifications: [{ key: 'Battery Life', value: '30 hours' }, { key: 'Connectivity', value: 'Bluetooth 5.2' }, { key: 'Weight', value: '250g' }] },
      { name: 'MacBook Pro 14" M3 Pro', category: 'Electronics', price: 1999.99, comparePrice: 2199.99, stock: 25, isFeatured: true, freeShipping: true, rating: { average: 4.9, count: 567 }, shortDescription: 'Supercharged by M3 Pro chip.', description: 'The MacBook Pro laptop with M3 Pro chip is a portable powerhouse. Features Liquid Retina XDR display, up to 22 hours battery, 18GB unified memory.', tags: ['apple', 'laptop', 'macbook', 'm3'], specifications: [{ key: 'Chip', value: 'Apple M3 Pro' }, { key: 'Memory', value: '18GB Unified' }, { key: 'Storage', value: '512GB SSD' }, { key: 'Display', value: '14.2" Liquid Retina XDR' }] },
      { name: 'iPad Air 5th Gen Wi-Fi 64GB', category: 'Electronics', price: 599.99, comparePrice: 699.99, stock: 55, rating: { average: 4.7, count: 430 }, shortDescription: 'Powerful. Colorful. Wonderful.', description: 'Supercharged by the M1 chip, iPad Air features a brilliant 10.9-inch Liquid Retina display, Touch ID fingerprint sensor, USB-C, and all-day battery life.', tags: ['apple', 'ipad', 'tablet'], specifications: [{ key: 'Chip', value: 'Apple M1' }, { key: 'Display', value: '10.9" Liquid Retina' }, { key: 'Storage', value: '64GB' }] },

      // Clothing
      { name: "Men's Premium Slim Fit Suit", category: 'Clothing', price: 249.99, comparePrice: 399.99, stock: 30, isFeatured: true, rating: { average: 4.5, count: 320 }, shortDescription: 'Tailored slim fit for modern professionals.', description: 'Premium wool-blend slim fit suit for the modern professional. Features notch lapels, single-breasted two-button closure, and flat-front trousers. Available in charcoal, navy, and black.', tags: ['suit', 'mens', 'formal', 'slim-fit'], specifications: [{ key: 'Material', value: '70% Wool, 30% Polyester' }, { key: 'Fit', value: 'Slim Fit' }, { key: 'Care', value: 'Dry Clean Only' }] },
      { name: "Women's Floral Maxi Dress", category: 'Clothing', price: 79.99, comparePrice: 120.00, stock: 65, isFeatured: true, isDeals: true, freeShipping: true, rating: { average: 4.4, count: 789 }, shortDescription: 'Elegant floral print for every occasion.', description: 'Beautiful floral maxi dress perfect for summer events, garden parties, and beach getaways. Features V-neck, adjustable spaghetti straps, and flowy silhouette.', tags: ['dress', 'womens', 'floral', 'summer'], specifications: [{ key: 'Material', value: '100% Polyester Chiffon' }, { key: 'Length', value: 'Maxi (Floor Length)' }, { key: 'Care', value: 'Machine Wash Cold' }] },
      { name: 'Classic White Sneakers Unisex', category: 'Clothing', price: 89.99, comparePrice: 130.00, stock: 120, rating: { average: 4.6, count: 1540 }, shortDescription: 'Timeless white leather sneakers.', description: 'Classic minimalist white leather sneakers that go with everything. Premium Italian leather upper, cushioned insole, and durable rubber outsole. A wardrobe staple.', tags: ['sneakers', 'shoes', 'unisex', 'white'], specifications: [{ key: 'Upper', value: 'Genuine Leather' }, { key: 'Sole', value: 'Rubber' }, { key: 'Closure', value: 'Lace-up' }] },

      // Home & Garden
      { name: 'Nespresso Vertuo Next Coffee Machine', category: 'Home & Garden', price: 179.99, comparePrice: 229.99, stock: 40, isFeatured: true, isDeals: true, rating: { average: 4.7, count: 2890 }, shortDescription: 'One-touch coffee perfection.', description: 'Make barista-style coffee at home with Nespresso Vertuo Next. Centrifusion technology spins capsule up to 7000 rpm for perfect espresso, double espresso, gran lungo, mug, and alto coffees.', tags: ['coffee', 'nespresso', 'kitchen', 'appliance'], specifications: [{ key: 'Capacity', value: '37oz Water Tank' }, { key: 'Pressure', value: '19 Bar' }, { key: 'Warm-up Time', value: '30 seconds' }] },
      { name: 'Ergonomic Office Chair with Lumbar Support', category: 'Home & Garden', price: 399.99, comparePrice: 549.99, stock: 18, isFeatured: true, freeShipping: true, rating: { average: 4.5, count: 456 }, shortDescription: 'All-day comfort for your home office.', description: 'Premium ergonomic office chair with adjustable lumbar support, 4D armrests, breathable mesh back, and seat depth adjustment. Supports up to 300 lbs. Perfect for long work sessions.', tags: ['chair', 'office', 'ergonomic', 'home'], specifications: [{ key: 'Material', value: 'Mesh & Foam' }, { key: 'Max Weight', value: '300 lbs' }, { key: 'Height Adjustment', value: '17"-21"' }] },

      // Sports & Outdoors
      { name: 'Yoga Mat Premium Non-Slip 6mm', category: 'Sports & Outdoors', price: 59.99, comparePrice: 89.99, stock: 200, isFeatured: true, isDeals: true, freeShipping: true, rating: { average: 4.7, count: 3200 }, shortDescription: 'Eco-friendly mat for all yoga styles.', description: 'Premium eco-friendly TPE yoga mat with dual-color reversible design. Extra-thick 6mm cushioning for joint protection. Non-slip texture on both sides. Includes carrying strap.', tags: ['yoga', 'fitness', 'mat', 'exercise'], specifications: [{ key: 'Material', value: 'TPE (Eco-friendly)' }, { key: 'Thickness', value: '6mm' }, { key: 'Size', value: '72" x 24"' }, { key: 'Weight', value: '2.2 lbs' }] },
      { name: 'Running Shoes Ultra Boost', category: 'Sports & Outdoors', price: 149.99, comparePrice: 200.00, stock: 85, isFeatured: true, rating: { average: 4.8, count: 1870 }, shortDescription: 'Energy-returning performance running shoes.', description: 'Experience unmatched energy return with Boost midsole technology. Primeknit+ upper provides a perfectly fitting second-skin feel. Continental Rubber outsole for superior traction in wet conditions.', tags: ['running', 'shoes', 'sports', 'boost'], specifications: [{ key: 'Upper', value: 'Primeknit+ / Textile' }, { key: 'Midsole', value: 'Boost Foam' }, { key: 'Outsole', value: 'Continental Rubber' }] },

      // Beauty & Health
      { name: 'Dyson Supersonic Hair Dryer', category: 'Beauty & Health', price: 429.99, comparePrice: 499.99, stock: 32, isFeatured: true, isDeals: true, rating: { average: 4.8, count: 4500 }, shortDescription: 'Fast drying. Intelligent heat control.', description: 'The Dyson Supersonic hair dryer is engineered to protect hair from extreme heat damage, with fast drying and controlled styling. 5 precise speed settings and 3 heat settings.', tags: ['dyson', 'hair-dryer', 'beauty', 'hair'], specifications: [{ key: 'Motor', value: 'Dyson V9 Digital Motor' }, { key: 'Wattage', value: '1600W' }, { key: 'Attachments', value: '5 Included' }] },

      // Books
      { name: 'Atomic Habits by James Clear', category: 'Books', price: 18.99, comparePrice: 27.99, stock: 500, isFeatured: true, freeShipping: true, rating: { average: 4.9, count: 12000 }, shortDescription: 'Tiny Changes, Remarkable Results.', description: 'No matter your goals, Atomic Habits offers a proven framework for improving every day. James Clear reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.', tags: ['self-help', 'habits', 'productivity', 'non-fiction'], specifications: [{ key: 'Author', value: 'James Clear' }, { key: 'Pages', value: '320' }, { key: 'Publisher', value: 'Avery' }, { key: 'Language', value: 'English' }] },

      // Jewelry
      { name: 'Diamond Solitaire Engagement Ring 14K Gold', category: 'Jewelry', price: 1299.99, comparePrice: 1799.99, stock: 10, isFeatured: true, isDeals: true, freeShipping: true, rating: { average: 4.9, count: 234 }, shortDescription: 'Timeless solitaire diamond ring.', description: 'Classic solitaire ring featuring a 1.0 carat round brilliant cut diamond set in 14K white gold. VS1 clarity, G-H color. Comes in a premium gift box with certificate of authenticity.', tags: ['diamond', 'ring', 'engagement', 'gold', 'jewelry'], specifications: [{ key: 'Metal', value: '14K White Gold' }, { key: 'Diamond', value: '1.0 Carat' }, { key: 'Clarity', value: 'VS1' }, { key: 'Color', value: 'G-H' }] },
    ];

    for (const prod of products) {
      const category = createdCategories[prod.category];
      if (!category) continue;

      const imgs = getImages(prod.category);
      await Product.create({
        name: prod.name,
        description: prod.description || prod.shortDescription,
        shortDescription: prod.shortDescription,
        price: prod.price,
        comparePrice: prod.comparePrice,
        images: imgs,
        category: category._id,
        vendor: vendorUser._id,
        stock: prod.stock,
        isFeatured: prod.isFeatured || false,
        isDeals: prod.isDeals || false,
        freeShipping: prod.freeShipping || false,
        rating: prod.rating || { average: 0, count: 0 },
        tags: prod.tags || [],
        specifications: prod.specifications || [],
        isActive: true,
      });
    }
    console.log('✅ Products created');

    // Create coupons
    const coupons = [
      { code: 'SAVE10', type: 'percentage', value: 10, description: '10% off your order', minOrderAmount: 50, maxDiscountAmount: 100, usageLimit: 1000, isActive: true, expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) },
      { code: 'SAVE20', type: 'percentage', value: 20, description: '20% off orders over $100', minOrderAmount: 100, maxDiscountAmount: 200, usageLimit: 500, isActive: true, expiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000) },
      { code: 'FREESHIP', type: 'fixed', value: 9.99, description: 'Free shipping on any order', minOrderAmount: 0, usageLimit: 2000, isActive: true, expiresAt: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000) },
      { code: 'NEWUSER', type: 'percentage', value: 15, description: 'Welcome discount for new users', minOrderAmount: 30, maxDiscountAmount: 50, usageLimit: 100, isActive: true, expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) },
      { code: 'FLASH50', type: 'percentage', value: 50, description: 'Flash sale - 50% off (limited time)', minOrderAmount: 200, maxDiscountAmount: 500, usageLimit: 50, isActive: true, expiresAt: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000) },
    ];

    await Coupon.insertMany(coupons);
    console.log('✅ Coupons created');

    console.log('\n🎉 Database seeded successfully!\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📋 TEST ACCOUNTS:');
    console.log('  Admin:    admin@shopzone.com    / Admin@123');
    console.log('  Vendor:   vendor@shopzone.com   / Vendor@123');
    console.log('  Delivery: delivery@shopzone.com / Delivery@123');
    console.log('  Customer: john@example.com      / John@123');
    console.log('  Customer: sarah@example.com     / Sarah@123');
    console.log('\n🎫 COUPON CODES:');
    console.log('  SAVE10, SAVE20, FREESHIP, NEWUSER, FLASH50');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    process.exit(1);
  }
};

seed();
