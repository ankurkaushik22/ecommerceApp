import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Category from '../models/Category.js';
import Product from '../models/Product.js';
import Coupon from '../models/Coupon.js';
import Order from '../models/Order.js';

const categories = [
  { name: 'Electronics', icon: '📱', image: 'https://images.unsplash.com/photo-1498049794561-7780e7231661?w=400', description: 'Latest gadgets and devices' },
  { name: 'Clothing', icon: '👕', image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=400', description: 'Fashion for everyone' },
  { name: 'Home & Garden', icon: '🏠', image: 'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=400', description: 'Everything for your home' },
  { name: 'Sports & Outdoors', icon: '⚽', image: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400', description: 'Stay active and fit' },
  { name: 'Books', icon: '📚', image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=400', description: 'Knowledge at your fingertips' },
  { name: 'Toys & Games', icon: '🎮', image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', description: 'Fun for all ages' },
  { name: 'Beauty & Health', icon: '💄', image: 'https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=400', description: 'Look and feel your best' },
];

export const autoSeed = async () => {
  const userCount = await User.countDocuments();
  if (userCount > 0) return; // already seeded

  console.log('🌱 Auto-seeding initial database data...');

  const passwordHash = await bcrypt.hash('Admin@123', 10);
  const vendorHash = await bcrypt.hash('Vendor@123', 10);
  const deliveryHash = await bcrypt.hash('Delivery@123', 10);
  const customerHash = await bcrypt.hash('John@123', 10);

  const [admin, vendor, delivery, customer] = await User.create([
    {
      name: 'Admin User',
      email: 'admin@shopzone.com',
      password: passwordHash,
      role: 'admin',
      isVerified: true,
      phone: '+1-555-0100',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150',
    },
    {
      name: 'Tech Haven Vendor',
      email: 'vendor@shopzone.com',
      password: vendorHash,
      role: 'vendor',
      isVerified: true,
      phone: '+1-555-0101',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    },
    {
      name: 'Alex Delivery',
      email: 'delivery@shopzone.com',
      password: deliveryHash,
      role: 'delivery',
      isVerified: true,
      phone: '+1-555-0102',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150',
    },
    {
      name: 'John Customer',
      email: 'john@example.com',
      password: customerHash,
      role: 'customer',
      isVerified: true,
      phone: '+1-555-0103',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      addresses: [
        {
          label: 'Home',
          fullName: 'John Customer',
          phone: '+1-555-0103',
          addressLine1: '742 Evergreen Terrace',
          city: 'Springfield',
          state: 'OR',
          postalCode: '97477',
          country: 'United States',
          isDefault: true,
        },
      ],
    },
  ]);

  const createdCategories = await Category.create(categories);
  const catMap = {};
  createdCategories.forEach((c) => { catMap[c.name] = c._id; });

  const products = [
    {
      name: 'Sony WH-1000XM5 Wireless Noise Cancelling Headphones',
      slug: 'sony-wh-1000xm5-wireless-headphones',
      description: 'Industry-leading noise canceling with two processors and 8 microphones. Magnificent Sound, engineered to perfection with the new Integrated Processor V1. Crystal clear hands-free calling with 4 beamforming microphones.',
      shortDescription: 'Industry-leading noise canceling with two processors and 8 microphones.',
      price: 348.00,
      comparePrice: 399.99,
      category: catMap['Electronics'],
      vendor: vendor._id,
      images: [
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800',
        'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800',
      ],
      stock: 45,
      sku: 'SONY-WHXM5-BLK',
      tags: ['audio', 'headphones', 'wireless', 'sony', 'noise-cancelling'],
      specifications: [
        { key: 'Brand', value: 'Sony' },
        { key: 'Battery Life', value: '30 Hours' },
        { key: 'Connectivity', value: 'Bluetooth 5.2' },
        { key: 'Noise Cancellation', value: 'Active (Dual Processor)' },
      ],
      isFeatured: true,
      isDeals: true,
      freeShipping: true,
      rating: { average: 4.8, count: 128 },
      reviewsCount: 128,
    },
    {
      name: 'Apple MacBook Pro 16" (M3 Max, 36GB, 1TB)',
      slug: 'apple-macbook-pro-16-m3-max',
      description: 'Supercharged by M3 Max: With a 14-core CPU and 30-core GPU, the Apple M3 Max chip delivers phenomenal performance for demanding workflows.',
      shortDescription: '16.2-inch Liquid Retina XDR display, M3 Max chip with 14-core CPU.',
      price: 3499.00,
      comparePrice: 3699.00,
      category: catMap['Electronics'],
      vendor: vendor._id,
      images: [
        'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800',
        'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800',
      ],
      stock: 20,
      sku: 'MBP-16-M3MAX',
      tags: ['apple', 'laptop', 'macbook', 'm3', 'pro'],
      specifications: [
        { key: 'Processor', value: 'Apple M3 Max' },
        { key: 'Memory', value: '36GB Unified' },
        { key: 'Storage', value: '1TB SSD' },
        { key: 'Display', value: '16.2" Liquid Retina XDR' },
      ],
      isFeatured: true,
      freeShipping: true,
      rating: { average: 4.9, count: 85 },
      reviewsCount: 85,
    },
    {
      name: 'Nike Air Zoom Pegasus 40 Running Shoes',
      slug: 'nike-air-zoom-pegasus-40',
      description: 'A springy ride for every run, the Peg return to help you accomplish your goals. This version has the same responsiveness and neutral support you love.',
      shortDescription: 'Responsive cushioning and neutral support for runners of all levels.',
      price: 130.00,
      comparePrice: 160.00,
      category: catMap['Clothing'],
      vendor: vendor._id,
      images: [
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800',
        'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=800',
      ],
      stock: 60,
      sku: 'NIKE-PEG40-RED',
      tags: ['shoes', 'nike', 'running', 'sports', 'sneakers'],
      specifications: [
        { key: 'Brand', value: 'Nike' },
        { key: 'Closure', value: 'Lace-Up' },
        { key: 'Sole Material', value: 'Rubber' },
      ],
      variants: [
        {
          name: 'Size',
          options: [
            { label: 'US 8', price: 0, stock: 15, sku: 'PEG40-8' },
            { label: 'US 9', price: 0, stock: 20, sku: 'PEG40-9' },
            { label: 'US 10', price: 0, stock: 25, sku: 'PEG40-10' },
          ],
        },
      ],
      isFeatured: true,
      isDeals: true,
      freeShipping: true,
      rating: { average: 4.7, count: 210 },
      reviewsCount: 210,
    },
    {
      name: 'Samsung 65-Inch OLED 4K S90C Series Smart TV',
      slug: 'samsung-65-inch-oled-4k-s90c-tv',
      description: 'Quantum HDR OLED provides deeper blacks, vibrant colors, and unbelievable detail powered by Neural Quantum Processor 4K.',
      shortDescription: '65-inch 4K OLED with 144Hz refresh rate, Dolby Atmos, and Gaming Hub.',
      price: 1597.99,
      comparePrice: 2099.99,
      category: catMap['Electronics'],
      vendor: vendor._id,
      images: [
        'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=800',
        'https://images.unsplash.com/photo-1461151304267-38535e780c79?w=800',
      ],
      stock: 12,
      sku: 'SAM-S90C-65',
      tags: ['tv', 'samsung', 'oled', '4k', 'smart-tv'],
      isFeatured: true,
      isDeals: true,
      freeShipping: true,
      rating: { average: 4.8, count: 64 },
      reviewsCount: 64,
    },
    {
      name: 'Ergonomic Mesh Office Executive Chair',
      slug: 'ergonomic-mesh-office-executive-chair',
      description: 'High-back ergonomic office chair with dynamic lumbar support, 3D adjustable armrests, and breathable high-density mesh back.',
      shortDescription: 'High-back ergonomic mesh chair with adjustable lumbar support and 3D arms.',
      price: 249.99,
      comparePrice: 329.99,
      category: catMap['Home & Garden'],
      vendor: vendor._id,
      images: [
        'https://images.unsplash.com/photo-1580481077197-28d821217e94?w=800',
        'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800',
      ],
      stock: 35,
      sku: 'CHAIR-ERGO-BLK',
      tags: ['furniture', 'chair', 'office', 'ergonomic', 'home'],
      isFeatured: true,
      freeShipping: true,
      rating: { average: 4.6, count: 42 },
      reviewsCount: 42,
    },
  ];

  await Product.create(products);

  const coupons = [
    { code: 'FLASH50', type: 'percentage', value: 50, minOrderAmount: 50, maxDiscountAmount: 100, usageLimit: 1000, description: 'Flash 50% discount' },
    { code: 'SAVE20', type: 'percentage', value: 20, minOrderAmount: 30, maxDiscountAmount: 50, usageLimit: 500, description: '20% off your purchase' },
    { code: 'SAVE10', type: 'percentage', value: 10, minOrderAmount: 20, maxDiscountAmount: 30, usageLimit: 1000, description: '10% off your order' },
  ];

  await Coupon.create(coupons);

  console.log('✅ Auto-seed complete!');
};
