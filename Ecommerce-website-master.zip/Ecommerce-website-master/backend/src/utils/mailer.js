import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, // use TLS
  requireTLS: true,
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

export const sendOrderEmail = async (userEmail, orderDetails, status) => {
  try {
    const html = `
      <h3>Order ${status}</h3>
      <p>Your order ID is ${orderDetails._id}.</p>
      <p>Status: ${status}</p>
    `;

    if (!process.env.SMTP_EMAIL) {
      console.log('--- Email Simulation (sendOrderEmail) ---');
      console.log(`To: ${userEmail}`);
      console.log(`Content: ${html}`);
      return;
    }

    await transporter.sendMail({
      from: process.env.SMTP_EMAIL,
      to: userEmail,
      subject: `Order Update - ${status}`,
      html,
    });
  } catch (error) {
    console.error('Error sending order email:', error);
  }
};

export const sendResetPasswordEmail = async (userEmail, otp) => {
  try {
    const html = `
      <h3>Password Reset OTP</h3>
      <p>Your OTP for password reset is: <strong>${otp}</strong></p>
      <p>It will expire in 10 minutes.</p>
    `;

    if (!process.env.SMTP_EMAIL) {
      console.log('--- Email Simulation (sendResetPasswordEmail) ---');
      console.log(`To: ${userEmail}`);
      console.log(`Content: ${html}`);
      return;
    }

    await transporter.sendMail({
      from: process.env.SMTP_EMAIL,
      to: userEmail,
      subject: 'Password Reset OTP',
      html,
    });
  } catch (error) {
    console.error('Error sending password reset email:', error);
  }
};

export const sendLoginOtpEmail = async (userEmail, otp) => {
  try {
    const html = `
      <h3>Login OTP</h3>
      <p>Your login OTP is: <strong>${otp}</strong></p>
      <p>It will expire in 10 minutes.</p>
    `;

    if (!process.env.SMTP_EMAIL) {
      console.log('--- Email Simulation (sendLoginOtpEmail) ---');
      console.log(`To: ${userEmail}`);
      console.log(`Content: ${html}`);
      return;
    }

    await transporter.sendMail({
      from: process.env.SMTP_EMAIL,
      to: userEmail,
      subject: 'Login OTP',
      html,
    });
  } catch (error) {
    console.error('Error sending login OTP email:', error);
  }
};
