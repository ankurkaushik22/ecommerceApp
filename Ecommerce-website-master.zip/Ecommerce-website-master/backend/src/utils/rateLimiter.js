import redis from '../config/redis.js';

// Configuration helpers
const getConfig = () => ({
  authIpWindowMs: parseInt(process.env.RATE_LIMIT_AUTH_IP_WINDOW_MS || '900000', 10), // 15 mins
  authIpMax: parseInt(process.env.RATE_LIMIT_AUTH_IP_MAX || '15', 10),
  authAccountMax: parseInt(process.env.RATE_LIMIT_AUTH_ACCOUNT_MAX || '5', 10),
  authBackoffBaseSec: parseInt(process.env.RATE_LIMIT_AUTH_BACKOFF_BASE_SEC || '2', 10),
  authBackoffMaxSec: parseInt(process.env.RATE_LIMIT_AUTH_BACKOFF_MAX_SEC || '3600', 10), // 1 hour cap
  publicWindowMs: parseInt(process.env.RATE_LIMIT_PUBLIC_WINDOW_MS || '900000', 10), // 15 mins
  publicMax: parseInt(process.env.RATE_LIMIT_PUBLIC_MAX || '300', 10),
  authenticatedWindowMs: parseInt(process.env.RATE_LIMIT_AUTHENTICATED_WINDOW_MS || '900000', 10), // 15 mins
  authenticatedMax: parseInt(process.env.RATE_LIMIT_AUTHENTICATED_MAX || '2000', 10),
});

// Fallback in-memory stores when Redis is unavailable
const inMemoryStore = new Map();
const accountBackoffStore = new Map();

// Helper to clean expired in-memory keys
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of inMemoryStore.entries()) {
    if (record.resetAt <= now) {
      inMemoryStore.delete(key);
    }
  }
  for (const [key, record] of accountBackoffStore.entries()) {
    if (record.lockUntil <= now && record.consecutiveFails === 0) {
      accountBackoffStore.delete(key);
    }
  }
}, 60000);

/**
 * Normalizes account identifier (lowercased email/phone) for backoff tracking.
 */
export function normalizeIdentifier(identifier) {
  if (!identifier || typeof identifier !== 'string') return null;
  return identifier.trim().toLowerCase();
}

/**
 * Checks sliding window IP rate limit for a tier ('auth', 'public', 'authenticated').
 */
export async function checkIpRateLimit(ip, tier = 'public') {
  const config = getConfig();
  let windowMs = config.publicWindowMs;
  let maxRequests = config.publicMax;

  if (tier === 'auth') {
    windowMs = config.authIpWindowMs;
    maxRequests = config.authIpMax;
  } else if (tier === 'authenticated') {
    windowMs = config.authenticatedWindowMs;
    maxRequests = config.authenticatedMax;
  }

  const key = `ratelimit:${tier}:${ip}`;
  const now = Date.now();

  try {
    // Try Redis sliding window counter
    if (redis && redis.status === 'ready' && typeof redis.pipeline === 'function') {
      const windowStart = now - windowMs;
      const pipeline = redis.pipeline();
      pipeline.zremrangebyscore(key, 0, windowStart);
      pipeline.zadd(key, now, `${now}-${Math.random()}`);
      pipeline.zcard(key);
      pipeline.expire(key, Math.ceil(windowMs / 1000));
      const results = await pipeline.exec();
      const requestCount = results[2][1];

      return {
        allowed: requestCount <= maxRequests,
        remaining: Math.max(0, maxRequests - requestCount),
        total: maxRequests,
        resetMs: windowMs,
      };
    }
  } catch (err) {
    // Fallback to in-memory store on Redis failure
  }

  // In-Memory Fallback
  let record = inMemoryStore.get(key);
  if (!record || record.resetAt <= now) {
    record = { count: 0, resetAt: now + windowMs };
    inMemoryStore.set(key, record);
  }
  record.count += 1;

  return {
    allowed: record.count <= maxRequests,
    remaining: Math.max(0, maxRequests - record.count),
    total: maxRequests,
    resetMs: Math.max(0, record.resetAt - now),
  };
}

/**
 * Checks per-account auth backoff status.
 * If account exceeds consecutive failed attempts, enforces exponential backoff delay.
 */
export async function checkAccountAuthBackoff(rawIdentifier) {
  const identifier = normalizeIdentifier(rawIdentifier);
  if (!identifier) return { allowed: true, retryAfterSeconds: 0 };

  const config = getConfig();
  const key = `authbackoff:${identifier}`;
  const now = Date.now();

  let consecutiveFails = 0;
  let lockUntil = 0;

  try {
    if (redis && redis.status === 'ready' && typeof redis.hgetall === 'function') {
      const data = await redis.hgetall(key);
      if (data && data.fails) {
        consecutiveFails = parseInt(data.fails, 10);
        lockUntil = parseInt(data.lockUntil || '0', 10);
      }
    } else {
      const record = accountBackoffStore.get(key);
      if (record) {
        consecutiveFails = record.consecutiveFails;
        lockUntil = record.lockUntil;
      }
    }
  } catch (err) {
    const record = accountBackoffStore.get(key);
    if (record) {
      consecutiveFails = record.consecutiveFails;
      lockUntil = record.lockUntil;
    }
  }

  if (lockUntil > now) {
    const retryAfterSeconds = Math.ceil((lockUntil - now) / 1000);
    return {
      allowed: false,
      retryAfterSeconds,
      consecutiveFails,
      message: `Too many failed login attempts. Please wait ${retryAfterSeconds} seconds before trying again.`,
    };
  }

  return { allowed: true, retryAfterSeconds: 0, consecutiveFails };
}

/**
 * Records a failed authentication attempt for an account identifier and calculates exponential backoff.
 */
export async function recordAuthFailure(rawIdentifier) {
  const identifier = normalizeIdentifier(rawIdentifier);
  if (!identifier) return;

  const config = getConfig();
  const key = `authbackoff:${identifier}`;
  const now = Date.now();

  const current = await checkAccountAuthBackoff(identifier);
  const newFails = (current.consecutiveFails || 0) + 1;

  let lockDurationMs = 0;
  if (newFails >= config.authAccountMax) {
    const exponent = newFails - config.authAccountMax;
    const backoffSec = Math.min(
      config.authBackoffBaseSec * Math.pow(2, exponent),
      config.authBackoffMaxSec
    );
    lockDurationMs = backoffSec * 1000;
  }

  const lockUntil = now + lockDurationMs;

  try {
    if (redis && redis.status === 'ready' && typeof redis.hmset === 'function') {
      await redis.hmset(key, {
        fails: newFails,
        lockUntil,
      });
      await redis.expire(key, 86400); // 24 hour TTL
    }
  } catch (err) {
    // Ignore Redis errors
  }

  accountBackoffStore.set(key, {
    consecutiveFails: newFails,
    lockUntil,
  });
}

/**
 * Resets backoff state upon successful authentication.
 */
export async function recordAuthSuccess(rawIdentifier) {
  const identifier = normalizeIdentifier(rawIdentifier);
  if (!identifier) return;

  const key = `authbackoff:${identifier}`;

  try {
    if (redis && redis.status === 'ready' && typeof redis.del === 'function') {
      await redis.del(key);
    }
  } catch (err) {
    // Ignore Redis errors
  }

  accountBackoffStore.delete(key);
}
