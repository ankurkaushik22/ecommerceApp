/**
 * Utility for verifying file content signatures (magic bytes) to prevent extension spoofing and file upload attacks.
 */

// Executable signatures that MUST be rejected unconditionally
const EXECUTABLE_SIGNATURES = [
  [0x4d, 0x5a], // Windows PE (EXE, DLL)
  [0x7f, 0x45, 0x4c, 0x46], // Linux ELF
  [0x23, 0x21], // Shebang (#! script)
  [0xca, 0xfe, 0xba, 0xbe], // Java class file / Mach-O
  [0xfe, 0xed, 0xfa, 0xce], // Mach-O binary
  [0xfe, 0xed, 0xfa, 0xcf], // Mach-O 64-bit
];

/**
 * Checks whether buffer contains any executable header signature.
 */
export function isExecutableContent(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 2) return false;
  for (const sig of EXECUTABLE_SIGNATURES) {
    if (buffer.length >= sig.length) {
      let matches = true;
      for (let i = 0; i < sig.length; i++) {
        if (buffer[i] !== sig[i]) {
          matches = false;
          break;
        }
      }
      if (matches) return true;
    }
  }
  return false;
}

/**
 * Validates image buffer content signature against JPEG, PNG, or WebP magic bytes.
 */
export function validateImageSignature(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) {
    return { valid: false, error: 'File buffer is too small or invalid' };
  }

  if (isExecutableContent(buffer)) {
    return { valid: false, error: 'Security Violation: Executable file content detected' };
  }

  // JPEG: FF D8 FF
  const isJpeg = buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;

  // PNG: 89 50 4E 47
  const isPng = buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4e && buffer[3] === 0x47;

  // WebP: RIFF ... WEBP
  const isWebp =
    buffer[0] === 0x52 &&
    buffer[1] === 0x49 &&
    buffer[2] === 0x46 &&
    buffer[3] === 0x46 &&
    buffer[8] === 0x57 &&
    buffer[9] === 0x45 &&
    buffer[10] === 0x42 &&
    buffer[11] === 0x50;

  if (!isJpeg && !isPng && !isWebp) {
    return {
      valid: false,
      error: 'Invalid image format signature. Only genuine JPEG, PNG, and WebP images are permitted.',
    };
  }

  return { valid: true };
}

/**
 * Validates ZIP archive buffer header magic bytes.
 */
export function validateZipSignature(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4) {
    return { valid: false, error: 'Invalid ZIP file buffer' };
  }

  if (isExecutableContent(buffer)) {
    return { valid: false, error: 'Security Violation: Executable file content detected' };
  }

  // ZIP magic bytes: PK\x03\x04 or PK\x05\x06 or PK\x07\x08
  const isZip =
    buffer[0] === 0x50 &&
    buffer[1] === 0x4b &&
    (buffer[2] === 0x03 || buffer[2] === 0x05 || buffer[2] === 0x07) &&
    (buffer[3] === 0x04 || buffer[3] === 0x06 || buffer[3] === 0x08);

  if (!isZip) {
    return { valid: false, error: 'Invalid ZIP archive signature.' };
  }

  return { valid: true };
}

/**
 * Validates CSV text buffer.
 */
export function validateCsvContent(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    return { valid: false, error: 'CSV file is empty' };
  }

  if (isExecutableContent(buffer)) {
    return { valid: false, error: 'Security Violation: Executable file content detected' };
  }

  // Check for binary null bytes or non-text control characters
  for (let i = 0; i < Math.min(buffer.length, 1024); i++) {
    const byte = buffer[i];
    if (byte === 0x00) {
      return { valid: false, error: 'CSV file contains illegal binary data.' };
    }
  }

  return { valid: true };
}
